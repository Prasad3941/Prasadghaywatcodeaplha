webpackJsonpqap([2], {
    11: function(t, n, e) {
        "use strict";
        var o = this && this.__extends || function() {
            var t = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, n) {
                t.__proto__ = n
            } || function(t, n) {
                for (var e in n) n.hasOwnProperty(e) && (t[e] = n[e])
            };
            return function(n, e) {
                function o() {
                    this.constructor = n
                }
                t(n, e), n.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o)
            }
        }();
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var r = e(5),
            i = function(t) {
                function n() {
                    return null !== t && t.apply(this, arguments) || this
                }
                return o(n, t), n.style = e(40), n.template = e(36), n
            }(r.BaseTemplate);
        n.Template = i
    },
    30: function(t, n, e) {
        n = t.exports = e(6)(), n.push([t.i, ".qap-image,.qap-image a{display:block;height:100%;width:100%}.qap-image img{height:100%;width:100%}", ""])
    },
    36: function(module, exports) {
        module.exports = function(obj) {
            obj || (obj = {});
            var __t, __p = "";
            with(obj) __p += '<div class="qap-image">\n  <a href="' + (null == (__t = landingURL) ? "" : __t) + '" target="_blank" rel="noopener" ' + (null == (__t = clickTracker) ? "" : __t) + '>\n    <img src="' + (null == (__t = imageURL) ? "" : __t) + '">\n  </a>\n</div>';
            return __p
        }
    },
    40: function(t, n, e) {
        var o, r = 0,
            i = e(30);
        "string" == typeof i && (i = [
            [t.i, i, ""]
        ]), n.use = n.ref = function() {
            return r++ || (n.locals = i.locals, o = e(7)(i, {})), n
        }, n.unuse = n.unref = function() {
            --r || (o(), o = null)
        }
    }
});