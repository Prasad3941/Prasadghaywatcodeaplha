wbJsonp([0], [, function(e, t) {
    e.exports = function(e, t) {
        var i = {
            init: function() {
                var e = document.getElementById("state-list-header");
                "undefined" != typeof jQuery && e && (e.style.display = "none", document.getElementById("state-toggle").addEventListener("click", function() {
                    jQuery(this).toggleClass("top-city"), jQuery(this).find(".icon-arrow").toggleClass("icon-arrow-rotate"), jQuery(".state-list").slideToggle()
                }))
            },
            selectState: function(e) {
                if (e.target && e.target.innerText) {
                    var i = e.target.innerText;
                    t.setCookie("new_prefer_state_id", e.target.getAttribute("data-sid"), ".quikr.com", "1"), t.setCookie("new_prefer_state", i.toLowerCase(), ".quikr.com", "1"), jQuery("#cityDropdown").hide(), window.location.reload()
                }
            }
        };
        return i.init(), {
            selectState: i.selectState
        }
    }(document, JsLib)
}]);