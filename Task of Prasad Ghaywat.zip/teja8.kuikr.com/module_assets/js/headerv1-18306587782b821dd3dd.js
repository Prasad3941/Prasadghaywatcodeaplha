var JsLib = {
        getElementById: function(e) {
            return document.getElementById(e)
        },
        toggle: function(e) {
            "block" == e.style.display ? e.style.display = "none" : e.style.display = "block"
        },
        show: function(e) {
            "string" == typeof e ? this.getElementById(e).style.display = "block" : e.style.display = "block"
        },
        hide: function(e) {
            "string" == typeof e ? this.getElementById(e).style.display = "none" : e.style.display = "none"
        },
        isEmpty: function(e) {
            return !(("string" == typeof e ? this.getElementById(e).children.length : e.children.length) > 0)
        },
        prev: function(e, t, n) {
            var i = e.previousElementSibling;
            if (!i) return null;
            var a = i.nodeName.toLowerCase(),
                o = t || null,
                s = n || "element",
                r = "name" == s ? a : i;
            return o ? (a != o && (r = this.prev(i, o, s)), r) : r
        },
        next: function(e, t, n) {
            var i = e.nextElementSibling;
            if (!i) return null;
            var a = i.nodeName.toLowerCase(),
                o = t || null,
                s = n || "element",
                r = "name" == s ? a : i;
            return o ? (a != o && (r = this.next(i, o, s)), r) : r
        },
        parent: function(e, t, n) {
            var i = e.parentElement;
            if (!i) return null;
            var a = i.nodeName.toLowerCase(),
                o = t || null,
                s = n || "element",
                r = "name" == s ? a : i;
            return o ? (a != o && (r = this.parent(i, o, s)), r) : r
        },
        lastParent: function(e, t) {
            var n = e.parentElement;
            if (!n) return null;
            var i = n.nodeName.toLowerCase(),
                a = t || "element",
                o = "name" == a ? n.children[0].nodeName.toLowerCase() : n.children[0];
            return "body" != i && (o = this.lastParent(n, a)), o
        },
        isInsideModal: function(e) {
            try {
                var t = e.getAttribute("data-type");
                if (t && "overlay" == t) return !0
            } catch (e) {}
            for (var n = e.parentNode; null != n;) {
                try {
                    var t = n.getAttribute("data-type");
                    if (t && "overlay" == t) return !0
                } catch (e) {}
                n = n.parentNode
            }
            return !1
        },
        isModalInitiator: function(e) {
            try {
                var t = e.getAttribute("data-togg");
                if (t && ("modal" == t || "dropdown" == t)) return !0
            } catch (e) {}
            for (var n = e.parentNode; null != n;) {
                try {
                    var t = n.getAttribute("data-togg");
                    if (t && ("modal" == t || "dropdown" == t)) return !0
                } catch (e) {}
                n = n.parentNode
            }
            return !1
        },
        child: function(e, t, n) {
            if (!t) return null;
            var i = e.children;
            if (!i) return null;
            for (var a = n || "element", o = null, s = 0; s < i.length; s++) {
                var r = i[s];
                if (r.nodeName.toLowerCase() == t) {
                    o = "name" == a ? r.nodeName : r;
                    break
                }
                if (null != (o = this.child(r, t))) break
            }
            return o
        },
        hasChild: function(e, t) {
            if (!t) return null;
            var n = e.children,
                i = !1;
            if (!n) return null;
            for (var a = 0; a < n.length; a++) {
                var o = n[a];
                if (o === t) {
                    i = !0;
                    break
                }
                if (!(i = this.child(o, t))) break
            }
            return i
        },
        navigateListDown: function(e, t, n, i) {
            var a = null,
                o = t.nodeName.toLowerCase();
            if (null == (a = n ? JsLib.next(JsLib.parent(t)) : JsLib.next(t))) return void e.focus();
            var s = JsLib.child(a, i);
            null != s ? JsLib.child(s, o).focus() : JsLib.child(a, o).focus()
        },
        navigateListUp: function(e, t, n, i, a) {
            var o = null,
                s = null,
                r = t.nodeName.toLowerCase();
            n ? (s = JsLib.parent(t), o = JsLib.prev(s)) : s = o = JsLib.prev(t), JsLib.parent(s, null, "name") == i ? null == o ? JsLib.child(JsLib.prev(JsLib.parent(t, a)), r).focus() : JsLib.child(o, r).focus() : null == o ? e.focus() : JsLib.child(o, r).focus()
        },
        hideAllModals: function(e) {
            var t = document.querySelectorAll('[data-type="overlay"]'),
                n = "";
            void 0 !== e && (n = e);
            for (var i = 0; i < t.length; i++) n != t[i].getAttribute("id") && this.hide(t[i])
        },
        hideOtherModals: function(e) {
            for (var t = document.querySelectorAll('[data-type="overlay"]'), n = 0; n < t.length; n++) e !== t[n] && this.hide(t[n])
        },
        asyncCssLoad: function(e, t) {
            var n = document.getElementsByTagName("head")[0],
                i = document.createElement("link");
            i.rel = "stylesheet", i.type = "text/css", i.href = e, i.onload = t, n.appendChild(i)
        },
        loaderInOverlay: function(e) {
            var t = document.getElementsByClassName("simple-overlay")[0];
            if (t) {
                var n = document.createElement("div");
                e = e || "Loadin, please wait...", n.textContent = e, t.appendChild(n);
                var i = t.querySelector("div");
                return i.style.color = "#fff", i.style.fontSize = "22px", i.style.position = "absolute", i.style.left = 0, i.style.right = 0, i.style.top = "110px", i.style.textAlign = "center", i.style.fontWeight = "bold", n
            }
            return null
        },
        removeLoaderInOverlay: function(e) {
            var t = document.getElementsByClassName("simple-overlay")[0];
            t && e && t.removeChild(e)
        },
        removeDataAttributes: function(e, t) {
            "[object Array]" == Object.prototype.toString.call(t) ? t.forEach(function(t) {
                delete e.dataset.a
            }) : "string" == typeof t && delete e.dataset.attr
        },
        getCookie: function(e) {
            if (("__m" == e || "__n" == e || "__u" == e) && !userObj.authCk) return userObj.ck[e];
            var t, n, i, a = document.cookie.split(";");
            for (t = 0; t < a.length; t++)
                if (n = a[t].substr(0, a[t].indexOf("=")), i = a[t].substr(a[t].indexOf("=") + 1), (n = n.replace(/^\s+|\s+$/g, "")) == e) return unescape(i)
        },
        setCookie: function(e, t, n, i) {
            var a = new Date,
                o = new Date;
            if (i) {
                o.setTime(a.getTime() + 864e5 * i);
                var s = "; expires=" + o.toUTCString()
            } else var s = "";
            document.cookie = e + "=" + encodeURIComponent(t) + "; domain=" + n + "; path=/" + s
        }
    },
    PUB_SUB = {
        events: {},
        on: function(e, t) {
            this.events[e] = this.events[e] || [], this.events[e].push(t)
        },
        off: function(e, t) {
            if (this.events[e])
                for (var n = 0; n < this.events[e].length; n++)
                    if (this.events[e][n] === t) {
                        this.events[e].splice(n, 1);
                        break
                    }
        },
        emit: function(e, t) {
            this.events[e] && this.events[e].forEach(function(e) {
                e(t)
            })
        }
    };
! function(e, t) {
    "function" == typeof define && define.amd ? define(t) : "object" == typeof exports ? module.exports = t : e.ajax = t(e)
}(this, function(e) {
    "use strict";
    var t = {},
        n = null,
        i = {
            contentType: "application/x-www-form-urlencoded"
        },
        a = function(e) {
            var t;
            try {
                t = JSON.parse(e.responseText)
            } catch (n) {
                t = e.responseText
            }
            return [t, e]
        },
        o = function(t, o, s) {
            var r = {
                    success: function() {},
                    error: function() {},
                    always: function() {}
                },
                c = e.XMLHttpRequest || ActiveXObject,
                l = new c("MSXML2.XMLHTTP.3.0");
            l.open(t, o, !0), l.setRequestHeader("Content-type", i.contentType), l.onreadystatechange = function() {
                var e;
                4 === l.readyState && (e = a(l), l.status >= 200 && l.status < 300 ? r.success.apply(r, e) : r.error.apply(r, e), r.always.apply(r, e))
            }, n = l, l.send(s);
            var c = {
                success: function(e) {
                    return r.success = e, c
                },
                error: function(e) {
                    return r.error = e, c
                },
                always: function(e) {
                    return r.always = e, c
                }
            };
            return c
        };
    return t.get = function(e) {
        return o("GET", e)
    }, t.put = function(e, t) {
        return o("PUT", e, t)
    }, t.post = function(e, t) {
        return o("POST", e, t)
    }, t.delete = function(e) {
        return o("DELETE", e)
    }, t.abort = function() {
        n.abort()
    }, t.getRequest = function() {
        return n
    }, t.setContentType = function(e) {
        i.contentType = e
    }, t
}),
function(e) {
    function t(n) {
        if (i[n]) return i[n].exports;
        var a = i[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(a.exports, a, a.exports, t), a.l = !0, a.exports
    }
    var n = window.wbJsonp;
    window.wbJsonp = function(t, i, o) {
        for (var s, r, c = 0, l = []; c < t.length; c++) r = t[c], a[r] && l.push(a[r][0]), a[r] = 0;
        for (s in i) Object.prototype.hasOwnProperty.call(i, s) && (e[s] = i[s]);
        for (n && n(t, i, o); l.length;) l.shift()()
    };
    var i = {},
        a = {
            11: 0
        };
    t.e = function(e) {
        function n() {
            r.onerror = r.onload = null, clearTimeout(c);
            var t = a[e];
            0 !== t && (t && t[1](new Error("Loading chunk " + e + " failed.")), a[e] = void 0)
        }
        var i = a[e];
        if (0 === i) return new Promise(function(e) {
            e()
        });
        if (i) return i[2];
        var o = new Promise(function(t, n) {
            i = a[e] = [t, n]
        });
        i[2] = o;
        var s = document.getElementsByTagName("head")[0],
            r = document.createElement("script");
        r.type = "text/javascript", r.charset = "utf-8", r.async = !0, r.timeout = 12e4, t.nc && r.setAttribute("nonce", t.nc), r.src = t.p + "" + e + ".headerv1-18306587782b821dd3dd.js";
        var c = setTimeout(n, 12e4);
        return r.onerror = r.onload = n, s.appendChild(r), o
    }, t.m = e, t.c = i, t.d = function(e, n, i) {
        t.o(e, n) || Object.defineProperty(e, n, {
            configurable: !1,
            enumerable: !0,
            get: i
        })
    }, t.n = function(e) {
        var n = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return t.d(n, "a", n), n
    }, t.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, t.p = "https://teja8.kuikr.com/module_assets/js/", t.oe = function(e) {
        throw console.error(e), e
    }, t(t.s = 10)
}({
    10: function(e, t, n) {
        e.exports = n(2)
    },
    2: function(e, t, n) {
        ! function(e, t) {
            var i = {
                init: function() {
                    this.cacheDom(), this.bindEvents(), window.pageRequestMap = this.pageRequestMap
                },
                isSessionAvailable: function() {
                    if (void 0 != typeof localStorage) {
                        const e = "logintooltip";
                        var t = localStorage.getItem(e);
                        if (t && void 0 != t && null != t) {
                            if (t < 3) {
                                var n = parseInt(t);
                                return localStorage.setItem(e, n + 1), !0
                            }
                            return !1
                        }
                        return localStorage.setItem(e, 1), !0
                    }
                    return !0
                },
                cacheDom: function() {
                    this.$mHeader = e.getElementById("mHeaderAPI"), this.$hamburger = e.getElementById("hamburger"), this.$hamBox = e.getElementById("hamBox"), this.$cityBtn = e.getElementById("hSelectCity"), this.$searchForm = e.getElementById("searchFormIndex"), this.$searchByCat = e.getElementById("searchedCat"), this.$searchInput = e.getElementById("query"), this.$submitSearch = e.getElementById("submitSearch"), this.$loginLink = e.getElementById("loginLink"), this.$hamLoginLink = e.getElementById("hamLoginLink"), this.$hamLogoutLink = e.getElementById("hamLogoutLink"), this.$dashboardMenu = e.getElementById("dashboardMenu"), this.$autoSuggestFlag = e.getElementById("isAutoSuggest"), this.$languageSelectLink = e.getElementById("languageSelectLink"), this.$myChatsLink = e.getElementById("myChatsLink"), this.$myOffersLink = e.getElementById("myOffersLink"), this.$uCredits = e.getElementById("uCredits"), this.$headerbl = e.getElementById("headerbl"), this.$headerbla = e.getElementById("headerbla"), this.$msp = e.getElementById("msp"), this.$nxtIcn = e.getElementById("nxtIcn"), this.$allDropdowns = e.querySelectorAll('[data-togg="dropdown"]'), this.$appDownloadLink = e.getElementById("app-link"), this.$postAdBtn = e.getElementById("postAdBtn"), this.$loggedInMyAc = e.getElementById("loggedInMyAc"), this.$acMyAds = e.getElementById("acMyAds"), this.$acMyDSOffers = e.getElementById("acMyDSOffers"), this.$acMyChats = e.getElementById("acMyChats"), this.$acMyAlerts = e.getElementById("acMyAlerts"), this.$acMyOrders = e.getElementById("acMyOrders"), this.$acMyProfUpdate = e.getElementById("acMyProfUpdate"), this.$acReco = e.getElementById("acReco"), this.$acMyLeads = e.getElementById("acMyLeads"), this.$cartIconHeader = e.getElementById("cartIconHeader"), this.$employer = e.getElementById("h_employer"), this.$jobSeeker = e.getElementById("h_jobSeeker"), this.$favourites = e.getElementById("h_fav"), this.$desktopSlots = e.querySelectorAll("[data-slot]"), this.$stateSelect = e.querySelectorAll("a[data-sid]"), this.$quikrLogo = e.getElementById("quikrLogo"), this.$bulkOredr = e.getElementById("bulkOrder")
                },
                bindEvents: function() {
                    if (e.addEventListener("keyup", this.bodyKeyUp), e.addEventListener("click", this.bodyClick), "complete" == document.readyState ? (this.geoLocationHandler(), this.notificationHandler(), this.checkHamburger.call(this), this.recentSearchInit.call(this), this.stateSelection(), this.autoSuggestInit()) : (window.addEventListener("load", this.geoLocationHandler), window.addEventListener("load", this.notificationHandler), window.addEventListener("load", this.checkHamburger.bind(this)), window.addEventListener("load", this.recentSearchInit.bind(this)), window.addEventListener("load", this.stateSelection), window.addEventListener("load", this.autoSuggestInit)), window.addEventListener("hashchange", this.checkHashChange.bind(this)), this.$stateSelect && this.$stateSelect.length > 0)
                        for (var t = 0; t < this.$stateSelect.length; t++) this.$stateSelect[t].addEventListener("click", this.stateSelect);
                    if (this.$hamburger && this.$hamburger.addEventListener("click", this.hamburger), this.$cityBtn && this.$cityBtn.addEventListener("click", this.city), this.$searchByCat && this.$searchByCat.addEventListener("click", this.searchByCat), this.$searchForm ? (this.$searchForm.addEventListener("submit", this.submitSearch), this.$searchInput.addEventListener("click", this.searchFocus), this.$autoSuggestFlag && this.$searchInput.addEventListener("keyup", this.autoSuggest), this.$submitSearch && this.$submitSearch.addEventListener("click", this.submitSearch)) : this.adjustHeaderHeight.call(this), this.$loginLink && this.$loginLink.addEventListener("click", this.loginLink), this.$dashboardMenu && this.$dashboardMenu.addEventListener("click", this.dashboardMenuClick), this.$uCredits && (this.$uCredits.addEventListener("mouseover", this.credits), this.$uCredits.addEventListener("click", this.creditsClick)), this.$headerbl && this.$headerbl.addEventListener("mouseover", this.blpopover), this.$headerbl && this.$headerbl.addEventListener("click", this.blclicked), this.$headerbla && this.$headerbla.addEventListener("click", this.blclicked), this.$languageSelectLink && this.$languageSelectLink.addEventListener("click", this.languageSelectLink), this.$myChatsLink && this.$myChatsLink.addEventListener("click", this.myChatsLinkClicked.bind(this)), this.$myOffersLink && this.$myOffersLink.addEventListener("click", this.myOffersClicked), this.$allDropdowns.length > 0)
                        for (var t = 0; t < this.$allDropdowns.length; t++) this.$allDropdowns[t].addEventListener("click", this.toggleDropdown);
                    if (this.$msp && this.$msp.addEventListener("click", this.mspLinkClicked), this.$nxtIcn && this.$nxtIcn.addEventListener("click", this.nxtIcnLinkClicked), this.$appDownloadLink && this.$appDownloadLink.addEventListener("click", this.appDownloadLinkClicked), this.$postAdBtn && this.$postAdBtn.addEventListener("click", this.postAdBtnClicked), this.$loggedInMyAc && this.$loggedInMyAc.addEventListener("click", this.myAcClicked), this.$acMyAds && this.$acMyAds.addEventListener("click", this.myAdsClicked), this.$acMyDSOffers && this.$acMyDSOffers.addEventListener("click", this.myDoorstepClicked), this.$acMyChats && this.$acMyChats.addEventListener("click", this.myChatsClicked), this.$acMyAlerts && this.$acMyAlerts.addEventListener("click", this.myAlertsClicked), this.$acMyOrders && this.$acMyOrders.addEventListener("click", this.myOrdersClicked), this.$acMyProfUpdate && this.$acMyProfUpdate.addEventListener("click", this.myProfileUpdateClicked), this.$acReco && this.$acReco.addEventListener("click", this.myRecoClicked), this.$acMyLeads && this.$acMyLeads.addEventListener("click", this.myLeadsLinkClicked), this.$cartIconHeader && this.$cartIconHeader.addEventListener("click", this.cartIconClicked), this.$employer && this.$employer.addEventListener("click", this.employerClicked), this.$jobSeeker && this.$jobSeeker.addEventListener("click", this.jobSeekerClicked), this.$favourites && this.$favourites.addEventListener("click", this.favouritesClicked), this.$desktopSlots && this.$desktopSlots.length > 0)
                        for (var t = 0; t < this.$desktopSlots.length; t++) this.$desktopSlots[t].addEventListener("click", this.desktopSlotsClicked);
                    this.$quikrLogo && this.$quikrLogo.addEventListener("click", this.quikrLogoClicked), this.$bulkOredr && this.$bulkOredr.addEventListener("click", this.bulkOrderClicked), PUB_SUB.on("chat_notification", this.popChatNotifications), PUB_SUB.on("my_offers_count", this.updateMyOffersCount), PUB_SUB.on("favourites_count", this.updateFavCount), PUB_SUB.on("language_select_link", this.languageSelectLink), PUB_SUB.on("do_login", this.doLogin.bind(this)), PUB_SUB.on("close_overlay", this.toggleOverlay), PUB_SUB.on("update_city", this.updateCity.bind(this))
                },
                bulkOrderClicked: function(e) {
                    PUB_SUB.emit("bulk_orders_clicked")
                },
                bodyKeyUp: function(e) {
                    27 == e.keyCode && (t.hideAllModals(), i.toggleOverlay(!1))
                },
                bodyClick: function(e) {
                    t.isInsideModal(e.target) || t.isModalInitiator(e.target) || ("#hamburgerMenu" === location.hash && history && history.pushState("", document.title, window.location.pathname), i.toggleOverlay(!1), t.hideAllModals())
                },
                toggleDropdown: function(n) {
                    n.preventDefault();
                    var a = this.getAttribute("data-area"),
                        o = e.getElementById(a);
                    o && ("block" == o.style.display && i.toggleOverlay(!1), t.hideAllModals(a), t.toggle(o))
                },
                hamburger: function(e) {
                    PUB_SUB.emit("hamburger_clicked");
                    var t = 0;
                    "undefined" != typeof isMobileRequest && (t = Number(isMobileRequest));
                    var a = this;
                    n.e(1).then(function(e) {
                        if (history && "#hamburgerMenu" !== location.hash && t) {
                            var i = window.location.pathname;
                            window.location.search && (i += window.location.search), history.pushState("", document.title, i + "#hamburgerMenu")
                        }
                        n(0).toggleHamBurger(a)
                    }.bind(null, n)).catch(n.oe), i.toggleOverlay(!0)
                },
                city: function(e) {
                    n.e(8).then(function(e) {
                        n(3)
                    }.bind(null, n)).catch(n.oe), PUB_SUB.emit("city_button_clicked")
                },
                searchByCat: function(e) {
                    n.e(3).then(function(e) {
                        n(4)
                    }.bind(null, n)).catch(n.oe), PUB_SUB.emit("searchedCat_click")
                },
                submitSearch: function(t) {
                    t.preventDefault();
                    var n = {
                        keyword: e.getElementById("query").value.trim(),
                        catName: this.getAttribute("data-catName")
                    };
                    PUB_SUB.emit("submit_search", n), getEventTrackGA({
                        category: "quikr",
                        action: "quikr_" + pageRequestMap(PAGEREQUEST) + "_search",
                        label: "quikr_" + pageRequestMap(PAGEREQUEST) + "_search_freetext_click_" + n.keyword
                    });
                    var i = document.querySelector("#searchedCat > span").innerText;
                    "string" == typeof i && (i = i.replace(/ /gi, "_"));
                    var a = window.currentCatName;
                    return "All_Categories" != i || a ? "All_Categories" == i && a ? sessionStorage.setItem("pageViewGa", "/searchflow_vp_" + a + "_nocat") : "All_Categories" == i || a ? "All_Categories" != i && a && sessionStorage.setItem("pageViewGa", "/searchflow_vp_" + a + "_" + i) : sessionStorage.setItem("pageViewGa", "/searchflow_hp_" + i) : sessionStorage.setItem("pageViewGa", "/searchflow_hp_nocat"), !1
                },
                searchFocus: function() {
                    PUB_SUB.emit("search_input_focus")
                },
                autoSuggest: function(e) {
                    if (13 != e.keyCode) {
                        PUB_SUB.emit("auto_suggest_keyword", e.target.value.trim());
                        var t = document.querySelector("#searchedCat > span").innerText;
                        "All Categories" == t && (t = "nocat"), sessionStorage.setItem("pageViewGa", "/searchflow_autosuggest_" + t)
                    }
                },
                loginLink: function(e) {
                    const t = parseInt(JsLib.getCookie("abRand")) || 100 * Math.random();
                    var n = 1;
                    if (document.getElementById("abRandLogin") && (n = parseInt(document.getElementById("abRandLogin").getAttribute("value")) || 1), t <= n) {
                        document.getElementById("newLogin_Div").style.display = "block", document.body.style.overflow = "hidden", document.getElementsByClassName("simple-overlay")[0].style.display = "none", document.getElementById("newLoginModal").innerHTML = '<img class="ajLoader" src="/public/core/images/ajax-loader.gif" />';
                        var a = function(e) {
                            e.preventDefault(), e.stopPropagation(), document.getElementById("newLogin_Div").style.display = "none", document.body.style.overflow = ""
                        };
                        document.getElementById("newLoginModalBG").addEventListener("click", a);
                        var o = function(e) {
                            e.preventDefault(), e.stopPropagation()
                        };
                        document.getElementById("newLoginModal").addEventListener("click", o), ajax.post("/core/new-login-popup").success(function(e) {
                            e.indexOf("User Already Logged In") > 0 ? window.location.reload() : (jQuery("#newLoginModal").html(e), document.getElementById("newLoginModal").removeEventListener("click", o))
                        }).error(function(e) {})
                    } else PUB_SUB.emit("login_modal", e), i.toggleOverlay(!0)
                },
                signOutLink: function(e) {
                    PUB_SUB.emit("sign_out_click")
                },
                dashboardMenuClick: function(e) {
                    switch (e.target.id) {
                        case "mobileLoginLink":
                            i.loginLink(e), this.style.display = "none";
                            break;
                        case "signOutLink":
                            i.signOutLink(e), this.style.display = "none";
                            break;
                        case "myac":
                            PUB_SUB.emit("dashboard_menu_my_ac_clicked");
                            break;
                        case "mycart":
                            PUB_SUB.emit("dashboard_menu_my_cart_clicked")
                    }
                },
                credits: function(e) {
                    n.e(7).then(function(t) {
                        n(5).popoverBox(e)
                    }.bind(null, n)).catch(n.oe)
                },
                creditsClick: function(e) {
                    getEventTrackGA({
                        category: window.HEADER_GA_CATEGORY ? window.HEADER_GA_CATEGORY : "quikr_" + pageRequestMap(PAGEREQUEST),
                        action: "Header",
                        label: "Discounts_on_Premium_ads"
                    })
                },
                blpopover: function(e) {
                    n.e(9).then(function(t) {
                        n(6).popoverBox(e)
                    }.bind(null, n)).catch(n.oe)
                },
                blclicked: function(e) {
                    PUB_SUB.emit("business_link_click")
                },
                languageSelectLink: function() {
                    PUB_SUB.emit("lang_link_click"), n.e(5).then(function(e) {
                        n(7)
                    }.bind(null, n)).catch(n.oe)
                },
                employerClicked: function() {
                    PUB_SUB.emit("employer_icon_click")
                },
                jobSeekerClicked: function() {
                    PUB_SUB.emit("job_seeker_icon_click")
                },
                favouritesClicked: function() {
                    PUB_SUB.emit("favourites_icon_click")
                },
                adjustHeaderHeight: function() {
                    this.$mHeader && (this.$mHeader.style.height = "44px")
                },
                updateFavCount: function(t) {
                    if (!(parseInt(t, 10) != t || t <= 0)) {
                        var n = e.querySelectorAll('[data-type="fav_count"]');
                        if (n.length > 0)
                            for (var a = 0; a < n.length; a++) n[a].innerHTML = t, n[a].parentElement.className += " active";
                        i.updateGlobalNotification(t, "fav_count")
                    }
                },
                updateMyOffersCount: function(t) {
                    if (!(parseInt(t, 10) != t || t <= 0)) {
                        var n = e.querySelectorAll('[data-type="my_offers_notif"]');
                        if (n.length > 0)
                            for (var a = 0; a < n.length; a++) n[a].innerHTML = t;
                        i.updateGlobalNotification(t, "my_offers_notif")
                    }
                },
                myChatsLinkClicked: function(t) {
                    (e.getElementById("loginLink") ? 0 : 1) ? window.location = "/MyQuikr?action=mychats": "function" == typeof logInRegisterPopUp && logInRegisterPopUp(this, t), PUB_SUB.emit("my_chats_clicked")
                },
                myOffersClicked: function(e) {
                    getEventTrackGA({
                        category: window.HEADER_GA_CATEGORY ? window.HEADER_GA_CATEGORY : "quikr_" + pageRequestMap(PAGEREQUEST),
                        action: "Header",
                        label: "Myoffers"
                    })
                },
                popChatNotifications: function(t) {
                    if (!(parseInt(t, 10) != t || t <= 0)) {
                        var n = e.querySelectorAll('[data-type="chat_notif"]');
                        if (n.length > 0)
                            for (var a = 0; a < n.length; a++) n[a].innerHTML = t, n[a].style.display = "inline-block";
                        i.updateGlobalNotification(t, "chat_notif")
                    }
                },
                updateGlobalNotification: function(t, n) {
                    var i = e.querySelector('[data-type="d_all_notifs"]'),
                        a = e.querySelector('[data-type="m_all_notifs"]'),
                        o = a,
                        s = ["my_offers_notif", "chat_notif", "fav_count"];
                    if (i) {
                        if ("fav_count" == n) return;
                        s = ["my_offers_notif", "chat_notif"], o = i
                    }
                    s.forEach(function(i) {
                        if (i != n) {
                            var a = e.querySelector('[data-type="' + i + '"]');
                            if (a) {
                                var o = parseInt(a.innerHTML);
                                o > 0 && (t += o)
                            }
                        }
                    }), o.innerHTML = t, "none" == o.style.display && (o.style.display = "block");
                    var r = e.getElementById("loggedInMyAc");
                    r && (r.className = "active")
                },
                doLogin: function(t) {
                    var n = this.$loginLink,
                        i = e.getElementById("mobileLoginLink"),
                        a = !1;
                    if (n ? (n.removeEventListener("click", this.loginLink), n.id = "loggedInMyAc", n.setAttribute("data-togg", "dropdown"), n.setAttribute("data-area", "dashboardMenu"), n.addEventListener("click", this.toggleDropdown), a = !0, void 0 !== t && void 0 !== t.name && (n.innerHTML = '<span><i class="icon-my-account"></i> ' + t.name + ' <i class="icon-arrow"></i></span>'), this.$hamLoginLink && (this.$hamLoginLink.removeEventListener("click", this.loginLink), this.$hamLoginLink.id = "hamLogoutLink", this.$hamLoginLink.innerHTML = "Logout", this.$hamLoginLink.addEventListener("click", this.signOutLink))) : i && (i.id = "signOutLink", i.innerHTML = "Log Out", a = !0), a)
                        for (var o = e.querySelectorAll('[data-login="1"]'), s = 0; s < o.length; s++) o[s].style.display = "block"
                },
                toggleOverlay: function(t) {
                    var n = e.getElementsByClassName("simple-overlay")[0],
                        i = e.body;
                    t ? (i.style.overflow = "hidden", n.style.display = "block") : (i.style = "", n.style.display = "none")
                },
                updateCity: function(e) {
                    var t = this.$cityBtn.querySelector("span"),
                        n = document.getElementById("hamCitySelection");
                    t && (t.innerHTML = e), n ? n.querySelector("span").innerHTML = "You are In : " + e : this.$hamburger && (this.$hamburger.dataset.cname = e)
                },
                mspLinkClicked: function() {
                    PUB_SUB.emit("msp_link_clicked")
                },
                nxtIcnLinkClicked: function() {
                    PUB_SUB.emit("nxt_icn_clicked")
                },
                appDownloadLinkClicked: function() {
                    PUB_SUB.emit("app_download_clicked")
                },
                postAdBtnClicked: function() {
                    PUB_SUB.emit("post_ad_btn_clicked")
                },
                myAcClicked: function() {
                    PUB_SUB.emit("my_ac_clicked")
                },
                myAdsClicked: function() {
                    PUB_SUB.emit("my_ads_clicked")
                },
                myDoorstepClicked: function() {
                    PUB_SUB.emit("my_ds_offers_clicked")
                },
                myChatsClicked: function() {
                    PUB_SUB.emit("my_ac_chats_clicked")
                },
                myAlertsClicked: function() {
                    PUB_SUB.emit("my_alerts_clicked")
                },
                myOrdersClicked: function() {
                    PUB_SUB.emit("my_orders_clicked")
                },
                myProfileUpdateClicked: function() {
                    PUB_SUB.emit("my_prof_update_clicked")
                },
                myRecoClicked: function() {
                    PUB_SUB.emit("reco_for_me_clicked")
                },
                myLeadsLinkClicked: function() {
                    PUB_SUB.emit("my_leads_clicked")
                },
                cartIconClicked: function() {
                    PUB_SUB.emit("cart_icon_clicked")
                },
                desktopSlotsClicked: function() {
                    PUB_SUB.emit("desktop_slot_clicked", this.getAttribute("data-slot"))
                },
                geoLocationHandler: function(e) {
                    n.e(6).then(function(e) {
                        n(11)
                    }.bind(null, n)).catch(n.oe)
                },
                notificationHandler: function(e) {
                    n.e(2).then(function(e) {
                        n(12)
                    }.bind(null, n)).catch(n.oe)
                },
                checkHamburger: function(e) {
                    history && "#hamburgerMenu" === location.hash && this.hamburger.call(this.$hamburger)
                },
                closeHamburger: function() {
                    n.e(1).then(function(e) {
                        n(0).closeHamburder()
                    }.bind(null, n)).catch(n.oe)
                },
                checkHashChange: function(e) {
                    var t = e.newURL.indexOf("#hamburgerMenu") > -1,
                        n = e.oldURL.indexOf("#hamburgerMenu") > -1;
                    t && !n ? this.$hamburger.dispatchEvent(new Event("click")) : !t && n && this.closeHamburger()
                },
                recentSearchInit: function(e) {
                    n.e(4).then(function(e) {
                        n(8)
                    }.bind(null, n)).catch(n.oe)
                },
                autoSuggestInit: function(e) {
                    n.e(10).then(function(e) {
                        n(9)
                    }.bind(null, n)).catch(n.oe)
                },
                pageRequestMap: function(e) {
                    var t;
                    switch (e) {
                        case "REQUEST_VIEWAD":
                            t = "vap";
                            break;
                        case "REQUEST_SEARCHCAT":
                            t = "search";
                            break;
                        case "REQUEST_BROWSECAT":
                            t = "browse";
                            break;
                        case "REQUEST_INDEXPAGE":
                        case "REQUEST_CITYPAGE":
                            t = "homepage";
                            break;
                        default:
                            t = "other"
                    }
                    return t
                },
                stateSelection: function() {
                    n.e(0).then(function(e) {
                        n(1)
                    }.bind(null, n)).catch(n.oe)
                },
                stateSelect: function(e) {
                    n.e(0).then(function(t) {
                        n(1).selectState(e)
                    }.bind(null, n)).catch(n.oe)
                },
                quikrLogoClicked: function(e) {
                    PUB_SUB.emit("quikr_logo_clicked")
                }
            };
            i.init()
        }(document, JsLib)
    }
});