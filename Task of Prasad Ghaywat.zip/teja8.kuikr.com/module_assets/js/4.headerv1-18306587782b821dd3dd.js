wbJsonp([4], {
    8: function(e, t) {
        e.exports = function(e, t) {
            ({
                init: function() {
                    if (this.cacheDom(), this.bindEvents(), "undefined" != typeof jQuery) {
                        "undefined" == typeof PAGEREQUEST && (window.PAGEREQUEST = null), "undefined" == typeof CDN_URL && (CDN_URL = "https://teja8.kuikr.com");
                        var e = this;
                        this.eventDelegator("#searchautosuggestnew", "click", ".autoSuggestResult", function() {
                            e.delegateListener.call(this, e)
                        })
                    }
                },
                cacheDom: function() {
                    this.$searchInput = e.getElementById("query")
                },
                eventDelegator: function(e, t, r, n) {
                    var a = document.querySelector(e);
                    a && a.addEventListener(t, function(e) {
                        for (var t = a.querySelectorAll(r), i = e.target, c = 0, s = t.length; c < s; c++)
                            for (var o = i, l = t[c]; o && o !== a;) {
                                if (o === l) return n.call(l, e);
                                o = o.parentNode
                            }
                    })
                },
                bindEvents: function() {
                    this.$searchInput && (this.$searchInput.addEventListener("focus", this.showRecentSearches.bind(this)), this.$searchInput.addEventListener("keyup", this.keyPress.bind(this))), PUB_SUB.on("submit_search", this.saveSearches.bind(this))
                },
                renderRecentSearches: function() {
                    var r = this,
                        n = t.getCookie("recentSearches");
                    if (n = n ? n.split("_") : [], n.length) {
                        if (!jQuery("#recentContainer").children().length) {
                            jQuery("#recentContainer").append('<div class="seaech-heading"><span>Recent Searches</span><a id="clearRecent" href="#">Clear</a></div>');
                            for (var a = n.length - 1; a >= 0; a--) {
                                jQuery("<span />").addClass("autoSuggKeywords").html(n[a]).wrapAll('<a class="autoSuggestResult" tabindex="' + a + '" href="#" data-id="loader" ></a>').parent().append('<i class="icon-recent"></i>').appendTo(jQuery("#recentContainer"))
                            }
                            jQuery("#recentContainer .autoSuggKeywords").each(function() {
                                jQuery(this).wrapAll('<label class="recentSearchLabel"></lable>')
                            })
                        }
                        jQuery("html").bind("click.recentSearches", function(e) {
                            e.target == r.$searchInput || jQuery(e.target).parents("#recentSearch").length || jQuery(e.target).parents("#category-dropdown").length || (r.hideRecentSearches.call(r), r.hideRecentSearches.call(r))
                        }), this.$clearButton = e.getElementById("clearRecent"), this.$clearButton.addEventListener("click", this.clearRecent.bind(this)), this.bindSearchEvents(), getEventTrackGA({
                            category: window.HEADER_GA_CATEGORY ? window.HEADER_GA_CATEGORY : "quikr_" + pageRequestMap(PAGEREQUEST),
                            action: "Header",
                            label: "search_recent_view"
                        }), jQuery("#recentSearch").slideDown()
                    }
                },
                loadTrendingSearches: function(e) {
                    if (e && 0 !== e.length) {
                        jQuery("#trendingContainer").empty(), jQuery("#trendingContainer").append('<div class="seaech-heading"><span>Trending Searches</span></div>');
                        for (var t = 0; t < e.length; t++) {
                            jQuery("<span />").addClass("autoSuggKeywords").html(e[t]).wrapAll('<a class="autoSuggestResult" tabindex="' + t + '" href="#" data-id="loader" ></a>').parent().append('<i class="icon-trending"></i>').appendTo(jQuery("#trendingContainer"))
                        }
                        jQuery("#trendingContainer .autoSuggKeywords").each(function() {
                            jQuery(this).wrapAll('<label class="recentSearchLabel"></lable>')
                        }), getEventTrackGA({
                            category: window.HEADER_GA_CATEGORY ? window.HEADER_GA_CATEGORY : "quikr_" + pageRequestMap(PAGEREQUEST),
                            action: "Header",
                            label: "search_popular_view"
                        }), jQuery("#recentSearch").slideDown(), this.bindSearchEvents()
                    }
                },
                renderTrendingSearches: function() {
                    var e = this,
                        r = [],
                        n = t.getCookie("new_prefer_city"),
                        a = document.getElementById("category-dropdown").getAttribute("data-searchedCat");
                    if (n || (n = "www"), a && "0" != a || (a = 1), sessionStorage) {
                        if ((r = JSON.parse(sessionStorage.getItem("trendingSearches_" + n + "_" + a))) && r.length > 0) return void this.loadTrendingSearches(r);
                        r = []
                    }
                    ajax.post(SERVICE_HOST + SERVICE_END_POINT + "/fetch_trending_searches", {}).success(function(t) {
                        t.length && t.length > 0 && (t.forEach(function(e) {
                            if (1 == a || a == e.parentCatId) {
                                var t = "";
                                for (x in e.attr) t += e.attr[x] + " ";
                                t = t.trim(), r.push(t)
                            }
                        }), sessionStorage && sessionStorage.setItem("trendingSearches_" + n + "_" + a, JSON.stringify(r)), e.loadTrendingSearches(r))
                    }).error(function(e) {})
                },
                bindSearchEvents: function() {
                    var e = this;
                    jQuery("html").bind("click.recentSearches", function(t) {
                        t.target == e.$searchInput || jQuery(t.target).parents("#recentSearch").length || jQuery(t.target).parents("#category-dropdown").length || e.hideRecentSearches.call(e)
                    }), jQuery("#recentContainer .autoSuggestResult").each(function() {
                        this.addEventListener("click", function(t) {
                            t.preventDefault();
                            var r = jQuery(this).text();
                            getEventTrackGA({
                                category: window.HEADER_GA_CATEGORY ? window.HEADER_GA_CATEGORY : "quikr_" + pageRequestMap(PAGEREQUEST),
                                action: "Header",
                                label: "search_recent_click_" + r
                            }), e.makeSearch.call(this, e)
                        })
                    }), jQuery("#trendingContainer .autoSuggestResult").each(function() {
                        this.addEventListener("click", function(t) {
                            t.preventDefault();
                            var r = jQuery(this).text();
                            getEventTrackGA({
                                category: window.HEADER_GA_CATEGORY ? window.HEADER_GA_CATEGORY : "quikr_" + pageRequestMap(PAGEREQUEST),
                                action: "Header",
                                label: "search_popular_click_" + r
                            }), e.makeSearch.call(this, e)
                        })
                    })
                },
                showRecentSearches: function(e) {
                    void 0 !== e && "focus" === e.type && getEventTrackGA({
                        category: window.HEADER_GA_CATEGORY ? window.HEADER_GA_CATEGORY : "quikr_" + pageRequestMap(PAGEREQUEST),
                        action: "Header",
                        label: "search_button_click"
                    }), this.renderRecentSearches(), jQuery("#searchFormIndex") && jQuery("#searchFormIndex").data() && 1 == jQuery("#searchFormIndex").data().trending && this.renderTrendingSearches()
                },
                hideRecentSearches: function(e) {
                    jQuery("html").unbind("click.recentSearches"), jQuery("#recentSearch").slideUp()
                },
                keyPress: function(e) {
                    var t = 27 == e.which;
                    if (!e.target.value.trim().length && !t) return void this.showRecentSearches();
                    this.hideRecentSearches.call(this)
                },
                saveSearches: function(e) {
                    if (e.keyword) {
                        var r = e.keyword.replace(/[\`\~\!\@\#\$\%\^\&\*\(\)\_\+\=\{\}\[\]\|\\\:\;\"\'\<\,\>\.\?\/\s.]+/g, " ").trim(),
                            n = t.getCookie("recentSearches"),
                            a = r;
                        if (n) {
                            var i = n.split("_"),
                                c = i.indexOf(r);
                            c > -1 && i.splice(c, 1), i.length > 2 && i.shift(), i.length > 0 && (i = i.join("_"), a = i + "_" + r)
                        }
                        t.setCookie("recentSearches", a, ".quikr.com", "15"), $("#recentContainer").empty()
                    }
                },
                clearRecent: function(e) {
                    e.preventDefault(), this.hideRecentSearches.call(this), t.setCookie("recentSearches", "", ".quikr.com", "0"), $("#recentContainer").empty()
                },
                makeSearch: function(e) {
                    var r = jQuery(this).text();
                    e.saveSearches({
                        keyword: r
                    }), jQuery("#loader-overlay").append('<img src="' + CDN_URL + '/public/images/ajax-loader.gif" >'), jQuery("#loader-overlay img").css({
                        position: "absolute",
                        left: 0,
                        right: 0,
                        margin: "0 auto",
                        top: "110px"
                    }), jQuery("#loader-overlay").css("display", "block"), jQuery.ajax({
                        url: "/common?aj=1&for=exactKeywordLog&rand=" + (new Date).getTime(),
                        type: "POST",
                        data: {
                            ekeyword: r
                        },
                        dataType: "json",
                        success: function(e) {}
                    });
                    var n = jQuery("#surl").val(),
                        a = jQuery("#categoryId").val();
                    if ("en" != t.getCookie("lang")) var i = r.trim().replace(/[\`\~\!\@\#\$\%\^\&\*\(\)\_\+\=\{\}\[\]\|\\\:\;\"\'\<\,\>\.\?\/\s.]+/g, "-");
                    else var i = r.trim().replace(/[^a-z0-9]+/gi, "-");
                    n = n.replace(/qqurlqq/gi, i), n = n.replace(/qqurlcatid/gi, a), n = n.replace(/qqurlcat/gi, "all"), window.location = n
                },
                delegateListener: function(e) {
                    var t = jQuery(this).find(".autoSuggKeywords").text();
                    e.saveSearches({
                        keyword: t
                    })
                }
            }).init()
        }(document, JsLib)
    }
});