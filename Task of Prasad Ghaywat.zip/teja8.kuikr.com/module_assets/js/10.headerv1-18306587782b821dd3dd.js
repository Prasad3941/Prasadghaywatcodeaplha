wbJsonp([10], {
    9: function(e, t) {
        e.exports = function(e, t) {
            ({
                init: function() {
                    "undefined" != typeof jQuery && (window.loadSuggestionAds = this.loadSuggestionAds.bind(this))
                },
                loadSuggestionAds: function(e) {
                    this.selectState(e)
                },
                selectState: function(e) {
                    var a = this,
                        r = jQuery("#searchedCat").attr("cat-name"),
                        i = t.getCookie("new_prefer_city"),
                        n = 'targetingParams={"key": "target.adunit","value": "SearchResult"}';
                    n += '&targetingParams={"key": "target.keyword","value": "' + e + '"}', i && (n += '&targetingParams={"key": "target.city","value": "' + i + '"}'), r && (n += '&targetingParams={"key": "target.category","value": "' + r + '"}'), ajax.post(SERVICE_HOST + SERVICE_END_POINT + "/fetch_search_ads", n).success(function(e) {
                        e.isSuccessfull && a.renderAds(e.body.customCreative, e.body.setting.lpUrlAdBlock)
                    }).error(function(e) {})
                },
                renderAds: function(e, t, a) {
                    var r = jQuery("#searchAdSlot");
                    if (r.empty(), r.attr("href", t), "image" == e.templateType) {
                        var i = '<figure><img src="' + e.imageURL + '"/></figure>';
                        r.append(i)
                    } else {
                        var n = decodeURIComponent(e.title),
                            s = decodeURIComponent(e.description),
                            o = '<figure><img src="' + e.imageURL + '"/></figure>',
                            c = "<p><label>" + n + "</label><span>" + s + "</span></p>";
                        r.append(o + c)
                    }
                    jQuery(".search-ad-slot").show()
                }
            }).init()
        }(document, JsLib)
    }
});