wbJsonp([6], {
    11: function(t, e) {
        t.exports = function(t, e) {
            ({
                SERVICE_HOST: SERVICE_HOST,
                SERVICE_END_POINT: SERVICE_END_POINT,
                isAjaxActive: !1,
                init: function() {
                    sessionStorage && !sessionStorage.getItem("locationAccessRequested") && this.requestLocationAccess()
                },
                requestLocationAccess: function() {
                    var t = e.getCookie("new_prefer_city"),
                        i = void 0 == t || "www" == t;
                    navigator.geolocation && i && navigator.geolocation.getCurrentPosition(this.fetchLocality.bind(this))
                },
                fetchLocality: function(t) {
                    sessionStorage && sessionStorage.setItem("locationAccessRequested", !0);
                    var e = t.coords.latitude,
                        i = t.coords.longitude,
                        o = t.coords.distance || GEOLOCATION_DISTANCE,
                        c = t.coords.distanceType || GEOLOCATION_UNIT,
                        s = "longitude=" + i + "&latitude=" + e + "&distance=" + o + "&distanceType=" + c + "&resultCount=1&source=1";
                    this.isAjaxActive && this.isAjaxActive.abort();
                    var n = this;
                    ajax.post(SERVICE_HOST + SERVICE_END_POINT + "/fetch_locality", s).success(function(t) {
                        n.changeLocality(t), n.isAjaxActive = !1
                    }).error(function(t) {
                        n.isAjaxActive = !1
                    }), this.isAjaxActive = ajax.getRequest()
                },
                changeLocality: function(t) {
                    var i = e.getCookie("new_prefer_city");
                    t.cityName && "string" == typeof t.cityName && (e.setCookie("new_prefer_city", t.cityName.toLowerCase(), ".quikr.com", "1"), e.setCookie("prefer_city_id", t.cityId, ".quikr.com", "1"), e.setCookie("geolocation", JSON.stringify(t), ".quikr.com", "1"), i !== t.cityName.toLowerCase() && window.location.reload())
                }
            }).init()
        }(document, JsLib)
    }
});