wbJsonp([2], [, , , , , , , , , , , , function(e, t, n) {
    e.exports = function(e, t) {
        ({
            isAjaxActive: !1,
            withTimeout: 5,
            counter: 0,
            init: function() {
                var n = this,
                    i = t.getCookie("new_prefer_city");
                n.$alertDom = e.getElementById("headerAlertData"), "true" == (n.$alertDom.getAttribute("data-alertshow") ? n.$alertDom.getAttribute("data-alertshow") : "true") && ("All India" === i ? (n.counter = 0, n.checkGeoLocationStatus()) : n.initiateNotificationPopup())
            },
            checkGeoLocationStatus: function() {
                var e = this;
                void 0 !== navigator.permissions ? navigator.permissions.query({
                    name: "geolocation"
                }).then(function(t) {
                    "prompt" !== t.state ? e.initiateNotificationPopup() : e.counter <= 10 && (e.counter += 1, setTimeout(e.checkGeoLocationStatus, 2e3))
                }) : e.initiateNotificationPopup()
            },
            initiateNotificationPopup: function() {
                var e = this;
                e.withTimeout ? setTimeout(e.initiate, 1e3 * e.withTimeout) : e.initiate()
            },
            initiate: function() {
                var i = this;
                i.$alertDom = e.getElementById("headerAlertData");
                var o = i.$alertDom.getAttribute("data-alerttext") ? i.$alertDom.getAttribute("data-alerttext") : "Would you like to receive notifications and updates from Quikr? Please subscribe",
                    r = i.$alertDom.getAttribute("data-alertvertical") ? i.$alertDom.getAttribute("data-alertvertical") : "Horizontal",
                    a = i.$alertDom.getAttribute("data-alertcontext") ? i.$alertDom.getAttribute("data-alertcontext") : "homepage",
                    c = n(16).default,
                    s = n(23).default;
                c.prototype.showCustomPopup = s;
                const u = new c({
                    context: a,
                    vertical: r,
                    withTimeout: i.withTimeout
                });
                u.initialize().then(function(e) {
                    const n = t.getCookie("pushSub");
                    e ? n || t.setCookie("pushSub", "true", ".quikr.com", "1") : u.showCustomPopup({
                        classes: {
                            description: "notif-text"
                        },
                        description: o
                    }).then(function() {
                        n || t.setCookie("pushSub", "false", ".quikr.com", "1")
                    }).catch(function(e) {
                        console.error(e.message)
                    })
                })
            }
        }).init()
    }(document, JsLib)
}, function(e, t, n) {
    "use strict";

    function i(e) {
        return new Promise(function(t, n) {
            if (e) try {
                var i = e.transaction(["webpush"], "readwrite").objectStore("webpush"),
                    o = i.clear();
                o.onsuccess = function() {
                    t()
                }, o.onerror = function() {
                    n(new Error("Could not transact with IDB"))
                }
            } catch (e) {
                n(new Error("Could not transact with IDB"))
            } else n(new Error("IDB instance unavailable. Please initialize."))
        })
    }

    function o(e, t) {
        return new Promise(function(n, i) {
            if (e) try {
                var o = e.transaction(["webpush"], "readwrite").objectStore("webpush"),
                    r = o.get(t);
                r.onsuccess = function(e) {
                    n(e.currentTarget.result)
                }, r.onerror = function() {
                    i(new Error("Could not transact with IDB"))
                }
            } catch (e) {
                i(new Error("Could not transact with IDB"))
            } else i(new Error("IDB instance unavailable. Please initialize."))
        })
    }

    function r(e, t, n) {
        return new Promise(function(i, o) {
            if (e) try {
                var r = e.transaction(["webpush"], "readwrite").objectStore("webpush"),
                    a = r.put(Object.assign({
                        id: t
                    }, n));
                a.onsuccess = function() {
                    i()
                }, a.onerror = function() {
                    o(new Error("Could not transact with IDB"))
                }
            } catch (e) {
                o(new Error("Could not transact with IDB"))
            } else o(new Error("IDB instance unavailable. Please initialize."))
        })
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.clearIDB = i, t.readFromIDB = o, t.writeToIDB = r
}, function(e, t, n) {
    "use strict";

    function i(e) {
        for (var t = "=".repeat((4 - e.length % 4) % 4), n = (e + t).replace(/\-/g, "+").replace(/_/g, "/"), i = window.atob(n), o = new Uint8Array(i.length), r = 0; r < i.length; r += 1) o[r] = i.charCodeAt(r);
        return o
    }

    function o() {
        var e = new Date;
        return "".concat(e.getFullYear() + "", "-").concat(e.getMonth() + 1, "-").concat(e.getDate(), " ").concat(e.toLocaleTimeString())
    }

    function r() {
        var e, t = navigator.userAgent,
            n = t.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
        return /trident/i.test(n[1]) ? (e = /\brv[ :]+(\d+)/g.exec(t) || [], "IE-".concat(e[1] || "")) : "Chrome" === n[1] && null !== (e = t.match(/\b(OPR|Edge)\/(\d+)/)) ? e.slice(1).join(" ").replace("OPR", "Opera") : (n = n[2] ? [n[1], n[2]] : [navigator.appName, navigator.appVersion, "-?"], e = t.match(/version\/(\d+)/i), null !== e && n.splice(1, 1, e[1]), {
            name: n[0],
            version: n[1]
        })
    }

    function a(e) {
        if ("undefined" != typeof document) {
            var t = document.cookie.match(new RegExp("(^| )".concat(e, "=([^;]+)")));
            if (t) return t[2]
        }
        return !1
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.urlBase64ToUint8Array = i, t.getCurrentDateTime = o, t.getBrowserDetails = r, t.getCookie = a
}, function(e, t, n) {
    "use strict";

    function i(e) {
        return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function o(e) {
        var t = new URLSearchParams;
        return "object" === i(e) && Object.keys(e).forEach(function(n) {
            return t.append(n, e[n])
        }), t
    }

    function r(e) {
        var t = "/core/quikrcom/pwa_api" + e.url,
            n = {
                method: e.method || "GET"
            };
        return e.body && (n.body = e.body), fetch(t, n)
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.formURLSearchObject = o, t.fetcher = r
}, function(e, t, n) {
    "use strict";

    function i(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o() {
        var e = this,
            t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
        if (this.subscribeConfig = {
                userVisibleOnly: !0
            }, !t.vertical || !t.context) throw new Error("Vertical and Context are mandatory!");
        if (this.vertical = t.vertical, this.context = t.context, this.threshold = 1, t.threshold && (this.threshold = t.threshold), t.vapidKey && (this.subscribeConfig.applicationServerKey = (0, d.urlBase64ToUint8Array)(t.vapidKey)), t.useThisServiceWorker) {
            if ("ServiceWorkerRegistration" !== Object.getPrototypeOf(t.useThisServiceWorker).constructor.name) throw new Error("Invalid service worker registration");
            this.swRegistration = t.useThisServiceWorker
        }
        t.pwa && (this.pwa = !0), window.ga = window.ga || function() {
            for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
            return (ga.q = ga.q || []).push(t)
        }, ga("create", t.gaTrackingId || (this.pwa ? "UA-5568615-7" : "UA-5568615-1"), "auto", "wpn"), ga("wpn.set", "transport", "beacon"), this.pushToGA = function(n, i, o) {
            "allow" == i || "block" == i || "impression" == i || ga("wpn.send", "event", {
                eventCategory: "wpn_".concat(0 < t.withTimeout ? "".concat(t.withTimeout, "sec") : "onload"),
                eventAction: "wpn_".concat(e.vertical, "_").concat(e.context, "_").concat(n),
                eventLabel: "wpn_".concat(i),
                nonInteraction: !o
            })
        }, this.isSupported = function() {
            return "undefined" != typeof navigator && "serviceWorker" in navigator && "undefined" != typeof PushManager && "undefined" != typeof Notification && "undefined" != typeof indexedDB
        }
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = void 0;
    var r = i(n(17)),
        a = i(n(18)),
        c = n(19),
        s = i(n(20)),
        u = i(n(21)),
        l = i(n(22)),
        d = n(14);
    o.prototype.canTriggerCustomDialog = c.canTriggerCustomDialog, o.prototype.getIgnoredTimestamp = c.getIgnoredTimestamp, o.prototype.getPushSubscription = r.default, o.prototype.initialize = a.default, o.prototype.requestPermission = s.default, o.prototype.saveSubscription = u.default, o.prototype.setIgnoredTimestamp = c.setIgnoredTimestamp, o.prototype.updateSubscription = l.default;
    var p = o;
    t.default = p
}, function(e, t, n) {
    "use strict";

    function i() {
        var e = this;
        return new Promise(function(t, n) {
            e.swRegistration ? e.swRegistration.pushManager.getSubscription().then(function(n) {
                e.pushSubscription = n, t(n)
            }) : n(new Error("Service Worker registration unavailable. Please initialize."))
        })
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = i
}, function(e, t, n) {
    "use strict";

    function i() {
        var e = this;
        return new Promise(function(t, n) {
            if (e.isSupported()) {
                e.initialized = !0, e.getPermissionStatus = function() {
                    return Notification.permission
                };
                var i = window.indexedDB.open("q_wpn");
                i.onerror = function() {
                    n(new Error("Could not open IndexedDB"))
                }, i.onupgradeneeded = function(t) {
                    e.idb = t.target.result, e.idb.createObjectStore("webpush", {
                        keyPath: "id"
                    })
                }, i.onsuccess = function(i) {
                    e.idb = i.target.result;
                    var r = function() {
                        return e.getPushSubscription().then(function(i) {
                            i ? (0, o.readFromIDB)(e.idb, "subscription").then(function(o) {
                                o && o.endpoint === i.endpoint ? t(i) : i.unsubscribe().then(function() {
                                    e.requestPermission().then(t).catch(n)
                                }).catch(n)
                            }).catch(n) : "granted" === e.getPermissionStatus() ? e.requestPermission().then(t).catch(n) : t(i)
                        }).catch(n)
                    };
                    e.swRegistration ? r() : navigator.serviceWorker.ready.then(function() {
                        navigator.serviceWorker.getRegistration().then(function(t) {
                            e.swRegistration = t, r()
                        })
                    })
                }
            } else n(new Error("Push notifications are not supported on this browser"))
        })
    }
    var o = n(13);
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = i
}, function(e, t, n) {
    "use strict";

    function i() {
        var e = this;
        return new Promise(function(t, n) {
            e.initialized ? (0, a.readFromIDB)(e.idb, "ignoredTimestamp").then(function(e) {
                return t(e && e.timestamp)
            }).catch(n) : n(new Error("IDB Instance unavailable. Please initialize."))
        })
    }

    function o() {
        var e = this;
        return new Promise(function(t, n) {
            e.initialized ? (0, a.writeToIDB)(e.idb, "ignoredTimestamp", {
                timestamp: Date.now()
            }).then(t).catch(n) : n(new Error("IDB Instance unavailable. Please initialize."))
        })
    }

    function r() {
        var e = this;
        return new Promise(function(t, n) {
            e.initialized ? e.pushSubscription ? n(new Error("User is already subscribed!")) : e.getIgnoredTimestamp().then(function(i) {
                !i || (Date.now() - i) / 864e5 > e.threshold ? t() : n(new Error("Last ignored timestamp is below the threshold"))
            }).catch(n) : new Error("IDB Instance unavailable. Please initialize.")
        })
    }
    var a = n(13);
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.getIgnoredTimestamp = i, t.setIgnoredTimestamp = o, t.canTriggerCustomDialog = r
}, function(e, t, n) {
    "use strict";

    function i() {
        var e = this;
        return new Promise(function(t, n) {
            e.idb && e.swRegistration && !e.pushSubscription && "undefined" != typeof window ? (e.pushToGA("native", "impression", !1), e.swRegistration.pushManager.subscribe(e.subscribeConfig).then(function(i) {
                e.pushToGA("native", "allow"), e.pushSubscription = i;
                var r;
                (0, o.readFromIDB)(e.idb, "subscription").then(function(t) {
                    return r = t, (0, o.writeToIDB)(e.idb, "subscription", i.toJSON())
                }).then(function() {
                    return r && r.endpoint !== i.endpoint ? e.updateSubscription(i) : e.saveSubscription(i)
                }).then(function() {
                    return t(i)
                }).catch(n)
            }).catch(function(t) {
                e.pushToGA("native", "block"), n(t)
            })) : n(new Error("Service Worker registration unavailable. Please initialize."))
        })
    }
    var o = n(13);
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = i
}, function(e, t, n) {
    "use strict";

    function i(e) {
        var t = this;
        return new Promise(function(n, i) {
            var c = (0, o.getBrowserDetails)(),
                s = {
                    endpointjson: JSON.stringify(e.toJSON()),
                    create_time: (0, o.getCurrentDateTime)(),
                    br_name: c.name,
                    br_version: c.version,
                    browser_url: window.location.href,
                    reg_id: e.endpoint.split("/").slice(-1)
                };
            (0, r.fetcher)({
                url: "/save-browser-reg-info",
                method: "POST",
                body: (0, r.formURLSearchObject)(s)
            }).then(function(e) {
                e.ok ? n() : (t.pushSubscription.unsubscribe(), (0, a.clearIDB)(t.idb), i(new Error("Subscription save API failure!")))
            })
        })
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = i;
    var o = n(14),
        r = n(15),
        a = n(13)
}, function(e, t, n) {
    "use strict";

    function i(e) {
        var t = this;
        return new Promise(function(n, i) {
            var c = {
                endpointjson: JSON.stringify(e.toJSON()),
                updatetime: (0, o.getCurrentDateTime)(),
                reg_id: e.endpoint.split("/").slice(-1)
            };
            (0, r.fetcher)({
                url: "/browser-unique-id-update",
                method: "POST",
                body: (0, r.formURLSearchObject)(c)
            }).then(function(e) {
                e.ok ? n() : (t.pushSubscription.unsubscribe(), (0, a.clearIDB)(t.idb), i(new Error("Subscription update API failure!")))
            })
        })
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = i;
    var o = n(14),
        r = n(15),
        a = n(13)
}, function(e, t, n) {
    "use strict";

    function i(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o() {
        var e = this,
            t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
        return new Promise(function(n, i) {
            "undefined" != typeof document && e.initialized && "default" === e.getPermissionStatus() ? e.canTriggerCustomDialog().then(function() {
                if (!s.alreadyTriggered) {
                    (0, r.appendModalStyles)(a.default);
                    var o = document.createElement("div");
                    document.body.append(o), s.alreadyTriggered = !0, s.container = o
                }
                if (!s.isOpen) {
                    var u = t.classes,
                        l = void 0 === u ? {} : u,
                        d = s.container;
                    d.className = "wpn_modal_container ".concat(l.container || "");
                    var p = function() {
                            d.className = "", d.innerHTML = "", s.isOpen = !1, document.body.style.overflow = ""
                        },
                        f = function(n) {
                            e.pushToGA("custom", "block"), e.setIgnoredTimestamp(), t.onIgnore && "function" == typeof t.onIgnore && t.onIgnore(n), i(new Error("User denied the permission")), p()
                        },
                        m = document.createElement("div");
                    m.className = "wpn_modal_backdrop", m.role = "presentation", m.addEventListener("click", function(e) {
                        return f(e)
                    });
                    var h = document.createElement("div");
                    h.className = "wpn_modal_modal", h.innerHTML = '<div class="wpn_modal_content"><div>'.concat(c.default, '</div><div class="wpn_modal_description ').concat(l.description || "", '">').concat(t.description || "Would you like to allow Quikr to send notifications? Please subscribe", "</div></div>");
                    var w = document.createElement("div");
                    w.className = "wpn_modal_actionButtonsContainer";
                    var g = (0, r.createActionButton)("NOT NOW");
                    g.addEventListener("click", function(e) {
                        return f(e)
                    }), w.appendChild(g);
                    var b = (0, r.createActionButton)("ALLOW");
                    b.addEventListener("click", function(o) {
                        e.pushToGA("custom", "allow"), t.onAllow && "function" == typeof t.onAllow && t.onAllow(o), e.requestPermission().then(n).catch(i), p()
                    }), w.appendChild(b), h.appendChild(w), d.appendChild(m), d.appendChild(h), s.isOpen = !0, document.body.style.overflow = "hidden", e.pushToGA("custom", "impression", !1), setTimeout(function() {
                        d.className += "wpn_modal_show"
                    }, 100)
                }
            }).catch(i) : i(new Error("Failed to show custom popup"))
        })
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = o;
    var r = n(24),
        a = i(n(25)),
        c = i(n(26)),
        s = {}
}, function(e, t, n) {
    "use strict";

    function i(e) {
        var t = document.createElement("style");
        t.type = "text/css", t.innerHTML = e, document.head.appendChild(t)
    }

    function o(e) {
        var t = !1,
            n = document.createElement("button");
        n.className = "wpn_modal_actionButton";
        var i = function(e) {
            var i = document.createElement("span");
            i.className = "wpn_ripple_effect", n.appendChild(i);
            var o = n.getBoundingClientRect();
            if (o.x = o.x || o.left, o.y = o.y || o.top, t) {
                var r = e.touches[0];
                i.style.left = "".concat(r.clientX - o.x, "px"), i.style.top = "".concat(r.clientY - o.y, "px")
            } else i.style.left = "".concat(e.x - o.x, "px"), i.style.top = "".concat(e.y - o.y, "px");
            i.addEventListener("animationend", function() {
                this.parentElement.removeChild(this)
            })
        };
        "ontouchstart" in document.documentElement ? (t = !0, n.addEventListener("touchstart", i, {
            passive: !0
        })) : n.addEventListener("mousedown", i);
        var o = document.createElement("span");
        return o.innerHTML = e, n.appendChild(o), n
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.appendModalStyles = i, t.createActionButton = o
}, function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = void 0;
    t.default = ".wpn_modal_backdrop,.wpn_modal_container{bottom:0;height:100%;left:0;position:fixed;right:0;top:0;width:100%}.wpn_modal_container{align-items:center;display:flex;justify-content:center;z-index:9999}.wpn_modal_backdrop{background:rgba(0,0,0,.6);opacity:0;transition:opacity .3s ease;z-index:-1}.wpn_modal_container.wpn_modal_show .wpn_modal_backdrop{opacity:1}.wpn_modal_modal{background:#fff;border-radius:2px;box-shadow:0 11px 15px -7px rgba(0,0,0,.2),0 24px 38px 3px rgba(0,0,0,.14),0 9px 46px 8px rgba(0,0,0,.12);margin:20px;opacity:0;transition:opacity .2s ease;max-width:500px}.wpn_modal_container.wpn_modal_show .wpn_modal_modal{opacity:1}.wpn_modal_title{font-size:1.25em;font-weight:500;margin:0;padding:24px 20px 0}.wpn_modal_content{align-items:center;display:flex;padding:20px 24px}.wpn_modal_description{line-height:1.25em;margin-left:16px}.wpn_modal_actionButtonsContainer{align-items:center;display:flex;justify-content:flex-end;padding:0 8px 8px}.wpn_modal_actionButton{background:0 0;border:none;border-radius:2px;color:#0083ca;cursor:pointer;font-size:1em;font-weight:500;margin:0;min-height:40px;min-width:80px;overflow:hidden;padding:8px 16px;position:relative;text-overflow:ellipsis;transition:background .3s ease-in;user-select:none;vertical-align:middle;white-space:nowrap;-webkit-user-select:none}.wpn_modal_actionButton:hover{background:rgba(0,131,202,.2)}@media (hover:none){.wpn_modal_actionButton:hover{background:0 0}}.wpn_modal_actionButton:focus{outline:0}.wpn_modal_actionButton:-moz-focus-inner{border:0}.wpn_modal_actionButton span{pointer-events:none}@keyframes wpnRippleEffect{0%{transform:translate(-50%,-50%) scale(0);opacity:.3}100%{transform:translate(-50%,-50%) scale(2.5);opacity:0}}@-webkit-keyframes wpnRippleEffect{0%{-webkit-transform:translate(-50%,-50%) scale(0);opacity:.3}100%{-webkit-transform:translate(-50%,-50%) scale(2.5);opacity:0}}.wpn_ripple_effect{animation-duration:1s;animation-name:wpnRippleEffect;background:currentColor;border-radius:50%;height:200px;position:absolute;width:200px;z-index:0;-webkit-animation-duration:1s;-webkit-animation-name:wpnRippleEffect}.wpn_modal_icon{font-size:56px;height:1em;vertical-align:middle;width:1em}"
}, function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = void 0;
    t.default = '<svg xmlns="http://www.w3.org/2000/svg" class="wpn_modal_icon" viewBox="0 0 72 72"><path fill="#AAD5E9" d="M36.7,59l-10.5-3.7c-3.2-1.1-4.9-4.6-3.8-7.8c0.2-0.5,0.4-1,0.8-1.5H8.9c-1.1,0-2-0.9-2-2s0.9-2,2-2h21c2.3-1.4,4.1-3.6,5-6.2l0-0.1H8.9c-1.1,0-2-0.9-2-2s0.9-2,2-2h27.4l0.7-2c0.9-2.7,2.5-5,4.4-6.8h-33c-3.9,0-7.1,3.2-7.1,7.1v25c0,3.9,3.2,7.1,7.1,7.1h27.9L36.7,59z M11,57.8c-1.4-3.9-4.8-3-4.8-3c3.3-1,1.8-5.6,1.8-5.6c1.6,4.3,4.8,3.3,4.8,3.3C9.7,53.5,11,57.8,11,57.8z M40.4,38.1c0,0,2.9-15.7,14.1-15.2c0,0-9.1,4.5-10.3,16.5L40.4,38.1z"/><path fill="#231F20" d="M69.1,57.1c-1.8-2.9-2.1-6.5-1-9.7l2.2-6.2c2.5-7.1,0.1-14.7-5.2-19.3c0.8-1,1.3-2.4,1.3-3.8c0-3.4-2.7-6.1-6.1-6.1c-3.2,0-5.8,2.5-6.1,5.6c-2.9-0.1-5.8,0.5-8.4,1.8c-4.3,2.1-7.5,5.7-9,10.2l-2.1,6.1c-1.1,3.3-3.7,5.9-7,7.1L26,43.1c-1.9,0.7-3.4,2.2-4.1,4.1c-1.2,3.5,0.6,7.3,4.1,8.5l10.1,3.5c-0.2,0.7-0.3,1.4-0.3,2.2c0,4.7,3.8,8.5,8.4,8.5c3.5,0,6.5-2.1,7.8-5.1l9.9,3.4c0.7,0.3,1.5,0.4,2.2,0.4c2.8,0,5.4-1.7,6.3-4.5c0.6-1.9,0.4-4-0.6-5.7L69.1,57.1z M60.2,12.9c2.8,0,5.1,2.3,5.1,5.1c0,1.2-0.4,2.3-1.1,3.2c-1.5-1.1-3.1-2-4.9-2.7c-1.4-0.5-2.7-0.8-4.1-0.9C55.3,14.9,57.5,12.9,60.2,12.9z M44.3,68.9c-4.1,0-7.4-3.3-7.4-7.5c0-0.6,0.1-1.3,0.2-1.9l14,4.9C49.9,67.1,47.3,68.9,44.3,68.9z M36.5,58.3l-10.1-3.5c-2.9-1-4.5-4.3-3.5-7.2c0.6-1.6,1.8-2.9,3.5-3.5l1.5-0.5c3.6-1.3,6.3-4.1,7.6-7.7l2.1-6.1c1.5-4.2,4.5-7.7,8.5-9.6c2.3-1.1,4.8-1.7,7.3-1.7l1.7,0.1c1.3,0.1,2.5,0.4,3.8,0.8c1.7,0.6,3.2,1.4,4.6,2.5l0.8,0.7c5.1,4.4,7.3,11.6,5,18.3L67.1,47c-1.2,3.5-0.8,7.4,1.1,10.6l0.8,1.3c0.9,1.5,1.1,3.2,0.5,4.9c-1,3-4.3,4.5-7.2,3.5l-9.9-3.4"/><path fill="#BDDFB8" d="M22.5,2.6c0,0,2.7,8.2-3.1,10.1c0,0,6.1-1.6,8.6,5.3c0,0-2.3-7.7,3.2-9.6C31.1,8.4,25.3,10.3,22.5,2.6z M59.1,46.1c0,0-2.8,5.7-6.8,3.6c0,0,4,2.3,1.7,7.2c0,0,2.8-5.2,6.6-3.3C60.5,53.6,56.6,51.6,59.1,46.1z"/></svg>'
}]);