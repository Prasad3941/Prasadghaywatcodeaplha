jsonp([0], [, , function(e, n, t) {
    "use strict";

    function r(e, n, t) {
        return n in e ? Object.defineProperty(e, n, {
            value: t,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = t, e
    }
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.trackError = n.init = void 0;
    var i, o = Object.assign || function(e) {
            for (var n = 1; n < arguments.length; n++) {
                var t = arguments[n];
                for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
            }
            return e
        },
        a = t(4),
        c = t(5),
        u = t(6),
        d = t(7),
        s = function(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }(d),
        f = s.default.version,
        v = {
            VERSION: "dimension6",
            CLIENT_ID: "dimension2",
            WINDOW_ID: "dimension7",
            JKID: "dimension8",
            HIT_ID: "dimension9",
            HIT_TIME: "dimension10",
            HIT_TYPE: "dimension11",
            HIT_SOURCE: "dimension12",
            CAT: "dimension16",
            SCAT: "dimension4",
            PTYPE: "dimension13",
            CITY: "dimension14",
            LCAL: "dimension15"
        },
        m = {
            FID: "metric1",
            RESPONSE_END_TIME: "metric2",
            DOM_LOAD_TIME: "metric3",
            WINDOW_LOAD_TIME: "metric4",
            VISIBILITY_STATE: "metric5",
            FP: "metric6",
            FCP: "metric7",
            ETYPE: "metric8",
            RTT: "metric9",
            DOWNL: "metric10",
            SDATA: "metric11",
            SUQ: "metric12"
        },
        p = (i = {}, r(i, v.CAT, "NA"), r(i, v.SCAT, "NA"), r(i, v.PTYPE, "NA"), r(i, v.CITY, "NA"), r(i, v.LCAL, "NA"), i),
        l = {
            visible: 0,
            hidden: 1,
            prerender: 2
        },
        g = p,
        w = (n.init = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                n = {};
            Object.keys(e).map(function(t) {
                n[v[t] || m[t]] = e[t]
            }), g = Object.assign({}, p, n), window.ga = window.ga || function() {
                for (var e = arguments.length, n = Array(e), t = 0; t < e; t++) n[t] = arguments[t];
                return (ga.q = ga.q || []).push(n)
            }, w(), T(), E(), _(), h(), k(), b()
        }, function() {
            ga("create", "UA-5568615-7", "auto", "quikrRUMTracker"), ga("quikrRUMTracker.set", "transport", "beacon")
        }),
        T = (n.trackError = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            ga("quikrRUMTracker.send", "event", Object.assign({
                eventCategory: "Error",
                eventAction: e.name || "(no error name)",
                eventLabel: e.message + "\n" + (e.stack || "(no stack trace)"),
                nonInteraction: !0
            }, n))
        }, function() {}),
        E = function() {
            ga(function() {
                var e = ga.getByName("quikrRUMTracker");
                if (e) {
                    var n;
                    Object.keys(v).forEach(function(n) {
                        e.set(v[n], "(not set)")
                    }), e.set((n = {}, r(n, v.VERSION, f), r(n, v.CLIENT_ID, e.get("clientId")), r(n, v.WINDOW_ID, I()), n));
                    var t = e.get("buildHitTask");
                    e.set("buildHitTask", function(e) {
                        var n = e.get("queueTime") || 0;
                        e.set(v.HIT_TIME, String(new Date - n), !0), e.set(v.HIT_ID, I(), !0), e.set(v.HIT_TYPE, e.get("hitType"), !0), e.set(m.VISIBILITY_STATE, l[document.visibilityState], !0), t(e)
                    })
                }
            })
        },
        _ = function e() {
            if (window.performance && window.performance.timing) {
                if ("complete" != document.readyState) return void window.addEventListener("load", e);
                var n = performance.timing,
                    t = n.navigationStart,
                    i = Math.round(n.responseEnd - t),
                    o = Math.round(n.domContentLoadedEventStart - t),
                    a = Math.round(n.loadEventStart - t);
                if (function() {
                        for (var e = arguments.length, n = Array(e), t = 0; t < e; t++) n[t] = arguments[t];
                        return n.every(function(e) {
                            return e > 0 && e < 6e6
                        })
                    }(i, o, a)) {
                    var c;
                    ga("quikrRUMTracker.send", "event", (c = {
                        eventCategory: "Navigation Timing",
                        eventAction: "track",
                        eventLabel: "(not set)",
                        nonInteraction: !0
                    }, r(c, m.RESPONSE_END_TIME, i), r(c, m.DOM_LOAD_TIME, o), r(c, m.WINDOW_LOAD_TIME, a), c))
                }
            }
        },
        I = function e(n) {
            return n ? (n ^ 16 * Math.random() >> n / 4).toString(16) : ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, e)
        },
        h = function() {
            if (void 0 !== window.qperf && Array.isArray(window.qperf)) {
                var e = {
                    eventCategory: "Before Unload",
                    eventAction: "collect existing events",
                    eventLabel: "(not set)",
                    nonInteraction: !0
                };
                window.qperf.forEach(function(n) {
                    Object.keys(n).forEach(function(t) {
                        var r = v[t] || m[t];
                        r && (e[r] = n[t])
                    })
                }), ga("quikrRUMTracker.send", "event", o({}, g, e)), window.qperf = []
            }
        },
        k = function() {
            window.addEventListener("beforeunload", function() {
                h(), window.removeEventListener("load", _)
            }, !1)
        },
        b = function() {
            (0, a.onConnCaptured)(function(e, n, t, r, i) {
                window.qperf = window.qperf || [], window.qperf.push({
                    ETYPE: e,
                    RTT: n,
                    DOWNL: t,
                    SDATA: r
                })
            }), (0, c.onPaintCaptured)(function(e, n, t) {
                window.qperf = window.qperf || [], window.qperf.push({
                    FP: e,
                    FCP: n
                })
            }), (0, u.onStorageQuota)(function(e) {
                window.qperf = window.qperf || [], window.qperf.push({
                    SUQ: e
                })
            })
        }
}, function(e, n, t) {
    "use strict";
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    n.d = document, n.w = window, n.p = performance
}, function(e, n, t) {
    "use strict";

    function r() {
        void 0 !== a && (v.forEach(function(e) {
            e(p[a], c, u, d ? 1 : 0, s)
        }), v = [])
    }

    function i() {
        return "navigator" in f.w && "connection" in navigator
    }

    function o() {
        i() && (s = navigator.connection, a = s.effectiveType, c = s.rtt, u = s.downlink, d = s.saveData), m && f.w.removeEventListener("load", o), r()
    }
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.onConnCaptured = void 0;
    var a, c, u, d, s, f = t(3),
        v = [],
        m = !1,
        p = {
            "slow-2g": 1,
            "2g": 2,
            "3g": 3,
            "4g": 4
        };
    n.onConnCaptured = function(e) {
        v.push(e), r()
    };
    void 0 !== f.d.readyState && "complete" === f.d.readyState ? o() : (m = !0, f.w.addEventListener("load", o))
}, function(e, n, t) {
    "use strict";

    function r(e) {
        u.push(e), a()
    }

    function i() {
        o() && (s = c.p.getEntriesByType("paint"), f = s[0].startTime, v = s[0].startTime), d && c.w.removeEventListener("load", i), a()
    }

    function o() {
        return "performance" in c.w && "PerformancePaintTiming" in c.w && c.p.getEntriesByType("paint").length > 0
    }

    function a() {
        s.length > 0 && (u.forEach(function(e) {
            e(f, v, s)
        }), u = [])
    }
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.onPaintCaptured = r;
    var c = t(3),
        u = [],
        d = !1,
        s = [],
        f = 0,
        v = 0;
    void 0 !== c.d.readyState && "complete" === c.d.readyState ? i() : (d = !0, c.w.addEventListener("load", i))
}, function(e, n, t) {
    "use strict";

    function r(e) {
        a.push(e)
    }

    function i() {
        a.forEach(function(e) {
            e(c)
        }), a = []
    }

    function o() {
        return "storage" in navigator && "estimate" in navigator.storage
    }
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.onStorageQuota = r;
    var a = [],
        c = 0;
    ! function() {
        o() ? navigator.storage.estimate().then(function(e) {
            var n = e.quota,
                t = e.usage;
            c = Math.floor(t / n * 100), i()
        }) : (c = "NA", i())
    }()
}, function(e, n) {
    e.exports = {
        _from: "quikr-rum@1.1.10",
        _id: "quikr-rum@1.1.10",
        _inBundle: !1,
        _integrity: "sha512-B69Y4D4wK0hAm2+N3iQxWiGhCtvchHMMoCsKC1uUNfd3CsvvyKHDbwXjaVDuSz0CN+ADAvdBD2jTfzPcFldFEw==",
        _location: "/quikr-rum",
        _phantomChildren: {},
        _requested: {
            type: "version",
            registry: !0,
            raw: "quikr-rum@1.1.10",
            name: "quikr-rum",
            escapedName: "quikr-rum",
            rawSpec: "1.1.10",
            saveSpec: null,
            fetchSpec: "1.1.10"
        },
        _requiredBy: ["/"],
        _resolved: "http://192.168.124.71:4873/quikr-rum/-/quikr-rum-1.1.10.tgz",
        _shasum: "3b2b195edb194621668687472a7b528797e23574",
        _spec: "quikr-rum@1.1.10",
        _where: "/var/lib/jenkins/workspace/Prod_adaptor",
        author: {
            name: "Samar Panda",
            email: "er.samar.panda@quikr.com"
        },
        bundleDependencies: !1,
        deprecated: !1,
        description: "Quikr real user monitoring",
        devDependencies: {
            "babel-eslint": "^10.0.1",
            "compression-webpack-plugin": "^2.0.0",
            eslint: "^5.13.0",
            lerna: "^3.8.0",
            webpack: "^4.29.5",
            "webpack-cli": "^3.2.3",
            "webpack-merge": "^4.2.1"
        },
        license: "MIT",
        main: "src/index.js",
        name: "quikr-rum",
        version: "1.1.10"
    }
}]);