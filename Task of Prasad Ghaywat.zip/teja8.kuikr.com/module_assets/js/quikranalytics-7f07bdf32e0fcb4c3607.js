! function(t) {
    function e(r) {
        if (n[r]) return n[r].exports;
        var a = n[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return t[r].call(a.exports, a, a.exports, e), a.l = !0, a.exports
    }
    var n = {};
    e.m = t, e.c = n, e.d = function(t, n, r) {
        e.o(t, n) || Object.defineProperty(t, n, {
            configurable: !1,
            enumerable: !0,
            get: r
        })
    }, e.n = function(t) {
        var n = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return e.d(n, "a", n), n
    }, e.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, e.p = "https://teja8.kuikr.com/module_assets/js/", e(e.s = 0)
}([function(t, e, n) {
    t.exports = n(1)
}, function(t, e, n) {
    "use strict";
    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    };
    ! function() {
        function t() {
            for (var t = f, e = {}, n = 0; n < t.length; ++n) e[t[n]] = n;
            return e
        }

        function e() {
            var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            return (t += t.toLowerCase() + "0123456789-_") + "."
        }

        function n(n) {
            f = f || e(), g = g || t();
            for (var r = [], a = 0; a < n.length; a += 3) {
                var o = a + 1 < n.length,
                    i = a + 2 < n.length,
                    s = n.charCodeAt(a),
                    c = o ? n.charCodeAt(a + 1) : 0,
                    u = i ? n.charCodeAt(a + 2) : 0,
                    l = s >> 2;
                s = (3 & s) << 4 | c >> 4, c = (15 & c) << 2 | u >> 6, u &= 63, i || (u = 64, o || (c = 64)), r.push(f[l], f[s], f[c], f[u])
            }
            return r.join("")
        }

        function r(n) {
            function r(t) {
                for (; o < n.length;) {
                    var e = n.charAt(o++),
                        r = g[e];
                    if (null != r) return r;
                    if (!/^[\s\xa0]*$/.test(e)) throw Error("Unknown base64 encoding at char: " + e)
                }
                return t
            }
            f = f || e(), g = g || t();
            for (var a = "", o = 0;;) {
                var i = r(-1),
                    s = r(0),
                    c = r(64),
                    u = r(64);
                if (64 === u && -1 === i) return a;
                a += String.fromCharCode(i << 2 | s >> 4), 64 != c && (a += String.fromCharCode(s << 4 & 240 | c >> 2), 64 != u && (a += String.fromCharCode(c << 6 & 192 | u)))
            }
        }

        function a(t) {
            return new RegExp("(.*?)(^|&)" + t + "=([^&]*)&?(.*)")
        }

        function o(t, e) {
            if (t = a(t).exec(e)) {
                var n = t[2],
                    r = t[4];
                e = t[1], r && (e = e + n + r)
            }
            return e
        }

        function i(t, e, n, r) {
            function a(e) {
                e = o(t, e);
                var n = e.charAt(e.length - 1);
                return e && "&" !== n && (e += "&"), e + c
            }
            r = void 0 !== r && r;
            var i = I.exec(n);
            if (!i) return "";
            n = i[1];
            var s = i[2] || "";
            i = i[3] || "";
            var c = t + "=" + e;
            return r ? i = "#" + a(i.substring(1)) : s = "?" + a(s.substring(1)), "" + n + s + i
        }

        function s(t, e) {
            var n = "FORM" === (t.tagName || "").toUpperCase(),
                r = A(e, 1, n),
                a = A(e, 2, n);
            e = A(e, 3, n), m(r) && (r = R(r), n ? l("_gl", r, t) : u("_gl", r, t, !1)), !n && m(a) && (n = R(a), u("_gl", n, t, !0));
            for (var o in e) e.hasOwnProperty(o) && c(o, e[o], t)
        }

        function c(t, e, n, r) {
            if (n.tagName) {
                if ("a" === n.tagName.toLowerCase()) return u(t, e, n, r);
                if ("form" === n.tagName.toLowerCase()) return l(t, e, n)
            }
            if ("string" == typeof n) return i(t, e, n, r)
        }

        function u(t, e, n, r) {
            n.href && (t = i(t, e, n.href, void 0 !== r && r), y.test(t) && (n.href = t))
        }

        function l(t, e, n) {
            if (n && n.action) {
                var r = (n.method || "").toLowerCase();
                if ("get" === r) {
                    r = n.childNodes || [];
                    for (var a = !1, o = 0; o < r.length; o++) {
                        var s = r[o];
                        if (s.name === t) {
                            s.setAttribute("value", e), a = !0;
                            break
                        }
                    }
                    a || (r = b.createElement("input"), r.setAttribute("type", "hidden"), r.setAttribute("name", t), r.setAttribute("value", e), n.appendChild(r))
                } else "post" === r && (t = i(t, e, n.action), y.test(t) && (n.action = t))
            }
        }
        var f, g, h, d = this || self,
            p = function(t, e) {
                t = t.split(".");
                var n = d;
                t[0] in n || void 0 === n.execScript || n.execScript("var " + t[0]);
                for (var r; t.length && (r = t.shift());) t.length || void 0 === e ? n = n[r] && n[r] !== Object.prototype[r] ? n[r] : n[r] = {} : n[r] = e
            },
            v = function(t, e) {
                for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
            },
            m = function(t) {
                for (var e in t)
                    if (t.hasOwnProperty(e)) return !0;
                return !1
            },
            w = window,
            b = document,
            _ = function(t, e) {
                b.addEventListener ? b.addEventListener(t, e, !1) : b.attachEvent && b.attachEvent("on" + t, e)
            },
            y = /^(?:(?:https?|mailto|ftp):|[^:\/?#]*(?:[\/?#]|$))/i,
            k = {},
            x = function() {
                k.TAGGING = k.TAGGING || [], k.TAGGING[1] = !0
            },
            O = /:[0-9]+$/,
            S = function(t, e) {
                e && (e = String(e).toLowerCase()), "protocol" !== e && "port" !== e || (t.protocol = T(t.protocol) || T(w.location.protocol)), "port" === e ? t.port = String(Number(t.hostname ? t.port : w.location.port) || ("http" == t.protocol ? 80 : "https" == t.protocol ? 443 : "")) : "host" === e && (t.hostname = (t.hostname || w.location.hostname).replace(O, "").toLowerCase());
                var n = T(t.protocol);
                switch (e && (e = String(e).toLowerCase()), e) {
                    case "url_no_fragment":
                        e = "", t && t.href && (e = t.href.indexOf("#"), e = 0 > e ? t.href : t.href.substr(0, e)), t = e;
                        break;
                    case "protocol":
                        t = n;
                        break;
                    case "host":
                        t = t.hostname.replace(O, "").toLowerCase();
                        break;
                    case "port":
                        t = String(Number(t.port) || ("http" == n ? 80 : "https" == n ? 443 : ""));
                        break;
                    case "path":
                        t.pathname || t.hostname || x(), t = "/" == t.pathname.substr(0, 1) ? t.pathname : "/" + t.pathname, t = t.split("/");
                        t: if (e = t[t.length - 1], n = [], Array.prototype.indexOf) e = n.indexOf(e), e = "number" == typeof e ? e : -1;
                            else {
                                for (var r = 0; r < n.length; r++)
                                    if (n[r] === e) {
                                        e = r;
                                        break t
                                    }
                                e = -1
                            }
                        0 <= e && (t[t.length - 1] = ""), t = t.join("/");
                        break;
                    case "query":
                        t = t.search.replace("?", "");
                        break;
                    case "extension":
                        t = t.pathname.split("."), t = 1 < t.length ? t[t.length - 1] : "", t = t.split("/")[0];
                        break;
                    case "fragment":
                        t = t.hash.replace("#", "");
                        break;
                    default:
                        t = t && t.href
                }
                return t
            },
            T = function(t) {
                return t ? t.replace(":", "").toLowerCase() : ""
            },
            j = function(t) {
                var e = b.createElement("a");
                t && (e.href = t);
                var n = e.pathname;
                return "/" !== n[0] && (t || x(), n = "/" + n), t = e.hostname.replace(O, ""), {
                    href: e.href,
                    protocol: e.protocol,
                    host: e.host,
                    hostname: t,
                    pathname: n,
                    search: e.search,
                    hash: e.hash,
                    port: e.port
                }
            },
            C = function() {
                var t = q,
                    e = U,
                    n = N(),
                    r = function(e) {
                        t(e.target || e.srcElement || {})
                    },
                    a = function(t) {
                        e(t.target || t.srcElement || {})
                    };
                if (!n.init) {
                    _("mousedown", r), _("keyup", r), _("submit", a);
                    var o = HTMLFormElement.prototype.submit;
                    HTMLFormElement.prototype.submit = function() {
                        e(this), o.call(this)
                    }, n.init = !0
                }
            },
            A = function(t, e, n) {
                for (var r = N().decorators, a = {}, o = 0; o < r.length; ++o) {
                    var i, s = r[o];
                    if (i = !n || s.forms) t: {
                        i = s.domains;
                        var c = t;
                        if (i && (s.sameHost || c !== b.location.hostname))
                            for (var u = 0; u < i.length; u++)
                                if (i[u] instanceof RegExp) {
                                    if (i[u].test(c)) {
                                        i = !0;
                                        break t
                                    }
                                } else if (0 <= c.indexOf(i[u])) {
                            i = !0;
                            break t
                        }
                        i = !1
                    }
                    i && (i = s.placement, void 0 == i && (i = s.fragment ? 2 : 1), i === e && v(a, s.callback()))
                }
                return a
            },
            N = function() {
                var t = {},
                    e = w.google_tag_data;
                return w.google_tag_data = void 0 === e ? t : e, t = w.google_tag_data, e = t.gl, e && e.decorators || (e = {
                    decorators: []
                }, t.gl = e), e
            },
            E = /(.*?)\*(.*?)\*(.*)/,
            I = /([^?#]+)(\?[^#]*)?(#.*)?/,
            R = function(t) {
                var e, r = [];
                for (e in t)
                    if (t.hasOwnProperty(e)) {
                        var a = t[e];
                        void 0 !== a && a === a && null !== a && "[object Object]" !== a.toString() && (r.push(e), r.push(n(String(a))))
                    }
                return t = r.join("*"), ["1", L(t), t].join("*")
            },
            L = function(t, e) {
                if (t = [window.navigator.userAgent, (new Date).getTimezoneOffset(), window.navigator.userLanguage || window.navigator.language, Math.floor((new Date).getTime() / 60 / 1e3) - (void 0 === e ? 0 : e), t].join("*"), !(e = h)) {
                    e = Array(256);
                    for (var n = 0; 256 > n; n++) {
                        for (var r = n, a = 0; 8 > a; a++) r = 1 & r ? r >>> 1 ^ 3988292384 : r >>> 1;
                        e[n] = r
                    }
                }
                for (h = e, e = 4294967295, n = 0; n < t.length; n++) e = e >>> 8 ^ h[255 & (e ^ t.charCodeAt(n))];
                return ((-1 ^ e) >>> 0).toString(36)
            },
            $ = function(t) {
                return function(e) {
                    var n = j(w.location.href),
                        r = n.search.replace("?", "");
                    t: {
                        for (var o = r.split("&"), i = 0; i < o.length; i++) {
                            var s = o[i].split("=");
                            if ("_gl" === decodeURIComponent(s[0]).replace(/\+/g, " ")) {
                                o = s.slice(1).join("=");
                                break t
                            }
                        }
                        o = void 0
                    }
                    e.query = M(o || "") || {}, o = S(n, "fragment"), i = o.match(a("_gl")), e.fragment = M(i && i[3] || "") || {}, t && P(n, r, o)
                }
            },
            P = function(t, e, n) {
                function r(t, e) {
                    return t = o("_gl", t), t.length && (t = e + t), t
                }
                if (w.history && w.history.replaceState) {
                    var i = a("_gl");
                    (i.test(e) || i.test(n)) && (t = S(t, "path"), e = r(e, "?"), n = r(n, "#"), w.history.replaceState({}, void 0, "" + t + e + n))
                }
            },
            M = function(t) {
                var e = void 0 === e ? 3 : e;
                try {
                    if (t) {
                        t: {
                            for (var n = 0; 3 > n; ++n) {
                                var a = E.exec(t);
                                if (a) {
                                    var o = a;
                                    break t
                                }
                                t = decodeURIComponent(t)
                            }
                            o = void 0
                        }
                        if (o && "1" === o[1]) {
                            var i = o[2],
                                s = o[3];
                            t: {
                                for (o = 0; o < e; ++o)
                                    if (i === L(s, o)) {
                                        var c = !0;
                                        break t
                                    }
                                c = !1
                            }
                            if (c) {
                                e = {};
                                var u = s ? s.split("*") : [];
                                for (s = 0; s < u.length; s += 2) e[u[s]] = r(u[s + 1]);
                                return e
                            }
                        }
                    }
                } catch (t) {}
            },
            q = function(t) {
                try {
                    t: {
                        for (var e = 100; t && 0 < e;) {
                            if (t.href && t.nodeName.match(/^a(?:rea)?$/i)) {
                                var n = t;
                                break t
                            }
                            t = t.parentNode, e--
                        }
                        n = null
                    }
                    if (n) {
                        var r = n.protocol;
                        "http:" !== r && "https:" !== r || s(n, n.hostname)
                    }
                }
                catch (t) {}
            },
            U = function(t) {
                try {
                    if (t.action) {
                        s(t, S(j(t.action), "host"))
                    }
                } catch (t) {}
            };
        p("google_tag_data.glBridge.auto", function(t, e, n, r) {
            C(), n = "fragment" === n ? 2 : 1, t = {
                callback: t,
                domains: e,
                fragment: 2 === n,
                placement: n,
                forms: !!r,
                sameHost: !1
            }, N().decorators.push(t)
        }), p("google_tag_data.glBridge.decorate", function(t, e, n) {
            return t = R(t), c("_gl", t, e, !!n)
        }), p("google_tag_data.glBridge.generate", R), p("google_tag_data.glBridge.get", function(t, e) {
            var n = $(!!e);
            return e = N(), e.data || (e.data = {
                query: {},
                fragment: {}
            }, n(e.data)), n = {}, (e = e.data) && (v(n, e.query), t && v(n, e.fragment)), n
        })
    }(window),
    function() {
        function t(t) {
            var e, n = 1;
            if (t)
                for (n = 0, e = t.length - 1; 0 <= e; e--) {
                    var r = t.charCodeAt(e);
                    n = (n << 6 & 268435455) + r + (r << 14), r = 266338304 & n, n = 0 != r ? n ^ r >> 21 : n
                }
            return n
        }

        function e(t) {
            L.set(t)
        }

        function n(e) {
            if (100 != e.get(qn) && t(Bt(e, kn)) % 1e4 >= 100 * zt(e, qn)) throw "abort"
        }

        function a(t) {
            if (gt(Bt(t, Tn))) throw "abort"
        }

        function o() {
            var t = ct.location.protocol;
            if ("http:" != t && "https:" != t) throw "abort"
        }

        function i(t) {
            try {
                st.navigator.sendBeacon ? e(42) : st.XMLHttpRequest && "withCredentials" in new st.XMLHttpRequest && e(40)
            } catch (t) {}
            t.set(en, $(t), !0), t.set(fe, zt(t, fe) + 1);
            var n = [];
            Xt.map(function(e, r) {
                r.F && void 0 != (e = t.get(e)) && e != r.defaultValue && ("boolean" == typeof e && (e *= 1), n.push(r.F + "=" + B("" + e)))
            }), !1 === t.get(er) && n.push("npa=1"), n.push("z=" + Ft()), t.set(ce, n.join("&"), !0)
        }

        function s(t) {
            var e = Bt(t, le);
            !e && t.get(ue) && (e = "beacon");
            var n = Bt(t, Wn),
                r = Bt(t, Wn),
                a = Bt(t, Zn),
                o = n || (a ? a + "/3" : Et(!1) + "/collect");
            switch (eq = r || (a ? a + "/3" : "/collect/qc2"), Bt(t, Qn)) {
                case "d":
                    o = n || (a ? a + "/32" : Et(!1) + "/j/collect"), eq = r || (a ? a + "/32" : "/collect/qc2"), e = t.get(Jn) || void 0, par = Bt(t, ce), par += "&qcv=2.0.0", Lt(o, par, e, t.Z(se)), Lt(eq, par, e, t.Z(se));
                    break;
                case "b":
                    o = n || (a ? a + "/31" : Et(!1) + "/r/collect"), eq = r || (a ? a + "/31" : "/collect/qc2");
                default:
                    e ? (r = Bt(t, ce), r += "&qcv=2.0.0", a = (a = t.Z(se)) || H, "image" == e ? $t(eq, r, a) : "xhr" == e && Pt(eq, r, a) || "beacon" == e && Mt(eq, r, a) || Rt(eq, r, a)) : Rt(eq, Bt(t, ce), t.Z(se)), e ? (n = Bt(t, ce), a = (a = t.Z(se)) || H, "image" == e ? $t(o, n, a) : "xhr" == e && Pt(o, n, a) || "beacon" == e && Mt(o, n, a) || Rt(o, n, a)) : Rt(o, Bt(t, ce), t.Z(se))
            }
            o = Bt(t, Tn), o = Dt(o), e = o.hitcount, o.hitcount = e ? e + 1 : 1, o = Bt(t, Tn), delete Dt(o).pending_experiments, t.set(se, H, !0)
        }

        function c(t) {
            Ut().expId && t.set(Be, Ut().expId), Ut().expVar && t.set(ze, Ut().expVar);
            var e = Bt(t, Tn);
            if (e = Dt(e).pending_experiments) {
                var n = [];
                for (r in e) e.hasOwnProperty(r) && e[r] && n.push(encodeURIComponent(r) + "." + encodeURIComponent(e[r]));
                var r = n.join("!")
            } else r = void 0;
            r && t.set(Ke, r, !0)
        }

        function u() {
            if (st.navigator && "preview" == st.navigator.loadPurpose) throw "abort"
        }

        function l(t) {
            var e = st.gaDevIds;
            q(e) && 0 != e.length && t.set("&did", e.join(","), !0)
        }

        function f(t) {
            if (!t.get(Tn)) throw "abort"
        }

        function g(t) {
            var n = zt(t, Ye);
            500 <= n && e(15);
            var r = Bt(t, ie);
            if ("transaction" != r && "item" != r) {
                r = zt(t, Qe);
                var a = (new Date).getTime(),
                    o = zt(t, Je);
                if (0 == o && t.set(Je, a), o = Math.round(2 * (a - o) / 1e3), 0 < o && (r = Math.min(r + o, 20), t.set(Je, a)), 0 >= r) throw "abort";
                t.set(Qe, --r)
            }
            t.set(Ye, ++n)
        }

        function h(t, n, r, a) {
            n[t] = function() {
                try {
                    return a && e(a), r.apply(this, arguments)
                } catch (e) {
                    throw qt("exc", t, e && e.name), e
                }
            }
        }

        function d() {
            var t, e;
            if ((e = (e = st.navigator) ? e.plugins : null) && e.length)
                for (var n = 0; n < e.length && !t; n++) {
                    var r = e[n]; - 1 < r.name.indexOf("Shockwave Flash") && (t = r.description)
                }
            if (!t) try {
                var a = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");
                t = a.GetVariable("$version")
            } catch (t) {}
            if (!t) try {
                a = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6"), t = "WIN 6,0,21,0", a.AllowScriptAccess = "always", t = a.GetVariable("$version")
            } catch (t) {}
            if (!t) try {
                a = new ActiveXObject("ShockwaveFlash.ShockwaveFlash"), t = a.GetVariable("$version")
            } catch (t) {}
            return t && (a = t.match(/[\d]+/g)) && 3 <= a.length && (t = a[0] + "." + a[1] + " r" + a[2]), t || void 0
        }

        function p(t, e, n) {
            "none" == e && (e = "");
            var r = [],
                a = ht(t);
            t = "__utma" == t ? 6 : 2;
            for (var o = 0; o < a.length; o++) {
                var i = ("" + a[o]).split(".");
                i.length >= t && r.push({
                    hash: i[0],
                    R: a[o],
                    O: i
                })
            }
            if (0 != r.length) return 1 == r.length ? r[0] : v(e, r) || v(n, r) || v(null, r) || r[0]
        }

        function v(e, n) {
            if (null == e) var r = e = 1;
            else r = t(e), e = t(D(e, ".") ? e.substring(1) : "." + e);
            for (var a = 0; a < n.length; a++)
                if (n[a].hash == r || n[a].hash == e) return n[a]
        }

        function m(t) {
            if (t.get(tn)) return e(35), Tr.generate(k(t));
            var n = Bt(t, kn),
                r = Bt(t, Gn) || "";
            return n = "_ga=2." + B(b(r + n, 0) + "." + r + "-" + n), (t = x(t)) ? (e(44), t = "&_gac=1." + B([b(t.qa, 0), t.timestamp, t.qa].join("."))) : t = "", n + t
        }

        function w(e, n) {
            var r = new Date,
                a = st.navigator,
                o = a.plugins || [];
            for (e = [e, a.userAgent, r.getTimezoneOffset(), r.getYear(), r.getDate(), r.getHours(), r.getMinutes() + n], n = 0; n < o.length; ++n) e.push(o[n].description);
            return t(e.join("."))
        }

        function b(e, n) {
            var r = new Date,
                a = st.navigator,
                o = r.getHours() + Math.floor((r.getMinutes() + n) / 60);
            return t([e, a.userAgent, a.language || "", r.getTimezoneOffset(), r.getYear(), r.getDate() + Math.floor(o / 24), (24 + o) % 24, (60 + r.getMinutes() + n) % 60].join("."))
        }

        function _(t, e) {
            if (e == ct.location.hostname) return !1;
            for (var n = 0; n < t.length; n++)
                if (t[n] instanceof RegExp) {
                    if (t[n].test(e)) return !0
                } else if (0 <= e.indexOf(t[n])) return !0;
            return !1
        }

        function y(t, e) {
            return e != w(t, 0) && e != w(t, -1) && e != w(t, -2) && e != b(t, 0) && e != b(t, -1) && e != b(t, -2)
        }

        function k(t) {
            var e = x(t);
            return {
                _ga: t.get(kn),
                _gid: t.get(Gn) || void 0,
                _gac: e ? [e.qa, e.timestamp].join(".") : void 0
            }
        }

        function x(t) {
            function n(t) {
                return void 0 == t || "" === t ? 0 : Number(t)
            }
            var r = t.get(Hn);
            if (r && t.get(Xn)) {
                var a = n(t.get(Bn));
                if (!(1e3 * a + n(t.get(zn)) <= (new Date).getTime())) return {
                    timestamp: a,
                    qa: r
                };
                e(76)
            }
        }

        function O(t) {
            return 0 <= t.indexOf(".") || 0 <= t.indexOf(":")
        }
        var S = function(t) {
            this.w = t || []
        };
        S.prototype.set = function(t) {
            this.w[t] = !0
        }, S.prototype.encode = function() {
            for (var t = [], e = 0; e < this.w.length; e++) this.w[e] && (t[Math.floor(e / 6)] ^= 1 << e % 6);
            for (e = 0; e < t.length; e++) t[e] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(t[e] || 0);
            return t.join("") + "~"
        };
        var T, j = window.GoogleAnalyticsObject;
        (T = void 0 != j) && (T = -1 < (j.constructor + "").indexOf("String"));
        var C;
        if (C = T) {
            var A = window.GoogleAnalyticsObject;
            C = A ? A.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "") : ""
        }
        var N = C || "ga",
            E = /^(?:utma\.)?\d+\.\d+$/,
            I = /^amp-[\w.-]{22,64}$/,
            R = !1,
            L = new S,
            $ = function(t) {
                t = P(t), t = new S(t);
                for (var e = L.w.slice(), n = 0; n < t.w.length; n++) e[n] = e[n] || t.w[n];
                return new S(e).encode()
            },
            P = function(t) {
                return t = t.get(nn), q(t) || (t = []), t
            },
            M = function(t) {
                return "function" == typeof t
            },
            q = function(t) {
                return "[object Array]" == Object.prototype.toString.call(Object(t))
            },
            U = function(t) {
                return void 0 != t && -1 < (t.constructor + "").indexOf("String")
            },
            D = function(t, e) {
                return 0 == t.indexOf(e)
            },
            G = function(t) {
                return t ? t.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "") : ""
            },
            V = function() {
                for (var e = st.navigator.userAgent + (ct.cookie ? ct.cookie : "") + (ct.referrer ? ct.referrer : ""), n = e.length, r = st.history.length; 0 < r;) e += r-- ^ n++;
                return [Vt() ^ 2147483647 & t(e), Math.round((new Date).getTime() / 1e3)].join(".")
            },
            F = function(t) {
                var e = ct.createElement("img");
                return e.width = 1, e.height = 1, e.src = t, e
            },
            H = function() {},
            B = function(t) {
                return encodeURIComponent instanceof Function ? encodeURIComponent(t) : (e(28), t)
            },
            z = function(t, n, r, a) {
                try {
                    t.addEventListener ? t.addEventListener(n, r, !!a) : t.attachEvent && t.attachEvent("on" + n, r)
                } catch (t) {
                    e(27)
                }
            },
            K = /^[\w\-:\/.?=&%!\[\]]+$/,
            X = /^[\w+\/_-]+[=]{0,2}$/,
            Z = function(t, e) {
                return W(ct.location[e ? "href" : "search"], t)
            },
            W = function(t, e) {
                return (t = t.match("(?:&|#|\\?)" + B(e).replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1") + "=([^&#]*)")) && 2 == t.length ? t[1] : ""
            },
            Y = function() {
                var t = "" + ct.location.hostname;
                return 0 == t.indexOf("www.") ? t.substring(4) : t
            },
            J = function(t, e) {
                var n = t.indexOf(e);
                return !(5 != n && 6 != n || "/" != (t = t.charAt(n + e.length)) && "?" != t && "" != t && ":" != t)
            },
            Q = function(t, e) {
                var n = ct.referrer;
                if (/^(https?|android-app):\/\//i.test(n)) {
                    if (t) return n;
                    if (t = "//" + ct.location.hostname, !J(n, t)) return e && (e = t.replace(/\./g, "-") + ".cdn.ampproject.org", J(n, e)) ? void 0 : n
                }
            },
            tt = function(t, e) {
                if (1 == e.length && null != e[0] && "object" === r(e[0])) return e[0];
                for (var n = {}, a = Math.min(t.length + 1, e.length), o = 0; o < a; o++) {
                    if ("object" === r(e[o])) {
                        for (var i in e[o]) e[o].hasOwnProperty(i) && (n[i] = e[o][i]);
                        break
                    }
                    o < t.length && (n[t[o]] = e[o])
                }
                return n
            },
            et = function() {
                this.keys = [], this.values = {}, this.m = {}
            };
        et.prototype.set = function(t, e, n) {
            this.keys.push(t), n ? this.m[":" + t] = e : this.values[":" + t] = e
        }, et.prototype.get = function(t) {
            return this.m.hasOwnProperty(":" + t) ? this.m[":" + t] : this.values[":" + t]
        }, et.prototype.map = function(t) {
            for (var e = 0; e < this.keys.length; e++) {
                var n = this.keys[e],
                    r = this.get(n);
                r && t(n, r)
            }
        };
        var nt, rt, at, ot, it, st = window,
            ct = document,
            ut = function(t, e) {
                return setTimeout(t, e)
            },
            lt = window,
            ft = document,
            gt = function(t) {
                var e = lt._gaUserPrefs;
                if (e && e.ioo && e.ioo() || t && !0 === lt["ga-disable-" + t]) return !0;
                try {
                    var n = lt.external;
                    if (n && n._gaUserPrefs && "oo" == n._gaUserPrefs) return !0
                } catch (t) {}
                for (t = [], e = String(ft.cookie || document.cookie).split(";"), n = 0; n < e.length; n++) {
                    var r = e[n].split("="),
                        a = r[0].replace(/^\s*|\s*$/g, "");
                    a && "AMP_TOKEN" == a && ((r = r.slice(1).join("=").replace(/^\s*|\s*$/g, "")) && (r = decodeURIComponent(r)), t.push(r))
                }
                for (e = 0; e < t.length; e++)
                    if ("$OPT_OUT" == t[e]) return !0;
                return !!ft.getElementById("__gaOptOutExtension")
            },
            ht = function(t) {
                var e = [],
                    n = ct.cookie.split(";");
                t = new RegExp("^\\s*" + t + "=\\s*(.*?)\\s*$");
                for (var r = 0; r < n.length; r++) {
                    var a = n[r].match(t);
                    a && e.push(a[1])
                }
                return e
            },
            dt = function(t, e, n, r, a, o, i) {
                if (!(a = !gt(a) && !(mt.test(ct.location.hostname) || "/" == n && vt.test(r)))) return !1;
                if (e && 1200 < e.length && (e = e.substring(0, 1200)), n = t + "=" + e + "; path=" + n + "; ", o && (n += "expires=" + new Date((new Date).getTime() + o).toGMTString() + "; "), r && "none" !== r && (n += "domain=" + r + ";"), i && (n += i + ";"), r = ct.cookie, ct.cookie = n, !(r = r != ct.cookie)) t: {
                    for (t = ht(t), r = 0; r < t.length; r++)
                        if (e == t[r]) {
                            r = !0;
                            break t
                        }
                    r = !1
                }
                return r
            },
            pt = function(t) {
                return encodeURIComponent ? encodeURIComponent(t).replace(/\(/g, "%28").replace(/\)/g, "%29") : t
            },
            vt = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
            mt = /(^|\.)doubleclick\.net$/i,
            wt = /^.*Version\/?(\d+)[^\d].*$/i,
            bt = function() {
                if (void 0 !== st.__ga4__) return st.__ga4__;
                if (void 0 === nt) {
                    var t = st.navigator.userAgent;
                    if (t) {
                        var e = t;
                        try {
                            e = decodeURIComponent(t)
                        } catch (t) {}(t = !(0 <= e.indexOf("Chrome") || 0 <= e.indexOf("CriOS") || !(0 <= e.indexOf("Safari/") || 0 <= e.indexOf("Safari,")))) && (e = wt.exec(e), t = 11 <= (e ? Number(e[1]) : -1)), nt = t
                    } else nt = !1
                }
                return nt
            },
            _t = /^https?:\/\/[^\/]*cdn\.ampproject\.org\//,
            yt = /^(?:www\.|m\.|amp\.)+/,
            kt = [],
            xt = function(t) {
                if (Nt(t[Fn])) {
                    if (void 0 === it) {
                        var n;
                        (n = (n = Tr.get()) && n._ga || void 0) && (it = n, e(81))
                    }
                    if (void 0 !== it) return t[kn] || (t[kn] = it), !1
                }
                if (t[Fn]) {
                    if (e(67), t[$n] && "cookie" != t[$n]) return !1;
                    if (void 0 !== it) t[kn] || (t[kn] = it);
                    else {
                        t: {
                            n = String(t[Cn] || Y());
                            var r = String(t[An] || "/"),
                                a = ht(String(t[jn] || "_ga"));
                            if (!(n = wr(a, n, r)) || E.test(n)) n = !0;
                            else if (n = ht("AMP_TOKEN"), 0 == n.length) n = !0;
                            else {
                                if (1 == n.length && ("$RETRIEVING" == (n = decodeURIComponent(n[0])) || "$OPT_OUT" == n || "$ERROR" == n || "$NOT_FOUND" == n)) {
                                    n = !0;
                                    break t
                                }
                                n = !1
                            }
                        }
                        if (n && St(Ot, String(t[Tn]))) return !0
                    }
                }
                return !1
            },
            Ot = function() {
                ha.D([H])
            },
            St = function t(n, r) {
                var a = ht("AMP_TOKEN");
                return 1 < a.length ? (e(55), !1) : "$OPT_OUT" == (a = decodeURIComponent(a[0] || "")) || "$ERROR" == a || gt(r) ? (e(62), !1) : _t.test(ct.referrer) || "$NOT_FOUND" != a ? void 0 !== it ? (e(56), ut(function() {
                    n(it)
                }, 0), !0) : rt ? (kt.push(n), !0) : "$RETRIEVING" == a ? (e(57), ut(function() {
                    t(n, r)
                }, 1e4), !0) : (rt = !0, a && "$" != a[0] || (Ct("$RETRIEVING", 3e4), setTimeout(jt, 3e4), a = ""), !!Tt(a, r) && (kt.push(n), !0)) : (e(68), !1)
            },
            Tt = function t(n, r, a) {
                if (!window.JSON) return e(58), !1;
                var o = st.XMLHttpRequest;
                if (!o) return e(59), !1;
                var i = new o;
                return "withCredentials" in i ? (i.open("POST", (a || "https://ampcid.google.com/v1/publisher:getClientId") + "?key=AIzaSyA65lEHUEizIsNtlbNo-l2K18dT680nsaM", !0), i.withCredentials = !0, i.setRequestHeader("Content-Type", "text/plain"), i.onload = function() {
                    if (rt = !1, 4 == i.readyState) {
                        try {
                            200 != i.status && (e(61), At("", "$ERROR", 3e4));
                            var o = JSON.parse(i.responseText);
                            o.optOut ? (e(63), At("", "$OPT_OUT", 31536e6)) : o.clientId ? At(o.clientId, o.securityToken, 31536e6) : !a && o.alternateUrl ? (at && clearTimeout(at), rt = !0, t(n, r, o.alternateUrl)) : (e(64), At("", "$NOT_FOUND", 36e5))
                        } catch (t) {
                            e(65), At("", "$ERROR", 3e4)
                        }
                        i = null
                    }
                }, o = {
                    originScope: "AMP_ECID_GOOGLE"
                }, n && (o.securityToken = n), i.send(JSON.stringify(o)), at = ut(function() {
                    e(66), At("", "$ERROR", 3e4)
                }, 1e4), !0) : (e(60), !1)
            },
            jt = function() {
                rt = !1
            },
            Ct = function(t, e) {
                if (void 0 === ot) {
                    ot = "";
                    for (var n = yr(), r = 0; r < n.length; r++) {
                        var a = n[r];
                        if (dt("AMP_TOKEN", encodeURIComponent(t), "/", a, "", e)) return void(ot = a)
                    }
                }
                dt("AMP_TOKEN", encodeURIComponent(t), "/", ot, "", e)
            },
            At = function(t, e, n) {
                for (at && clearTimeout(at), e && Ct(e, n), it = t, e = kt, kt = [], n = 0; n < e.length; n++) e[n](t)
            },
            Nt = function(t) {
                t: {
                    if (_t.test(ct.referrer)) {
                        var n = ct.location.hostname.replace(yt, "");
                        e: {
                            var r = ct.referrer;r = r.replace(/^https?:\/\//, "");
                            var a = r.replace(/^[^\/]+/, "").split("/"),
                                o = a[2];
                            if (!(a = (a = "s" == o ? a[3] : o) ? decodeURIComponent(a) : a)) {
                                if (0 == r.indexOf("xn--")) {
                                    r = "";
                                    break e
                                }(r = r.match(/(.*)\.cdn\.ampproject\.org\/?$/)) && 2 == r.length && (a = r[1].replace(/-/g, ".").replace(/\.\./g, "-"))
                            }
                            r = a ? a.replace(yt, "") : ""
                        }
                        if ((a = n === r) || (r = "." + r, a = n.substring(n.length - r.length, n.length) === r), a) {
                            n = !0;
                            break t
                        }
                        e(78)
                    }
                    n = !1
                }
                return n && !1 !== t
            },
            Et = function(t) {
                return (t ? "https:" : R || "https:" == ct.location.protocol ? "https:" : "http:") + "//www.google-analytics.com"
            },
            It = function(t) {
                this.name = "len", this.message = t + "-8192"
            },
            Rt = function(t, e, n) {
                if (n = n || H, 2036 >= e.length) $t(t, e, n);
                else {
                    if (!(8192 >= e.length)) throw qt("len", e.length), new It(e.length);
                    Mt(t, e, n) || Pt(t, e, n) || $t(t, e, n)
                }
            },
            Lt = function(t, e, n, r) {
                r = r || H, Pt(t + "?" + e, "", r, n)
            },
            $t = function(t, e, n) {
                var r = F(t + "?" + e);
                r.onload = r.onerror = function() {
                    r.onload = null, r.onerror = null, n()
                }
            },
            Pt = function(t, e, n, r) {
                var a = st.XMLHttpRequest;
                if (!a) return !1;
                var o = new a;
                return "withCredentials" in o && (t = t.replace(/^http:/, "https:"), o.open("POST", t, !0), o.withCredentials = !0, o.setRequestHeader("Content-Type", "text/plain"), o.onreadystatechange = function() {
                    if (4 == o.readyState) {
                        if (r) try {
                            var t = o.responseText;
                            if (1 > t.length) qt("xhr", "ver", "0"), n();
                            else if ("1" != t.charAt(0)) qt("xhr", "ver", String(t.length)), n();
                            else if (3 < r.count++) qt("xhr", "tmr", "" + r.count), n();
                            else if (1 == t.length) n();
                            else {
                                var e = t.charAt(1);
                                if ("d" == e) Lt("https://stats.g.doubleclick.net/j/collect", r.U, r, n);
                                else if ("g" == e) {
                                    $t("https://www.google.%/ads/ga-audiences".replace("%", "com"), r.google, n);
                                    var a = t.substring(2);
                                    a && (/^[a-z.]{1,6}$/.test(a) ? $t("https://www.google.%/ads/ga-audiences".replace("%", a), r.google, H) : qt("tld", "bcc", a))
                                } else qt("xhr", "brc", e), n()
                            }
                        } catch (t) {
                            qt("xhr", "rsp"), n()
                        } else n();
                        o = null
                    }
                }, o.send(e), !0)
            },
            Mt = function(t, e, n) {
                return !!st.navigator.sendBeacon && (!!st.navigator.sendBeacon(t, e) && (n(), !0))
            },
            qt = function(t, e, n) {
                1 <= 100 * Math.random() || gt("?") || (t = ["t=error", "_e=" + t, "_v=j81", "sr=1"], e && t.push("_f=" + e), n && t.push("_m=" + B(n.substring(0, 100))), t.push("aip=1"), t.push("z=" + Vt()), $t(Et(!0) + "/u/d", t.join("&"), H))
            },
            Ut = function() {
                return st.gaData = st.gaData || {}
            },
            Dt = function(t) {
                var e = Ut();
                return e[t] = e[t] || {}
            },
            Gt = function() {
                this.M = []
            };
        Gt.prototype.add = function(t) {
            this.M.push(t)
        }, Gt.prototype.D = function(t) {
            try {
                for (var e = 0; e < this.M.length; e++) {
                    var n = t.get(this.M[e]);
                    n && M(n) && n.call(st, t)
                }
            } catch (t) {}(e = t.get(se)) != H && M(e) && (t.set(se, H, !0), setTimeout(e, 10))
        };
        var Vt = function() {
                return Math.round(2147483647 * Math.random())
            },
            Ft = function() {
                try {
                    var t = new Uint32Array(1);
                    return st.crypto.getRandomValues(t), 2147483647 & t[0]
                } catch (t) {
                    return Vt()
                }
            },
            Ht = function() {
                this.data = new et
            };
        Ht.prototype.get = function(t) {
            var e = Yt(t),
                n = this.data.get(t);
            return e && void 0 == n && (n = M(e.defaultValue) ? e.defaultValue() : e.defaultValue), e && e.Z ? e.Z(this, t, n) : n
        };
        var Bt = function(t, e) {
                return t = t.get(e), void 0 == t ? "" : "" + t
            },
            zt = function(t, e) {
                return t = t.get(e), void 0 == t || "" === t ? 0 : Number(t)
            };
        Ht.prototype.Z = function(t) {
            return (t = this.get(t)) && M(t) ? t : H
        }, Ht.prototype.set = function(t, e, n) {
            if (t)
                if ("object" == (void 0 === t ? "undefined" : r(t)))
                    for (var a in t) t.hasOwnProperty(a) && Kt(this, a, t[a], n);
                else Kt(this, t, e, n)
        };
        var Kt = function(t, e, n, r) {
                if (void 0 != n) switch (e) {
                    case Tn:
                        Xr.test(n)
                }
                var a = Yt(e);
                a && a.o ? a.o(t, e, n, r) : t.data.set(e, n, r)
            },
            Xt = new et,
            Zt = [],
            Wt = function(t, e, n, r, a) {
                this.name = t, this.F = e, this.Z = r, this.o = a, this.defaultValue = n
            },
            Yt = function(t) {
                var e = Xt.get(t);
                if (!e)
                    for (var n = 0; n < Zt.length; n++) {
                        var r = Zt[n],
                            a = r[0].exec(t);
                        if (a) {
                            e = r[1](a), Xt.set(e.name, e);
                            break
                        }
                    }
                return e
            },
            Jt = function(t) {
                var e;
                return Xt.map(function(n, r) {
                    r.F == t && (e = r)
                }), e && e.name
            },
            Qt = function(t, e, n, r, a) {
                return t = new Wt(t, e, n, r, a), Xt.set(t.name, t), t.name
            },
            te = function(t, e) {
                Zt.push([new RegExp("^" + t + "$"), e])
            },
            ee = function(t, e, n) {
                return Qt(t, e, n, void 0, ne)
            },
            ne = function() {},
            re = ee("apiVersion", "v"),
            ae = ee("clientVersion", "_v");
        Qt("anonymizeIp", "aip");
        var oe = Qt("adSenseId", "a"),
            ie = Qt("hitType", "t"),
            se = Qt("hitCallback"),
            ce = Qt("hitPayload");
        Qt("nonInteraction", "ni"), Qt("currencyCode", "cu"), Qt("dataSource", "ds");
        var ue = Qt("useBeacon", void 0, !1),
            le = Qt("transport");
        Qt("sessionControl", "sc", ""), Qt("sessionGroup", "sg"), Qt("queueTime", "qt");
        var fe = Qt("_s", "_s");
        Qt("screenName", "cd");
        var ge = Qt("location", "dl", ""),
            he = Qt("referrer", "dr"),
            de = Qt("page", "dp", "");
        Qt("hostname", "dh");
        var pe = Qt("language", "ul"),
            ve = Qt("encoding", "de");
        Qt("title", "dt", function() {
            return ct.title || void 0
        }), te("contentGroup([0-9]+)", function(t) {
            return new Wt(t[0], "cg" + t[1])
        });
        var me = Qt("screenColors", "sd"),
            we = Qt("screenResolution", "sr"),
            be = Qt("viewportSize", "vp"),
            _e = Qt("javaEnabled", "je"),
            ye = Qt("flashVersion", "fl");
        Qt("campaignId", "ci"), Qt("campaignName", "cn"), Qt("campaignSource", "cs"), Qt("campaignMedium", "cm"), Qt("campaignKeyword", "ck"), Qt("campaignContent", "cc");
        var ke = Qt("eventCategory", "ec"),
            xe = Qt("eventAction", "ea"),
            Oe = Qt("eventLabel", "el"),
            Se = Qt("eventValue", "ev"),
            Te = Qt("socialNetwork", "sn"),
            je = Qt("socialAction", "sa"),
            Ce = Qt("socialTarget", "st"),
            Ae = Qt("l1", "plt"),
            Ne = Qt("l2", "pdt"),
            Ee = Qt("l3", "dns"),
            Ie = Qt("l4", "rrt"),
            Re = Qt("l5", "srt"),
            Le = Qt("l6", "tcp"),
            $e = Qt("l7", "dit"),
            Pe = Qt("l8", "clt"),
            Me = Qt("l9", "_gst"),
            qe = Qt("l10", "_gbt"),
            Ue = Qt("l11", "_cst"),
            De = Qt("l12", "_cbt"),
            Ge = Qt("timingCategory", "utc"),
            Ve = Qt("timingVar", "utv"),
            Fe = Qt("timingLabel", "utl"),
            He = Qt("timingValue", "utt");
        Qt("appName", "an"), Qt("appVersion", "av", ""), Qt("appId", "aid", ""), Qt("appInstallerId", "aiid", ""), Qt("exDescription", "exd"), Qt("exFatal", "exf");
        var Be = Qt("expId", "xid"),
            ze = Qt("expVar", "xvar"),
            Ke = Qt("exp", "exp"),
            Xe = Qt("_utma", "_utma"),
            Ze = Qt("_utmz", "_utmz"),
            We = Qt("_utmht", "_utmht"),
            Ye = Qt("_hc", void 0, 0),
            Je = Qt("_ti", void 0, 0),
            Qe = Qt("_to", void 0, 20);
        te("dimension([0-9]+)", function(t) {
            return new Wt(t[0], "cd" + t[1])
        }), te("metric([0-9]+)", function(t) {
            return new Wt(t[0], "cm" + t[1])
        }), Qt("linkerParam", void 0, void 0, m, ne);
        var tn = ee("_cd2l", void 0, !1),
            en = Qt("usage", "_u"),
            nn = Qt("_um");
        Qt("forceSSL", void 0, void 0, function() {
            return R
        }, function(t, n, r) {
            e(34), R = !!r
        });
        var rn = Qt("_j1", "jid"),
            an = Qt("_j2", "gjid");
        te("\\&(.*)", function(t) {
            var e = new Wt(t[0], t[1]),
                n = Jt(t[0].substring(1));
            return n && (e.Z = function(t) {
                return t.get(n)
            }, e.o = function(t, e, r, a) {
                t.set(n, r, a)
            }, e.F = void 0), e
        });
        var on = ee("_oot"),
            sn = Qt("previewTask"),
            cn = Qt("checkProtocolTask"),
            un = Qt("validationTask"),
            ln = Qt("checkStorageTask"),
            fn = Qt("historyImportTask"),
            gn = Qt("samplerTask"),
            hn = Qt("_rlt"),
            dn = Qt("buildHitTask"),
            pn = Qt("sendHitTask"),
            vn = Qt("ceTask"),
            mn = Qt("devIdTask"),
            wn = Qt("timingTask"),
            bn = Qt("displayFeaturesTask"),
            _n = Qt("customTask"),
            yn = ee("name"),
            kn = ee("clientId", "cid"),
            xn = ee("clientIdTime"),
            On = ee("storedClientId"),
            Sn = Qt("userId", "uid"),
            Tn = ee("trackingId", "tid"),
            jn = ee("cookieName", void 0, "_ga"),
            Cn = ee("cookieDomain"),
            An = ee("cookiePath", void 0, "/"),
            Nn = ee("cookieExpires", void 0, 63072e3),
            En = ee("cookieUpdate", void 0, !0),
            In = ee("cookieFlags", void 0, ""),
            Rn = ee("legacyCookieDomain"),
            Ln = ee("legacyHistoryImport", void 0, !0),
            $n = ee("storage", void 0, "cookie"),
            Pn = ee("allowLinker", void 0, !1),
            Mn = ee("allowAnchor", void 0, !0),
            qn = ee("sampleRate", "sf", 100),
            Un = ee("siteSpeedSampleRate", void 0, 1),
            Dn = ee("alwaysSendReferrer", void 0, !1),
            Gn = ee("_gid", "_gid"),
            Vn = ee("_gcn"),
            Fn = ee("useAmpClientId"),
            Hn = ee("_gclid"),
            Bn = ee("_gt"),
            zn = ee("_ge", void 0, 7776e6),
            Kn = ee("_gclsrc"),
            Xn = ee("storeGac", void 0, !0),
            Zn = Qt("_x_19"),
            Wn = Qt("transportUrl"),
            Yn = Qt("_r", "_r"),
            Jn = Qt("_dp"),
            Qn = Qt("_jt", void 0, "n"),
            tr = Qt("allowAdFeatures", void 0, !0),
            er = Qt("allowAdPersonalizationSignals", void 0, !0),
            nr = function() {
                this.V = 100, this.$ = this.fa = !1, this.oa = "detourexp", this.groups = 1
            },
            rr = function(t) {
                var e, n = new nr;
                if (n.fa && n.$) return 0;
                if (n.$ = !0, t) {
                    if (n.oa && void 0 !== t.get(n.oa)) return zt(t, n.oa);
                    if (0 == t.get(Un)) return 0
                }
                return 0 == n.V ? 0 : (void 0 === e && (e = Ft()), 0 == e % n.V ? Math.floor(e / n.V) % n.groups + 1 : 0)
            },
            ar = function(e) {
                var n = Math.min(zt(e, Un), 100);
                return !(t(Bt(e, kn)) % 100 >= n)
            },
            or = function t(e) {
                var n = {};
                if (ir(n) || sr(n)) {
                    var r = n[Ae];
                    void 0 == r || 1 / 0 == r || isNaN(r) || (0 < r ? (cr(n, Ee), cr(n, Le), cr(n, Re), cr(n, Ne), cr(n, Ie), cr(n, $e), cr(n, Pe), cr(n, Me), cr(n, qe), cr(n, Ue), cr(n, De), ut(function() {
                        e(n)
                    }, 10)) : z(st, "load", function() {
                        t(e)
                    }, !1))
                }
            },
            ir = function(t) {
                var e = st.performance || st.webkitPerformance;
                if (!(e = e && e.timing)) return !1;
                var n = e.navigationStart;
                return 0 != n && (t[Ae] = e.loadEventStart - n, t[Ee] = e.domainLookupEnd - e.domainLookupStart, t[Le] = e.connectEnd - e.connectStart, t[Re] = e.responseStart - e.requestStart, t[Ne] = e.responseEnd - e.responseStart, t[Ie] = e.fetchStart - n, t[$e] = e.domInteractive - n, t[Pe] = e.domContentLoadedEventStart - n, t[Me] = da.L - n, t[qe] = da.ya - n, st.google_tag_manager && st.google_tag_manager._li && (e = st.google_tag_manager._li, t[Ue] = e.cst, t[De] = e.cbt), !0)
            },
            sr = function(t) {
                if (st.top != st) return !1;
                var e = st.external,
                    n = e && e.onloadT;
                return e && !e.isValidLoadTime && (n = void 0), 2147483648 < n && (n = void 0), 0 < n && e.setPageReadyTime(), void 0 != n && (t[Ae] = n, !0)
            },
            cr = function(t, e) {
                var n = t[e];
                (isNaN(n) || 1 / 0 == n || 0 > n) && (t[e] = void 0)
            },
            ur = function(t) {
                return function(e) {
                    if ("pageview" == e.get(ie) && !t.I) {
                        t.I = !0;
                        var n = ar(e),
                            r = 0 < W(Bt(e, ge), "gclid").length;
                        (n || r) && or(function(e) {
                            n && t.send("timing", e), r && t.send("adtiming", e)
                        })
                    }
                }
            },
            lr = !1,
            fr = function(t) {
                if ("cookie" == Bt(t, $n)) {
                    if (t.get(En) || Bt(t, On) != Bt(t, kn)) {
                        var n = 1e3 * zt(t, Nn);
                        gr(t, kn, jn, n)
                    }
                    if ((t.get(En) || hr(t) != Bt(t, Gn)) && gr(t, Gn, Vn, 864e5), t.get(Xn)) {
                        var r = Bt(t, Hn);
                        if (r) {
                            var a = Math.min(zt(t, zn), 1e3 * zt(t, Nn));
                            a = Math.min(a, 1e3 * zt(t, Bn) + a - (new Date).getTime()), t.data.set(zn, a), n = {};
                            var o = Bt(t, Bn),
                                i = Bt(t, Kn),
                                s = kr(Bt(t, An)),
                                c = _r(Bt(t, Cn)),
                                u = Bt(t, Tn);
                            t = Bt(t, In), i && "aw.ds" != i ? n && (n.ua = !0) : (r = ["1", o, pt(r)].join("."), 0 < a && (n && (n.ta = !0), dt("_gac_" + pt(u), r, s, c, u, a, t))), Or(n)
                        }
                    } else e(75)
                }
            },
            gr = function(t, n, r, a) {
                var o = vr(t, n);
                if (o) {
                    r = Bt(t, r);
                    var i = kr(Bt(t, An)),
                        s = _r(Bt(t, Cn)),
                        c = Bt(t, In),
                        u = Bt(t, Tn);
                    if ("auto" != s) dt(r, o, i, s, u, a, c) && (lr = !0);
                    else {
                        e(32);
                        for (var l = yr(), f = 0; f < l.length; f++)
                            if (s = l[f], t.data.set(Cn, s), o = vr(t, n), dt(r, o, i, s, u, a, c)) return void(lr = !0);
                        t.data.set(Cn, "auto")
                    }
                }
            },
            hr = function(t) {
                var e = ht(Bt(t, Vn));
                return mr(t, e)
            },
            dr = function(t) {
                if ("cookie" == Bt(t, $n) && !lr && (fr(t), !lr)) throw "abort"
            },
            pr = function(t) {
                if (t.get(Ln)) {
                    var n = Bt(t, Cn),
                        r = Bt(t, Rn) || Y(),
                        a = p("__utma", r, n);
                    a && (e(19), t.set(We, (new Date).getTime(), !0), t.set(Xe, a.R), (n = p("__utmz", r, n)) && a.hash == n.hash && t.set(Ze, n.R))
                }
            },
            vr = function(t, e) {
                e = pt(Bt(t, e));
                var n = _r(Bt(t, Cn)).split(".").length;
                return t = xr(Bt(t, An)), 1 < t && (n += "-" + t), e ? ["GA1", n, e].join(".") : ""
            },
            mr = function(t, e) {
                return wr(e, Bt(t, Cn), Bt(t, An))
            },
            wr = function(t, n, r) {
                if (!t || 1 > t.length) e(12);
                else {
                    for (var a = [], o = 0; o < t.length; o++) {
                        var i = t[o],
                            s = i.split("."),
                            c = s.shift();
                        ("GA1" == c || "1" == c) && 1 < s.length ? (i = s.shift().split("-"), 1 == i.length && (i[1] = "1"), i[0] *= 1, i[1] *= 1, s = {
                            H: i,
                            s: s.join(".")
                        }) : s = I.test(i) ? {
                            H: [0, 0],
                            s: i
                        } : void 0, s && a.push(s)
                    }
                    if (1 == a.length) return e(13), a[0].s;
                    if (0 != a.length) return e(14), a = br(a, _r(n).split(".").length, 0), 1 == a.length ? a[0].s : (a = br(a, xr(r), 1), 1 < a.length && e(41), a[0] && a[0].s);
                    e(12)
                }
            },
            br = function(t, e, n) {
                for (var r, a = [], o = [], i = 0; i < t.length; i++) {
                    var s = t[i];
                    s.H[n] == e ? a.push(s) : void 0 == r || s.H[n] < r ? (o = [s], r = s.H[n]) : s.H[n] == r && o.push(s)
                }
                return 0 < a.length ? a : o
            },
            _r = function(t) {
                return 0 == t.indexOf(".") ? t.substr(1) : t
            },
            yr = function() {
                var t = [],
                    e = Y().split(".");
                if (4 == e.length) {
                    var n = e[e.length - 1];
                    if (parseInt(n, 10) == n) return ["none"]
                }
                for (n = e.length - 2; 0 <= n; n--) t.push(e.slice(n).join("."));
                return e = ct.location.hostname, mt.test(e) || vt.test(e) || t.push("none"), t
            },
            kr = function(t) {
                return t ? (1 < t.length && t.lastIndexOf("/") == t.length - 1 && (t = t.substr(0, t.length - 1)), 0 != t.indexOf("/") && (t = "/" + t), t) : "/"
            },
            xr = function(t) {
                return t = kr(t), "/" == t ? 1 : t.split("/").length
            },
            Or = function(t) {
                t.ta && e(77), t.na && e(74), t.pa && e(73), t.ua && e(69)
            },
            Sr = new RegExp(/^https?:\/\/([^\/:]+)/),
            Tr = st.google_tag_data.glBridge,
            jr = /(.*)([?&#])(?:_ga=[^&#]*)(?:&?)(.*)/,
            Cr = /(.*)([?&#])(?:_gac=[^&#]*)(?:&?)(.*)/,
            Ar = function(t) {
                e(48), this.target = t, this.T = !1
            };
        Ar.prototype.ca = function(t, e) {
            if (t) {
                if (this.target.get(tn)) return Tr.decorate(k(this.target), t, e);
                if (t.tagName) {
                    if ("a" == t.tagName.toLowerCase()) return void(t.href && (t.href = Nr(this, t.href, e)));
                    if ("form" == t.tagName.toLowerCase()) return Er(this, t)
                }
                if ("string" == typeof t) return Nr(this, t, e)
            }
        };
        var Nr = function(t, e, n) {
                var r = jr.exec(e);
                r && 3 <= r.length && (e = r[1] + (r[3] ? r[2] + r[3] : "")), (r = Cr.exec(e)) && 3 <= r.length && (e = r[1] + (r[3] ? r[2] + r[3] : "")), t = t.target.get("linkerParam");
                var a = e.indexOf("?");
                return r = e.indexOf("#"), n ? e += (-1 == r ? "#" : "&") + t : (n = -1 == a ? "?" : "&", e = -1 == r ? e + (n + t) : e.substring(0, r) + n + t + e.substring(r)), e = e.replace(/&+_ga=/, "&_ga="), e = e.replace(/&+_gac=/, "&_gac=")
            },
            Er = function(t, e) {
                if (e && e.action)
                    if ("get" == e.method.toLowerCase()) {
                        t = t.target.get("linkerParam").split("&");
                        for (var n = 0; n < t.length; n++) {
                            var r = t[n].split("="),
                                a = r[1];
                            r = r[0];
                            for (var o = e.childNodes || [], i = !1, s = 0; s < o.length; s++)
                                if (o[s].name == r) {
                                    o[s].setAttribute("value", a), i = !0;
                                    break
                                }
                            i || (o = ct.createElement("input"), o.setAttribute("type", "hidden"), o.setAttribute("name", r), o.setAttribute("value", a), e.appendChild(o))
                        }
                    } else "post" == e.method.toLowerCase() && (e.action = Nr(t, e.action))
            };
        Ar.prototype.S = function(t, n, r) {
            function a(r) {
                try {
                    r = r || st.event;
                    t: {
                        var a = r.target || r.srcElement;
                        for (r = 100; a && 0 < r;) {
                            if (a.href && a.nodeName.match(/^a(?:rea)?$/i)) {
                                var i = a;
                                break t
                            }
                            a = a.parentNode, r--
                        }
                        i = {}
                    }("http:" == i.protocol || "https:" == i.protocol) && _(t, i.hostname || "") && i.href && (i.href = Nr(o, i.href, n))
                } catch (t) {
                    e(26)
                }
            }
            var o = this;
            this.target.get(tn) ? Tr.auto(function() {
                return k(o.target)
            }, t, n ? "fragment" : "", r) : (this.T || (this.T = !0, z(ct, "mousedown", a, !1), z(ct, "keyup", a, !1)), r && z(ct, "submit", function(e) {
                if (e = e || st.event, (e = e.target || e.srcElement) && e.action) {
                    var n = e.action.match(Sr);
                    n && _(t, n[1]) && Er(o, e)
                }
            }))
        };
        var Ir = /^(GTM|OPT)-[A-Z0-9]+$/,
            Rr = /;_gaexp=[^;]*/g,
            Lr = /;((__utma=)|([^;=]+=GAX?\d+\.))[^;]*/g,
            $r = /^https?:\/\/[\w\-.]+\.google.com(:\d+)?\/optimize\/opt-launch\.html\?.*$/,
            Pr = function(t) {
                function e(t, e) {
                    e && (n += "&" + t + "=" + B(e))
                }
                var n = "https://www.google-analytics.com/gtm/js?id=" + B(t.id);
                return "dataLayer" != t.B && e("l", t.B), e("t", t.target), e("cid", t.clientId), e("cidt", t.ka), e("gac", t.la), e("aip", t.ia), t.sync && e("m", "sync"), e("cycle", t.G), t.qa && e("gclid", t.qa), $r.test(ct.referrer) && e("cb", String(Vt())), n
            },
            Mr = function(t, e, n) {
                this.aa = e, (e = n) || (e = (e = Bt(t, yn)) && "t0" != e ? Hr.test(e) ? "_gat_" + pt(Bt(t, Tn)) : "_gat_" + pt(e) : "_gat"), this.Y = e, this.ra = null
            },
            qr = function(t, n) {
                var r = n.get(dn);
                n.set(dn, function(e) {
                    Ur(t, e, rn), Ur(t, e, an);
                    var n = r(e);
                    return Dr(t, e), n
                });
                var a = n.get(pn);
                n.set(pn, function(n) {
                    var r = a(n);
                    if (Gr(n)) {
                        if (bt() !== Fr(t, n)) {
                            e(80);
                            var o = {
                                U: Vr(t, n, 1),
                                google: Vr(t, n, 2),
                                count: 0
                            };
                            Lt("https://stats.g.doubleclick.net/j/collect", o.U, o)
                        } else F(Vr(t, n, 0));
                        n.set(rn, "", !0)
                    }
                    return r
                })
            },
            Ur = function(t, e, n) {
                !1 === e.get(tr) || e.get(n) || ("1" == ht(t.Y)[0] ? e.set(n, "", !0) : e.set(n, "" + Vt(), !0))
            },
            Dr = function(t, e) {
                Gr(e) && dt(t.Y, "1", Bt(e, An), Bt(e, Cn), Bt(e, Tn), 6e4, Bt(e, In))
            },
            Gr = function(t) {
                return !!t.get(rn) && !1 !== t.get(tr)
            },
            Vr = function(t, e, n) {
                var r = new et,
                    a = function(t) {
                        Yt(t).F && r.set(Yt(t).F, e.get(t))
                    };
                a(re), a(ae), a(Tn), a(kn), a(rn), 0 != n && 1 != n || (a(Sn), a(an), a(Gn)), r.set(Yt(en).F, $(e));
                var o = "";
                return r.map(function(t, e) {
                    o += B(t) + "=", o += B("" + e) + "&"
                }), o += "z=" + Vt(), 0 == n ? o = t.aa + o : 1 == n ? o = "t=dc&aip=1&_r=3&" + o : 2 == n && (o = "t=sr&aip=1&_r=4&slf_rd=1&" + o), o
            },
            Fr = function(t, n) {
                return null === t.ra && (t.ra = 1 === rr(n), t.ra && e(33)), t.ra
            },
            Hr = /^gtm\d+$/,
            Br = function(t, e) {
                if (t = t.b, !t.get("dcLoaded")) {
                    var n = new S(P(t));
                    n.set(29), t.set(nn, n.w), e = e || {};
                    var r;
                    e[jn] && (r = pt(e[jn])), e = new Mr(t, "https://stats.g.doubleclick.net/r/collect?t=dc&aip=1&_r=3&", r), qr(e, t), t.set("dcLoaded", !0)
                }
            },
            zr = function(t) {
                if (!t.get("dcLoaded") && "cookie" == t.get($n)) {
                    var n = new Mr(t);
                    if (Ur(n, t, rn), Ur(n, t, an), Dr(n, t), Gr(t)) {
                        var r = bt() !== Fr(n, t);
                        t.set(Yn, 1, !0), r ? (e(79), t.set(Qn, "d", !0), t.set(Jn, {
                            U: Vr(n, t, 1),
                            google: Vr(n, t, 2),
                            count: 0
                        }, !0)) : t.set(Qn, "b", !0)
                    }
                }
            },
            Kr = function() {
                var t = st.gaGlobal = st.gaGlobal || {};
                return t.hid = t.hid || Vt()
            },
            Xr = /^(UA|YT|MO|GP)-(\d+)-(\d+)$/,
            Zr = function(t) {
                function e(t, e) {
                    h.b.data.set(t, e)
                }

                function r(t, n) {
                    e(t, n), h.filters.add(t)
                }
                var h = this;
                this.b = new Ht, this.filters = new Gt, e(yn, t[yn]), e(Tn, G(t[Tn])), e(jn, t[jn]), e(Cn, t[Cn] || Y()), e(An, t[An]), e(Nn, t[Nn]), e(En, t[En]), e(In, t[In]), e(Rn, t[Rn]), e(Ln, t[Ln]), e(Pn, t[Pn]), e(Mn, t[Mn]), e(qn, t[qn]), e(Un, t[Un]), e(Dn, t[Dn]), e($n, t[$n]), e(Sn, t[Sn]), e(xn, t[xn]), e(Fn, t[Fn]), e(Xn, t[Xn]), e(tn, t[tn]), e(Zn, t[Zn]), e(re, 1), e(ae, "j81"), r(on, a), r(_n, H), r(sn, u), r(cn, o), r(un, f), r(ln, dr), r(fn, pr), r(gn, n), r(hn, g), r(vn, c), r(mn, l), r(bn, zr), r(dn, i), r(pn, s), r(wn, ur(this)), Yr(this.b), Wr(this.b, t[kn]), this.b.set(oe, Kr())
            },
            Wr = function(t, n) {
                var r = Bt(t, jn);
                if (t.data.set(Vn, "_ga" == r ? "_gid" : r + "_gid"), "cookie" == Bt(t, $n)) {
                    if (lr = !1, r = ht(Bt(t, jn)), !(r = mr(t, r))) {
                        r = Bt(t, Cn);
                        var a = Bt(t, Rn) || Y();
                        r = p("__utma", a, r), void 0 != r ? (e(10), r = r.O[1] + "." + r.O[2]) : r = void 0
                    }
                    if (r && (lr = !0), a = r && !t.get(En))
                        if (a = r.split("."), 2 != a.length) a = !1;
                        else if (a = Number(a[1])) {
                        var o = zt(t, Nn);
                        a = a + o < (new Date).getTime() / 1e3
                    } else a = !1;
                    if (a && (r = void 0), r && (t.data.set(On, r), t.data.set(kn, r), (r = hr(t)) && t.data.set(Gn, r)), t.get(Xn) && (r = t.get(Hn), a = t.get(Kn), !r || a && "aw.ds" != a)) {
                        if (r = {}, ct) {
                            a = [], o = ct.cookie.split(";");
                            for (var i = /^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/, s = 0; s < o.length; s++) {
                                var c = o[s].match(i);
                                c && a.push({
                                    ja: c[1],
                                    value: c[2]
                                })
                            }
                            if (o = {}, a && a.length)
                                for (i = 0; i < a.length; i++) s = a[i].value.split("."), "1" != s[0] || 3 != s.length ? r && (r.na = !0) : s[1] && (o[a[i].ja] ? r && (r.pa = !0) : o[a[i].ja] = [], o[a[i].ja].push({
                                    timestamp: s[1],
                                    qa: s[2]
                                }));
                            a = o
                        } else a = {};
                        a = a[Bt(t, Tn)], Or(r), a && 0 != a.length && (r = a[0], t.data.set(Bn, r.timestamp), t.data.set(Hn, r.qa))
                    }
                }
                if (t.get(En) && (r = Z("_ga", !!t.get(Mn)), i = Z("_gl", !!t.get(Mn)), a = Tr.get(t.get(Mn)), o = a._ga, i && 0 < i.indexOf("_ga*") && !o && e(30), i = a.gclid, s = a._gac, r || o || i || s))
                    if (r && o && e(36), t.get(Pn) || Nt(t.get(Fn))) {
                        if (o && (e(38), t.data.set(kn, o), a._gid && (e(51), t.data.set(Gn, a._gid))), i ? (e(82), t.data.set(Hn, i), a.gclsrc && t.data.set(Kn, a.gclsrc)) : s && (a = s.split(".")) && 2 === a.length && (e(37), t.data.set(Hn, a[0]), t.data.set(Bn, a[1])), r) t: if (-1 == (a = r.indexOf("."))) e(22);
                            else {
                                if (o = r.substring(0, a), i = r.substring(a + 1), a = i.indexOf("."), r = i.substring(0, a), i = i.substring(a + 1), "1" == o) {
                                    if (a = i, y(a, r)) {
                                        e(23);
                                        break t
                                    }
                                } else {
                                    if ("2" != o) {
                                        e(22);
                                        break t
                                    }
                                    if (a = i.indexOf("-"), o = "", 0 < a ? (o = i.substring(0, a), a = i.substring(a + 1)) : a = i.substring(1), y(o + a, r)) {
                                        e(53);
                                        break t
                                    }
                                    o && (e(2), t.data.set(Gn, o))
                                }
                                e(11), t.data.set(kn, a), (r = Z("_gac", !!t.get(Mn))) && (r = r.split("."), "1" != r[0] || 4 != r.length ? e(72) : y(r[3], r[1]) ? e(71) : (t.data.set(Hn, r[3]), t.data.set(Bn, r[2]), e(70)))
                            }
                    } else e(21);
                n && (e(9), t.data.set(kn, B(n))), t.get(kn) || ((n = (n = st.gaGlobal && st.gaGlobal.vid) && -1 != n.search(E) ? n : void 0) ? (e(17), t.data.set(kn, n)) : (e(8), t.data.set(kn, V()))), t.get(Gn) || (e(3), t.data.set(Gn, V())), fr(t)
            },
            Yr = function(t) {
                var n = st.navigator,
                    r = st.screen,
                    a = ct.location;
                if (t.set(he, Q(!!t.get(Dn), !!t.get(Fn))), a) {
                    var o = a.pathname || "";
                    "/" != o.charAt(0) && (e(31), o = "/" + o), t.set(ge, a.protocol + "//" + a.hostname + o + a.search)
                }
                r && t.set(we, r.width + "x" + r.height), r && t.set(me, r.colorDepth + "-bit"), r = ct.documentElement;
                var i = (o = ct.body) && o.clientWidth && o.clientHeight,
                    s = [];
                if (r && r.clientWidth && r.clientHeight && ("CSS1Compat" === ct.compatMode || !i) ? s = [r.clientWidth, r.clientHeight] : i && (s = [o.clientWidth, o.clientHeight]), r = 0 >= s[0] || 0 >= s[1] ? "" : s.join("x"), t.set(be, r), t.set(ye, d()), t.set(ve, ct.characterSet || ct.charset), t.set(_e, n && "function" == typeof n.javaEnabled && n.javaEnabled() || !1), t.set(pe, (n && (n.language || n.browserLanguage) || "").toLowerCase()), t.data.set(Hn, Z("gclid", !0)), t.data.set(Kn, Z("gclsrc", !0)), t.data.set(Bn, Math.round((new Date).getTime() / 1e3)), a && t.get(Mn) && (n = ct.location.hash)) {
                    for (n = n.split(/[?&#]+/), a = [], r = 0; r < n.length; ++r)(D(n[r], "utm_id") || D(n[r], "utm_campaign") || D(n[r], "utm_source") || D(n[r], "utm_medium") || D(n[r], "utm_term") || D(n[r], "utm_content") || D(n[r], "gclid") || D(n[r], "dclid") || D(n[r], "gclsrc")) && a.push(n[r]);
                    0 < a.length && (n = "#" + a.join("&"), t.set(ge, t.get(ge) + n))
                }
            };
        Zr.prototype.get = function(t) {
            return this.b.get(t)
        }, Zr.prototype.set = function(t, e) {
            this.b.set(t, e)
        };
        var Jr = {
            pageview: [de],
            event: [ke, xe, Oe, Se],
            social: [Te, je, Ce],
            timing: [Ge, Ve, He, Fe]
        };
        Zr.prototype.send = function(t) {
            if (!(1 > arguments.length)) {
                if ("string" == typeof arguments[0]) var e = arguments[0],
                    n = [].slice.call(arguments, 1);
                else e = arguments[0] && arguments[0][ie], n = arguments;
                e && (n = tt(Jr[e] || [], n), n[ie] = e, this.b.set(n, void 0, !0), this.filters.D(this.b), this.b.data.m = {})
            }
        }, Zr.prototype.ma = function(t, e) {
            var n = this;
            sa(t, n, e) || (ua(t, function() {
                sa(t, n, e)
            }), ca(String(n.get(yn)), t, void 0, e, !0))
        };
        var Qr, ta, ea, na, ra = function(t) {
                return "prerender" != ct.visibilityState && (t(), !0)
            },
            aa = function(t) {
                if (!ra(t)) {
                    e(16);
                    var n = !1;
                    z(ct, "visibilitychange", function e() {
                        if (!n && ra(t)) {
                            n = !0;
                            var r = e,
                                a = ct;
                            a.removeEventListener ? a.removeEventListener("visibilitychange", r, !1) : a.detachEvent && a.detachEvent("onvisibilitychange", r)
                        }
                    })
                }
            },
            oa = /^(?:(\w+)\.)?(?:(\w+):)?(\w+)$/,
            ia = function(t) {
                if (M(t[0])) this.u = t[0];
                else {
                    var e = oa.exec(t[0]);
                    if (null != e && 4 == e.length && (this.c = e[1] || "t0", this.K = e[2] || "", this.methodName = e[3], this.a = [].slice.call(t, 1), this.K || (this.A = "create" == this.methodName, this.i = "require" == this.methodName, this.g = "provide" == this.methodName, this.ba = "remove" == this.methodName), this.i && (3 <= this.a.length ? (this.X = this.a[1], this.W = this.a[2]) : this.a[1] && (U(this.a[1]) ? this.X = this.a[1] : this.W = this.a[1]))), e = t[1], t = t[2], !this.methodName) throw "abort";
                    if (this.i && (!U(e) || "" == e)) throw "abort";
                    if (this.g && (!U(e) || "" == e || !M(t))) throw "abort";
                    if (O(this.c) || O(this.K)) throw "abort";
                    if (this.g && "t0" != this.c) throw "abort"
                }
            };
        Qr = new et, ea = new et, na = new et, ta = {
            ec: 45,
            ecommerce: 46,
            linkid: 47
        };
        var sa = function(t, e, n) {
                e == da || e.get(yn);
                var r = Qr.get(t);
                return !!M(r) && (e.plugins_ = e.plugins_ || new et, !!e.plugins_.get(t) || (e.plugins_.set(t, new r(e, n || {})), !0))
            },
            ca = function(t, n, r, a, o) {
                if (!M(Qr.get(n)) && !ea.get(n)) {
                    if (ta.hasOwnProperty(n) && e(ta[n]), t = da.j(t), Ir.test(n)) {
                        if (e(52), !t) return !0;
                        r = a || {}, a = {
                            id: n,
                            B: r.dataLayer || "dataLayer",
                            ia: !!t.get("anonymizeIp"),
                            sync: o,
                            G: !1
                        }, t.get("&gtm") == n && (a.G = !0);
                        var i = String(t.get("name"));
                        "t0" != i && (a.target = i), gt(String(t.get("trackingId"))) || (a.clientId = String(t.get(kn)), a.ka = Number(t.get(xn)), r = r.palindrome ? Lr : Rr, r = (r = ct.cookie.replace(/^|(; +)/g, ";").match(r)) ? r.sort().join("").substring(1) : void 0, a.la = r, a.qa = W(t.b.get(ge) || "", "gclid")), r = a.B, i = (new Date).getTime(), st[r] = st[r] || [], i = {
                            "gtm.start": i
                        }, o || (i.event = "gtm.js"), st[r].push(i), r = Pr(a)
                    }
                    if (!r && ta.hasOwnProperty(n) ? (e(39), r = n + ".js") : e(43), r) {
                        if (t) {
                            var s = t.get(Zn);
                            U(s) || (s = void 0)
                        }
                        r && 0 <= r.indexOf("/") || (r = (s ? s + "/34" : Et(!1) + "/plugins/ua/") + r), s = ga(r), t = s.protocol, a = ct.location.protocol, ("https:" == t || t == a || ("http:" != t ? 0 : "http:" == a)) && fa(s) && ((s = s.url) && (t = (t = ct.querySelector && ct.querySelector("script[nonce]") || null) ? t.nonce || t.getAttribute && t.getAttribute("nonce") || "" : "", o ? (o = "", t && X.test(t) && (o = ' nonce="' + t + '"'), K.test(s) && ct.write("<script" + o + ' src="' + s + '"><\/script>')) : (o = ct.createElement("script"), o.type = "text/javascript", o.async = !0, o.src = s, t && o.setAttribute("nonce", t), s = ct.getElementsByTagName("script")[0], s.parentNode.insertBefore(o, s))), ea.set(n, !0))
                    }
                }
            },
            ua = function(t, e) {
                var n = na.get(t) || [];
                n.push(e), na.set(t, n)
            },
            la = function(t, e) {
                Qr.set(t, e), e = na.get(t) || [];
                for (var n = 0; n < e.length; n++) e[n]();
                na.set(t, [])
            },
            fa = function(t) {
                var e = ga(ct.location.href);
                return !!D(t.url, "https://www.google-analytics.com/gtm/js?id=") || !(t.query || 0 <= t.url.indexOf("?") || 0 <= t.path.indexOf("://")) && (t.host == e.host && t.port == e.port || (e = "http:" == t.protocol ? 80 : 443, !("www.google-analytics.com" != t.host || (t.port || e) != e || !D(t.path, "/plugins/"))))
            },
            ga = function(t) {
                function e(t) {
                    var e = t.hostname || "",
                        n = 0 <= e.indexOf("]");
                    return e = e.split(n ? "]" : ":")[0].toLowerCase(), n && (e += "]"), n = (t.protocol || "").toLowerCase(), n = 1 * t.port || ("http:" == n ? 80 : "https:" == n ? 443 : ""), t = t.pathname || "", D(t, "/") || (t = "/" + t), [e, "" + n, t]
                }
                var n = ct.createElement("a");
                n.href = ct.location.href;
                var r = (n.protocol || "").toLowerCase(),
                    a = e(n),
                    o = n.search || "",
                    i = r + "//" + a[0] + (a[1] ? ":" + a[1] : "");
                return D(t, "//") ? t = r + t : D(t, "/") ? t = i + t : !t || D(t, "?") ? t = i + a[2] + (t || o) : 0 > t.split("/")[0].indexOf(":") && (t = i + a[2].substring(0, a[2].lastIndexOf("/")) + "/" + t), n.href = t, r = e(n), {
                    protocol: (n.protocol || "").toLowerCase(),
                    host: r[0],
                    port: r[1],
                    path: r[2],
                    query: n.search || "",
                    url: t || ""
                }
            },
            ha = {
                ga: function() {
                    ha.f = []
                }
            };
        ha.ga(), ha.D = function(t) {
            var e = ha.J.apply(ha, arguments);
            for (e = ha.f.concat(e), ha.f = []; 0 < e.length && !ha.v(e[0]) && (e.shift(), !(0 < ha.f.length)););
            ha.f = ha.f.concat(e)
        }, ha.J = function(t) {
            for (var e = [], n = 0; n < arguments.length; n++) try {
                var r = new ia(arguments[n]);
                r.g ? la(r.a[0], r.a[1]) : (r.i && (r.ha = ca(r.c, r.a[0], r.X, r.W)), e.push(r))
            } catch (t) {}
            return e
        }, ha.v = function(t) {
            try {
                if (t.u) t.u.call(st, da.j("t0"));
                else {
                    var e = t.c == N ? da : da.j(t.c);
                    if (t.A) {
                        if ("t0" == t.c && null === (e = da.create.apply(da, t.a))) return !0
                    } else if (t.ba) da.remove(t.c);
                    else if (e)
                        if (t.i) {
                            if (t.ha && (t.ha = ca(t.c, t.a[0], t.X, t.W)), !sa(t.a[0], e, t.W)) return !0
                        } else if (t.K) {
                        var n = t.methodName,
                            r = t.a,
                            a = e.plugins_.get(t.K);
                        a[n].apply(a, r)
                    } else e[t.methodName].apply(e, t.a)
                }
            } catch (t) {}
        };
        var da = function(t) {
            e(1), ha.D.apply(ha, [arguments])
        };
        da.h = {}, da.P = [], da.L = 0, da.ya = 0, da.answer = 42;
        var pa = [Tn, Cn, yn];
        da.create = function(t) {
            var e = tt(pa, [].slice.call(arguments));
            e[yn] || (e[yn] = "t0");
            var n = "" + e[yn];
            if (da.h[n]) return da.h[n];
            if (xt(e)) return null;
            if (e = new Zr(e), da.h[n] = e, da.P.push(e), n = Ut().tracker_created, M(n)) try {
                n(e)
            } catch (t) {}
            return e
        }, da.remove = function(t) {
            for (var e = 0; e < da.P.length; e++)
                if (da.P[e].get(yn) == t) {
                    da.P.splice(e, 1), da.h[t] = null;
                    break
                }
        }, da.j = function(t) {
            return da.h[t]
        }, da.getAll = function() {
            return da.P.slice(0)
        }, da.N = function() {
            "ga" != N && e(49);
            var t = st[N];
            if (!t || 42 != t.answer) {
                da.L = t && t.l, da.ya = 1 * new Date, da.loaded = !0;
                var n = st[N] = da;
                if (h("create", n, n.create), h("remove", n, n.remove), h("getByName", n, n.j, 5), h("getAll", n, n.getAll, 6), n = Zr.prototype, h("get", n, n.get, 7), h("set", n, n.set, 4), h("send", n, n.send), h("requireSync", n, n.ma), n = Ht.prototype, h("get", n, n.get), h("set", n, n.set), "https:" != ct.location.protocol && !R) {
                    t: {
                        n = ct.getElementsByTagName("script");
                        for (var r = 0; r < n.length && 100 > r; r++) {
                            var a = n[r].src;
                            if (a && 0 == a.indexOf(Et(!0) + "/analytics")) {
                                n = !0;
                                break t
                            }
                        }
                        n = !1
                    }
                    n && (R = !0)
                }(st.gaplugins = st.gaplugins || {}).Linker = Ar, n = Ar.prototype, la("linker", Ar), h("decorate", n, n.ca, 20), h("autoLink", n, n.S, 25), la("displayfeatures", Br), la("adfeatures", Br), t = t && t.q, q(t) ? ha.D.apply(da, t) : e(50)
            }
        }, da.da = function() {
            for (var t = da.getAll(), e = 0; e < t.length; e++) t[e].get(yn)
        };
        var va = da.N,
            ma = st[N];
        ma && ma.r ? va() : aa(va), aa(function() {
            ha.D(["provide", "render", H])
        })
    }(window)
}]);