(function(e) {
    function t(n) {
        if (a[n]) return a[n].exports;
        var i = a[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(i.exports, i, i.exports, t), i.l = !0, i.exports
    }
    var n = window.wbchatJsonp;
    window.wbchatJsonp = function(t, a, s) {
        for (var r, l, d = 0, i = []; d < t.length; d++) l = t[d], o[l] && i.push(o[l][0]), o[l] = 0;
        for (r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r]);
        for (n && n(t, a, s); i.length;) i.shift()()
    };
    var a = {},
        o = {
            2: 0
        };
    return t.e = function(e) {
        function n() {
            r.onerror = r.onload = null, clearTimeout(l);
            var t = o[e];
            0 !== t && (t && t[1](new Error("Loading chunk " + e + " failed.")), o[e] = void 0)
        }
        var a = o[e];
        if (0 === a) return new Promise(function(e) {
            e()
        });
        if (a) return a[2];
        var i = new Promise(function(t, n) {
            a = o[e] = [t, n]
        });
        a[2] = i;
        var s = document.getElementsByTagName("head")[0],
            r = document.createElement("script");
        r.type = "text/javascript", r.charset = "utf-8", r.async = !0, r.timeout = 1.2e5, t.nc && r.setAttribute("nonce", t.nc), r.src = t.p + "" + e + ".quikrChat.js";
        var l = setTimeout(n, 1.2e5);
        return r.onerror = r.onload = n, s.appendChild(r), i
    }, t.m = e, t.c = a, t.i = function(e) {
        return e
    }, t.d = function(e, n, a) {
        t.o(e, n) || Object.defineProperty(e, n, {
            configurable: !1,
            enumerable: !0,
            get: a
        })
    }, t.n = function(e) {
        var n = e && e.__esModule ? function() {
            return e["default"]
        } : function() {
            return e
        };
        return t.d(n, "a", n), n
    }, t.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, t.p = "https://teja8.kuikr.com/js/im/", t.oe = function(e) {
        throw console.error(e), e
    }, t(t.s = 47)
})([function(e) {
    "use strict";
    var t = function() {
        var e = {
            layerTicket: {
                NONE: 0,
                CON: 1,
                MOD: 2,
                BL: 3,
                UBL: 4,
                CC: 5,
                GCM: 6
            },
            EventEnum: {
                CONNECTING: 1,
                CONNECTIONFAIL: 2,
                DISCONNECTED: 3,
                AUTHFAIL: 4,
                CONNECTED: 5,
                REGISTER: 6,
                IDLETIMEOUT: 7,
                FORCEDDISCONNECT: 8,
                S_T: 10,
                S_I: 11,
                S_A: 12,
                S_L: 13,
                S_V: 14,
                S_C: 15,
                R_T: 16,
                R_I: 17,
                R_A: 18,
                R_L: 19,
                R_V: 20,
                R_C: 21,
                L_CL: 22,
                L_MIN: 23,
                L_MAX: 24,
                C_CL: 25,
                C_MIN: 26,
                C_MAX: 27,
                C_I: 28,
                REP_S: 31,
                REP_E: 32,
                R_N: 33,
                I_L: 34,
                I_I: 35,
                I_V: 36,
                I_CC: 37,
                Y_CC: 38,
                N_CC: 39,
                I_UB: 40,
                Y_UB: 41,
                N_UB: 42,
                I_BL: 43,
                Y_BL: 44,
                N_BL: 45,
                L_EOP: 46,
                C_EOP: 47,
                S_CAN: 48,
                I_C: 49,
                E_LT: 50,
                E_MO: 51,
                E_WO: 52,
                E_EO: 53,
                E_NO: 54,
                E_AO_B: 55,
                E_AO_S: 56,
                E_MO_Y: 57,
                E_MO_N: 58,
                E_EO_Y: 59,
                E_EO_N: 60,
                E_NO_Y: 61,
                E_NO_N: 62,
                E_MOD_S: 63,
                E_RO: 64,
                E_MP: 65,
                Y_GCM: 66,
                N_GCM: 67,
                R_SM: 68,
                S_D: 69,
                R_D: 70,
                SS_B1C: 71,
                H_ERR: 72,
                L_O: 73,
                C_O: 74,
                SESS_O: 75,
                SESS_MIN: 76,
                LRU_CL: 77,
                R_PM: 78,
                E_API_S: 79,
                CB_CR: 80,
                HIS_PRS: 81,
                L_I_B: 82,
                L_I_F: 83,
                E_CMO: 84,
                E_CMO_Y: 85,
                E_CMO_N: 86,
                M_A: 87,
                C_ID: 88,
                HI: 89,
                CAB_L: 90
            },
            modeEnum: {
                LOGIN: 0,
                REPLY: 1,
                CHATBOX: 2,
                NONE: 3
            },
            uiStatesEnum: {
                OPEN: 0,
                CLOSED: 1,
                MINIMISED: 2,
                POPPEDOUT: 3
            },
            TIMEOUTRECONNECT: -1,
            config: {
                MEM_URL: window.location.protocol + "//" + window.location.host + "/quikchat/?aj=1&chatMemcache=1",
                CLIENT_TAG: "",
                CAPTCHA_URL: window.location.protocol + "//captcha.quikr.com/serve-captcha?",
                PRESENCE_POLL_TIME_INTERVAL: 1,
                VIDEO_DOWNLOAD_URL: window.location.protocol + "//raven.kuikr.com/dwnld/",
                IMAGE_DOWNLOAD_URL: window.location.protocol + "//www.quikr.com/quikchat/?aj=1&downloadMedia=1&mUrl=",
                IMAGE_API_DOMAIN: window.location.protocol + "//raven.kuikr.com/upload2share",
                MAX_IMG_FILE_SIZE: 15728640,
                ALLOWED_IMG_EXT: {
                    jpg: "dc",
                    jpeg: "dc",
                    png: "dc",
                    gif: "dc"
                },
                MAX_VID_FILE_SIZE: 5242880,
                ALLOWED_VID_EXT: {
                    mp4: ""
                },
                LOGIN_TEMPLATE_URL: "/js/chatrelated/templates/register.tpl",
                CHATBOX_TEMPLATE_URL: "/js/chatrelated/templates/chatbox.tpl",
                CHECK_IDLE_TIMEOUT_INTERVAL: 3e4,
                QUICK_CHAT_IDLE_TIMEOUT: 15,
                MAX_NO_OF_CHATS: 3,
                QUIKCHATDOMAIN: "stage-chat.quikr.com",
                QUIKCHATPRESENCEDOMAIN: "",
                QUIKCHATADPRESENCEDOMAIN: "",
                QUIK_CHAT_HISTORY_DOMAIN: "",
                WS_SERVICE: "ws://stage-chat.quikr.com:5290",
                BOSH_SERVICE: window.location.protocol + "//stage-chat.quikr.com:5280",
                SWITCHPROTOCOL: !1,
                AUTO_LOGIN: !1,
                CHATTER_INFO: {},
                HISTORY_CHAT_COUNT: 30,
                ADDETAILS_API_URL: window.location.protocol + "//www.quikr.com/quikchat/?aj=1&getadinfo=1",
                CHAT_CONTAINER: "a",
                ESCROW_CREATE_OFFER_ID: window.location.protocol + "//" + location.host + "/quikchat/?aj=1&getEscrowOfferId=1",
                ESCROW_UPDATE_OFFER_STATUS: window.location.protocol + "//" + location.host + "/quikchat/?aj=1&updateEscrowOfferId=1",
                ESCROW_CONTEXTS: window.location.protocol + "//" + location.host + "/Escrow/UserLatestUpdatesPerAd",
                BYPASS_LOGIN: !1,
                SHOW_GCM: !1,
                GCM_URL: window.location.protocol + "//securestatic.quikr.com?s=1",
                DO_LOG: !1,
                LOG_ENDPOINT: window.location.protocol + "//www.quikr.com/quikchat/?aj=1",
                CLIENT: "d",
                MOBILE_CLIENTS: ["w"],
                MOBILE_CHAT_VOLATILE: !0,
                CONNECTION_RETRY_COUNT: 2,
                PRE_LOAD_TEMPLATES: !1,
                MANDATORY_LOGIN_FIELDS_MAP: {
                    name: !0,
                    email: !0,
                    mobile: !1,
                    message: !0
                },
                MAO_MIN_AMOUNT: 70,
                DEFAULT_CHAT_INPUT: "Type your Message",
                AD_BANNER_URL: window.location.protocol + "//www.quikr.com/quikchat/?aj=1&getAdBanner=1",
                USER_CONFLICT_API: "https://www.quikr.com/ssr-api/core/common/detect-conf"
            }
        };
        return e
    }();
    e.exports = t
}, function(e, t, n) {
    "use strict";
    var a = n(3),
        i = n(0).uiStatesEnum,
        o = n(7),
        s = n(6);
    e.exports = {
        sendAck: !1,
        msg: null,
        handleIncomingMessage: function(e, t) {
            e.attachDateToast(a.getToastMsgTimestamp(this.msg.stime), this.template.dateToast), e.uiState == i.CLOSED && e.showNotification(this.msg.text, this.msg.stime, this.msg.id, this.type), e.checkMessageDisplayed(this.msg.id) || this.attachIncomingMessageTemplate(this.msg.text, e, t), e.scrollToBottom(), e.lastIncomingMessage = this.msg, o.setMessage({
                adId: e.adDetails.getInfo().adId,
                buddy: e.chatee.getInfo().jid,
                owner: s.jid,
                msg: {
                    id: this.msg.id,
                    time: this.msg.stime,
                    direction: 0,
                    msg: this.msg.text,
                    metadata: null
                }
            })
        },
        handleHistoryMessage: function(e, t) {
            var n = !1;
            "" != this.msg.text && (1 == this.msg.direction ? (this.attachOutgoingMessageTemplate(this.msg.text, e, t, !0), n = !0) : this.attachIncomingMessageTemplate(this.msg.text, e, t, !0), n && (e.setMessageAcknowledgment("sent", this.msg.stime, this.msg.id), n = !1))
        },
        handleOutgoingMessage: function(e, t) {
            e.attachDateToast(a.getToastMsgTimestamp(this.msg.stime), this.template.dateToast), this.attachOutgoingMessageTemplate(this.msg.message, e, t), e.setMessageAcknowledgment("sending", this.msg.stime, this.msg.id), e.scrollToBottom(), o.setMessage({
                adId: e.adDetails.getInfo().adId,
                buddy: e.chatee.getInfo().jid,
                owner: s.jid,
                msg: {
                    id: this.msg.id,
                    time: this.msg.stime,
                    direction: 1,
                    msg: this.msg.message,
                    metadata: null
                }
            })
        },
        shouldSendSeenAck: function(e) {
            return this.sendAck && e.uiState == i.OPEN
        },
        config: function(e, t) {
            this.msg = e, this.template = t
        },
        attachOutgoingMessageTemplate: function(e, t, n, i) {
            if ("undefined" == typeof i) var i = !1;
            return "undefined" == typeof n ? void t.displayChatMessage(e, this.msg.stime, this.msg.id, this.template["outgoing" + a.capitalizeFirstLetter(this.type) + "Message"], this.type, i) : void t.attachMessage(n, i)
        },
        attachIncomingMessageTemplate: function(e, t, n, i) {
            if ("undefined" == typeof i) var i = !1;
            return "undefined" == typeof n ? void t.displayChatMessage(e, this.msg.stime, this.msg.id, this.template["incoming" + a.capitalizeFirstLetter(this.type) + "Message"], this.type, i) : void t.attachMessage(n, i)
        }
    }
}, function(e, t, n) {
    "use strict";
    var a = function() {
        var e = n(25),
            t = [];
        return {
            addCustomHandler: function(n, a, i, o) {
                var s = new e(n, a, i, o);
                return t.push(s), s
            },
            invokeHandlers: function(e, n) {
                var a;
                for (a = 0; a < t.length; a++) {
                    var i = t[a];
                    if (i.eventName == e) {
                        var o = i.run(n);
                        o && (t.splice(a, 1), a--)
                    }
                }
            }
        }
    }();
    e.exports = a
}, function(e, t, n) {
    "use strict";
    var a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        },
        i = n(0),
        o = n(8),
        s = {
            extend: function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
            },
            isMobile: function() {
                return !!(-1 < i.config.MOBILE_CLIENTS.indexOf(i.config.CLIENT))
            },
            isUndefined: function(e) {
                return !("undefined" != typeof e)
            },
            closestParent: function(e, t) {
                var n = t.substring(1);
                if (e.hasClass(n)) return !0
            },
            errorAlert: function(e) {
                if ("selfchat" == e) return void alert("Now why would you want to talk to yourself?")
            },
            removeElement: function(e) {
                e.parentElement.removeChild(e)
            },
            capitalizeFirstLetter: function(e) {
                return e.charAt(0).toUpperCase() + e.slice(1)
            },
            onMediaClick: function(e, t, n) {
                var a, r = s.queryOne(o.dl_link, e);
                r || (a = "image" == n ? i.config.IMAGE_DOWNLOAD_URL + encodeURIComponent(t) : "video" == n ? i.config.VIDEO_DOWNLOAD_URL + t.replace(/^https?:\/\/teja\d.kuikr.com\//, "") : t, r = s.createDLLink(a, o.dl_link.substring(1), n), e.appendChild(r)), r.click()
            },
            clearIntervals: function(e) {
                isNaN(e) || clearInterval(e)
            },
            toggleDisplay: function(e, t) {
                e && ("off" == t ? e.style.display = "none" : "on" == t ? e.style.display = "block" : !t && (e.style.display = "none" == e.style.display ? "inline-block" : "none"))
            },
            getMsgTimestamp: function(e) {
                var t;
                !e || isNaN(e) ? t = new Date : (13 > e.length && (e *= 1e3), t = new Date(parseInt(e, 10)));
                var n = s.getTwoDigitFormat(t.getHours()),
                    a = s.getTwoDigitFormat(t.getMinutes());
                return n + ":" + a
            },
            getTime: function() {
                var e = new Date;
                return e.getTime()
            },
            insertAfter: function(e, t) {
                t.parentNode.insertBefore(e, t.nextSibling)
            },
            getToastMsgTimestamp: function(e) {
                var t;
                return !e || isNaN(e) ? t = new Date : (e = e.toString(), 13 > e.length && (e *= 1e3), t = new Date(parseInt(e, 10))), t.toDateString()
            },
            truncateString: function(e, t, n) {
                var a = "";
                if (e) return (t || (t = 20), "/" == n && n ? "/" == n && (n = "") : n = "...", "" == e.trim()) ? a : (a = e.length >= t ? e.substring(0, t) + n : e, a)
            },
            getTwoDigitFormat: function(e) {
                return ("0" + e).slice(-2)
            },
            textLinkify: function(e) {
                if (this.isBlankString(e)) return "";
                var t = /((http:\/\/|https:\/\/)?(www.)?(([a-zA-Z0-9-]){2,}\.){1,4}(com|org|edu|gov|net|int|mil|([a-z]{2})\b)(\/([a-zA-Z-_\/\.0-9#:?=&;,!@#\$%\^\&*\]\[\)\(+=._-]*)?)?)/ig,
                    n = e.match(t);
                return "undefined" != typeof n && null != n && (0 > n[0].indexOf("http://") && 0 > n[0].indexOf("https://") ? e = e.replace(t, "<a target='_blank' href='http://$1'>$1</a>") : e = e.replace(t, "<a target='_blank' href='$1'>$1</a>")), e
            },
            getNthChild: function(e, t) {
                return e ? e.children[t] : null
            },
            queryOne: function(e, t) {
                return this.isBlankString(e) ? null : (t || (t = document), t.querySelector(e))
            },
            queryAll: function(e, t) {
                t || (t = document);
                var n = e.match(/^#([\w-]*)$/),
                    a = !n && e.match(/^\.([\w-]+)$/),
                    i = !a && e.match(/^[\w-]+$/);
                if (n) {
                    var o = t.getElementById(n[1]);
                    return o ? [o] : []
                }
                if (a) {
                    if (this.hasClass(t, a[1])) return t;
                    var s = t.getElementsByClassName(a[1]);
                    return this.toArray(s)
                }
                if (i) {
                    var s = t.getElementsByTagName(e);
                    return this.toArray(s)
                }
                return this.toArray(t.querySelectorAll(e))
            },
            objectToArray: function(e) {
                return Object.keys(e).map(function(t) {
                    return e[t]
                })
            },
            toArray: function(e, t) {
                return Array.prototype.slice.call(e, t)
            },
            deDupArray: function(e) {
                for (var t = {}, n = 0; n < e.length; n++) t[e[n]] = !0;
                var a = [];
                for (var i in t) a.push(i);
                return a
            },
            prepend: function(e, t) {
                e && e.insertBefore(t, e.firstChild)
            },
            hasClass: function(e, t) {
                return -1 < (" " + e.className + " ").indexOf(" " + t + " ")
            },
            addClass: function(e, t) {
                e.classList ? e.classList.add(t) : e.className += " " + t
            },
            removeClass: function(e, t) {
                e.classList ? e.classList.remove(t) : e.className = e.className.replace(new RegExp(t, "g"), "")
            },
            isBlankString: function(e) {
                return void 0 == e || null == e || "" === e || "undefined" == e
            },
            isEmpty: function(e) {
                return 0 === Object.keys(e).length
            },
            ajaxGet: function(e, t, n) {
                var a = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
                return n = "undefined" == typeof n || n, a.open("GET", e, n), a.onreadystatechange = function() {
                    3 < a.readyState && (200 === a.status || 202 === a.status) && t.success && t.success(a.responseText), 3 < a.readyState && 500 === a.status && t.error(a.responseText)
                }, a.setRequestHeader("X-Quikr-Client", i.config.CLIENT_TAG), a.send(), a
            },
            ajaxUpload: function(e, t, n, i) {
                var o = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
                return o.upload && (o.upload.onprogress = function(t) {
                    var e, a = t.loaded,
                        i = t.total;
                    e = 0 == a ? "0%" : Math.floor(1e3 * (a / i)) / 10 + "%", n.uploadProgress && n.uploadProgress(t, a, i, e)
                }), i = void 0 == ("undefined" == typeof i ? "undefined" : a(i)) || i, o.open("POST", e, i), o.onreadystatechange = function() {
                    3 < o.readyState && 200 === o.status && n.success(o.responseText), 3 < o.readyState && !o.status && n.timeout(o.responseText), 3 < o.readyState && 500 === o.status && n.error(o.responseText)
                }, o.send(t), o
            },
            ajaxPost: function(e, t, n, a, i, o, s) {
                var r = "string" == typeof t ? t : Object.keys(t).map(function(e) {
                        return encodeURIComponent(e) + "=" + encodeURIComponent(t[e])
                    }).join("&"),
                    l = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
                if (i && l.upload.addEventListener("progress", function(t) {
                        i(t)
                    }, !1), a = "undefined" == typeof a || a, l.open("POST", e, a), l.onreadystatechange = function() {
                        3 < l.readyState && 200 === l.status && n.success && n.success(l.responseText), 3 < l.readyState && 200 != l.status && n.error && n.error(l.responseText)
                    }, o ? l.setRequestHeader("Content-Type", o) : l.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), s)
                    for (var d in s) l.setRequestHeader(d, s[d]);
                return l.send(r), l
            },
            forEachElement: function(e, t, n) {
                for (var a = 0; a < e.length; a++) t.call(n, a, e[a])
            },
            _addListener: function(e, t, n) {
                "function" == typeof window.addEventListener ? e.addEventListener(t, n, !1) : "function" == typeof document.attachEvent ? e.attachEvent("on", t, n) : e["on" + t] = n
            },
            addListener: function(e, t, n) {
                e instanceof Array ? e.forEach(function(e) {
                    e && s._addListener(e, t, n)
                }) : e && s._addListener(e, t, n)
            },
            removeListener: function(e, t, n) {
                "function" == typeof window.addEventListener ? e.removeEventListener(t, n, !1) : "function" == typeof document.attachEvent ? e.detachEvent("on", t, n) : e["on" + t] = null
            },
            validateContactForm: function(e, t, n) {
                var a = {
                    code: 1,
                    errorField: "",
                    errorMessage: ""
                };
                if ("Name" == e || "" == e) return a.code = 0, a.errorField = "name", a.errorMessage = "Please Enter Your Name", a;
                if (t = t.replace(/(^\s*)|(\s*$)/g, ""), "Mobile" != t && (isNaN(t) || 0 != t.length && (10 > t.length || 10 < t.length) || 0 != t.length && "9" != t.substr(0, 1) && "8" != t.substr(0, 1) && "7" != t.substr(0, 1) && "6" != t.substr(0, 1))) return a.code = 0, a.errorField = "mobile", a.errorMessage = "Please Enter Valid Phone Number", a;
                var i = new RegExp(/^[_a-zA-Z0-9\-]+(\.[_a-zA-Z0-9\-]*)*@[a-zA-Z0-9\-]+([\.][a-zA-Z0-9\-]+)+$/);
                return "" != n && "Email" != n && i.test(n) ? a : (a.code = 0, a.errorField = "email", a.errorMessage = "Please Enter Valid Email", a)
            },
            validateLoginForm: function(e, t, n, a) {
                var o = {
                    code: 1,
                    errorField: "",
                    errorMessage: ""
                };
                if ("Name" == e || "" == e) return o.code = 0, o.errorField = "name", o.errorMessage = "Please Enter Your Name", o;
                if (t = t.replace(/(^\s*)|(\s*$)/g, ""), "Mobile" != t || i.config.MANDATORY_LOGIN_FIELDS_MAP.mobile) {
                    if (isNaN(t) || 0 != t.length && (10 > t.length || 10 < t.length) || 0 != t.length && "9" != t.substr(0, 1) && "8" != t.substr(0, 1) && "7" != t.substr(0, 1) && "6" != t.substr(0, 1)) return o.code = 0, o.errorField = "mobile", o.errorMessage = "Please Enter Valid Phone Number", o;
                    if (i.config.MANDATORY_LOGIN_FIELDS_MAP.mobile && 0 == t.length) return o.code = 0, o.errorField = "mobile", o.errorMessage = "Please Enter Phone Number", o
                }
                var s = new RegExp(/^[_a-zA-Z0-9\-]+(\.[_a-zA-Z0-9\-]*)*@[a-zA-Z0-9\-]+([\.][a-zA-Z0-9\-]+)+$/);
                return "" != n && "Email" != n && "donotreply@quikr.com" != n && "noreply@quikr.com" != n && s.test(n) ? i.config.MANDATORY_LOGIN_FIELDS_MAP.message && ("Type Your Question Here" == a || "" == a) ? (o.code = 0, o.errorField = "question", o.errorMessage = "Please Type Your Question", o) : o : (o.code = 0, o.errorField = "email", o.errorMessage = "Please Enter Valid Email", o)
            },
            parseContactMessage: function(e) {
                var t, n = {},
                    a = e.split(",");
                for (var i in a) t = a[i].split(":"), n[t[0].trim()] = t[1].trim();
                return n
            },
            createDLLink: function(e, t, n) {
                if (e) {
                    var a = document.createElement("a");
                    return a.setAttribute("href", e), a.setAttribute("class", t), "document" == n ? a.setAttribute("target", "_blank") : "view" == n ? a.setAttribute("target", "_blank") : a.setAttribute("download", ""), a
                }
                return !1
            },
            validateMediaUpload: function(e, t, n, a, i) {
                var o = {};
                return o.code = 1, n > a && (o.code = 0, o.errorField = "size", o.errorMessage = "Filesize must be " + this.formatFileSize(a) + " or below"), i.hasOwnProperty(t) || (o.code = 0, o.errorField = "extension", o.errorMessage = "File must be " + Object.keys(i).join(" / ") + " format"), o
            },
            formatFileSize: function(e) {
                for (var t, n, a = 0; 0 < parseInt(e / 1024);) a++, t = e % 1024, e /= 1024;
                switch (t = parseInt(t / 100), a) {
                    case 1:
                        n = " KB";
                        break;
                    case 2:
                        n = " MB";
                        break;
                    case 3:
                        n = " GB";
                        break;
                    default:
                        n = " B";
                }
                return 0 < t ? parseInt(e) + "." + t + n : parseInt(e) + n
            },
            removeDivEditableLines: function(e) {
                return e.replace(/<div><br><\/div>|<div><br\/><\/div>|<br>|<br\/>/g, "")
            },
            preventDefault: function(t) {
                var e = t ? t : window.event;
                return e.preventDefault && e.preventDefault(), e.returnValue = !1, !1
            },
            stopEventPropogation: function(e) {
                return s.isUndefined(e) || null == e || (s.isUndefined(e.stopPropagation) ? (e || window.event).cancelBubble = !0 : e.stopPropagation()), !0
            },
            B64encode: function(e) {
                return Base64.encode(e)
            },
            B64decode: function(e) {
                return Base64.decode(e)
            },
            isObject: function(e) {
                return "object" == ("undefined" == typeof e ? "undefined" : a(e))
            },
            mergeObject: function(e, t) {
                for (var n in t) e[n] = t[n];
                return e
            },
            isWSService: function(e) {
                return !this.isBlankString(e) && (0 === e.indexOf("ws:") || 0 === e.indexOf("wss:"))
            },
            isBoshService: function(e) {
                return !this.isBlankString(e) && (0 === e.indexOf("http:") || 0 === e.indexOf("https:"))
            },
            saveChatStateRequired: function() {
                return s.isMobile() && (!s.isMobile() || i.config.MOBILE_CHAT_VOLATILE) ? !1 : !0
            }
        };
    e.exports = s
}, function(e, t, n) {
    "use strict";
    var a = function() {
        function e(e, t) {
            for (var n = v.config.AD_BANNER_URL, a = document.querySelectorAll(".promo-banner"), o = a.length - 1; 0 <= o; o--) 0 != a[o].children.length && (i = 0);
            var i = 1;
            i && M.ajaxPost(n, {
                adId: e
            }, {
                success: function(e) {
                    if (e && "null" != e)
                        for (var n = document.querySelectorAll(".promo-banner"), a = n.length - 1; 0 <= a; a--) - 1 < n[a].innerHTML.indexOf("img") || (n[a].innerHTML += e, R.invokeHandlers(v.EventEnum.CAB_L, {
                            container: t
                        }))
                },
                error: function() {}
            })
        }

        function t(e, t) {
            var n = [];
            if ("email" == t)
                for (var a in U) U[a].chatee.getEmail() == e && n.push(U[a]);
            else if ("ui" == t)
                for (var a in U) U[a].uiState == e && n.push(U[a]);
            else if ("email&adId" == t)
                for (var a in U) U[a].chatee.getEmail() == e.email && U[a].adDetails.adDetails.adId == e.adId && n.push(U[a]);
            else
                for (var a in U) n.push(U[a]);
            return n
        }

        function i(e, t, n) {
            var a = t.adDetails.getInfo().adId,
                i = t.chatee.getInfo().jid,
                s = x.jid;
            w.manipulateHistory({
                type: e,
                adId: a,
                buddyJid: i,
                ownerJid: s,
                count: v.config.HISTORY_CHAT_COUNT,
                timestampOffset: t.lastMessageFromHistoryTS,
                page: n,
                callback: {
                    success: function(r) {
                        try {
                            var r = JSON.parse(r)
                        } catch (n) {
                            var r = w.jumpStartHistory({
                                adId: a,
                                ad: t.adDetails.getInfo(),
                                buddy: t.chatee.getInfo().jid,
                                owner: x.jid
                            })
                        }
                        return M.isBlankString(r) || "Error" == r || "8221" == r.status ? "" : void(r.status && "ok" == r.status && M.isEmpty(r.data) && "delete" == e ? (w.deleteMessages({
                            adId: a,
                            ad: t.adDetails.getInfo(),
                            buddy: t.chatee.getInfo().jid,
                            owner: x.jid
                        }), t.clearConversation("on")) : r.status && "ok" == r.status && !M.isEmpty(r.data) && "undefined" != typeof r.data[a] && r.data[a].conver[0] && 0 < r.data[a].conver[0].messages.length && (w.setHistory(w.getHistoryKey({
                            adId: a,
                            buddy: i,
                            owner: s
                        }), r), o(r, t, a, n, i)), R.invokeHandlers(v.EventEnum.HIS_PRS, {
                            status: !0
                        }))
                    },
                    error: function() {
                        R.invokeHandlers(v.EventEnum.HIS_PRS, {
                            status: !1
                        }), R.invokeHandlers(v.EventEnum.HI, {
                            chatbox: t
                        })
                    }
                }
            })
        }

        function o(e, t, n, a, o) {
            e.data[n].conver[0].vcard && t.setVcard(e.data[n].conver[0].vcard);
            for (var s, r, l = e.data[n].conver[0].messages, d = "", c = !1, g = 0; g < l.length; g++) {
                r = {}, r.text = l[g].msg, r.stime = l[g].time, r.id = l[g].id, r.direction = l[g].direction, r.filesize = l[g].filesize, r.duration = l[g].duration, r.metadata = l[g].metadata, r.type = "chat", c || 0 != r.direction || (s = r, c = !0), g == l.length - 1 && (t.lastMessageFromHistoryTS = r.stime);
                var i = M.getToastMsgTimestamp(r.stime);
                d != i && (g ? t.attachDateToast(d, j.dateToast, !0) : t.removeDateToast(i), d = i);
                var m = N(r, j);
                "" != m.msg.text && m.handleHistoryMessage(t)
            }
            t.attachDateToast(d, j.dateToast, !0), !a && t.uiState == v.uiStatesEnum.OPEN && s && A.sendMessageAck("seen", {
                to: o,
                adId: n,
                stime: s.stime,
                id: s.id
            }), s && (t.lastIncomingMessage = {}, t.lastIncomingMessage.from = o, t.lastIncomingMessage.adId = n, t.lastIncomingMessage.stime = s.stime, t.lastIncomingMessage.id = s.id), l.length == v.config.HISTORY_CHAT_COUNT ? t.toggleLoadMore(j.loadMoreToast, "on") : a && t.toggleLoadMore(j.loadMoreToast, "off");
            var u = e.data[n].conver[0].escrowDetails;
            t.historyDetails = u, R.invokeHandlers(v.EventEnum.HI, {
                chatbox: t
            });
            var p, _ = e.data[n].adDetails;
            if (_ && (p = _.attribute_sold), 269 != t.adDetails.getInfo().category_pgid && 247 != t.adDetails.getInfo().category_pgid && 40 != t.adDetails.getInfo().category_pgid && t.adDetails.isInactive()) {
                t.toggleInactiveAd("on");
                var f = document.getElementsByClassName("ChatAd-DetailsArea");
                if (f)
                    for (var g = 0; g < f.length; g++) f[g].classList.add("inacitvedisable")
            }
        }

        function s(e) {
            if (!e) return !0;
            for (var t in U) e.to = U[t].chatee.getInfo().jid, e.adid = U[t].chatee.getInfo().adid, A.sendMessage(e)
        }

        function r(e, t) {
            var n = "";
            "login" === e ? n = v.config.LOGIN_TEMPLATE_URL : "chatbox" === e ? n = v.config.CHATBOX_TEMPLATE_URL : void 0;
            M.ajaxGet(n, {
                success: function(n) {
                    l(n, e), t && t()
                },
                error: function() {}
            })
        }

        function l(e, t) {
            var n = document.createElement("div");
            if (n.innerHTML = e, "chatbox" == t) {
                var i = ">:first-child";
                j.incomingTextMessage = M.queryOne(k.it + i, n), j.outgoingTextMessage = M.queryOne(k.ot + i, n), j.incomingContactMessage = M.queryOne(k.ic + i, n), j.outgoingContactMessage = M.queryOne(k.oc + i, n), j.incomingImageMessage = M.queryOne(k.ii + i, n), j.outgoingImageMessage = M.queryOne(k.oi + i, n), j.incomingVideoMessage = M.queryOne(k.iv + i, n), j.outgoingVideoMessage = M.queryOne(k.ov + i, n), j.incomingDocumentMessage = M.queryOne(k.id + i, n), j.outgoingDocumentMessage = M.queryOne(k.od + i, n), j.incomingLocationMessage = M.queryOne(k.il + i, n), j.outgoingLocationMessage = M.queryOne(k.ol + i, n), j.incomingEscrowMessage = M.queryOne(k.ie + i, n), j.outgoingEscrowMessage = M.queryOne(k.oe + i, n), j.incomingServerMessage = M.queryOne(k.ism + i, n), j.outgoingServerMessage = M.queryOne(k.osm + i, n), j.incomingPromoMessage = M.queryOne(k.ipm + i, n), j.loadMoreToast = M.queryOne(k.lmtst + i, n), j.dateToast = M.queryOne(k.dtst + i, n), j.uploadBar_i = M.queryOne(k.upprog_i + i, n), j.uploadBar_v = M.queryOne(k.upprog_v + i, n), j.cannedResponse = M.queryOne(k.cnr, n), j.textPlaceholder = M.queryOne(k.st_i, n).innerHTML.trim(), j.cannedResponse.style.display = "inline-block";
                var o = document.createElement("input");
                o.setAttribute("type", "file"), o.setAttribute("style", "display:none;"), o.setAttribute("name", "object"), o.setAttribute("class", "object");
                var s = document.createElement("input");
                s.setAttribute("type", "file"), s.setAttribute("style", "display:none;"), s.setAttribute("name", "objectVideo"), s.setAttribute("class", "objectVideo");
                var r = M.getNthChild(n, 0);
                r.appendChild(o), r.appendChild(s), j.chatbox = r
            } else "login" == t && (j.loginform = M.getNthChild(n, 0));
            j.scriptsLoaded || (M.queryAll("script", n).forEach(function(e) {
                M.queryOne("body", document).appendChild(e)
            }), j.scriptsLoaded = !0)
        }

        function d(e) {
            if (!M.isUndefined(e)) {
                var t = e.chatee,
                    n = e.adDetails,
                    a = e.chatterInfo;
                (!a || M.isBlankString(a.name) || M.isBlankString(a.email) || M.isBlankString(a.mobile)) && (a = new q(x.name, x.mobile, x.email));
                var i = new L(t, n, a),
                    o = document.createElement("div");
                return o.id = t.getWindowIdentifier(), o.style.display = "none", document.getElementById(v.config.CHAT_CONTAINER).appendChild(o), i.htmlContainer = o, i
            }
        }

        function c(e, t) {
            var n = e.htmlContainer;
            if ("login" == t) {
                var o = j.loginform;
                n.appendChild(o.cloneNode(!0));
                var s = e.chatterInfo;
                if (s) {
                    var r;
                    (r = M.queryOne(k.ip_n, n)) && (r.value = s.name), (r = M.queryOne(k.ip_m, n)) && (r.value = s.mobile), (r = M.queryOne(k.ip_e, n)) && (r.value = s.email)
                }
                R.invokeHandlers(v.EventEnum.L_EOP, {
                    chatdom: e.htmlContainer
                }), n.style.display = "block"
            } else if ("chat" == t) {
                if (0 < n.children.length) return;
                n.appendChild(j.chatbox.cloneNode(!0)), M.queryAll(k.ct, n).forEach(function(t) {
                    var n, a = e.adDetails.getInfo().adOwnerName;
                    n = e.isPoster() || M.isBlankString(a) ? e.chatee.getInfo().email : a, n = n.replace(/\./g, ""), t.innerHTML = M.isBlankString(n) ? "Quikr User" : -1 < n.indexOf("@") ? n.substr(0, n.indexOf("@")) : n
                }), M.queryAll(k.ad_t, n).forEach(function(t) {
                    t.innerHTML = "<span class=\"titleChat\">" + M.truncateString(e.adDetails.getInfo().adTitle, 120) + "</span>"
                }), M.queryAll(k.ad_p, n).forEach(function(t) {
                    t.innerHTML = e.adDetails.getInfo().adPrice
                }), M.queryAll(k.ad_d, n).forEach(function(t) {
                    t.innerHTML = e.adDetails.getInfo().lastUpdatedTime
                }), e.adDetails.getInfo().adImage ? M.queryAll(k.ad_i, n).forEach(function(t) {
                    t.setAttribute("src", e.adDetails.getInfo().adImage)
                }) : (M.queryAll(k.ad_i, n).forEach(function(e) {
                    M.toggleDisplay(e, "off")
                }), M.queryAll(k.ad_n_i, n).forEach(function(e) {
                    M.toggleDisplay(e, "on")
                })), M.queryAll(k.ad_l, n).forEach(function(t) {
                    t.setAttribute("href", e.adDetails.getInfo().adLink)
                });
                var a = M.queryOne(k.boxes.conbox, e.htmlContainer);
                a && (M.queryOne(k.ip_c_n, a) && (M.queryOne(k.ip_c_n, a).value = x.name), M.queryOne(k.ip_c_m, a) && (M.queryOne(k.ip_c_m, a).value = x.mobile), M.queryOne(k.ip_c_e, a) && (M.queryOne(k.ip_c_e, a).value = x.email));
                var l = M.queryOne(k.cna, n),
                    d = e.adDetails.getInfo().cannedResponses;
                if (!M.isUndefined(d)) {
                    var c = e.isPoster() ? d.poster ? d.poster : [] : d.seeker ? d.seeker : [];
                    c.forEach(function(e) {
                        var t = j.cannedResponse.cloneNode(!0);
                        t.id = e.id, M.queryOne(k.cno, t).innerHTML = e.msg, l.appendChild(t)
                    })
                }
                v.config.SHOW_GCM && (M.queryOne(k.o_gcm_y, e.htmlContainer).href = v.config.GCM_URL, M.queryOne(k.boxes.gcmbox, e.htmlContainer).style.display = "block"), x.fetchHistory ? (R.addCustomHandler(function() {
                    R.invokeHandlers(v.EventEnum.C_EOP, {
                        chatdom: e.htmlContainer,
                        qEmail: x.email
                    })
                }, v.EventEnum.HIS_PRS, null, !0), i("get", e)) : R.invokeHandlers(v.EventEnum.C_EOP, {
                    chatdom: e.htmlContainer,
                    qEmail: x.email
                })
            }
        }

        function g(e, t) {
            var n = e.htmlContainer;
            if ("login" == t) {
                var o = function(e, t) {
                        M.addListener(M.queryOne(e, n), "blur", function(e) {
                            R.invokeHandlers(v.EventEnum.L_I_B, {
                                type: t,
                                element: e.target
                            })
                        })
                    },
                    s = function(e, t) {
                        M.addListener(M.queryOne(e, n), "focus", function(a) {
                            M.removeClass(M.queryOne(e, n), "field-error"), R.invokeHandlers(v.EventEnum.L_I_F, {
                                type: t,
                                element: a.target
                            })
                        })
                    };
                M.addListener(M.queryOne(k.ip_l, n), "click", function(t) {
                    var n = e.loginUser(t);
                    1 == n.code && B.detectConflicts(n).then(function(t) {
                        if (t) B.rediectLogin();
                        else {
                            if (R.invokeHandlers(v.EventEnum.C_I, {
                                    adDetails: e.adDetails.getInfo(),
                                    chatter: {
                                        name: n.name,
                                        mobile: n.mobile,
                                        email: n.email
                                    },
                                    isSeller: !!("function" == typeof e.isSeller && e.isSeller())
                                }), e.chatterInfo = new q(n.name, n.mobile, n.email), e.isPoster()) return void M.errorAlert("selfchat");
                            x.isLoggedIn || (R.addCustomHandler(a.initChat.bind(null, {
                                sendVcard: !0,
                                chatee: {
                                    chatee: e.chatee.getInfo()
                                },
                                chatterInfo: e.chatterInfo,
                                adDetails: {
                                    adDetails: e.adDetails.getInfo()
                                },
                                loginInit: !0
                            }), v.EventEnum.CONNECTED, null, !0), R.addCustomHandler(function() {
                                var t = e.getTextMessage(null, n.message, j.textPlaceholder);
                                t && A.sendMessage(t), e.attachDateToast(M.getToastMsgTimestamp(t.stime), j.dateToast), e.displayChatMessage(t.message, t.stime, t.id, j.outgoingTextMessage, "text"), e.setMessageAcknowledgment("sent", t.stime, t.id), w.setMessage({
                                    adId: e.adDetails.getInfo().adId,
                                    buddy: e.chatee.getInfo().jid,
                                    owner: x.jid,
                                    msg: {
                                        id: t.id,
                                        time: t.stime,
                                        direction: 1,
                                        msg: t.message,
                                        metadata: null
                                    }
                                })
                            }, v.EventEnum.CB_CR, null, !0), A.login(n))
                        }
                    })
                });
                var r = {
                    name: k.ip_n,
                    email: k.ip_e,
                    mobile: k.ip_m,
                    question: k.ip_q
                };
                for (var l in r) s(r[l], l), o(r[l], l)
            } else if ("chat" == t) {
                M.addListener(M.queryOne(k.st_i, n), "keydown", function(t) {
                    if ((13 == t.keyCode || 13 == t.which) && !t.shiftKey) return M.preventDefault(t), !1
                }), M.addListener(M.queryOne(k.st_i, n), "keyup", function(t) {
                    var n;
                    if (!(M.isBlankString(this.textContent.trim()) || M.isBlankString(this.innerText.trim())) && (e.hasTyped = !M.isBlankString(this.innerHTML.trim()), n = 13 != t.which && 13 != t.keyCode || t.shiftKey ? e.getTypingStatus(t) : e.getTextMessage(t), n)) {
                        A.sendMessage(n);
                        var a = N(n, j);
                        a.handleOutgoingMessage(e), e.hasTyped = !1
                    }
                }), M.addListener(M.queryOne(k.st_i, n), "paste", function(e) {
                    var t = (e.originalEvent || e).clipboardData;
                    return this.innerHTML += t.getData("text/plain"), M.stopEventPropogation(e), M.preventDefault(e)
                }), M.addListener(M.queryOne(k.sl, n), "click", function(t) {
                    M.stopEventPropogation(t), R.invokeHandlers(v.EventEnum.I_L, {
                        sendLocation: e.getLocation.bind(e)
                    })
                }), M.addListener(M.queryOne(k.st_b, n), "click", function(t) {
                    if (e.hasTyped) {
                        var a = e.getTextMessage(t);
                        if (a) {
                            M.isMobile() && M.queryOne(k.st_i, n).focus(), A.sendMessage(a);
                            var i = N(a, j);
                            i.handleOutgoingMessage(e), e.hasTyped = !1
                        }
                    }
                }), M.addListener(M.queryOne(k.t_s, n), "click", function(t) {
                    M.stopEventPropogation(t), e.toggleSettings(t, "on"), e.toggleAllPopups("off", "settings")
                }), M.addListener(M.queryOne(k.t_bc, n), "click", function(t) {
                    M.stopEventPropogation(t), R.invokeHandlers(v.EventEnum.I_BL), e.toggleBlockConfirmationPopup(t, "on"), e.toggleAllPopups("off", "block")
                }), M.addListener(M.queryOne(k.o_b_n, n), "click", function(t) {
                    R.invokeHandlers(v.EventEnum.N_BL), e.toggleBlockConfirmationPopup(t, "off")
                }), M.addListener(M.queryOne(k.o_b_y, n), "click", function(t) {
                    R.invokeHandlers(v.EventEnum.Y_BL), e.toggleBlockConfirmationPopup(t, "off");
                    var n = e.chatee.getInfo().jid;
                    A.blockUnblockUser(n, "block"), e.blockUnblockChatbox("block")
                }), M.addListener(M.queryOne(k.t_ubc, n), "click", function(t) {
                    M.stopEventPropogation(t), R.invokeHandlers(v.EventEnum.I_UB), e.toggleUnblockConfirmationPopup(t, "on"), e.toggleAllPopups("off", "unblock")
                }), M.addListener(M.queryOne(k.o_ub_n, n), "click", function(t) {
                    R.invokeHandlers(v.EventEnum.N_UB), e.toggleUnblockConfirmationPopup(t, "off")
                }), M.addListener(M.queryOne(k.o_ub_y, n), "click", function(t) {
                    R.invokeHandlers(v.EventEnum.Y_UB), e.toggleUnblockConfirmationPopup(t, "off");
                    var n = e.chatee.getInfo().jid;
                    A.blockUnblockUser(n, "unblock"), e.blockUnblockChatbox("unblock")
                }), M.addListener(M.queryOne(k.st_i, n), "focus", function(e) {
                    M.stopEventPropogation(e), M.queryOne(k.st_i, n).innerHTML.toLowerCase() == v.config.DEFAULT_CHAT_INPUT.toLowerCase() && (M.queryOne(k.st_i, n).innerHTML = "")
                }), M.addListener(M.queryOne(k.st_i, n), "blur", function(e) {
                    M.stopEventPropogation(e), ("" == M.queryOne(k.st_i, n).innerHTML || M.queryOne(k.st_i, n).innerHTML == void 0) && (M.queryOne(k.st_i, n).innerHTML = v.config.DEFAULT_CHAT_INPUT)
                }), M.addListener(M.queryOne(k.o_gcm_y, n), "click", function(e) {
                    R.invokeHandlers(v.EventEnum.Y_GCM), O("toggleGCMPopup", [e, "off"])
                }), M.addListener(M.queryOne(k.o_gcm_n, n), "click", function(e) {
                    R.invokeHandlers(v.EventEnum.N_GCM), O("toggleGCMPopup", [e, "off"])
                }), M.addListener(M.queryOne(k.pop, n), "click", function(t) {
                    M.stopEventPropogation(t), e.popOutChat(t)
                }), M.addListener(M.queryOne(k.t_cc, n), "click", function(t) {
                    M.stopEventPropogation(t), R.invokeHandlers(v.EventEnum.I_CC), e.toggleClearConfirmationPopup(t, "on"), e.toggleAllPopups("off", "clearconversation")
                }), M.addListener(M.queryOne(k.o_c_y, n), "click", function(t) {
                    R.invokeHandlers(v.EventEnum.Y_CC), e.toggleClearConfirmationPopup(t, "off"), i("delete", e)
                }), M.addListener(M.queryOne(k.o_c_n, n), "click", function(t) {
                    R.invokeHandlers(v.EventEnum.N_CC), e.toggleClearConfirmationPopup(t, "off")
                }), M.addListener(M.queryOne(k.t_a, n), "click", function(t) {
                    M.stopEventPropogation(t), e.toggleAttachements(t, "on"), e.toggleAllPopups("off", "attachment")
                }), M.addListener(M.queryOne(k.t_c, n), "click", function(t) {
                    M.stopEventPropogation(t), e.toggleContactForm(t, "on"), R.invokeHandlers(v.EventEnum.I_C, {
                        chatdom: e.htmlContainer
                    }), e.toggleAllPopups("off", "contact")
                }), M.addListener(M.queryOne(k.sc, n), "click", function(t) {
                    M.stopEventPropogation(t);
                    var n = e.getContact(t);
                    if (n) {
                        A.sendMessage(n);
                        var a = N(n, j);
                        a.handleOutgoingMessage(e)
                    }
                }), M.addListener(M.queryOne(k.sc_n, n), "click", function(t) {
                    M.stopEventPropogation(t), e.toggleContactForm(t, "off")
                }), M.queryAll(k.call, n).forEach(function(t) {
                    M.addListener(t, "click", function(t) {
                        if (M.stopEventPropogation(t), !e.isPoster()) {
                            var n = e.adDetails.getInfo().adPhone;
                            M.isBlankString(e.adDetails.getInfo().adPhone) ? e.generalError("User has not shared his/her number.") : window.location.href = "tel://" + n
                        } else M.isBlankString(e.chateeVcard.phone) ? e.generalError("User has not shared his/her number.") : window.location.href = "tel://" + e.chateeVcard.phone
                    })
                }), M.addListener(M.queryOne(k.si, n), "click", function(t) {
                    M.stopEventPropogation(t), R.invokeHandlers(v.EventEnum.I_I), e.beforePhotoUpload(t)
                }), M.addListener(M.queryOne(k.ip_i, n), "change", function(t) {
                    e.toggleAttachements(t, "off"), e.toggleUploadProgressBar("on", null, j.uploadBar_i), e.scrollToBottom(), e.getPhoto(t, function(t) {
                        if (t) {
                            A.sendMessage(t);
                            var n = N(t, j);
                            n.handleOutgoingMessage(e)
                        }
                    })
                }), M.addListener(M.queryOne(k.sv, n), "click", function(t) {
                    M.stopEventPropogation(t), R.invokeHandlers(v.EventEnum.I_V), e.beforeVideoUpload(t)
                }), M.addListener(M.queryOne(k.ip_v, n), "change", function(t) {
                    e.toggleAttachements(t, "off"), e.toggleUploadProgressBar("on", null, j.uploadBar_v), e.scrollToBottom(), e.getVideo(t, function(t) {
                        if (t) {
                            A.sendMessage(t), t.message = t.message + " " + t.duration + " " + t.fileSize;
                            var n = N(t, j);
                            n.handleOutgoingMessage(e)
                        }
                    })
                }), M.addListener(M.queryOne(k.sa, n), "click", function(t) {
                    M.stopEventPropogation(t), e.shareAudio(t)
                }), M.addListener(M.queryOne(k.lml, n), "click", function() {
                    i("get", e, !0)
                }), M.addListener(M.queryOne(k.rel, n), "click", function() {
                    m(e)
                }), M.addListener(M.queryOne(k.t_can, n), "click", function(t) {
                    e.toggleCanned(t), e.toggleAllPopups("off", "canned")
                }), M.addListener(M.queryOne(k.t_can, n), "keyup", function(t) {
                    e.toggleCanned(t, "off"), e.toggleAllPopups("off", "canned")
                }), M.queryAll(k.cnr, n).forEach(function(t) {
                    M.addListener(t, "click", function(t) {
                        e.toggleCanned(t, "off");
                        var n = M.queryOne(k.cno, this),
                            a = n.innerHTML,
                            i = this.id,
                            o = e.getTextMessage(t, a);
                        if (o) {
                            A.sendMessage(o);
                            var s = N(o, j);
                            s.handleOutgoingMessage(e)
                        }
                        R.invokeHandlers(v.EventEnum.S_CAN, {
                            id: i,
                            adDetails: e.adDetails.getInfo()
                        })
                    })
                });
                var d = [];
                for (var c in k.boxes) d.push(M.queryOne(k.boxes[c], n));
                M.addListener(d, "click", function(e) {
                    M.stopEventPropogation(e)
                })
            }
            M.addListener(n, "click", function() {
                e.toggleAllPopups("off")
            }), M.isMobile() && M.addListener(document.getElementById(v.config.CHAT_CONTAINER), "click", function() {
                e.toggleAllPopups("off")
            }), M.addListener(M.queryAll(k.tgl, n), "click", function(t) {
                e.toggleWindow(t, !1)
            }), M.addListener(M.queryAll(k.min, n), "click", function(t) {
                e.minimize(t, !1)
            }), M.addListener(M.queryAll(k.cl, n), "click", function(t) {
                e.close(t, !1)
            }), M.addListener(M.queryAll(k.max, n), "click", function(t) {
                e.maximize(t, !1)
            })
        }

        function m(e) {
            R.addCustomHandler(function() {
                e.dispatchPluginAction("LogIn"), O("toggleRelogin", ["off"])
            }, v.EventEnum.CONNECTED, null, !0), A.login()
        }

        function u(t, n) {
            function a() {
                if (l || g(G, "chat"), G.mode = v.modeEnum.CHATBOX, !M.isBlankString(o)) switch (G.uiAction(o, !0), o) {
                    case v.uiStatesEnum.OPEN:
                        R.invokeHandlers(v.EventEnum.SESS_O);
                        break;
                    case v.uiStatesEnum.MINIMISED:
                        R.invokeHandlers(v.EventEnum.SESS_MIN);
                        break;
                    default:
                } else G.open(null, !1);
                if (X && !0 == X && (X = !1), F || (F = !0, f()), M.isBlankString(s) || G.toggleOnlineStatus(s), !G.isPoster() && r) {
                    var e = G.sendVcard();
                    A.sendMessage(e)
                }
                G.dispatchPluginAction("Init", G.historyDetails), R.invokeHandlers(v.EventEnum.CB_CR)
            }
            var i = t.chatee,
                o = t.uiState,
                s = t.isOnline,
                r = t.sendVcard,
                l = !1,
                m = !1;
            M.isUndefined(t.chatee) && G.mode == v.modeEnum.LOGIN ? (m = !0, x.fetchHistory = !1, G.flush()) : U[i.getWindowIdentifier()] && U[i.getWindowIdentifier()].mode == v.modeEnum.CHATBOX ? (m = !0, G = U[i.getWindowIdentifier()], l = !0) : (x.fetchHistory = !0, R.addCustomHandler(function(e) {
                var t = e.eventparams.chatbox;
                t.dispatchPluginAction("Init", t.historyDetails)
            }, v.EventEnum.HI, null, !0), G = d(t), U[i.getWindowIdentifier()] = G), R.addCustomHandler(function() {
                l ? a() : (R.addCustomHandler(a, v.EventEnum.C_EOP, null, !0), c(G, "chat"))
            }, "PI_" + G.htmlContainer.id, null, !0), T(G), e(n, G.htmlContainer)
        }

        function p(e) {
            return M.removeElement(e.htmlContainer), delete U[e.chatee.getWindowIdentifier()], null
        }

        function _(e) {
            if (!M.isUndefined(e)) {
                var t = e.chatee;
                if (U[t.getWindowIdentifier()]) G = U[t.getWindowIdentifier()];
                else {
                    G && G.mode == v.modeEnum.LOGIN && (G = p(G));
                    var n = d(e);
                    U[t.getWindowIdentifier()] = n, c(n, "login"), g(n, "login"), G = n, G.mode = v.modeEnum.LOGIN
                }
                G.open(null, !1)
            }
        }

        function f() {
            var e = [],
                t = {};
            if (!M.isEmpty(U)) {
                for (var n in U) {
                    var a = U[n];
                    a.shouldPoll() && (t[n] = a.chatee.getInfo().jid, e.push(a.chatee.getInfo().jid))
                }
                0 < e.length && (e = M.deDupArray(e).join(","), P.getJidPresence(e, {
                    success: function(e) {
                        if (0 < e.length)
                            for (var n in t) {
                                var a = t[n];
                                e.forEach(function(e) {
                                    a == e.jid && ("on" == e.status ? U[n].chateeOnline() : U[n].chateeOffline())
                                })
                            }
                    }
                }))
            }
            setTimeout(function() {
                X || (f(), X = !1)
            }, 60000 * v.config.PRESENCE_POLL_TIME_INTERVAL)
        }

        function h(e) {
            var t, n = new Date,
                a = n.getTime();
            return e.forEach(function(e) {
                a > e.lastActivityTimestamp && (t = e, a = e.lastActivityTimestamp)
            }), t
        }

        function y(e) {
            if (!e.noHistory) {
                var t = e.chatee.chatee.jid,
                    n = x.jid;
                t && "" != t || (e.chatee.chatee.email && "" != e.chatee.chatee.email ? t = b.fromRawEmailToJID(e.chatee.chatee.email) : e.chatee.chatee.demail && "" != e.chatee.chatee.demail && (t = b.fromRawDEmailToJID(e.chatee.chatee.demail))), n && "" != n || (e.chatterInfo.email && "" != e.chatterInfo.email ? n = b.fromRawEmailToJID(e.chatterInfo.email) : e.chatterInfo.demail && "" != e.chatterInfo.demail && (n = b.fromRawDEmailToJID(e.chatterInfo.demail))), w.jumpStartHistory({
                    adId: e.adDetails.adDetails.adId,
                    ad: e.adDetails.adDetails,
                    buddy: t,
                    owner: n
                }), e.loginInit && (e = {
                    sendVcard: !0
                })
            }
            return e
        }

        function I(e) {
            var t = null;
            try {
                t = e.adDetails.adDetails.adId
            } catch (t) {}
            e = y(e), M.isBlankString(j.chatbox) ? r("chatbox", u.bind(void 0, e, t)) : u(e, t)
        }

        function E() {
            if (!M.isEmpty(U)) {
                for (var e in U) U[e].htmlContainer.remove();
                U = {}
            }
            F = null, X = !0, G = null
        }

        function C() {
            var e = [],
                n = t(v.uiStatesEnum.OPEN, "ui"),
                a = t(v.uiStatesEnum.MINIMISED, "ui").concat(n);
            for (var i in a) {
                var o = new H;
                o.setInfo(a[i].chatee, a[i].adDetails, a[i].uiState, a[i].isOnline), e.push(o)
            }
            return e
        }

        function O(e, n) {
            var a = t();
            a.forEach(function(t) {
                t[e].apply(t, n)
            })
        }

        function T(e) {
            var t = n(45);
            t({
                currentChatBox: e,
                helper: M,
                configs: v,
                stropheConnectionHandler: A,
                messageFactory: N,
                customHandler: R,
                template: j,
                qUser: x
            })
        }
        var M = n(3),
            b = n(5),
            v = n(0),
            k = n(8),
            A = n(11),
            L = n(24),
            S = n(9),
            D = n(10),
            H = n(15),
            x = n(6),
            N = n(23),
            q = n(12),
            P = n(13),
            w = n(7),
            R = n(2),
            B = n(44),
            U = {},
            j = {
                scriptsLoaded: !1,
                loginform: "",
                chatbox: "",
                toastMessage: "",
                incomingTextMessage: "",
                outgoingTextMessage: "",
                incomingContactMessage: "",
                outgoingContactMessage: "",
                incomingImageMessage: "",
                outgoingImageMessage: "",
                incomingVideoMessage: "",
                outgoingVideoMessage: "",
                incomingDocumentMessage: "",
                outgoingDocumentMessage: "",
                incomingServerMessage: "",
                outgoingServerMessage: "",
                incomingPromoMessage: "",
                loadMoreToast: "",
                dateToast: "",
                uploadBar_i: "",
                uploadBar_v: "",
                cannedResponse: ""
            },
            F = null,
            X = !1,
            G = null;
        return {
            chatBoxes: U,
            initiateLogin: function(e) {
                M.isBlankString(j.loginform) ? r("login", _.bind(void 0, e)) : _(e)
            },
            getChatBoxes: t,
            saveState: function() {
                var e = n(14),
                    t = n(16),
                    a = [];
                if (M.saveChatStateRequired()) var a = C();
                var i = x.getUserState();
                e.setChatSession(new t(i, a))
            },
            loadTemplates: r,
            broadcastMessage: s,
            initChat: I,
            delegateIncomingMessage: function(e) {
                function n(e) {
                    e.forEach(function(e) {
                        a.handleIncomingMessage(e), a.shouldSendSeenAck(e) && A.sendMessageAck("seen", {
                            to: a.msg.from,
                            adId: a.msg.adId,
                            stime: a.msg.stime,
                            id: a.msg.id
                        })
                    })
                }
                var a = N(e, j),
                    i = [];
                if (a.sendAck && A.sendMessageAck("recv", {
                        to: a.msg.from,
                        adId: a.msg.adId,
                        stime: a.msg.stime,
                        id: a.msg.id
                    }), "acknowledge" == a.type && R.invokeHandlers(v.EventEnum.M_A, {
                        status: a.msg.text
                    }), "block" != a.type) {
                    var o = !1,
                        s = a.msg.adId + "_" + a.msg.adEmail;
                    U[s] ? i.push(U[s]) : (a.sendAck || "vcard" == a.type) && (o = !0, new S().loadInfo(a.msg.adId, function(e) {
                        var t = new D;
                        t.setInfo({
                            adid: a.msg.adId,
                            status: "on",
                            jid: a.msg.from
                        }), x.fetchHistory = !0;
                        var o = new q(x.name, x.mobile, x.email);
                        R.addCustomHandler(function() {
                            i.push(G), n(i)
                        }, v.EventEnum.CB_CR, null, !0), I({
                            chatee: t,
                            adDetails: e,
                            chatterInfo: o,
                            uiState: v.uiStatesEnum.CLOSED,
                            sendVcard: !1
                        })
                    }))
                } else i = t(a.msg.adEmail, "email");
                o || n(i)
            },
            template: j,
            getChatBoxStates: C,
            pollPresence: f,
            initDisconnect: function() {
                P.sendLogInLogoutPresence("logOut"), s({
                    message: "off",
                    type: "chat",
                    stime: M.getTime(),
                    id: "presence"
                }), E(), A.forcedDisconnect(), x.flushState()
            },
            getLastActivityTimestamp: function() {
                var e = t(v.uiStatesEnum.OPEN, "ui"),
                    n = 0;
                return e.forEach(function(e) {
                    n < e.lastActivityTimestamp && (n = e.lastActivityTimestamp)
                }), n
            },
            broadcastAction: O,
            adjustChatBoxes: function(e) {
                var n = t(v.uiStatesEnum.OPEN, "ui"),
                    a = t(v.uiStatesEnum.MINIMISED, "ui").concat(n);
                if (a.length == v.config.MAX_NO_OF_CHATS) {
                    var i = h(a);
                    i != e && 0 > a.indexOf(e) && (i.close(null, !0), R.invokeHandlers(v.EventEnum.LRU_CL))
                }
            },
            shareLocation: function(e, t) {
                if (t) {
                    A.sendMessage(t);
                    var n = N(t, j);
                    n.handleOutgoingMessage(e)
                }
            },
            sendMessageAcknowledgment: function(e, t) {
                A.sendMessageAck(e, t)
            },
            onRelogin: m,
            getNumberOfChatBoxes: function(e) {
                var n;
                if (M.isBlankString(e)) return null;
                switch (e) {
                    case "o":
                        n = v.uiStatesEnum.OPEN;
                        break;
                    case "m":
                        n = v.uiStatesEnum.MINIMISED;
                        break;
                    case "c":
                        n = v.uiStatesEnum.CLOSED;
                        break;
                    default:
                        return null;
                }
                return t(n, "ui").length
            },
            MAOchatmanager: function(e, t, n) {
                var a = this.getChatBoxes({
                    email: e.getInfo().email,
                    adId: n.getInfo().adId
                }, "email&adId")[0];
                a.dispatchPluginAction("MaoChat", t), a.pluginInitStatus = !0
            },
            initPsuedoChat: function(e, t) {
                var n = this.getChatBoxes(e.getInfo().email, "email")[0];
                if ("t" == t.type) var a = n.getTextMessage(null, t.msg);
                A.sendMessage(a);
                var i = N(a, j);
                i.handleOutgoingMessage(n)
            }
        }
    }();
    e.exports = a
}, function(e, t, n) {
    "use strict";
    var a = function() {
        var e = n(0);
        return {
            removeResource: function(e) {
                return e ? -1 < e.indexOf("/") ? e.substring(0, indexPos) : e : e
            },
            generatePassword: function(e) {
                var t = e.split("@")[0];
                return MD5.hexdigest(t)
            },
            isDevicejaberId: function(e) {
                return !!e && !!(-1 < e.indexOf("-d@"))
            },
            fromJIDToEmailID: function(e, t) {
                if (e) {
                    var n = e.match(/-e|-d/),
                        a = "";
                    return a = e.match(/@/) ? e.substring(0, e.substring(0, e.indexOf("@")).indexOf(n)) : e.substring(0, e.indexOf(n)), t || (t = "@"), a.replace("-", t)
                }
            },
            fromRawEmailToJID: function(t) {
                if (!t) return "";
                var n = t.toLowerCase().replace("@", "-");
                return n + "-e@" + e.config.QUIKCHATDOMAIN
            },
            fromRawDEmailToJID: function(t) {
                if (!t) return "";
                var n = t.toLowerCase().replace("@", "-");
                return n + "-d@" + e.config.QUIKCHATDOMAIN
            },
            removeDomainFromJID: function(e) {
                if (!e) return !1;
                var t = "@";
                return -1 < e.indexOf(t) ? e.substring(0, e.indexOf(t)) : e
            }
        }
    }();
    e.exports = a
}, function(e, t, n) {
    "use strict";
    var a = n(17),
        i = function() {
            return {
                isLoggedIn: !1,
                type: "ws",
                jid: "",
                name: "",
                password: "",
                email: "",
                demail: "",
                mobile: "",
                connectionStatus: "",
                idleTimeout: "",
                lastActivityAt: "",
                autoConnect: !0,
                autoRegisterOnAuthFail: !0,
                reloginOnNetworkError: !0,
                authfail: !1,
                fetchHistory: !1,
                dontMarkSeen: !1,
                expoCounter: 0,
                expoTimerInterval: 3e3,
                expoLimit: 4,
                initializationComplete: !1,
                service: "",
                flushState: function() {
                    i.jid = i.name = i.password = i.email = i.demail = i.mobile = i.connectionStatus = i.idleTimeout = i.isReconnect = !1, i.isLoggedIn = i.autoConnect = !1
                },
                getUserState: function() {
                    var e = new a;
                    return e.setInfo(i.jid, i.password, i.name, i.email, i.mobile, i.isLoggedIn, i.demail, i.authfail), e
                },
                setLastActivityTimeStamp: function(e) {
                    if (!e) {
                        var t = new Date;
                        e = t.getTime()
                    }
                    i.lastActivityAt = e
                }
            }
        }();
    e.exports = i
}, function(e, t, n) {
    "use strict";

    function a(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var i = n(0),
        o = n(3),
        s = n(5),
        r = n(18),
        l = function() {
            var e = {},
                t = function(e) {
                    if (e.adId && e.buddy && e.owner) return e.owner = s.removeDomainFromJID(e.owner), e.buddy = s.removeDomainFromJID(e.buddy), e.adId + "_" + e.owner + "_" + e.buddy;
                    throw "History creation failed! not enough params passed. adId, buddy or owner lookup failed."
                },
                n = function(n) {
                    try {
                        var i = t(n),
                            o = r.getLocalStorage("hist_" + i);
                        return null == o ? (e[i] = {
                            status: "ok",
                            desc: "ok",
                            owner: n.owner,
                            empty: !0,
                            data: a({}, n.adId, {
                                adid: n.adId,
                                adDetails: n.ad,
                                numUnseenMsgs: 0,
                                poster: 2,
                                conver: [{
                                    buddy: n.buddy,
                                    messages: [],
                                    vcard: null,
                                    lastSeenTimeStamp: 0,
                                    lastSeenMsgId: "",
                                    numUnseenMsgs: 0,
                                    lastActivityTime: 1495713110318,
                                    block: 0,
                                    vcardFound: 1,
                                    numMsgs: 0
                                }]
                            }),
                            numTotalUnseen: 0,
                            hasNext: !1
                        }, d(i, e[i]), e[i]) : (e[i] = JSON.parse(o), e[i])
                    } catch (t) {
                        console.log(t)
                    }
                },
                l = function(n, a) {
                    try {
                        var i = a || t(n),
                            o = r.getLocalStorage("hist_" + i);
                        return null != o && (e[i] = JSON.parse(o), !e[i].empty) ? o : null
                    } catch (t) {
                        console.log(t)
                    }
                },
                d = function(t, n) {
                    e[t] = n, r.setLocalStorage("hist_" + t, JSON.stringify(n))
                };
            return {
                manipulateHistory: function(e) {
                    var t = i.config.QUIK_CHAT_HISTORY_DOMAIN,
                        e = e || {};
                    switch (e.type) {
                        case "get":
                            var n = l({
                                adId: e.adId,
                                buddy: e.buddyJid,
                                owner: e.ownerJid
                            });
                            null == n ? t = "/xhr/c_x?adId=" + e.adId + "&buddy=" + e.buddyJid + "&owner=" + e.ownerJid + "&count=" + e.count + "&vcard=1&client=modularchat" : (t = null, e.callback.success(n));
                            break;
                        case "delete":
                            t += "/delete?adid=" + e.adId + "&owner=" + e.ownerJid + "&buddy=" + e.buddyJid;
                            break;
                        case "unseen":
                            t += "/unseen?jid=" + s.removeDomainFromJID(e.jid);
                    }
                    var a = {
                        "X-Quikr-Client": i.config.CLIENT_TAG
                    };
                    if (null != t) try {
                        o.ajaxGet(t, {
                            success: function(t) {
                                e.callback && e.callback.success && e.callback.success(t)
                            },
                            error: function(t) {
                                e.callback && e.callback.error && e.callback.error(t)
                            }
                        }, !0, null, a)
                    } catch (t) {}
                },
                jumpStartHistory: n,
                setMessage: function(a) {
                    try {
                        var i = t(a);
                        e[i] || n(a);
                        var o = e[i].data[a.adId].conver[0].messages,
                            s = e[i].data[a.adId].conver[0].numMsgs;
                        o.unshift(a.msg), e[i].data[a.adId].conver[0].messages = o, e[i].data[a.adId].conver[0].numMsgs = s + 1, e[i].empty = !1, d(i, e[i])
                    } catch (t) {
                        console.log(t)
                    }
                },
                setVcard: function(a) {
                    try {
                        var i = t(a);
                        e[i] || n(a), e[i].data[a.adId].conver[0].vcard = a.vcard, d(i, e[i])
                    } catch (t) {
                        console.log(t)
                    }
                },
                setHistory: d,
                getHistoryKey: t,
                deleteMessages: function(a) {
                    try {
                        var i = t(a);
                        e[i] || n(a), e[i].data[a.adId].conver[0].messages = [], e[i].data[a.adId].conver[0].numMsgs = 0, e[i].empty = !1, d(i, e[i])
                    } catch (t) {
                        console.log(t)
                    }
                }
            }
        }();
    e.exports = l
}, function(e) {
    e.exports = {
        it: ".script_i_text_message",
        ot: ".script_o_text_message",
        msg: ".script_msg",
        msg_time: ".script_msg_time",
        msg_ack: ".script_msg_ack",
        ic: ".script_i_contact_message",
        oc: ".script_o_contact_message",
        con_n: ".script_c_name",
        con_e: ".script_c_email",
        con_m: ".script_c_mobile",
        ii: ".script_i_img_message",
        oi: ".script_o_img_message",
        img: ".script_img",
        i_click2dl: ".script_img_download_trigger",
        id: ".script_i_doc_message",
        od: ".script_o_doc_message",
        d_title: ".script_doc_title",
        d_click2dl: ".script_doc_download_trigger",
        d_size: ".script_doc_size",
        iv: ".script_i_vid_message",
        ov: ".script_o_vid_message",
        v_img: ".script_vid_img",
        v_click2dl: ".script_vid_download_trigger",
        v_size: ".script_vid_size",
        il: ".script_i_loc_message",
        ol: ".script_o_loc_message",
        ie: ".script_i_escrow_message",
        oe: ".script_o_escrow_message",
        ehm: ".script_escrow_hint_msg",
        ehmc: ".script_escrow_hint_container",
        emt: ".script_escrow_msg_title",
        lmtst: ".script_load_more_toast",
        dtst: ".script_date_toast",
        ack_d: ".script_date",
        upprog_i: ".script_upload_progress_i",
        upprog_v: ".script_upload_progress_v",
        upprog_bar: ".script_progress_bar",
        upprog_text: ".script_progress_text",
        msgdel: ".script_msg_clear",
        osm: ".script_o_server_message",
        ism: ".script_i_server_message",
        smb_1: ".script_server_msg_button1",
        smb_2: ".script_server_msg_button2",
        smb_1_t: ".script_server_msg_button1_title",
        smb_2_t: ".script_server_msg_button2_title",
        smt_1: ".script_server_msg_text1",
        smt_2: ".script_server_msg_text2",
        smi: ".script_server_msg_img",
        smt: ".script_server_msg_title",
        ipm: ".script_i_promo_message",
        cnr: ".script_canned_container",
        cna: ".script_canned_area",
        cno: ".script_canned_opt",
        ip_v: ".objectVideo",
        ip_i: ".object",
        ip_n: ".script_input_name",
        ip_m: ".script_input_mobile",
        ip_e: ".script_input_email",
        ip_q: ".script_input_question",
        ip_l: ".script_input_login",
        ip_er: ".script_login_error",
        ip_e_er: ".script_login_email_error",
        ip_n_er: ".script_login_name_error",
        ip_m_er: ".script_login_mobile_error",
        sel_e: ".script_select_email",
        sel_m: ".script_select_mobile",
        ip_e_container: ".script_input_eml_container",
        sel_e_container: ".script_select_eml_container",
        ip_m_container: ".script_input_mob_container",
        sel_m_container: ".script_select_mob_container",
        ip_c_n: ".script_contact_name_input",
        ip_c_m: ".script_contact_mobile_input",
        ip_c_e: ".script_contact_email_input",
        ip_c_err: ".script_contact_error",
        gen_err_container: ".script_general_error_container",
        gen_err_text: ".script_error_text",
        if_canbox: ".if-BottomPopup-View",
        cp_a: ".script_chat_panel_a",
        mbox: ".script_msg_box",
        mscroll: ".script_scroll",
        minbox: ".script_toggle_minimise",
        type_con: ".script_type_container",
        on_min_hide: {
            attachment: ".script_toggle_attachements",
            setting: ".script_toggle_settings"
        },
        relbox: ".script_relogin_message",
        boxes: {
            setbox: ".script_chat_settings",
            attbox: ".script_attachements",
            canbox: ".script_canned",
            bcbox: ".script_block_confirm",
            ubcbox: ".script_unblock_confirm",
            ccbox: ".script_clear_confirm",
            conbox: ".script_contact_form",
            mofbox: ".script_mof",
            modbox: ".script_mod",
            gcmbox: ".script_gcm_confirm"
        },
        bbox: ".script_blocked_area",
        pop_lyr: ".script_popup_layer",
        soldbox: ".script_soldout_area",
        inactivebox: ".script_inactive_area",
        ipbar: ".script_input_bar",
        ct: ".script_chat_title",
        ad_t: ".script_ad_title",
        ad_p: ".script_ad_price",
        ad_d: ".script_ad_date",
        ad_i: ".script_ad_image",
        ad_l: ".script_ad_link",
        ad_n_i: ".script_ad_no_image",
        tgl: ".script_toggle_window",
        min: ".script_minimize_chat",
        max: ".script_maximize_chat",
        cl: ".script_close_chat",
        pop: ".script_popout_chat",
        on: ".script_online",
        off: ".script_offline",
        off_tip: ".script_tip_on",
        pr_t: ".script_presence_text",
        st_i: ".script_input_chat",
        st_b: ".script_send_chat",
        sc: ".script_attach_contact",
        sc_n: ".script_attach_contact_cancel",
        si: ".script_attach_photo",
        sv: ".script_attach_video",
        sl: ".script_attach_location",
        sa: ".script_attach_audio",
        call: ".script_call",
        lml: ".script_load_more",
        rel: ".script_relogin",
        typing: ".script_typing",
        dl_link: ".script_msg_dl_link",
        t_s: ".script_toggle_settings",
        t_bc: ".script_toggle_block_confirm",
        t_ubc: ".script_toggle_unblock_confirm",
        t_cc: ".script_toggle_clear_confirm",
        t_a: ".script_toggle_attachements",
        t_c: ".script_toggle_contact_form",
        t_can: ".script_toggle_canned",
        o_gcm_n: ".script_gcm_no",
        o_gcm_y: ".script_gcm_yes",
        o_b_n: ".script_block_no",
        o_b_y: ".script_block_yes",
        o_ub_n: ".script_unblock_no",
        o_ub_y: ".script_unblock_yes",
        o_c_n: ".script_clear_no",
        o_c_y: ".script_clear_yes",
        lmv: ".script_load_more_visible",
        sys: ".script_sys",
        esc: {
            mo: ".script_mo",
            mob: ".script_mob",
            mob_c: ".script_cmob",
            mod_e: ".script_mod_email",
            mod_m: ".script_mod_number",
            mod_s: ".script_mod_submit",
            mod_err: ".script_mod_error",
            mod: ".script_mod",
            mof: ".script_mof",
            mof_p: ".script_mof_price",
            mof_err: ".script_mof_error",
            eo: ".script_eo",
            co: ".script_co",
            so: ".script_so",
            no: ".script_no",
            ao: ".script_ao",
            ro: ".script_ro",
            wo: ".script_wo",
            op: ".script_op",
            np: ".script_np",
            ep: ".script_ep",
            eps: ".script_eps",
            bso: ".script_bso",
            bro: ".script_bro",
            sro: ".script_sro"
        }
    }
}, function(e, t, n) {
    "use strict";
    var a = n(3),
        i = n(0),
        o = function() {
            this.adDetails = {}
        };
    o.prototype.getInfo = function() {
        return this.adDetails
    }, o.prototype.loadInfo = function(e, t) {
        var n = this;
        a.ajaxPost(i.config.ADDETAILS_API_URL, {
            id: e
        }, {
            success: function(e) {
                var i = JSON.parse(e);
                "SUCCESS" == i.status && (i.adTitle = a.truncateString(i.adTitle, 25), i.adOwnerName = i.adEmail.substr(0, i.adEmail.indexOf("@")), i.cannedResponses = i.cannedResponses, i.lastUpdatedTime = i.lastUpdatedTime, n.setInfo(i), t && t(n))
            },
            error: function() {}
        })
    }, o.prototype.setInfo = function(e) {
        this.adDetails.adId = e.adId, this.adDetails.adOwnerName = e.adOwnerName, this.adDetails.adEmail = e.adEmail, this.adDetails.adPhone = e.adPhone, this.adDetails.adTitle = a.truncateString(e.adTitle, 25), this.adDetails.adPrice = e.adPrice, this.adDetails.adImage = e.adImage, this.adDetails.lastUpdatedTime = e.lastUpdatedTime, this.adDetails.adLink = e.adLink, this.adDetails.adStatus = e.adStatus, this.adDetails.soldOut = e.soldOut, this.adDetails.adType = e.adType, this.adDetails.isEscrow = e.isEscrow, this.adDetails.isEscrowLowTouch = e.isEscrowLowTouch, this.adDetails.cannedResponses = e.cannedResponses, this.adDetails.adDEmail = e.adDEmail, this.adDetails.category_pgid = e.catId ? e.catId : e.category_pgid, this.adDetails.category_gid = e.category_gid, this.adDetails.sellerPincode = e.sellerPincode, this.adDetails.weight = e.weight, this.adDetails.orderFlow = e.orderFlow
    }, o.prototype.isInactive = function() {
        return this.adDetails.adStatus && 0 != this.adDetails.adStatus && (0 == this.adDetails.soldOut || !this.adDetails.soldOut)
    }, o.prototype.isSoldOut = function() {
        return this.adDetails.adStatus && 0 != this.adDetails.adStatus && (0 == this.adDetails.soldOut || !this.adDetails.soldOut)
    }, e.exports = o
}, function(e, t, n) {
    "use strict";
    var a = n(5),
        i = function() {
            this.chatee = {}
        };
    i.prototype.validateInfo = function(e) {
        return !!e && (e.jid || e.email || e.demail) && e.adid
    }, i.prototype.getWindowIdentifier = function() {
        return this.chatee.adid + "_" + this.getJidEmail()
    }, i.prototype.getJidEmail = function() {
        return a.fromJIDToEmailID(this.chatee.jid) || this.chatee.demail || this.chatee.email
    }, i.prototype.getEmail = function() {
        return this.chatee.demail || this.chatee.email
    }, i.prototype.getInfo = function() {
        return this.chatee
    }, i.prototype.setInfo = function(e) {
        return !!this.validateInfo(e) && (e.jid || (e.jid = e.demail ? a.fromRawDEmailToJID(e.demail) : a.fromRawEmailToJID(e.email)), e.email || (e.email = a.isDevicejaberId(e.jid) ? "" : a.fromJIDToEmailID(e.jid)), e.demail || (e.demail = "" == e.email ? a.fromJIDToEmailID(e.jid) : ""), this.chatee = e)
    }, e.exports = i
}, function(e, t, n) {
    "use strict";
    var a = function() {
        var e, t = n(5),
            a = n(0),
            i = n(6),
            o = n(3),
            s = n(2),
            r = {
                connectHandler: function() {
                    i.isLoggedIn = !0, i.authfail = !1, i.autoConnect = !0, i.initializationComplete = !0, i.setLastActivityTimeStamp(), e.addHandler(h, null, "message", null, null, null), o.clearIntervals(i.idleTimeout), i.idleTimeout = setInterval(d, a.config.CHECK_IDLE_TIMEOUT_INTERVAL)
                },
                disconnectHandler: function() {
                    i.isLoggedIn = !1, !1 === i.authfail && i.autoConnect && !i.reloginOnNetworkError && setTimeout(function() {
                        g()
                    }, 3e3), o.clearIntervals(i.idleTimeout)
                },
                authfailHandler: function() {
                    i.authfail = !0, e.addHandler(p, null, "iq", null, null, null), l()
                },
                connfailHandler: function() {
                    setTimeout(function() {
                        c("Network error"), i.expoCounter < i.expoLimit - 1 ? (i.expoCounter++, g()) : i.expoCounter < i.expoLimit && (i.expoCounter++, a.config.SWITCHPROTOCOL && !o.isBoshService(i.service) && (i.service = a.config.BOSH_SERVICE, i.expoCounter = 0), g())
                    }, i.expoTimerInterval)
                },
                idletimeoutHandler: function() {
                    o.clearIntervals(i.idleTimeout);
                    var e = n(4);
                    e.broadcastAction("toggleRelogin", ["on"]), m("idletimeout")
                }
            },
            l = function() {
                var t = $iq({
                    type: "get",
                    id: "qkrnxt-registration1"
                }).c("query", {
                    xmlns: "jabber:iq:register"
                });
                e.send(t)
            },
            d = function() {
                var e, t = n(4),
                    i = new Date,
                    o = t.getLastActivityTimestamp();
                if (o && 0 < (e = i.getTime() - o) && e >= parseInt(1e3 * (60 * a.config.QUICK_CHAT_IDLE_TIMEOUT))) {
                    var r = t.chatBoxes;
                    for (var l in r) r[l].dispatchPluginAction("LogOut");
                    s.invokeHandlers(a.EventEnum.IDLETIMEOUT, {
                        relogin: n(4).onRelogin
                    })
                }
            },
            c = function(t) {
                e.disconnect(t)
            },
            g = function(n) {
                n = n || {};
                var a = n.name,
                    s = n.mobile,
                    r = n.email,
                    l = n.demail,
                    d = n.jid;
                o.isBlankString(i.jid) || i.isLoggedIn ? !i.isLoggedIn && (e = new Strophe.Connection(i.service), i.name = a, i.mobile = s, i.email = r, i.demail = l, o.isBlankString(d) ? o.isBlankString(l) ? i.jid = t.fromRawEmailToJID(r) : i.jid = t.fromRawDEmailToJID(l) : (i.jid = d, t.isDevicejaberId(d) && (i.demail = t.fromJIDToEmailID(d)), !t.isDevicejaberId(d) && (i.email = t.fromJIDToEmailID(d))), i.password = t.generatePassword(i.jid), e.connect(i.jid, i.password, u)) : (e = null, e = new Strophe.Connection(i.service), e.connect(i.jid, i.password, u))
            },
            m = function(e) {
                e = e ? e : "signout", i.isLoggedIn && (i.autoConnect = !1, c(e), s.invokeHandlers(a.EventEnum.FORCEDDISCONNECT))
            },
            u = function(e, t) {
                switch (i.connectionStatus = e, e) {
                    case Strophe.Status.CONNECTING:
                        s.invokeHandlers(a.EventEnum.CONNECTING, {
                            qUser: i.getUserState().getInfo(),
                            connection: {
                                service: i.service,
                                retry: i.expoCounter
                            }
                        });
                        break;
                    case Strophe.Status.CONNFAIL:
                        s.invokeHandlers(a.EventEnum.CONNECTIONFAIL, {
                            condition: t,
                            qUser: i.getUserState().getInfo(),
                            connection: {
                                service: i.service,
                                retry: i.expoCounter
                            }
                        });
                        break;
                    case Strophe.Status.DISCONNECTING:
                        break;
                    case Strophe.Status.DISCONNECTED:
                        s.invokeHandlers(a.EventEnum.DISCONNECTED);
                        break;
                    case Strophe.Status.AUTHFAIL:
                        s.invokeHandlers(a.EventEnum.AUTHFAIL, {
                            qUser: i.getUserState().getInfo(),
                            connection: {
                                service: i.service,
                                retry: i.expoCounter
                            }
                        });
                        break;
                    case Strophe.Status.CONNECTED:
                        s.invokeHandlers(a.EventEnum.CONNECTED, {
                            qUser: i.getUserState().getInfo(),
                            connection: {
                                service: i.service,
                                retry: i.expoCounter
                            }
                        });
                        break;
                    default:
                }
            },
            p = function(t) {
                var n = t.getAttribute("id");
                "qkrnxt-registration1" == n && (_(), setTimeout(function() {
                    e.disconnect("authFail"), i.connectionStatus = "", g()
                }, 1e3))
            },
            _ = function() {
                var t = $iq({
                    type: "set",
                    id: "qkrnxt-registration2"
                }).c("query", {
                    xmlns: "jabber:iq:register"
                }).c("username", {}).t(i.jid).up().c("password", {}).t(i.password);
                e.send(t)
            },
            f = function(t) {
                t.fileSize || (t.fileSize = ""), t.duration || (t.duration = "");
                var n = $msg({
                    to: t.to,
                    adid: t.adId,
                    type: t.type,
                    stime: t.stime ? t.stime : 0,
                    id: t.id,
                    duration: t.duration,
                    filesize: t.fileSize
                }).cnode(Strophe.xmlElement("body", t.message)).up().c("active", {
                    xmlns: "http://jabber.org/protocol/chatstates"
                });
                try {
                    e.send(n)
                } catch (t) {}
                return !0
            },
            h = function(e) {
                try {
                    var a = n(4),
                        s = {};
                    return !(s.to = e.getAttribute("to"), s.from = e.getAttribute("from"), s.type = e.getAttribute("type"), s.adId = e.getAttribute("adid"), s.stime = e.getAttribute("stime"), s.id = e.getAttribute("id"), s.duration = e.getAttribute("duration"), s.filesize = e.getAttribute("filesize"), s.metadata = e.getAttribute("metadata"), s.elems = e.getElementsByTagName("body"), o.isBoshService(i.service) ? (s.duration = s.elems[0].getAttribute("duration"), s.filesize = s.elems[0].getAttribute("filesize"), !o.isBlankString(Strophe.getText(e.getElementsByTagName("metadata")[0])) && (s.metadata = Strophe.getText(e.getElementsByTagName("metadata")[0]).replace(/&quot;/g, "\""))) : !o.isBlankString(s.metadata) && (s.metadata = Base64.decode(s.metadata)), s.from != i.jid) || !(s.delayelems = e.getElementsByTagName("delay"), !(0 < s.delayelems.length)) || (s.adEmail = t.fromJIDToEmailID(s.from), 0 < s.elems.length && (s.body = s.elems[0], s.text = Strophe.getText(s.body), "vcard" == s.id ? a.delegateIncomingMessage(s) : setTimeout(function() {
                        a.delegateIncomingMessage(s)
                    }, 1e3)), !0)
                } catch (t) {
                    return !0
                }
            };
        return {
            addDefaultHandlers: function() {
                s.addCustomHandler(r.connectHandler, a.EventEnum.CONNECTED, null, null), s.addCustomHandler(r.disconnectHandler, a.EventEnum.DISCONNECTED, null, null), i.autoRegisterOnAuthFail && s.addCustomHandler(r.authfailHandler, a.EventEnum.AUTHFAIL, null, null), s.addCustomHandler(r.idletimeoutHandler, a.EventEnum.IDLETIMEOUT, null, null), s.addCustomHandler(r.connfailHandler, a.EventEnum.CONNECTIONFAIL, null, null)
            },
            login: g,
            sendMessage: f,
            sendMessageAck: function(e, t) {
                if (!i.isLoggedIn) return !0;
                var n = t.id.match(/(.*)\-(.*)_(.*)/),
                    a = !1;
                if (n) switch (n[1].charAt(0)) {
                    case "i":
                        a = 270 <= n[2];
                        break;
                    case "a":
                        a = 650 <= n[2];
                        break;
                    case "d":
                    case "w":
                    case "n":
                    case "e":
                        a = !0;
                } else a = !0;
                a && (t.type = "result", t.message = e, f(t))
            },
            forcedDisconnect: m,
            blockUnblockUser: function(t, n) {
                if ("block" == n) var a = "deny";
                else var a = "allow";
                var i = t;
                t.match(/@/) && (i = t.substring(0, t.indexOf("@")));
                var o = $iq({
                    type: "set",
                    id: "all1"
                }).c("query", {
                    xmlns: "jabber:iq:privacy"
                }).c("list", {
                    name: "public"
                }).c("item", {
                    type: "jid",
                    value: i,
                    action: a,
                    order: "100"
                }).c("message");
                e && e.sendIQ(o)
            },
            leaveReply: function(e, t) {
                var n = a.config.REPLY_API + e.adId + "?aj=1&act=reply&inlinereply=true";
                o.ajaxPost(n, e, {
                    success: function(e) {
                        e = JSON.parse(e), t && t.success && t.success(e), s.invokeHandlers(a.EventEnum.REP_S, e)
                    },
                    error: function(e) {
                        t && t.error && t.error(e), s.invokeHandlers(a.EventEnum.REP_E, e)
                    }
                }, !0, null)
            }
        }
    }();
    e.exports = a
}, function(e, t, n) {
    "use strict";
    var a = n(5);
    window.chatterInfo = function(e, t, n, i, o) {
        return o && a.isDevicejaberId(o) && (i = a.fromJIDToEmailID(o)), o && !a.isDevicejaberId(o) && (n = a.fromJIDToEmailID(o)), {
            name: e,
            mobile: t,
            email: n,
            demail: i,
            jid: o
        }
    }, e.exports = chatterInfo
}, function(e, t, n) {
    "use strict";
    var a = function() {
        var e = n(0),
            t = n(3);
        return {
            sendLogInLogoutPresence: function(e) {
                "logIn" == e ? $pres().c("show").t("chat") : "logOut" == e && $pres().c("show").t("dnd")
            },
            getJidPresence: function(n, a) {
                if (!n) return null;
                var i = {};
                e.config.CLIENT_TAG && (i["X-Quikr-Client"] = e.config.CLIENT_TAG), t.ajaxPost(e.config.QUIKCHATPRESENCEDOMAIN, {
                    jids: n
                }, {
                    success: function(e) {
                        a.success && a.success(JSON.parse(e))
                    },
                    error: function(e) {
                        try {
                            a.error && a.error(JSON.parse(e))
                        } catch (t) {}
                    }
                }, !0, null, "text/plain", i)
            },
            getAdPresence: function(n, a) {
                var o, s = [];
                if (!n) return [];
                for (var r = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i), l = 0; l < n.length; l++)
                    if (n[l]) {
                        var i = n[l];
                        i[0].match(/^\d{1,}$/) && r.test(i[1]) && (!i[2] || r.test(i[2])) && s.push(i.join(","))
                    }
                if (0 == s.length) return [];
                o = s.join(";");
                var d = {};
                e.config.CLIENT_TAG && (d["X-Quikr-Client"] = e.config.CLIENT_TAG), t.ajaxPost(e.config.QUIKCHATADPRESENCEDOMAIN, {
                    ids: o
                }, {
                    success: function(e) {
                        a.success && a.success(JSON.parse(e))
                    },
                    error: function(e) {
                        try {
                            a.error && a.error(JSON.parse(e))
                        } catch (t) {
                            a.error(e)
                        }
                    }
                }, !0, null, "text/plain", d)
            }
        }
    }();
    e.exports = a
}, function(e, t, n) {
    "use strict";
    var a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        },
        i = function() {
            function e(e, t) {
                var n = o.getCookie("qc");
                s.isBlankString(n) ? o.setCookie("qc", e) : n != e && (i(l + n), o.setCookie("qc", e));
                var a = o.getLocalStorage(l + e);
                t != a && (o.setLocalStorage(l + e, t), o.setInMem(l + e, t))
            }

            function t(e, t) {
                var n = o.getCookie("qc"),
                    a = "";
                if (!s.isBlankString(n)) s.isBlankString(e) || n == e ? o.getFromMem(l + n, {
                    success: function(e) {
                        !s.isBlankString(e) && e ? (a = e, o.setLocalStorage(l + n, e)) : a = o.getLocalStorage(l + n), t(a)
                    },
                    error: function() {
                        t(null)
                    }
                }) : (i(l + n), o.setCookie("qc", e), t(null));
                else {
                    var r = /^qc_/,
                        d = o.getKeysLocalStorage(r);
                    o.flushLocalStorage(d), o.delFromMem(d), t(null)
                }
            }

            function i(e, t) {
                if (t && (e = l + e), e) {
                    var n = [];
                    n.push(e), o.unsetCookie("qc"), o.flushLocalStorage(n), o.delFromMem(n)
                }
            }
            var o = n(18),
                s = n(3),
                r = n(16),
                l = "qc_";
            return {
                setChatSession: function(t) {
                    var n, i;
                    "string" == typeof t ? (n = "", i = "") : "object" == ("undefined" == typeof t ? "undefined" : a(t)) && (i = t.userState.email, s.isBlankString(i) && (i = t.userState.demail), n = JSON.stringify(t), n = s.B64encode(n)), e(i, n)
                },
                getChatSession: function(e, n) {
                    t(e, function(e) {
                        var t = null;
                        s.isBlankString(e) || (e = s.B64decode(e), t = r.prototype.fromJson(e)), n && n(t)
                    })
                },
                clearChatSession: i
            }
        }();
    e.exports = i
}, function(e, t, n) {
    "use strict";
    var a = n(10),
        i = n(9),
        o = function() {
            this.chatee, this.adDetails, this.uiState, this.isOnline
        };
    o.prototype.setInfo = function(e, t, n, a) {
        this.chatee = e, this.adDetails = t, this.uiState = n, this.isOnline = a
    }, o.prototype.copy = function(e) {
        var t = new a;
        t.setInfo(e.chatee.chatee);
        var n = new i;
        n.setInfo(e.adDetails.adDetails);
        var s = new o;
        return s.setInfo(t, n, e.uiState, e.isOnline), s
    }, e.exports = o
}, function(e, t, n) {
    "use strict";
    var a = n(17),
        i = n(15),
        o = function(e, t) {
            this.userState = e, this.cbsArray = t
        };
    o.prototype.fromJson = function(e) {
        var t = JSON.parse(e),
            n = a.prototype.copy(t.userState),
            s = [];
        for (var r in t.cbsArray) s.push(i.prototype.copy(t.cbsArray[r]));
        return new o(n, s)
    }, e.exports = o
}, function(e) {
    "use strict";
    var t = function() {
        this.jid, this.name, this.password, this.email, this.mobile, this.isLoggedIn, this.demail, this.authfail
    };
    t.prototype.setInfo = function(e, t, n, a, i, o, s, r) {
        this.jid = e, this.name = n, this.password = t, this.email = a, this.mobile = i, this.isLoggedIn = o, this.demail = s, this.authfail = r
    }, t.prototype.getInfo = function() {
        return {
            jid: this.jid,
            name: this.name,
            password: this.password,
            email: this.email,
            mobile: this.mobile,
            isLoggedIn: this.isLoggedIn,
            demail: this.demail,
            authfail: this.authfail
        }
    }, t.prototype.copy = function(e) {
        var n = new t;
        return n.setInfo(e.jid, e.password, e.name, e.email, e.mobile, e.isLoggedIn, e.demail, e.authfail), n
    }, e.exports = t
}, function(e, t, n) {
    "use strict";
    var a = n(3),
        i = n(0),
        o = {
            setInMem: function(e, t) {
                a.ajaxPost(i.config.MEM_URL, {
                    setKey: e,
                    memVal: t
                }, {
                    success: function() {},
                    error: function() {}
                }, !0, null)
            },
            delFromMem: function(e) {
                e.forEach(function(e) {
                    a.ajaxPost(i.config.MEM_URL, {
                        delKey: e
                    }, {
                        success: function() {},
                        error: function() {}
                    }, !0, null)
                })
            },
            getFromMem: function(e, t) {
                var n = "";
                return a.ajaxPost(i.config.MEM_URL, {
                    getKey: e
                }, {
                    success: function(e) {
                        n = JSON.parse(e).memVal, t && t.success && t.success(n)
                    },
                    error: function() {
                        t && t.error && t.error(n)
                    }
                }, !0, null), n
            },
            getCookie: function(e) {
                if (0 < document.cookie.length) {
                    var t = document.cookie.indexOf(e + "=");
                    if (-1 != t) {
                        t = t + e.length + 1;
                        var n = document.cookie.indexOf(";", t);
                        return -1 == n && (n = document.cookie.length), unescape(document.cookie.substring(t, n))
                    }
                }
                return ""
            },
            unsetCookie: function(e) {
                e && (document.cookie = e + "=; expires=Thu, 01 Jan 1970 00:00:01 GMT; path=/ ;Domain=.quikr.com")
            },
            setCookie: function(e, t, n) {
                var a;
                if (n) {
                    var i = new Date;
                    i.setTime(i.getTime() + 1e3 * (60 * (60 * (24 * n)))), a = "; expires=" + i.toGMTString()
                } else a = "";
                document.cookie = e + "=" + t + a + "; path=/ ;Domain=.quikr.com"
            },
            unsetLocalStorage: function(e) {
                return !!localStorage && (localStorage.removeItem(e), !0)
            },
            setLocalStorage: function(e, t) {
                return !!localStorage && (localStorage.setItem(e, t), !0)
            },
            getLocalStorage: function(e) {
                return !!localStorage && localStorage.getItem(e)
            },
            setSessionStorage: function(e, t) {
                return !!sessionStorage && (sessionStorage.setItem(e, t), !0)
            },
            getSessionStorage: function(e) {
                if (sessionStorage) return sessionStorage.getItem(e)
            },
            getKeysLocalStorage: function(e) {
                var t = [];
                if (localStorage)
                    for (var n = 0, a = localStorage.length; n < a; ++n) e.test(localStorage.key(n)) && t.push(localStorage.key(n));
                return t
            },
            flushLocalStorage: function(e) {
                e.forEach(function(e) {
                    o.unsetLocalStorage(e)
                })
            }
        };
    e.exports = o
}, function(e, t, n) {
    "use strict";
    var a = n(0),
        i = n(2).addCustomHandler,
        o = n(3),
        s = function() {
            var e = {
                    DEBUG: 0,
                    INFO: 1
                },
                t = 0,
                n = function(n) {
                    if (!o.isBlankString(n)) {
                        var a = n;
                        o.isObject(n) && (a = JSON.stringify(n)), t == e.DEBUG ? console.log(a) : t == e.INFO && s(a)
                    }
                },
                s = function(e) {
                    o.ajaxPost(a.config.LOG_ENDPOINT, {
                        details: e
                    }, {
                        success: function() {},
                        error: function() {}
                    }, !0)
                },
                r = function() {
                    i(function(e) {
                        if (e) var t = e.eventparams;
                        var i = {};
                        i = t.qUser, i.type = "modular", i.stage = "CONNECTED", i.autologin = a.config.AUTO_LOGIN;
                        var o = t.connection;
                        i.service = o.service, i.retry = o.retry, n(i)
                    }, a.EventEnum.CONNECTED, null, null), i(function(e) {
                        if (e) var t = e.eventparams;
                        var i = {};
                        i = t.qUser, i.type = "modular", i.stage = "CONNECTING", i.autologin = a.config.AUTO_LOGIN;
                        var o = t.connection;
                        i.service = o.service, i.retry = o.retry, n(i)
                    }, a.EventEnum.CONNECTING, null, null), i(function(e) {
                        if (e) var t = e.eventparams;
                        var i = {};
                        i = t.qUser, i.type = "modular", i.stage = "CONNECTIONFAIL", i.autologin = a.config.AUTO_LOGIN, i.condition = t.condition;
                        var o = t.connection;
                        i.service = o.service, i.retry = o.retry, n(i)
                    }, a.EventEnum.CONNECTIONFAIL, null, null), i(function(e) {
                        if (e) var t = e.eventparams;
                        var a = {};
                        a = t.qUser, a.type = "modular", a.stage = "AUTHFAIL", a.isAuthFail = t.qUser.authfail;
                        var i = t.connection;
                        a.service = i.service, a.retry = i.retry, n(a)
                    }, a.EventEnum.AUTHFAIL, null, null)
                };
            return {
                init: function(e) {
                    t = e, r()
                },
                doLog: n,
                LogLevelEnum: e
            }
        }();
    e.exports = s
}, , , function(e, t, n) {
    "use strict";
    var i = n(8);
    e.exports = {
        EscrowEndPoints: {
            MO: 0,
            EO: 1,
            CO: 2,
            RO: 3,
            WO: 4,
            AO: 5,
            CMO: 6
        },
        EscrowStatus: {
            INITIATE: 5,
            REJECTED: 6,
            ACCEPTED: 7,
            COUNTER: 8,
            ACCEPTANDPAID: 9,
            COUNTERANDPAID: 10,
            WITHDRAW: 11,
            COUNTEROFFERACCEPTED: 12
        },
        EscrowChatStatus: {
            INITIATE: 1,
            EDITOFFER: 2,
            REJECTED: 3,
            COUNTER: 4,
            ACCEPTED: 5,
            ACCEPTANDPAID: 6,
            WITHDRAW: 7,
            BUYERCOUNTER: 8
        },
        EscrowChatStatusMap: {
            1: 5,
            2: 5,
            3: 6,
            4: 8,
            5: 7,
            6: 9,
            7: 11,
            8: 5
        },
        EscrowMessages: {
            1: {
                chatMsg: "Offer Made: XXXX",
                title: "Offer Made",
                buyerSentHintMsg: "<p class=\"pre-txt\"><strong>Quikr Doorstep -</strong> Great! You just made an Offer. Now chat with Seller and get your offer Accepted. </p><ul class=\"listing\"><p>Benefits of <strong> getting Offer accepted</strong></p><li>Cashback eligibility*</li><li>Doorstep delivery of item</li><li>Secure online Payment</li></ul><p class=\"apply-txt\">*T&amp;C apply</p>",
                buyerRecvHintMsg: "",
                sellerSentHintMsg: "",
                sellerRecvHintMsg: "You have received an offer. You can accept the offer or propose a new price."
            },
            2: {
                chatMsg: "Offer Made: XXXX",
                title: "Offer Made",
                buyerSentHintMsg: "Your revised offer has been sent to the seller. Please wait for the seller to respond.",
                buyerRecvHintMsg: "",
                sellerSentHintMsg: "",
                sellerRecvHintMsg: "You have received an offer. You can accept the offer or propose a new price."
            },
            3: {
                chatMsg: "Offer Rejected: XXXX",
                title: "Offer Rejected",
                buyerSentHintMsg: "You have cancelled the transaction. We encourage you to make new offers to similar ads.",
                buyerRecvHintMsg: "",
                sellerSentHintMsg: "",
                sellerRecvHintMsg: "Sorry, buyer has cancelled the  transaction."
            },
            4: {
                chatMsg: "Counter Offer: XXXX",
                title: "Counter Offer",
                buyerSentHintMsg: "",
                buyerRecvHintMsg: " <p class=\"pre-txt\"><strong>Quikr Doorstep</strong> - This is the best price seller can offer. Do you think you can increase your budget a little? Go ahead and <strong>Accept Counter Offer</strong></p> ",
                sellerSentHintMsg: " <p class=\"pre-txt\"><strong>Quikr Doorstep</strong> - We have shared your counter offer with the buyer. ",
                sellerRecvHintMsg: ""
            },
            5: {
                chatMsg: "Offer Accepted: XXXX",
                title: "Offer Accepted",
                buyerSentHintMsg: "You accepted the offer. Please make the payment to initiate the delivery.",
                buyerRecvHintMsg: "<p class=\"pre-txt\"><strong>Quikr Doorstep</strong> - Hurray! Seller has accepted your Offer. Hurry up! Make Payment before the item is sold out. <strong class=\"script_epb\">Pay Now</strong></p>                     <ul class=\"listing\"> <p>Benefits of <strong> Paying online</strong></p> <li>Cashback eligibility*</li> <li>Doorstep delivery of item</li> <li>Secure online Payment</li>      </ul>                      <p class=\"apply-txt\">*T&amp;C apply</p>",
                sellerSentHintMsg: "We will schedule a pick-up after buyer makes the payment.",
                sellerRecvHintMsg: "Buyer has accepted the offer. We will schedule a pick-up after buyer makes the payment."
            },
            7: {
                chatMsg: "Offer Cancelled: XXXX",
                title: "Offer Cancelled",
                buyerSentHintMsg: "You have cancelled the transaction. We encourage you to make new offers to similar ads.",
                buyerRecvHintMsg: "",
                sellerSentHintMsg: "",
                sellerRecvHintMsg: "Sorry, buyer has cancelled the  transaction."
            },
            8: {
                chatMsg: "Offer Made: XXXX",
                title: "Offer Made",
                buyerSentHintMsg: "<p class=\"pre-txt\"><strong>Quikr Doorstep -</strong> Great! You just made an Offer. Now chat with Seller and get your offer Accepted. </p><ul class=\"listing\"><p>Benefits of <strong> getting Offer accepted</strong></p><li>Cashback eligibility*</li><li>Doorstep delivery of item</li><li>Secure online Payment</li></ul><p class=\"apply-txt\">*T&amp;C apply</p>",
                buyerRecvHintMsg: "",
                sellerSentHintMsg: "",
                sellerRecvHintMsg: "You have received an offer. You can accept the offer or propose a new price."
            }
        },
        CarsMessages: {
            1: {
                chatMsg: "Offer Made: XXXX",
                title: "Offer Made",
                buyerSentHintMsg: "<p class=\"pre-txt\"><strong>Quikr Cars -</strong> Great! You just made an Offer. Now chat with Seller and get your offer Accepted. ",
                buyerRecvHintMsg: "",
                sellerSentHintMsg: "",
                sellerRecvHintMsg: "You have received an offer. You can accept the offer or propose a new price."
            },
            2: {
                chatMsg: "Offer Made: XXXX",
                title: "Offer Made",
                buyerSentHintMsg: "Your revised offer has been sent to the seller. Please wait for the seller to respond.",
                buyerRecvHintMsg: "",
                sellerSentHintMsg: "",
                sellerRecvHintMsg: "You have received an offer. You can accept the offer or propose a new price."
            },
            3: {
                chatMsg: "Offer Rejected: XXXX",
                title: "Offer Rejected",
                buyerSentHintMsg: "You have cancelled the transaction. We encourage you to make new offers to similar ads.",
                buyerRecvHintMsg: "",
                sellerSentHintMsg: "",
                sellerRecvHintMsg: "Sorry, buyer has cancelled the  transaction."
            },
            4: {
                chatMsg: "Counter Offer: XXXX",
                title: "Counter Offer",
                buyerSentHintMsg: "",
                buyerRecvHintMsg: " <p class=\"pre-txt\"><strong>Quikr Cars</strong> - This is the best price seller can offer. Do you think you can increase your budget a little? Go ahead and <strong>Accept Counter Offer</strong></p> ",
                sellerSentHintMsg: " <p class=\"pre-txt\"><strong>Quikr Cars</strong> - We have shared your counter offer with the buyer. ",
                sellerRecvHintMsg: ""
            },
            5: {
                chatMsg: "Offer Accepted: XXXX",
                title: "Offer Accepted",
                buyerSentHintMsg: "You accepted the offer.",
                buyerRecvHintMsg: "<p class=\"pre-txt\"><strong>Quikr Cars</strong> - Hurray! Seller has accepted your Offer. Connect with the Seller to complete transaction. Thanks for using Quikr Cars. </p>",
                sellerSentHintMsg: "We will schedule a pick-up after buyer makes the payment.",
                sellerRecvHintMsg: "Buyer has accepted the offer. Thanks for using Quikr Cars."
            },
            7: {
                chatMsg: "Offer Cancelled: XXXX",
                title: "Offer Cancelled",
                buyerSentHintMsg: "You have cancelled the transaction. We encourage you to make new offers to similar ads.",
                buyerRecvHintMsg: "",
                sellerSentHintMsg: "",
                sellerRecvHintMsg: "Sorry, buyer has cancelled the  transaction."
            }
        },
        handleOutgoingMessage: function(e, t) {
            var n = {},
                o = [],
                s = [],
                r = "";
            s.push(i.esc.mof), s.push(i.esc.mo), s.push(i.esc.mod);
            var l = this.EscrowChatStatus;
            switch (parseInt(e)) {
                case l.INITIATE:
                case l.EDITOFFER:
                case l.BUYERCOUNTER:
                    r = i.esc.bso, o.push(r), s.push(i.esc.ep), t || s.push(i.esc.bro);
                    break;
                case l.COUNTER:
                    s.push(i.esc.sro);
                    break;
                case l.WITHDRAW:
                case l.REJECTED:
                    r = i.esc.mo, o.push(r), s.push(i.esc.bro), s.push(i.esc.bso);
                    break;
                case l.ACCEPTED:
                    t ? s.push(i.esc.sro) : (r = i.esc.ep, s.push(i.esc.bro), o.push(r));
            }
            return n.on = o, n.off = s, n.buttonBarClass = r, n
        },
        handleIncomingMessage: function(e, t) {
            var n = {},
                o = [],
                s = [],
                r = "";
            s.push(i.esc.mof), s.push(i.esc.mo), s.push(i.esc.mod);
            var l = this.EscrowChatStatus;
            switch (parseInt(e)) {
                case l.INITIATE:
                case l.EDITOFFER:
                case l.BUYERCOUNTER:
                    r = i.esc.sro, o.push(i.esc.sro);
                    break;
                case l.COUNTER:
                    r = i.esc.bro, o.push(i.esc.bro), s.push(i.esc.bso);
                    break;
                case l.WITHDRAW:
                    s.push(i.esc.sro);
                    break;
                case l.ACCEPTED:
                    t || (s.push(i.esc.bso), o.push(i.esc.ep), r = i.esc.ep);
            }
            return n.on = o, n.off = s, n.buttonBarClass = r, n
        },
        handleUIHistory: function(e, t) {
            var n = {},
                o = [],
                s = [],
                r = "";
            s.push(i.esc.mof), s.push(i.esc.mo);
            var l = this.EscrowStatus;
            switch (parseInt(e)) {
                case l.INITIATE:
                    r = t ? i.esc.sro : i.esc.bso, o.push(r);
                    break;
                case l.COUNTER:
                    t || (r = i.esc.bro, o.push(r));
                    break;
                case l.REJECTED:
                case l.WITHDRAW:
                    t || (r = i.esc.mo, o.push(r));
                    break;
                case l.ACCEPTED:
                case l.COUNTEROFFERACCEPTED:
                    t || (r = i.esc.ep, o.push(r));
                    break;
                case l.ACCEPTANDPAID:
                case l.COUNTERANDPAID:
                    t || (r = i.esc.eps, o.push(r));
            }
            return n.on = o, n.off = s, n.buttonBarClass = r, n
        },
        getEscrowHintMessage: function(e, t, n, a) {
            var i = !1;
            return this.EscrowMessages[e] && (0 === n ? i = t ? "cars" == a ? this.CarsMessages[e].sellerRecvHintMsg : this.EscrowMessages[e].sellerRecvHintMsg : "cars" == a ? this.CarsMessages[e].buyerRecvHintMsg : this.EscrowMessages[e].buyerRecvHintMsg : 1 === n ? i = t ? "cars" == a ? this.CarsMessages[e].sellerSentHintMsg : this.EscrowMessages[e].sellerSentHintMsg : "cars" == a ? this.CarsMessages[e].buyerSentHintMsg : this.EscrowMessages[e].buyerSentHintMsg : void 0), i
        }
    }
}, function(e, t, n) {
    "use strict";
    var a = n(3),
        i = n(35);
    e.exports = function(e, t) {
        var n;
        if ("block1" == e.id && (n = new i.block1), "block0" == e.id && (n = new i.block0), "chat" == e.type && "block0" != e.id && "block1" != e.id) switch (e.id) {
            case "vcard":
                n = new i.vcard;
                break;
            case "typing":
                n = new i.typing;
                break;
            case "presence":
                "off" == e.text && (n = new i.presenceoff);
                break;
            default:
                {
                    var o = e.id[4];
                    switch ("x" == o && (o = e.id[5]), o) {
                        case "a":
                            n = new i.audio;
                            break;
                        case "v":
                            (a.isBlankString(e.duration) || isNaN(e.duration)) && (e.duration = "0"), e.text += " " + e.duration, (a.isBlankString(e.filesize) || isNaN(e.filesize)) && (e.filesize = "0"), e.text += " " + e.filesize, n = new i.video;
                            break;
                        case "i":
                            n = new i.image;
                            break;
                        case "l":
                            n = new i.location;
                            break;
                        case "c":
                            n = new i.contact;
                            break;
                        case "e":
                            n = new i.escrow;
                            break;
                        case "t":
                            n = new i.text;
                            break;
                        case "d":
                            n = new i.document;
                            break;
                        case "s":
                            n = new i.server;
                            break;
                        case "p":
                            n = new i.promo;
                            break;
                        default:
                    }
                }
        } else n = "result" == e.type ? new i.acknowledge : new i.error;
        return n ? (n.config(e, t), n) : null
    }
}, function(e, t, n) {
    "use strict";
    var o = n(3),
        s = n(6),
        i = n(0),
        r = n(8),
        a = n(2),
        l = i.uiStatesEnum,
        d = i.modeEnum,
        c = i.EventEnum,
        g = n(7),
        m = function(e, t, n) {
            return e && t ? void(this.chatee = e, this.adDetails = t, this.chatterInfo = n, this.htmlContainer = null, this.lastActivityTimestamp = 0, this.uiState = l.CLOSED, this.mediaUploadCounter = 0, this.typingFlag = null, this.hasTyped = !1, this.isOnline = !0, this.mode = -1, this.chateeVcard, this.lastMessageFromHistoryTS, this.conversationCleared = !1, this.layerTicket = 0, this.isInputAllowed = !0, this.historyDetails = {}, this.pluginInitStatus = !1) : null
        };
    o.extend(m.prototype, {
        setLastActivityTimestamp: function() {
            var e = new Date;
            this.lastActivityTimestamp = e.getTime()
        },
        removeDateToast: function(e) {
            var t = o.queryOne(r.mbox, this.htmlContainer),
                n = ".toast-" + e.replace(/ /g, "_"),
                a = o.queryOne(n, t);
            a && t.removeChild(a)
        },
        attachDateToast: function(e, t, n) {
            e || (e = o.getToastMsgTimestamp(o.getTime()));
            var a = "toast-" + e.replace(/ /g, "_");
            o.queryOne(r.mbox, this.htmlContainer);
            var i = o.queryOne("." + a, o.queryOne(r.mbox, this.htmlContainer));
            i || (i = t.cloneNode(!0), o.addClass(i, a), o.addClass(i, "script_sys"), i.innerHTML = e, this.attachMessage(i, n))
        },
        uiAction: function(e, t) {
            switch (e) {
                case l.OPEN:
                    this.open(null, t);
                    break;
                case l.MINIMISED:
                    this.minimize(null, t);
                    break;
                case l.CLOSED:
                    this.close(null, t);
                    break;
                default:
            }
        },
        toggleWindow: function(e, t) {
            this.uiState == i.uiStatesEnum.OPEN ? this.minimize(e, t) : this.maximize(e, t)
        },
        maximize: function(e, t, g) {
            var m = c.L_MAX;
            if (this.uiState = l.OPEN, o.toggleDisplay(o.queryOne(r.minbox, this.htmlContainer), "on"), o.toggleDisplay(o.queryOne(r.type_con, this.htmlContainer), "on"), this.isInputAllowed)
                for (var u in r.on_min_hide) o.toggleDisplay(o.queryOne(r.on_min_hide[u], this.htmlContainer), "on");
            if (this.setLastActivityTimestamp(), n(4).saveState(), this.mode == d.CHATBOX) {
                this.scrollToBottom();
                var i = this.lastIncomingMessage;
                i && n(4).sendMessageAcknowledgment("seen", {
                    to: i.from,
                    adId: i.adId,
                    stime: i.stime,
                    id: i.id
                }), this.lastIncomingMessage = void 0, m = c.C_MAX, o.queryOne(r.st_i, this.htmlContainer).focus()
            }
            this.mode == d.LOGIN && o.queryOne(r.ip_n, this.htmlContainer).focus(), t || g || a.invokeHandlers(m, {
                adDetails: this.adDetails.getInfo(),
                qUser: s.getUserState().getInfo()
            })
        },
        minimize: function(e, t) {
            var s = this.mode == d.CHATBOX ? c.C_MIN : c.L_MIN;
            for (var g in this.uiState = l.MINIMISED, o.toggleDisplay(o.queryOne(r.minbox, this.htmlContainer), "off"), o.toggleDisplay(o.queryOne(r.type_con, this.htmlContainer), "off"), r.on_min_hide) o.toggleDisplay(o.queryOne(r.on_min_hide[g], this.htmlContainer), "off");
            this.htmlContainer.style.display = o.isMobile() ? "block" : "inline-block", n(4).saveState(), this.setLastActivityTimestamp(), t || a.invokeHandlers(s)
        },
        close: function(e, t) {
            var r = this.mode == d.CHATBOX ? c.C_CL : c.L_CL,
                g = n(4),
                m = g.getChatBoxes(l.OPEN, "ui"),
                u = g.getChatBoxes(l.MINIMISED, "ui").concat(m);
            1 == u.length && (o.queryOne("#" + i.config.CHAT_CONTAINER).style.display = "none"), this.uiState = l.CLOSED, this.htmlContainer.style.display = "none", this.setLastActivityTimestamp(), g.saveState(), t || a.invokeHandlers(r, {
                adDetails: this.adDetails.getInfo(),
                qUser: s.getUserState().getInfo()
            }), o.stopEventPropogation(e)
        },
        open: function(e, t) {
            var r = n(4);
            r.adjustChatBoxes(this), o.queryOne("#" + i.config.CHAT_CONTAINER).style.display = "block", this.uiState = l.OPEN, this.htmlContainer.style.display = o.isMobile() ? "block" : "inline-block";
            var g = this.mode == d.CHATBOX ? c.C_O : c.L_O;
            t || a.invokeHandlers(g, {
                adDetails: this.adDetails.getInfo(),
                qUser: s.getUserState().getInfo()
            }), this.maximize(e, t, !0), this.setLastActivityTimestamp()
        },
        popOutChat: function() {
            alert("Pop Out Feature Not Available")
        },
        flush: function() {
            this.htmlContainer.innerHTML = ""
        },
        loginUser: function() {
            (e = o.queryOne(r.ip_er, this.htmlContainer)) && (e.innerHTML = ""), (e = o.queryOne(r.ip_m_er, this.htmlContainer)) && (e.innerHTML = ""), (e = o.queryOne(r.ip_e_er, this.htmlContainer)) && (e.innerHTML = ""), (e = o.queryOne(r.ip_n_er, this.htmlContainer)) && (e.innerHTML = "");
            var e, t = "",
                n = "",
                a = "",
                i = "";
            (e = o.queryOne(r.ip_n, this.htmlContainer)) && (t = e.value.trim(), t.replace(/(<([^>]+)>)/ig, "")), (e = o.queryOne(r.ip_m, this.htmlContainer)) && (n = e.value.trim(), n.replace(/(<([^>]+)>)/ig, "")), (e = o.queryOne(r.ip_e, this.htmlContainer)) && (a = e.value.trim(), a.replace(/(<([^>]+)>)/ig, "")), (e = o.queryOne(r.ip_q, this.htmlContainer)) && (i = e.value.trim(), i.replace(/(<([^>]+)>)/ig, ""));
            var s = o.validateLoginForm(t, n, a, i);
            if (0 == s.code) {
                var l, d;
                switch (s.errorField) {
                    case "mobile":
                        l = r.ip_m_er, d = r.ip_m;
                        break;
                    case "email":
                        l = r.ip_e_er, d = r.ip_e;
                        break;
                    case "name":
                        l = r.ip_n_er, d = r.ip_n;
                        break;
                    case "question":
                        d = r.ip_q;
                    default:
                        l = r.ip_er;
                }
                return s.errorField = "", o.queryOne(l, this.htmlContainer).innerHTML = s.errorMessage, o.addClass(o.queryOne(d, this.htmlContainer), "field-error"), s
            }
            return {
                code: s.code,
                name: t,
                mobile: n,
                email: a,
                message: i
            }
        },
        toggleDivs: function(e) {
            var t = this.htmlContainer;
            if (0 < e.off.length)
                for (var n = 0; n < e.off.length; n++) o.queryAll(e.off[n], t).forEach(function(e) {
                    e.style.display = "none"
                });
            if (0 < e.on.length)
                for (var n = 0; n < e.on.length; n++) o.queryAll(e.on[n], t).forEach(function(e) {
                    e.style.display = "block"
                })
        },
        toggleInputControls: function(e) {
            if (!("on" == e && this.adDetails.isInactive())) {
                var t = this.htmlContainer,
                    n = [r.ipbar, r.t_s, r.t_a, this.buttonBar],
                    a = this;
                n.forEach(function(n) {
                    var i = o.queryOne(n, t);
                    o.toggleDisplay(i, e), a.isInputAllowed = i && "block" == i.style.display
                }), this.setLastActivityTimestamp()
            }
        },
        toggleLoadMore: function(e, t) {
            var n = o.queryOne(r.lmv, this.htmlContainer);
            n || (n = document.createElement("div"), o.addClass(n, r.lmv.substring(1)), o.addClass(n, r.sys.substring(1)), n.appendChild(e.cloneNode(!0))), "on" == t ? o.prepend(o.queryOne(r.mbox, this.htmlContainer), n) : "off" == t && o.toggleDisplay(n, "off")
        },
        toggleSoldOut: function(e) {
            var t = o.queryOne(r.soldbox, this.htmlContainer);
            o.toggleDisplay(t, e), e = "on" == e ? "off" : "on", this.toggleInputControls(e), this.setLastActivityTimestamp()
        },
        toggleInactiveAd: function(e) {
            var t = o.queryOne(r.inactivebox, this.htmlContainer);
            o.toggleDisplay(t, e), e = "on" == e ? "off" : "on", this.toggleInputControls(e), this.setLastActivityTimestamp()
        },
        toggleRelogin: function(e) {
            var t = o.queryOne(r.relbox, this.htmlContainer);
            o.toggleDisplay(t, e), e = "on" == e ? "off" : "on", this.toggleInputControls(e), this.setLastActivityTimestamp()
        },
        toggleEscrowBar: function(e, t) {
            if (!o.isBlankString(this.buttonBar)) {
                var n = o.queryOne(this.buttonBar, this.htmlContainer);
                o.toggleDisplay(n, t), this.setLastActivityTimestamp()
            }
        },
        toggleCarsMAO: function(e, t) {
            if (!o.isBlankString(this.buttonBar)) {
                var n = o.queryOne(this.buttonBar, this.htmlContainer);
                o.toggleDisplay(n, t), this.setLastActivityTimestamp()
            }
        },
        togglePopupLayer: function(e, t) {
            if (this.layerTicket == i.layerTicket.NONE || this.layerTicket == e) {
                this.layerTicket = e;
                var n = o.queryOne(r.pop_lyr, this.htmlContainer);
                o.toggleDisplay(n, t), n && "none" == n.style.display && (this.layerTicket = i.layerTicket.NONE)
            }
        },
        toggleSettings: function(e, t) {
            var n = o.queryOne(r.boxes.setbox, this.htmlContainer);
            o.toggleDisplay(n, t), o.stopEventPropogation(e), this.setLastActivityTimestamp()
        },
        toggleAttachements: function(e, t) {
            var n = o.queryOne(r.boxes.attbox, this.htmlContainer);
            o.toggleDisplay(n, t), o.stopEventPropogation(e), this.setLastActivityTimestamp()
        },
        toggleCanned: function(e, t) {
            if (o.queryOne(r.cna, this.htmlContainer)) {
                var n = o.queryOne(r.cna, this.htmlContainer).getElementsByTagName("li");
                if (n.length) {
                    var i = o.queryOne(r.boxes.canbox, this.htmlContainer);
                    o.toggleDisplay(i, t), o.stopEventPropogation(e);
                    var a = o.queryOne(r.cp_a, this.htmlContainer);
                    i && ("none" === i.style.display ? o.removeClass(a, r.if_canbox.replace(".", "")) : o.addClass(a, r.if_canbox.replace(".", ""))), this.setLastActivityTimestamp()
                }
            }
        },
        toggleBlockConfirmationPopup: function(e, t) {
            var n = o.queryOne(r.boxes.bcbox, this.htmlContainer);
            o.toggleDisplay(n, t), this.togglePopupLayer(i.layerTicket.BL, t), o.stopEventPropogation(e), this.setLastActivityTimestamp()
        },
        toggleGCMPopup: function(e, t) {
            var n = o.queryOne(r.boxes.gcmbox, this.htmlContainer);
            o.toggleDisplay(n, t), this.togglePopupLayer(i.layerTicket.GCM, t), o.stopEventPropogation(e), this.setLastActivityTimestamp()
        },
        toggleUnblockConfirmationPopup: function(e, t) {
            var n = o.queryOne(r.boxes.ubcbox, this.htmlContainer);
            o.toggleDisplay(n, t), this.togglePopupLayer(i.layerTicket.UBL, t), o.stopEventPropogation(e), this.setLastActivityTimestamp()
        },
        toggleClearConfirmationPopup: function(e, t) {
            var n = o.queryOne(r.boxes.ccbox, this.htmlContainer);
            o.toggleDisplay(n, t), this.togglePopupLayer(i.layerTicket.CC, t), o.stopEventPropogation(e), this.setLastActivityTimestamp()
        },
        toggleContactForm: function(e, t) {
            var n = o.queryOne(r.boxes.conbox, this.htmlContainer);
            o.toggleDisplay(n, t), this.togglePopupLayer(i.layerTicket.CON, t), n && "block" == n.style.display && (o.queryOne(r.ip_c_n, n) && (o.queryOne(r.ip_c_n, n).value = s.name), o.queryOne(r.ip_c_m, n) && (o.queryOne(r.ip_c_m, n).value = s.mobile), o.queryOne(r.ip_c_e, n) && (o.queryOne(r.ip_c_e, n).value = s.email)), o.stopEventPropogation(e), this.setLastActivityTimestamp()
        },
        toggleAllPopups: function(e, t) {
            var n = {
                contact: this.toggleContactForm,
                clearconversation: this.toggleClearConfirmationPopup,
                attachment: this.toggleAttachements,
                unblock: this.toggleUnblockConfirmationPopup,
                block: this.toggleBlockConfirmationPopup,
                settings: this.toggleSettings,
                canned: this.toggleCanned,
                gcm: this.toggleGCMPopup
            };
            for (var a in n) a != t && n[a].bind(this, null, e)()
        },
        clearConversation: function(e) {
            var t = o.queryOne(r.mbox, this.htmlContainer),
                n = o.queryOne(r.msgdel, this.htmlContainer);
            "on" == e ? (o.queryAll(r.sys, t).forEach(function(e) {
                o.removeElement(e)
            }), o.toggleDisplay(n, "on"), this.setLastActivityTimestamp(), this.conversationCleared = !0) : "off" == e && (o.toggleDisplay(n, "off"), this.conversationCleared = !1), window.setTimeout(function() {
                o.removeElement(n)
            }, 3e3)
        },
        blockUnblockChatbox: function(e) {
            "block" == e ? (o.queryOne(r.bbox, this.htmlContainer).style.display = "", this.toggleInputControls("off")) : "unblock" == e && (o.queryOne(r.bbox, this.htmlContainer).style.display = "none", this.toggleInputControls("on")), this.setLastActivityTimestamp()
        },
        getLocation: function(e) {
            n(4).shareLocation(this, this.getStropheChatMessageObject({
                presenceStatus: "o",
                message: e,
                msgId: null,
                mediatype: "l",
                mediasubtype: "l",
                adId: this.chatee.getInfo().adid,
                toId: this.chatee.getInfo().jid
            }))
        },
        getContact: function() {
            var e, t, n, a, i;
            "none" == o.queryOne(r.boxes.conbox, this.htmlContainer).style.display ? (e = s.name, t = s.mobile, n = s.email) : (i = !0, e = o.queryOne(r.ip_c_n, this.htmlContainer).value, t = o.queryOne(r.ip_c_m, this.htmlContainer).value, n = o.queryOne(r.ip_c_e, this.htmlContainer).value);
            var a = o.validateContactForm(e, t, n);
            if (1 != a.code) return i && (o.queryOne(r.ip_c_err, this.htmlContainer).innerHTML = a.errorMessage), null;
            var l = "name: " + e + ", phone: " + t + ", email: " + n;
            return s.name = e, s.mobile = t, this.getStropheChatMessageObject({
                presenceStatus: "o",
                message: l,
                msgId: null,
                mediatype: "c",
                mediasubtype: "c",
                adId: this.chatee.getInfo().adid,
                toId: this.chatee.getInfo().jid
            })
        },
        displayChatMessage: function(e, t, n, i, s, l) {
            if (!o.isBlankString(i)) {
                var d = i.cloneNode(!0);
                switch (d.id = n, o.addClass(d, r.sys.substring(1)), s) {
                    case "contact":
                        e = o.parseContactMessage(e), o.queryOne(r.con_n, d).innerHTML = e.name, o.queryOne(r.con_m, d).innerHTML = e.phone, o.queryOne(r.con_e, d).innerHTML = e.email;
                        break;
                    case "text":
                        o.queryOne(r.msg, d).innerHTML = o.textLinkify(e);
                        break;
                    case "location":
                        o.queryOne(r.msg, d).innerHTML = o.textLinkify(e);
                        break;
                    case "image":
                        if (e = e.replace("_sm", ""), 0 > e.indexOf("_sm")) {
                            var g = e.split(".");
                            g = g[g.length - 1];
                            var m = e.replace("." + g, "_sm." + g)
                        }
                        o.queryOne(r.img, d).setAttribute("src", m), o.queryOne(r.i_click2dl, d).onclick = function() {
                            o.onMediaClick(d, e, "image")
                        };
                        break;
                    case "server":
                    case "promo":
                        var u, p, _, f, h, y = e.msg,
                            I = e.msg1,
                            E = e.image,
                            C = e.buttons,
                            O = e.links;
                        e.title && (o.queryOne(r.smt, d).innerHTML = e.title), o.isBlankString(y) || (o.queryOne(r.smt_1, d).innerHTML = o.textLinkify(y)), o.isBlankString(I) || (o.queryOne(r.smt_2, d).innerHTML = o.textLinkify(I)), o.isBlankString(C) || (u = C[0], u && (o.queryOne(r.smb_1_t, o.queryOne(r.smb_1, d)).innerHTML = u.title, 1 == u.actionType && (_ = decodeURIComponent(u.action).replace(/^quikr:\/\//, "http://"), o.queryOne(r.smb_1, d).onclick = function() {
                            o.onMediaClick(d, _, "view"), a.invokeHandlers(c.SS_B1C)
                        })), u = C[1], u && (o.queryOne(r.smb_1_t, o.queryOne(r.smb_1, d)).innerHTML = u.title, 1 == u.actionType && (_ = decodeURIComponent(u.action).replace(/^quikr:\/\//, "http://"), o.queryOne(r.smb_1, d).onclick = function() {
                            o.onMediaClick(d, _, "view"), a.invokeHandlers(c.SS_B1C)
                        }))), o.isBlankString(O) || (p = O[0], p && (o.queryOne(r.smb_1_t, o.queryOne(r.smb_1, d)).innerHTML = p.title, 1 == p.actionType && (_ = decodeURIComponent(p.action).replace(/^quikr:\/\//, "http://"), o.queryOne(r.smb_1, d).onclick = function() {
                            o.onMediaClick(d, _, "view"), a.invokeHandlers(c.SS_B1C)
                        }))), o.isBlankString(E) || (h = decodeURIComponent(E.imageUrl), o.queryOne(r.smi, d).src = decodeURIComponent(h), 1 == E.actionType && (f = decodeURIComponent(E.action).replace(/^quikr:\/\//, "http://"), o.queryOne(r.smi, d).onclick = function() {
                            o.onMediaClick(d, f, "view")
                        }));
                        break;
                    case "document":
                        var m = e.split("|"),
                            T = m[1],
                            M = o.formatFileSize(m[2]);
                        o.queryOne(r.d_size, d).innerHTML = M, o.queryOne(r.d_title, d).innerHTML = o.truncateString(T, 30), o.queryOne(r.d_click2dl, d).onclick = function() {
                            o.onMediaClick(d, m[0], "document")
                        };
                        break;
                    case "video":
                        var m = e.split(" "),
                            b = o.formatFileSize(m[2]),
                            v = m[0].replace(/\.mp4/, "_sm.jpeg");
                        o.queryOne(r.v_size, d).innerHTML = b, o.queryOne(r.v_img, d).setAttribute("src", v), o.queryOne(r.v_click2dl, d).onclick = function() {
                            o.onMediaClick(d, m[0], "video")
                        };
                }
                o.queryOne(r.msg_time, d).innerHTML = o.getMsgTimestamp(t), this.attachMessage(d, l)
            }
        },
        toggleUploadProgressBar: function(e, t, n) {
            if ("on" == e) {
                var i = document.createElement("div");
                i.id = "med_" + ++this.mediaUploadCounter, i.appendChild(n.cloneNode(!0)), this.attachMessage(i)
            } else if ("off" == e) {
                var s = o.queryOne(r.mbox, this.htmlContainer),
                    a = o.queryOne("#med_" + t, s);
                o.removeElement(a)
            }
        },
        uploadProgress: function(t, n, e, i, s) {
            var l = o.queryOne(r.mbox, this.htmlContainer),
                a = o.queryOne("#med_" + t, l),
                d = o.queryOne(r.upprog_bar, a),
                c = o.queryOne(r.upprog_text, a);
            d.style.width = s, c.innerHTML = s
        },
        beforePhotoUpload: function() {
            this.setLastActivityTimestamp(), o.queryOne(".object", this.htmlContainer).click()
        },
        getPhoto: function(e, t) {
            var n = e.target.files[0],
                a = n.name.toLowerCase(),
                s = a.substring(a.lastIndexOf(".") + 1),
                r = n.size,
                l = o.validateMediaUpload(a, s, r, i.config.MAX_IMG_FILE_SIZE, i.config.ALLOWED_IMG_EXT),
                d = this.mediaUploadCounter;
            if (0 == l.code) return this.toggleUploadProgressBar("off", d), this.generalError(l.errorMessage), !1;
            if (1 == l.code) {
                var c = null;
                if (FormData && (c = new FormData, c.append("object", n)), "c" == i.config.ALLOWED_IMG_EXT[s]);
                else {
                    var g = this;
                    o.ajaxUpload(i.config.IMAGE_API_DOMAIN, c, {
                        success: function(e) {
                            if (!o.isBlankString(e))
                                if (e = JSON.parse(e), "success" == e.status) {
                                    var n = {},
                                        a = e.fileurl,
                                        i = e.filename.replace("o1_", ""),
                                        s = i.split(".")[0],
                                        l = i.split(".")[1];
                                    a = a.replace(s + "_sm." + l, i), n = g.getStropheChatMessageObject({
                                        presenceStatus: "o",
                                        message: a,
                                        msgId: null,
                                        mediatype: "i",
                                        mediasubtype: "i",
                                        adId: g.chatee.getInfo().adid,
                                        toId: g.chatee.getInfo().jid,
                                        fileSize: r
                                    }), g.toggleUploadProgressBar("off", d), t && t(n)
                                } else g.toggleUploadProgressBar("off", d), g.generalError("Unable to send. Please try again.")
                        },
                        uploadProgress: function(t, e, n, a) {
                            g.uploadProgress(d, t, e, n, a)
                        },
                        timeout: function() {
                            g.toggleUploadProgressBar("off", d), g.generalError("Unable to send. Please try again.")
                        }
                    }, !0)
                }
            }
            return o.queryOne(".object", this.htmlContainer).value = "", !0
        },
        beforeVideoUpload: function() {
            this.setLastActivityTimestamp(), o.queryOne(".objectVideo", this.htmlContainer).click()
        },
        getVideo: function(e, t) {
            var n = e.target.files[0],
                a = n.name.toLowerCase(),
                s = a.substring(a.lastIndexOf(".") + 1),
                r = n.size,
                l = o.validateMediaUpload(a, s, r, i.config.MAX_VID_FILE_SIZE, i.config.ALLOWED_VID_EXT),
                d = this.mediaUploadCounter;
            if (0 == l.code) return this.toggleUploadProgressBar("off", d), this.generalError(l.errorMessage), !1;
            if (1 == l.code) {
                var c = null;
                FormData && (c = new FormData, c.append("object", n), c.append("content", "video"));
                var g = this;
                o.ajaxUpload(i.config.IMAGE_API_DOMAIN, c, {
                    success: function(e) {
                        if (!o.isBlankString(e))
                            if (e = JSON.parse(e), "success" == e.status) {
                                var n = {},
                                    a = e.fileurl;
                                a = a, n = g.getStropheChatMessageObject({
                                    presenceStatus: "o",
                                    message: a,
                                    msgId: null,
                                    mediatype: "v",
                                    mediasubtype: "v",
                                    adId: g.chatee.getInfo().adid,
                                    toId: g.chatee.getInfo().jid,
                                    fileSize: r,
                                    duration: "0"
                                }), g.toggleUploadProgressBar("off", d), t && t(n, d)
                            } else g.toggleUploadProgressBar("off", d), g.generalError("Unable to send. Please try again.")
                    },
                    uploadProgress: function(t, e, n, a) {
                        g.uploadProgress(d, t, e, n, a)
                    },
                    timeout: function() {
                        g.toggleUploadProgressBar("off", d), g.generalError("Unable to send. Please try again.")
                    }
                }, !0), o.queryOne(".objectVideo", this.htmlContainer).value = ""
            }
            return !0
        },
        attachMessage: function(e, t) {
            var n = o.queryOne(r.mbox, this.htmlContainer);
            if (t ? n.insertBefore(e, n.firstChild) : n.appendChild(e), this.conversationCleared && this.clearConversation("off"), this.setLastActivityTimestamp(), !1 == t) try {
                for (var a = document.querySelectorAll(".promo-banner-m"), s = a.length - 1; 0 <= s; s--) a[s].style.opacity = 0.1, a[s].style["pointer-events"] = "none", a[s].outerHTML.indexOf("ad-banner-content") || a[s].classList.add("chat-banner-disabled");
                var i = document.querySelector(".promo-banner-m").cloneNode(!0);
                i.style.opacity = 1, i.style["pointer-events"] = "all", i.className = "promo-banner-clone", i.classList.remove("chat-banner-disabled");
                for (var l = document.querySelectorAll(".ChatMessageDate"), s = l.length - 1; 0 <= s; s--) - 1 < l[s].outerHTML.indexOf("201") && !(-1 < l[s].nextSibling.outerHTML.indexOf("promo-banner-clone")) && l[s].parentElement.insertBefore(i.cloneNode(!0), l[s].nextSibling)
            } catch (t) {}
        },
        shareLocation: function() {
            alert("Share Location Feature Not Available")
        },
        shareAudio: function() {
            alert("Share Audio Feature Not Available")
        },
        getTextMessage: function(e, t, n) {
            var a = "";
            return t ? a = t : (a = o.queryOne(r.st_i, this.htmlContainer).innerHTML.trim(), a = a.replace(/(<([^>]+)> )/ig, ""), a = a.replace(/&lt;|&gt;|&gt;&lt;/ig, ""), a = o.removeDivEditableLines(a), o.queryOne(r.st_i, this.htmlContainer).innerHTML = ""), o.isBlankString(a) || a == n ? void 0 : this.getStropheChatMessageObject({
                presenceStatus: "o",
                message: a,
                msgId: null,
                mediatype: "t",
                mediasubtype: "t",
                adId: this.chatee.getInfo().adid,
                toId: this.chatee.getInfo().jid
            })
        },
        sendVcard: function() {
            this.setLastActivityTimestamp();
            var e;
            return e = "{'email':'" + s.email + "','name':'" + s.name + "','phone':'" + s.mobile + "'}", this.getStropheChatMessageObject({
                presenceStatus: null,
                message: e,
                msgId: "vcard",
                mediatype: null,
                mediasubtype: null,
                adId: this.chatee.getInfo().adid,
                toId: this.chatee.getInfo().jid
            })
        },
        setVcard: function(e) {
            if ("string" == typeof e) {
                e = decodeURIComponent(e), e = decodeURI(e), e = e.replace(/&apos;/g, "'");
                try {
                    e = eval("(" + e + ")")
                } catch (t) {}
            }
            e.name || (e.name = e.email.substr(0, e.email.indexOf("@"))), this.chateeVcard = e, g.setVcard({
                adId: this.adDetails.getInfo().adId,
                buddy: this.chatee.getInfo().jid,
                owner: s.jid,
                vcard: e
            }), o.queryAll(r.ct, this.htmlContainer).forEach(function(t) {
                t.innerHTML = e.name
            }), this.setLastActivityTimestamp()
        },
        isPoster: function() {
            return s.email && this.adDetails.getInfo().adEmail == s.email || s.demail && this.adDetails.getInfo().adDEmail == s.demail
        },
        isSeller: function() {
            return this.isPoster() && "offer" == this.adDetails.getInfo().adType
        },
        isEscrowLowTouch: function() {
            return this.isSeller() && this.adDetails.getInfo().isEscrowLowTouch
        },
        getStropheChatMessageObject: function(e) {
            var t = e.fileSize ? e.fileSize : "",
                n = e.duration ? e.duration : "",
                a = new Date,
                s = a.getTime();
            if (o.isBlankString(e.msgId)) {
                var r = this.isPoster() ? "p" : "s";
                e.msgId = i.config.CLIENT + "e" + r + e.presenceStatus + e.mediatype + e.mediasubtype + "-100_", e.msgId += "e" == e.mediatype && e.offerId ? e.offerId : a.getTime()
            }
            return {
                id: e.msgId,
                message: e.message,
                adId: e.adId,
                to: e.toId,
                type: "chat",
                fileSize: t,
                duration: n,
                stime: s
            }
        },
        showNotification: function(e, t, n, i) {
            this.setLastActivityTimestamp(), a.invokeHandlers(c.R_N, {
                title: this.chatee.getEmail(),
                email: this.chatee.getEmail(),
                adDetails: this.adDetails.getInfo(),
                text: e,
                time: t,
                type: i,
                vcard: this.chateeVcard,
                openChat: this.open.bind(this, null, !1)
            })
        },
        setMessageAcknowledgment: function(e, t, n) {
            var a;
            "sent" === e ? a = "Sent" : "sending" === e ? a = "Sending" : "seen" === e ? (a = "Seen", o.queryAll(r.msg_ack, this.htmlContainer).forEach(function(e) {
                e.innerHTML = ""
            })) : void 0;
            o.queryOne(r.msg_ack, o.queryOne("#" + n, this.htmlContainer)).innerHTML = a
        },
        toggleTypingStatus: function(e) {
            if ("1" != e) "0" == e && o.queryAll(r.typing, this.htmlContainer).forEach(function(e) {
                e.innerHTML = " "
            });
            else if (o.queryAll(r.typing, this.htmlContainer).forEach(function(e) {
                    e.innerHTML = "typing...."
                }), !this.intervalTypingFlag) {
                var t = this;
                this.intervalTypingFlag = setTimeout(function() {
                    t.toggleTypingStatus("0"), clearTimeout(t.intervalTypingFlag), t.intervalTypingFlag = null
                }, 7800)
            }
            this.setLastActivityTimestamp()
        },
        getTypingStatus: function(e) {
            if (18 != e.which && 18 != e.keyCode && 116 != e.which && 116 != e.keyCode) {
                var t = o.queryOne(r.st_i, this.htmlContainer).innerHTML.trim();
                if (!this.typingStatus && (8 == e.which || 8 == e.keyCode) && !o.isBlankString(t)) {
                    this.typingStatus = !0;
                    var n = new Date;
                    return {
                        to: this.chatee.getInfo().jid,
                        adId: this.chatee.getInfo().adid,
                        type: "chat",
                        stime: n.getTime(),
                        id: "typing",
                        message: "1"
                    }
                }
                if (!this.typingFlag) {
                    var a = this;
                    this.typingFlag = setTimeout(function() {
                        a.typingStatus = !1, clearTimeout(a.typingFlag), a.typingFlag = null
                    }, 8e3)
                }
                this.setLastActivityTimestamp()
            }
        },
        scrollToBottom: function() {
            o.queryOne(r.mscroll, this.htmlContainer).scrollTop = o.queryOne(r.mscroll, this.htmlContainer).scrollHeight, o.isMobile() && (document.getElementById(i.config.CHAT_CONTAINER).scrollTop = document.getElementById(i.config.CHAT_CONTAINER).scrollHeight)
        },
        scrollToTop: function() {
            o.queryOne(r.mbox, this.htmlContainer).scrollTop = 0, o.isMobile() && (document.getElementById(i.config.CHAT_CONTAINER).scrollTop = 0)
        },
        chatBoxTip: function(e) {
            o.isBlankString(e) || o.queryAll(r.off_tip, this.htmlContainer).forEach(function(t) {
                o.toggleDisplay(t, e)
            })
        },
        chateeOffline: function() {
            this.isOnline = !1, o.queryAll(r.on, this.htmlContainer).forEach(function(e) {
                o.toggleDisplay(e, "off")
            }), o.queryAll(r.off, this.htmlContainer).forEach(function(e) {
                o.toggleDisplay(e, "on")
            }), o.queryAll(r.pr_t, this.htmlContainer).forEach(function(e) {
                e.innerHTML = "Offline"
            }), this.chatBoxTip("on")
        },
        chateeOnline: function() {
            this.isOnline = !0, o.queryAll(r.on, this.htmlContainer).forEach(function(e) {
                o.toggleDisplay(e, "on")
            }), o.queryAll(r.off, this.htmlContainer).forEach(function(e) {
                o.toggleDisplay(e, "off")
            }), o.queryAll(r.pr_t, this.htmlContainer).forEach(function(e) {
                e.innerHTML = "Online"
            }), this.chatBoxTip("off")
        },
        toggleOnlineStatus: function(e) {
            e ? this.chateeOnline() : this.chateeOffline()
        },
        shouldPoll: function() {
            return this.uiState == l.OPEN || this.uiState == l.MINIMISED
        },
        checkMessageDisplayed: function(e) {
            return !!o.queryOne("#" + e, this.htmlContainer)
        },
        sendCarsOffer: function(e, t) {
            var n = this.htmlContainer,
                a = this.offerId,
                i = o.queryOne(r.esc.mof_p, n).value,
                s = this.getEscrowMsg(i, a);
            o.isUndefined(e) || o.isUndefined(e.updateSeller) || (s.params.offerId = s.params.offer_id, s.params = o.mergeObject(s.params, e)), s.params && s.msg && this.callEscrowAPI(s, t)
        },
        generalError: function(e) {
            if (!o.isBlankString(e)) {
                var t = o.queryOne(r.gen_err_container, this.htmlContainer);
                o.toggleDisplay(t, "on"), o.queryOne(r.gen_err_text, t).innerHTML = e
            }
            window.setTimeout(function() {
                o.toggleDisplay(t, "off")
            }, 3e3)
        },
        dispatchPluginAction: function(e, t) {
            if ("Init" == e && this.pluginInitStatus) return !1;
            var n = "dispatchPlugin" + e + "Action";
            if (this[n]) {
                this[n](t || null)
            }
        }
    }), e.exports = m
}, function(e) {
    "use strict";
    var t = function(e, t, n, a) {
        this.handler = e, this.eventName = t, this.params = n, this.vol = a
    };
    t.prototype = {
        run: function(e) {
            try {
                var t = {};
                return t.customparams = this.params, t.eventparams = e, t.eventparams || t.customparams ? this.handler(t) : this.handler(), this.vol
            } catch (t) {
                console.log(t)
            }
        }
    }, e.exports = t
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = function() {
            this.type = "acknowledge", this.handleIncomingMessage = function(e) {
                e.setMessageAcknowledgment(this.msg.text, this.msg.stime, this.msg.id)
            }
        };
    i.prototype = Object.create(a), e.exports = i
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = function() {
            this.type = "audio", this.handleIncomingMessage = function() {}, this.handleOutgoingMessage = function() {}, this.sendAck = !0
        };
    i.prototype = Object.create(a), e.exports = i
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = function() {
            this.type = "block", this.handleIncomingMessage = function() {}
        };
    i.prototype = Object.create(a), e.exports = i
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = function() {
            this.type = "block", this.handleIncomingMessage = function(e) {
                e.blockUnblockChatbox("block")
            }, this.handleHistoryMessage = function() {}
        };
    i.prototype = Object.create(a), e.exports = i
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = n(2).invokeHandlers,
        o = n(0).EventEnum,
        s = function e() {
            this.type = "contact", this.handleOutgoingMessage = function(t) {
                t.toggleContactForm(null, "off"), e.prototype.handleOutgoingMessage.call(this, t), i(o.S_C)
            }, this.handleIncomingMessage = function(t) {
                e.prototype.handleIncomingMessage.call(this, t), i(o.R_C)
            }, this.sendAck = !0
        };
    s.prototype = Object.create(a), e.exports = s
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = n(2).invokeHandlers,
        o = n(0).EventEnum,
        s = function e() {
            this.type = "document", this.handleOutgoingMessage = function(t) {
                e.prototype.handleOutgoingMessage.call(this, t), i(o.S_D)
            }, this.handleHistoryMessage = function(t) {
                this.msg.text = this.msg.text + "|" + this.msg.filesize, e.prototype.handleHistoryMessage.call(this, t)
            }, this.handleIncomingMessage = function(t) {
                this.msg.text = this.msg.text + "|" + this.msg.filesize, e.prototype.handleIncomingMessage.call(this, t), i(o.R_D)
            }, this.sendAck = !0
        };
    s.prototype = Object.create(a), e.exports = s
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = function() {
            this.type = "error", this.handleOutgoingMessage = function() {}, this.handleIncomingMessage = function() {}, this.handleHistoryMessage = function() {}, this.sendAck = !1
        };
    i.prototype = Object.create(a), e.exports = i
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = n(22),
        o = function e() {
            this.type = "escrow", this.handleIncomingMessage = function(t) {
                var n = document.createElement("div");
                n.innerHTML = t.escrowMessages.incomingMessage(this.msg), n.id = this.msg.id, n.className += "script_sys", t.attachMessage(n), e.prototype.handleIncomingMessage.call(this, t, n)
            }, this.handleOutgoingMessage = function(t) {
                var n = document.createElement("div");
                n.innerHTML = t.escrowMessages.outgoingMessage(this.msg), n.id = this.msg.id, n.className += "script_sys", e.prototype.handleOutgoingMessage.call(this, t, n)
            }, this.handleHistoryMessage = function(t) {
                var n = document.createElement("div");
                "" != this.msg.text && (n.innerHTML = 1 == this.msg.direction ? t.escrowMessages.outgoingMessage(this.msg, !0) : t.escrowMessages.incomingMessage(this.msg, !0), n.id = this.msg.id, n.className += "script_sys", e.prototype.handleHistoryMessage.call(this, t, n))
            }, this.sendAck = !0
        };
    o.prototype = Object.create(a), e.exports = o
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = n(2).invokeHandlers,
        o = n(0).EventEnum,
        s = function e() {
            this.type = "image", this.handleOutgoingMessage = function(t) {
                e.prototype.handleOutgoingMessage.call(this, t), i(o.S_I)
            }, this.handleIncomingMessage = function(t) {
                e.prototype.handleIncomingMessage.call(this, t), i(o.R_I)
            }, this.sendAck = !0
        };
    s.prototype = Object.create(a), e.exports = s
}, function(e, t, n) {
    "use strict";
    e.exports = {
        acknowledge: n(26),
        audio: n(27),
        base: n(1),
        block0: n(28),
        block1: n(29),
        contact: n(30),
        document: n(31),
        error: n(32),
        escrow: n(33),
        image: n(34),
        location: n(36),
        presenceOff: n(37),
        promo: n(38),
        server: n(39),
        text: n(40),
        typing: n(41),
        vcard: n(42),
        video: n(43)
    }
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = n(2).invokeHandlers,
        o = n(0).EventEnum,
        s = function e() {
            this.type = "location", this.sendAck = !0, this.handleIncomingMessage = function(t) {
                e.prototype.handleIncomingMessage.call(this, t), i(o.R_L)
            }, this.handleOutgoingMessage = function(t) {
                e.prototype.handleOutgoingMessage.call(this, t), i(o.S_L)
            }
        };
    s.prototype = Object.create(a), e.exports = s
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = function() {
            this.type = "presenceoff", this.handleIncomingMessage = function(e) {
                e.chateeOffline()
            }
        };
    i.prototype = Object.create(a), e.exports = i
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = n(2).invokeHandlers,
        o = n(0).EventEnum,
        s = function e() {
            this.type = "promo", this.handleOutgoingMessage = function() {}, this.handleIncomingMessage = function(t) {
                this.msg.text = JSON.parse(this.msg.metadata), e.prototype.handleIncomingMessage.call(this, t), i(o.R_PM)
            }, this.handleHistoryMessage = function() {}, this.sendAck = !0
        };
    s.prototype = Object.create(a), e.exports = s
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = n(2).invokeHandlers,
        o = n(0).EventEnum,
        s = function e() {
            this.type = "server", this.handleOutgoingMessage = function() {}, this.handleIncomingMessage = function(t) {
                this.msg.text = JSON.parse(this.msg.metadata), e.prototype.handleIncomingMessage.call(this, t), i(o.R_SM)
            }, this.handleHistoryMessage = function(t) {
                this.msg.text = JSON.parse(this.msg.metadata), e.prototype.handleHistoryMessage.call(this, t)
            }, this.sendAck = !0
        };
    s.prototype = Object.create(a), e.exports = s
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = n(2).invokeHandlers,
        o = n(0).EventEnum,
        s = function e() {
            this.type = "text", this.handleOutgoingMessage = function(t) {
                e.prototype.handleOutgoingMessage.call(this, t), i(o.S_T, {
                    ad: t.adDetails,
                    isSeller: !!("function" == typeof t.isSeller && t.isSeller())
                })
            }, this.handleIncomingMessage = function(t) {
                e.prototype.handleIncomingMessage.call(this, t), i(o.R_T)
            }, this.sendAck = !0
        };
    s.prototype = Object.create(a), e.exports = s
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = function() {
            this.type = "typing", this.handleIncomingMessage = function(e) {
                e.toggleTypingStatus(this.msg.text, this.msg.stime, this.msg.id)
            }, this.handleOutgoingMessage = function() {}
        };
    i.prototype = Object.create(a), e.exports = i
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = function() {
            this.type = "vcard", this.handleIncomingMessage = function(e) {
                e.setVcard(this.msg.text)
            }, this.handleHistoryMessage = function(e) {
                e.isPoster() && e.setVcard(this.msg.text)
            }
        };
    i.prototype = Object.create(a), e.exports = i
}, function(e, t, n) {
    "use strict";
    var a = n(1),
        i = n(2).invokeHandlers,
        o = n(0).EventEnum,
        s = function e() {
            this.type = "video", this.handleOutgoingMessage = function(t) {
                e.prototype.handleOutgoingMessage.call(this, t), i(o.S_V)
            }, this.handleIncomingMessage = function(t) {
                e.prototype.handleIncomingMessage.call(this, t), i(o.R_V)
            }, this.sendAck = !0
        };
    s.prototype = Object.create(a), e.exports = s
}, function(e, t, n) {
    "use strict";
    var a = n(0),
        i = n(3);
    e.exports = {
        detectConflicts: function(e) {
            var t = e.mobile,
                n = e.email,
                i = {
                    mobile: t,
                    email: n
                },
                o = a.config.USER_CONFLICT_API;
            return new Promise(function(e) {
                fetch(o, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(i)
                }).then(function(e) {
                    return e.json()
                }).then(function(t) {
                    var n = t.isConflict;
                    e(n)
                }).catch(function() {
                    e(!0)
                })
            })
        },
        rediectLogin: function() {
            var e = new URL(window.location.href);
            e.searchParams.append("isChatIni", !0);
            var t = "https://www.quikr.com/SignIn?redirect=" + e.href,
                n = i.isMobile();
            if (!n) {
                var a = document.getElementById("loginLink");
                a ? a.click() : window.location.href = t
            } else window.location.href = t
        }
    }
}, function(e, t, n) {
    "use strict";

    function a(e) {
        return {
            setPluginContext: function(t) {
                e.currentChatBox.escrowMessages = t.msgContext, e.currentChatBox.dispatchPluginInitAction = t.action, e.currentChatBox.dispatchPluginLogInAction = t.logIn, e.currentChatBox.dispatchPluginLogOutAction = t.logOut, e.currentChatBox.dispatchPluginMaoChatAction = t.maoChat, e.customHandler.invokeHandlers("PI_" + e.currentChatBox.htmlContainer.id, {})
            },
            attachDom: function(t) {
                var n = !1;
                t.name && (n = !0), n && this.beforeDomComplete({
                    name: t.name,
                    status: 1,
                    remove: !0
                }), e.currentChatBox.htmlContainer.querySelector(t.container).innerHTML = t.content, n && this.domComplete({
                    name: t.name,
                    status: 1,
                    remove: !1
                })
            },
            sendMessage: function(t) {
                var n = t.msgObject,
                    a = t.data;
                n = this.prepareMsgObject(n), e.stropheConnectionHandler.sendMessage(n), n.title = a.title;
                var i = e.messageFactory(n, e.template);
                i.handleOutgoingMessage(e.currentChatBox)
            },
            prepareMsgObject: function(t) {
                return t.presenceStatus = "o", t.msgId = null, t.adId = e.currentChatBox.adDetails.getInfo().adId, t.toId = e.currentChatBox.chatee.getInfo().jid, e.currentChatBox.getStropheChatMessageObject(t)
            },
            noInit: function() {
                e.customHandler.invokeHandlers("PI_" + e.currentChatBox.htmlContainer.id, {})
            }
        }
    }
    var i = n(46);
    e.exports = function(e) {
        var t = a(e);
        i.init(e.currentChatBox, {
            domHelper: e.helper,
            context: t,
            qUser: e.qUser
        }, e.configs)
    }
}, function(e, t, n) {
    var a = {
        init(e, t, a) {
            let i = 1 * e.adDetails.getInfo().category_pgid,
                o = 1 * e.adDetails.getInfo().category_gid;
            269 == i || 247 == i || 40 == i ? n.e(1).then(function() {
                let i = n(20);
                i(t, a, e)
            }.bind(null, n)).catch(n.oe) : 60 == i ? 72 == o ? n.e(0).then(function() {
                let i = n(21);
                i(t, a, e)
            }.bind(null, n)).catch(n.oe) : t.context.noInit() : t.context.noInit()
        }
    };
    e.exports = a
}, function(e, t, n) {
    window.__webpack_public_path__ = "https://teja8.kuikr.com/js/im/";
    var a = n(0),
        i = n(6),
        o = n(11),
        s = n(4),
        r = n(14),
        l = n(10),
        d = n(9),
        c = n(12),
        g = n(2),
        m = n(3),
        u = n(5),
        p = n(7),
        _ = n(13);
    chatManager = function(e) {
        function t(e) {
            m.isEmpty(e) || o.login(e)
        }
        return o.addDefaultHandlers(), e && function(e) {
            var t = !e.LOGIN_TEMPLATE_URL || !e.CHATBOX_TEMPLATE_URL || !e.CHAT_CONTAINER;
            return !t && ((m.extend(a.config, e), i.service = a.config.WS_SERVICE, i.expoLimit = a.config.CONNECTION_RETRY_COUNT, a.config.AUTO_LOGIN && !e.CHATTER_INFO) ? (console.log("Can not find CHATTER_INFO configuration for autologin"), !1) : (a.config.CHATTER_INFO = e.CHATTER_INFO, !0))
        }(e) ? {
            chatNow: function(e, t, n) {
                if ((!a.config.AUTO_LOGIN || i.isLoggedIn) && i.initializationComplete) {
                    var o = "off" != e.getInfo().status;
                    if (a.config.AUTO_LOGIN) return i.jid == e.getInfo().jid ? void m.errorAlert("selfchat") : (n = a.config.CHATTER_INFO, void s.initChat({
                        chatee: e,
                        adDetails: t,
                        chatterInfo: n,
                        sendVcard: !0,
                        isOnline: o
                    }));
                    if (!i.isLoggedIn) s.initiateLogin({
                        chatee: e,
                        adDetails: t,
                        chatterInfo: n
                    });
                    else {
                        if (i.jid == e.getInfo().jid) return void m.errorAlert("selfchat");
                        s.initChat({
                            chatee: e,
                            adDetails: t,
                            chatterInfo: n,
                            sendVcard: !0,
                            isOnline: o
                        })
                    }
                }
            },
            signOut: function() {
                r.clearChatSession(i.email, !0), s.initDisconnect()
            },
            chatee: l,
            adDetails: d,
            init: function() {
                if (a.config.LOG_ENDPOINT && a.config.DO_LOG) {
                    var e = n(19);
                    e.init(e.LogLevelEnum.INFO)
                }
                var o = "";
                a.config.AUTO_LOGIN ? (o = a.config.CHATTER_INFO.email || a.config.CHATTER_INFO.demail, a.config.PRE_LOAD_TEMPLATES && s.loadTemplates("chatbox")) : a.config.PRE_LOAD_TEMPLATES && (s.loadTemplates("login"), s.loadTemplates("chatbox")), r.getChatSession(o, function(e) {
                    if (e) {
                        var n = new c(e.userState.name, e.userState.mobile, e.userState.email, e.userState.demail, e.userState.jid);
                        for (var o in e.cbsArray) {
                            var r = e.cbsArray[o];
                            g.addCustomHandler(s.initChat.bind(void 0, {
                                chatee: r.chatee,
                                adDetails: r.adDetails,
                                chatterInfo: n,
                                uiState: r.uiState,
                                isOnline: r.isOnline,
                                noHistory: !0
                            }), a.EventEnum.CONNECTED, null, !0)
                        }
                        t(n)
                    } else a.config.AUTO_LOGIN ? t(a.config.CHATTER_INFO) : i.initializationComplete = !0
                })
            },
            addHandler: g.addCustomHandler,
            invokeHandlers: g.invokeHandlers,
            events: a.EventEnum,
            setConfig: function(e, t) {
                void 0 != a.config[e] && (a.config[e] = t)
            },
            fromJIDToEmailID: u.fromJIDToEmailID,
            fromRawEmailToJID: u.fromRawEmailToJID,
            fromRawDEmailToJID: u.fromRawDEmailToJID,
            manipulateHistory: p.manipulateHistory,
            isDevicejaberId: u.isDevicejaberId,
            blockUnblockUser: o.blockUnblockUser,
            getAdPresence: _.getAdPresence,
            getJidPresence: _.getJidPresence,
            getNumberOfChatBoxes: s.getNumberOfChatBoxes,
            MAOchat: function(e, n, o, r) {
                if (!a.config.AUTO_LOGIN || i.isLoggedIn) {
                    var l = "off" != e.getInfo().status;
                    if (a.config.AUTO_LOGIN) {
                        if (i.jid == e.getInfo().jid) return void m.errorAlert("selfchat");
                        o = a.config.CHATTER_INFO, s.initChat({
                            chatee: e,
                            adDetails: n,
                            chatterInfo: o,
                            sendVcard: !0,
                            isOnline: l
                        });
                        var d = s.getChatBoxes({
                            email: e.getInfo().email,
                            adId: n.getInfo().adId
                        }, "email&adId");
                        return void(0 < d.length ? s.MAOchatmanager(e, r, n) : g.addCustomHandler(function() {
                            s.MAOchatmanager(e, r, n)
                        }, a.EventEnum.CB_CR, null, !0))
                    }
                    if (!i.isLoggedIn) return t(o), g.addCustomHandler(function() {
                        s.initChat({
                            chatee: e,
                            adDetails: n,
                            chatterInfo: o,
                            sendVcard: !0,
                            isOnline: l
                        })
                    }, a.EventEnum.CONNECTED, null, !0), void g.addCustomHandler(function() {
                        s.MAOchatmanager(e, r, n)
                    }, a.EventEnum.CB_CR, null, !0);
                    if (i.jid == e.getInfo().jid) return void m.errorAlert("selfchat");
                    s.initChat({
                        chatee: e,
                        adDetails: n,
                        chatterInfo: o,
                        sendVcard: !0,
                        isOnline: l
                    });
                    var d = s.getChatBoxes({
                        email: e.getInfo().email,
                        adId: n.getInfo().adId
                    }, "email&adId");
                    0 < d.length ? s.MAOchatmanager(e, r, n) : g.addCustomHandler(function() {
                        s.MAOchatmanager(e, r, n)
                    }, a.EventEnum.CB_CR, null, !0)
                }
            },
            psuedoChatNow: function(e, n, o, r) {
                if ((!a.config.AUTO_LOGIN || i.isLoggedIn) && i.initializationComplete) {
                    var l = "off" != e.getInfo().status;
                    return a.config.AUTO_LOGIN ? i.jid == e.getInfo().jid ? void m.errorAlert("selfchat") : (o = a.config.CHATTER_INFO, s.initChat({
                        chatee: e,
                        adDetails: n,
                        chatterInfo: o,
                        sendVcard: !0,
                        isOnline: l
                    }), void g.addCustomHandler(function() {
                        s.initPsuedoChat(e, r)
                    }, a.EventEnum.CB_CR, null, !0)) : i.isLoggedIn ? i.jid == e.getInfo().jid ? void m.errorAlert("selfchat") : (s.initChat({
                        chatee: e,
                        adDetails: n,
                        chatterInfo: o,
                        sendVcard: !0,
                        isOnline: l
                    }), void g.addCustomHandler(function() {
                        s.initPsuedoChat(e, r)
                    }, a.EventEnum.CB_CR, null, !0)) : (t(o), g.addCustomHandler(function() {
                        s.initChat({
                            chatee: e,
                            adDetails: n,
                            chatterInfo: o,
                            sendVcard: !0,
                            isOnline: l
                        })
                    }, a.EventEnum.CONNECTED, null, !0), void g.addCustomHandler(function() {
                        s.initPsuedoChat(e, r)
                    }, a.EventEnum.CB_CR, null, !0))
                }
            }
        } : (console.log("Insufficient Configuration specified for initiation"), null)
    }
}]);