var Base64 = function() {
        var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        return {
            encode: function(e) {
                var n, s, i, r, o, a, h, c = "",
                    l = 0;
                do {
                    r = (n = e.charCodeAt(l++)) >> 2, o = (3 & n) << 4 | (s = e.charCodeAt(l++)) >> 4, a = (15 & s) << 2 | (i = e.charCodeAt(l++)) >> 6, h = 63 & i, isNaN(s) ? a = h = 64 : isNaN(i) && (h = 64), c = c + t.charAt(r) + t.charAt(o) + t.charAt(a) + t.charAt(h)
                } while (l < e.length);
                return c
            },
            decode: function(e) {
                var n, s, i, r, o, a, h = "",
                    c = 0;
                e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
                do {
                    n = t.indexOf(e.charAt(c++)) << 2 | (r = t.indexOf(e.charAt(c++))) >> 4, s = (15 & r) << 4 | (o = t.indexOf(e.charAt(c++))) >> 2, i = (3 & o) << 6 | (a = t.indexOf(e.charAt(c++))), h += String.fromCharCode(n), 64 != o && (h += String.fromCharCode(s)), 64 != a && (h += String.fromCharCode(i))
                } while (c < e.length);
                return h
            }
        }
    }(),
    MD5 = function() {
        var t = function(t, e) {
                var n = (65535 & t) + (65535 & e);
                return (t >> 16) + (e >> 16) + (n >> 16) << 16 | 65535 & n
            },
            e = function(t) {
                for (var e = [], n = 0; n < 8 * t.length; n += 8) e[n >> 5] |= (255 & t.charCodeAt(n / 8)) << n % 32;
                return e
            },
            n = function(e, n, s, i, r, o) {
                return t((a = t(t(n, e), t(i, o))) << (h = r) | a >>> 32 - h, s);
                var a, h
            },
            s = function(t, e, s, i, r, o, a) {
                return n(e & s | ~e & i, t, e, r, o, a)
            },
            i = function(t, e, s, i, r, o, a) {
                return n(e & i | s & ~i, t, e, r, o, a)
            },
            r = function(t, e, s, i, r, o, a) {
                return n(e ^ s ^ i, t, e, r, o, a)
            },
            o = function(t, e, s, i, r, o, a) {
                return n(s ^ (e | ~i), t, e, r, o, a)
            },
            a = function(e, n) {
                e[n >> 5] |= 128 << n % 32, e[14 + (n + 64 >>> 9 << 4)] = n;
                for (var a, h, c, l, d = 1732584193, u = -271733879, m = -1732584194, _ = 271733878, p = 0; p < e.length; p += 16) a = d, h = u, c = m, l = _, d = s(d, u, m, _, e[p + 0], 7, -680876936), _ = s(_, d, u, m, e[p + 1], 12, -389564586), m = s(m, _, d, u, e[p + 2], 17, 606105819), u = s(u, m, _, d, e[p + 3], 22, -1044525330), d = s(d, u, m, _, e[p + 4], 7, -176418897), _ = s(_, d, u, m, e[p + 5], 12, 1200080426), m = s(m, _, d, u, e[p + 6], 17, -1473231341), u = s(u, m, _, d, e[p + 7], 22, -45705983), d = s(d, u, m, _, e[p + 8], 7, 1770035416), _ = s(_, d, u, m, e[p + 9], 12, -1958414417), m = s(m, _, d, u, e[p + 10], 17, -42063), u = s(u, m, _, d, e[p + 11], 22, -1990404162), d = s(d, u, m, _, e[p + 12], 7, 1804603682), _ = s(_, d, u, m, e[p + 13], 12, -40341101), m = s(m, _, d, u, e[p + 14], 17, -1502002290), u = s(u, m, _, d, e[p + 15], 22, 1236535329), d = i(d, u, m, _, e[p + 1], 5, -165796510), _ = i(_, d, u, m, e[p + 6], 9, -1069501632), m = i(m, _, d, u, e[p + 11], 14, 643717713), u = i(u, m, _, d, e[p + 0], 20, -373897302), d = i(d, u, m, _, e[p + 5], 5, -701558691), _ = i(_, d, u, m, e[p + 10], 9, 38016083), m = i(m, _, d, u, e[p + 15], 14, -660478335), u = i(u, m, _, d, e[p + 4], 20, -405537848), d = i(d, u, m, _, e[p + 9], 5, 568446438), _ = i(_, d, u, m, e[p + 14], 9, -1019803690), m = i(m, _, d, u, e[p + 3], 14, -187363961), u = i(u, m, _, d, e[p + 8], 20, 1163531501), d = i(d, u, m, _, e[p + 13], 5, -1444681467), _ = i(_, d, u, m, e[p + 2], 9, -51403784), m = i(m, _, d, u, e[p + 7], 14, 1735328473), u = i(u, m, _, d, e[p + 12], 20, -1926607734), d = r(d, u, m, _, e[p + 5], 4, -378558), _ = r(_, d, u, m, e[p + 8], 11, -2022574463), m = r(m, _, d, u, e[p + 11], 16, 1839030562), u = r(u, m, _, d, e[p + 14], 23, -35309556), d = r(d, u, m, _, e[p + 1], 4, -1530992060), _ = r(_, d, u, m, e[p + 4], 11, 1272893353), m = r(m, _, d, u, e[p + 7], 16, -155497632), u = r(u, m, _, d, e[p + 10], 23, -1094730640), d = r(d, u, m, _, e[p + 13], 4, 681279174), _ = r(_, d, u, m, e[p + 0], 11, -358537222), m = r(m, _, d, u, e[p + 3], 16, -722521979), u = r(u, m, _, d, e[p + 6], 23, 76029189), d = r(d, u, m, _, e[p + 9], 4, -640364487), _ = r(_, d, u, m, e[p + 12], 11, -421815835), m = r(m, _, d, u, e[p + 15], 16, 530742520), u = r(u, m, _, d, e[p + 2], 23, -995338651), d = o(d, u, m, _, e[p + 0], 6, -198630844), _ = o(_, d, u, m, e[p + 7], 10, 1126891415), m = o(m, _, d, u, e[p + 14], 15, -1416354905), u = o(u, m, _, d, e[p + 5], 21, -57434055), d = o(d, u, m, _, e[p + 12], 6, 1700485571), _ = o(_, d, u, m, e[p + 3], 10, -1894986606), m = o(m, _, d, u, e[p + 10], 15, -1051523), u = o(u, m, _, d, e[p + 1], 21, -2054922799), d = o(d, u, m, _, e[p + 8], 6, 1873313359), _ = o(_, d, u, m, e[p + 15], 10, -30611744), m = o(m, _, d, u, e[p + 6], 15, -1560198380), u = o(u, m, _, d, e[p + 13], 21, 1309151649), d = o(d, u, m, _, e[p + 4], 6, -145523070), _ = o(_, d, u, m, e[p + 11], 10, -1120210379), m = o(m, _, d, u, e[p + 2], 15, 718787259), u = o(u, m, _, d, e[p + 9], 21, -343485551), d = t(d, a), u = t(u, h), m = t(m, c), _ = t(_, l);
                return [d, u, m, _]
            };
        return {
            hexdigest: function(t) {
                return function(t) {
                    for (var e = "", n = 0; n < 4 * t.length; n++) e += "0123456789abcdef".charAt(t[n >> 2] >> n % 4 * 8 + 4 & 15) + "0123456789abcdef".charAt(t[n >> 2] >> n % 4 * 8 & 15);
                    return e
                }(a(e(t), 8 * t.length))
            },
            hash: function(t) {
                return function(t) {
                    for (var e = "", n = 0; n < 32 * t.length; n += 8) e += String.fromCharCode(t[n >> 5] >>> n % 32 & 255);
                    return e
                }(a(e(t), 8 * t.length))
            }
        }
    }();
Function.prototype.bind || (Function.prototype.bind = function(t) {
        var e = this,
            n = Array.prototype.slice,
            s = Array.prototype.concat,
            i = n.call(arguments, 1);
        return function() {
            return e.apply(t || this, s.call(i, n.call(arguments, 0)))
        }
    }), Array.prototype.indexOf || (Array.prototype.indexOf = function(t) {
        var e = this.length,
            n = Number(arguments[1]) || 0;
        for ((n = n < 0 ? Math.ceil(n) : Math.floor(n)) < 0 && (n += e); n < e; n++)
            if (n in this && this[n] === t) return n;
        return -1
    }),
    function(t) {
        var e;

        function n(t, n) {
            return new e.Builder(t, n)
        }

        function s(t) {
            return new e.Builder("iq", t)
        }

        function i(t) {
            return new e.Builder("presence", t)
        }(e = {
            VERSION: "",
            NS: {
                HTTPBIND: "http://jabber.org/protocol/httpbind",
                BOSH: "urn:xmpp:xbosh",
                CLIENT: "jabber:client",
                AUTH: "jabber:iq:auth",
                ROSTER: "jabber:iq:roster",
                PROFILE: "jabber:iq:profile",
                DISCO_INFO: "http://jabber.org/protocol/disco#info",
                DISCO_ITEMS: "http://jabber.org/protocol/disco#items",
                MUC: "http://jabber.org/protocol/muc",
                SASL: "urn:ietf:params:xml:ns:xmpp-sasl",
                STREAM: "http://etherx.jabber.org/streams",
                BIND: "urn:ietf:params:xml:ns:xmpp-bind",
                SESSION: "urn:ietf:params:xml:ns:xmpp-session",
                VERSION: "jabber:iq:version",
                STANZAS: "urn:ietf:params:xml:ns:xmpp-stanzas",
                XHTML_IM: "http://jabber.org/protocol/xhtml-im",
                XHTML: "http://www.w3.org/1999/xhtml"
            },
            XHTML: {
                tags: ["a", "blockquote", "br", "cite", "em", "img", "li", "ol", "p", "span", "strong", "ul", "body"],
                attributes: {
                    a: ["href"],
                    blockquote: ["style"],
                    br: [],
                    cite: ["style"],
                    em: [],
                    img: ["src", "alt", "style", "height", "width"],
                    li: ["style"],
                    ol: ["style"],
                    p: ["style"],
                    span: ["style"],
                    strong: [],
                    ul: ["style"],
                    body: []
                },
                css: ["background-color", "color", "font-family", "font-size", "font-style", "font-weight", "margin-left", "margin-right", "text-align", "text-decoration"],
                validTag: function(t) {
                    for (var n = 0; n < e.XHTML.tags.length; n++)
                        if (t == e.XHTML.tags[n]) return !0;
                    return !1
                },
                validAttribute: function(t, n) {
                    if (void 0 !== e.XHTML.attributes[t] && e.XHTML.attributes[t].length > 0)
                        for (var s = 0; s < e.XHTML.attributes[t].length; s++)
                            if (n == e.XHTML.attributes[t][s]) return !0;
                    return !1
                },
                validCSS: function(t) {
                    for (var n = 0; n < e.XHTML.css.length; n++)
                        if (t == e.XHTML.css[n]) return !0;
                    return !1
                }
            },
            Status: {
                ERROR: 0,
                CONNECTING: 1,
                CONNFAIL: 2,
                AUTHENTICATING: 3,
                AUTHFAIL: 4,
                CONNECTED: 5,
                DISCONNECTED: 6,
                DISCONNECTING: 7,
                ATTACHED: 8
            },
            LogLevel: {
                DEBUG: 0,
                INFO: 1,
                WARN: 2,
                ERROR: 3,
                FATAL: 4
            },
            ElementType: {
                NORMAL: 1,
                TEXT: 3,
                CDATA: 4,
                FRAGMENT: 11
            },
            TIMEOUT: 1.1,
            SECONDARY_TIMEOUT: .1,
            addNamespace: function(t, n) {
                e.NS[t] = n
            },
            forEachChild: function(t, n, s) {
                var i, r;
                for (i = 0; i < t.childNodes.length; i++)(r = t.childNodes[i]).nodeType != e.ElementType.NORMAL || n && !this.isTagEqual(r, n) || s(r)
            },
            isTagEqual: function(t, e) {
                return t.tagName == e
            },
            _xmlGenerator: null,
            _makeGenerator: function() {
                var t;
                return void 0 === document.implementation.createDocument || document.implementation.createDocument && document.documentMode && document.documentMode < 10 ? (t = this._getIEXmlDom()).appendChild(t.createElement("strophe")) : t = document.implementation.createDocument("jabber:client", "strophe", null), t
            },
            xmlGenerator: function() {
                return e._xmlGenerator || (e._xmlGenerator = e._makeGenerator()), e._xmlGenerator
            },
            _getIEXmlDom: function() {
                for (var t = null, e = ["Msxml2.DOMDocument.6.0", "Msxml2.DOMDocument.5.0", "Msxml2.DOMDocument.4.0", "MSXML2.DOMDocument.3.0", "MSXML2.DOMDocument", "MSXML.DOMDocument", "Microsoft.XMLDOM"], n = 0; n < e.length && null === t; n++) try {
                    t = new ActiveXObject(e[n])
                } catch (e) {
                    t = null
                }
                return t
            },
            xmlElement: function(t) {
                if (!t) return null;
                var n, s, i, r = e.xmlGenerator().createElement(t);
                for (n = 1; n < arguments.length; n++)
                    if (arguments[n])
                        if ("string" == typeof arguments[n] || "number" == typeof arguments[n]) r.appendChild(e.xmlTextNode(arguments[n]));
                        else if ("object" == typeof arguments[n] && "function" == typeof arguments[n].sort)
                    for (s = 0; s < arguments[n].length; s++) "object" == typeof arguments[n][s] && "function" == typeof arguments[n][s].sort && r.setAttribute(arguments[n][s][0], arguments[n][s][1]);
                else if ("object" == typeof arguments[n])
                    for (i in arguments[n]) arguments[n].hasOwnProperty(i) && r.setAttribute(i, arguments[n][i]);
                return r
            },
            xmlescape: function(t) {
                return t = (t = (t = (t = (t = t.replace(/\&/g, "&amp;")).replace(/</g, "&lt;")).replace(/>/g, "&gt;")).replace(/'/g, "&apos;")).replace(/"/g, "&quot;")
            },
            xmlTextNode: function(t) {
                return e.xmlGenerator().createTextNode(t)
            },
            xmlHtmlNode: function(t) {
                var e;
                window.DOMParser ? e = (new DOMParser).parseFromString(t, "text/xml") : ((e = new ActiveXObject("Microsoft.XMLDOM")).async = "false", e.loadXML(t));
                return e
            },
            getText: function(t) {
                if (!t) return null;
                var n = "";
                0 === t.childNodes.length && t.nodeType == e.ElementType.TEXT && (n += t.nodeValue);
                for (var s = 0; s < t.childNodes.length; s++) t.childNodes[s].nodeType == e.ElementType.TEXT && (n += t.childNodes[s].nodeValue);
                return e.xmlescape(n)
            },
            copyElement: function(t) {
                var n, s;
                if (t.nodeType == e.ElementType.NORMAL) {
                    for (s = e.xmlElement(t.tagName), n = 0; n < t.attributes.length; n++) s.setAttribute(t.attributes[n].nodeName, t.attributes[n].value);
                    for (n = 0; n < t.childNodes.length; n++) s.appendChild(e.copyElement(t.childNodes[n]))
                } else t.nodeType == e.ElementType.TEXT && (s = e.xmlGenerator().createTextNode(t.nodeValue));
                return s
            },
            createHtml: function(t) {
                var n, s, i, r, o, a, h, c, l, d, u;
                if (t.nodeType == e.ElementType.NORMAL)
                    if (r = t.nodeName, e.XHTML.validTag(r)) try {
                        for (s = e.xmlElement(r), n = 0; n < e.XHTML.attributes[r].length; n++)
                            if (o = e.XHTML.attributes[r][n], null != (a = t.getAttribute(o)) && "" !== a && !1 !== a && 0 !== a)
                                if ("style" == o && "object" == typeof a && void 0 !== a.cssText && (a = a.cssText), "style" == o) {
                                    for (h = [], c = a.split(";"), i = 0; i < c.length; i++) d = (l = c[i].split(":"))[0].replace(/^\s*/, "").replace(/\s*$/, "").toLowerCase(), e.XHTML.validCSS(d) && (u = l[1].replace(/^\s*/, "").replace(/\s*$/, ""), h.push(d + ": " + u));
                                    h.length > 0 && (a = h.join("; "), s.setAttribute(o, a))
                                } else s.setAttribute(o, a);
                        for (n = 0; n < t.childNodes.length; n++) s.appendChild(e.createHtml(t.childNodes[n]))
                    } catch (t) {
                        s = e.xmlTextNode("")
                    } else
                        for (s = e.xmlGenerator().createDocumentFragment(), n = 0; n < t.childNodes.length; n++) s.appendChild(e.createHtml(t.childNodes[n]));
                    else if (t.nodeType == e.ElementType.FRAGMENT)
                    for (s = e.xmlGenerator().createDocumentFragment(), n = 0; n < t.childNodes.length; n++) s.appendChild(e.createHtml(t.childNodes[n]));
                else t.nodeType == e.ElementType.TEXT && (s = e.xmlTextNode(t.nodeValue));
                return s
            },
            escapeNode: function(t) {
                return t.replace(/^\s+|\s+$/g, "").replace(/\\/g, "\\5c").replace(/ /g, "\\20").replace(/\"/g, "\\22").replace(/\&/g, "\\26").replace(/\'/g, "\\27").replace(/\//g, "\\2f").replace(/:/g, "\\3a").replace(/</g, "\\3c").replace(/>/g, "\\3e").replace(/@/g, "\\40")
            },
            unescapeNode: function(t) {
                return t.replace(/\\20/g, " ").replace(/\\22/g, '"').replace(/\\26/g, "&").replace(/\\27/g, "'").replace(/\\2f/g, "/").replace(/\\3a/g, ":").replace(/\\3c/g, "<").replace(/\\3e/g, ">").replace(/\\40/g, "@").replace(/\\5c/g, "\\")
            },
            getNodeFromJid: function(t) {
                return t.indexOf("@") < 0 ? null : t.split("@")[0]
            },
            getDomainFromJid: function(t) {
                var n = e.getBareJidFromJid(t);
                if (n.indexOf("@") < 0) return n;
                var s = n.split("@");
                return s.splice(0, 1), s.join("@")
            },
            getResourceFromJid: function(t) {
                var e = t.split("/");
                return e.length < 2 ? null : (e.splice(0, 1), e.join("/"))
            },
            getBareJidFromJid: function(t) {
                return t ? t.split("/")[0] : null
            },
            log: function(t, e) {},
            debug: function(t) {
                this.log(this.LogLevel.DEBUG, t)
            },
            info: function(t) {
                this.log(this.LogLevel.INFO, t)
            },
            warn: function(t) {
                this.log(this.LogLevel.WARN, t)
            },
            error: function(t) {
                this.log(this.LogLevel.ERROR, t)
            },
            fatal: function(t) {
                this.log(this.LogLevel.FATAL, t)
            },
            serialize: function(t) {
                var n;
                if (!t) return null;
                "function" == typeof t.tree && (t = t.tree());
                var s, i, r = t.nodeName;
                for (t.getAttribute("_realname") && (r = t.getAttribute("_realname")), n = "<" + r, s = 0; s < t.attributes.length; s++) "_realname" != t.attributes[s].nodeName && (n += " " + t.attributes[s].nodeName + "='" + t.attributes[s].value.replace(/&/g, "&amp;").replace(/\'/g, "&apos;").replace(/>/g, "&gt;").replace(/</g, "&lt;") + "'");
                if (t.childNodes.length > 0) {
                    for (n += ">", s = 0; s < t.childNodes.length; s++) switch ((i = t.childNodes[s]).nodeType) {
                        case e.ElementType.NORMAL:
                            n += e.serialize(i);
                            break;
                        case e.ElementType.TEXT:
                            n += e.xmlescape(i.nodeValue);
                            break;
                        case e.ElementType.CDATA:
                            n += "<![CDATA[" + i.nodeValue + "]]>"
                    }
                    n += "</" + r + ">"
                } else n += "/>";
                return n
            },
            _requestId: 0,
            _connectionPlugins: {},
            addConnectionPlugin: function(t, n) {
                e._connectionPlugins[t] = n
            }
        }).Builder = function(t, n) {
            "presence" != t && "message" != t && "iq" != t || (n && !n.xmlns ? n.xmlns = e.NS.CLIENT : n || (n = {
                xmlns: e.NS.CLIENT
            })), this.nodeTree = e.xmlElement(t, n), this.node = this.nodeTree
        }, e.Builder.prototype = {
            tree: function() {
                return this.nodeTree
            },
            toString: function() {
                return e.serialize(this.nodeTree)
            },
            up: function() {
                return this.node = this.node.parentNode, this
            },
            attrs: function(t) {
                for (var e in t) t.hasOwnProperty(e) && this.node.setAttribute(e, t[e]);
                return this
            },
            c: function(t, n, s) {
                var i = e.xmlElement(t, n, s);
                return this.node.appendChild(i), s || (this.node = i), this
            },
            cnode: function(t) {
                var n, s = e.xmlGenerator();
                try {
                    n = void 0 !== s.importNode
                } catch (t) {
                    n = !1
                }
                var i = n ? s.importNode(t, !0) : e.copyElement(t);
                return this.node.appendChild(i), this.node = i, this
            },
            t: function(t) {
                var n = e.xmlTextNode(t);
                return this.node.appendChild(n), this
            },
            h: function(t) {
                var n = document.createElement("body");
                n.innerHTML = t;
                for (var s = e.createHtml(n); s.childNodes.length > 0;) this.node.appendChild(s.childNodes[0]);
                return this
            }
        }, e.Handler = function(t, n, s, i, r, o, a) {
            this.handler = t, this.ns = n, this.name = s, this.type = i, this.id = r, this.options = a || {
                matchBare: !1
            }, this.options.matchBare || (this.options.matchBare = !1), this.options.matchBare ? this.from = o ? e.getBareJidFromJid(o) : null : this.from = o, this.user = !0
        }, e.Handler.prototype = {
            isMatch: function(t) {
                var n, s = null;
                if (s = this.options.matchBare ? e.getBareJidFromJid(t.getAttribute("from")) : t.getAttribute("from"), n = !1, this.ns) {
                    var i = this;
                    e.forEachChild(t, null, function(t) {
                        t.getAttribute("xmlns") == i.ns && (n = !0)
                    }), n = n || t.getAttribute("xmlns") == this.ns
                } else n = !0;
                return !(!n || this.name && !e.isTagEqual(t, this.name) || this.type && t.getAttribute("type") != this.type || this.id && t.getAttribute("id") != this.id || this.from && s != this.from)
            },
            run: function(t) {
                var n = null;
                try {
                    n = this.handler(t)
                } catch (t) {
                    throw t.sourceURL ? e.fatal("error: " + this.handler + " " + t.sourceURL + ":" + t.line + " - " + t.name + ": " + t.message) : t.fileName ? ("undefined" != typeof console && (console.trace(), console.error(this.handler, " - error - ", t, t.message)), e.fatal("error: " + this.handler + " " + t.fileName + ":" + t.lineNumber + " - " + t.name + ": " + t.message)) : e.fatal("error: " + t.message + "\n" + t.stack), t
                }
                return n
            },
            toString: function() {
                return "{Handler: " + this.handler + "(" + this.name + "," + this.id + "," + this.ns + ")}"
            }
        }, e.TimedHandler = function(t, e) {
            this.period = t, this.handler = e, this.lastCalled = (new Date).getTime(), this.user = !0
        }, e.TimedHandler.prototype = {
            run: function() {
                return this.lastCalled = (new Date).getTime(), this.handler()
            },
            reset: function() {
                this.lastCalled = (new Date).getTime()
            },
            toString: function() {
                return "{TimedHandler: " + this.handler + "(" + this.period + ")}"
            }
        }, e.Connection = function(t, n) {
            this.service = t, this.options = n || {};
            var s = this.options.protocol || "";
            for (var i in 0 === t.indexOf("ws:") || 0 === t.indexOf("wss:") || 0 === s.indexOf("ws") ? this._proto = new e.Websocket(this) : this._proto = new e.Bosh(this), this.jid = "", this.domain = null, this.features = null, this._sasl_data = {}, this.do_session = !1, this.do_bind = !1, this.timedHandlers = [], this.handlers = [], this.removeTimeds = [], this.removeHandlers = [], this.addTimeds = [], this.addHandlers = [], this._authentication = {}, this._idleTimeout = null, this._disconnectTimeout = null, this.do_authentication = !0, this.authenticated = !1, this.disconnecting = !1, this.connected = !1, this.paused = !1, this._data = [], this._uniqueId = 0, this._sasl_success_handler = null, this._sasl_failure_handler = null, this._sasl_challenge_handler = null, this.maxRetries = 5, this._idleTimeout = setTimeout(this._onIdle.bind(this), 100), e._connectionPlugins)
                if (e._connectionPlugins.hasOwnProperty(i)) {
                    var r = e._connectionPlugins[i],
                        o = function() {};
                    o.prototype = r, this[i] = new o, this[i].init(this)
                }
        }, e.Connection.prototype = {
            reset: function() {
                this._proto._reset(), this.do_session = !1, this.do_bind = !1, this.timedHandlers = [], this.handlers = [], this.removeTimeds = [], this.removeHandlers = [], this.addTimeds = [], this.addHandlers = [], this._authentication = {}, this.authenticated = !1, this.disconnecting = !1, this.connected = !1, this._requests = [], this._uniqueId = 0
            },
            pause: function() {
                this.paused = !0
            },
            resume: function() {
                this.paused = !1
            },
            getUniqueId: function(t) {
                return "string" == typeof t || "number" == typeof t ? ++this._uniqueId + ":" + t : ++this._uniqueId + ""
            },
            connect: function(t, n, s, i, r, o) {
                this.jid = t, this.authzid = e.getBareJidFromJid(this.jid), this.authcid = e.getNodeFromJid(this.jid), this.pass = n, this.servtype = "xmpp", this.connect_callback = s, this.disconnecting = !1, this.connected = !1, this.authenticated = !1, this.domain = e.getDomainFromJid(this.jid), this._changeConnectStatus(e.Status.CONNECTING, null), this._proto._connect(i, r, o)
            },
            attach: function(t, e, n, s, i, r, o) {
                this._proto._attach(t, e, n, s, i, r, o)
            },
            xmlInput: function(t) {},
            xmlOutput: function(t) {},
            rawInput: function(t) {},
            rawOutput: function(t) {},
            send: function(t) {
                if (null !== t) {
                    if ("function" == typeof t.sort)
                        for (var e = 0; e < t.length; e++) this._queueData(t[e]);
                    else "function" == typeof t.tree ? this._queueData(t.tree()) : this._queueData(t);
                    this._proto._send()
                }
            },
            flush: function() {
                clearTimeout(this._idleTimeout), this._onIdle()
            },
            sendIQ: function(t, n, s, i) {
                var r = null,
                    o = this;
                "function" == typeof t.tree && (t = t.tree());
                var a = t.getAttribute("id");
                a || (a = this.getUniqueId("sendIQ"), t.setAttribute("id", a));
                var h = t.getAttribute("to"),
                    c = this.jid,
                    l = this.addHandler(function(t) {
                        r && o.deleteTimedHandler(r);
                        var i = !1,
                            a = t.getAttribute("from");
                        if (a !== h && (null !== h || a !== e.getBareJidFromJid(c) && a !== e.getDomainFromJid(c) && a !== c) || (i = !0), !i) throw {
                            name: "StropheError",
                            message: "Got answer to IQ from wrong jid:" + a + "\nExpected jid: " + h
                        };
                        var l = t.getAttribute("type");
                        if ("result" == l) n && n(t);
                        else {
                            if ("error" != l) throw {
                                name: "StropheError",
                                message: "Got bad IQ type of " + l
                            };
                            s && s(t)
                        }
                    }, null, "iq", null, a);
                return i && (r = this.addTimedHandler(i, function() {
                    return o.deleteHandler(l), s && s(null), !1
                })), this.send(t), a
            },
            _queueData: function(t) {
                if (null === t || !t.tagName || !t.childNodes) throw {
                    name: "StropheError",
                    message: "Cannot queue non-DOMElement."
                };
                this._data.push(t)
            },
            _sendRestart: function() {
                this._data.push("restart"), this._proto._sendRestart(), this._idleTimeout = setTimeout(this._onIdle.bind(this), 100)
            },
            addTimedHandler: function(t, n) {
                var s = new e.TimedHandler(t, n);
                return this.addTimeds.push(s), s
            },
            deleteTimedHandler: function(t) {
                this.removeTimeds.push(t)
            },
            addHandler: function(t, n, s, i, r, o, a) {
                var h = new e.Handler(t, n, s, i, r, o, a);
                return this.addHandlers.push(h), h
            },
            deleteHandler: function(t) {
                this.removeHandlers.push(t);
                var e = this.addHandlers.indexOf(t);
                e >= 0 && this.addHandlers.splice(e, 1)
            },
            disconnect: function(t) {
                if (this._changeConnectStatus(e.Status.DISCONNECTING, t), e.info("Disconnect was called because: " + t), this.connected) {
                    var n = !1;
                    this.disconnecting = !0, this.authenticated && (n = i({
                        xmlns: e.NS.CLIENT,
                        type: "unavailable"
                    })), this._disconnectTimeout = this._addSysTimedHandler(3e3, this._onDisconnectTimeout.bind(this)), this._proto._disconnect(n)
                }
            },
            _changeConnectStatus: function(t, n) {
                for (var s in e._connectionPlugins)
                    if (e._connectionPlugins.hasOwnProperty(s)) {
                        var i = this[s];
                        if (i.statusChanged) try {
                            i.statusChanged(t, n)
                        } catch (t) {
                            e.error(s + " plugin caused an exception changing status: " + t)
                        }
                    }
                if (this.connect_callback) try {
                    this.connect_callback(t, n)
                } catch (t) {
                    e.error("User connection callback caused an exception: " + t)
                }
            },
            _doDisconnect: function() {
                "number" == typeof this._idleTimeout && clearTimeout(this._idleTimeout), null !== this._disconnectTimeout && (this.deleteTimedHandler(this._disconnectTimeout), this._disconnectTimeout = null), e.info("_doDisconnect was called"), this._proto._doDisconnect(), this.authenticated = !1, this.disconnecting = !1, this.handlers = [], this.timedHandlers = [], this.removeTimeds = [], this.removeHandlers = [], this.addTimeds = [], this.addHandlers = [], this._changeConnectStatus(e.Status.DISCONNECTED, null), this.connected = !1
            },
            _dataRecv: function(t, n) {
                e.info("_dataRecv called");
                var s = this._proto._reqToData(t);
                if (null !== s) {
                    var i, r;
                    for (this.xmlInput !== e.Connection.prototype.xmlInput && (s.nodeName === this._proto.strip && s.childNodes.length ? this.xmlInput(s.childNodes[0]) : this.xmlInput(s)), this.rawInput !== e.Connection.prototype.rawInput && (n ? this.rawInput(n) : this.rawInput(e.serialize(s))); this.removeHandlers.length > 0;) r = this.removeHandlers.pop(), (i = this.handlers.indexOf(r)) >= 0 && this.handlers.splice(i, 1);
                    for (; this.addHandlers.length > 0;) this.handlers.push(this.addHandlers.pop());
                    if (this.disconnecting && this._proto._emptyQueue()) this._doDisconnect();
                    else {
                        var o, a, h = s.getAttribute("type");
                        if (null !== h && "terminate" == h) {
                            if (this.disconnecting) return;
                            return o = s.getAttribute("condition"), a = s.getElementsByTagName("conflict"), null !== o ? ("remote-stream-error" == o && a.length > 0 && (o = "conflict"), this._changeConnectStatus(e.Status.CONNFAIL, o)) : this._changeConnectStatus(e.Status.CONNFAIL, "unknown"), void this._doDisconnect()
                        }
                        var c = this;
                        e.forEachChild(s, null, function(t) {
                            var n, s;
                            for (s = c.handlers, c.handlers = [], n = 0; n < s.length; n++) {
                                var i = s[n],
                                    r = !1;
                                try {
                                    "iq" != i.name || c.authenticated || (r = !0), i.isMatch(t) && (c.authenticated || !i.user || r) ? i.run(t) && c.handlers.push(i) : c.handlers.push(i)
                                } catch (t) {
                                    e.warn("Removing Strophe handlers due to uncaught exception: " + t.message)
                                }
                                r = !1
                            }
                        })
                    }
                }
            },
            mechanisms: {},
            _connect_cb: function(t, n, s) {
                e.info("_connect_cb was called"), this.connected = !0;
                var i = this._proto._reqToData(t);
                if (i && (this.xmlInput !== e.Connection.prototype.xmlInput && (i.nodeName === this._proto.strip && i.childNodes.length ? this.xmlInput(i.childNodes[0]) : this.xmlInput(i)), this.rawInput !== e.Connection.prototype.rawInput && (s ? this.rawInput(s) : this.rawInput(e.serialize(i))), this._proto._connect_cb(i) !== e.Status.CONNFAIL)) {
                    this._authentication.sasl_scram_sha1 = !1, this._authentication.sasl_plain = !1, this._authentication.sasl_digest_md5 = !1, this._authentication.sasl_anonymous = !1, this._authentication.legacy_auth = !1;
                    var r, o, a = i.getElementsByTagNameNS(e.NS.STREAM, "features").length > 0,
                        h = i.getElementsByTagName("mechanism"),
                        c = [];
                    if (a) {
                        if (h.length > 0)
                            for (r = 0; r < h.length; r++) o = e.getText(h[r]), this.mechanisms[o] && c.push(this.mechanisms[o]);
                        this._authentication.legacy_auth = i.getElementsByTagName("auth").length > 0, this._authentication.legacy_auth || c.length > 0 ? !1 !== this.do_authentication && this.authenticate(c) : this._proto._no_auth_received(n)
                    } else this._proto._no_auth_received(n)
                }
            },
            authenticate: function(t) {
                var i;
                for (i = 0; i < t.length - 1; ++i) {
                    for (var r = i, o = i + 1; o < t.length; ++o) t[o].prototype.priority > t[r].prototype.priority && (r = o);
                    if (r != i) {
                        var a = t[i];
                        t[i] = t[r], t[r] = a
                    }
                }
                var h = !1;
                for (i = 0; i < t.length; ++i)
                    if (t[i].test(this)) {
                        this._sasl_success_handler = this._addSysHandler(this._sasl_success_cb.bind(this), null, "success", null, null), this._sasl_failure_handler = this._addSysHandler(this._sasl_failure_cb.bind(this), null, "failure", null, null), this._sasl_challenge_handler = this._addSysHandler(this._sasl_challenge_cb.bind(this), null, "challenge", null, null), this._sasl_mechanism = new t[i], this._sasl_mechanism.onStart(this);
                        var c = n("auth", {
                            xmlns: e.NS.SASL,
                            mechanism: this._sasl_mechanism.name
                        });
                        if (this._sasl_mechanism.isClientFirst) {
                            var l = this._sasl_mechanism.onChallenge(this, null);
                            c.t(Base64.encode(l))
                        }
                        this.send(c.tree()), h = !0;
                        break
                    }
                h || (null === e.getNodeFromJid(this.jid) ? (this._changeConnectStatus(e.Status.CONNFAIL, "x-strophe-bad-non-anon-jid"), this.disconnect("x-strophe-bad-non-anon-jid")) : (this._changeConnectStatus(e.Status.AUTHENTICATING, null), this._addSysHandler(this._auth1_cb.bind(this), null, null, null, "_auth_1"), this.send(s({
                    type: "get",
                    to: this.domain,
                    id: "_auth_1"
                }).c("query", {
                    xmlns: e.NS.AUTH
                }).c("username", {}).t(e.getNodeFromJid(this.jid)).tree())))
            },
            _sasl_challenge_cb: function(t) {
                var s = Base64.decode(e.getText(t)),
                    i = this._sasl_mechanism.onChallenge(this, s),
                    r = n("response", {
                        xmlns: e.NS.SASL
                    });
                return "" !== i && r.t(Base64.encode(i)), this.send(r.tree()), !0
            },
            _auth1_cb: function(t) {
                var n = s({
                    type: "set",
                    id: "_auth_2"
                }).c("query", {
                    xmlns: e.NS.AUTH
                }).c("username", {}).t(e.getNodeFromJid(this.jid)).up().c("password").t(this.pass);
                return e.getResourceFromJid(this.jid) || (this.jid = e.getBareJidFromJid(this.jid) + "/strophe"), n.up().c("resource", {}).t(e.getResourceFromJid(this.jid)), this._addSysHandler(this._auth2_cb.bind(this), null, null, null, "_auth_2"), this.send(n.tree()), !1
            },
            _sasl_success_cb: function(t) {
                if (this._sasl_data["server-signature"]) {
                    var n, s = Base64.decode(e.getText(t)).match(/([a-z]+)=([^,]+)(,|$)/);
                    if ("v" == s[1] && (n = s[2]), n != this._sasl_data["server-signature"]) return this.deleteHandler(this._sasl_failure_handler), this._sasl_failure_handler = null, this._sasl_challenge_handler && (this.deleteHandler(this._sasl_challenge_handler), this._sasl_challenge_handler = null), this._sasl_data = {}, this._sasl_failure_cb(null)
                }
                return e.info("SASL authentication succeeded."), this._sasl_mechanism && this._sasl_mechanism.onSuccess(), this.deleteHandler(this._sasl_failure_handler), this._sasl_failure_handler = null, this._sasl_challenge_handler && (this.deleteHandler(this._sasl_challenge_handler), this._sasl_challenge_handler = null), this._addSysHandler(this._sasl_auth1_cb.bind(this), null, "stream:features", null, null), this._sendRestart(), !1
            },
            _sasl_auth1_cb: function(t) {
                var n, i;
                for (this.features = t, n = 0; n < t.childNodes.length; n++) "bind" == (i = t.childNodes[n]).nodeName && (this.do_bind = !0), "session" == i.nodeName && (this.do_session = !0);
                if (!this.do_bind) return this._changeConnectStatus(e.Status.AUTHFAIL, null), !1;
                this._addSysHandler(this._sasl_bind_cb.bind(this), null, null, null, "_bind_auth_2");
                var r = "_bind_auth_2",
                    o = "d100-" + Math.floor(1e4 * Math.random() + 1);
                r || (r = "bind_1");
                var a = s({
                    type: "set",
                    id: r
                }).c("bind", {
                    xmlns: "urn:ietf:params:xml:ns:xmpp-bind"
                }).c("resource").t(o);
                return this.send(a), !1
            },
            _sasl_bind_cb: function(t) {
                var n;
                if ("error" == t.getAttribute("type")) return e.info("SASL binding failed."), t.getElementsByTagName("conflict").length > 0 && (n = "conflict"), this._changeConnectStatus(e.Status.AUTHFAIL, n), !1;
                var i, r = t.getElementsByTagName("bind");
                if (!(r.length > 0)) return e.info("SASL binding failed."), this._changeConnectStatus(e.Status.AUTHFAIL, null), !1;
                (i = r[0].getElementsByTagName("jid")).length > 0 && (this.jid = e.getText(i[0]), this.do_session ? (this._addSysHandler(this._sasl_session_cb.bind(this), null, null, null, "_session_auth_2"), this.send(s({
                    type: "set",
                    id: "_session_auth_2"
                }).c("session", {
                    xmlns: e.NS.SESSION
                }).tree())) : (this.authenticated = !0, this._changeConnectStatus(e.Status.CONNECTED, null)))
            },
            _sasl_session_cb: function(t) {
                if ("result" == t.getAttribute("type")) this.authenticated = !0, this._changeConnectStatus(e.Status.CONNECTED, null);
                else if ("error" == t.getAttribute("type")) return e.info("Session creation failed."), this._changeConnectStatus(e.Status.AUTHFAIL, null), !1;
                return !1
            },
            _sasl_failure_cb: function(t) {
                return this._sasl_success_handler && (this.deleteHandler(this._sasl_success_handler), this._sasl_success_handler = null), this._sasl_challenge_handler && (this.deleteHandler(this._sasl_challenge_handler), this._sasl_challenge_handler = null), this._sasl_mechanism && this._sasl_mechanism.onFailure(), this._changeConnectStatus(e.Status.AUTHFAIL, null), !1
            },
            _auth2_cb: function(t) {
                return "result" == t.getAttribute("type") ? (this.authenticated = !0, this._changeConnectStatus(e.Status.CONNECTED, null)) : "error" == t.getAttribute("type") && (this._changeConnectStatus(e.Status.AUTHFAIL, null), this.disconnect("authentication failed")), !1
            },
            _addSysTimedHandler: function(t, n) {
                var s = new e.TimedHandler(t, n);
                return s.user = !1, this.addTimeds.push(s), s
            },
            _addSysHandler: function(t, n, s, i, r) {
                var o = new e.Handler(t, n, s, i, r);
                return o.user = !1, this.addHandlers.push(o), o
            },
            _onDisconnectTimeout: function() {
                return e.info("_onDisconnectTimeout was called"), this._proto._onDisconnectTimeout(), this._doDisconnect(), !1
            },
            _onIdle: function() {
                for (var t, e, n; this.addTimeds.length > 0;) this.timedHandlers.push(this.addTimeds.pop());
                for (; this.removeTimeds.length > 0;) e = this.removeTimeds.pop(), (t = this.timedHandlers.indexOf(e)) >= 0 && this.timedHandlers.splice(t, 1);
                var s = (new Date).getTime();
                for (n = [], t = 0; t < this.timedHandlers.length; t++) e = this.timedHandlers[t], !this.authenticated && e.user || (e.lastCalled + e.period - s <= 0 ? e.run() && n.push(e) : n.push(e));
                this.timedHandlers = n, clearTimeout(this._idleTimeout), this._proto._onIdle(), this.connected && (this._idleTimeout = setTimeout(this._onIdle.bind(this), 100))
            }
        }, t && t(e, n, function(t) {
            return new e.Builder("message", t)
        }, s, i), e.SASLMechanism = function(t, e, n) {
            this.name = t, this.isClientFirst = e, this.priority = n
        }, e.SASLMechanism.prototype = {
            test: function(t) {
                return !0
            },
            onStart: function(t) {
                this._connection = t
            },
            onChallenge: function(t, e) {
                throw new Error("You should implement challenge handling!")
            },
            onFailure: function() {
                this._connection = null
            },
            onSuccess: function() {
                this._connection = null
            }
        }, e.SASLAnonymous = function() {}, e.SASLAnonymous.prototype = new e.SASLMechanism("ANONYMOUS", !1, 10), e.SASLAnonymous.test = function(t) {
            return null === t.authcid
        }, e.Connection.prototype.mechanisms[e.SASLAnonymous.prototype.name] = e.SASLAnonymous, e.SASLPlain = function() {}, e.SASLPlain.prototype = new e.SASLMechanism("PLAIN", !0, 20), e.SASLPlain.test = function(t) {
            return null !== t.authcid
        }, e.SASLPlain.prototype.onChallenge = function(t) {
            var e = t.authzid;
            return e += "\0", e += t.authcid, e += "\0", e += t.pass
        }, e.Connection.prototype.mechanisms[e.SASLPlain.prototype.name] = e.SASLPlain
    }(function() {
        window.Strophe = arguments[0], window.$build = arguments[1], window.$msg = arguments[2], window.$iq = arguments[3], window.$pres = arguments[4]
    }), Strophe.Request = function(t, e, n, s) {
        this.id = ++Strophe._requestId, this.xmlData = t, this.data = Strophe.serialize(t), this.origFunc = e, this.func = e, this.rid = n, this.date = NaN, this.sends = s || 0, this.abort = !1, this.dead = null, this.age = function() {
            return this.date ? (new Date - this.date) / 1e3 : 0
        }, this.timeDead = function() {
            return this.dead ? (new Date - this.dead) / 1e3 : 0
        }, this.xhr = this._newXHR()
    }, Strophe.Request.prototype = {
        getResponse: function() {
            var t = null;
            if (this.xhr.responseXML && this.xhr.responseXML.documentElement) {
                if ("parsererror" == (t = this.xhr.responseXML.documentElement).tagName) throw Strophe.error("invalid response received"), Strophe.error("responseText: " + this.xhr.responseText), Strophe.error("responseXML: " + Strophe.serialize(this.xhr.responseXML)), "parsererror"
            } else this.xhr.responseText && (Strophe.error("invalid response received"), Strophe.error("responseText: " + this.xhr.responseText), Strophe.error("responseXML: " + Strophe.serialize(this.xhr.responseXML)));
            return t
        },
        _newXHR: function() {
            var t = null;
            return window.XMLHttpRequest ? (t = new XMLHttpRequest).overrideMimeType && t.overrideMimeType("text/xml; charset=utf-8") : window.ActiveXObject && (t = new ActiveXObject("Microsoft.XMLHTTP")), t.onreadystatechange = this.func.bind(null, this), t
        }
    }, Strophe.Bosh = function(t) {
        this._conn = t, this.rid = Math.floor(4294967295 * Math.random()), this.sid = null, this.hold = 1, this.wait = 60, this.window = 5, this.errors = 0, this._requests = []
    }, Strophe.Bosh.prototype = {
        strip: null,
        _buildBody: function() {
            var t = $build("body", {
                rid: this.rid++,
                xmlns: Strophe.NS.HTTPBIND
            });
            return null !== this.sid && t.attrs({
                sid: this.sid
            }), t
        },
        _reset: function() {
            this.rid = Math.floor(4294967295 * Math.random()), this.sid = null, this.errors = 0
        },
        _connect: function(t, e, n) {
            this.wait = t || this.wait, this.hold = e || this.hold, this.errors = 0;
            var s = this._buildBody().attrs({
                to: this._conn.domain,
                "xml:lang": "en",
                wait: this.wait,
                hold: this.hold,
                content: "text/xml; charset=utf-8",
                ver: "1.6",
                "xmpp:version": "1.0",
                "xmlns:xmpp": Strophe.NS.BOSH
            });
            n && s.attrs({
                route: n
            });
            var i = this._conn._connect_cb;
            this._requests.push(new Strophe.Request(s.tree(), this._onRequestStateChange.bind(this, i.bind(this._conn)), s.tree().getAttribute("rid"))), this._throttledRequestHandler()
        },
        _attach: function(t, e, n, s, i, r, o) {
            this._conn.jid = t, this.sid = e, this.rid = n, this._conn.connect_callback = s, this._conn.domain = Strophe.getDomainFromJid(this._conn.jid), this._conn.authenticated = !0, this._conn.connected = !0, this.wait = i || this.wait, this.hold = r || this.hold, this.window = o || this.window, this._conn._changeConnectStatus(Strophe.Status.ATTACHED, null)
        },
        _connect_cb: function(t) {
            var e, n, s = t.getAttribute("type");
            if (null !== s && "terminate" == s) return Strophe.error("BOSH-Connection failed: " + e), e = t.getAttribute("condition"), n = t.getElementsByTagName("conflict"), null !== e ? ("remote-stream-error" == e && n.length > 0 && (e = "conflict"), this._conn._changeConnectStatus(Strophe.Status.CONNFAIL, e)) : this._conn._changeConnectStatus(Strophe.Status.CONNFAIL, "unknown"), this._conn._doDisconnect(), Strophe.Status.CONNFAIL;
            this.sid || (this.sid = t.getAttribute("sid"));
            var i = t.getAttribute("requests");
            i && (this.window = parseInt(i, 10));
            var r = t.getAttribute("hold");
            r && (this.hold = parseInt(r, 10));
            var o = t.getAttribute("wait");
            o && (this.wait = parseInt(o, 10))
        },
        _disconnect: function(t) {
            this._sendTerminate(t)
        },
        _doDisconnect: function() {
            this.sid = null, this.rid = Math.floor(4294967295 * Math.random())
        },
        _emptyQueue: function() {
            return 0 === this._requests.length
        },
        _hitError: function(t) {
            this.errors++, Strophe.warn("request errored, status: " + t + ", number of errors: " + this.errors), this.errors > 4 && this._conn._onDisconnectTimeout()
        },
        _no_auth_received: function(t) {
            t = t ? t.bind(this._conn) : this._conn._connect_cb.bind(this._conn);
            var e = this._buildBody();
            this._requests.push(new Strophe.Request(e.tree(), this._onRequestStateChange.bind(this, t.bind(this._conn)), e.tree().getAttribute("rid"))), this._throttledRequestHandler()
        },
        _onDisconnectTimeout: function() {
            for (var t; this._requests.length > 0;)(t = this._requests.pop()).abort = !0, t.xhr.abort(), t.xhr.onreadystatechange = function() {}
        },
        _onIdle: function() {
            var t = this._conn._data;
            if (this._conn.authenticated && 0 === this._requests.length && 0 === t.length && !this._conn.disconnecting && (Strophe.info("no requests during idle cycle, sending blank request"), t.push(null)), !this._conn.paused) {
                if (this._requests.length < 2 && t.length > 0) {
                    for (var e = this._buildBody(), n = 0; n < t.length; n++) null !== t[n] && ("restart" === t[n] ? e.attrs({
                        to: this._conn.domain,
                        "xml:lang": "en",
                        "xmpp:restart": "true",
                        "xmlns:xmpp": Strophe.NS.BOSH
                    }) : e.cnode(t[n]).up());
                    delete this._conn._data, this._conn._data = [], this._requests.push(new Strophe.Request(e.tree(), this._onRequestStateChange.bind(this, this._conn._dataRecv.bind(this._conn)), e.tree().getAttribute("rid"))), this._processRequest(this._requests.length - 1)
                }
                if (this._requests.length > 0) {
                    var s = this._requests[0].age();
                    null !== this._requests[0].dead && this._requests[0].timeDead() > Math.floor(Strophe.SECONDARY_TIMEOUT * this.wait) && this._throttledRequestHandler(), s > Math.floor(Strophe.TIMEOUT * this.wait) && (Strophe.warn("Request " + this._requests[0].id + " timed out, over " + Math.floor(Strophe.TIMEOUT * this.wait) + " seconds since last activity"), this._throttledRequestHandler())
                }
            }
        },
        _onRequestStateChange: function(t, e) {
            var n;
            if (Strophe.debug("request id " + e.id + "." + e.sends + " state changed to " + e.xhr.readyState), e.abort) e.abort = !1;
            else if (4 == e.xhr.readyState) {
                n = 0;
                try {
                    n = e.xhr.status
                } catch (t) {}
                if (void 0 === n && (n = 0), this.disconnecting && n >= 400) return void this._hitError(n);
                var s = this._requests[0] == e,
                    i = this._requests[1] == e;
                (n > 0 && n < 500 || e.sends > 5) && (this._removeRequest(e), Strophe.debug("request id " + e.id + " should now be removed")), 200 == n ? ((i || s && this._requests.length > 0 && this._requests[0].age() > Math.floor(Strophe.SECONDARY_TIMEOUT * this.wait)) && this._restartRequest(0), Strophe.debug("request id " + e.id + "." + e.sends + " got 200"), t(e), this.errors = 0) : (console.log("receive error:" + n), Strophe.error("request id " + e.id + "." + e.sends + " error " + n + " happened"), (0 === n || n >= 400 && n < 600 || n >= 12e3) && (this._hitError(n), n >= 400 && n < 500 && this._conn._doDisconnect())), n > 0 && n < 500 || e.sends > 5 || this._throttledRequestHandler()
            }
        },
        _processRequest: function(t) {
            var e = this,
                n = this._requests[t],
                s = -1;
            try {
                4 == n.xhr.readyState && (s = n.xhr.status)
            } catch (e) {
                Strophe.error("caught an error in _requests[" + t + "], reqStatus: " + s)
            }
            if (void 0 === s && (s = -1), n.sends > this._conn.maxRetries) this._conn._onDisconnectTimeout();
            else {
                var i = n.age(),
                    r = !isNaN(i) && i > Math.floor(Strophe.TIMEOUT * this.wait),
                    o = null !== n.dead && n.timeDead() > Math.floor(Strophe.SECONDARY_TIMEOUT * this.wait),
                    a = 4 == n.xhr.readyState && (s < 1 || s >= 500);
                if ((r || o || a) && (o && Strophe.error("Request " + this._requests[t].id + " timed out (secondary), restarting"), n.abort = !0, n.xhr.abort(), n.xhr.onreadystatechange = function() {}, this._requests[t] = new Strophe.Request(n.xmlData, n.origFunc, n.rid, n.sends), n = this._requests[t]), 0 === n.xhr.readyState) {
                    Strophe.debug("request id " + n.id + "." + n.sends + " posting");
                    try {
                        n.xhr.open("POST", this._conn.service, !this._conn.options.sync), n.xhr.setRequestHeader("Content-Type", "text/xml; charset=utf-8")
                    } catch (t) {
                        return Strophe.error("XHR open failed."), this._conn.connected || this._conn._changeConnectStatus(Strophe.Status.CONNFAIL, "bad-service"), void this._conn.disconnect()
                    }
                    var h = function() {
                        if (n.date = new Date, e._conn.options.customHeaders) {
                            var t = e._conn.options.customHeaders;
                            for (var s in t) t.hasOwnProperty(s) && n.xhr.setRequestHeader(s, t[s])
                        }
                        n.xhr.send(n.data)
                    };
                    if (n.sends > 1) {
                        var c = 1e3 * Math.min(Math.floor(Strophe.TIMEOUT * this.wait), Math.pow(n.sends, 3));
                        setTimeout(h, c)
                    } else h();
                    n.sends++, this._conn.xmlOutput !== Strophe.Connection.prototype.xmlOutput && (n.xmlData.nodeName === this.strip && n.xmlData.childNodes.length ? this._conn.xmlOutput(n.xmlData.childNodes[0]) : this._conn.xmlOutput(n.xmlData)), this._conn.rawOutput !== Strophe.Connection.prototype.rawOutput && this._conn.rawOutput(n.data)
                } else Strophe.debug("_processRequest: " + (0 === t ? "first" : "second") + " request has readyState of " + n.xhr.readyState)
            }
        },
        _removeRequest: function(t) {
            var e;
            for (Strophe.debug("removing request"), e = this._requests.length - 1; e >= 0; e--) t == this._requests[e] && this._requests.splice(e, 1);
            t.xhr.onreadystatechange = function() {}, this._throttledRequestHandler()
        },
        _restartRequest: function(t) {
            var e = this._requests[t];
            null === e.dead && (e.dead = new Date), this._processRequest(t)
        },
        _reqToData: function(t) {
            try {
                return t.getResponse()
            } catch (t) {
                if ("parsererror" != t) throw t;
                this._conn.disconnect("strophe-parsererror")
            }
        },
        _sendTerminate: function(t) {
            Strophe.info("_sendTerminate was called");
            var e = this._buildBody().attrs({
                type: "terminate"
            });
            t && e.cnode(t.tree());
            var n = new Strophe.Request(e.tree(), this._onRequestStateChange.bind(this, this._conn._dataRecv.bind(this._conn)), e.tree().getAttribute("rid"));
            this._requests.push(n), this._throttledRequestHandler()
        },
        _send: function() {
            clearTimeout(this._conn._idleTimeout), this._throttledRequestHandler(), this._conn._idleTimeout = setTimeout(this._conn._onIdle.bind(this._conn), 100)
        },
        _sendRestart: function() {
            this._throttledRequestHandler(), clearTimeout(this._conn._idleTimeout)
        },
        _throttledRequestHandler: function() {
            this._requests ? Strophe.debug("_throttledRequestHandler called with " + this._requests.length + " requests") : Strophe.debug("_throttledRequestHandler called with undefined requests"), this._requests && 0 !== this._requests.length && (this._requests.length > 0 && this._processRequest(0), this._requests.length > 1 && Math.abs(this._requests[0].rid - this._requests[1].rid) < this.window && this._processRequest(1))
        }
    }, Strophe.Websocket = function(t) {
        this._conn = t, this.strip = "stream:stream";
        var e = t.service;
        if (0 !== e.indexOf("ws:") && 0 !== e.indexOf("wss:")) {
            var n = "";
            "ws" === t.options.protocol && "https:" !== window.location.protocol ? n += "ws" : n += "wss", n += "://" + window.location.host, 0 !== e.indexOf("/") ? n += window.location.pathname + e : n += e, t.service = n
        }
    }, Strophe.Websocket.prototype = {
        _buildStream: function() {
            return $build("stream:stream", {
                to: this._conn.domain,
                xmlns: Strophe.NS.CLIENT,
                "xmlns:stream": Strophe.NS.STREAM,
                version: "1.0"
            })
        },
        _check_streamerror: function(t, e) {
            var n = t.getElementsByTagNameNS(Strophe.NS.STREAM, "error");
            if (0 === n.length) return !1;
            for (var s = n[0], i = "", r = "", o = 0; o < s.childNodes.length; o++) {
                var a = s.childNodes[o];
                if ("urn:ietf:params:xml:ns:xmpp-streams" !== a.getAttribute("xmlns")) break;
                "text" === a.nodeName ? r = a.textContent : i = a.nodeName
            }
            var h = "WebSocket stream error: ";
            return h += i || "unknown", r && (h += " - " + i), Strophe.error(h), this._conn._changeConnectStatus(e, i), this._conn._doDisconnect(), !0
        },
        _reset: function() {},
        _connect: function() {
            this._closeSocket(), this.socket = new WebSocket(this._conn.service, "xmpp"), this.socket.onopen = this._onOpen.bind(this), this.socket.onerror = this._onError.bind(this), this.socket.onclose = this._onClose.bind(this), this.socket.onmessage = this._connect_cb_wrapper.bind(this)
        },
        _connect_cb: function(t) {
            if (this._check_streamerror(t, Strophe.Status.CONNFAIL)) return Strophe.Status.CONNFAIL
        },
        _handleStreamStart: function(t) {
            var e = !1,
                n = t.getAttribute("xmlns");
            "string" != typeof n ? e = "Missing xmlns in stream:stream" : n !== Strophe.NS.CLIENT && (e = "Wrong xmlns in stream:stream: " + n);
            var s = t.namespaceURI;
            "string" != typeof s ? e = "Missing xmlns:stream in stream:stream" : s !== Strophe.NS.STREAM && (e = "Wrong xmlns:stream in stream:stream: " + s);
            var i = t.getAttribute("version");
            return "string" != typeof i ? e = "Missing version in stream:stream" : "1.0" !== i && (e = "Wrong version in stream:stream: " + i), !e || (this._conn._changeConnectStatus(Strophe.Status.CONNFAIL, e), this._conn._doDisconnect(), !1)
        },
        _connect_cb_wrapper: function(t) {
            if (0 === t.data.indexOf("<stream:stream ") || 0 === t.data.indexOf("<?xml")) {
                var e = t.data.replace(/^(<\?.*?\?>\s*)*/, "");
                if ("" === e) return;
                e = t.data.replace(/<stream:stream (.*[^\/])>/, "<stream:stream $1/>");
                var n = (new DOMParser).parseFromString(e, "text/xml").documentElement;
                this._conn.xmlInput(n), this._conn.rawInput(t.data), this._handleStreamStart(n) && (this._connect_cb(n), this.streamStart = t.data.replace(/^<stream:(.*)\/>$/, "<stream:$1>"))
            } else {
                if ("</stream:stream>" === t.data) return this._conn.rawInput(t.data), this._conn.xmlInput(document.createElement("stream:stream")), this._conn._changeConnectStatus(Strophe.Status.CONNFAIL, "Received closing stream"), void this._conn._doDisconnect();
                var s = this._streamWrap(t.data),
                    i = (new DOMParser).parseFromString(s, "text/xml").documentElement;
                this.socket.onmessage = this._onMessage.bind(this), this._conn._connect_cb(i, null, t.data)
            }
        },
        _disconnect: function(t) {
            if (this.socket.readyState !== WebSocket.CLOSED) {
                t && this._conn.send(t);
                var e = "</stream:stream>";
                this._conn.xmlOutput(document.createElement("stream:stream")), this._conn.rawOutput(e);
                try {
                    this.socket.send(e)
                } catch (t) {
                    Strophe.info("Couldn't send closing stream tag.")
                }
            }
            this._conn._doDisconnect()
        },
        _doDisconnect: function() {
            Strophe.info("WebSockets _doDisconnect was called"), this._closeSocket()
        },
        _streamWrap: function(t) {
            return this.streamStart + t + "</stream:stream>"
        },
        _closeSocket: function() {
            if (this.socket) try {
                this.socket.close()
            } catch (t) {}
            this.socket = null
        },
        _emptyQueue: function() {
            return !0
        },
        _onClose: function() {
            this._conn.connected && !this._conn.disconnecting ? (Strophe.error("Websocket closed unexcectedly"), this._conn._doDisconnect()) : Strophe.info("Websocket closed")
        },
        _no_auth_received: function(t) {
            Strophe.error("Server did not send any auth methods"), this._conn._changeConnectStatus(Strophe.Status.CONNFAIL, "Server did not send any auth methods"), t && (t = t.bind(this._conn))(), this._conn._doDisconnect()
        },
        _onDisconnectTimeout: function() {},
        _onError: function(t) {
            Strophe.error("Websocket error " + t), this._conn._changeConnectStatus(Strophe.Status.CONNFAIL, "The WebSocket connection could not be established was disconnected."), this._disconnect()
        },
        _onIdle: function() {
            var t = this._conn._data;
            if (t.length > 0 && !this._conn.paused) {
                let S = this._getAnalyticsCookie();
                for (var e = 0; e < t.length; e++)
                    if (null !== t[e]) {
                        var n, s;
                        "restart" === t[e] ? (n = this._buildStream(), s = this._removeClosingTag(n), n = n.tree()) : (n = t[e], s = Strophe.serialize(n)), this._conn.xmlOutput(n), this._conn.rawOutput(s);
                        var i = "";
                        switch (n.nodeName) {
                            case "message":
                                var r, o, a = "",
                                    h = n.getAttribute("to").split("@");
                                h = h[0];
                                var c = n.getAttribute("adid"),
                                    l = n.getAttribute("id"),
                                    d = n.getAttribute("type"),
                                    u = n.getAttribute("stime");
                                if (n.hasChildNodes() && "body" == n.childNodes[0].nodeName) var m = n.childNodes[0].textContent;
                                switch (d) {
                                    case "chat":
                                        switch (r = "m", l) {
                                            case "typing":
                                                r = "0" == m ? "nt" : "t", o = h + ";" + c, a = "<b>" + m + "</b>";
                                                break;
                                            default:
                                                if (o = h + ";" + c + ";" + l, a = "<b>" + m + "</b>", l.match(/(.*)-(\d*)_(\d*)/) && ("v" == l[4] || "a" == l[4])) {
                                                    var _ = n.getAttribute("duration"),
                                                        p = "";
                                                    if ("v" == l[4]) {
                                                        p = n.getAttribute("filesize");
                                                        (isNaN(p) || null == p) && (p = "")
                                                    }(isNaN(_) || null == _) && (_ = ""), a = "<b t='" + (p + ";" + _) + "'>" + m + "</b>"
                                                }
                                                break;
                                            case "presence":
                                                "off" == m && (r = "p0", o = h + ";" + c), "on" == m && (r = "p1", o = h + ";" + c)
                                        }
                                        break;
                                    case "result":
                                        "recv" == m && (r = "r", o = h + ";" + c + ";" + l + ";" + u), "seen" == m && (r = "e", o = h + ";" + c + ";" + l + ";" + u)
                                }
                                S && (o = o ? o + ";" + S : S), i = a ? "<" + r + " i='" + o + "' >" + a + "</" + r + ">" : "<" + r + " i='" + o + "' />";
                                break;
                            case "iq":
                                if (n.getAttribute("id").indexOf("ping") >= 0) {
                                    var f = n.getAttribute("id");
                                    i = '<p i="r;' + f + '" ></p>'
                                }
                                if (n.getAttribute("id").indexOf("all1") >= 0) {
                                    var g = n.getElementsByTagName("item");
                                    Array.prototype.forEach.call(g, function(t, e) {
                                        var n = t.getAttribute("value"),
                                            s = t.getAttribute("action");
                                        i = '<bl i="' + (s = "allow" == s ? "d" : "a") + ";" + n + '"></bl>'
                                    })
                                } else if (n.getAttribute("id").indexOf("getlist2") >= 0) i = '<bl i="g"></bl>';
                                else if (n.getAttribute("type").indexOf("header") >= 0) {
                                    if (n.hasChildNodes() && "body" == n.childNodes[0].nodeName) m = n.childNodes[0].textContent;
                                    var b = "<b>" + m + "</b>";
                                    i = '<h i="' + n.getAttribute("id") + '">' + b + "</h>"
                                }
                        }
                        i && (s = i), this.socket.send(s)
                    }
                this._conn._data = []
            }
        },
        _onMessage: function(t) {
            if (t && t.data && t.data.replace(/ /g, "")) {
                var e, n, s, i = (s = t.data).match(/^.*<(\w{1,2})\s*i=["|'](.*?)['|"][\w|\s|\/]*>/);
                if (i && i.length > 0) {
                    var r, o, a, h, c, l, d = "0",
                        u = "",
                        m = "",
                        _ = "",
                        p = i[2].split(";"),
                        f = p[0].split("@");
                    switch (f && f.length > 0 && (p[0] = f[0]), i[1]) {
                        case "m":
                            if (o = "", a = p[0] + "@" + this._conn.domain, h = p[1], r = p[2], d = p[3], (S = s.match(/<b>([\w\W]*)<\/b>/)) && S.length > 0 && (c = S[1]), r.match(/(.*)-(\d*)_(\d*)/))
                                if ("v" == r[4] || "a" == r[4] || "d" == r[4]) {
                                    if ((S = s.match(/<b\s*t="(.*?)"\s*>([\w\W]*)<\/b>/)) && S.length > 0) {
                                        c = S[2];
                                        var g = S[1].split(";");
                                        g[0] && (m += ' filesize="' + g[0] + '" ');
                                        g[1] && (m += ' duration="' + g[1] + '" ')
                                    }
                                } else if ((r[4].match(/[s|p]/) || "x" == r[4] && r[5].match(/[s|p]/)) && s.match(/<md>(.*)<\/md>/)) {
                                var b = s.match(/<md>(.*)<\/md>/);
                                _ += " metadata='" + Base64.encode(b[1]) + "' "
                            }
                            l = "chat", u = "message";
                            break;
                        case "nt":
                            o = "", a = p[0] + "@" + this._conn.domain, h = p[1], r = "typing", l = "chat", c = "0", u = "message";
                            break;
                        case "t":
                            o = "", a = p[0] + "@" + this._conn.domain, h = p[1], r = "typing", l = "chat", c = "1", u = "message";
                            break;
                        case "e":
                            o = "", a = p[0] + "@" + this._conn.domain, h = p[1], r = p[2], d = p[3], l = "result", c = "seen", u = "message";
                            break;
                        case "r":
                            o = "", a = p[0] + "@" + this._conn.domain, h = p[1], r = p[2], d = p[3], l = "result", c = "recv", u = "message";
                            break;
                        case "s":
                            o = "", a = p[0] + "@" + this._conn.domain, h = p[1], r = p[2], d = p[3], l = "result", c = "sent", u = "message";
                            break;
                        case "p0":
                            o = "", a = p[0] + "@" + this._conn.domain, h = p[1], r = "presence", c = "off", l = "chat", u = "message";
                            break;
                        case "p1":
                            o = "", a = p[0] + "@" + this._conn.domain, h = p[1], r = "presence", c = "on", l = "chat", u = "message";
                            break;
                        case "p":
                            o = "", r = p[1], a = this._conn.domain, "g" == p[0] && (l = "get"), u = "iq";
                            break;
                        case "bl":
                            var S;
                            if ((S = s.match(/^.*<bl\s*i="(.*)"\s*><b>([\w\W]*)<\/b><\/bl>/)) && S.length > 0) c = S[2], r = "block", a = "";
                            else {
                                var v = s.match(/^.*<bl\s*i="(.*)"\s*\/>/);
                                if (v) {
                                    var T = v[1].split(";");
                                    a = T[1], r = "y" == T[0] ? "block1" : "block0"
                                }
                            }(S || v) && (d = "", l = "chat", o = "", h = "", u = "message")
                    }
                    switch (c = c.replace(/\&nbsp;/g, " "), u) {
                        case "message":
                            s = '<message id="' + r + '" stime="' + d + '" type="' + l + '" to="' + o + '" from="' + a + '" adid="' + h + '" ' + m + " " + _ + ' xmlns="jabber:client"><body >' + c + '</body><active xmlns="http://jabber.org/protocol/chatstates"></active></message>';
                            break;
                        case "iq":
                            s = '<iq to="' + o + '" type="' + l + '" from="' + a + '" id="' + r + '"><ping ></ping></iq>'
                    }
                }
                if ("</stream:stream>" === s) {
                    return this._conn.rawInput("</stream:stream>"), this._conn.xmlInput(document.createElement("stream:stream")), void(this._conn.disconnecting || this._conn._doDisconnect())
                }
                if (0 === s.search("<stream:stream ")) {
                    if (n = s.replace(/<stream:stream (.*[^\/])>/, "<stream:stream $1/>"), e = (new DOMParser).parseFromString(n, "text/xml").documentElement, !this._handleStreamStart(e)) return
                } else n = this._streamWrap(s), e = (new DOMParser).parseFromString(n, "text/xml").documentElement;
                if (!this._check_streamerror(e, Strophe.Status.ERROR)) {
                    if (this._conn.disconnecting && "presence" === e.firstChild.nodeName && "unavailable" === e.firstChild.getAttribute("type")) return this._conn.xmlInput(e), void this._conn.rawInput(Strophe.serialize(e));
                    var y = e.getElementsByTagName("iq");
                    if (s.indexOf("<ping") >= 0) {
                        var N = $iq({
                            type: "result",
                            id: y[0].getAttribute("id"),
                            to: y[0].attributes.from.value
                        });
                        connection.sendIQ(N)
                    }
                    this._conn._dataRecv(e, s)
                }
            }
        },
        _onOpen: function() {
            Strophe.info("Websocket open");
            var t = this._buildStream();
            this._conn.xmlOutput(t.tree());
            var e = this._removeClosingTag(t);
            this._conn.rawOutput(e), this.socket.send(e)
        },
        _removeClosingTag: function(t) {
            var e = Strophe.serialize(t);
            return e = e.replace(/<(stream:stream .*[^\/])\/>$/, "<$1>")
        },
        _getAnalyticsCookie: function() {
            let t = function(t) {
                let e = document.cookie.match(new RegExp("(^| )" + t + "=([^;]+)"));
                return e ? e[2] : null
            }("_jk_id");
            return t ? t.split(".")[0] : null
        },
        _reqToData: function(t) {
            return t
        },
        _send: function() {
            this._conn.flush()
        },
        _sendRestart: function() {
            clearTimeout(this._conn._idleTimeout), this._conn._onIdle.bind(this._conn)()
        }
    };