! function(t) {
    function e(n) {
        if (i[n]) return i[n].exports;
        var a = i[n] = {
            exports: {},
            id: n,
            loaded: !1
        };
        return t[n].call(a.exports, a, a.exports, e), a.loaded = !0, a.exports
    }
    var n = window.webpackJsonp;
    window.webpackJsonp = function(i, o) {
        for (var s, r, d = 0, l = []; d < i.length; d++) r = i[d], a[r] && l.push.apply(l, a[r]), a[r] = 0;
        for (s in o) Object.prototype.hasOwnProperty.call(o, s) && (t[s] = o[s]);
        for (n && n(i, o); l.length;) l.shift().call(null, e)
    };
    var i = {},
        a = {
            31: 0
        };
    return e.e = function(t, n) {
        if (0 === a[t]) return n.call(null, e);
        if (void 0 !== a[t]) a[t].push(n);
        else {
            a[t] = [n];
            var i = document.getElementsByTagName("head")[0],
                o = document.createElement("script");
            o.type = "text/javascript", o.charset = "utf-8", o.async = !0, o.src = e.p + "" + ({
                0: "template9",
                1: "template10",
                2: "template6",
                3: "template4",
                4: "template3",
                5: "template2",
                6: "template15",
                7: "template13",
                8: "template12",
                9: "template11",
                10: "template1",
                11: "templateol",
                12: "template5",
                13: "template14"
            }[t] || t) + ".js", i.appendChild(o)
        }
    }, e.m = t, e.c = i, e.p = "https://teja8.kuikr.com/public/mon/qapqdfp/dist/3.3.4/", e(0)
}([function(t, e, n) {
    "use strict";

    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }
    var a = n(26),
        o = i(a),
        s = n(37);
    new o.default(s.config, s.pages)
}, function(t, e) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.NetworkId = "81214979", e.IS_DEV = !1, e.A_BLOCK_KEY = "br_adb", e.LS_KEY = "mon_active_session", e.INTAD_EVENT = "START_INTAD", e.QAP_VERSION = "4.8.4"
}, function(t, e) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), window.googletag = window.googletag || {}, window.googletag.cmd = window.googletag.cmd || [], e.gtag = window.googletag, e.cmd = window.googletag.cmd, ! function(t, e) {
        t[e] = t[e] || function() {
            (t[e].q = t[e].q || []).push(arguments)
        }, t[e].t = 1 * new Date
    }(window, "_googCsa")
}, function(t, e) {
    "use strict";

    function n(t, e, n) {
        window._gaq.push(["_trackEvent", t, e, n, 0, !0])
    }

    function i(t, e) {
        return t.ads.find(function(t) {
            return t.slot === e
        })
    }

    function a(t) {
        return Object.keys(t).map(function(e) {
            return encodeURIComponent(e) + "=" + encodeURIComponent(t[e])
        }).join("&")
    }

    function o() {
        return document.cookie.search("br_imblk=t") !== -1
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    };
    e.gaTrack = n, e.getSlotData = i, e.buildQuery = a, e.isAdBlock = o;
    var r = (e.listen = function(t, e, n) {
            e.addEventListener ? e.addEventListener(t, n, !1) : e.attachEvent ? e.attachEvent("on" + t, n) : console.log("listen is not supported!")
        }, e.objectHasKey = function(t, e) {
            return t.hasOwnProperty("key")
        }, e.objectHasKeys = function(t, e) {
            return e.reduce(function(e, n) {
                return t.hasOwnProperty(n)
            }, !0)
        }, e.getCookieVal = function(t) {
            var e = null,
                n = null,
                i = document.cookie.split(";");
            return i.forEach(function(i) {
                e = i.split("=");
                var a = e[0].trim();
                a === t && (n = e[1])
            }), n
        }, e.getPageQapRequest = function(t) {
            var e = t.ads;
            e = e.filter(function(t) {
                return !t.useQapV2
            });
            var n = e.map(function(t) {
                return {
                    slot: t.slot,
                    adcode: t.adcode
                }
            });
            return n
        }, e.getQapSlotIds = function(t) {
            var e = t.ads;
            return e.filter(function(t) {
                return t.preferQap === !0 && !t.useQapV2
            }).map(function(t) {
                return t.slot
            })
        }, e.arrayCompare = function(t, e, n) {
            switch (n) {
                case "=":
                    return t.length === e.length && t.every(function(t, n) {
                        t === e[n]
                    });
                case ">":
                    return t.length === e.length && t.every(function(t, n) {
                        t >= e[n]
                    });
                case "<":
                    return t.length === e.length && t.every(function(t, n) {
                        t <= e[n]
                    })
            }
        }),
        d = (e.validViewport = function(t, e) {
            if ("undefined" == typeof t && "undefined" == typeof e) return !0;
            var n = Math.max(document.documentElement.clientWidth, window.innerWidth || 0),
                i = Math.max(document.documentElement.clientHeight, window.innerHeight || 0),
                a = [];
            return a.push(n), a.push(i), "undefined" == typeof t && "object" === ("undefined" == typeof e ? "undefined" : s(e)) ? r(e, a, ">") : "object" === ("undefined" == typeof t ? "undefined" : s(t)) && "undefined" == typeof e ? r(t, a, "<") : r(e, a, ">") && r(t, a, "<")
        }, e.getLocalStorageItem = function(t) {
            return d() ? localStorage.getItem(t) : null
        }, e.setKey = function(t, e) {
            e = JSON.stringify(e), d() && localStorage.setItem(t, e)
        }, e.getKey = function(t) {
            return d() ? JSON.parse(localStorage.getItem(t)) : null
        }, e.hasLocalStorage = function() {
            try {
                return localStorage.setItem("mod", "mod"), localStorage.removeItem("mod"), !0
            } catch (t) {
                return !1
            }
        });
    window._gaq = window._gaq || []
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.clearPageTargeting = e.pageTargeting = e.clearSlotTargeting = e.slotTargeting = void 0, n(2), e.slotTargeting = function(t, e) {
        e.forEach(function(e) {
            var n = e.key,
                i = e.value;
            t.setTargeting(n, i)
        })
    }, e.clearSlotTargeting = function(t) {
        t.clearTargeting()
    }, e.pageTargeting = function(t) {
        var e = googletag.pubads();
        t.forEach(function(t) {
            var n = t.key,
                i = t.value;
            e.setTargeting(n, i)
        })
    }, e.clearPageTargeting = function() {
        var t = googletag.pubads();
        t.clearTargeting()
    }
}, function(t, e, n) {
    "use strict";

    function i(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }

    function a(t) {
        qap.cmd.push(t)
    }

    function o() {
        if (!c) {
            c = !0;
            var t = document.createElement("script"),
                e = "https:" == document.location.protocol;
            t.async = !0, t.type = "text/javascript", t.src = (e ? "https://teja8" : "http://teja2") + ".kuikr.com/public/mon/qap/" + l.QAP_VERSION + "/lib.js";
            var n = document.getElementsByTagName("script")[0];
            n.parentNode.insertBefore(t, n)
        }
    }

    function s(t) {
        a(t.useDataAttribute ? function() {
            qap.createMultiSlot(t.slot, t.adcode, t.sizes[0][0], t.sizes[0][1])
        } : function() {
            qap.createInlineSlot(t.slot, t.adcode, t.sizes[0][0], t.sizes[0][1])
        }), o()
    }

    function r(t) {
        a(function() {
            qap.createOverlaySlot(t.adcode, t.width, t.height)
        }), o()
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.PageQap = void 0;
    var d = function() {
        function t(t, e) {
            for (var n = 0; n < e.length; n++) {
                var i = e[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
            }
        }
        return function(e, n, i) {
            return n && t(e.prototype, n), i && t(e, i), e
        }
    }();
    e.loadQap = o, e.createQapSlot = s, e.createQapOverlay = r;
    var l = (n(3), n(1)),
        c = !1;
    window.qap = window.qap || {}, qap.cmd = qap.cmd || [], e.PageQap = function() {
        function t(e, n) {
            i(this, t), this.config = e, this.pdata = n
        }
        return d(t, null, [{
            key: "init",
            value: function(e, n) {
                return new t(e, n)
            }
        }]), d(t, [{
            key: "showDynamic",
            value: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                    n = this.pdata.dynads,
                    i = Object.assign({}, n[e]);
                i.slot = t, s(i)
            }
        }, {
            key: "getAdForDivId",
            value: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                    n = this.pdata.dynads,
                    i = Object.assign({}, n[e]);
                i.slot = t, s(i)
            }
        }]), t
    }(), window.qdfp_vp && window.qdfp_vp.ptargeting && window.qdfp_vp.ptargeting.forEach(function(t) {
        a(function() {
            qap.setTargeting(t.key.toLowerCase(), t.value.toString().toLowerCase().replace(/\s/g, "").replace(/&/, "-"))
        })
    })
}, function(t, e, n) {
    "use strict";

    function i(t) {
        a(t, function(t, e) {
            t || Object.keys(e).forEach(function(t) {
                u(t, e[t])
            })
        })
    }

    function a(t, e) {
        var n = (0, r.getTargetingParams)();
        n.adCodes = JSON.stringify(t), o.Util.ajax({
            method: "POST",
            url: s.Constants.domain + "getNativeAdsForSlots",
            data: n,
            onSuccess: function(t) {
                var n = JSON.parse(t.responseText);
                e(null, n)
            },
            onFailure: function(t) {
                e(!0)
            }
        })
    }
    var o = n(7),
        s = n(29),
        r = n(31),
        d = n(30),
        l = n(32),
        c = function() {
            var t = 0;
            if ("undefined" != typeof Storage) {
                try {
                    var e = sessionStorage.getItem(s.Constants.cookieName)
                } catch (t) {}
                void 0 !== e && (t = e)
            }
            if (t++, t <= s.Constants.sessionCap) {
                var n = (0, r.getTargetingParams)();
                if (o.Util.ajax({
                        method: "GET",
                        url: s.Constants.domain + s.Constants.nativeAdApi,
                        data: n,
                        onSuccess: function(t) {
                            try {
                                var e = JSON.parse(t.responseText),
                                    n = new d.NativeAdOverlay;
                                l.create(n.container.id, e)
                            } catch (t) {
                                void 0 !== n.container && n.container.remove(), console.log(t)
                            }
                        }
                    }), "undefined" != typeof Storage) try {
                    sessionStorage.setItem(s.Constants.cookieName, t)
                } catch (t) {}
            }
        },
        u = function(t, e) {
            try {
                var n = document.getElementById(t);
                n && (n.innerHTML = "", n.style.display = "block", n.removeAttribute("data-google-query-id")), l.create(t, e)
            } catch (t) {
                console.log(t)
            }
        },
        p = function() {
            try {
                var t = new d.NativeAdOverlay;
                l.create(t.container.id, {
                    templateType: "onlineleads"
                })
            } catch (t) {
                console.log(t)
            }
        };
    t.exports = {
        showNativeAdInDiv: u,
        showNativeAdsInSlots: i,
        fetchNativeAdsForSlots: a,
        showNativeAdInOverlay: c,
        showStaticNativeAdInOverlay: p
    }
}, function(t, e) {
    "use strict";

    function n(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var i = function() {
        function t(t, e) {
            for (var n = 0; n < e.length; n++) {
                var i = e[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
            }
        }
        return function(e, n, i) {
            return n && t(e.prototype, n), i && t(e, i), e
        }
    }();
    e.Util = function() {
        function t() {
            n(this, t)
        }
        return i(t, null, [{
            key: "ajax",
            value: function(t) {
                var e = new XMLHttpRequest;
                if (t.data) var n = Object.keys(t.data).map(function(e) {
                    return encodeURIComponent(e) + "=" + encodeURIComponent(t.data[e])
                }).join("&");
                "GET" === t.method ? (e.open("GET", t.url + "?" + n, !0), e.send()) : "POST" === t.method && (e.open("POST", t.url, !0), e.setRequestHeader("Content-type", "application/x-www-form-urlencoded"), e.send(n)), e.onreadystatechange = function() {
                    4 === e.readyState && (200 === e.status ? t.onSuccess(e) : (t.onFailure && t.onFailure(e), console.log("Error: " + e.statusText)))
                }
            }
        }, {
            key: "getCookie",
            value: function(t) {
                for (var e = t + "=", n = document.cookie.split(";"), i = 0; i < n.length; i++) {
                    for (var a = n[i];
                        " " == a.charAt(0);) a = a.substring(1);
                    if (0 == a.indexOf(e)) return a.substring(e.length, a.length)
                }
                return ""
            }
        }]), t
    }()
}, function(t, e, n) {
    "use strict";

    function i(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.Interstitial = void 0;
    var a = function() {
            function t(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var i = e[n];
                    i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
                }
            }
            return function(e, n, i) {
                return n && t(e.prototype, n), i && t(e, i), e
            }
        }(),
        o = n(3),
        s = n(1);
    e.Interstitial = function() {
        function t(e) {
            i(this, t), this.expiry = e.expiry, this.freq = e.freq, this.key = s.LS_KEY, this.interval = e.interval, this.firstShow = e.firstshow;
            var n = (0, o.getKey)(this.key);
            "undefined" != typeof n && null !== n || this.resetUser()
        }
        return a(t, null, [{
            key: "init",
            value: function(e) {
                return new t(e)
            }
        }]), a(t, [{
            key: "fire",
            value: function() {
                this.isActiveUser() && this.startTimer(), this.updateUser()
            }
        }, {
            key: "isActiveUser",
            value: function() {
                var t = (0, o.getKey)(this.key);
                return "undefined" != typeof t && null !== t && (this.expired(t.lastShown) && this.resetUser(), t = (0, o.getKey)(this.key), !(!this.inCap(t.count) || !this.inTime(t.lastShown)))
            }
        }, {
            key: "expired",
            value: function(t) {
                return (new Date).getTime() - t >= this.expiry
            }
        }, {
            key: "inCap",
            value: function(t) {
                return t == this.firstShow || 0 != t && (t - this.firstShow) % this.freq == 0
            }
        }, {
            key: "inTime",
            value: function(t) {
                return (new Date).getTime() - t >= this.interval
            }
        }, {
            key: "startTimer",
            value: function() {
                setTimeout(this.loadInterstitial.bind(this), this.interval)
            }
        }, {
            key: "loadInterstitial",
            value: function() {
                var t = window.QDFP;
                t.showInterstitial()
            }
        }, {
            key: "updateUser",
            value: function() {
                var t = (0, o.getKey)(this.key);
                "undefined" != typeof t && null !== t && (t.lastShown = (new Date).getTime(), t.count = parseInt(t.count) + 1, (0, o.setKey)(this.key, t))
            }
        }, {
            key: "resetUser",
            value: function() {
                var t = {};
                t.lastShown = (new Date).getTime(), t.count = 0, (0, o.setKey)(this.key, t)
            }
        }]), t
    }()
}, , , , , , , , , , , , , , , function(t, e, n) {
    "use strict";

    function i(t) {
        if (Array.isArray(t)) {
            for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
            return n
        }
        return Array.from(t)
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.displaySlot = e.defineSlot = void 0;
    var a = n(1),
        o = (n(4), n(2)),
        s = (e.defineSlot = function(t) {
            var e = r(t);
            return function() {
                o.gtag.defineSlot.apply(o.gtag, i(e)).addService(o.gtag.pubads())
            }
        }, function(t) {
            return "/" + a.NetworkId + "/" + t
        }),
        r = function(t) {
            var e = t.adcode,
                n = t.sizes,
                i = t.slot,
                a = s(e);
            return [a, n, i]
        };
    e.displaySlot = function(t) {
        return function() {
            o.gtag.display(t)
        }
    }
}, function(t, e) {
    "use strict";

    function n(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var i = function() {
        function t(t, e) {
            for (var n = 0; n < e.length; n++) {
                var i = e[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
            }
        }
        return function(e, n, i) {
            return n && t(e.prototype, n), i && t(e, i), e
        }
    }();
    e.AFSH = function() {
        function t(e) {
            n(this, t), this.defaultOptions = e.defaultOptions, this.type = e.type, this.afshBlock = {
                container: e.container,
                width: e.width,
                height: e.height
            }, this.loadJS()
        }
        return i(t, [{
            key: "loadJS",
            value: function() {
                var t = document.createElement("script");
                t.async = !0, t.type = "text/javascript", t.src = "https://www.google.com/adsense/search/ads.js", document.head.appendChild(t)
            }
        }, {
            key: "show",
            value: function(t) {
                var e = Object.assign({}, this.defaultOptions, t);
                "multi" === this.type ? _googCsa("plas", e, this.afshBlock) : _googCsa("single-product", e, this.afshBlock)
            }
        }]), t
    }()
}, function(t, e) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.loadGpt = function() {
        var t = document.createElement("script");
        t.async = !0, t.type = "text/javascript";
        var e = "https:" == document.location.protocol;
        t.src = (e ? "https:" : "http:") + "//www.googletagservices.com/tag/js/gpt.js";
        var n = document.getElementsByTagName("script")[0];
        n.parentNode.insertBefore(t, n)
    }
}, function(t, e, n) {
    "use strict";

    function i(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var a = function() {
            function t(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var i = e[n];
                    i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
                }
            }
            return function(e, n, i) {
                return n && t(e.prototype, n), i && t(e, i), e
            }
        }(),
        o = n(27),
        s = n(3),
        r = n(1),
        d = n(5);
    "function" != typeof Object.assign && (Object.assign = function(t, e) {
        if (null == t) throw new TypeError("Cannot convert undefined or null to object");
        for (var n = Object(t), i = 1; i < arguments.length; i++) {
            var a = arguments[i];
            if (null != a)
                for (var o in a) Object.prototype.hasOwnProperty.call(a, o) && (n[o] = a[o])
        }
        return n
    });
    var l = function() {
        function t(e, n, a) {
            i(this, t), this.config = e, this.pages = n, this.options = a, this.init()
        }
        return a(t, [{
            key: "init",
            value: function() {
                var t = !0;
                this.options && "undefined" != typeof this.options.changePublicPath && (t = this.options.changePublicPath), t && ("https:" === document.location.protocol ? n.p = "https://teja10.kuikr.com/public/mon/qapqdfp/dist/3.3.4/" : n.p = "http://teja2.kuikr.com/public/mon/qapqdfp/dist/3.3.4/");
                var e = this.getQdfpObj(),
                    i = this.pages.filter(function(t) {
                        return t.id === e.id && t
                    });
                window.QDFP = window.QDFP || {}, QDFP.dynamicSlots = QDFP.dynamicSlots || [], window.QDFP.showInterstitial = function() {}, window.QDFP.getAdForDivId = function() {}, i[0].loadQap && (0, d.loadQap)();
                var a = (0, s.getLocalStorageItem)(r.A_BLOCK_KEY);
                try {
                    a = JSON.parse(a).value
                } catch (t) {
                    a = "f"
                }
                if ("t" === a) {
                    (0, s.listen)("DOMContentLoaded", document, function() {
                        var t = n(6),
                            e = (0, s.getPageQapRequest)(i[0]);
                        e.length > 0 && t.showNativeAdsInSlots(e), i[0].ads.filter(function(t) {
                            return t.useQapV2 === !0
                        }).forEach(d.createQapSlot), i[0].overlay && (0, d.createQapOverlay)(i[0].overlay), this.trackFramework("native")
                    }.bind(this));
                    var l = d.PageQap.init(this.config, i[0])
                } else {
                    var c = !this.options || this.options && !this.options.hasOwnProperty("isEventListeningRequired") || this.options && this.options.isEventListeningRequired,
                        u = !this.options || this.options && !this.options.hasOwnProperty("isInterstitialAdEventDispatchRequired") || this.options && this.options.isInterstitialAdEventDispatchRequired,
                        l = o.Page.init(this.config, i[0], {
                            isEventListeningRequired: c,
                            isInterstitialAdEventDispatchRequired: u
                        });
                    window.QDFP.showInterstitial = l.showInterstitial.bind(l), this.trackFramework("qdfp")
                }
                window.QDFP.getAdForDivId = l.getAdForDivId.bind(l), window.QDFP.getDynamicAdsSingleRequest = l.getDynamicAdsSingleRequest.bind(l)
            }
        }, {
            key: "trackFramework",
            value: function(t) {}
        }, {
            key: "getQdfpObj",
            value: function() {
                var t = this.getGmon();
                return window.qdfp_vp = window.qdfp_vp || {
                    id: "1",
                    ptargeting: [{
                        key: "City",
                        value: t.cityname
                    }, {
                        key: "Category",
                        value: t.catname
                    }, {
                        key: "SubCat",
                        value: t.subcatname
                    }],
                    stargeting: {
                        "Desktop_SnB_Top_735X125(728X90)": [{
                            key: "Test",
                            value: "A"
                        }]
                    }
                }, qdfp_vp
            }
        }, {
            key: "getGmon",
            value: function() {
                var t = window.gmon || {
                    cityname: "",
                    catname: "",
                    subcatname: ""
                };
                return t
            }
        }]), t
    }();
    e.default = l
}, function(t, e, n) {
    "use strict";

    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }

    function a(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.Page = void 0;
    var o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        },
        s = function() {
            function t(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var i = e[n];
                    i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
                }
            }
            return function(e, n, i) {
                return n && t(e.prototype, n), i && t(e, i), e
            }
        }(),
        r = n(2),
        d = n(3),
        l = n(25),
        c = n(28),
        u = i(c),
        p = n(23),
        g = n(1),
        f = n(8),
        h = n(4),
        v = n(5),
        _ = n(24),
        m = n(6);
    e.Page = function() {
        function t(e, n) {
            var i = this,
                o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
                    isEventListeningRequired: !0,
                    isInterstitialAdEventDispatchRequired: !0
                };
            if (a(this, t), this.preSlots = [], this.postSlots = [], this.dynSlots = [], this.dynAds = [], this.interstitialAds = [], this.interstitialSlots = [], this.pdata = n, this.config = e, this.isEventListeningRequired = o.isEventListeningRequired, this.isInterstitialAdEventDispatchRequired = o.isInterstitialAdEventDispatchRequired, window.qdfp_vp.pixelAdUnit || this.pdata.pixelAdUnit || this.config.pixelAdUnit) {
                var s = window.qdfp_vp.pixelAdUnit || this.pdata.pixelAdUnit || this.config.pixelAdUnit,
                    r = "qdfp_pixel_" + (new Date).getTime(),
                    l = document.createElement("div");
                l.id = r, l.style = "position:fixed;top:0px;left:0px;height:1px;width:1px;", document.body.appendChild(l), this.pdata.ads.push({
                    top: !1,
                    slot: r,
                    adcode: s,
                    sizes: [
                        [1, 1]
                    ],
                    targeting: []
                })
            }
            this.pageTarget = this.getTargeting(), this.addListeners(), this.emptySlots = (0, d.getQapSlotIds)(this.pdata), this.pdata.multirequest ? this.emptySlots.length > 0 && this.emptySlots.forEach(function(t) {
                i.showQapAd(t)
            }) : (this.qapResponse = null, this.qapRequestSent = !1, this.emptySlots.length > 0 && this.fetchQapAds()), g.IS_DEV && this.dev()
        }
        return s(t, null, [{
            key: "init",
            value: function(e, n) {
                var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
                    isEventListeningRequired: !0,
                    isInterstitialAdEventDispatchRequired: !0
                };
                return new t(e, n, i)
            }
        }]), s(t, [{
            key: "fetchQapAds",
            value: function() {
                var t = this;
                if (!this.qapRequestSent) {
                    this.qapRequestSent = !0;
                    var e = (0, d.getPageQapRequest)(this.pdata);
                    m.fetchNativeAdsForSlots(e, function(e, n) {
                        if (!e)
                            for (t.qapResponse = n; t.emptySlots.length;) {
                                var i = t.emptySlots.pop();
                                void 0 !== n[i] && m.showNativeAdInDiv(i, n[i])
                            }
                    })
                }
            }
        }, {
            key: "showQapAd",
            value: function(t) {
                var e = this.pdata.ads.find(function(e) {
                    return e.slot === t
                });
                if (void 0 != e) {
                    var n = [{
                        slot: e.slot,
                        adcode: e.adcode
                    }];
                    (0, d.gaTrack)("qap_request", e.adcode, ""), m.fetchNativeAdsForSlots(n, function(n, i) {
                        n || ((0, d.gaTrack)("qap_response", e.adcode, i[t] ? "found" : "empty"), void 0 !== i[t] && m.showNativeAdInDiv(t, i[t]))
                    })
                }
            }
        }, {
            key: "dev",
            value: function() {
                var t = this,
                    e = document.createElement("button");
                e.id = "dfp-debug-btn", document.body.appendChild(e);
                var n = document.getElementById("dfp-debug-btn");
                e.innerHTML = "TEST BTN", n && n.addEventListener("click", function(e) {
                    t.showInterstitial()
                })
            }
        }, {
            key: "getTargeting",
            value: function() {
                return window.qdfp_vp.hasOwnProperty("ptargeting") ? window.qdfp_vp.ptargeting : []
            }
        }, {
            key: "addListeners",
            value: function() {
                var t = this;
                this.isEventListeningRequired && ("complete" === document.readyState ? (this.onDomLoadedHandler(), this.onLoadHandler()) : "interactive" === document.readyState ? (this.onDomLoadedHandler(), (0, d.listen)("load", window, this.onLoadHandler.bind(this))) : ((0, d.listen)("DOMContentLoaded", window, this.onDomLoadedHandler.bind(this)), (0, d.listen)("load", window, this.onLoadHandler.bind(this))), (0, d.listen)("message", window, this.onMessage.bind(this)), this.enqueue(function() {
                    r.gtag.pubads().addEventListener("slotRenderEnded", t.onSlotRenderEnded.bind(t))
                }))
            }
        }, {
            key: "onMessage",
            value: function(t) {
                var e = t.data;
                "dfp.click" === e.event && (window.dataLayer = window.dataLayer || [], dataLayer.push({
                    event: "dfp.click",
                    data: e.data
                }))
            }
        }, {
            key: "onSlotRenderEnded",
            value: function(t) {
                if (t.isEmpty) {
                    var e = t.slot.getSlotElementId();
                    if (this.pdata.interstitials && this.pdata.interstitials[0] && this.pdata.interstitials[0].slot == e) return;
                    this.pdata.multirequest ? this.showQapAd(e) : null !== this.qapResponse ? void 0 !== this.qapResponse[e] && m.showNativeAdInDiv(e, this.qapResponse[e]) : (this.emptySlots.push(e), this.fetchQapAds())
                }
            }
        }, {
            key: "onDomLoadedHandler",
            value: function() {
                this.config.preload && ((0, l.loadGpt)(), this.configurePreload()), this.showQapV2Ads()
            }
        }, {
            key: "onLoadHandler",
            value: function() {
                this.config.preload || (0, l.loadGpt)(), this.configurePostload(), this.showQapV2Ads(), this.pdata.afsh && (QDFP.afsh = new _.AFSH(this.pdata.afsh), qdfp_vp.afsh_options && QDFP.afsh.show(qdfp_vp.afsh_options))
            }
        }, {
            key: "configurePreload",
            value: function() {
                var t = this.getAds(this.pdata.ads, !0);
                this.lineUpPreAds(t), this.disableInitialLoad(), this.showPreloadAds()
            }
        }, {
            key: "configurePostload",
            value: function() {
                var t = this,
                    e = this.getAds(this.pdata.ads, !1);
                this.lineUpPostAds(e);
                var n = this.pdata.interstitials;
                this.lineUpInterstitialAds(n), this.config.preload || this.disableInitialLoad(), this.showPostloadAds(), this.isInterstitialAdEventDispatchRequired && window.dispatchEvent(new CustomEvent("START_INTAD")), QDFP.dynamicSlots.forEach(function(e) {
                    "object" === ("undefined" == typeof e ? "undefined" : o(e)) && e.slotId ? t.showDynamic(e.slotId, e.index ? e.index : 0) : t.showDynamic(e)
                });
                var i = this.dynAds;
                this.lineUpDynamicAds(i), this.showDynamicAds()
            }
        }, {
            key: "showQapV2Ads",
            value: function() {
                if (!this.qapShowed) {
                    this.qapShowed = !0;
                    var t = this.pdata.ads.filter(function(t) {
                        return t.useQapV2 === !0
                    });
                    t.forEach(v.createQapSlot), this.pdata.overlay && (0, v.createQapOverlay)(this.pdata.overlay)
                }
            }
        }, {
            key: "disableInitialLoad",
            value: function() {
                var t = this,
                    e = function() {
                        (0, h.pageTargeting)(t.pageTarget), googletag.pubads().enableSingleRequest(), googletag.pubads().disableInitialLoad(), googletag.pubads().collapseEmptyDivs(), googletag.enableServices()
                    };
                this.enqueue(e)
            }
        }, {
            key: "enableSingleRequest",
            value: function() {
                var t = this,
                    e = function() {
                        (0, h.pageTargeting)(t.pageTarget), googletag.pubads().enableSingleRequest(), googletag.pubads().collapseEmptyDivs(), googletag.enableServices()
                    };
                this.enqueue(e)
            }
        }, {
            key: "getAds",
            value: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    n = t.filter(function(t) {
                        return t.top === e && t.preferQap !== !0
                    });
                return n
            }
        }, {
            key: "lineUpPreAds",
            value: function(t) {
                var e, n = this,
                    i = t.map(function(t) {
                        return e = new u.default(t), n.preSlots.push(e), e.defineSlot()
                    });
                this.multiEnqueue(i)
            }
        }, {
            key: "lineUpPostAds",
            value: function(t) {
                var e, n = this,
                    i = t.map(function(t) {
                        return e = new u.default(t), n.postSlots.push(e), e.defineSlot()
                    });
                this.multiEnqueue(i)
            }
        }, {
            key: "lineUpDynamicAds",
            value: function(t) {
                var e, n = this,
                    i = t.map(function(t) {
                        return e = new u.default(t), n.dynSlots.push(e), e.defineSlot()
                    });
                this.multiEnqueue(i)
            }
        }, {
            key: "lineUpInterstitialAds",
            value: function(t) {
                var e;
                "undefined" != typeof t && null !== t && (e = new f.Interstitial(t[0].config), this.isEventListeningRequired && (0, d.listen)(g.INTAD_EVENT, window, e.fire.bind(e)))
            }
        }, {
            key: "showPreloadAds",
            value: function() {
                var t = this.getAds(this.pdata.ads, !0),
                    e = this.preSlots,
                    n = this.preSlots.length - 1,
                    i = [],
                    a = e.map(function(e, a) {
                        return function() {
                            googletag.display(t[a].slot), i.push(e.getSpSlot()), a === n && googletag.pubads().refresh(i)
                        }
                    });
                this.multiEnqueue(a)
            }
        }, {
            key: "showPostloadAds",
            value: function() {
                var t = this.getAds(this.pdata.ads, !1),
                    e = this.postSlots,
                    n = this.postSlots.length - 1,
                    i = [],
                    a = e.map(function(e, a) {
                        return function() {
                            googletag.display(t[a].slot), i.push(e.getSpSlot()), a === n && googletag.pubads().refresh(i)
                        }
                    });
                this.multiEnqueue(a)
            }
        }, {
            key: "showDynamicAds",
            value: function() {
                var t = this.dynAds,
                    e = this.dynSlots,
                    n = this.dynSlots.length - 1,
                    i = [],
                    a = e.map(function(e, a) {
                        return function() {
                            googletag.display(t[a].slot), i.push(e.getSpSlot()), a === n && googletag.pubads().refresh(i)
                        }
                    });
                this.multiEnqueue(a)
            }
        }, {
            key: "showInterstitialAds",
            value: function() {
                var t = this.pdata.interstitials[0];
                if (t)
                    if (t.slot = "mon-interstitial-" + (new Date).getTime(), this.createInterstitialDiv(), t.preferQap)(0, v.createQapSlot)(t);
                    else {
                        var e = new u.default(t);
                        this.enqueue(e.defineSlot()), this.enqueue(function() {
                            googletag.display(t.slot), googletag.pubads().refresh([e.getSpSlot()])
                        })
                    }
            }
        }, {
            key: "renderEvents",
            value: function() {
                var t = !1,
                    e = this,
                    n = function() {
                        (0, d.listen)("slotRenderEnded", googletag.pubads(), function(n) {
                            n.slot.getSlotElementId() === e.pdata.interstitials[0].slot && (e.divDisplayNone(e.pdata.interstitials[0].slot), t = !n.isEmpty, t || e.closeOverlay())
                        })
                    };
                this.enqueue(n)
            }
        }, {
            key: "showInterstitial",
            value: function() {
                this.showInterstitialAds(), this.renderEvents()
            }
        }, {
            key: "divDisplayNone",
            value: function(t) {
                var e = document.getElementById(t);
                "undefined" != typeof e && "none" === e.style.display && this.closeOverlay()
            }
        }, {
            key: "createInterstitialDiv",
            value: function() {
                var t = this,
                    e = window.innerWidth < 800,
                    n = document.createElement("div");
                n.id = this.pdata.interstitials[0].slot;
                var i = this.pdata.interstitials[0].hideCloseButton,
                    a = this.pdata.interstitials[0].preferQap,
                    o = document.createElement("style"),
                    s = document.createElement("div");
                if (s.id = "mon-overlay", o.innerHTML = "#closebtn-interstitial{position: absolute;top: -92px;width: 32px;height: 32px;right: 0px;z-index: 1112;background: #fff;padding: 8px;border-radius: 50%;border: 1px solid #ccc;}#" + this.pdata.interstitials[0].slot + "{z-index: 1111;position: fixed;top: " + (i && e ? "0px" : "20px") + ";left: 0;margin:0 auto;right:0;text-align: center;}#mon-overlay{opacity:" + (e ? "1" : "0.8") + ";background: #eee;width: 100%;height: 100%;z-index: 500;top: 0;left: 0;position: fixed;text-align: center;padding:0;}", document.head.appendChild(o), document.body.appendChild(s), document.body.appendChild(n), a && (s.style.display = "none", n.style.display = "none"), !this.pdata.interstitials[0].hideCloseButton) {
                    var r = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                    r.id = "closebtn-interstitial", r.setAttribute("viewBox", "0 0 70 70");
                    var l = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
                    l.setAttribute("points", "70,8.8 63.2,2 36,29.2 8.8,2 2,8.8 29.2,36 2,63.2 8.8,70 36,42.8 63.2,70 70,63.2 42.8,36"), r.appendChild(l), document.body.appendChild(r), (0, d.listen)("click", r, this.closeOverlay.bind(this))
                }(0, d.listen)("message", window, function(e) {
                    "mon_interstitial_close" === e.data && e.origin.indexOf("kuikr.com") > -1 && t.closeOverlay()
                })
            }
        }, {
            key: "closeOverlay",
            value: function() {
                var t = document.getElementById(this.pdata.interstitials[0].slot),
                    e = document.getElementById("mon-overlay"),
                    n = document.getElementById("closebtn-interstitial");
                e.parentNode.removeChild(e), t.parentNode.removeChild(t), n.parentNode.removeChild(n)
            }
        }, {
            key: "showDynamic",
            value: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                    n = this.pdata.dynads,
                    i = Object.assign({}, n[e]);
                i.slot = t, this.dynAds.push(i)
            }
        }, {
            key: "getAdForDivId",
            value: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                    n = this.pdata.dynads,
                    i = Object.assign({}, n[e]);
                if (i.slot = t, i.useQapV2) return void(0, v.createQapSlot)(i);
                var a = function() {
                    var e = new u.default(i),
                        n = e.defineSlot();
                    n(), googletag.display(t), googletag.pubads().refresh([e.getSpSlot()])
                };
                this.enqueue(a)
            }
        }, {
            key: "getDynamicAdsSingleRequest",
            value: function(t) {
                var e = this.pdata.dynads;
                this.enqueue(function() {
                    var n = t.map(function(t) {
                        return "string" == typeof t ? {
                            divId: t,
                            index: 0
                        } : {
                            divId: t.divId,
                            index: t.index || 0
                        }
                    }).filter(function(t) {
                        return !e[t.index].useQapV2
                    }).map(function(t) {
                        var n = Object.assign({}, e[t.index], {
                                slot: t.divId
                            }),
                            i = new u.default(n);
                        return i.defineSlot()(), googletag.display(t.divId), i.getSpSlot()
                    });
                    googletag.pubads().refresh(n)
                })
            }
        }, {
            key: "sendAdRequest",
            value: function() {
                var t = this,
                    e = this.pdata.ads;
                e.forEach(function(e) {
                    var n = (0, p.defineSlot)(e);
                    t.enqueue(n)
                })
            }
        }, {
            key: "multiEnqueue",
            value: function(t) {
                var e = this;
                t.forEach(function(t) {
                    e.enqueue(t)
                })
            }
        }, {
            key: "enqueue",
            value: function(t) {
                googletag.cmd.push(t)
            }
        }]), t
    }()
}, function(t, e, n) {
    "use strict";

    function i(t) {
        if (Array.isArray(t)) {
            for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
            return n
        }
        return Array.from(t)
    }

    function a(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = function() {
            function t(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var i = e[n];
                    i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
                }
            }
            return function(e, n, i) {
                return n && t(e.prototype, n), i && t(e, i), e
            }
        }(),
        s = n(1),
        r = n(4),
        d = (n(2), function() {
            function t(e) {
                a(this, t), this.ad = e, this.gptSlot = "", this.slotTarget = this.getTargeting(), this.ad.adcode
            }
            return o(t, [{
                key: "getTargeting",
                value: function() {
                    var t = this.ad.adcode;
                    return window.qdfp_vp.hasOwnProperty("stargeting") && window.qdfp_vp.stargeting.hasOwnProperty(t) ? window.qdfp_vp.stargeting[t] : []
                }
            }, {
                key: "getSpSlot",
                value: function() {
                    return this.gptSlot
                }
            }, {
                key: "defineSlot",
                value: function() {
                    var t = this,
                        e = this.getSlotParams();
                    return function() {
                        var n, a = (n = googletag).defineSlot.apply(n, i(e));
                        "undefined" != typeof t.ad.adsizes && a.defineSizeMapping(t.buildSizeMap(t.ad.adsizes)), a.addService(googletag.pubads()), (0, r.slotTargeting)(a, t.slotTarget), t.gptSlot = a
                    }
                }
            }, {
                key: "getAdUnitPath",
                value: function(t) {
                    return "/" + s.NetworkId + "/" + t
                }
            }, {
                key: "getSlotParams",
                value: function() {
                    var t = this.ad,
                        e = t.adcode,
                        n = t.sizes,
                        i = t.slot,
                        a = this.getAdUnitPath(e);
                    return [a, n, i]
                }
            }, {
                key: "getSizeMapping",
                value: function() {
                    return googletag.sizeMapping()
                }
            }, {
                key: "buildSizeMap",
                value: function(t) {
                    var e = this.getSizeMapping();
                    return t.forEach(function(t) {
                        e = e.addSize(t[0], t[1])
                    }), e.build()
                }
            }]), t
        }());
    e.default = d
}, function(t, e) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.Constants = {
        domain: "//" + document.location.host + "/",
        sessionCap: 3,
        nativeAdApi: "getNativeAdForOverlay",
        cookieName: "native_overlay_session_count",
        imageHost: "//teja2.kuikr.com/"
    }
}, function(t, e) {
    "use strict";

    function n(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var i = function() {
        function t(t, e) {
            for (var n = 0; n < e.length; n++) {
                var i = e[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
            }
        }
        return function(e, n, i) {
            return n && t(e.prototype, n), i && t(e, i), e
        }
    }();
    e.NativeAdOverlay = function() {
        function t() {
            n(this, t), this.createContainer()
        }
        return i(t, [{
            key: "createContainer",
            value: function() {
                var t = document.createElement("div");
                t.id = "ad-overlay-div", document.body.appendChild(t), this.container = t, window.addEventListener("overlay-close", function() {
                    t.remove()
                })
            }
        }, {
            key: "remove",
            value: function() {
                this.container.remove()
            }
        }]), t
    }()
}, function(t, e) {
    "use strict";

    function n(t) {
        var e = t || {};
        if (void 0 !== window.dataLayer && void 0 !== window.dataLayer[0]) {
            var n = window.dataLayer[0];
            void 0 !== n.USER_CITY_NAME && (e.city = n.USER_CITY_NAME), void 0 !== n.Category_Name && (e.cat = n.Category_Name), void 0 !== n.SubCategory_Name && (e.sub = n.SubCategory_Name)
        }
        return e
    }

    function i(t) {
        var e = t || {},
            n = window.qdfp_vp;
        return n && n.ptargeting && n.ptargeting.length > 0 && n.ptargeting.forEach(function(t) {
            "City" === t.key && (e.city = o(t.value)), "Category" === t.key && (e.cat = a(t.value))
        }), e
    }

    function a(t) {
        for (var e = t.split(" "), n = 0; n < e.length; n++) e[n] = e[n][0].toUpperCase() + e[n].substring(1);
        return e.join(" ").replace("&", "").replace(/\s+/g, "-")
    }

    function o(t) {
        return t[0].toUpperCase() + t.substring(1)
    }

    function s(t) {
        var e = t || {};
        return document.cookie.search("br_imblk=t") !== -1 ? e.ablocker = "t" : e.ablocker = "f", e
    }

    function r(t) {
        var e = t || {};
        return "undefined" != typeof screen && (screen.width <= 768 ? e.source = "MOBILE" : screen.width <= 1024 ? e.source = "TABLET" : e.source = "DESKTOP"), e
    }

    function d() {
        var t = n();
        return t = i(t), t = s(t), t = r(t)
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.getTargetingParams = d
}, function(t, e, n) {
    function i(t, e, n) {
        var i = document.getElementById(t);
        i.innerHTML = e.html, e.init(t, n)
    }

    function a(t) {
        return t.map(function(t) {
            return t.img = o + decodeURIComponent(t.images[0]), t.landing = decodeURIComponent(t.landingUrl), t.videoUrl = decodeURIComponent(t.videoUrl), document.cookie.search("br_imblk=t;") === -1 && "" !== t.clickTrackingUrl && (t.landing = decodeURIComponent(t.clickTrackingUrl)), t.title = decodeURIComponent(t.titles[0].text), t.desc = decodeURIComponent(t.description), void 0 !== t.impressionTrackingUrl && (t.impressionTrackingUrl = decodeURIComponent(t.impressionTrackingUrl)),
                void 0 === t.cta || "" === t.cta ? t.cta = "Read More" : t.cta = decodeURIComponent(t.cta), t
        })
    }
    var o = "https:" === document.location.protocol ? "https://teja10.kuikr.com" : "http://teja1.kuikr.com";
    t.exports = {
        create: function(t, e) {
            if (void 0 !== e.creatives && (e.creatives = a(e.creatives)), e.creatives.length > 1 && 4 != e.type) {
                var o = e.creatives,
                    s = Math.floor(100 * Math.random()) % o.length;
                e.creatives = [o[s]]
            } else if (0 == e.creatives.length) throw new Error;
            switch (e.creatives[0].type) {
                case 1:
                    n.e(10, function(a) {
                        var o = n(9);
                        i(t, o, e)
                    });
                    break;
                case 2:
                    n.e(5, function(a) {
                        var o = n(16);
                        i(t, o, e)
                    });
                    break;
                case 3:
                    n.e(4, function(a) {
                        var o = n(17);
                        i(t, o, e)
                    });
                    break;
                case 4:
                    n.e(3, function(a) {
                        var o = n(18);
                        i(t, o, e)
                    });
                    break;
                case 5:
                    n.e(12, function(a) {
                        var o = n(19);
                        i(t, o, e)
                    });
                    break;
                case 6:
                    n.e(2, function(a) {
                        var o = n(20);
                        i(t, o, e)
                    });
                    break;
                case 9:
                    n.e(0, function(a) {
                        var o = n(21);
                        i(t, o, e)
                    });
                    break;
                case 10:
                    n.e(1, function(a) {
                        var o = n(10);
                        i(t, o, e)
                    });
                    break;
                case 11:
                    n.e(9, function(a) {
                        var o = n(11);
                        i(t, o, e)
                    });
                    break;
                case 12:
                    n.e(8, function(a) {
                        var o = n(12);
                        i(t, o, e)
                    });
                    break;
                case 13:
                    n.e(7, function(a) {
                        var o = n(13);
                        i(t, o, e)
                    });
                    break;
                case 14:
                    n.e(13, function(a) {
                        var o = n(14);
                        i(t, o, e)
                    });
                    break;
                case 15:
                    n.e(6, function(a) {
                        var o = n(15);
                        i(t, o, e)
                    });
                    break;
                case "onlineleads":
                    n.e(11, function(e) {
                        var a = n(22);
                        i(t, a)
                    })
            }
        }
    }
}, , , , , function(t, e) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.config = {
        name: "Horizontal",
        desc: "default",
        id: "horizontal",
        preload: !0
    }, e.pages = [{
        name: "horizontal_pets_snb",
        id: "horizontal_pets_snb",
        pixelAdUnit: "D_Pets_SnB_1x1",
        ptargeting: [],
        minviewport: [320, 50],
        maxviewport: [1920, 1200],
        multirequest: !0,
        ads: [{
            top: !0,
            slot: "mon_Pets_Pet_Care_snb_mh",
            adcode: "Desktop_Pets_SnB_1",
            sizes: [
                [970, 90]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_snb_skyscpr",
            adcode: "Desktop_Pets_SnB_5",
            sizes: [
                [160, 600],
                [180, 150]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon-Pets_Pet_Care-snb-sticky-left",
            adcode: "Desktop_Pets_SnB_3",
            sizes: [
                [120, 600]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon-Pets_Pet_Care-snb-sticky-right",
            adcode: "Desktop_Pets_SnB_4",
            sizes: [
                [120, 600]
            ],
            targeting: []
        }],
        dynads: [{
            adcode: "Desktop_Pets_SnB_2",
            sizes: [
                [728, 90]
            ],
            targeting: []
        }]
    }, {
        name: "horizontal_snb",
        id: "horizontal_snb",
        ptargeting: [],
        minviewport: [320, 50],
        maxviewport: [1920, 1200],
        multirequest: !0,
        ads: [{
            top: !0,
            slot: "mon_snb_mh",
            adcode: "Desktop_SnB_Top_735X125(728X90)",
            sizes: [
                [735, 125],
                [728, 90],
                [970, 90],
                [970, 250]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_snb_skyscpr",
            adcode: "Desktop_SnB_160X600",
            sizes: [
                [160, 600],
                [180, 150]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon-snb-sticky-left",
            adcode: "Desktop_SnB_Sticky_Left_160X600",
            sizes: [
                [160, 600]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon-snb-sticky-right",
            adcode: "Desktop_SnB_Sticky_Right_160X600",
            sizes: [
                [160, 600]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_snb_bot",
            adcode: "Desktop_SnB_Bot_735X125(728X90)",
            sizes: [
                [735, 125],
                [728, 90]
            ]
        }, {
            top: !1,
            preferQap: !0,
            useQapV2: !0,
            slot: "qap-text-snb",
            useDataAttribute: !0,
            adcode: "Desktop_Horizontal_SNB_Text",
            sizes: [
                [138, 42]
            ]
        }],
        dynads: [{
            adcode: "Desktop_SnB_mid_735X125(728X90)",
            sizes: [
                [735, 125],
                [728, 90]
            ],
            targeting: []
        }]
    }, {
        name: "msite_pets_vap",
        id: "msite_pets_vap",
        ptargeting: [],
        pixelAdUnit: "M_Pets_VAP_1x1",
        ads: [{
            top: !0,
            slot: "mon_vap_bsticky",
            adcode: "Msite_Pets_VAP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }]
    }, {
        name: "msite_vap",
        id: "msite_vap",
        ptargeting: [],
        ads: [{
            top: !0,
            slot: "mon_vap_bsticky",
            adcode: "mSite_VAP_320X50",
            sizes: [
                [320, 50],
                [320, 100], -[300, 250]
            ],
            targeting: []
        }]
    }, {
        name: "horizontal_vap",
        id: "horizontal_vap",
        ptargeting: [],
        ads: [{
            top: !0,
            slot: "mon_vap_top",
            adcode: "Desktop_VAP_970X90",
            sizes: [
                [970, 90],
                [970, 250]
            ],
            adsizes: [
                [
                    [1024, 120],
                    [970, 90]
                ],
                [
                    [0, 0],
                    []
                ]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_vap_bottom",
            adcode: "Desktop_VAP_728X90",
            sizes: [
                [728, 90],
                [970, 90]
            ],
            adsizes: [
                [
                    [1024, 120],
                    [
                        [728, 90],
                        [970, 90]
                    ]
                ],
                [
                    [0, 0],
                    []
                ]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_vap_skyscraper",
            adcode: "Desktop_VAP_160X600",
            sizes: [
                [160, 600]
            ],
            targeting: []
        }, {
            top: !1,
            preferQap: !0,
            useQapV2: !0,
            slot: "qap-text-vap",
            adcode: "Desktop_Horizontal_VAP_Text",
            sizes: [
                [146.77, 36]
            ]
        }],
        overlay: {
            adcode: "Desktop_VAP_Overlay",
            width: 350,
            height: 135
        }
    }, {
        name: "horizontal_pets_vap",
        id: "horizontal_pets_vap",
        pixelAdUnit: "D_Pets_VAP_1x1",
        ptargeting: [],
        ads: [{
            top: !0,
            slot: "mon_Pets_Pet_Care_vap_top",
            adcode: "Desktop_Pets_VAP_1",
            sizes: [
                [970, 90]
            ],
            adsizes: [
                [
                    [1024, 120],
                    [970, 90]
                ],
                [
                    [0, 0],
                    []
                ]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_Pets_Pet_Care_vap_bottom",
            adcode: "Desktop_Pets_VAP_4",
            sizes: [
                [728, 90]
            ],
            adsizes: [
                [
                    [1024, 120],
                    [
                        [728, 90],
                        [970, 90]
                    ]
                ],
                [
                    [0, 0],
                    []
                ]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_Pets_Pet_Care_vap_skyscraper",
            adcode: "Desktop_Pets_VAP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }, {
            top: !1,
            preferQap: !0,
            useQapV2: !0,
            slot: "qap-text-vap",
            adcode: "Desktop_Horizontal_VAP_Text",
            sizes: [
                [146.77, 36]
            ]
        }],
        overlay: {
            adcode: "Desktop_VAP_Overlay",
            width: 350,
            height: 135
        }
    }, {
        name: "horizontal_cathp",
        id: "horizontal_cathp",
        ptargeting: [],
        ads: [{
            top: !0,
            slot: "mon_cathp_right_bottom",
            adcode: "Desktop_CatHP_300X250",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_cathp_masthead",
            adcode: "Desktop_CatHP_970X125(90)",
            sizes: [
                [970, 90],
                [978, 125]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_cathp_sticky_left",
            adcode: "Desktop_CatHP_Sticky_Left_160X600",
            sizes: [
                [160, 600]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_cathp_sticky_right",
            adcode: "Desktop_CatHP_Sticky_Right_160X600",
            sizes: [
                [160, 600]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_cathp_btm1",
            adcode: "Desktop_EnL_CatHP_3",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }, {
            top: !0,
            slot: "mon_cathp_btm2",
            adcode: "Desktop_EnL_CatHP_4",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }],
        overlay: {
            adcode: "Desktop_CatHP_Overlay",
            width: 350,
            height: 135
        }
    }, {
        name: "category_page_pets_desk",
        id: "category_page_pets_desk",
        pixelAdUnit: "D_Pets_HP_1x1",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "pets-970-90",
            adcode: "Desktop_Pets_CatHP_1",
            sizes: [
                [970, 90]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "pets-970-250",
            adcode: "Desktop_Pets_CatHP_2",
            sizes: [
                [970, 250]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "pets-300-250",
            adcode: "Desktop_Pets_CatHP_3",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }],
        overlay: {
            adcode: "Desktop_Pets_CatHP_Overlay",
            width: 350,
            height: 135
        },
        interstitials: [{
            adcode: "Desktop_Interstitial_1",
            sizes: [
                [330, 600]
            ],
            slot: "mon-interstitial",
            targeting: [],
            preferQap: !0,
            hideCloseButton: !0,
            config: {
                firstshow: 0,
                freq: 1e3,
                interval: 0,
                expiry: 36e5
            }
        }]
    }, {
        name: "category_page_community_desk",
        id: "category_page_community_desk",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "community-970-250",
            adcode: "Desktop_Community_CatHP_1",
            sizes: [
                [970, 250]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "community-300-250",
            adcode: "Desktop_Community_CatHP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }],
        overlay: {
            adcode: "Desktop_Community_CatHP_Overlay",
            width: 350,
            height: 135
        }
    }, {
        name: "category_page_events_desk",
        id: "category_page_events_desk",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "events-970-250",
            adcode: "Desktop_Events_CatHP_1",
            sizes: [
                [970, 250]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "events-300-250",
            adcode: "Desktop_Events_CatHP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }],
        overlay: {
            adcode: "Desktop_Events_CatHP_Overlay",
            width: 350,
            height: 135
        }
    }, {
        name: "category_page_matrimonial_desk",
        id: "category_page_matrimonial_desk",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "matrimonial-970-250",
            adcode: "Desktop_Matrimonial_CatHP_1",
            sizes: [
                [970, 250]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "matrimonial-300-250",
            adcode: "Desktop_Matrimonial_CatHP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }],
        overlay: {
            adcode: "Desktop_Matrimonial_CatHP_Overlay",
            width: 350,
            height: 135
        }
    }, {
        name: "category_page_entertainment_desk",
        id: "category_page_entertainment_desk",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "entertainment-970-250",
            adcode: "Desktop_Entertainment_CatHP_1",
            sizes: [
                [970, 250]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "entertainment-300-250",
            adcode: "Desktop_Entertainment_CatHP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }],
        overlay: {
            adcode: "Desktop_Entertainment_CatHP_Overlay",
            width: 350,
            height: 135
        }
    }, {
        name: "category_page_pets_mobile",
        id: "category_page_pets_mobile",
        ptargeting: [],
        multirequest: !0,
        pixelAdUnit: "M_Pets_HP_1x1",
        ads: [{
            top: !1,
            slot: "pets-320-100",
            adcode: "Msite_Pets_CatHP_1",
            sizes: [
                [320, 100]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "pets-300-250",
            adcode: "Msite_Pets_CatHP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }],
        interstitials: [{
            adcode: "mSite_Interstitial_1",
            sizes: [
                [320, 480]
            ],
            slot: "mon-interstitial",
            targeting: [],
            preferQap: !0,
            hideCloseButton: !0,
            config: {
                firstshow: 0,
                freq: 1e3,
                interval: 0,
                expiry: 36e5
            }
        }]
    }, {
        name: "horizontal_HP",
        id: "horizontal_HP",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "dfp_desktop_hp",
            adcode: "Desktop_HP_300X250",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "dfp_desktop_hp_top_banner",
            adcode: "Desktop_HP_978X125",
            sizes: [
                [970, 90],
                [978, 125]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "dfp_desktop_hp_bottom_banner",
            adcode: "Desktop_HP_bottom_970X90",
            sizes: [
                [970, 90],
                [978, 125]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "dfp_msite_hp_bottom_banner",
            adcode: "mSite_HP",
            sizes: [
                [320, 100],
                [320, 50],
                [300, 250]
            ],
            targeting: []
        }]
    }, {
        name: "horizontal_PAP",
        id: "horizontal_PAP",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "dfp_desktop_pap",
            adcode: "Desktop_PAPNavigation_300x250",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }]
    }, {
        name: "horizontal_PAPSUCESS",
        id: "horizontal_PAPSUCESS",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "dfp_desktop_papsucess",
            adcode: "Desktop_PAPSuccesspage_728x90",
            sizes: [
                [728, 90]
            ],
            targeting: []
        }]
    }, {
        name: "category_page_entertainment_mobile",
        id: "category_page_entertainment_mobile",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "entertainment-320-100",
            adcode: "mSite_Entertainment_CatHP_1",
            sizes: [
                [320, 100]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "entertainment-300-250",
            adcode: "mSite_Entertainment_CatHP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }]
    }, {
        name: "category_page_events_mobile",
        id: "category_page_events_mobile",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "events-320-100",
            adcode: "mSite_Events_CatHP_1",
            sizes: [
                [320, 100]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "events-300-250",
            adcode: "mSite_Events_CatHP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }]
    }, {
        name: "category_page_community_mobile",
        id: "category_page_community_mobile",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "community-320-100",
            adcode: "mSite_Community_CatHP_1",
            sizes: [
                [320, 100]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "community-300-250",
            adcode: "mSite_Community_CatHP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }]
    }, {
        name: "category_page_matrimonial_mobile",
        id: "category_page_matrimonial_mobile",
        ptargeting: [],
        multirequest: !0,
        ads: [{
            top: !1,
            slot: "matrimonial-320-100",
            adcode: "mSite_Matrimonial_CatHP_1",
            sizes: [
                [320, 100]
            ],
            targeting: []
        }, {
            top: !1,
            slot: "matrimonial-300-250",
            adcode: "mSite_Matrimonial_CatHP_2",
            sizes: [
                [300, 250]
            ],
            targeting: []
        }]
    }, {
        name: "pets_pet_care_msite_snb",
        id: "pets_pet_care_msite_snb",
        ptargeting: [],
        pixelAdUnit: "M_Pets_SnB_1x1",
        ads: [],
        dynads: [{
            adcode: "Msite_Pets_SnB_1",
            sizes: [
                [300, 250],
                [320, 50],
                [320, 100]
            ],
            targeting: []
        }]
    }, {
        name: "other_horizontal",
        id: "other_horizontal",
        ptargeting: [],
        ads: [],
        dynads: [{
            adcode: "mSite_SnB_All_320X50",
            sizes: [
                [300, 250],
                [320, 50],
                [320, 100]
            ],
            targeting: []
        }]
    }, {
        name: "My Ads (Desktop)",
        id: "my_ads_desktop",
        ptargeting: [],
        ads: [],
        dynads: [{
            adcode: "Desktop_MyAccount_MyAds_1",
            sizes: [
                [728, 90]
            ],
            targeting: []
        }]
    }, {
        name: "My Ads (Msite)",
        id: "my_ads_msite",
        ptargeting: [],
        ads: [],
        dynads: [{
            adcode: "mSite_MyAccount_MyAds_1",
            sizes: [
                [320, 50],
                [970, 90]
            ],
            targeting: []
        }]
    }]
}]);