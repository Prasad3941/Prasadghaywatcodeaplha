(function(_) {
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    /* 
     
     
     Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors 
     Licensed under the Apache License, Version 2.0 (the "License"); 
     you may not use this file except in compliance with the License. 
     You may obtain a copy of the License at 
         http://www.apache.org/licenses/LICENSE-2.0 
     Unless required by applicable law or agreed to in writing, software 
     distributed under the License is distributed on an "AS IS" BASIS, 
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
     See the License for the specific language governing permissions and 
     limitations under the License. 
    */
    /* 
     
    Math.uuid.js (v1.4) 
    http://www.broofa.com 
    mailto:robert@broofa.com 
    Copyright (c) 2010 Robert Kieffer 
    Dual licensed under the MIT and GPL licenses. 
    */
    var ba, da, la, xa, za, Da, Ja, La, Sa, Ua, Va, Wa, Xa, $a, bb, eb, ib, kb, mb, pb, ob, qb, rb, sb, tb, xb, yb, Bb, Db, Fb, Hb, Jb, Kb, Mb, Nb, Ob, Pb, Qb, Sb, Tb, Wb, Xb, Zb, $b, cc, ec, hc, ic, jc, mc, oc, qc, sc, rc, tc, xc, Bc, Cc, Fc, Jc, Ic, Kc, Lc, Gc, Oc, Qc, Rc, Tc, Wc, Yc, Zc, $c, bd, id, jd, kd, ld, md, nd, gd, od, dd, pd, cd, ed, fd, qd, rd, sd, vd, wd, zd, Cd, Dd, Gd, Fd, Id, Jd, Kd, Od, Pd, Sd, Ud, Xd, Yd, be, ce, de, he, je, ie, me, oe, ne, qe, pe, re, te, ae, ye, ze, Ae, Ie, Be, De, Ee, Le, Pe, Qe, Re, Ze, af, $e, Ce, Ge, ef, ff, gf, kf, lf, of , rf, yf, qf, sf, tf, zf, Bf, Cf, Of, Tf, Uf, Wf, Xf, Yf, ag, bg, cg, dg, gg, lg, hg, pg, og, rg, tg, xg, Ag, Bg, Cg, Dg, Eg, Gg, Hg, Ig, Kg, Lg, Mg, Ng, Rg, Qg, ah, hh, qh, yh, Dh, Hh, Jh, Qh, Ih, Lh, Oh, Uh, Vh, Xh, Yh, ai, bi, di, ei, fi, ii, ji, li, oi, pi, ti, ui, wi, yi, Bi, Ai, xi, Di, Ei, Gi, Hi, Ii, Ji, Ki, Li, Mi, Ni, Oi, Pi, Qi, Ti, Ui, Vi, Wi, Xi, Yi, Zi, bj, dj, ej, mj, rj, pj, wj, zj, Dj, Ej, Fj, Bj, Cj, Ij, Hj, Gj, Kj, Lj, Nj, Oj, Pj, Rj, Sj, Uj, Xj, ak, fk, hk, ik, lk, kk, nk, pk, qk, sk, yk, Jk, Mk, Nk, Ok, Pk, Qk, Rk, Sk, Tk, Vk, Yk, Wk, al, Xk, bl, el, fl, il, kl, ll, ol, rl, sl, tl, zl, Gl, Bl, Hl, Ql, Zl, Xl, Yl, dm, hm, mm, pm, rm, sm, tm, vm, zm, Gm, Bm, wm, Wm, Ym, an, bn, gn, kn, ln, N, on, pn, qn, tn, O, vn, wn, xn, zn, Bn, Cn, Jn, Kn, Mn, Nn, Sn, Zn, ao, co, eo, fo, go, jo, no, ro, to, so, Ao, Bo, Co, Do, uo, Eo, vo, Go, Ho, Lo, Mo, Po, Qo, Ro, To, Xo, Yo, cp, ep, fp, hp, ip, np, op, pp, tp, mp, vp, wp, xp, zp, Cp, Ep, Fp, Gp, Hp, Jp, Lp, Mp, Op, Pp, Qp, Rp, Sp, Vp, fq, iq, jq, lq, nq, wq, yq, Eq, Hq, Iq, Rq, Vq, Yq, Wq, Xq, dr, lr, nr, pr, rr, ur, tr, sr, Gr, Jr, Sr, Tr, Wr, Xr, Zr, $r, as, bs, cs, es, fs, hs, gs, js, ns, ls, ps, rs, ss, ws, xs, ys, Bs, Es, Ds, Fs, Gs, Hs, Ns, Os, Qs, Ss, Ts, Vs, Us, Ys, at, bt, ct, dt, et, ft, gt, ht, jt, kt, lt, nt, ot, pt, qt, tt, ut, wt, Bt, Ot, Gt, Pt, Qt, Rt, St, Ut, Wt, Yt, Zt, au, lu, fu, eu, ou, su, uu, wu, yu, Au, zu, Iu, lb, Ju, Ku, Mu, Lu, Nu, Pu, Tu, Zu, Yu, cv, dv, fv, hv, lv, mv, iv, nv, ov, pv, rv, tv, xv, yv, uv, vv, wv, Av, Bv, Ev, Fv, Jv, Kv, Lv, Mv, Sv, Tv, Vv, Xv, Yv, Zv, bw, kw, Tw, Vw, Ww, Xw, Wx, Yx, dy, cy, ey, hy, jy, ky, sy, wy, zy, Dy, Ey, Fy, Gy, Iy, Jy, Ky, Ly, Ny, My, Oy, Py, Wy, Xy, Yy, wg, $y, cz, az, bz, dz, ez;
    ba = function(a) {
        return function() {
            return _.aa[a].apply(this, arguments)
        }
    };
    da = function() {
        var a = _.ca.navigator;
        return a && (a = a.userAgent) ? a : ""
    };
    la = function(a) {
        return fa ? ka ? ka.brands.some(function(b) {
            return (b = b.brand) && b.indexOf(a) != -1
        }) : !1 : !1
    };
    _.na = function(a) {
        return da().indexOf(a) != -1
    };
    _.oa = function() {
        return fa ? !!ka && ka.brands.length > 0 : !1
    };
    _.pa = function() {
        return _.oa() ? !1 : _.na("Opera")
    };
    _.qa = function() {
        return _.oa() ? !1 : _.na("Trident") || _.na("MSIE")
    };
    _.sa = function() {
        return _.na("Firefox") || _.na("FxiOS")
    };
    _.ua = function() {
        return _.na("Safari") && !(_.ta() || (_.oa() ? 0 : _.na("Coast")) || _.pa() || (_.oa() ? 0 : _.na("Edge")) || (_.oa() ? la("Microsoft Edge") : _.na("Edg/")) || (_.oa() ? la("Opera") : _.na("OPR")) || _.sa() || _.na("Silk") || _.na("Android"))
    };
    _.ta = function() {
        return _.oa() ? la("Chromium") : (_.na("Chrome") || _.na("CriOS")) && !(_.oa() ? 0 : _.na("Edge")) || _.na("Silk")
    };
    _.va = function() {
        return _.na("Android") && !(_.ta() || _.sa() || _.pa() || _.na("Silk"))
    };
    xa = function() {
        wa === void 0 && (wa = null);
        return wa
    };
    za = function(a) {
        var b = xa();
        return new _.ya(b ? b.createScriptURL(a) : a)
    };
    _.Aa = function(a) {
        if (a instanceof _.ya) return a.g;
        throw Error("");
    };
    Da = function(a) {
        return new Ca(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    };
    _.Ha = function(a) {
        var b = b === void 0 ? Ea : b;
        a: if (b = b === void 0 ? Ea : b, !(a instanceof Fa)) {
            for (var c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d instanceof Ca && d.co(a)) {
                    a = new Fa(a);
                    break a
                }
            }
            a = void 0
        }
        return a || Ga
    };
    Ja = function(a) {
        for (var b = _.Ia.apply(1, arguments), c = [a[0]], d = 0; d < b.length; d++) c.push(String(b[d])), c.push(a[d + 1]);
        return new Fa(c.join(""))
    };
    La = function(a) {
        if (Ka.test(a)) return a
    };
    _.Ma = function(a) {
        if (a instanceof Fa)
            if (a instanceof Fa) a = a.g;
            else throw Error("");
        else a = La(a);
        return a
    };
    _.Na = function(a, b) {
        b = _.Ma(b);
        b !== void 0 && (a.href = b)
    };
    _.Qa = function(a) {
        var b = xa();
        return new _.Pa(b ? b.createHTML(a) : a)
    };
    _.Ra = function(a) {
        if (a instanceof _.Pa) return a.g;
        throw Error("");
    };
    Sa = function(a, b) {
        throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
    };
    Ua = function(a) {
        var b = xa();
        return new Ta(b ? b.createScript(a) : a)
    };
    Va = function(a) {
        if (a instanceof Ta) return a.g;
        throw Error("");
    };
    Wa = function(a) {
        var b, c = a.ownerDocument && a.ownerDocument.defaultView || window;
        c = c === void 0 ? document : c;
        var d;
        c = (d = (b = "document" in c ? c.document : c).querySelector) == null ? void 0 : d.call(b, "script[nonce]");
        (b = c == null ? "" : c.nonce || c.getAttribute("nonce") || "") && a.setAttribute("nonce", b)
    };
    Xa = function(a, b) {
        a.src = _.Aa(b);
        Wa(a)
    };
    _.Za = function(a) {
        if (a instanceof _.Ya) return a.g;
        throw Error("");
    };
    $a = function(a, b) {
        for (var c = typeof a === "string" ? a.split("") : a, d = a.length - 1; d >= 0; --d) d in c && b.call(void 0, c[d], d, a)
    };
    bb = function(a, b) {
        b = _.ab(a, b);
        var c;
        (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
        return c
    };
    _.cb = function(a, b) {
        var c = 0;
        $a(a, function(d, e) {
            b.call(void 0, d, e, a) && Array.prototype.splice.call(a, e, 1).length == 1 && c++
        })
    };
    _.db = function(a) {
        var b = a.length;
        if (b > 0) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };
    eb = function(a, b, c) {
        return arguments.length <= 2 ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    };
    ib = function(a) {
        for (var b = 0, c = 0, d = {}; c < a.length;) {
            var e = a[c++],
                f = _.gb(e) ? "o" + _.hb(e) : (typeof e).charAt(0) + e;
            Object.prototype.hasOwnProperty.call(d, f) || (d[f] = !0, a[b++] = e)
        }
        a.length = b
    };
    kb = function(a, b) {
        a.sort(b || _.jb)
    };
    mb = function(a) {
        for (var b = lb, c = Array(a.length), d = 0; d < a.length; d++) c[d] = {
            index: d,
            value: a[d]
        };
        var e = b || _.jb;
        kb(c, function(f, g) {
            return e(f.value, g.value) || f.index - g.index
        });
        for (b = 0; b < a.length; b++) a[b] = c[b].value
    };
    pb = function(a, b) {
        if (!_.nb(a) || !_.nb(b) || a.length != b.length) return !1;
        for (var c = a.length, d = ob, e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    };
    _.jb = function(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    };
    ob = function(a, b) {
        return a === b
    };
    qb = function(a, b) {
        for (var c = {}, d = 0; d < a.length; d++) {
            var e = a[d],
                f = b.call(void 0, e, d, a);
            f !== void 0 && (c[f] || (c[f] = [])).push(e)
        }
        return c
    };
    rb = function(a) {
        for (var b = [], c = 0; c < arguments.length; c++) {
            var d = arguments[c];
            if (Array.isArray(d))
                for (var e = 0; e < d.length; e += 8192)
                    for (var f = rb.apply(null, eb(d, e, e + 8192)), g = 0; g < f.length; g++) b.push(f[g]);
            else b.push(d)
        }
        return b
    };
    sb = function(a) {
        a = a(function(b) {
            b.stack = Error().stack
        });
        a.prototype = Object.create(Error.prototype);
        a.prototype.constructor = a
    };
    tb = function(a) {
        var b = {};
        b.winner_qid = a.getEscapedQemQueryId();
        b.cid = _.t(a, 19);
        b.ecrs = _.t(a, 11);
        return "https://googleads.g.doubleclick.net/td/activeview?" + _.w(Object, "entries").call(Object, b).map(function(c) {
            var d = _.y(c);
            c = d.next().value;
            d = d.next().value;
            return encodeURIComponent(c) + "=" + encodeURIComponent(d)
        }).join("&") + "&acvw=[VIEWABILITY]"
    };
    xb = function(a) {
        var b = !1;
        b = b === void 0 ? !1 : b;
        if (ub) {
            if (b && (vb ? !a.isWellFormed() : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(a))) throw Error("Found an unpaired surrogate");
            a = (wb || (wb = new TextEncoder)).encode(a)
        } else {
            for (var c = 0, d = new Uint8Array(3 * a.length), e = 0; e < a.length; e++) {
                var f = a.charCodeAt(e);
                if (f < 128) d[c++] = f;
                else {
                    if (f < 2048) d[c++] = f >> 6 | 192;
                    else {
                        if (f >= 55296 && f <= 57343) {
                            if (f <= 56319 && e < a.length) {
                                var g = a.charCodeAt(++e);
                                if (g >= 56320 && g <= 57343) {
                                    f = (f - 55296) * 1024 + g - 56320 + 65536;
                                    d[c++] = f >> 18 | 240;
                                    d[c++] = f >> 12 & 63 | 128;
                                    d[c++] = f >> 6 & 63 | 128;
                                    d[c++] = f & 63 | 128;
                                    continue
                                } else e--
                            }
                            if (b) throw Error("Found an unpaired surrogate");
                            f = 65533
                        }
                        d[c++] = f >> 12 | 224;
                        d[c++] = f >> 6 & 63 | 128
                    }
                    d[c++] = f & 63 | 128
                }
            }
            a = c === d.length ? d : d.subarray(0, c)
        }
        return a
    };
    yb = function(a) {
        _.ca.setTimeout(function() {
            throw a;
        }, 0)
    };
    Bb = function(a) {
        if (!zb) return Ab(a);
        for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    };
    Db = function(a) {
        return Cb[a] || ""
    };
    Fb = function(a) {
        return Eb && a != null && a instanceof Uint8Array
    };
    Hb = function(a) {
        if (a !== Gb) throw Error("illegal external caller");
    };
    Jb = function(a) {
        if (Ib) throw Error("");
        Ib = function(b) {
            _.ca.setTimeout(function() {
                a(b)
            }, 0)
        }
    };
    Kb = function(a) {
        if (Ib) try {
            Ib(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    };
    Mb = function() {
        var a = Error();
        Lb(a, "incident");
        Ib ? Kb(a) : yb(a)
    };
    Nb = function(a) {
        a = Error(a);
        Lb(a, "warning");
        Kb(a);
        return a
    };
    Ob = function() {
        return typeof BigInt === "function"
    };
    Pb = function(a) {
        return Array.prototype.slice.call(a)
    };
    Qb = function(a) {
        return typeof _.z.Symbol === "function" && typeof(0, _.z.Symbol)() === "symbol" ? (0, _.z.Symbol)() : a
    };
    Sb = function(a) {
        Rb(a, 34);
        return a
    };
    Tb = function(a) {
        Rb(a, 32);
        return a
    };
    Wb = function(a, b) {
        Vb(b, (a | 0) & -30975)
    };
    Xb = function(a, b) {
        Vb(b, (a | 34) & -30941)
    };
    Zb = function(a) {
        return !(!a || typeof a !== "object" || a.ko !== Yb)
    };
    $b = function(a) {
        return a !== null && typeof a === "object" && !Array.isArray(a) && a.constructor === Object
    };
    cc = function(a, b) {
        if (a != null)
            if (typeof a === "string") a = a ? new ac(a, Gb) : bc();
            else if (a.constructor !== ac)
            if (Fb(a)) a = a.length ? new ac(new Uint8Array(a), Gb) : bc();
            else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    };
    ec = function(a) {
        return !Array.isArray(a) || a.length ? !1 : (0, _.dc)(a) & 1 ? !0 : !1
    };
    _.fc = function(a) {
        if (a & 2) throw Error();
    };
    hc = function(a) {
        var b = _.gc;
        if (!a) throw Error((typeof b === "function" ? b() : b) || String(a));
    };
    ic = function(a) {
        a.xr = !0;
        return a
    };
    jc = function() {
        return ic(function(a) {
            return a === 0
        })
    };
    mc = function() {
        var a = lc;
        return ic(function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        })
    };
    oc = function() {
        var a = nc;
        return ic(function(b) {
            return b instanceof a
        })
    };
    qc = function(a) {
        return ic(function(b) {
            if (!pc(b)) return !1;
            for (var c = _.y(_.w(Object, "entries").call(Object, a)), d = c.next(); !d.done; d = c.next()) {
                var e = _.y(d.value);
                d = e.next().value;
                e = e.next().value;
                if (!(d in b)) {
                    if (e.ao === !0) continue;
                    return !1
                }
                if (!e(b[d])) return !1
            }
            return !0
        })
    };
    sc = function(a) {
        return rc(ic(function(b, c) {
            return b === void 0 ? !0 : a(b, c)
        }))
    };
    rc = function(a) {
        a.ao = !0;
        return a
    };
    tc = function() {
        return ic(function(a) {
            return Array.isArray(a)
        })
    };
    xc = function() {
        return ic(function(a) {
            return uc(a) ? a.every(function(b) {
                return wc(b)
            }) : !1
        })
    };
    Bc = function(a) {
        var b = a;
        if (wc(b)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error(String(b));
        } else if (yc(b) && !_.w(Number, "isSafeInteger").call(Number, b)) throw Error(String(b));
        return zc ? BigInt(a) : a = Ac(a) ? a ? "1" : "0" : wc(a) ? a.trim() || "0" : String(a)
    };
    Cc = function(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
    };
    Fc = function(a) {
        var b = a >>> 0;
        _.Dc = b;
        _.Ec = (a - b) / 4294967296 >>> 0
    };
    _.Hc = function(a) {
        if (a < 0) {
            Fc(-a);
            var b = _.y(Gc(_.Dc, _.Ec));
            a = b.next().value;
            b = b.next().value;
            _.Dc = a >>> 0;
            _.Ec = b >>> 0
        } else Fc(a)
    };
    Jc = function(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else Ob() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), c = b + Ic(c) + Ic(a));
        return c
    };
    Ic = function(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    };
    Kc = function() {
        var a = _.Dc,
            b = _.Ec;
        b & 2147483648 ? Ob() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = _.y(Gc(a, b)), a = b.next().value, b = b.next().value, a = "-" + Jc(a, b)) : a = Jc(a, b);
        return a
    };
    Lc = function(a) {
        if (a.length < 16) _.Hc(Number(a));
        else if (Ob()) a = BigInt(a), _.Dc = Number(a & BigInt(4294967295)) >>> 0, _.Ec = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            var b = +(a[0] === "-");
            _.Ec = _.Dc = 0;
            for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), _.Ec *= 1E6, _.Dc = _.Dc * 1E6 + d, _.Dc >= 4294967296 && (_.Ec += _.w(Math, "trunc").call(Math, _.Dc / 4294967296), _.Ec >>>= 0, _.Dc >>>= 0);
            b && (b = _.y(Gc(_.Dc, _.Ec)), a = b.next().value, b = b.next().value, _.Dc = a, _.Ec = b)
        }
    };
    Gc = function(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    _.Mc = function(a) {
        if (a != null && typeof a !== "number") throw Error("Value of float/double field must be a number, found " + typeof a + ": " + a);
        return a
    };
    Oc = function(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    };
    Qc = function(a) {
        if (typeof a !== "boolean") throw Error("Expected boolean but got " + Pc(a) + ": " + a);
        return a
    };
    Rc = function(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    };
    Tc = function(a) {
        var b = typeof a;
        switch (b) {
            case "bigint":
                return !0;
            case "number":
                return _.w(Number, "isFinite").call(Number, a)
        }
        return b !== "string" ? !1 : Sc.test(a)
    };
    _.Vc = function(a) {
        if (!_.w(Number, "isFinite").call(Number, a)) throw Nb("enum");
        return a | 0
    };
    Wc = function(a) {
        return a == null ? a : _.Vc(a)
    };
    _.Xc = function(a) {
        return a == null ? a : _.w(Number, "isFinite").call(Number, a) ? a | 0 : void 0
    };
    Yc = function(a) {
        if (typeof a !== "number") throw Nb("int32");
        if (!_.w(Number, "isFinite").call(Number, a)) throw Nb("int32");
        return a | 0
    };
    Zc = function(a) {
        if (a == null) return a;
        if (typeof a === "string") {
            if (!a) return;
            a = +a
        }
        if (typeof a === "number") return _.w(Number, "isFinite").call(Number, a) ? a | 0 : void 0
    };
    $c = function(a) {
        if (typeof a !== "number") throw Nb("uint32");
        if (!_.w(Number, "isFinite").call(Number, a)) throw Nb("uint32");
        return a >>> 0
    };
    _.ad = function(a) {
        return a == null ? a : $c(a)
    };
    bd = function(a) {
        if (a == null) return a;
        if (typeof a === "string") {
            if (!a) return;
            a = +a
        }
        if (typeof a === "number") return _.w(Number, "isFinite").call(Number, a) ? a >>> 0 : void 0
    };
    _.hd = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (!Tc(a)) throw Nb("int64");
        var c = typeof a;
        switch (b) {
            case 4096:
                switch (c) {
                    case "string":
                        return cd(a);
                    case "bigint":
                        return String(BigInt.asIntN(64, a));
                    default:
                        return dd(a)
                }
            case 8192:
                switch (c) {
                    case "string":
                        return ed(a);
                    case "bigint":
                        return Bc(BigInt.asIntN(64, a));
                    default:
                        return fd(a)
                }
            case 0:
                switch (c) {
                    case "string":
                        return cd(a);
                    case "bigint":
                        return Bc(BigInt.asIntN(64, a));
                    default:
                        return gd(a)
                }
            default:
                return Sa(b, "Unknown format requested type for int64")
        }
    };
    id = function(a) {
        return a == null ? a : _.hd(a, 0)
    };
    jd = function(a) {
        return a[0] === "-" ? !1 : a.length < 20 ? !0 : a.length === 20 && Number(a.substring(0, 6)) < 184467
    };
    kd = function(a) {
        return a[0] === "-" ? a.length < 20 ? !0 : a.length === 20 && Number(a.substring(0, 7)) > -922337 : a.length < 19 ? !0 : a.length === 19 && Number(a.substring(0, 6)) < 922337
    };
    ld = function(a) {
        if (a < 0) {
            _.Hc(a);
            var b = Jc(_.Dc, _.Ec);
            a = Number(b);
            return _.w(Number, "isSafeInteger").call(Number, a) ? a : b
        }
        if (jd(String(a))) return a;
        _.Hc(a);
        return _.Ec * 4294967296 + (_.Dc >>> 0)
    };
    md = function(a) {
        if (kd(a)) return a;
        Lc(a);
        return Kc()
    };
    nd = function(a) {
        if (jd(a)) return a;
        Lc(a);
        return Jc(_.Dc, _.Ec)
    };
    gd = function(a) {
        a = _.w(Math, "trunc").call(Math, a);
        if (!_.w(Number, "isSafeInteger").call(Number, a)) {
            _.Hc(a);
            var b = _.Dc,
                c = _.Ec;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            b = c * 4294967296 + (b >>> 0);
            a = a ? -b : b
        }
        return a
    };
    od = function(a) {
        a = _.w(Math, "trunc").call(Math, a);
        return a >= 0 && _.w(Number, "isSafeInteger").call(Number, a) ? a : ld(a)
    };
    dd = function(a) {
        a = _.w(Math, "trunc").call(Math, a);
        if (_.w(Number, "isSafeInteger").call(Number, a)) a = String(a);
        else {
            var b = String(a);
            kd(b) ? a = b : (_.Hc(a), a = Kc())
        }
        return a
    };
    pd = function(a) {
        a = _.w(Math, "trunc").call(Math, a);
        if (a >= 0 && _.w(Number, "isSafeInteger").call(Number, a)) a = String(a);
        else {
            var b = String(a);
            jd(b) ? a = b : (_.Hc(a), a = Jc(_.Dc, _.Ec))
        }
        return a
    };
    cd = function(a) {
        var b = _.w(Math, "trunc").call(Math, Number(a));
        if (_.w(Number, "isSafeInteger").call(Number, b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return md(a)
    };
    ed = function(a) {
        var b = _.w(Math, "trunc").call(Math, Number(a));
        if (_.w(Number, "isSafeInteger").call(Number, b)) return Bc(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Ob() ? Bc(BigInt.asIntN(64, BigInt(a))) : Bc(md(a))
    };
    fd = function(a) {
        return _.w(Number, "isSafeInteger").call(Number, a) ? Bc(gd(a)) : Bc(dd(a))
    };
    qd = function(a) {
        return _.w(Number, "isSafeInteger").call(Number, a) ? Bc(od(a)) : Bc(pd(a))
    };
    rd = function(a) {
        var b = _.w(Math, "trunc").call(Math, Number(a));
        if (_.w(Number, "isSafeInteger").call(Number, b) && b >= 0) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return nd(a)
    };
    sd = function(a) {
        var b = _.w(Math, "trunc").call(Math, Number(a));
        if (_.w(Number, "isSafeInteger").call(Number, b) && b >= 0) return Bc(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Ob() ? Bc(BigInt.asUintN(64, BigInt(a))) : Bc(nd(a))
    };
    _.ud = function(a) {
        if (a == null) return a;
        if (typeof a === "bigint") return td(a) ? a = Number(a) : (a = BigInt.asIntN(64, a), a = td(a) ? Number(a) : String(a)), a;
        if (Tc(a)) return typeof a === "number" ? gd(a) : cd(a)
    };
    vd = function(a, b) {
        b = b === void 0 ? !1 : b;
        var c = typeof a;
        if (a == null) return a;
        if (c === "bigint") return String(BigInt.asIntN(64, a));
        if (Tc(a)) return c === "string" ? cd(a) : b ? dd(a) : gd(a)
    };
    wd = function(a) {
        var b = 0;
        b = b === void 0 ? 0 : b;
        if (!Tc(a)) throw Nb("uint64");
        var c = typeof a;
        switch (b) {
            case 4096:
                switch (c) {
                    case "string":
                        return rd(a);
                    case "bigint":
                        return String(BigInt.asUintN(64, a));
                    default:
                        return pd(a)
                }
            case 8192:
                switch (c) {
                    case "string":
                        return sd(a);
                    case "bigint":
                        return Bc(BigInt.asUintN(64, a));
                    default:
                        return qd(a)
                }
            case 0:
                switch (c) {
                    case "string":
                        return rd(a);
                    case "bigint":
                        return Bc(BigInt.asUintN(64, a));
                    default:
                        return od(a)
                }
            default:
                return Sa(b, "Unknown format requested type for int64")
        }
    };
    _.xd = function(a) {
        return a == null ? a : wd(a)
    };
    _.yd = function(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(BigInt.asIntN(64, a));
        if (Tc(a)) {
            if (b === "string") return cd(a);
            if (b === "number") return gd(a)
        }
    };
    zd = function(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(BigInt.asUintN(64, a));
        if (Tc(a)) {
            if (b === "string") return rd(a);
            if (b === "number") return od(a)
        }
    };
    _.Bd = function(a) {
        if (typeof a !== "string") throw Error();
        return a
    };
    Cd = function(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    };
    Dd = function(a) {
        return a == null || typeof a === "string" ? a : void 0
    };
    Gd = function(a, b, c, d) {
        if (a != null && typeof a === "object" && a.Lh === Ed) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? Fd(b) : new b : void 0;
        var e = c = (0, _.dc)(a);
        e === 0 && (e |= d & 32);
        e |= d & 2;
        e !== c && Vb(a, e);
        return new b(a)
    };
    Fd = function(a) {
        var b = a[Hd];
        if (b) return b;
        b = new a;
        Sb(b.D);
        return a[Hd] = b
    };
    Id = function(a, b, c) {
        if (b) return Qc(a);
        var d;
        return (d = Rc(a)) != null ? d : c ? !1 : void 0
    };
    Jd = function(a, b, c) {
        if (b) return _.Bd(a);
        var d;
        return (d = Dd(a)) != null ? d : c ? "" : void 0
    };
    Kd = function() {
        Mb()
    };
    Od = function(a, b) {
        (Ld || (Ld = new Md)).set(a, b);
        (Nd || (Nd = new Md)).set(b, a)
    };
    Pd = function(a) {
        try {
            return a.toString().indexOf("[native code]") !== -1 ? a : null
        } catch (b) {
            return null
        }
    };
    Sd = function(a) {
        if (Qd === void 0) {
            var b = new Rd([], {});
            Qd = Array.prototype.concat.call([], b).length === 1
        }
        Qd && typeof _.z.Symbol === "function" && _.z.Symbol.isConcatSpreadable && (a[_.z.Symbol.isConcatSpreadable] = !0)
    };
    Ud = function(a, b) {
        Td = b;
        a = new a(b);
        Td = void 0;
        return a
    };
    Xd = function(a) {
        switch (typeof a) {
            case "boolean":
                return Vd || (Vd = [0, void 0, !0]);
            case "number":
                return a > 0 ? void 0 : a === 0 ? Wd || (Wd = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return a
        }
    };
    _.A = function(a, b, c, d) {
        var e;
        d = (e = d) != null ? e : 0;
        a == null && (a = Td);
        Td = void 0;
        if (a == null) e = 96, c ? (a = [c], e |= 512) : a = [], b && (e = e & -33521665 | (b & 1023) << 15);
        else {
            if (!Array.isArray(a)) throw Error("narr");
            e = (0, _.dc)(a);
            if (e & 2048) throw Error("farr");
            if (e & 64) return a;
            d === 1 || d === 2 || (e |= 64);
            if (c && (e |= 512, c !== a[0])) throw Error("mid");
            a: {
                d = a;c = e;
                if (e = d.length) {
                    var f = e - 1;
                    if ($b(d[f])) {
                        c |= 256;
                        b = f - (+!!(c & 512) - 1);
                        if (b >= 1024) throw Error("pvtlmt");
                        e = c & -33521665 | (b & 1023) << 15;
                        break a
                    }
                }
                if (b) {
                    b = Math.max(b, e - (+!!(c & 512) - 1));
                    if (b > 1024) throw Error("spvt");
                    e = c & -33521665 | (b & 1023) << 15
                } else e = c
            }
        }
        Vb(a, e);
        return a
    };
    Yd = function(a) {
        return a
    };
    be = function(a, b, c, d, e, f) {
        a = Gd(a, d, c, f);
        e && (a = ae(a));
        return a
    };
    ce = function(a) {
        return a
    };
    de = function(a) {
        return [a, this.get(a)]
    };
    he = function() {
        return ee || (ee = new fe(Sb([]), void 0, void 0, void 0, ge))
    };
    je = function(a, b) {
        return ie(b)
    };
    ie = function(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "bigint":
                return td(a) ? Number(a) : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a)
                    if (Array.isArray(a)) {
                        if (ec(a)) return
                    } else {
                        if (Fb(a)) return Bb(a);
                        if (a instanceof ac) return ke(a);
                        if (a instanceof fe) return le(a)
                    }
        }
        return a
    };
    me = function(a, b, c) {
        a = Pb(a);
        var d = a.length,
            e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (var f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    };
    oe = function(a, b, c, d, e) {
        if (a != null) {
            if (Array.isArray(a)) a = ec(a) ? void 0 : e && (0, _.dc)(a) & 2 ? a : ne(a, b, c, d !== void 0, e);
            else if ($b(a)) {
                var f = {},
                    g;
                for (g in a) Object.prototype.hasOwnProperty.call(a, g) && (f[g] = oe(a[g], b, c, d, e));
                a = f
            } else a = b(a, d);
            return a
        }
    };
    ne = function(a, b, c, d, e) {
        var f = d || c ? (0, _.dc)(a) : 0;
        d = d ? !!(f & 32) : void 0;
        a = Pb(a);
        for (var g = 0; g < a.length; g++) a[g] = oe(a[g], b, c, d, e);
        c && c(f, a);
        return a
    };
    qe = function(a) {
        return oe(a, pe, void 0, void 0, !1)
    };
    pe = function(a) {
        return a.Lh === Ed ? a.toJSON() : a instanceof fe ? le(a, qe) : ie(a)
    };
    re = function(a, b, c) {
        c = c === void 0 ? Xb : c;
        if (a != null) {
            if (Eb && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = (0, _.dc)(a);
                if (d & 2) return a;
                b && (b = d === 0 || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (Vb(a, (d | 34) & -12293), a) : ne(a, re, d & 4 ? Xb : c, !0, !0)
            }
            a.Lh === Ed ? (c = a.D, d = (0, _.se)(c), a = d & 2 ? a : Ud(a.constructor, te(c, d, !0))) : a instanceof fe && !(a.ae & 2) && (c = Sb(ue(a, re)), a = new fe(c, a.rg, a.we, a.Si));
            return a
        }
    };
    _.ve = function(a) {
        var b = a.D;
        return Ud(a.constructor, te(b, (0, _.se)(b), !1))
    };
    te = function(a, b, c) {
        var d = c || b & 2 ? Xb : Wb,
            e = !!(b & 32);
        a = me(a, b, function(f) {
            return re(f, e, d)
        });
        Rb(a, 32 | (c ? 2 : 0));
        return a
    };
    ae = function(a) {
        var b = a.D,
            c = (0, _.se)(b);
        return c & 2 ? Ud(a.constructor, te(b, c, !1)) : a
    };
    _.we = function(a) {
        var b = a.D,
            c = (0, _.se)(b);
        return c & 2 ? a : Ud(a.constructor, te(b, c, !0))
    };
    ye = function(a, b, c, d) {
        if (!(4 & b)) return !0;
        if (c == null) return !1;
        !d && c === 0 && (4096 & b || 8192 & b) && (a.constructor[xe] = (a.constructor[xe] | 0) + 1) < 5 && Mb();
        return c === 0 ? !1 : !(c & b)
    };
    ze = function(a, b, c, d) {
        b = d + (+!!(b & 512) - 1);
        if (!(b < 0 || b >= a.length || b >= c)) return a[b]
    };
    Ae = function(a, b, c, d) {
        var e = b >> 15 & 1023 || 536870912;
        if (c >= e) {
            var f = b;
            if (b & 256) var g = a[a.length - 1];
            else {
                if (d == null) return f;
                g = a[e + (+!!(b & 512) - 1)] = {};
                f |= 256
            }
            g[c] = d;
            c < e && (a[c + (+!!(b & 512) - 1)] = void 0);
            f !== b && Vb(a, f);
            return f
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    };
    Ie = function(a, b, c, d, e, f, g) {
        var h = a.D,
            l = (0, _.se)(h);
        d = 2 & l ? 1 : d;
        f = !!f;
        e = Be(h, l, b, e);
        var k = (0, _.dc)(e);
        if (ye(a, k, g, f)) {
            4 & k && (e = Pb(e), k = Ce(k, l), l = Ae(h, l, b, e));
            for (var m = a = 0; a < e.length; a++) {
                var n = c(e[a]);
                n != null && (e[m++] = n)
            }
            m < a && (e.length = m);
            k = De(k, l);
            k = (k | 20) & -4097;
            k &= -8193;
            g && (k |= g);
            Vb(e, k);
            2 & k && Object.freeze(e)
        }
        if (d === 1 || d === 4 && 32 & k) Ee(k) || (f = k, k |= 2, k !== f && Vb(e, k), Object.freeze(e));
        else if (g = d !== 5 ? !1 : !!(32 & k) || Ee(k) || !!Fe(e), (d === 2 || g) && Ee(k) && (e = Pb(e), k = Ce(k, l), k = Ge(k, l, f), Vb(e, k), l = Ae(h, l, b, e)), Ee(k) || (b = k, k = Ge(k, l, f), k !== b && Vb(e, k)), g) var p = He(e);
        else if (d === 2 && !f) {
            var r;
            (r = Ld) == null || r.delete(e)
        }
        return p || e
    };
    Be = function(a, b, c, d) {
        a = Je(a, b, c, d);
        return Array.isArray(a) ? a : Ke
    };
    De = function(a, b) {
        a === 0 && (a = Ce(a, b));
        return a | 1
    };
    Ee = function(a) {
        return !!(2 & a) && !!(4 & a) || !!(2048 & a)
    };
    Le = function(a) {
        return cc(a, !0)
    };
    Pe = function(a, b, c, d, e, f) {
        var g = b & 2;
        a: {
            var h = c,
                l = b & 2;c = !1;
            if (h == null) {
                if (l) {
                    a = he();
                    break a
                }
                h = []
            } else if (h.constructor === fe) {
                if ((h.ae & 2) == 0 || l) {
                    a = h;
                    break a
                }
                h = ue(h)
            } else Array.isArray(h) ? c = !!((0, _.dc)(h) & 2) : h = [];
            if (l) {
                if (!h.length) {
                    a = he();
                    break a
                }
                c || (c = !0, Sb(h))
            } else if (c) {
                c = !1;
                l = Pb(h);
                for (h = 0; h < l.length; h++) {
                    var k = l[h] = Pb(l[h]);
                    Array.isArray(k[1]) && (k[1] = Sb(k[1]))
                }
                h = l
            }
            c || ((0, _.dc)(h) & 64 ? (0, _.Me)(h, 32) : 32 & b && Tb(h));f = new fe(h, e, Jd, f);Ae(a, b, d, f);a = f
        }!g && e && (a.zm = !0);
        return a
    };
    Qe = function(a, b, c) {
        a = a.D;
        var d = (0, _.se)(a);
        return Pe(a, d, Je(a, d, b), b, void 0, c)
    };
    Re = function(a, b, c) {
        a = a.D;
        var d = (0, _.se)(a);
        return Pe(a, d, Je(a, d, b), b, c)
    };
    _.Ve = function(a, b, c, d) {
        var e = a.D,
            f = (0, _.se)(e);
        _.fc(f);
        if (c == null) return Ae(e, f, b), a;
        c = _.Se(c);
        var g = (0, _.dc)(c),
            h = g,
            l = !!(2 & g) || Object.isFrozen(c),
            k = !l && (void 0 === Te || void 0 !== Ue);
        if (ye(a, g))
            for (g = 21, l && (c = Pb(c), h = 0, g = Ce(g, f), g = Ge(g, f, !0)), l = 0; l < c.length; l++) c[l] = d(c[l]);
        k && (c = Pb(c), h = 0, g = Ce(g, f), g = Ge(g, f, !0));
        g !== h && Vb(c, g);
        Ae(e, f, b, c);
        return a
    };
    _.We = function(a, b, c, d) {
        var e = a.D,
            f = (0, _.se)(e);
        _.fc(f);
        Ae(e, f, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    };
    Ze = function(a) {
        if (Xe) {
            var b;
            return (b = a[Ye]) != null ? b : a[Ye] = new _.z.Map
        }
        if (Ye in a) return a[Ye];
        b = new _.z.Map;
        Object.defineProperty(a, Ye, {
            value: b
        });
        return b
    };
    af = function(a, b, c, d) {
        var e = Ze(a),
            f = $e(e, a, b, c);
        f !== d && (f && (b = Ae(a, b, f)), e.set(c, d));
        return b
    };
    $e = function(a, b, c, d) {
        var e = a.get(d);
        if (e != null) return e;
        for (var f = e = 0; f < d.length; f++) {
            var g = d[f];
            Je(b, c, g) != null && (e !== 0 && (c = Ae(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    };
    _.bf = function(a, b, c, d) {
        a = a.D;
        var e = (0, _.se)(a);
        d = Je(a, e, c, d);
        b = Gd(d, b, !1, e);
        b !== d && b != null && Ae(a, e, c, b);
        return b
    };
    _.cf = function(a, b, c, d, e, f, g, h) {
        a = a.D;
        var l = !!(2 & b);
        e = l ? 1 : e;
        g = !!g;
        h && (h = !l);
        f = Be(a, b, d, f);
        var k = (0, _.dc)(f);
        l = !!(4 & k);
        if (!l) {
            k = De(k, b);
            var m = f,
                n = b,
                p = !!(2 & k);
            p && (n |= 2);
            for (var r = !p, v = !0, u = 0, x = 0; u < m.length; u++) {
                var D = Gd(m[u], c, !1, n);
                if (D instanceof c) {
                    if (!p) {
                        var F = !!((0, _.dc)(D.D) & 2);
                        r && (r = !F);
                        v && (v = F)
                    }
                    m[x++] = D
                }
            }
            x < u && (m.length = x);
            k |= 4;
            k = v ? k | 16 : k & -17;
            k = r ? k | 8 : k & -9;
            Vb(m, k);
            p && Object.freeze(m)
        }
        if (h && !(8 & k || !f.length && (e === 1 || e === 4 && 32 & k))) {
            Ee(k) && (f = Pb(f), k = Ce(k, b), b = Ae(a, b, d, f));
            c = f;
            h = k;
            for (m = 0; m < c.length; m++) k = c[m], n = ae(k), k !== n && (c[m] = n);
            h |= 8;
            h = c.length ? h & -17 : h | 16;
            Vb(c, h);
            k = h
        }
        if (e === 1 || e === 4 && 32 & k) Ee(k) || (b = k, k |= !f.length || 16 & k && (!l || 32 & k) ? 2 : 2048, k !== b && Vb(f, k), Object.freeze(f));
        else if (l = e !== 5 ? !1 : !!(32 & k) || Ee(k) || !!Fe(f), (e === 2 || l) && Ee(k) && (f = Pb(f), k = Ce(k, b), k = Ge(k, b, g), Vb(f, k), b = Ae(a, b, d, f)), Ee(k) || (d = k, k = Ge(k, b, g), k !== d && Vb(f, k)), l) var C = He(f);
        else if (e === 2 && !g) {
            var G;
            (G = Ld) == null || G.delete(f)
        }
        return C || f
    };
    Ce = function(a, b) {
        a = (2 & b ? a | 2 : a & -3) | 32;
        return a &= -2049
    };
    Ge = function(a, b, c) {
        32 & b && c || (a &= -33);
        return a
    };
    _.df = function(a, b, c, d, e, f, g) {
        _.fc((0, _.se)(a.D));
        b = Ie(a, b, e, 2, void 0, !0);
        e = (0, _.dc)(b);
        e = 4 & e ? 4096 & e ? 4096 : 8192 & e ? 8192 : 0 : void 0;
        e = e != null ? e : 0;
        if (g)
            if (Array.isArray(d))
                for (d = _.Se(d), f = d.length, g = 0; g < f; g++) b.push(c(d[g], e));
            else
                for (d = _.y(d), f = d.next(); !f.done; f = d.next()) b.push(c(f.value, e));
        else {
            if (f) throw Error();
            b.push(c(d, e))
        }
        return a
    };
    ef = function(a, b, c, d) {
        var e = (0, _.se)(a.D);
        _.fc(e);
        a = _.cf(a, e, c, b, 2, void 0, !0);
        d = d != null ? d : new c;
        a.push(d);
        (0, _.dc)(d.D) & 2 ? (0, _.Me)(a, 8) : (0, _.Me)(a, 16);
        return d
    };
    ff = function(a) {
        return vd(a, !0)
    };
    gf = function(a, b) {
        return a != null ? a : b
    };
    _.jf = function(a) {
        a = hf ? a.D : ne(a.D, pe, void 0, void 0, !1);
        var b = !hf,
            c = a.length;
        if (c) {
            var d = a[c - 1],
                e = $b(d);
            e ? c-- : d = void 0;
            var f = a;
            if (e) {
                b: {
                    var g = d;
                    var h;
                    var l = !1;
                    if (g)
                        for (var k in g)
                            if (Object.prototype.hasOwnProperty.call(g, k))
                                if (isNaN(+k)) e = void 0, ((e = h) != null ? e : h = {})[k] = g[k];
                                else if (e = g[k], Array.isArray(e) && (ec(e) || Zb(e) && e.size === 0) && (e = null), e == null && (l = !0), e != null) {
                        var m = void 0;
                        ((m = h) != null ? m : h = {})[k] = e
                    }
                    l || (h = g);
                    if (h)
                        for (var n in h) {
                            l = h;
                            break b
                        }
                    l = null
                }
                g = l == null ? d != null : l !== d
            }
            for (; c > 0; c--) {
                h = f[c - 1];
                if (!(h == null || ec(h) || Zb(h) && h.size === 0)) break;
                var p = !0
            }
            if (f !== a || g || p) {
                if (!b) f = Array.prototype.slice.call(f, 0, c);
                else if (p || g || l) f.length = c;
                l && f.push(l)
            }
            p = f
        } else p = a;
        return p
    };
    kf = function(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        Rb(b, 128);
        return Ud(a, Tb(b))
    };
    lf = function() {
        var a = function() {
            throw Error();
        };
        _.w(Object, "setPrototypeOf").call(Object, a, a.prototype);
        return a
    }; of = function(a) {
        var b = b === void 0 ? mf : b;
        return new nf(a, b)
    };
    rf = function(a, b, c, d, e) {
        pf(a, c, qf(b, d), e)
    };
    yf = function(a) {
        var b = sf,
            c = tf,
            d = a[uf];
        if (d) return d;
        d = {};
        d.Gk = Xd(a[0]);
        var e = a[1],
            f = 1;
        e && e.constructor === Object && (d.ln = e, e = a[++f], typeof e === "function" && (d.Zn = !0, vf != null || (vf = e), wf != null || (wf = a[f + 1]), e = a[f += 2]));
        for (var g = {}; e && Array.isArray(e) && e.length && typeof e[0] === "number" && e[0] > 0;) {
            for (var h = 0; h < e.length; h++) g[e[h]] = e;
            e = a[++f]
        }
        for (h = 1; e !== void 0;) {
            typeof e === "number" && (h += e, e = a[++f]);
            var l = void 0;
            if (e instanceof nf) var k = e;
            else k = xf, f--;
            e = void 0;
            if ((e = k) == null ? 0 : e.o) {
                e = a[++f];
                l = a;
                var m = f;
                typeof e === "function" && (e = e(), l[m] = e);
                l = e
            }
            e = a[++f];
            m = h + 1;
            typeof e === "number" && e < 0 && (m -= e, e = a[++f]);
            for (; h < m; h++) {
                var n = g[h];
                l ? c(d, h, k, l, n) : b(d, h, k, n)
            }
        }
        return a[uf] = d
    };
    qf = function(a, b) {
        if (a instanceof _.B) return a.D;
        if (Array.isArray(a)) return _.A(a, b[0], b[1], 2)
    };
    sf = function(a, b, c) {
        a[b] = c.g
    };
    tf = function(a, b, c, d) {
        var e, f, g = c.g;
        a[b] = function(h, l, k) {
            return g(h, l, k, f || (f = yf(d).Gk), e || (e = zf(d)))
        }
    };
    zf = function(a) {
        var b = a[Af];
        if (!b) {
            var c = yf(a);
            b = function(d, e) {
                return Bf(d, e, c)
            };
            a[Af] = b
        }
        return b
    };
    Bf = function(a, b, c) {
        for (var d = (0, _.dc)(a), e = +!!(d & 512) - 1, f = a.length, g = f + (d & 256 ? -1 : 0), h = d & 512 ? 1 : 0; h < g; h++) {
            var l = a[h];
            if (l != null) {
                var k = h - e,
                    m = Cf(c, k);
                m && m(b, l, k)
            }
        }
        if (d & 256) {
            a = a[f - 1];
            for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (d = +n, _.w(Number, "isNaN").call(Number, d) || (e = a[d], e != null && (f = Cf(c, d)) && f(b, e, d)))
        }
    };
    Cf = function(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.ln)
            if (c = c[b]) {
                c = Array.isArray(c) ? c[0] instanceof nf ? c : [Df, c] : [c, void 0];
                var d = c[0].g;
                if (c = c[1]) {
                    var e = zf(c),
                        f = yf(c).Gk;
                    c = a.Zn ? wf(f, e) : function(g, h, l) {
                        return d(g, h, l, f, e)
                    }
                } else c = d;
                return a[b] = c
            }
    };
    _.Ef = function(a, b, c) {
        if (Array.isArray(b)) {
            var d = (0, _.dc)(b);
            if (d & 4) return b;
            for (var e = 0, f = 0; e < b.length; e++) {
                var g = a(b[e]);
                g != null && (b[f++] = g)
            }
            f < e && (b.length = f);
            c && (Vb(b, (d | 5) & -12289), d & 2 && Object.freeze(b));
            return b
        }
    };
    _.Ff = function(a, b) {
        return new nf(a, b)
    };
    _.Gf = function(a, b) {
        return new nf(a, b)
    };
    _.Kf = function(a, b, c) {
        b = Oc(b);
        b != null && (Hf(a, c, 5), a = a.g, c = If || (If = new DataView(new ArrayBuffer(8))), c.setFloat32(0, +b, !0), _.Ec = 0, _.Dc = c.getUint32(0, !0), Jf(a, _.Dc))
    };
    Of = function(a, b, c) {
        b = _.yd(b);
        if (b != null) {
            switch (typeof b) {
                case "string":
                    _.Lf(b)
            }
            if (b != null) switch (Hf(a, c, 0), typeof b) {
                case "number":
                    a = a.g;
                    _.Hc(b);
                    _.Mf(a, _.Dc, _.Ec);
                    break;
                case "bigint":
                    c = _.Nf(b);
                    _.Mf(a.g, c.o, c.g);
                    break;
                default:
                    c = _.Lf(b), _.Mf(a.g, c.o, c.g)
            }
        }
    };
    _.Rf = function(a, b, c) {
        b = zd(b);
        if (b != null) {
            switch (typeof b) {
                case "string":
                    Pf(b)
            }
            if (b != null) switch (Hf(a, c, 0), typeof b) {
                case "number":
                    a = a.g;
                    _.Hc(b);
                    _.Mf(a, _.Dc, _.Ec);
                    break;
                case "bigint":
                    c = BigInt.asUintN(64, b);
                    c = new Qf(Number(c & BigInt(4294967295)), Number(c >> BigInt(32)));
                    _.Mf(a.g, c.o, c.g);
                    break;
                default:
                    c = Pf(b), _.Mf(a.g, c.o, c.g)
            }
        }
    };
    Tf = function(a, b, c) {
        b = Zc(b);
        b != null && b != null && (Hf(a, c, 0), Sf(a.g, b))
    };
    Uf = function(a, b, c) {
        b = Rc(b);
        b != null && (Hf(a, c, 0), a.g.g.push(b ? 1 : 0))
    };
    Wf = function(a, b, c) {
        b = Dd(b);
        b != null && Vf(a, c, xb(b))
    };
    Xf = function(a, b, c, d, e) {
        pf(a, c, qf(b, d), e)
    };
    Yf = function(a, b, c) {
        b = Zc(b);
        b != null && (b = parseInt(b, 10), Hf(a, c, 0), Sf(a.g, b))
    };
    _.$f = function(a) {
        return function(b) {
            return Zf(b, a)
        }
    };
    ag = function(a) {
        return function() {
            return Zf(this, a)
        }
    };
    bg = function(a) {
        return function(b) {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = Ud(a, Tb(b))
            }
            return b
        }
    };
    cg = function(a) {
        return a instanceof _.Pa ? a : _.Qa(String(a).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;"))
    };
    dg = function(a) {
        var b = cg("");
        return _.Qa(a.map(function(c) {
            return _.Ra(cg(c))
        }).join(_.Ra(b).toString()))
    };
    gg = function(a) {
        if (!eg.test(a)) throw Error("");
        if (fg.indexOf(a.toUpperCase()) !== -1) throw Error("");
    };
    lg = function(a, b, c) {
        gg(a);
        var d = "<" + a;
        b && (d += hg(b));
        Array.isArray(c) || (c = c === void 0 ? [] : [c]);
        kg.indexOf(a.toUpperCase()) !== -1 ? d += ">" : (b = dg(c.map(function(e) {
            return e instanceof _.Pa ? e : cg(String(e))
        })), d += ">" + b.toString() + "</" + a + ">");
        return _.Qa(d)
    };
    hg = function(a) {
        for (var b = "", c = _.w(Object, "keys").call(Object, a), d = 0; d < c.length; d++) {
            var e = c[d],
                f = a[e];
            if (!eg.test(e)) throw Error("");
            if (f !== void 0 && f !== null) {
                if (/^on./i.test(e)) throw Error("");
                mg.indexOf(e.toLowerCase()) !== -1 && (f = f instanceof Fa ? f.toString() : La(String(f)) || "about:invalid#zClosurez");
                f = e + '="' + cg(String(f)) + '"';
                b += " " + f
            }
        }
        return b
    };
    _.ng = function(a) {
        var b = _.Ia.apply(1, arguments);
        if (b.length === 0) return za(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return za(c)
    };
    pg = function(a, b) {
        a = _.Aa(a).toString();
        var c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return og(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    };
    og = function(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(function(l) {
                return e(l, h)
            }) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        var f = b.length ? "&" : "?";
        d.constructor === Object && (d = _.w(Object, "entries").call(Object, d));
        Array.isArray(d) ? d.forEach(function(g) {
            return e(g[1], g[0])
        }) : d.forEach(e);
        return za(a + b + c)
    };
    rg = function(a) {
        return a ? a.passive && qg() ? a : a.capture || !1 : !1
    };
    tg = function(a) {
        var b = window,
            c = !0;
        c = c === void 0 ? !1 : c;
        new _.z.Promise(function(d, e) {
            function f() {
                g.onload = null;
                g.onerror = null;
                var h;
                (h = g.parentElement) == null || h.removeChild(g)
            }
            var g = b.document.createElement("script");
            g.onload = function() {
                f();
                d()
            };
            g.onerror = function() {
                f();
                e(void 0)
            };
            g.type = "text/javascript";
            Xa(g, a);
            c && b.document.readyState !== "complete" ? _.sg(b, "load", function() {
                b.document.body.appendChild(g)
            }) : b.document.body.appendChild(g)
        })
    };
    xg = function(a) {
        var b, c, d, e, f, g, h;
        return _.ug(function(l) {
            switch (l.g) {
                case 1:
                    return b = a.qc ? "https://ep1.adtrafficquality.google/getconfig/sodar" : "https://pagead2.googlesyndication.com/getconfig/sodar", c = b + "?sv=200&tid=" + a.g + ("&tv=" + a.o + "&st=") + a.Rd, d = void 0, l.l = 2, l.yield(vg(c), 4);
                case 4:
                    d = l.o;
                    l.g = 3;
                    l.l = 0;
                    break;
                case 2:
                    wg(l);
                case 3:
                    if (!d) return l.return(void 0);
                    e = a.ve || d.sodar_query_id;
                    f = d.rc_enable !== void 0 && a.l ? d.rc_enable : "n";
                    g = d.bg_snapshot_delay_ms === void 0 ? "0" : d.bg_snapshot_delay_ms;
                    h = d.is_gen_204 === void 0 ? "1" : d.is_gen_204;
                    return e && d.bg_hash_basename && d.bg_binary ? l.return({
                        context: a.j,
                        sm: d.bg_hash_basename,
                        rm: d.bg_binary,
                        io: a.g + "_" + a.o,
                        ve: e,
                        Rd: a.Rd,
                        Hf: f,
                        kg: g,
                        Gf: h,
                        qc: a.qc
                    }) : l.return(void 0)
            }
        })
    };
    Ag = function(a) {
        var b;
        _.ug(function(c) {
            if (c.g == 1) return c.yield(xg(a), 2);
            if (b = c.o) {
                var d = b,
                    e = "sodar2";
                e = e === void 0 ? "sodar2" : e;
                var f = window,
                    g = f.GoogleGcLKhOms;
                g && typeof g.push === "function" || (g = f.GoogleGcLKhOms = []);
                var h = {};
                g.push((h._ctx_ = d.context, h._bgv_ = d.sm, h._bgp_ = d.rm, h._li_ = d.io, h._jk_ = d.ve, h._st_ = d.Rd, h._rc_ = d.Hf, h._dl_ = d.kg, h._g2_ = d.Gf, h._atqg_ = d.qc === void 0 ? "0" : d.qc ? "1" : "0", h));
                if (g = f.GoogleDX5YKUSk) f.GoogleDX5YKUSk = void 0, g[1]();
                d = d.qc ? _.ng(yg, e) : _.ng(zg, e);
                tg(d)
            }
            return c.return(b)
        })
    };
    Bg = function(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    };
    Cg = function(a, b) {
        for (var c in a) b.call(void 0, a[c], c, a)
    };
    Dg = function(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    Eg = function(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return c
    };
    Gg = function(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < Fg.length; f++) c = Fg[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    Hg = function(a) {
        a = a === void 0 ? _.ca : a;
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch (e) {}
        var c, d;
        return ((c = b) == null ? 0 : c.pageViewId) && ((d = b) == null ? 0 : d.canonicalUrl) ? b : null
    };
    Ig = function(a) {
        return _.w(a, "includes").call(a, "~") ? a.split("~").slice(1) : []
    };
    Kg = function(a) {
        return Jg(a.length % 4 !== 0 ? a + "A" : a).map(function(b) {
            return (_.E = b.toString(2), _.w(_.E, "padStart")).call(_.E, 8, "0")
        }).join("")
    };
    Lg = function(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        return parseInt(a, 2)
    };
    Mg = function(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        for (var b = [1, 2, 3, 5], c = 0, d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };
    Ng = function(a, b) {
        a = Kg(a);
        return a.length < b ? _.w(a, "padEnd").call(a, b, "0") : a
    };
    Rg = function(a) {
        var b = Kg(a),
            c = Lg(b.slice(0, 6));
        a = Lg(b.slice(6, 12));
        var d = new Og;
        c = _.Pg(d, 1, c);
        a = _.Pg(c, 2, a);
        b = b.slice(12);
        c = Lg(b.slice(0, 12));
        d = [];
        for (var e = b.slice(12).replace(/0+$/, ""), f = 0; f < c; f++) {
            if (e.length === 0) throw Error("Found " + f + " of " + c + " sections [" + d + "] but reached end of input [" + b + "]");
            var g = Lg(e[0]) === 0;
            e = e.slice(1);
            var h = Qg(e, b),
                l = d.length === 0 ? 0 : d[d.length - 1];
            l = Mg(h) + l;
            e = e.slice(h.length);
            if (g) d.push(l);
            else {
                g = Qg(e, b);
                h = Mg(g);
                for (var k = 0; k <= h; k++) d.push(l + k);
                e = e.slice(g.length)
            }
        }
        if (e.length > 0) throw Error("Found " + c + " sections [" + d + "] but has remaining input [" + e + "], entire input [" + b + "]");
        return _.Ve(a, 3, d, Yc)
    };
    Qg = function(a, b) {
        var c = a.indexOf("11");
        if (c === -1) throw Error("Expected section bitstring but not found in [" + a + "] part of [" + b + "]");
        return a.slice(0, c + 2)
    };
    ah = function(a) {
        if (a.length === 0) throw Error("Cannot decode empty USCA section string.");
        var b = a.split(".");
        if (b.length > 2) throw Error("Expected at most 1 sub-section but got " + (b.length - 1) + " when decoding " + a + ".");
        a = b[0];
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        var c = Ng(a, Sg),
            d = Lg(c.slice(0, 6));
        c = c.slice(6);
        if (d !== 1) throw Error("Unable to decode unsupported USCA Section specification version " + d + " - only version 1 is supported.");
        var e = 0;
        a = [];
        for (var f = 0; f < Tg.length; f++) {
            var g = Tg[f];
            a.push(Lg(c.slice(e, e + g)));
            e += g
        }
        c = new Ug;
        d = _.Pg(c, 1, d);
        c = a.shift();
        d = _.H(d, 2, c);
        c = a.shift();
        d = _.H(d, 3, c);
        c = a.shift();
        d = _.H(d, 4, c);
        c = a.shift();
        d = _.H(d, 5, c);
        c = a.shift();
        d = _.H(d, 6, c);
        c = new Vg;
        e = a.shift();
        c = _.H(c, 1, e);
        e = a.shift();
        c = _.H(c, 2, e);
        e = a.shift();
        c = _.H(c, 3, e);
        e = a.shift();
        c = _.H(c, 4, e);
        e = a.shift();
        c = _.H(c, 5, e);
        e = a.shift();
        c = _.H(c, 6, e);
        e = a.shift();
        c = _.H(c, 7, e);
        e = a.shift();
        c = _.H(c, 8, e);
        e = a.shift();
        c = _.H(c, 9, e);
        d = _.Wg(d, 7, c);
        c = new Xg;
        e = a.shift();
        c = _.H(c, 1, e);
        e = a.shift();
        c = _.H(c, 2, e);
        d = _.Wg(d, 8, c);
        c = a.shift();
        d = _.H(d, 9, c);
        c = a.shift();
        d = _.H(d, 10, c);
        c = a.shift();
        d = _.H(d, 11, c);
        a = a.shift();
        a = _.H(d, 12, a);
        if (b.length === 1) b = Yg(a);
        else {
            a = Yg(a);
            b = b[1];
            if (b.length === 0) throw Error("Cannot decode empty GPC segment string.");
            d = Ng(b, 3);
            b = Lg(d.slice(0, 2));
            if (b < 0 || b > 1) throw Error("Attempting to decode unknown GPC segment subsection type " + b + ".");
            b += 1;
            d = Lg(d.charAt(2));
            c = new Zg;
            b = _.H(c, 2, b);
            b = _.$g(b, 1, !!d);
            b = _.Wg(a, 2, b)
        }
        return b
    };
    hh = function(a) {
        if (a.length === 0) throw Error("Cannot decode empty USCO section string.");
        var b = a.split(".");
        if (b.length > 2) throw Error("Expected at most 2 segments but got " + b.length + " when decoding " + a + ".");
        a = b[0];
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        var c = Ng(a, bh),
            d = Lg(c.slice(0, 6));
        c = c.slice(6);
        if (d !== 1) throw Error("Unable to decode unsupported USCO Section specification version " + d + " - only version 1 is supported.");
        var e = 0;
        a = [];
        for (var f = 0; f < ch.length; f++) {
            var g = ch[f];
            a.push(Lg(c.slice(e, e + g)));
            e += g
        }
        c = new dh;
        d = _.Pg(c, 1, d);
        c = a.shift();
        d = _.H(d, 2, c);
        c = a.shift();
        d = _.H(d, 3, c);
        c = a.shift();
        d = _.H(d, 4, c);
        c = a.shift();
        d = _.H(d, 5, c);
        c = a.shift();
        d = _.H(d, 6, c);
        c = new eh;
        e = a.shift();
        c = _.H(c, 1, e);
        e = a.shift();
        c = _.H(c, 2, e);
        e = a.shift();
        c = _.H(c, 3, e);
        e = a.shift();
        c = _.H(c, 4, e);
        e = a.shift();
        c = _.H(c, 5, e);
        e = a.shift();
        c = _.H(c, 6, e);
        e = a.shift();
        c = _.H(c, 7, e);
        d = _.Wg(d, 7, c);
        c = a.shift();
        d = _.H(d, 8, c);
        c = a.shift();
        d = _.H(d, 9, c);
        c = a.shift();
        d = _.H(d, 10, c);
        a = a.shift();
        a = _.H(d, 11, a);
        if (b.length === 1) b = fh(a);
        else {
            a = fh(a);
            b = b[1];
            if (b.length === 0) throw Error("Cannot decode empty GPC segment string.");
            d = Ng(b, 3);
            b = Lg(d.slice(0, 2));
            if (b < 0 || b > 1) throw Error("Attempting to decode unknown GPC segment subsection type " + b + ".");
            b += 1;
            d = Lg(d.charAt(2));
            c = new gh;
            b = _.H(c, 2, b);
            b = _.$g(b, 1, !!d);
            b = _.Wg(a, 2, b)
        }
        return b
    };
    qh = function(a) {
        if (a.length === 0) throw Error("Cannot decode empty usct section string.");
        var b = a.split(".");
        if (b.length > 2) throw Error("Expected at most 2 segments but got " + b.length + " when decoding " + a + ".");
        a = b[0];
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        var c = Ng(a, ih),
            d = Lg(c.slice(0, 6));
        c = c.slice(6);
        if (d !== 1) throw Error("Unable to decode unsupported USCT Section specification version " + d + " - only version 1 is supported.");
        var e = 0;
        a = [];
        for (var f = 0; f < jh.length; f++) {
            var g = jh[f];
            a.push(Lg(c.slice(e, e + g)));
            e += g
        }
        c = new kh;
        d = _.Pg(c, 1, d);
        c = a.shift();
        d = _.H(d, 2, c);
        c = a.shift();
        d = _.H(d, 3, c);
        c = a.shift();
        d = _.H(d, 4, c);
        c = a.shift();
        d = _.H(d, 5, c);
        c = a.shift();
        d = _.H(d, 6, c);
        c = new lh;
        e = a.shift();
        c = _.H(c, 1, e);
        e = a.shift();
        c = _.H(c, 2, e);
        e = a.shift();
        c = _.H(c, 3, e);
        e = a.shift();
        c = _.H(c, 4, e);
        e = a.shift();
        c = _.H(c, 5, e);
        e = a.shift();
        c = _.H(c, 6, e);
        e = a.shift();
        c = _.H(c, 7, e);
        e = a.shift();
        c = _.H(c, 8, e);
        d = _.Wg(d, 7, c);
        c = new mh;
        e = a.shift();
        c = _.H(c, 1, e);
        e = a.shift();
        c = _.H(c, 2, e);
        e = a.shift();
        c = _.H(c, 3, e);
        d = _.Wg(d, 8, c);
        c = a.shift();
        d = _.H(d, 9, c);
        c = a.shift();
        d = _.H(d, 10, c);
        a = a.shift();
        a = _.H(d, 11, a);
        if (b.length === 1) b = oh(a);
        else {
            a = oh(a);
            b = b[1];
            if (b.length === 0) throw Error("Cannot decode empty GPC segment string.");
            d = Ng(b, 3);
            b = Lg(d.slice(0, 2));
            if (b < 0 || b > 1) throw Error("Attempting to decode unknown GPC segment subsection type " + b + ".");
            b += 1;
            d = Lg(d.charAt(2));
            c = new ph;
            b = _.H(c, 2, b);
            b = _.$g(b, 1, !!d);
            b = _.Wg(a, 2, b)
        }
        return b
    };
    yh = function(a) {
        if (a.length === 0) throw Error("Cannot decode empty USNat section string.");
        var b = a.split(".");
        if (b.length > 2) throw Error("Expected at most 2 segments but got " + b.length + " when decoding " + a + ".");
        a = b[0];
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        var c = Ng(a, rh),
            d = Lg(c.slice(0, 6));
        c = c.slice(6);
        if (d !== 1) throw Error("Unable to decode unsupported USNat Section specification version " + d + " - only version 1 is supported.");
        var e = 0;
        a = [];
        for (var f = 0; f < sh.length; f++) {
            var g = sh[f];
            a.push(Lg(c.slice(e, e + g)));
            e += g
        }
        c = new th;
        d = _.Pg(c, 1, d);
        c = a.shift();
        d = _.H(d, 2, c);
        c = a.shift();
        d = _.H(d, 3, c);
        c = a.shift();
        d = _.H(d, 4, c);
        c = a.shift();
        d = _.H(d, 5, c);
        c = a.shift();
        d = _.H(d, 6, c);
        c = a.shift();
        d = _.H(d, 7, c);
        c = a.shift();
        d = _.H(d, 8, c);
        c = a.shift();
        d = _.H(d, 9, c);
        c = a.shift();
        d = _.H(d, 10, c);
        c = new uh;
        e = a.shift();
        c = _.H(c, 1, e);
        e = a.shift();
        c = _.H(c, 2, e);
        e = a.shift();
        c = _.H(c, 3, e);
        e = a.shift();
        c = _.H(c, 4, e);
        e = a.shift();
        c = _.H(c, 5, e);
        e = a.shift();
        c = _.H(c, 6, e);
        e = a.shift();
        c = _.H(c, 7, e);
        e = a.shift();
        c = _.H(c, 8, e);
        e = a.shift();
        c = _.H(c, 9, e);
        e = a.shift();
        c = _.H(c, 10, e);
        e = a.shift();
        c = _.H(c, 11, e);
        e = a.shift();
        c = _.H(c, 12, e);
        d = _.Wg(d, 11, c);
        c = new vh;
        e = a.shift();
        c = _.H(c, 1, e);
        e = a.shift();
        c = _.H(c, 2, e);
        d = _.Wg(d, 12, c);
        c = a.shift();
        d = _.H(d, 13, c);
        c = a.shift();
        d = _.H(d, 14, c);
        c = a.shift();
        d = _.H(d, 15, c);
        a = a.shift();
        a = _.H(d, 16, a);
        if (b.length === 1) b = wh(a);
        else {
            a = wh(a);
            b = b[1];
            if (b.length === 0) throw Error("Cannot decode empty GPC segment string.");
            d = Ng(b, 3);
            b = Lg(d.slice(0, 2));
            if (b < 0 || b > 1) throw Error("Attempting to decode unknown GPC segment subsection type " + b + ".");
            b += 1;
            d = Lg(d.charAt(2));
            c = new xh;
            b = _.H(c, 2, b);
            b = _.$g(b, 1, !!d);
            b = _.Wg(a, 2, b)
        }
        return b
    };
    Dh = function(a) {
        if (a.length === 0) throw Error("Cannot decode empty USVA section string.");
        var b = Ng(a, zh),
            c = Lg(b.slice(0, 6));
        b = b.slice(6);
        if (c !== 1) throw Error("Unable to decode unsupported USVA Section specification version " + c + " - only version 1 is supported.");
        var d = 0;
        a = [];
        for (var e = 0; e < Ah.length; e++) {
            var f = Ah[e];
            a.push(Lg(b.slice(d, d + f)));
            d += f
        }
        b = new Bh;
        c = _.Pg(b, 1, c);
        b = a.shift();
        c = _.H(c, 2, b);
        b = a.shift();
        c = _.H(c, 3, b);
        b = a.shift();
        c = _.H(c, 4, b);
        b = a.shift();
        c = _.H(c, 5, b);
        b = a.shift();
        c = _.H(c, 6, b);
        b = new Ch;
        d = a.shift();
        b = _.H(b, 1, d);
        d = a.shift();
        b = _.H(b, 2, d);
        d = a.shift();
        b = _.H(b, 3, d);
        d = a.shift();
        b = _.H(b, 4, d);
        d = a.shift();
        b = _.H(b, 5, d);
        d = a.shift();
        b = _.H(b, 6, d);
        d = a.shift();
        b = _.H(b, 7, d);
        d = a.shift();
        b = _.H(b, 8, d);
        c = _.Wg(c, 7, b);
        b = a.shift();
        c = _.H(c, 8, b);
        b = a.shift();
        c = _.H(c, 9, b);
        b = a.shift();
        c = _.H(c, 10, b);
        a = a.shift();
        return _.H(c, 11, a)
    };
    _.Eh = function(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                for (var d; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (e) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    Hh = function(a, b, c, d, e) {
        e = e === void 0 ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var f = _.Fh("IMG", a.document);
        if (c || d) {
            var g = function(h) {
                c && c(h);
                d && bb(a.google_image_requests, f);
                _.Gh(f, "load", g);
                _.Gh(f, "error", g)
            };
            _.sg(f, "load", g);
            _.sg(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    };
    Jh = function(a, b) {
        try {
            var c = function(d) {
                var e = {};
                return [(e[d.za] = d.vb, e)]
            };
            return JSON.stringify([a.filter(function(d) {
                return d.ua
            }).map(c), _.jf(b), a.filter(function(d) {
                return !d.ua
            }).map(c)])
        } catch (d) {
            return Ih(d, b), ""
        }
    };
    Qh = function(a, b) {
        var c = new Kh;
        try {
            var d = a.filter(function(f) {
                return f.ua
            }).map(Lh);
            Mh(c, 1, d);
            pf(c, 2, Nh(b), Oh);
            var e = a.filter(function(f) {
                return !f.ua
            }).map(Lh);
            Mh(c, 3, e)
        } catch (f) {
            Ih(f, b)
        }
        return Ph(c)
    };
    Ih = function(a, b) {
        try {
            Rh({
                m: _.Eh(a instanceof Error ? a : Error(String(a))),
                b: _.Sh(b, 1, 0) || null,
                v: _.t(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    };
    Lh = function(a) {
        var b = new Kh;
        pf(b, a.za, a.yb, Oh);
        return Ph(b)
    };
    Oh = function(a, b) {
        a = a.subarray(0, a.length);
        Th(b, b.g.end());
        Th(b, a)
    };
    Uh = function(a) {
        return Math.round(a)
    };
    Vh = function(a, b, c, d, e, f) {
        try {
            var g = a.g,
                h = _.Fh("SCRIPT", g);
            h.async = !0;
            Xa(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", function() {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", function() {
                c > 0 ? Vh(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (l) {
            f()
        }
    };
    Xh = function(a, b, c, d) {
        c = c === void 0 ? function() {} : c;
        d = d === void 0 ? function() {} : d;
        Vh(Wh(a), b, 0, !1, c, d)
    };
    Yh = function(a) {
        return a[_.w(_.z.Symbol, "iterator")]()
    };
    ai = function(a) {
        var b = Zh($h(a.location.href));
        a = b.get("fcconsent");
        b = b.get("fc");
        return b === "alwaysshow" ? b : a === "alwaysshow" ? a : null
    };
    bi = function(a) {
        var b = ["ab", "gdpr", "consent", "ccpa", "monetization"];
        return (a = Zh($h(a.location.href)).get("fctype")) && b.indexOf(a) !== -1 ? a : null
    };
    di = function(a) {
        var b = $h(a),
            c = {
                search: "",
                hash: ""
            };
        a = {};
        b && (a.protocol = b.protocol, a.username = b.username, a.password = b.password, a.hostname = b.hostname, a.port = b.port, a.pathname = b.pathname, a.search = b.search, a.hash = b.hash);
        _.w(Object, "assign").call(Object, a, c);
        if (a.port && a.port[0] === ":") throw Error("port should not start with ':'");
        a.hash && a.hash[0] != "#" && (a.hash = "#" + a.hash);
        c.search ? c.search[0] != "?" && (a.search = "?" + c.search) : c.searchParams && (a.search = "?" + ci(c.searchParams), a.searchParams = void 0);
        b = "";
        a.protocol && (b += a.protocol + "//");
        c = a.username;
        var d = a.password;
        b = b + (c && d ? c + ":" + d + "@" : c ? c + "@" : d ? ":" + d + "@" : "") + (a.hostname || "");
        a.port && (b += ":" + a.port);
        b += a.pathname || "";
        b += a.search || "";
        b += a.hash || "";
        a = $h(b).toString();
        a.charAt(a.length - 1) === "/" && (a = a.substring(0, a.length - 1));
        return a.toString().length <= 1E3 ? a : null
    };
    ei = function(a) {
        var b = a.document,
            c = function() {
                if (!a.frames.googlefcPresent)
                    if (b.body) {
                        var d = _.Fh("IFRAME", b);
                        d.style.display = "none";
                        d.style.width = "0px";
                        d.style.height = "0px";
                        d.style.border = "none";
                        d.style.zIndex = "-1000";
                        d.style.left = "-1000px";
                        d.style.top = "-1000px";
                        d.name = "googlefcPresent";
                        b.body.appendChild(d)
                    } else a.setTimeout(c, 5)
            };
        c()
    };
    fi = function(a) {
        a && typeof a.dispose == "function" && a.dispose()
    };
    ii = function(a) {
        a = gi(a.data.__fciReturn);
        return {
            payload: a,
            ki: _.hi(a, 1)
        }
    };
    ji = function(a) {
        a.addtlConsent !== void 0 && typeof a.addtlConsent !== "string" && (a.addtlConsent = void 0);
        a.gdprApplies !== void 0 && typeof a.gdprApplies !== "boolean" && (a.gdprApplies = void 0);
        return a.tcString !== void 0 && typeof a.tcString !== "string" || a.listenerId !== void 0 && typeof a.listenerId !== "number" ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    };
    li = function(a, b) {
        a = _.ng(ki, a);
        b = _.w(Object, "assign").call(Object, {}, b, {
            ers: 3
        });
        return pg(a, b)
    };
    oi = function() {
        var a = da();
        return a ? _.mi("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;WebOS".split(";"), function(b) {
            return ni(a, b)
        }) || ni(a, "OMI/") && !ni(a, "XiaoMi/") ? !0 : ni(a, "Presto") && ni(a, "Linux") && !ni(a, "X11") && !ni(a, "Android") && !ni(a, "Mobi") : !1
    };
    pi = function(a) {
        return !!a && a.top === a
    };
    ti = function(a) {
        a = a === void 0 ? _.ca : a;
        var b = new qi;
        "SVGElement" in a && "createElementNS" in a.document && b.set(0);
        var c = ri();
        c["allow-top-navigation-by-user-activation"] && b.set(1);
        c["allow-popups-to-escape-sandbox"] && b.set(2);
        a.crypto && a.crypto.subtle && b.set(3);
        "TextDecoder" in a && "TextEncoder" in a && b.set(4);
        return si(b)
    };
    ui = function(a) {
        var b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            ki: b.__uspapiReturn.callId
        }
    };
    wi = function(a, b) {
        b = b === void 0 ? window : b;
        if (vi(a)) try {
            return b.localStorage
        } catch (c) {}
        return null
    };
    yi = function(a, b, c) {
        return vi(b) ? xi(a, c) : null
    };
    Bi = function(a) {
        return zi ? zi : a.origin === "null" ? zi = !1 : zi = Ai(a)
    };
    Ai = function(a) {
        if (!a.navigator.cookieEnabled) return !1;
        var b = new Ci(a.document);
        if (!b.isEmpty()) return !0;
        b.set("TESTCOOKIESENABLED", "1", {
            maxAge: 60,
            sameSite: a.isSecureContext ? "none" : void 0,
            secure: a.isSecureContext || void 0
        });
        if (b.get("TESTCOOKIESENABLED") !== "1") return !1;
        b.remove("TESTCOOKIESENABLED");
        return !0
    };
    xi = function(a, b) {
        b = b.origin !== "null" ? b.document.cookie : null;
        return b === null ? null : (new Ci({
            cookie: b
        })).get(a) || ""
    };
    Di = function(a, b, c, d) {
        d.origin !== "null" && (d.isSecureContext && (c = _.w(Object, "assign").call(Object, {}, c, {
            sameSite: "none",
            secure: !0
        })), (new Ci(d.document)).set(a, b, c))
    };
    Ei = function(a) {
        var b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            ki: b.__gppReturn.callId
        }
    };
    Gi = function(a) {
        a = _.Fi(a, th, 1);
        return _.Sh(a, 8, 0) === 1 || _.Sh(a, 9, 0) === 1 || _.Sh(a, 10, 0) === 1 ? !0 : !1
    };
    Hi = function(a) {
        a = _.Fi(a, Ug, 1);
        return _.Sh(a, 5, 0) === 1 || _.Sh(a, 6, 0) === 1 ? !0 : !1
    };
    Ii = function(a) {
        return _.Sh(a, 5, 0) === 1 || _.Sh(a, 6, 0) === 1 ? !0 : !1
    };
    Ji = function(a) {
        a = _.Fi(a, dh, 1);
        return _.Sh(a, 5, 0) === 1 || _.Sh(a, 6, 0) === 1 ? !0 : !1
    };
    Ki = function(a) {
        a = _.Fi(a, kh, 1);
        return _.Sh(a, 5, 0) === 1 || _.Sh(a, 6, 0) === 1 ? !0 : !1
    };
    Li = function(a) {
        return !a || a.length === 1 && a[0] === -1
    };
    Mi = function(a, b, c) {
        b = b === void 0 ? window : b;
        c = c === void 0 ? function() {} : c;
        try {
            return b.localStorage.getItem(a)
        } catch (d) {
            return c(d), null
        }
    };
    Ni = function(a, b, c) {
        var d = window;
        d = d === void 0 ? window : d;
        c = c === void 0 ? function() {} : c;
        return vi(b) ? Mi(a, d, c) : null
    };
    Oi = function(a, b, c, d) {
        c = c === void 0 ? window : c;
        d = d === void 0 ? function() {} : d;
        try {
            return c.localStorage.setItem(a, b), !0
        } catch (e) {
            d(e)
        }
        return !1
    };
    Pi = function(a, b, c, d) {
        var e = window;
        e = e === void 0 ? window : e;
        d = d === void 0 ? function() {} : d;
        return vi(c) ? Oi(a, b, e, d) : !1
    };
    Qi = function(a, b, c) {
        return b[a] || c
    };
    Ti = function(a) {
        _.Ri(Si).l(a)
    };
    Ui = function() {
        return _.Ri(Si).j()
    };
    Vi = function(a, b) {
        b = b === void 0 ? document : b;
        var c;
        return !((c = b.featurePolicy) == null || !(_.E = c.allowedFeatures(), _.w(_.E, "includes")).call(_.E, a))
    };
    Wi = function(a) {
        a = a === void 0 ? navigator : a;
        try {
            var b, c;
            return !!((b = a.protectedAudience) == null ? 0 : (c = b.queryFeatureSupport) == null ? 0 : c.call(b, "deprecatedRenderURLReplacements"))
        } catch (d) {
            return !1
        }
    };
    Xi = function(a, b, c) {
        return !!(a && "runAdAuction" in b && b.runAdAuction instanceof Function && Vi("run-ad-auction", c))
    };
    Yi = function(a, b) {
        return !!(a && "browsingTopics" in b && b.browsingTopics instanceof Function && Vi("browsing-topics", b))
    };
    Zi = function(a, b, c) {
        c = c === void 0 ? b.document : c;
        return !!(a && "sharedStorage" in b && b.sharedStorage && Vi("shared-storage", c))
    };
    bj = function(a) {
        a = a === void 0 ? _.$i() : a;
        return function(b) {
            return _.aj(b + " + " + a) % 1E3
        }
    };
    _.I = function(a) {
        return _.Ri(cj).o(a.g, a.defaultValue)
    };
    _.K = function(a) {
        return _.Ri(cj).j(a.g, a.defaultValue)
    };
    dj = function(a) {
        return _.Ri(cj).J(a.g, a.defaultValue)
    };
    ej = function(a) {
        return _.Ri(cj).F(a.g, a.defaultValue)
    };
    mj = function(a) {
        _.Ri(ij).g(a)
    };
    rj = function() {
        if (b === void 0) {
            var a = a === void 0 ? _.ca : a;
            var b = a.ggeac || (a.ggeac = {})
        }
        a = b;
        oj(_.Ri(Si), a);
        pj(b);
        qj(_.Ri(ij), b);
        _.Ri(cj).g()
    };
    pj = function(a) {
        var b = _.Ri(cj);
        b.o = function(c, d) {
            return Qi(5, a, function() {
                return !1
            })(c, d, 2)
        };
        b.j = function(c, d) {
            return Qi(6, a, function() {
                return 0
            })(c, d, 2)
        };
        b.J = function(c, d) {
            return Qi(7, a, function() {
                return ""
            })(c, d, 2)
        };
        b.F = function(c, d) {
            return Qi(8, a, function() {
                return []
            })(c, d, 2)
        };
        b.l = function(c, d) {
            return Qi(17, a, function() {
                return []
            })(c, d, 2)
        };
        b.g = function() {
            Qi(15, a, function() {})(2)
        }
    };
    wj = function(a) {
        a = a === void 0 ? document : a;
        var b = [],
            c = [];
        a = _.y(_.w(Array, "from").call(Array, a.querySelectorAll("meta[name=generator][content]")));
        for (var d = a.next(); !d.done; d = a.next())
            if (d = d.value) {
                var e = void 0;
                d = (e = d.getAttribute("content")) != null ? e : "";
                var f = void 0;
                e = _.y((f = /^([^0-9]+)(?:\s([0-9]+(?:\.[0-9]+){0,2})[.0-9]*)?[^0-9]*$/.exec(d)) != null ? f : []);
                e.next();
                f = e.next().value;
                var g = e.next().value;
                e = f;
                f = new sj;
                g && _.tj(f, 3, g.substring(0, 20));
                var h = void 0,
                    l = void 0;
                if (e) {
                    for (var k = _.y((_.E = new _.z.Map([
                            [1, "WordPress"],
                            [2, "Drupal"],
                            [3, "MediaWiki"],
                            [4, "Blogger"],
                            [5, "SEOmatic"],
                            [7, "Flutter"],
                            [8, "Joomla! - Open Source Content Management"]
                        ]), _.w(_.E, "entries")).call(_.E)), m = k.next(); !m.done; m = k.next()) {
                        var n = _.y(m.value);
                        m = n.next().value;
                        n = n.next().value;
                        if (n === e.trim()) {
                            h = m;
                            break
                        }
                    }
                    k = _.y((_.E = new _.z.Map([
                        [1, "All in One SEO (AIOSEO)"],
                        [2, "All in One SEO Pro (AIOSEO)"],
                        [3, "AMP for WP"],
                        [4, "Site Kit by Google"],
                        [5, "Elementor"],
                        [6, "Powered by WPBakery Page Builder - drag and drop page builder for WordPress."]
                    ]), _.w(_.E, "entries")).call(_.E));
                    for (m = k.next(); !m.done; m = k.next())
                        if (n = _.y(m.value), m = n.next().value, n = n.next().value, n === e.trim()) {
                            l = m;
                            break
                        }
                }
                l ? (d = _.uj(f, 1, 1), _.uj(d, 2, l)) : h ? _.uj(f, 1, h) : (l = _.uj(f, 1, 0), _.vj(l, 3), c.push({
                    content: d,
                    name: e,
                    version: g
                }));
                b.push(f)
            }
        return {
            labels: b,
            Sp: c
        }
    };
    zj = function(a) {
        try {
            var b, c, d = (b = a.performance) == null ? void 0 : (c = b.getEntriesByType("navigation")) == null ? void 0 : c[0];
            if (d == null ? 0 : d.type) {
                var e;
                return (e = xj.get(d.type)) != null ? e : null
            }
        } catch (l) {}
        var f, g, h;
        return (h = yj.get((f = a.performance) == null ? void 0 : (g = f.navigation) == null ? void 0 : g.type)) != null ? h : null
    };
    Dj = function(a, b, c, d) {
        var e = new _.Aj,
            f = "",
            g = function(l) {
                try {
                    var k = typeof l.data === "object" ? l.data : JSON.parse(l.data);
                    f === k.paw_id && (_.Gh(a, "message", g), k.error ? e.reject(Error(k.error)) : e.resolve(d(k)))
                } catch (m) {}
            },
            h = Bj(a);
        return h ? (_.sg(a, "message", g), f = c(h), e.promise) : (c = Cj(a)) ? (f = String(Math.floor(_.$i() * 2147483647)), _.sg(a, "message", g), b(c, f), e.promise) : null
    };
    Ej = function(a) {
        return Dj(a, function(b, c) {
            var d, e;
            return void((d = (e = b.getGmaQueryInfo) != null ? e : b.getGmaSig) == null ? void 0 : d.postMessage(c))
        }, function(b) {
            return b.getQueryInfo()
        }, function(b) {
            return b
        })
    };
    Fj = function(a) {
        return !!Bj(a) || !!Cj(a)
    };
    Bj = function(a) {
        var b;
        if (typeof((b = a.gmaSdk) == null ? void 0 : b.getQueryInfo) === "function") return a.gmaSdk
    };
    Cj = function(a) {
        var b, c, d, e, f, g;
        if (typeof((b = a.webkit) == null ? void 0 : (c = b.messageHandlers) == null ? void 0 : (d = c.getGmaQueryInfo) == null ? void 0 : d.postMessage) === "function" || typeof((e = a.webkit) == null ? void 0 : (f = e.messageHandlers) == null ? void 0 : (g = f.getGmaSig) == null ? void 0 : g.postMessage) === "function") return a.webkit.messageHandlers
    };
    Ij = function(a) {
        if ((a = Gj(a)) && RegExp("^(?:\\d+(?:,\\d)*)+$").exec(a.eid) && Hj(a.vc) && Hj(a.pn) && Hj(a.js) && (!a.vnm || Hj(a.vnm))) {
            var b = a.js.indexOf("afma-sdk-a") >= 0,
                c = a.vc + "." + (b ? "android" : "iphone") + "." + a.pn,
                d = a.eid.split(",").map(function(f) {
                    return Number(f)
                }),
                e = a.vnm;
            if (b || e === void 0) return {
                an: c,
                eid: d,
                js: a.js,
                vnm: e
            }
        }
    };
    Hj = function(a) {
        return !!RegExp("^(?:\\d|\\.|\\w|-|_)+$").exec(a)
    };
    Gj = function(a) {
        var b;
        if (typeof((b = a.gmaSdk) == null ? void 0 : b.as) === "object" && (a = a.gmaSdk.as, Jj(a))) return {
            vc: atob(a.vc),
            pn: atob(a.pn),
            eid: atob(a.eid),
            js: atob(a.js),
            vnm: a.vnm ? atob(a.vnm) : void 0
        }
    };
    Kj = function(a) {
        var b, c;
        return (c = (_.E = ["pbjs"].concat((b = a._pbjsGlobals) != null ? b : []).map(function(d) {
            return a[d]
        }), _.w(_.E, "find")).call(_.E, function(d) {
            return Array.isArray(d == null ? void 0 : d.que)
        })) != null ? c : null
    };
    Lj = function(a, b) {
        var c, d;
        return (d = (c = b == null ? void 0 : b.get(a)) != null ? c : b == null ? void 0 : b.get(_.aj(a))) != null ? d : 0
    };
    Nj = function(a, b, c) {
        return (new Mj(a, b, c)).fetch()
    };
    Oj = function(a, b) {
        var c, d;
        return _.ug(function(e) {
            if (e.g == 1) return c = b ? a.filter(function(f) {
                return !f.rc
            }) : a, e.yield(_.z.Promise.all(c.map(function(f) {
                return f.Tg.promise
            })), 2);
            if (a.length === c.length) return e.return();
            d = a.filter(function(f) {
                return f.rc
            });
            return e.yield(_.z.Promise.race([_.z.Promise.all(d.map(function(f) {
                return f.Tg.promise
            })), new _.z.Promise(function(f) {
                return void setTimeout(f, b)
            })]), 0)
        })
    };
    Pj = function(a, b, c) {
        return {
            id: a,
            func: b,
            Qa: c
        }
    };
    Rj = function(a, b) {
        return new Qj(a.id, a.func, b, a.Qa, _.Ia.apply(2, arguments))
    };
    Sj = function(a, b, c, d) {
        return {
            id: a,
            func: b,
            Ao: c,
            Qa: d
        }
    };
    Uj = function(a, b) {
        return new Tj(a.id, a.func, b, a.Ao, a.Qa, _.Ia.apply(2, arguments))
    };
    Xj = function(a, b) {
        if (a !== a.top) {
            b = b === void 0 ? -1 : b;
            if (b < 0) a = !1;
            else {
                var c = _.Vj(a, !0, !0),
                    d = _.Wj(a, !0);
                a = c > 0 && d > 0 && Math.abs(1 - a.screen.width / c) <= b && Math.abs(1 - a.screen.height / d) <= b
            }
            a = a ? 0 : 512
        } else a = 0;
        return a
    };
    _.Yj = function(a) {
        return a.innerHeight >= a.innerWidth
    };
    _.Zj = function(a) {
        var b = _.Vj(a);
        a = a.innerWidth;
        return b && a ? b / a : 0
    };
    ak = function(a, b, c) {
        b = b === void 0 ? 420 : b;
        return (a = _.Vj(a, !0, c === void 0 ? !1 : c)) ? a > b ? 32768 : a < 320 ? 65536 : 0 : 16384
    };
    _.bk = function(a) {
        a = a.document;
        var b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    };
    _.Wj = function(a, b) {
        var c = _.bk(a).clientHeight;
        return (b === void 0 ? 0 : b) ? c * _.ck(a) : c
    };
    _.Vj = function(a, b, c) {
        var d, e = (d = _.bk(a).clientWidth) != null ? d : (c === void 0 ? 0 : c) ? a.innerWidth : void 0;
        return (b === void 0 ? 0 : b) ? e * _.ck(a) : e
    };
    _.dk = function(a, b) {
        var c = _.bk(a);
        return b ? (a = _.Wj(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    };
    _.ek = function(a) {
        return a.pageYOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    };
    fk = function(a, b, c, d) {
        try {
            if (a.setAttribute("data-google-query-id", c), !d) {
                b.googletag != null || (b.googletag = {
                    cmd: []
                });
                var e;
                b.googletag.queryIds = (e = b.googletag.queryIds) != null ? e : [];
                b.googletag.queryIds.push(c);
                b.googletag.queryIds.length > 500 && b.googletag.queryIds.shift()
            }
        } catch (f) {}
    };
    _.gk = function(a) {
        var b = a.Ji;
        var c = a.bh;
        var d = a.Xh;
        var e = a.Ki;
        var f = a.dh;
        a = a.Yh;
        for (var g = [], h = 0; h < a; h++)
            for (var l = 0; l < d; l++) {
                var k = l,
                    m = d - 1,
                    n = h,
                    p = a - 1;
                g.push({
                    x: b + (m === 0 ? 0 : k / m) * (c - b),
                    y: e + (p === 0 ? 0 : n / p) * (f - e)
                })
            }
        return g
    };
    hk = function(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };
    ik = function(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    };
    lk = function(a, b) {
        return new _.jk(a, {
            Vj: kk(a, b === void 0 ? null : b)
        })
    };
    kk = function(a, b) {
        if (b = b === void 0 ? null : b) {
            var c = b;
            return function(d, e, f) {
                var g, h;
                _.mk(c, "ach_evt", {
                    tn: d.tagName,
                    id: (g = d.getAttribute("id")) != null ? g : "",
                    cls: (h = d.getAttribute("class")) != null ? h : "",
                    ign: String(f),
                    pw: a.innerWidth,
                    ph: a.innerHeight,
                    x: e.x,
                    y: e.y
                }, !0, 1)
            }
        }
    };
    nk = function(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            var b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return b === "__storage_test__"
        } catch (c) {
            return !1
        }
    };
    pk = function(a, b) {
        b = b === void 0 ? [] : b;
        var c = Date.now();
        return _.ok(b, function(d) {
            return c - d < a * 1E3
        })
    };
    qk = function(a, b, c) {
        try {
            var d = a.getItem(c);
            if (!d) return [];
            try {
                var e = JSON.parse(d)
            } catch (f) {}
            if (!Array.isArray(e) || _.mi(e, function(f) {
                    return !_.w(Number, "isInteger").call(Number, f)
                })) return a.removeItem(c), [];
            e = pk(b, e);
            e.length || a == null || a.removeItem(c);
            return e
        } catch (f) {
            return null
        }
    };
    _.rk = function(a, b, c) {
        return b <= 0 || a == null || !nk(a) ? null : qk(a, b, c)
    };
    sk = function(a, b) {
        var c = _.Fh("STYLE", a);
        c.textContent = _.Za(new _.Ya);
        a == null || a.head.appendChild(c);
        setTimeout(function() {
            a == null || a.head.removeChild(c)
        }, b)
    };
    _.vk = function(a, b, c) {
        if (!a.body) return null;
        var d = new tk;
        d.apply(a, b);
        return function() {
            var e = c || 0;
            e > 0 && sk(b.document, e);
            _.uk(a.body, {
                filter: d.g,
                webkitFilter: d.g,
                overflow: d.l,
                position: d.j,
                top: d.J
            });
            b.scrollTo(0, d.o)
        }
    };
    _.wk = function(a) {
        a = a === void 0 ? _.ca : a;
        return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    };
    _.xk = function(a) {
        a = a === void 0 ? _.ca : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    yk = function(a, b) {
        b = b === void 0 ? _.ca : b;
        var c, d;
        return ((c = b.performance) == null ? void 0 : (d = c.timing) == null ? void 0 : d[a]) || 0
    };
    _.zk = function(a) {
        a = a === void 0 ? _.ca : a;
        var b = Math.min(yk("domLoading", a) || Infinity, yk("domInteractive", a) || Infinity);
        return b === Infinity ? Math.max(yk("responseEnd", a), yk("navigationStart", a)) : b
    };
    Jk = function(a) {
        var b = _.Ak(new _.Bk, a.Ta);
        b = Ck(b, 4, _.Dk, id(a.uo));
        b = _.Ek(b, 11, a.documentUrl);
        b = _.Fk(b, 8, a.pvsid);
        b = _.Fk(b, 7, a.Cg);
        b = _.Ek(b, 9, a.Ub);
        _.Gk(_.Hk(b, _.Ik, 5), a.kb);
        return b
    };
    _.Kk = function(a) {
        var b = _.Ak(new _.Bk, a.Ta);
        b = Ck(b, 3, _.Dk, Wc(a.P));
        b = _.Ek(b, 11, a.documentUrl);
        b = _.Fk(b, 8, a.pvsid);
        b = _.Fk(b, 7, a.Cg);
        b = _.Ek(b, 9, a.Ub);
        _.Gk(_.Hk(b, _.Ik, 5), a.kb);
        return b
    };
    Mk = function(a, b) {
        return _.Lk(a, function(c) {
            return c.nodeType === Node.ELEMENT_NODE && b.has(c)
        }, !0) !== null
    };
    Nk = function(a, b) {
        return _.Lk(a, function(c) {
            return c.nodeType === Node.ELEMENT_NODE && b.getComputedStyle(c, null).position === "fixed"
        }, !0)
    };
    Ok = function(a) {
        for (var b = [], c = _.y(a.document.querySelectorAll("*")), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = a.getComputedStyle(d, null);
            e.position === "fixed" && e.display !== "none" && e.visibility !== "hidden" && b.push(d)
        }
        return b
    };
    Pk = function(a, b) {
        b = b.getBoundingClientRect();
        var c = b.left,
            d = b.bottom,
            e = b.right;
        return b.top >= 0 && c >= 0 && d <= a.innerHeight && e <= a.innerWidth
    };
    Qk = function(a) {
        return Math.round(Math.round(a / 10) * 10)
    };
    Rk = function(a) {
        return a.position + "-" + Qk(a.na) + "x" + Qk(a.sa) + "-" + Qk(a.scrollY + a.Ld) + "Y"
    };
    Sk = function(a) {
        return "f-" + Rk({
            position: a.position,
            Ld: a.Ld,
            scrollY: 0,
            na: a.na,
            sa: a.sa
        })
    };
    Tk = function(a, b) {
        a = Math.min(a != null ? a : Infinity, b != null ? b : Infinity);
        return a !== Infinity ? a : 0
    };
    Vk = function(a, b, c) {
        var d = _.Uk(c.ra).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.min(e.bottom + 10, c.sa),
                    g = Math.max(e.left - 10, 0),
                    h = Math.min(e.right + 10, c.na),
                    l = c.na * .3;
                for (e = Math.max(e.top - 10, 0); e <= f; e += 10) {
                    if (h > 0 && g < l) {
                        var k = Sk({
                            position: "left",
                            Ld: e,
                            na: c.na,
                            sa: c.sa
                        });
                        b.set(k, Tk(b.get(k), g))
                    }
                    if (g < c.na && h > c.na - l) {
                        k = Sk({
                            position: "right",
                            Ld: e,
                            na: c.na,
                            sa: c.sa
                        });
                        var m = c.na - h;
                        b.set(k, Tk(b.get(k), m))
                    }
                }
                d.add(a)
            }
        }
    };
    Yk = function(a, b) {
        var c = b.ra,
            d = b.fd,
            e = b.md,
            f = "f-" + Qk(b.na) + "x" + Qk(b.sa);
        a.has(f) || (a.set(f, 0), f = Ok(c), d || e ? (Wk(a, b, f.filter(function(g) {
            return Pk(c, g)
        })), Xk(c, f.filter(function(g) {
            return !Pk(c, g)
        }).concat(e ? _.w(Array, "from").call(Array, c.document.querySelectorAll("[google-side-rail-overlap=false]")) : []))) : Wk(a, b, f))
    };
    Wk = function(a, b, c) {
        var d = b.Wc,
            e = b.ra;
        _.Uk(e).sideRailProcessedFixedElements.clear();
        d = new _.z.Set([].concat(_.Zk(_.w(Array, "from").call(Array, e.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]"))), _.Zk(d)));
        c = _.y(c);
        for (e = c.next(); !e.done; e = c.next()) e = e.value, Mk(e, d) || Vk(e, a, b)
    };
    al = function(a) {
        if (a.na < 1200 || a.sa < 650) return null;
        var b = _.Uk(a.ra).sideRailAvailableSpace;
        a.wk || Yk(b, {
            ra: a.ra,
            na: a.na,
            sa: a.sa,
            Wc: a.Wc,
            fd: a.fd,
            md: a.md
        });
        for (var c = [], d = a.sa * .9, e = _.ek(a.ra), f = (a.sa - d) / 2, g = f, h = d / 7, l = 0; l < 8; l++) {
            var k = c,
                m = k.push;
            var n = g;
            var p = a.position,
                r = b,
                v = {
                    ra: a.ra,
                    na: a.na,
                    sa: a.sa,
                    Wc: a.Wc,
                    Kd: a.Kd
                },
                u = Sk({
                    position: p,
                    Ld: n,
                    na: v.na,
                    sa: v.sa
                }),
                x = Rk({
                    position: p,
                    Ld: n,
                    scrollY: e,
                    na: v.na,
                    sa: v.sa
                });
            if (!r.has(x)) {
                var D = p === "left" ? 20 : v.na - 20,
                    F = D;
                p = v.na * .3 / 5 * (p === "left" ? 1 : -1);
                for (var C = 0; C < 6; C++) {
                    var G = hk(v.ra.document, {
                            x: Math.round(F),
                            y: Math.round(n)
                        }),
                        S = Mk(G, v.Wc),
                        P = Nk(G, v.ra);
                    if (!S && P !== null) {
                        Vk(P, r, v);
                        r.delete(x);
                        break
                    }
                    S || (S = v, G.getAttribute("google-side-rail-overlap") === "true" ? S = !0 : G.getAttribute("google-side-rail-overlap") === "false" || S.Kd && !_.w($k, "includes").call($k, G.tagName.toLowerCase()) ? S = !1 : (P = G.offsetHeight >= S.sa * .25, S = G.offsetWidth >= S.na * .9 && P));
                    if (S) r.set(x, Math.round(Math.abs(F - D) + 20));
                    else if (F !== D) F -= p, p /= 2;
                    else {
                        r.set(x, 0);
                        break
                    }
                    F += p
                }
            }
            n = Tk(r.get(u), r.get(x));
            m.call(k, n);
            g += h
        }
        b = a.fl;
        e = a.position;
        d = Math.round(d / 8);
        f = Math.round(f);
        g = a.minWidth;
        a = a.minHeight;
        k = [];
        h = _.w(Array(c.length), "fill").call(Array(c.length), 0);
        for (l = 0; l < c.length; l++) {
            for (; k.length !== 0 && c[k[k.length - 1]] >= c[l];) k.pop();
            h[l] = k.length === 0 ? 0 : k[k.length - 1] + 1;
            k.push(l)
        }
        k = [];
        m = c.length - 1;
        l = _.w(Array(c.length), "fill").call(Array(c.length), 0);
        for (n = m; n >= 0; n--) {
            for (; k.length !== 0 && c[k[k.length - 1]] >= c[n];) k.pop();
            l[n] = k.length === 0 ? m : k[k.length - 1] - 1;
            k.push(n)
        }
        k = null;
        for (m = 0; m < c.length; m++)
            if (n = {
                    position: e,
                    width: Math.round(c[m]),
                    height: Math.round((l[m] - h[m] + 1) * d),
                    offsetY: f + h[m] * d
                }, r = n.width >= g && n.height >= a, b === 0 && r) {
                k = n;
                break
            } else b === 1 && r && (!k || n.width * n.height > k.width * k.height) && (k = n);
        return k
    };
    Xk = function(a, b) {
        var c = _.Uk(a);
        if (b.length && !c.g) {
            var d = new MutationObserver(function() {
                setTimeout(function() {
                    bl(a);
                    for (var f = _.y(c.sideRailMutationCallbacks), g = f.next(); !g.done; g = f.next()) g = g.value, g()
                }, 500)
            });
            b = _.y(b);
            for (var e = b.next(); !e.done; e = b.next()) d.observe(e.value, {
                attributes: !0
            });
            c.g = d
        }
    };
    bl = function(a) {
        a = _.Uk(a).sideRailAvailableSpace;
        var b = _.w(Array, "from").call(Array, _.w(a, "keys").call(a)).filter(function(d) {
            return _.w(d, "startsWith").call(d, "f-")
        });
        b = _.y(b);
        for (var c = b.next(); !c.done; c = b.next()) a.delete(c.value)
    };
    _.cl = function(a) {
        if (a.ma) return a.ma.Lb(1228, function() {
            return al(a)
        }) || null;
        try {
            return al(a)
        } catch (b) {}
        return null
    };
    el = function(a, b) {
        b = b === void 0 ? {} : b;
        var c = {};
        c = (c.frameborder = 0, c.allowTransparency = "true", c.style = "border:0;vertical-align:bottom;", c.src = "about:blank", c);
        Gg(c, b);
        dl(a, c)
    };
    fl = function(a, b, c, d, e) {
        b = b.styleSheets;
        if (!b) return !1;
        var f = a.matches || a.msMatchesSelector;
        d = d === -1 ? Infinity : d;
        e = e === -1 ? Infinity : e;
        for (var g = 0; g < Math.min(b.length, d); ++g) {
            var h = null;
            try {
                var l = b[g],
                    k = null;
                try {
                    k = l.cssRules || l.rules
                } catch (G) {
                    if (G.code == 15) throw G.styleSheet = l, G;
                }
                h = k
            } catch (G) {
                continue
            }
            k = void 0;
            if ((k = h) != null && k.length)
                for (k = 0; k < Math.min(h.length, e); ++k) try {
                    var m = h[k],
                        n, p = m,
                        r = c;
                    if (!(n = f.call(a, p.selectorText) && r(p))) a: {
                        var v = void 0;p = a;r = f;
                        var u = c,
                            x = e,
                            D = (v = m.cssRules) != null ? v : [];
                        for (v = 0; v < Math.min(D.length, x); v++) {
                            var F = D[v],
                                C = u;
                            if (r.call(p, F.selectorText) && C(F)) {
                                n = !0;
                                break a
                            }
                        }
                        n = !1
                    }
                    if (n) return !0
                } catch (G) {}
        }
        return !1
    };
    il = function(a, b, c, d) {
        var e = a.style;
        return (e == null ? 0 : e.height) && !_.w(gl, "includes").call(gl, e.height) || (e == null ? 0 : e.maxHeight) && !_.w(hl, "includes").call(hl, e.maxHeight) || fl(a, b.document, function(f) {
            var g = f.style.height;
            f = f.style.getPropertyValue("max-height");
            return !!g && !_.w(gl, "includes").call(gl, g) || !!f && !_.w(hl, "includes").call(hl, f)
        }, c, d) ? !1 : !0
    };
    kl = function(a, b, c) {
        if (!a) return !0;
        var d = !0;
        jl(a, function(e) {
            return d = il(e, b, 10, 10)
        }, c);
        return d
    };
    ll = function(a) {
        return typeof a === "number" || typeof a === "string"
    };
    ol = function(a, b) {
        a = ml.eo(a);
        return (b = nl(b)) ? pg(a, new _.z.Map([
            ["n", String(b)]
        ])) : a
    };
    rl = function(a, b, c, d) {
        c = c === void 0 ? null : c;
        d = d === void 0 ? {} : d;
        var e = pl.g();
        e.g === 0 && (e.g = Math.random() < .001 ? 2 : 1);
        e.g === 2 && (e = {}, Rh(_.w(Object, "assign").call(Object, {}, (e.c = String(a), e.pc = String(ql(window)), e.em = c, e.lid = b, e.eids = Ui().join(), e), d), "esp"))
    };
    sl = function() {
        var a = window;
        var b = b === void 0 ? function() {} : b;
        return new _.z.Promise(function(c) {
            var d = function() {
                c(b());
                _.Gh(a, "load", d)
            };
            _.sg(a, "load", d)
        })
    };
    tl = function(a) {
        var b = [],
            c = RegExp("^_GESPSK-(.+)$");
        try {
            for (var d = 0; d < a.length; d++) {
                var e = (c.exec(a.key(d)) || [])[1];
                e && b.push(e)
            }
        } catch (f) {}
        return b
    };
    zl = function(a, b) {
        return _.ul(a, vl, 2, _.wl()).some(function(c) {
            return xl(c, 1) === b && _.yl(c, 2)
        })
    };
    Gl = function(a, b, c, d) {
        if (b)
            for (var e = _.y(tl(b)), f = e.next(), g = {}; !f.done; g = {
                    ed: void 0
                }, f = e.next())
                if (g.ed = f.value, (f = Al().get(g.ed, b).vd) && !Bl(a, g.ed)) {
                    var h = Cl(f);
                    if (h !== 2 && h !== 3) {
                        h = !1;
                        if (c) {
                            var l = /^(\d+)$/.exec(g.ed);
                            if (l && !(h = _.w(c.split(","), "includes").call(c.split(","), l[1]))) continue;
                            if (!h && !c.split(",").some(function(m) {
                                    return function(n) {
                                        var p;
                                        return d == null ? void 0 : (p = d.get(n)) == null ? void 0 : p.has(m.ed)
                                    }
                                }(g))) continue
                        }
                        _.Dl(f, 9, h);
                        (h = xl(f, 2)) && h.length > 1024 && (l = {}, rl(55, g.ed, null, (l.sl = String(h.length), l)), _.vj(f.zb(El(108)), 2));
                        Fl(a, 2, vl, f);
                        f = xl(f, 2);
                        l = h = void 0;
                        var k = {};
                        rl(19, g.ed, null, (k.hs = f ? "1" : "0", k.sl = String((l = (h = f) == null ? void 0 : h.length) != null ? l : -1), k))
                    }
                }
    };
    Bl = function(a, b) {
        return _.ul(a, vl, 2, _.wl()).some(function(c) {
            return xl(c, 1) === b && _.yl(c, 2)
        })
    };
    Hl = function(a) {
        return typeof a === "string" ? a : a instanceof Error ? a.message : null
    };
    Ql = function(a, b, c, d, e, f) {
        var g, h, l, k, m, n, p, r, v, u, x, D, F;
        return _.ug(function(C) {
            return C.g == 1 ? (g = new L(a, 2), h = new Il(b, d, null, f), M(g, h), M(g, new Jl(h.A, e, null, f)), l = new Kl(h.j, f), M(g, l), k = new Ll(l.j, f), M(g, k), m = new Ml(c, k.j, f), M(g, m), M(g, new Jl(m.A, e, null, f)), n = new Nl(m.j, m.C, 1024, f), M(g, n), M(g, new Jl(n.j, e, null, f)), p = new Ol(f), M(g, p), r = new Pl(p.output, k.A, f), M(g, r), v = new Ml(c, r.j, f), M(g, v), u = new Jl(v.j, e, null, f), M(g, u), g.run(), F = b, C.yield(n.j.promise, 2)) : C.return({
                id: F,
                collectorGeneratedData: (D = (x = C.o) == null ? void 0 : xl(x, 2)) != null ? D : null
            })
        })
    };
    Zl = function(a, b, c, d, e) {
        var f = {
            Jg: ej(Rl),
            sj: _.K(Sl),
            Wg: ej(Tl)
        };
        f = f === void 0 ? Ul : f;
        Vl() !== Wl(window) ? rl(16, "") : Xl(b, "encryptedSignalProviders", d) && Xl(b, "secureSignalProviders", d) || (rl(38, ""), Yl(a, b, "encryptedSignalProviders", c, f, d, e), Yl(a, b, "secureSignalProviders", c, f, d, function() {}))
    };
    Xl = function(a, b, c) {
        if (a[b] === void 0 || a[b] instanceof Array) return !1;
        a[b].addErrorHandler(c);
        return !0
    };
    Yl = function(a, b, c, d, e, f, g) {
        var h;
        a = new $l(a, (h = b[c]) != null ? h : [], d, c === "secureSignalProviders", g, e);
        b[c] = new am(a);
        a.addErrorHandler(f)
    };
    dm = function(a, b, c) {
        a = new L(a, 1);
        var d = new Ol(c);
        b = new bm(d.output, b, c);
        cm(a, [d, b]);
        a.run()
    };
    hm = function(a, b, c, d, e, f) {
        var g = c.toString();
        if (em.has(g)) return null;
        em.add(g);
        a = new L(a, 5);
        b = new Il(b, d, null, f);
        d = new Jl(b.A, e, null, f);
        g = new fm(b.j, f);
        var h = new Kl(g.j, f);
        c = new gm(h.j, c, f);
        e = new Jl(c.j, e, null, f);
        cm(a, [b, d, g, h, c, e]);
        a.run();
        return a
    };
    mm = function(a) {
        for (var b = [], c = 0; c < 8; ++c) {
            var d = new im(7, "m202411060201", "https://pagead2.googlesyndication.com/pagead/ping", function(f) {
                    b.push({
                        url: f
                    })
                }),
                e = _.H(jm(km(new lm, a), c), 3, 5);
            d.il(e)
        }
        return b
    };
    pm = function(a) {
        var b, c, d;
        _.ug(function(e) {
            if (e.g == 1) return b = _.nm(), b.sharedStorage ? e.yield(b.sharedStorage.createWorklet(om.toString(), {
                dataOrigin: "script-origin"
            }), 2) : e.return();
            if (e.g != 3) return c = e.o, e.yield(c.selectURL("ps_caus", mm(a), {
                resolveToConfig: !0
            }), 3);
            if (d = e.o) {
                var f = b.document.body,
                    g = document.createElement("fencedframe");
                g.id = "ps_caff";
                g.name = "ps_caff";
                g.mode = "opaque-ads";
                g.config = d;
                _.uk(g, "border", "0");
                f.appendChild(g)
            }
            e.g = 0
        })
    };
    rm = function(a, b, c) {
        c = c === void 0 ? qm : c;
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), a.document.readyState === "complete" ? c(a, b) : _.sg(a, "load", function() {
            return void c(a, b)
        }))
    };
    sm = function(a) {
        try {
            var b, c;
            return ((c = (b = a.top) == null ? void 0 : b.frames) != null ? c : {}).google_ads_top_frame
        } catch (d) {}
        return null
    };
    tm = function(a) {
        var b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    };
    vm = function(a) {
        if (a === a.top || _.um(a.top)) return _.z.Promise.resolve({
            status: 4
        });
        var b = sm(a);
        if (!b) return _.z.Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && tm(a.document.referrer)) return _.z.Promise.resolve({
            status: 3
        });
        var c = new _.Aj;
        a = new MessageChannel;
        a.port1.onmessage = function(d) {
            d.data.msgType === "__goog_top_url_resp" && c.resolve({
                ac: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };
    zm = function(a, b) {
        var c = wm(a);
        return c.messageChannelSendRequestFn ? _.z.Promise.resolve(c.messageChannelSendRequestFn) : new _.z.Promise(function(d) {
            function e(l) {
                return h.g(l).then(function(k) {
                    return k.data
                })
            }
            var f = _.Fh("IFRAME");
            f.style.display = "none";
            f.name = "goog_topics_frame";
            b && (f.credentialless = !0);
            f.src = _.Aa(xm).toString();
            var g = (new URL(xm.toString())).origin,
                h = ym({
                    destination: a,
                    Fd: f,
                    origin: g,
                    Ob: "goog:gRpYw:doubleclick"
                });
            h.g("goog:topics:frame:handshake:ack").then(function(l) {
                l.data === "goog:topics:frame:handshake:ack" && d(e)
            });
            c.messageChannelSendRequestFn = e;
            a.document.documentElement.appendChild(f)
        })
    };
    Gm = function(a, b, c, d) {
        var e = {
            skipTopicsObservation: _.I(Am)
        };
        e = e === void 0 ? {} : e;
        var f = Bm(d),
            g = f.hf,
            h = f.gf;
        b = wm(b);
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e.skipTopicsObservation
        }).then(function(l) {
            var k = h;
            if (l instanceof Uint8Array) k || (k = !(g instanceof Uint8Array && pb(l, g)));
            else if (mc()(l)) k || (k = l !== g);
            else return c.ob(989, Error(JSON.stringify(l))), 7;
            if (k && d) try {
                var m = new Cm,
                    n = _.wk();
                var p = _.Dm(m, 2, n);
                l instanceof Uint8Array ? Ck(p, 1, Em, cc(l, !1)) : Ck(p, 3, Em, Wc(l));
                d.setItem("goog:cached:topics", Fm(p))
            } catch (r) {}
            return l
        }), b.getTopicsPromise = a);
        return g && !h ? _.z.Promise.resolve(g) : b.getTopicsPromise
    };
    Bm = function(a) {
        if (!a) return {
            hf: null,
            gf: !0
        };
        try {
            var b = a.getItem("goog:cached:topics");
            if (!b) return {
                hf: null,
                gf: !0
            };
            var c = Hm(b),
                d = _.Im(c, Em);
            switch (d) {
                case 0:
                    var e = null;
                    break;
                case 1:
                    e = Jm(Km(c, _.Lm(c, Em, 1)));
                    break;
                case 3:
                    e = _.Sh(c, _.Lm(c, Em, 3), 0);
                    break;
                default:
                    Sa(d)
            }
            var f = _.hi(c, 2) + 6048E5 < _.wk();
            return {
                hf: e,
                gf: f
            }
        } catch (g) {
            return {
                hf: null,
                gf: !0
            }
        }
    };
    wm = function(a) {
        var b;
        return (b = a.google_tag_topics_state) != null ? b : a.google_tag_topics_state = {}
    };
    Wm = function(a) {
        var b = "";
        Mm(function(c) {
            if (c === c.top) return !0;
            var d;
            if ((d = c.document) == null ? 0 : d.referrer) b = c.document.referrer;
            return !1
        }, !1, !1, a);
        return b
    };
    Ym = function() {
        var a = Date.now();
        return _.w(Number, "isFinite").call(Number, a) ? Math.round(a) : 0
    };
    an = function(a, b) {
        var c = new Zm;
        var d = Ym();
        c = _.Fk(c, 1, d);
        c = _.Fk(c, 2, a.pvsid);
        c = _.Ek(c, 3, a.Ra);
        d = Ui();
        c = _.Ve(c, 4, d, Yc);
        b = _.Fk(c, 5, b);
        a = _.Ek(b, 12, a.documentUrl);
        var e;
        if (b = (e = _.z.globalThis.performance) == null ? void 0 : e.memory) {
            e = new $m;
            try {
                _.Fk(e, 1, b.jsHeapSizeLimit)
            } catch (f) {}
            try {
                _.Fk(e, 2, b.totalJSHeapSize)
            } catch (f) {}
            try {
                _.Fk(e, 3, b.usedJSHeapSize)
            } catch (f) {}
        } else e = void 0;
        e && _.Wg(a, 10, e);
        return a
    };
    bn = function(a) {
        return {
            kd: 1E3,
            ud: a.Zb < .001,
            Ck: 1E4,
            ol: a.Zb < 1E-4
        }
    };
    gn = function(a) {
        var b = _.zk(),
            c = bn(a),
            d = c.ud,
            e = c.kd,
            f = c.ol,
            g = c.Ck;
        if (d) {
            c = a.va;
            var h = c.Fc,
                l = an(a, e),
                k = new cn;
            b = _.Fk(k, 2, b);
            k = new dn;
            d = _.$g(k, 1, d);
            e = _.Pg(d, 2, e);
            f = _.$g(e, 3, f);
            f = _.Pg(f, 4, g);
            f = _.$g(f, 5, a.Ai);
            a = _.Pg(f, 6, a.fh);
            a = _.Wg(b, 3, a);
            l = _.en(l, 6, fn, a);
            h.call(c, l)
        }
    };
    kn = function(a) {
        var b = bn(a),
            c = b.kd;
        if (!b.ud) return function() {};
        var d = Ym();
        a.va.Fc(hn(an(a, c)));
        return function() {
            var e = a.va,
                f = e.Fc,
                g = an(a, c);
            var h = new jn;
            var l = Ym() - d;
            h = _.Fk(h, 1, l);
            g = _.en(g, 14, fn, h);
            return void f.call(e, g)
        }
    };
    ln = function(a) {
        var b = a.split("/");
        return a.charAt(0) === "/" && b.length >= 2 ? b[1] : a.charAt(0) !== "/" && b.length >= 1 ? b[0] : ""
    };
    N = function(a, b, c) {
        var d = d === void 0 ? !1 : d;
        return function() {
            var e = _.Ia.apply(0, arguments),
                f = new _.mn(a);
            f.Te(d);
            f = f.Aa(b, c).apply(this, e);
            try {
                var g = e.length,
                    h = bn(a),
                    l = h.ol,
                    k = h.Ck;
                if (h.ud && l) {
                    var m = a.va,
                        n = m.Fc,
                        p = an(a, h.kd);
                    var r = _.Fk(p, 5, k);
                    var v = new nn;
                    var u = _.H(v, 1, b);
                    var x = _.Pg(u, 2, g);
                    var D = _.en(r, 9, fn, x);
                    n.call(m, D)
                }
            } catch (F) {}
            return f
        }
    };
    on = function(a, b, c) {
        a = new _.mn(a);
        a.Te(!1);
        return a.Aa(b, c)
    };
    pn = function(a, b, c, d) {
        a = new _.mn(a);
        a.Te(d === void 0 ? !1 : d);
        return a.Lb(b, c)
    };
    qn = function(a, b, c) {
        (new _.mn(a)).ob(b, c)
    };
    tn = function(a, b) {
        var c = rn.get(a);
        c || (b = c = b(), sn.set(b, a), rn.set(a, b));
        return c
    };
    O = function(a) {
        return function() {
            return new un(a, [].concat(_.Zk(_.Ia.apply(0, arguments))))
        }
    };
    vn = function(a) {
        return "[" + a.map(function(b) {
            return typeof b === "string" ? "'" + b + "'" : Array.isArray(b) ? vn(b) : String(b)
        }).join(", ") + "]"
    };
    wn = function(a, b) {
        b = vn(b);
        b = b.substring(1, b.length - 1);
        return new un(96, [a, b])
    };
    xn = function(a) {
        return (_.E = "rewardedSlotReady rewardedSlotGranted rewardedSlotClosed slotAdded slotRequested slotResponseReceived slotRenderEnded slotOnload slotVisibilityChanged impressionViewable gameManualInterstitialSlotReady gameManualInterstitialSlotClosed".split(" "), _.w(_.E, "includes")).call(_.E, a) ? a : null
    };
    zn = function(a, b, c) {
        return tn(c, function() {
            return new yn(a, b, c)
        })
    };
    Bn = function(a, b, c) {
        return tn(c, function() {
            return new An(a, b, c)
        })
    };
    Cn = function(a, b, c, d) {
        typeof a === "string" ? b.setClickUrl(a) : Q(d, wn("Slot.setClickUrl", [a]), c)
    };
    Jn = function(a, b, c, d, e) {
        if (typeof a !== "string" || Dn(a)) a === void 0 && b === void 0 || Q(e, wn("Slot.setTargeting", [a, b]), c);
        else {
            var f = [];
            Array.isArray(b) ? f = b : _.nb(b) ? f = _.w(Array, "from").call(Array, b) : b && (f = [b]);
            f = f.map(String);
            (b = (_.E = En(d), _.w(_.E, "find")).call(_.E, function(g) {
                return xl(g, 1) === a
            })) ? Fn(b, f): (b = Fn(Gn(new Hn, a), f), Fl(d, 9, Hn, b));
            e.info(In(a, f.join(), d.getAdUnitPath()), c)
        }
    };
    Kn = function(a, b, c, d) {
        if (a != null && typeof a === "object")
            for (var e = _.y(_.w(Object, "keys").call(Object, a)), f = e.next(); !f.done; f = e.next()) f = f.value, Jn(f, a[f], b, c, d);
        else d.error(wn("Slot.updateTargetingFromMap", [a]), b)
    };
    Mn = function(a, b, c, d) {
        return typeof a !== "string" ? (Q(d, wn("Slot.getTargeting", [a]), b), []) : (b = (_.E = En(c), _.w(_.E, "find")).call(_.E, function(e) {
            return xl(e, 1) === a
        })) ? Ln(b).slice() : []
    };
    Nn = function(a) {
        return En(a).map(function(b) {
            return _.t(b, 1)
        })
    };
    Sn = function(a, b, c, d) {
        if (a === void 0) _.vj(c, 9), d.info(On(b.getAdUnitPath()), b);
        else if (typeof a !== "string" || Dn(a)) Q(d, wn("Slot.clearTargeting", [a]), b);
        else {
            var e = En(c).slice(),
                f = _.w(e, "findIndex").call(e, function(g) {
                    return xl(g, 1) === a
                });
            f < 0 ? d.info(Pn(a, b.getAdUnitPath()), b) : (e.splice(f, 1), _.Qn(c, 9, e), d.info(Rn(a, b.getAdUnitPath()), b))
        }
    };
    _.Vn = function(a) {
        _.Ri(Tn).g = !0;
        return Un[a]
    };
    Zn = function(a, b, c) {
        var d, e;
        return (e = (d = _.w(a, "find").call(a, function(f) {
            f = _.Fi(f, Wn, 1);
            return Xn(f, 1) <= b && Xn(f, 2) <= c
        })) == null ? void 0 : _.ul(d, Wn, 2, _.wl(_.Yn))) != null ? e : null
    };
    ao = function(a, b, c) {
        return typeof b === "number" && typeof c === "number" && _.ul(a, $n, 6, _.wl()).length ? Zn(_.ul(a, $n, 6, _.wl()), b, c) : _.ul(a, Wn, 5, _.wl(_.Yn))
    };
    co = function(a) {
        var b = b === void 0 ? window : b;
        var c = null;
        b.top === b && (b = bo(!1, b), c = ao(a, b.width, b.height));
        c != null || (c = ao(a));
        return c == null ? [] : c.map(function(d) {
            return _.R(d, 3) ? "fluid" : [Xn(d, 1), Xn(d, 2)]
        })
    };
    eo = function(a) {
        var b = [],
            c = !1;
        a = _.y(co(a));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, Array.isArray(d) ? b.push(d.join("x")) : d === "fluid" ? c = !0 : b.push(d);
        c && b.unshift("320x50");
        return b.join("|")
    };
    fo = function(a) {
        return a !== 0 && a !== 1
    };
    go = function(a) {
        var b = a.document;
        return pi(a) ? b.URL : b.referrer
    };
    jo = function(a) {
        try {
            return ho(a, window.top)
        } catch (b) {
            return new _.io(-12245933, -12245933)
        }
    };
    no = function(a) {
        if (!a) return null;
        var b, c;
        a.getBoundingClientRect ? (a = _.ko(lo, a), a = new _.mo(a.right - a.left, a.bottom - a.top)) : a = null;
        return (c = (b = a) == null ? void 0 : b.floor()) != null ? c : null
    };
    ro = function(a, b, c) {
        for (var d = {}, e = _.w(Object, "keys").call(Object, b), f = _.y(e), g = f.next(); !g.done; g = f.next()) {
            g = g.value;
            var h = _.ve(b[g]),
                l = _.Ri(oo),
                k = l.g.get(g);
            k == null ? k = ++_.Ri(po).o : l.g.delete(g);
            _.vj(h, 20, _.ad(k));
            d[g] = h
        }
        a = {
            Z: _.ve(a),
            W: d
        };
        b = qo();
        d = {};
        e = _.y(e);
        for (f = e.next(); !f.done; f = e.next()) f = f.value, h = g = void 0, d[f] = _.w(Array, "from").call(Array, (h = (g = b.o[f]) == null ? void 0 : _.w(g, "values").call(g)) != null ? h : []);
        a.Bd = d;
        a.lc = c;
        return a
    };
    to = function() {
        for (var a = "", b = _.y(so()), c = b.next(); !c.done; c = b.next()) c = c.value, c <= 15 && (a += "0"), a += c.toString(16);
        return a
    };
    so = function() {
        var a;
        if (typeof((a = window.crypto) == null ? void 0 : a.getRandomValues) === "function") return a = new Uint8Array(16), window.crypto.getRandomValues(a), a;
        a = window;
        var b;
        if (typeof((b = a.msCrypto) == null ? void 0 : b.getRandomValues) === "function") return b = new Uint8Array(16), a.msCrypto.getRandomValues(b), b;
        a = Array(16);
        for (b = 0; b < a.length; b++) a[b] = Math.floor(Math.random() * 255);
        return a
    };
    Ao = function(a, b, c, d) {
        var e = uo(b, a) || vo(b, a);
        if (!e) return null;
        var f = jo(e),
            g = e === vo(b, a),
            h = wo(function() {
                var p = g ? vo(b, a) : e;
                return p && xo(p, window)
            }),
            l = function(p) {
                var r;
                return (r = h()) == null ? void 0 : r.getPropertyValue(p)
            };
        c = co(c)[0];
        var k = !1;
        Array.isArray(c) && (k = d ? g : f.x === 0 && l("text-align") === "center");
        k && (f.x += Math.round(Math.max(0, (g ? e.clientWidth : e.parentElement.clientWidth) - Number(c[0])) / 2));
        if (g) {
            var m;
            f.y += Math.round(Math.min((m = _.yo(l("padding-top"))) != null ? m : 0, e.clientHeight));
            if (!k) {
                d = e.clientWidth;
                var n;
                f.x += Math.round(Math.min((n = _.yo(l("padding-left"))) != null ? n : 0, d))
            }
        }
        return f && zo(e) ? f : new _.io(-12245933, -12245933)
    };
    Bo = function(a, b, c, d) {
        var e = vo(a, c),
            f = (e == null ? void 0 : e.style.display) === "none";
        f && (e.style.display = "block");
        a = Ao(c, a, b, d);
        f && (e.style.display = "none");
        return a
    };
    Co = function(a) {
        return "google_ads_iframe_" + a.toString()
    };
    Do = function(a) {
        return Co(a) + "__container__"
    };
    uo = function(a, b) {
        var c;
        return ((c = vo(a, b)) == null ? void 0 : c.querySelector('[id="' + Do(a) + '"]')) || null
    };
    Eo = function(a, b) {
        var c, d;
        return (d = (c = uo(a, b)) == null ? void 0 : c.querySelector('iframe[id="' + Co(a) + '"]')) != null ? d : null
    };
    vo = function(a, b) {
        b = b === void 0 ? document : b;
        return qo().l.get(a) || b.getElementById(a.getDomId())
    };
    Go = function(a, b, c) {
        return tn(c, function() {
            return new Fo(a, b, c, c.l)
        })
    };
    Ho = function(a) {
        return _.w(Object, "assign").call(Object, {}, a, _.w(Object, "fromEntries").call(Object, _.w(Object, "entries").call(Object, a).map(function(b) {
            var c = _.y(b);
            b = c.next().value;
            return [c.next().value, b]
        })))
    };
    Lo = function() {
        var a = {},
            b = Ho(Io);
        a.OutOfPageFormat = b;
        b = Ho(Jo);
        a.TrafficSource = b;
        b = Ho(Ko);
        a.Taxonomy = b;
        return a
    };
    Mo = function() {
        var a = {};
        return a.adsense_channel_ids = "channel", a.adsense_ad_types = "ad_type", a.adsense_ad_format = "format", a.adsense_background_color = "color_bg", a.adsense_border_color = "color_border", a.adsense_link_color = "color_link", a.adsense_text_color = "color_text", a.adsense_url_color = "color_url", a.page_url = "url", a.adsense_encoding = "oe", a.adsense_family_safe = "adsafe", a.adsense_flash_version = "flash", a.adsense_font_face = "f", a.adsense_hints = "hints", a.adsense_keyword_type = "kw_type", a.adsense_keywords = "kw", a.adsense_test_mode = "adtest", a.alternate_ad_iframe_color = "alt_color", a.alternate_ad_url = "alternate_ad_url", a.demographic_age = "cust_age", a.demographic_gender = "cust_gender", a.document_language = "hl", a.tag_origin = "to", a
    };
    Po = function(a, b, c, d, e) {
        if (typeof a === "string" && a.length && Mo()[a] !== void 0 && typeof b === "string") {
            var f = (_.E = c.Ya(), _.w(_.E, "find")).call(_.E, function(g) {
                return xl(g, 1) === a
            });
            f ? Fn(f, [b]) : (f = No(Gn(new Hn, a), b), Fl(c, 14, Hn, f));
            e.info(Oo(a, String(b), d))
        } else Q(e, wn("PubAdsService.set", [a, b]))
    };
    Qo = function(a, b, c) {
        return typeof a !== "string" ? (Q(c, wn("PubAdsService.get", [a])), null) : (b = (b = (_.E = b.Ya(), _.w(_.E, "find")).call(_.E, function(d) {
            return xl(d, 1) === a
        })) && Ln(b)) ? b[0] : null
    };
    Ro = function(a) {
        return a.Ya().map(function(b) {
            return _.t(b, 1)
        })
    };
    To = function() {
        for (var a = dj(So) || "0-0-0", b = a.split("-").map(function(e) {
                return Number(e)
            }), c = ["1", "0", "40"].map(function(e) {
                return Number(e)
            }), d = 0; d < b.length; d++) {
            if (b[d] > c[d]) return a;
            if (b[d] < c[d]) break
        }
        return "1-0-40"
    };
    Xo = function() {
        if (Uo) return Uo;
        for (var a = ej(Vo), b = [], c = 0; c < a.length; c += 2) Wo(a[c], a[c + 1], b);
        return Uo = b.join("&")
    };
    Yo = function(a) {
        for (var b = ej(Vo), c = new _.z.Map, d = 0; d < b.length; d += 2) c.set(b[d], b[d + 1]);
        return pg(a, c)
    };
    cp = function(a, b) {
        if (!b || !_.gb(b)) return null;
        var c = !1,
            d = new Zo;
        _.$o(b, function(e, f) {
            var g = !1;
            switch (f) {
                case "allowOverlayExpansion":
                    typeof e === "boolean" ? _.Dl(d, 1, b.allowOverlayExpansion) : c = g = !0;
                    break;
                case "allowPushExpansion":
                    typeof e === "boolean" ? _.Dl(d, 2, b.allowPushExpansion) : c = g = !0;
                    break;
                case "sandbox":
                    e === !0 ? _.Dl(d, 3, b.sandbox) : c = g = !0;
                    break;
                default:
                    g = !0
            }
            g && a.error(ap("setSafeFrameConfig", bp(b), f, bp(e)))
        });
        return c ? null : d
    };
    ep = function(a) {
        var b = new Zo;
        a = _.y(a);
        for (var c = a.next(); !c.done; c = a.next())
            if (c = c.value) {
                if (dp(c, 1)) {
                    var d = b,
                        e = _.R(c, 1);
                    _.Dl(d, 1, e)
                }
                dp(c, 2) && (d = b, e = _.R(c, 2), _.Dl(d, 2, e));
                dp(c, 3) && (d = b, c = _.R(c, 3), _.Dl(d, 3, c))
            }
        return b
    };
    fp = function(a, b) {
        var c = {};
        b = (c[0] = bj(b.pvsid), c);
        return _.Ri(Si).o(a, b)
    };
    hp = function(a, b) {
        var c;
        return (c = _.gp(a, "__gads", b)) == null ? void 0 : _.w(c.split(":"), "find").call(c.split(":"), function(d) {
            return d.indexOf("ID=") === 0
        })
    };
    ip = function(a, b, c, d) {
        (c = hp(c, d)) ? (d = {}, b = (d[0] = bj(b.pvsid), d[1] = bj(c), d), _.Ri(Si).o(a, b)) : fp(a, b)
    };
    np = function(a) {
        var b = a.key;
        var c = a.value;
        var d = a.settings;
        var e = a.serviceName;
        var f = a.qp;
        var g = a.Bb;
        var h = a.V;
        a = a.context;
        var l = null;
        typeof c === "string" ? l = [c] : Array.isArray(c) ? l = c : _.nb(c) && (l = _.w(Array, "from").call(Array, c));
        l = l && rb(l);
        var k, m = (k = l == null ? void 0 : l.every(function(n) {
            return typeof n === "string"
        })) != null ? k : !1;
        if (typeof b === "string" && !Dn(b) && m) {
            c = l;
            k = (_.E = jp(d), _.w(_.E, "find")).call(_.E, function(n) {
                return xl(n, 1) === b
            });
            if (b === "gpt-beta") {
                if (f) {
                    Q(h, kp(c.join()));
                    return
                }
                if (k) {
                    Q(h, lp(c.join()));
                    return
                }
                c = mp(c, g, a)
            }
            k ? Fn(k, c) : (f = Fn(Gn(new Hn, b), c), Fl(d, 2, Hn, f));
            h.info(In(b, c.join(), e))
        } else Q(h, wn("PubAdsService.setTargeting", [b, c]))
    };
    op = function(a, b, c) {
        return typeof a !== "string" ? (Q(c, wn("PubAdsService.getTargeting", [a])), []) : (b = (_.E = jp(b), _.w(_.E, "find")).call(_.E, function(d) {
            return xl(d, 1) === a
        })) ? Ln(b).slice() : []
    };
    pp = function(a) {
        return jp(a).map(function(b) {
            return _.t(b, 1)
        })
    };
    tp = function(a, b, c, d) {
        if (a === void 0) _.vj(b, 2), d.info(qp(c));
        else if (typeof a !== "string" || Dn(a)) Q(d, wn("PubAdsService.clearTargeting", [a]));
        else if (a === "gpt-beta") Q(d, rp(a));
        else {
            var e = jp(b).slice(),
                f = _.w(e, "findIndex").call(e, function(g) {
                    return xl(g, 1) === a
                });
            f < 0 ? d.info(Pn(a, c)) : (e.splice(f, 1), _.Qn(b, 2, e), d.info(sp(a, c)))
        }
    };
    mp = function(a, b, c) {
        var d = [];
        a = _.y(a);
        for (var e = a.next(); !e.done; e = a.next()) {
            e = e.value;
            b.g = e;
            var f = fp(9, c);
            f.length === 1 && (d.push(e), d.push(e + "-" + f[0]))
        }
        return d
    };
    vp = function() {
        var a, b, c;
        return ((c = up.exec((b = (a = _.Vn(172)) == null ? void 0 : a.src) != null ? b : "")) != null ? c : [])[1] === "pagead2.googlesyndication.com"
    };
    wp = function(a) {
        return a + 'Correlator has been deprecated. Please see the Google Ad Manager help page on "Pageviews in GPT" for more information: https://support.google.com/admanager/answer/183281?hl=en'
    };
    xp = function(a, b) {
        var c = b.g;
        return a.map(function(d) {
            return _.w(c, "find").call(c, function(e) {
                return e.Ba === d
            })
        }).filter(oc())
    };
    zp = function() {
        Object.defineProperty(window, "google_DisableInitialLoad", {
            get: function() {
                yp();
                return !0
            },
            set: function() {
                yp()
            },
            configurable: !0
        })
    };
    Cp = function(a, b, c, d, e, f) {
        var g = Ap(f, a, b, d, e, void 0, !0);
        f = g.slotId;
        g = g.settings;
        if (!f || !g) return Q(b, wn("PubAdsService.definePassback", [d, e])), null;
        _.Dl(g, 17, !0);
        c.slotAdded(f, g);
        return {
            Rk: Go(a, b, new Bp(a, f, c)),
            settings: g
        }
    };
    Ep = function(a, b, c, d, e) {
        return tn(c, function() {
            return new Dp(a, b, c, d, e)
        })
    };
    Fp = function(a, b, c, d, e) {
        typeof a !== "string" || typeof b !== "string" || Mo()[a] === void 0 ? Q(e, wn("Slot.set", [a, b]), c) : (c = (_.E = d.Ya(), _.w(_.E, "find")).call(_.E, function(f) {
            return xl(f, 1) === a
        })) ? Fn(c, [b]) : (b = No(Gn(new Hn, a), b), Fl(d, 3, Hn, b))
    };
    Gp = function(a, b, c, d) {
        return typeof a !== "string" ? (Q(d, wn("Slot.get", [a]), b), null) : (b = (b = (_.E = c.Ya(), _.w(_.E, "find")).call(_.E, function(e) {
            return xl(e, 1) === a
        })) && Ln(b)) ? b[0] : null
    };
    Hp = function(a) {
        return a.Ya().map(function(b) {
            return _.t(b, 1)
        })
    };
    Jp = function(a) {
        return Array.isArray(a) && a.length === 2 ? a.every(Ip) : a === "fluid"
    };
    Lp = function(a) {
        return Array.isArray(a) && a.length === 2 ? a.every(Kp) : a === "fluid"
    };
    Mp = function(a) {
        return Array.isArray(a) && a.length === 2 && Ip(a[0]) && Ip(a[1])
    };
    Op = function(a) {
        if (Array.isArray(a)) {
            var b = new Wn;
            a = _.vj(b, 1, _.ad(a[0])).setHeight(a[1])
        } else a = Np();
        return a
    };
    Pp = function(a) {
        var b = [];
        if (Lp(a)) b.push(Op(a));
        else if (Array.isArray(a)) {
            a = _.y(a);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, Lp(c) ? b.push(Op(c)) : pb(c, ["fluid"]) && b.push(Np())
        }
        return b
    };
    Qp = function(a) {
        var b = b === void 0 ? window : b;
        if (!a) return [];
        if (!a.length) {
            var c, d;
            (c = b.console) == null || (d = c.warn) == null || d.call(c, "Invalid GPT fixed size specification: " + JSON.stringify(a))
        }
        return Pp(a)
    };
    Rp = function(a) {
        if (!Array.isArray(a)) return "Size mapping must be an array";
        var b = [];
        a = _.y(a);
        for (var c = a.next(); !c.done; c = a.next()) {
            c = c.value;
            if (!Array.isArray(c) || c.length !== 2) return "Each mapping entry must be an array of size 2";
            if (!Mp(c[0])) return "Size must be an array of two non-negative integers";
            var d = _.y(c[0]),
                e = d.next().value;
            d = d.next().value;
            var f = new Wn;
            d = _.vj(f, 1, _.ad(e)).setHeight(d);
            if (Array.isArray(c[1]) && c[1].length === 0) f = [];
            else if (f = Pp(c[1]), f.length === 0) return "At least one slot size must be present";
            c = b;
            e = c.push;
            var g = new $n;
            d = _.Wg(g, 1, d);
            d = _.Qn(d, 2, f);
            e.call(c, d)
        }
        return b
    };
    Sp = function() {
        var a;
        return (a = _.ca.googletag) != null ? a : _.ca.googletag = {
            cmd: []
        }
    };
    Vp = function(a, b, c, d) {
        _.vj(a, 28);
        Tp(d) || (pc(d) ? _.w(Object, "hasOwn").call(Object, d, "enabled") && (d = d.enabled, Ac(d) ? (b = Up(d), _.Wg(a, 28, b)) : Q(b, wn("slot.setConfig.adExpansion.enabled", [d]), c)) : Q(b, wn("slot.setConfig.adExpansion", [d]), c))
    };
    fq = function(a, b, c, d) {
        if (Wp(a) !== 5) Q(b, Xp("interstitial"), c);
        else {
            b.info(Yp("interstitial", bp(d)), c);
            if (pc(d)) {
                var e = {};
                d = _.y(_.w(Object, "entries").call(Object, d));
                for (var f = d.next(); !f.done; f = d.next()) {
                    var g = _.y(f.value);
                    f = g.next().value;
                    g = g.next().value;
                    switch (f) {
                        case "triggers":
                            e.triggers = g;
                            break;
                        case "requireStorageAccess":
                            e.requireStorageAccess = g;
                            break;
                        default:
                            Q(b, Zp("interstitial", f), c)
                    }
                }
            } else Q(b, $p("googletag.slot.setConfig", "interstitial", bp(d)), c), e = null;
            d = new aq;
            f = {};
            if (e) {
                if (e.triggers)
                    if (g = e.triggers, pc(g)) {
                        f.triggers = {};
                        g = _.y(_.w(Object, "entries").call(Object, g));
                        for (var h = g.next(); !h.done; h = g.next()) {
                            var l = _.y(h.value);
                            h = l.next().value;
                            l = l.next().value;
                            var k = h;
                            h = l;
                            if (bq.has(k))
                                if (Ac(h)) switch (k) {
                                    case "unhideWindow":
                                        l = d;
                                        k = cq(2).setEnabled(h);
                                        Fl(l, 1, dq, k);
                                        f.triggers.Jr = h;
                                        break;
                                    case "navBar":
                                        l = d, k = cq(3).setEnabled(h), Fl(l, 1, dq, k), f.triggers.Ar = h
                                } else Q(b, $p("interstitial.triggers", k, bp(h)), c);
                                else Q(b, Zp("interstitial.triggers", k), c)
                        }
                    } else Q(b, $p("interstitial", "triggers", bp(g)), c);
                e.requireStorageAccess !== void 0 && (typeof e.requireStorageAccess === "boolean" ? (_.Dl(d, 2, e.requireStorageAccess), f.requireStorageAccess = e.requireStorageAccess) : Q(b, $p("interstitial", "requireStorageAccess", bp(e.requireStorageAccess)), c))
            }
            b.info(eq("interstitial", bp(f)), c);
            _.Wg(a, 29, d)
        }
    };
    iq = function(a, b, c, d) {
        if (_.I(gq) && (_.vj(a, 31), !Tp(d)))
            if (pc(d))
                if (Wp(a) !== 0) Q(b, Xp("outstream", String(Wp(a))), c);
                else {
                    a: {
                        var e = ["exposeVast"],
                            f = new _.z.Map;d = _.y(_.w(Object, "entries").call(Object, d));
                        for (var g = d.next(); !g.done; g = d.next()) {
                            var h = _.y(g.value);
                            g = h.next().value;
                            h = h.next().value;
                            _.w(e, "includes").call(e, g) ? f.set(g, h) : Q(b, Zp("outstream", g), c)
                        }
                        if (f.size === 0) b = null;
                        else {
                            e = new hq;
                            f = _.y(f);
                            for (d = f.next(); !d.done; d = f.next())
                                if (g = _.y(d.value), d = g.next().value, g = g.next().value, d === "exposeVast") {
                                    if (!Ac(g)) {
                                        Q(b, $p("outstream", "exposeVast", bp(g)), c);
                                        b = null;
                                        break a
                                    }
                                    _.Dl(e, 1, g)
                                }
                            b = e
                        }
                    }
                    b && _.Wg(a, 31, b)
                }
        else Q(b, $p("googletag.slot.setConfig", "outstream", bp(d)), c)
    };
    jq = function(a, b) {
        if (b !== void 0 && Array.isArray(b)) {
            b = _.y(b);
            for (var c = b.next(); !c.done; c = b.next()) {
                var d = c.value;
                c = d.configKey;
                d = d.auctionConfig;
                if (typeof c === "string" && !Dn(c)) {
                    var e = void 0,
                        f = void 0,
                        g = qo(),
                        h = a.getDomId();
                    d === null ? (f = g.o[h]) == null || f.delete(c) : d && ((e = g.o)[h] != null || (e[h] = new _.z.Map), g.o[h].set(c, d))
                }
            }
        }
    };
    lq = function(a, b, c, d, e) {
        if (pc(e)) {
            e = _.y(_.w(Object, "entries").call(Object, e));
            for (var f = e.next(), g = {}; !f.done; g = {
                    mf: void 0,
                    Kl: void 0
                }, f = e.next()) {
                var h = _.y(f.value);
                f = h.next().value;
                h = h.next().value;
                g.Kl = h;
                g.mf = kq[f];
                g.mf && N(a, g.mf.methodName, function(l) {
                    return function() {
                        l.mf.Cb(b, c, d, l.Kl)
                    }
                }(g))()
            }
        } else Q(c, wn("googletag.slot.setConfig", [e]), d)
    };
    nq = function(a, b, c) {
        return tn(c, function() {
            return new mq(a, b, c)
        })
    };
    wq = function(a) {
        var b, c = oq(pq(qq(rq(sq(new tq, a.pvsid), a.Ra), a.documentUrl), (b = a.Cg) != null ? b : _.wk()));
        a.payload && uq(c, a.payload());
        a.Ta && vq(c, a.Ta);
        return c
    };
    yq = function(a, b, c, d) {
        for (var e = _.y(_.w(Object, "entries").call(Object, xq)), f = e.next(); !f.done; f = e.next()) {
            var g = _.y(f.value);
            f = g.next().value;
            g = g.next().value;
            b & f && Q(a, g(String(c), d))
        }
    };
    Eq = function(a) {
        return wq(_.w(Object, "assign").call(Object, {}, a, {
            payload: function() {
                var b = new zq;
                var c = _.Aq(b, Bq, 1, Cq);
                c = _.Dq(c, 1, a.so);
                _.Dq(c, 2, a.Uo);
                return b
            }
        }))
    };
    Hq = function(a, b, c) {
        b = b === void 0 ? !1 : b;
        c = (c = c === void 0 ? null : c) ? wi(c) : null;
        c = _.I(Fq) ? null : c;
        var d = _.I(Gq);
        b = b === void 0 ? !0 : b;
        d = d === void 0 ? !1 : d;
        var e = 0;
        try {
            e |= Xj(a);
            var f;
            if (!(f = !a.navigator)) {
                var g = a.navigator;
                f = "brave" in g && "isBrave" in g.brave || !1
            }
            e |= f || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            e |= ak(a, d ? _.w(Number, "MAX_SAFE_INTEGER") : 2500);
            !b || c && nk(c) || (e |= 4194304)
        } catch (h) {
            e |= 32
        }
        return e
    };
    Iq = function(a) {
        switch (a) {
            case 4:
                return 11;
            case 2:
                return 2;
            case 3:
                return 1;
            case 5:
                return 8;
            case 6:
                return 42;
            case 7:
                return 10;
            case 8:
                return 3;
            case 9:
                return 4
        }
    };
    Rq = function(a, b, c, d) {
        d = d === void 0 ? !0 : d;
        a = Iq(a);
        if (!a) return null;
        if (a === 10) return 0;
        var e = 0;
        if (!(_.E = [11, 10], _.w(_.E, "includes")).call(_.E, a)) {
            e |= Xj(b);
            if (d) {
                var f = _.Uk(b);
                f = a !== 26 && a !== 27 && a !== 40 && a !== 41 && a !== 10 && f.adCount ? a == 1 || a == 2 ? !(!f.adCount[1] && !f.adCount[2]) : (f = f.adCount[a]) ? f >= 1 : !1 : !1;
                f && (e |= 64)
            }
            if (e) return e
        }
        if (a === 2 || a === 1) {
            c = {
                ra: b,
                Fk: _.I(Jq) ? _.w(Number, "MAX_SAFE_INTEGER") : Kq,
                Am: c ? a : void 0
            };
            (0, _.Lq)() === 0 && (c.Fk = _.I(Jq) ? _.w(Number, "MAX_SAFE_INTEGER") : 3E3, c.po = _.I(Mq) ? -1 : 650, c.Vp = _.I(Nq), c.Zp = _.K(Oq));
            var g = e;
            e = c.ra;
            f = c.po;
            var h = c.Fk;
            var l = c.Am;
            var k = c.Vp;
            var m = c.Zp;
            var n = c.M;
            c = 0;
            try {
                c |= Xj(e, m);
                var p = Math.min(e.screen.width || 0, e.screen.height || 0);
                c |= p ? p < 320 ? 8192 : 0 : 2048;
                c |= e.navigator && ik(e.navigator.userAgent) ? 1048576 : 0;
                if (f) {
                    p = c;
                    var r = e.innerHeight;
                    var v = _.ck(e) * r >= f ? 0 : 1024;
                    var u = p | v
                } else u = c | (_.Yj(e) ? 0 : 8);
                c = u;
                c |= ak(e, h, k)
            } catch (x) {
                c |= 32
            }
            switch (l) {
                case 2:
                    u = n;
                    u = u === void 0 ? null : u;
                    v = _.gk({
                        Ji: 0,
                        bh: e.innerWidth,
                        Xh: 3,
                        Ki: 0,
                        dh: Math.min(Math.round(e.innerWidth / 320 * 50), Pq) + 15,
                        Yh: 3
                    });
                    Qq(lk(e, u), v) != null && (c |= 16777216);
                    break;
                case 1:
                    u = n, u = u === void 0 ? null : u, v = e.innerWidth, r = e.innerHeight, p = Math.min(Math.round(e.innerWidth / 320 * 50), Pq) + 15, f = _.gk({
                        Ji: 0,
                        bh: v,
                        Xh: 3,
                        Ki: r - p,
                        dh: r,
                        Yh: 3
                    }), p > 25 && f.push({
                        x: v - 25,
                        y: r - 25
                    }), Qq(lk(e, u), f) != null && (c |= 16777216)
            }
            e = g | c
        } else a === 8 ? e |= Hq(b) : a === 3 || a === 4 ? (p = a, v = !0, r = !1, c = !0, p = p === void 0 ? null : p, v = v === void 0 ? !1 : v, r = r === void 0 ? !1 : r, c = c === void 0 ? !1 : c, u = Xj(b), ik((g = b.navigator) == null ? void 0 : g.userAgent) && (u |= 1048576), g = b.innerWidth, g < 1200 && (u |= 65536), f = b.innerHeight, f < 650 && (u |= 2097152), p && u === 0 && (p = p === 3 ? "left" : "right", (g = _.cl({
            ra: b,
            wk: !1,
            fl: 1,
            position: p,
            na: g,
            sa: f,
            Wc: new _.z.Set,
            minWidth: 120,
            minHeight: 500,
            fd: v,
            Kd: r,
            md: c
        })) ? _.Uk(b).sideRailPlasParam.set(p, g.width + "x" + g.height + "_" + String(p).charAt(0)) : u |= 16), e |= u) : a !== 11 && a !== 42 && (e |= 32);
        !e && d && (b = _.Uk(b), b.adCount = b.adCount || {}, b.adCount[a] = b.adCount[a] + 1 || 1);
        return e
    };
    Vq = function(a, b, c, d, e) {
        a = new L(a.S, 41);
        _.Sq(e, a);
        b = a.l(Tq, {
            adUnitPath: c != null ? c : void 0
        }, b, d);
        b = a.g(Uq, {
            data: b.output
        });
        a.run();
        return b.jb
    };
    Yq = function(a, b, c, d, e) {
        var f = e.Lj;
        var g = e.adUnitPath;
        e = e.Kb === void 0 ? !1 : e.Kb;
        return typeof g === "string" && g.length && (f == null || typeof f === "string" || typeof f === "number" && Wq(f)) ? Xq(a, b, g, c, d, {
            Qb: typeof f === "string" ? f : void 0,
            format: typeof f === "number" ? f : 1,
            Kb: e
        }) : (b.error(wn("googletag.defineOutOfPageSlot", [g, f])), null)
    };
    Wq = function(a) {
        switch (a) {
            case 6:
                return !0;
            case 7:
                return !0;
            default:
                return !!Zq(Io, function(b) {
                    return b === a
                })
        }
    };
    Xq = function(a, b, c, d, e, f) {
        var g = f.Qb;
        var h = f.format;
        f = d.add(a, b, c, [1, 1], {
            Qb: g,
            format: h,
            Kb: f.Kb
        });
        c = f.slotId;
        f = f.settings;
        c && f && (_.uj(f, 15, h), _.$q(c, function() {
            var l = window,
                k = Iq(h);
            if (k) {
                l = _.Uk(l);
                var m = l.adCount && l.adCount[k];
                m && (l.adCount[k] = m - 1)
            }
        }));
        c && e && h === 6 && (new ar(a, b, d, window, c, e)).run();
        return c != null ? c : null
    };
    dr = function(a, b) {
        try {
            return hc(a._b_), {
                data: br(a._b_.d)
            }
        } catch (c) {
            return b.ob(1299, c), {
                data: cr()
            }
        }
    };
    lr = function(a, b, c, d) {
        er(fr(c, d.applicableSections.filter(function(g) {
            return _.w(Number, "isInteger").call(Number, g)
        })), d.gppString);
        if (_.I(gr)) try {
            var e = hr(d.gppString, d.applicableSections, {
                idpcApplies: b,
                supportTcfeu: !0
            });
            ir(jr(_.Dl(c, 5, e.zp), e.vo), e.Dp)
        } catch (g) {
            qn(a, 1182, g), ir(jr(_.Dl(c, 5, !b), !1), !1)
        } else {
            try {
                var f = kr(d.gppString, d.applicableSections)
            } catch (g) {
                qn(a, 1182, g), f = !1
            }
            jr(c, f)
        }
    };
    nr = function(a, b) {
        b.tcString === "tcunavailable" ? a.info(mr("failed")) : a.info(mr("succeeded"))
    };
    pr = function(a, b) {
        return tn(b, function() {
            return new or(a, b)
        })
    };
    rr = function(a, b, c) {
        var d = on(a, 77, function() {
            var e = b.cmd;
            if (!e || Array.isArray(e)) {
                var f = new qr(c);
                b.cmd = pr(a, f);
                e != null && e.length && b.cmd.push.apply(f, e)
            }
        });
        b.fifWin && document.readyState !== "complete" ? _.sg(window, "load", function() {
            return window.setTimeout(d, 0)
        }) : d()
    };
    ur = function(a) {
        var b = window;
        _.ca.document.readyState === "complete" ? pn(a, 94, function() {
            Sp()._pubconsole_disable_ || sr(b) !== null && tr(a, b)
        }) : _.sg(_.ca, "load", on(a, 94, function() {
            Sp()._pubconsole_disable_ || sr(b) !== null && tr(a, b)
        }))
    };
    tr = function(a, b) {
        b = b === void 0 ? _.ca : b;
        if (!vr) {
            var c = _.Ri(cj).l(wr.g, wr.defaultValue);
            var d = new xr("gpt_pubconsole_loaded");
            yr(d, a);
            zr(d, "param", String(sr(b)));
            zr(d, "api", String(Ar));
            c && zr(d, "exp", c.join("~"));
            Br(d);
            c.length ? _.Cr(b.document, _.ng(Dr, c.join("~"))) : _.Cr(b.document, Er);
            vr = !0
        }
    };
    sr = function(a) {
        var b = go(a),
            c;
        return (c = (_.E = ["google_debug", "dfpdeb", "google_console", "google_force_console", "googfc"], _.w(_.E, "find")).call(_.E, function(d) {
            var e = b.search(Fr);
            b: {
                var f = 0;
                for (var g = d.length;
                    (f = b.indexOf(d, f)) >= 0 && f < e;) {
                    var h = b.charCodeAt(f - 1);
                    if (h == 38 || h == 63)
                        if (h = b.charCodeAt(f + g), !h || h == 61 || h == 38 || h == 35) break b;
                    f += g + 1
                }
                f = -1
            }
            if (f < 0) d = null;
            else {
                g = b.indexOf("&", f);
                if (g < 0 || g > e) g = e;
                f += d.length + 1;
                d = decodeURIComponent(b.slice(f, g !== -1 ? g : 0).replace(/\+/g, " "))
            }
            return d !== null
        })) != null ? c : null
    };
    Gr = function() {
        Sp()._pubconsole_disable_ = !0
    };
    Jr = function() {
        Hr && (Sp().console.openConsole(Ir), Ir = void 0, Hr = !1)
    };
    Sr = function() {
        var a = {};
        return a[576944485] = new Kr, a[578856259] = new Lr(function() {
            return _.K(Mr)
        }), a[607368714] = new Nr, a[629394304] = new Or, a[633226268] = new Pr, a[655300591] = new Qr, a[684553008] = new Rr, a
    };
    Tr = function(a) {
        switch (Number(a)) {
            case 0:
                return "";
            case 1:
                return "Out-of-page creative";
            case 2:
            case 3:
                return "Anchor";
            case 5:
                return "Interstitial";
            case 6:
                return "Shoppit";
            case 7:
                return "Game Manual Interstitial";
            case 4:
                return "Rewarded";
            case 8:
            case 9:
                return "Side Rail";
            default:
                return ""
        }
    };
    Wr = function(a) {
        var b, c, d;
        var e = new Ur;
        e = _.Fk(e, 1, a.pvsid);
        var f = Ui();
        e = _.Ve(e, 2, f, Yc);
        e = _.Ek(e, 3, a.documentUrl);
        e = _.Ek(e, 4, a.Ra);
        e = _.Fk(e, 5, 10);
        e = _.H(e, 6, a.jo);
        e = _.Ek(e, 7, a.mo);
        f = a.message.getMessageId();
        e = _.H(e, 8, f);
        f = a.message.getMessageArgs();
        e = _.Ve(e, 9, f, _.Bd);
        f = ln((d = (b = a.slotId) == null ? void 0 : b.getAdUnitPath()) != null ? d : "");
        b = _.Ek(e, 10, f);
        a = (c = a.slotId) == null ? void 0 : c.getAdUnitPath();
        c = _.Ek(b, 11, a);
        a = [].concat(_.Zk(_.w(Vr, "keys").call(Vr)));
        return _.Ve(c, 12, a, _.Bd)
    };
    Xr = function(a, b) {
        b = b === void 0 ? null : b;
        var c = [];
        a && (c.push(xl(a, 1)), c.push(eo(a)), c.push(xl(a, 2)));
        if (b) {
            a = [];
            for (var d = 0; b && d < 25; b = b.parentNode, ++d) b.nodeType === 9 ? a.push("") : a.push(b.id);
            (b = a.join()) && c.push(b)
        }
        return c.length ? _.aj(c.join(":")).toString() : "0"
    };
    Zr = function(a, b) {
        var c;
        return !((c = Yr(b, 22)) != null ? !c : !_.R(a, 15))
    };
    $r = function(a) {
        if (!_.um(a)) return -1;
        a = a.pageYOffset;
        return a < 0 ? -1 : a
    };
    as = function(a) {
        a = (_.um(a.top) ? a.top : a).AMP;
        return typeof a === "object" && !!Zq(a, function(b, c) {
            return !/^inabox/i.test(c)
        })
    };
    bs = function(a) {
        return Math.round(Number(_.yo(a)))
    };
    cs = function(a) {
        var b = a.parentElement;
        return !b || b.children.length <= 1 ? !1 : _.w(Array, "from").call(Array, b.children).some(function(c) {
            return c !== a && !(_.E = ["script", "style"], _.w(_.E, "includes")).call(_.E, c.tagName.toLowerCase())
        })
    };
    es = function(a, b, c) {
        for (var d = 100; a && a !== b && --d;) _.ds(a, c), a = a.parentElement
    };
    fs = function(a, b, c, d, e) {
        _.ds(a, {
            "margin-left": "0px",
            "margin-right": "0px"
        });
        var f = {},
            g = d.direction === "rtl",
            h = ((e && e.width !== -12245933 ? e.width : b.innerWidth) - c) / 2;
        d = function() {
            var l = a.getBoundingClientRect().left;
            return g ? h - l : l - h
        };
        b = d();
        return b !== 0 ? (c = function(l) {
            g ? f["margin-right"] = l + "px" : f["margin-left"] = l + "px"
        }, c(-b), _.ds(a, f), d = d(), d !== 0 && b !== d && (c(b / (d - b) * b), _.ds(a, f)), !0) : !1
    };
    hs = function(a, b, c, d, e, f, g, h, l, k) {
        window.setTimeout(function() {
            var m = eo(d);
            if (window.IntersectionObserver) {
                var n, p = (n = Eo(c, b)) != null ? n : vo(c, b);
                m = gs(a, b, c, e, f, g, m, h, l, k, p);
                (new window.IntersectionObserver(m, {
                    threshold: .98
                })).observe(p)
            }
        }, 500)
    };
    gs = function(a, b, c, d, e, f, g, h, l, k, m) {
        var n = window.location && window.location.hash === "#flexibleAdSlotTest" ? 1 : _.K(is);
        return on(a, 459, function(p, r) {
            (p = p == null ? void 0 : p[0]) && js(a, b, c, d, e, f, g, h, l, k, r, m, p, n)
        })
    };
    js = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r) {
        var v = p.boundingClientRect,
            u = p.intersectionRatio,
            x = window.innerWidth,
            D = v.left,
            F = v.right,
            C = D + 2 < 0,
            G = F - (x + 2) > 0;
        (u >= .98 || C || G) && ks(l, function(S) {
            m.unobserve(n);
            var P = C || G;
            var J = new qi;
            ls(n, P) && J.set(10);
            if (h !== void 0 && cs(n)) {
                var U, ha = (U = vo(c, b)) == null ? void 0 : U.parentElement,
                    ea;
                U = ha ? (ea = xo(ha, window)) == null ? void 0 : ea.width : void 0;
                h !== U && J.set(16)
            }
            P ? (J.set(8), P = si(J)) : P = ns(b, c, u, J);
            ea = ps(c, n, f);
            J = ea.Xn;
            ea = ea.bo;
            yr(S, a);
            zr(S, "qid", k);
            zr(S, "iu", c.getAdUnitPath());
            zr(S, "e", String(P));
            C && zr(S, "ofl", String(D));
            G && zr(S, "ofr", String(F - x));
            zr(S, "ret", e + "x" + f);
            zr(S, "req", g);
            zr(S, "bm", String(d));
            zr(S, "efh", Number(J));
            zr(S, "stk", Number(ea));
            zr(S, "ifi", qs(window))
        }, r)
    };
    ns = function(a, b, c, d) {
        var e = Eo(b, a) || vo(b, a);
        try {
            var f = e.getBoundingClientRect(),
                g = f.left,
                h = f.top,
                l = f.width,
                k = f.height,
                m = vo(b, a),
                n = xo(m, window);
            if (n.visibility === "hidden" || n.display === "none") return si(d);
            var p = bs(n.getPropertyValue("border-top-width") || 0) + 1;
            b = g + l;
            f = h + k;
            c = (1 - c) * k;
            var r = a.elementsFromPoint(g + p + 2, h + c + p);
            var v = a.elementsFromPoint(b - p - 2, h + c + p);
            var u = a.elementsFromPoint(b - p - 2, f - c - p);
            var x = a.elementsFromPoint(g + p + 2, f - c - p);
            var D = a.elementsFromPoint(b / 2, f - c - p)
        } catch (C) {
            return d.set(1), si(d)
        }
        if (!(r && r.length && v && v.length && u && u.length && x && x.length && D && D.length)) return d.set(7), si(d);
        a = function(C, G) {
            for (var S = !1, P = 0; P < C.length; P++) {
                var J = C[P];
                if (S) {
                    var U = xo(J, window);
                    if (U.visibility !== "hidden" && !rs(J) && !F(e, J)) {
                        d.set(G);
                        U.position === "absolute" && d.set(11);
                        break
                    }
                } else e === J && (S = !0)
            }
        };
        ss(e) && d.set(9);
        var F = function(C, G) {
            return ts(C, G) || ts(G, C)
        };
        g = r[0];
        e === g || F(e, g) || rs(g) || d.set(2);
        g = v[0];
        e === g || F(e, g) || rs(g) || d.set(3);
        g = u[0];
        e === g || F(e, g) || rs(g) || d.set(4);
        g = x[0];
        e === g || F(e, g) || rs(g) || d.set(5);
        if (rs(e)) return si(d);
        a(r, 12);
        a(v, 13);
        a(u, 14);
        a(x, 15);
        a(D, 6);
        return si(d)
    };
    ls = function(a, b) {
        var c = !1,
            d = !1;
        return vs(a, function(e, f) {
            d = d || e.overflowX === "scroll" || e.overflowX === "auto";
            c = c || e.display === "flex";
            return b && c && d || f.role === "listbox"
        })
    };
    ps = function(a, b, c) {
        var d = (a = vo(a)) && xo(a, window),
            e = d ? d.position !== "absolute" : !0,
            f = !1,
            g = a && a.parentElement,
            h = !1;
        jl(b, function(l) {
            var k = l.style;
            if (e)
                if (h || (h = l === g)) e = il(l, _.ca, -1, -1);
                else {
                    k = k && k.height;
                    var m = (k && _.w(k, "endsWith").call(k, "px") ? bs(k) : 0) >= c;
                    !k || m || typeof k === "string" && _.w(gl, "includes").call(gl, k) || (e = !1)
                }
            f || (l = xo(l, _.ca), l.position !== "sticky" && l.position !== "fixed") || (f = !0);
            return !(f && !e)
        }, 100);
        return {
            Xn: e,
            bo: f
        }
    };
    rs = function(a) {
        return vs(a, function(b) {
            return b.position === "fixed" || b.position === "sticky"
        })
    };
    ss = function(a) {
        return vs(a, function(b) {
            var c;
            return (_.E = ["left", "right"], _.w(_.E, "includes")).call(_.E, (c = b["float"]) != null ? c : b.cssFloat)
        })
    };
    ws = function(a) {
        a = co(a)[0];
        return Array.isArray(a) && a.every(function(b) {
            return typeof b === "number"
        }) ? new _.mo(a[0], a[1]) : null
    };
    xs = function(a, b, c, d) {
        var e = _.Fh("DIV");
        e.id = b;
        e.name = b;
        b = e.style;
        b.border = "0pt none";
        c && (b.margin = "auto", b.textAlign = "center");
        d && (c = Array.isArray(d), b.width = c ? d[0] + "px" : "100%", b.height = c ? d[1] + "px" : "0%");
        a.appendChild(e);
        return e
    };
    ys = function(a) {
        return (a == null ? void 0 : a.position) === "sticky" || (a == null ? void 0 : a.position) === "fixed"
    };
    Bs = function(a, b, c) {
        var d = new _.z.Map;
        a = _.y(a);
        for (var e = a.next(); !e.done; e = a.next()) {
            e = e.value;
            var f = b[e.getDomId()];
            f = _.zs(f, As, 28) ? _.Fi(f, As, 28) : _.Fi(c, As, 34);
            var g = void 0;
            d.set(e, ((g = f) == null ? 0 : dp(g, 1)) ? _.R(f, 1) ? 2 : 1 : 0)
        }
        return d
    };
    Es = function(a, b, c) {
        var d, e, f = [],
            g = [];
        a = _.y(a);
        for (d = a.next(); !d.done; d = a.next())
            if (d = d.value, b.get(d) === 1) f.push(null), g.push(null);
            else {
                var h = c,
                    l = vo(d);
                d = Cs((l == null ? void 0 : l.parentElement) && xo(l.parentElement, h) || null);
                if (!d || d[0] === 1 && d[3] === 1) {
                    var k = e = d = void 0,
                        m = (k = l == null ? void 0 : l.parentElement) != null ? k : null;
                    k = (e = no(m)) != null ? e : new _.mo(0, 0);
                    Ds(k, m, h, 100);
                    e = (d = no(l)) != null ? d : new _.mo(0, 0);
                    Ds(e, l, h, 1);
                    k.height === -1 && (e.height = -1);
                    d = k;
                    d = d.width + "x" + d.height;
                    e = e.width + "x" + e.height
                } else e = d = "-1x-1";
                f.push(d);
                g.push(e)
            }
        return {
            Eo: f,
            xp: g
        }
    };
    Ds = function(a, b, c, d) {
        try {
            var e;
            if (!(e = !b || !kl(b, c, d))) {
                a: {
                    do {
                        var f = xo(b, c);
                        if (f && f.position == "fixed") {
                            var g = !1;
                            break a
                        }
                    } while (b = b.parentElement);g = !0
                }
                e = !g
            }
            e && (a.height = -1)
        } catch (h) {
            a.width = -1, a.height = -1
        }
    };
    Fs = function(a, b, c) {
        var d = (0, _.Lq)() !== 0,
            e = bo(!0, c, d).width,
            f = [],
            g = [],
            h = [];
        if (c !== null && c != c.top) {
            var l = bo(!1, c).width;
            (e === -12245933 || l === -12245933 || l < e) && h.push(8)
        }
        e !== -12245933 && (e * 1.5 < c.document.documentElement.scrollWidth ? h.push(10) : d && c.outerWidth * 1.5 < e && h.push(10));
        a = _.y(a);
        for (d = a.next(); !d.done; d = a.next())
            if (l = d.value, b.get(l) === 1) f.push(null), g.push(null);
            else {
                d = new qi;
                var k = vo(l);
                l = 0;
                var m = !1,
                    n = !1,
                    p = !1;
                if (k) {
                    for (var r = 0, v = k; v && r < 100; r++, v = v.parentElement) {
                        var u = xo(v, c);
                        if (u) {
                            var x = u,
                                D = x.display,
                                F = x.overflowX;
                            if (x.overflowY !== "visible" && (d.set(2), (x = no(v)) && (l = l ? Math.min(l, x.width) : x.width), d.get(9))) break;
                            ys(u) && d.set(9);
                            D === "none" && d.set(7);
                            v.nodeName === "IFRAME" && (u = parseInt(u.width, 10), u < e && (d.set(8), l = l ? Math.min(u, l) : u));
                            n || (n = F === "scroll" || F === "auto");
                            m || (m = D === "flex");
                            p || (p = v.role === "listbox")
                        } else d.set(3)
                    }
                    if (!p) {
                        if (m = n && m) k = k.getBoundingClientRect().left, m = k > e || k < 0;
                        p = m
                    }
                    p && d.set(11)
                } else d.set(1);
                k = _.y(h);
                for (m = k.next(); !m.done; m = k.next()) d.set(m.value);
                f.push(si(d));
                g.push(l)
            }
        return {
            un: f,
            Bo: g
        }
    };
    Gs = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        var d = [];
        if (!a || c >= b.length) return d;
        for (; c < b.length;) {
            var e = b[c++];
            a = a[e];
            if (!a) return d;
            if (a instanceof Array) {
                e = _.y(a);
                for (var f = e.next(); !f.done; f = e.next()) d.push.apply(d, _.Zk(Gs(f.value, b, c)))
            }
        }
        d.push(a);
        return d
    };
    Hs = function(a) {
        throw Error(a);
    };
    Ns = function(a, b, c, d, e) {
        if (b != null && b.size) {
            var f, g;
            e = (g = (f = e == null ? void 0 : e.adUnits) != null ? f : a == null ? void 0 : a.adUnits) != null ? g : [];
            a = _.y(e);
            g = a.next();
            for (f = {}; !g.done; f = {
                    ni: void 0
                }, g = a.next()) {
                g = g.value;
                var h = e = void 0,
                    l = void 0;
                if ((e = g) != null && e.code && ((h = g) == null ? 0 : (l = h.bids) == null ? 0 : l.length) && (e = g.bids, g = Lj(g.code, b), f.ni = g / 1E6, !(g <= 0)))
                    for (e = _.y(e), l = e.next(), h = {}; !l.done; h = {
                            zc: void 0,
                            kk: void 0
                        }, l = e.next()) l = l.value, h.kk = typeof l.getFloor === "function" ? l.getFloor : void 0, h.zc = Js(Ks(Ls(new Ms, 4), g), c), l.getFloor = function(k, m) {
                        return function(n) {
                            _.Sh(k.zc, 1, 0) === 4 && Ls(k.zc, 1);
                            var p, r = (p = k.kk) == null ? void 0 : p.apply(this, [n]);
                            n = c ? r || {} : {
                                currency: "USD",
                                floor: m.ni
                            };
                            return r != null && r.floor ? (r == null ? 0 : r.currency) && r.currency !== "USD" ? (_.Sh(k.zc, 1, 0) === 1 && (n = Ks(Ls(k.zc, 6), r.floor * 1E6), _.tj(n, 3, r.currency)), r) : (r.floor || 0) > m.ni ? (_.Sh(k.zc, 1, 0) === 1 && Ks(Ls(k.zc, 5), r.floor * 1E6), r) : n : n
                        }
                    }(h, f), d.set(l.getFloor, h.zc)
            }
        }
    };
    Os = function(a, b) {
        var c = a.que,
            d = function() {
                var e;
                a == null || (e = a.requestBids) == null || e.before.call(b, function(f, g) {
                    return Sp().pbjs_hooks.push({
                        context: b,
                        nextFunction: f,
                        requestBidsConfig: g
                    })
                }, 0)
            };
        (c == null ? 0 : c.hasOwnProperty("push")) ? c == null || c.push(d): c == null || c.unshift(d)
    };
    Qs = function(a, b) {
        return tn(b, function() {
            return new Ps(a, b)
        })
    };
    Ss = function(a, b) {
        return _.ug(function(c) {
            return c.return(new _.z.Promise(function(d) {
                var e = _.Rs(function() {
                    a();
                    d()
                });
                setTimeout(e, b);
                var f, g;
                (g = (f = window).requestIdleCallback) == null || g.call(f, e)
            }))
        })
    };
    Ts = function(a, b) {
        for (var c = new qi, d = 0; d < a.length; d++) c.set(a.length - d - 1, b(a[d]));
        return si(c)
    };
    Vs = function(a, b) {
        return Us(a, b)
    };
    Us = function(a, b) {
        return a.map(function(c) {
            return b(c)
        })
    };
    Ys = function(a, b, c, d, e, f, g, h, l) {
        if (h) {
            var k = {
                    Hi: new Ws
                },
                m = new L(a.S, 15);
            a = new Xs(a, b, c, d, e, f, g, h, l, k);
            M(m, a);
            m.run();
            return {
                pm: k,
                Ib: m
            }
        }
    };
    at = function(a, b, c) {
        a = _.y(a);
        for (var d = a.next(); !d.done; d = a.next()) {
            d = d.value;
            var e = void 0;
            if ((e = d.args) != null && e.adUnits)
                for (e = void 0, d = _.y((e = d.args) == null ? void 0 : e.adUnits), e = d.next(); !e.done; e = d.next()) {
                    e = e.value;
                    var f = void 0,
                        g = void 0;
                    if (((f = e) == null ? void 0 : f.code) === b.getDomId() || ((g = e) == null ? void 0 : g.code) === b.getAdUnitPath()) {
                        var h = g = f = void 0;
                        if (e = (f = e) == null ? void 0 : (g = f.ortb2Imp) == null ? void 0 : (h = g.ext) == null ? void 0 : h.gpid) return Zs.set(b, e), _.$q(b, function() {
                            return void Zs.delete(b)
                        }), c.va.La.Ma.hb.li.Fn.wb({
                            xb: e.length
                        }), e.slice(0, _.K($s))
                    }
                }
        }
    };
    bt = function(a, b) {
        var c;
        return !((c = Yr(a, 11)) != null ? !c : !_.R(b, 10))
    };
    ct = function(a, b, c, d) {
        if (a = vo(a, b)) {
            var e;
            if (c = (e = Yr(c, 24)) != null ? e : _.R(d, 30)) c = a.getBoundingClientRect(), d = c.top, e = c.bottom, c.height === 0 ? c = !1 : (c = _.ca.innerHeight, c = 0 < e && e < c || 0 < d && d < c);
            c || (a.style.display = "none")
        }
    };
    dt = function(a) {
        for (var b = 0; a && b < 100; b++, a = a.parentElement) {
            var c = void 0;
            if (((c = xo(a, window)) == null ? void 0 : c.display) !== "none") return a
        }
        return null
    };
    et = function(a) {
        if (a.length <= 61440) return {
            url: a,
            tj: 0
        };
        var b = a;
        b.length > 61440 && (b = b.substring(0, 61432), b = b.replace(/%\w?$/, ""), b = b.replace(/&[^=]*=?$/, ""), b += "&trunc=1");
        return {
            url: b,
            tj: a.length - b.length + 8
        }
    };
    ft = function(a, b) {
        b = b === void 0 ? window : b;
        return b.location ? b.URLSearchParams ? (a = (new URLSearchParams(b.location.search)).get(a), (a == null ? 0 : a.length) ? a : null) : (a = (new RegExp("[?&]" + a + "=([^&]*)")).exec(b.location.search)) ? decodeURIComponent(a[1]) : null : null
    };
    gt = function(a, b) {
        b = b === void 0 ? window : b;
        return !!ft(a, b)
    };
    ht = function(a) {
        var b, c;
        return (c = (b = _.w(a, "find").call(a, function(d) {
            return xl(d, 1) === "page_url"
        })) == null ? void 0 : Ln(b)[0]) != null ? c : null
    };
    jt = function(a) {
        var b = a.indexOf("google_preview=", a.lastIndexOf("?")),
            c = a.indexOf("&", b);
        c === -1 && (c = a.length - 1, --b);
        return a.substring(0, b) + a.substring(c + 1, a.length)
    };
    kt = function(a) {
        var b;
        if ((b = a.location) == null ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        Mm(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    lt = function(a, b) {
        var c = b.Z;
        var d = b.W;
        return !!ht(c.Ya()) || a.some(function(e) {
            return ht(d[e.getDomId()].Ya()) !== null
        })
    };
    nt = function() {
        var a = a === void 0 ? window : a;
        mt = _.wk(a)
    };
    ot = function(a, b, c, d, e, f) {
        var g = void 0,
            h = on(a, c, f);
        _.sg(d, e, h) && (g = function() {
            return void _.Gh(d, e, h)
        }, _.$q(b, g));
        return g
    };
    pt = function(a, b, c, d, e) {
        return ot(a.context, a, b, c, d, e)
    };
    qt = function(a, b) {
        var c = _.Fh("DIV");
        c.id = a;
        c.textContent = b;
        _.ds(c, {
            height: "24px",
            "line-height": "24px",
            "text-align": "center",
            "vertical-align": "middle",
            color: "white",
            "background-color": "black",
            margin: "0",
            "font-family": "Roboto",
            "font-style": "normal",
            "font-weight": "500",
            "font-size": "11px",
            "letter-spacing": "0.08em"
        });
        return c
    };
    tt = function(a, b, c, d) {
        if (!(a = rt(b, a) > 0)) {
            a: {
                try {
                    a = top;
                    if (!a) {
                        var e = !0;
                        break a
                    }
                    var f = st(a.document, a).y,
                        g = f + c.height;
                    e = d.y >= f && d.y <= g;
                    break a
                } catch (h) {
                    e = !0;
                    break a
                }
                e = void 0
            }
            a = !e
        }
        return a
    };
    ut = function(a, b) {
        if (typeof IntersectionObserver !== "undefined") return new IntersectionObserver(b, {
            rootMargin: a + "%"
        })
    };
    wt = function(a, b, c, d, e) {
        return new _.z.Promise(function(f) {
            for (var g = new e(function(m, n) {
                    m.some(function(p) {
                        return p.intersectionRatio > 0
                    }) && (n.disconnect(), f())
                }, {
                    rootMargin: b + "%"
                }), h = _.y(a), l = h.next(), k = {}; !l.done; k = {
                    hg: void 0
                }, l = h.next()) {
                l = l.value;
                k.hg = vo(l);
                if (!k.hg) return;
                g.observe(k.hg);
                vt(c, l, function(m) {
                    return function() {
                        return void g.unobserve(m.hg)
                    }
                }(k))
            }
            _.$q(d, function() {
                return void g.disconnect()
            })
        })
    };
    Bt = function(a, b, c, d, e) {
        var f = f === void 0 ? _.z.globalThis.IntersectionObserver : f;
        if (!b) return {
            Ch: e
        };
        b = xt(b, 1) != null ? yt(b, 3) != null && (0, _.Lq)() !== 0 ? xt(b, 1) * yt(b, 3) : xt(b, 1) : null;
        if (b == null) return {
            Ch: e
        };
        a = new L(a.S, 24);
        c = a.l(zt, {}, d, c, b, a, f);
        e && At(c, e);
        a.run();
        return {
            Ch: c.complete,
            ho: a
        }
    };
    _.Dt = function(a) {
        if (a) {
            var b = _.Ct(a, 1);
            var c = c === void 0 ? 0 : c;
            a = gf(yt(a, 2), c);
            b = {
                maxHeight: b,
                lj: a
            }
        } else b = null;
        return b
    };
    Ot = function(a, b, c, d, e) {
        var f = window,
            g = new L(a.S, 27),
            h = new Et(b, Ft, g, function(m) {
                return Gt("i-adframe-load", m.detail.data)
            }),
            l = new Et(b, Ft, g, function(m) {
                return Gt("i-dismiss", m.detail.data)
            });
        h = _.K(Ht) > 0 ? M(g, new It(a, h.output, void 0)).output : h.output;
        h = M(g, new Jt(a, b, c, h));
        M(g, new Kt(a, f, d, e, h.output));
        if (f.top === f) var k = M(g, new Lt(a, f, h.output)).output;
        d = [l.output];
        k && d.push(k);
        k = new Mt(d, !0);
        M(g, new Nt(a, b, c, h.output, k));
        return g
    };
    Gt = function(a, b) {
        try {
            var c = JSON.parse(b);
            return c.googMsgType === "sth" && c.msg_type === a
        } catch (d) {}
        return !1
    };
    Pt = function(a, b) {
        a.O.log(576944485, wq, _.w(Object, "assign").call(Object, {}, a, b))
    };
    Qt = function(a) {
        return window.IntersectionObserver && new IntersectionObserver(a, {
            threshold: [.5]
        })
    };
    Rt = function(a) {
        return Math.max.apply(Math, _.Zk(a != null ? a : []))
    };
    St = function(a) {
        return (_.E = [4, 5, 7, 1], _.w(_.E, "includes")).call(_.E, Wp(a))
    };
    Ut = function(a, b, c) {
        _.ug(function(d) {
            a.O.log(629394304, function(e) {
                var f = new Tt;
                f = _.Fk(f, 1, a.pvsid);
                var g = Ui();
                f = _.Ve(f, 2, g, Yc);
                f = _.Ek(f, 3, a.documentUrl);
                g = _.wk() - c;
                f = _.Pg(f, 6, g);
                f = _.Ek(f, 8, b);
                f = _.Ek(f, 7, ln(b));
                return _.Fk(f, 5, e.Ta)
            }, {});
            d.g = 0
        })
    };
    Wt = function(a, b, c) {
        return new Vt(a, Ft, function(d) {
            d = d.detail.data;
            try {
                var e = JSON.parse(d);
                if (e.type === "rewarded" && e.message === b) return e
            } catch (f) {}
            return null
        }, c)
    };
    Yt = function(a, b, c) {
        a.O.log(576944485, Eq, _.w(Object, "assign").call(Object, {}, a, {
            Ta: _.K(Xt),
            so: b,
            Uo: Iq(c)
        }))
    };
    Zt = function(a) {
        return Array.isArray(a) ? a.every(function(b) {
            return function() {
                return b.hasOwn("id") && b.hasOwn("collectorFunction")
            }
        }) : !1
    };
    au = function(a) {
        for (var b = Array(36), c = 0, d, e = 0; e < 36; e++) e == 8 || e == 13 || e == 18 || e == 23 ? b[e] = "-" : e == 14 ? b[e] = "4" : (c <= 2 && (c = 33554432 + Math.random() * 16777216 | 0), d = c & 15, c >>= 4, b[e] = $t[e == 19 ? d & 3 | 8 : d]);
        a.postMessage(JSON.stringify({
            paw_id: b.join(""),
            gpa: 0
        }))
    };
    lu = function(a, b, c, d) {
        if (pc(a) && a !== null && _.w(Object, "keys").call(Object, a).some(function(k) {
                return bu.has(k) || (_.E = _.w(Object, "values").call(Object, cu), _.w(_.E, "includes")).call(_.E, Number(k))
            })) {
            d = _.w(Object, "keys").call(Object, a).some(function(k) {
                return bu.has(k)
            });
            for (var e = _.y(_.w(Object, "entries").call(Object, a)), f = e.next(); !f.done; f = e.next()) {
                var g = _.y(f.value);
                f = g.next().value;
                var h = g = g.next().value;
                g = null;
                if (d) bu.has(f) && (g = bu.get(f));
                else {
                    var l = Number(f);
                    du.has(l) && (g = du.get(l))
                }
                g === null ? eu("taxonomy", f, c, a) : h !== null && pc(h) && h.hasOwnProperty("values") ? Array.isArray(_.w(h, "values")) ? (h = fu(f, _.w(h, "values"), c, h), h.size && (h = [].concat(_.Zk(h)), gu(b, hu(iu(new ju, g), h)), c.info(ku(bp(h), bp(d ? f : Number(f)))))) : eu("taxonomyData.values", _.w(h, "values"), c, h) : eu("taxonomyData", h, c, a)
            }
        } else eu("taxonomies", a, c, d)
    };
    fu = function(a, b, c, d) {
        if (!xc()(b)) return eu("taxonomyData.values", b, c, d), new _.z.Set;
        d = new _.z.Set;
        var e = !1;
        b = _.y(b);
        for (var f = b.next(); !f.done; f = b.next()) {
            f = f.value;
            if (d.size >= 10) {
                e = !0;
                break
            }
            d.add(f)
        }
        e && (e = Number(a), Q(c, mu(bp(e ? e : a), bp(10))));
        return d
    };
    eu = function(a, b, c, d) {
        Q(c, ap("googletag.setConfig.pps", bp(d), a, bp(b)))
    };
    ou = function(a) {
        return nu.has(a)
    };
    su = function(a, b) {
        if (_.pu(b) === 3) {
            var c = {
                    Ge: new qu
                },
                d = new L(a.S, 31);
            M(d, new ru(a, b, c.Ge));
            d.run();
            return {
                Ib: d,
                Mo: c
            }
        }
    };
    uu = function(a, b, c, d, e, f, g) {
        if (b) {
            var h = {
                    pi: new Ws
                },
                l = new L(a.S, 32);
            M(l, new tu(a, b, c, d, h, e, f, g));
            l.run();
            return {
                Ib: l,
                Wf: h
            }
        }
    };
    wu = function(a) {
        vu = a
    };
    yu = function(a, b, c, d) {
        Zl(a.S, b, d, function(e, f) {
            qn(a, e, f);
            var g, h;
            (h = (g = window.console).error) == null || h.call(g, f)
        }, function() {
            return void c.info(xu())
        })
    };
    Au = function(a) {
        a = zu(a);
        return _.Qa(a)
    };
    zu = function(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a
    };
    Iu = function(a, b, c, d, e, f, g, h) {
        var l = window,
            k, m, n, p, r, v, u, x;
        _.ug(function(D) {
            k = new L(a.S, 40);
            m = k.g(Bu, {
                od: g
            }, window.location.hash);
            n = m.adUnitPath;
            p = m.Ec;
            r = Vq(a, l, n, null, k);
            v = k.g(Cu, {
                adUnitPath: n,
                Ec: p
            }, b, a, c, d, null);
            u = v.output;
            k.g(Du, {
                jb: r
            });
            x = new Eu(r, h, u, a, e, l, f);
            Fu(k, x);
            k.l(Gu, {
                adUnitPath: n,
                jb: r,
                Ec: p
            }, b, a, c, d);
            return D.yield(Hu(k), 0)
        })
    };
    lb = function(a, b) {
        a: {
            b = b[0];a = a[0];
            for (var c = _.jb, d = Math.min(b.length, a.length), e = 0; e < d; e++) {
                var f = c(b[e], a[e]);
                if (f != 0) {
                    b = f;
                    break a
                }
            }
            b = _.jb(b.length, a.length)
        }
        return b
    };
    Ju = function(a) {
        return Array.isArray(a) && a.length === 2 && typeof a[0] === "number" && _.w(a, "includes").call(a, 0)
    };
    Ku = function(a) {
        if (Ju(a)) return {
            size: [],
            vi: !0
        };
        if (Array.isArray(a) && a.length > 0 && typeof a[0] !== "number") {
            var b = !1;
            a = a.filter(function(c) {
                c = Ju(c);
                b = b || c;
                return !c
            });
            return {
                size: a,
                vi: b
            }
        }
        return {
            size: a,
            vi: !1
        }
    };
    Mu = function(a, b) {
        var c = b.W;
        return Vs(a, function(d) {
            return Lu(c[d.getDomId()]).join("&")
        })
    };
    Lu = function(a) {
        a = Nu(a);
        var b = [];
        _.$o(a, function(c, d) {
            c.length && (c = c.map(encodeURIComponent), d = encodeURIComponent(d), b.push(d + "=" + c.join()))
        });
        return b
    };
    Nu = function(a) {
        for (var b = {}, c = _.y(En(a)), d = c.next(); !d.done; d = c.next()) d = d.value, b[_.t(d, 1)] = Ln(d, _.Yn);
        a = _.Ou(a, 8, _.wl(_.Yn));
        a.length && (b.excl_cat != null || (b.excl_cat = a));
        return b
    };
    Pu = function(a) {
        var b = !1,
            c = jp(a).map(function(d) {
                var e = _.t(d, 1);
                b = e === "excl_cat";
                d = Ln(d);
                return encodeURIComponent(e) + "=" + encodeURIComponent(d.join())
            });
        a = _.Ou(a, 3, _.wl());
        !b && a.length && c.push(encodeURIComponent("excl_cat") + "=" + encodeURIComponent(a.join()));
        return c
    };
    Tu = function(a, b, c, d) {
        d === "adYield" && Q(b, Qu("adYield", "threadYield"));
        var e = _.Hk(a, Ru, 33);
        _.vj(e, 3);
        switch (c) {
            case null:
                break;
            case "ENABLED_ALL_SLOTS":
                a = _.Hk(a, Ru, 33);
                b = new Su;
                b = _.Dl(b, 2, !0);
                _.Wg(a, 3, b);
                break;
            case "DISABLED":
                a = _.Hk(a, Ru, 33);
                b = new Su;
                b = _.Dl(b, 1, !0);
                _.Wg(a, 3, b);
                break;
            default:
                Q(b, wn("googletag.setConfig." + d, [c]))
        }
    };
    Zu = function(a, b, c) {
        var d, e, f, g, h, l, k, m, n, p, r, v, u, x, D, F, C, G, S;
        return _.ug(function(P) {
            if (P.g == 1) {
                if (![Uu, Vu, Wu].some(_.I)) return P.return();
                d = 10;
                e = c.Zb < 1 / d ? c.va.La.Ma.hb.threadYield : void 0;
                g = (f = _.Fi(a.Z, Ru, 33)) == null ? void 0 : _.Fi(f, Su, 3);
                if ((h = g) == null ? 0 : _.R(h, 1)) return (l = e) == null || l.he.ta({
                    wa: d,
                    reason: 1
                }), P.return();
                k = window;
                if (k !== k.top) return (m = e) == null || m.he.ta({
                    wa: d,
                    reason: 2
                }), P.return();
                if (((n = g) == null || !_.R(n, 2)) && _.I(Xu) && (p = Yu, r = p(b, a, k), r >= 0 && r < 1)) return (v = e) == null || v.he.ta({
                    wa: d,
                    reason: 3
                }), P.return();
                u = _.wk(k);
                if (_.I(Uu) && ((D = k.scheduler) == null ? 0 : D.yield)) return x = 1, P.yield(k.scheduler.yield(), 3);
                if (_.I(Vu) && ((F = k.scheduler) == null ? 0 : F.postTask)) return x = 2, P.yield(new _.z.Promise(function(J) {
                    return void k.scheduler.postTask(J, {
                        priority: "user-blocking"
                    })
                }), 3);
                if (!_.I(Wu)) return (C = e) == null || C.he.ta({
                    wa: d,
                    reason: 4
                }), P.return();
                x = 3;
                return P.yield(new _.z.Promise(function(J) {
                    k.setTimeout(function() {
                        return void J()
                    }, 0)
                }), 3)
            }(G = e) == null || G.he.ta({
                wa: d,
                reason: 5
            });
            (S = e) == null || S.fo.wb({
                xb: _.wk(k) - u,
                sn: x
            });
            P.g = 0
        })
    };
    Yu = function(a, b, c) {
        var d = b.Z;
        if (_.pu(c.document) !== 1) return 1;
        b = b.W[a.getDomId()];
        a = Bo(a, b, c.document, Zr(d, b));
        if (_.I($u)) {
            if (c = av(a, c), c !== null) return c
        } else {
            b = bo(!0, c);
            d = b.height;
            b = b.width;
            if (!a || a.y === -12245933 || d === -12245933 || b === -12245933 || !d) return 0;
            b = 0;
            try {
                b = st(c.top.document, c.top).y
            } catch (e) {
                return 0
            }
            c = b + d;
            if (a.y < b) return b - a.y / d;
            if (a.y > c) return (a.y - c) / d
        }
        return 0
    };
    cv = function(a, b, c, d, e, f, g) {
        if (d) {
            var h = {
                    ng: new Ws,
                    og: new Ws,
                    We: new Ws
                },
                l = new L(a.S, 46);
            M(l, new bv(a, c, b, d, e, h, f, g));
            l.run();
            return {
                Ib: l,
                Ip: h
            }
        }
    };
    dv = function(a) {
        return "gads_privacy_sandbox_td_buyerlist__" + a
    };
    fv = function(a, b) {
        return a.filter(function(c) {
            return ev(c, 2) > b
        })
    };
    hv = function(a, b) {
        a = new _.z.Map(a.map(function(e) {
            return [_.t(e, 1), e]
        }));
        b = _.y(b);
        for (var c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            var d = a.get(_.t(c, 1));
            d ? gv(d, Math.max(ev(c, 2), ev(d, 2))) : a.set(_.t(c, 1), c)
        }
        return _.w(Array, "from").call(Array, _.w(a, "values").call(a))
    };
    lv = function(a, b, c, d, e) {
        if (iv(b, c, d, e)) return new _.z.Map;
        c = new _.z.Map(_.w(Object, "entries").call(Object, b).filter(function(l) {
            var k = _.y(l);
            l = k.next().value;
            k = k.next().value;
            return _.w(l, "startsWith").call(l, "gads_privacy_sandbox_td_buyerlist__") && k
        }).map(function(l) {
            var k = _.y(l);
            l = k.next().value;
            k = k.next().value;
            return [l, jv(k)]
        }));
        d = _.y(c);
        for (e = d.next(); !e.done; e = d.next()) {
            var f = _.y(e.value);
            e = f.next().value;
            f = f.next().value;
            var g = kv(f),
                h = fv(g, a);
            h.length === 0 ? (c.delete(e), b.removeItem(e)) : h.length < g.length && (_.Qn(f, 1, h), b.setItem(e, Fm(f)))
        }
        return c
    };
    mv = function(a, b, c) {
        return c ? String(_.aj(b + "-" + Fm(a))) : String(_.aj(b + "-" + _.t(a, 2) + _.t(a, 4) + ("" + _.R(a, 3))))
    };
    iv = function(a, b, c, d) {
        if (!_.R(b, 3) && !c) return !1;
        b = mv(b, d, c);
        if (a.getItem("gads_privacy_sandbox_tcf_hash") === b) return !1;
        c = _.y(_.w(Object, "keys").call(Object, a).filter(function(e) {
            return _.w(e, "startsWith").call(e, "gads_privacy_sandbox_td_buyerlist__")
        }));
        for (d = c.next(); !d.done; d = c.next()) a.removeItem(d.value);
        a.setItem("gads_privacy_sandbox_tcf_hash", b);
        return !0
    };
    nv = function(a) {
        return a !== null && _.w(Number, "isFinite").call(Number, a) && a >= 0
    };
    ov = function(a) {
        return (_.E = ["https://securepubads.g.doubleclick.net", "https://pubads.g.doubleclick.net"], _.w(_.E, "includes")).call(_.E, a)
    };
    pv = function(a) {
        var b;
        return (b = (new _.z.Map([
            ["https://googleads.g.doubleclick.net", BigInt(200)],
            ["https://td.doubleclick.net", BigInt(300)],
            ["https://f.creativecdn.com", BigInt(400)],
            ["https://fledge.us.criteo.com", BigInt(500)],
            ["https://fledge.eu.criteo.com", BigInt(600)],
            ["https://fledge.as.criteo.com", BigInt(700)],
            ["https://fledge-buyer-testing-1.uc.r.appspot.com", BigInt(800)],
            ["https://at-us-east.amazon-adsystem.com", BigInt(900)],
            ["https://x.adroll.com", BigInt(1E3)],
            ["https://fledge.dynalyst.jp", BigInt(1100)]
        ])).get(a)) != null ? b : BigInt(100)
    };
    rv = function(a, b, c, d, e) {
        if (b) {
            var f = b.nd,
                g = b.Yo;
            if (b.Pi && f === 4) {
                b = new Ws;
                f = new Ws;
                if (!g) return b.H({
                    kind: 1,
                    reason: 1
                }), f.H(!1), {
                    Dl: {
                        Xk: b,
                        jk: f
                    }
                };
                g = new L(a.S, 55);
                a = new qv(a, c, d, e, b, f);
                M(g, a);
                g.run();
                return {
                    Dl: {
                        Xk: b,
                        jk: f
                    },
                    Pp: g
                }
            }
        }
    };
    tv = function(a, b, c) {
        var d = "https://googleads.g.doubleclick.net/td/auctionwinner?status=nowinner",
            e = _.R(c, 18),
            f = _.R(c, 7);
        if (f || e) d += "&isContextualWinner=1";
        f && (d += "&hasXfpAds=1");
        e = c.getEscapedQemQueryId();
        f = _.t(c, 6);
        e && (d += "&winner_qid=" + encodeURIComponent(e));
        f && (d += "&xfpQid=" + encodeURIComponent(f));
        _.R(c, 4) && (d += "&is_plog=1");
        (e = _.t(c, 11)) && (d += "&ecrs=" + e);
        if (c == null ? 0 : _.t(c, 19)) d += "&cid=" + encodeURIComponent(_.t(c, 19));
        (c == null ? 0 : _.R(c, 21)) || (d += "&turtlexTest=1");
        d += "&applied_timeout_ms=" + b + ("&duration_ms=" + Math.round(a));
        sv(d)
    };
    xv = function(a) {
        var b = a.Sg,
            c = a.Nb,
            d = a.Bd === void 0 ? [] : a.Bd,
            e = a.interestGroupBuyers,
            f = a.En,
            g = a.mn,
            h = a.gm,
            l = a.ap,
            k = a.sellerTimeout,
            m = a.multiBidLimit;
        a = a.auctionNonce;
        var n = {};
        f !== void 0 && (n["https://googleads.g.doubleclick.net"] = f, n["https://td.doubleclick.net"] = f);
        if (g) {
            g = _.y(g);
            for (var p = g.next(); !p.done; p = g.next()) {
                var r = _.y(p.value);
                p = r.next().value;
                r = r.next().value;
                n[p] = r
            }
        }
        g = {};
        m && m > 1 && (g["*"] = m);
        e = {
            seller: "https://securepubads.g.doubleclick.net",
            decisionLogicUrl: "https://securepubads.g.doubleclick.net/td/sjs",
            trustedScoringSignalsUrl: "https://securepubads.g.doubleclick.net/td/sts",
            interestGroupBuyers: e != null ? e : ["https://googleads.g.doubleclick.net", "https://td.doubleclick.net"],
            sellerExperimentGroupId: f,
            auctionSignals: b.auctionSignals.promise,
            sellerSignals: b.g.promise,
            sellerTimeout: k,
            sellerCurrency: "USD",
            perBuyerCurrencies: b.perBuyerCurrencies.promise,
            perBuyerExperimentGroupIds: n,
            perBuyerSignals: b.perBuyerSignals.promise,
            perBuyerTimeouts: b.perBuyerTimeouts.promise,
            perBuyerCumulativeTimeouts: b.perBuyerCumulativeTimeouts.promise,
            perBuyerMultiBidLimits: g,
            reportingTimeout: 5E3
        };
        a && (e.auctionNonce = a, e.additionalBids = b.o.promise);
        e.deprecatedRenderURLReplacements = b.deprecatedRenderURLReplacements.promise;
        uv(e.interestGroupBuyers, h) && (e.auctionReportBuyerKeys = e.interestGroupBuyers.map(pv), e.auctionReportBuyers = vv(l), e.auctionReportBuyerDebugModeConfig = wv());
        e.directFromSellerSignalsHeaderAdSlot = b.directFromSellerSignalsHeaderAdSlot.promise;
        c = {
            seller: "https://securepubads.g.doubleclick.net",
            decisionLogicUrl: "https://securepubads.g.doubleclick.net/td/sjs",
            interestGroupBuyers: [],
            auctionSignals: {},
            sellerExperimentGroupId: f,
            sellerSignals: b.topLevelSellerSignals.promise,
            sellerTimeout: k,
            signal: c.signal,
            perBuyerExperimentGroupIds: {},
            perBuyerSignals: {},
            perBuyerTimeouts: {},
            perBuyerCumulativeTimeouts: {},
            componentAuctions: [e].concat(_.Zk(d)),
            resolveToConfig: b.resolveToConfig.promise
        };
        c.directFromSellerSignalsHeaderAdSlot = b.directFromSellerSignalsHeaderAdSlot.promise;
        return c
    };
    yv = function(a, b) {
        var c = b.Sg;
        c.topLevelSellerSignals.resolve(a.sellerSignals);
        c.directFromSellerSignals.resolve(a.directFromSellerSignals);
        c.directFromSellerSignalsHeaderAdSlot.resolve(a.directFromSellerSignalsHeaderAdSlot);
        c.resolveToConfig.resolve(!!a.resolveToConfig);
        var d;
        a = (d = a.componentAuctions) == null ? void 0 : _.w(d, "find").call(d, function(m) {
            return ov(m.seller)
        });
        var e;
        d = (e = a == null ? void 0 : a.perBuyerCumulativeTimeouts) != null ? e : {};
        b = _.y(b.interestGroupBuyers);
        for (e = b.next(); !e.done; e = b.next()) {
            e = e.value;
            var f = void 0,
                g = void 0;
            ((f = a) == null ? 0 : (g = f.interestGroupBuyers) == null ? 0 : _.w(g, "includes").call(g, e)) || (d[e] = 0)
        }
        c.o.resolve();
        if (a) {
            c.auctionSignals.resolve(a.auctionSignals);
            c.g.resolve(a.sellerSignals);
            c.perBuyerSignals.resolve(a.perBuyerSignals);
            var h;
            c.perBuyerTimeouts.resolve((h = a.perBuyerTimeouts) != null ? h : {});
            c.perBuyerCumulativeTimeouts.resolve(d);
            var l;
            c.perBuyerCurrencies.resolve((l = a.perBuyerCurrencies) != null ? l : {});
            var k;
            c.deprecatedRenderURLReplacements.resolve((k = a.deprecatedRenderURLReplacements) != null ? k : {})
        } else c.auctionSignals.resolve(void 0), c.g.resolve(void 0), c.perBuyerSignals.resolve({}), c.perBuyerTimeouts.resolve({}), c.perBuyerCumulativeTimeouts.resolve(d), c.perBuyerCurrencies.resolve({}), c.deprecatedRenderURLReplacements.resolve({})
    };
    uv = function(a, b) {
        return a.some(function(c) {
            return pv(c) !== BigInt(100)
        }) && (b != null ? b : !1)
    };
    vv = function(a) {
        var b = {
            interestGroupCount: {
                bucket: BigInt(0),
                scale: 1
            },
            bidCount: {
                bucket: BigInt(1),
                scale: 1
            }
        };
        a || (b.totalGenerateBidLatency = {
            bucket: BigInt(2),
            scale: 1
        }, b.totalSignalsFetchLatency = {
            bucket: BigInt(3),
            scale: 1
        });
        return b
    };
    wv = function() {
        var a = a === void 0 ? BigInt(0) : a;
        return {
            enabled: !0,
            debugKey: a
        }
    };
    Av = function(a, b) {
        if (!nv(b)) return [];
        var c = Math.round(b);
        return a.map(function(d) {
            var e = new zv;
            d = _.Ek(e, 1, d);
            return gv(d, c)
        })
    };
    Bv = function(a, b, c, d, e) {
        a.bc.H(e);
        a.Ka.H(c);
        a.Oa.H(d);
        b == null || b.H(!1)
    };
    Ev = function(a, b) {
        var c, d, e, f, g;
        return _.ug(function(h) {
            if (typeof a === "string" && !_.w(a, "startsWith").call(a, "urn:") || !Cv.deprecatedReplaceInURN) return h.return();
            c = {};
            c["${GDPR}"] = b.gdprApplies || "";
            c["${ADDTL_CONSENT}"] = b.im || "";
            c["${AD_WIDTH}"] = b.dm || "";
            c["${AD_HEIGHT}"] = b.bm || "";
            c["${RENDER_DATA}"] = b.bp || "";
            if (b.Og == null || _.R(b.Og, 4))
                for (d = 0; d <= 2E3; d++) c["${GDPR_CONSENT_" + String(d) + "}"] = b.jh || "";
            else {
                c["${GDPR_CONSENT_0}"] = b.jh || "";
                var l = Dv(b.Og, 3);
                e = _.y(l);
                for (f = e.next(); !f.done; f = e.next()) g = f.value, c["${GDPR_CONSENT_" + String(g) + "}"] = b.jh || ""
            }
            return h.yield(Cv.deprecatedReplaceInURN(a, c), 0)
        })
    };
    Fv = function(a) {
        return typeof FencedFrameConfig === "function" && a instanceof FencedFrameConfig
    };
    Jv = function(a) {
        var b = a.ie;
        var c = a.km;
        var d = a.To;
        var e = a.Hn;
        a = a.Ta;
        if (typeof c === "string" || Fv(c)) c = 4;
        else switch (c) {
            case null:
                c = 5;
                break;
            case 2:
                c = 1;
                break;
            case 3:
                c = 3;
                break;
            case 1:
                c = 2;
                break;
            case 4:
            case 0:
                c = 0;
                break;
            default:
                c = 0
        }
        var f = new Gv;
        c = _.H(f, 3, c);
        d = _.Ek(c, 2, d);
        b = _.Pg(d, 1, b);
        e !== void 0 && _.Ek(b, 4, e);
        e = new Hv;
        a !== void 0 && _.Pg(e, 1, a);
        _.en(e, 3, Iv, b);
        return e
    };
    Kv = function(a, b, c, d, e, f, g, h) {
        var l = b === 3,
            k = b === 2,
            m = b === 1,
            n = f.getEscapedQemQueryId(),
            p = _.t(f, 6);
        ks("run_ad_auction_stats", function(r) {
            yr(r, a);
            zr(r, "duration_ms", c);
            zr(r, "applied_timeout_ms", d);
            zr(r, "timed_out", k ? 1 : 0);
            zr(r, "error", l ? 1 : 0);
            zr(r, "auction_skipped", m ? 1 : 0);
            zr(r, "auction_winner", h ? 1 : 0);
            zr(r, "winner_qid", n != null ? n : "");
            zr(r, "xfpQid", p != null ? p : "");
            zr(r, "publisher_tag", "gpt");
            e && zr(r, "parallel", "1");
            g > 0 && zr(r, "nc", g)
        }, 1)
    };
    Lv = function(a, b, c, d, e) {
        var f = e.getEscapedQemQueryId(),
            g = _.t(e, 6);
        ks("run_ad_auction_complete", function(h) {
            yr(h, a);
            zr(h, "duration_ms", Math.round(d));
            zr(h, "applied_timeout_ms", c);
            zr(h, "auction_has_winner", b);
            f && zr(h, "winner_qid", f);
            g && zr(h, "xfpQid", g)
        }, 1)
    };
    Mv = function(a, b) {
        var c = b.getEscapedQemQueryId(),
            d = _.t(b, 6);
        ks("pre_run_ad_auction_ping", function(e) {
            yr(e, a);
            zr(e, "winner_qid", c != null ? c : "");
            zr(e, "xfpQid", d != null ? d : "");
            zr(e, "publisher_tag", "gpt")
        }, 1)
    };
    Sv = function(a, b, c, d) {
        var e = vo(a, document);
        e && fk(e, window, d, !0);
        Nv(_.Ri(po), "5", Ov(c.W[a.getDomId()], 20));
        a.dispatchEvent(Pv, 801, {
            Cj: null,
            isBackfill: !1
        });
        if (_.Qv(b, a) && !Eo(a, document)) {
            b = c.Z;
            c = c.W[a.getDomId()];
            var f;
            ((f = Yr(c, 10)) != null ? f : _.R(b, 11)) && ct(a, document, c, b)
        }
        a.dispatchEvent(Rv, 825, {
            isEmpty: !0
        })
    };
    Tv = function(a) {
        var b = new _.z.Set;
        a = _.y(_.w(a, "values").call(a));
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, _.R(c, 2) && kv(c).forEach(function(d) {
            b.add(_.t(d, 1))
        });
        return b.size > 0 ? _.w(Array, "from").call(Array, b) : null
    };
    Vv = function(a, b, c, d, e, f, g, h, l, k) {
        if (b) {
            var m = b.nd;
            if (b.Pi && m !== 0) return b = new L(a.S, 54), a = new Uv(a, m, c, d, e, f, g, h, l, k), M(b, a), b.run(), {
                Op: a.j,
                Np: b
            }
        }
    };
    Xv = function(a, b, c, d, e) {
        if (pc(e)) {
            e = _.y(_.w(Object, "entries").call(Object, e));
            for (var f = e.next(), g = {}; !f.done; g = {
                    nf: void 0,
                    Ll: void 0
                }, f = e.next()) {
                var h = _.y(f.value);
                f = h.next().value;
                h = h.next().value;
                g.Ll = h;
                g.nf = Wv[f];
                g.nf && N(a, g.nf.methodName, function(l) {
                    return function() {
                        l.nf.Cb(b, c, l.Ll, d)
                    }
                }(g))()
            }
        } else Q(c, wn("googletag.setConfig", [e]))
    };
    Yv = function() {
        for (var a = _.y(_.w(Array, "from").call(Array, document.getElementsByTagName("script"))), b = a.next(); !b.done; b = a.next()) {
            var c = b = b.value,
                d = b.src;
            !d || d.indexOf("/tag/js/gpt.js") == -1 && d.indexOf("/tag/js/gpt_mobile.js") == -1 || c.googletag_executed || !b.textContent || (c.googletag_executed = !0, c = document.createElement("script"), b = Ua(b.textContent), c.textContent = Va(b), Wa(c), document.head.appendChild(c), document.head.removeChild(c))
        }
    };
    Zv = function(a, b) {
        b = _.y(_.w(Object, "entries").call(Object, b));
        for (var c = b.next(); !c.done; c = b.next()) {
            var d = _.y(c.value);
            c = d.next().value;
            d = d.next().value;
            a.hasOwnProperty(c) || (a[c] = d)
        }
    };
    bw = function(a, b, c) {
        var d = [];
        c = [].concat(_.Zk(c.T)).slice();
        if (b) {
            if (!Array.isArray(b)) return Q(a, wn("googletag.destroySlots", [b])), !1;
            ib(b);
            d = c.filter(function(e) {
                return _.w(b, "includes").call(b, e.Ba)
            })
        } else d = c;
        if (!d.length) return !1;
        $v(d);
        aw(d);
        return !0
    };
    kw = function(a, b, c, d, e, f, g, h, l, k, m) {
        var n = Sp(),
            p, r, v = N(a, 74, function(x, D, F) {
                return e.defineSlot(a, b, x, D, F)
            }),
            u = {};
        v = (u._loaded_ = !0, u.cmd = [], u._vars_ = n._vars_, u.evalScripts = function() {
            try {
                Yv()
            } catch (F) {
                qn(a, 297, F);
                var x, D;
                (x = window.console) == null || (D = x.error) == null || D.call(x, F)
            }
        }, u.display = N(a, 95, function(x) {
            cw(c, x, e)
        }), u.defineOutOfPageSlot = N(a, 73, function(x, D) {
            return (x = Yq(a, b, e, k, {
                Lj: D,
                adUnitPath: x
            })) ? x.Ba : null
        }), u.getVersion = N(a, 946, function() {
            return a.Df
        }), u.pubads = N(a, 947, function() {
            return Ep(a, b, c, e, h)
        }), u.companionAds = N(a, 816, function() {
            p != null || (p = new dw(a, b, c, f));
            return zn(a, b, p)
        }), u.content = N(a, 817, function() {
            r != null || (r = new ew(a, b, g));
            return Bn(a, b, r)
        }), u.setAdIframeTitle = N(a, 729, wu), u.getEventLog = N(a, 945, function() {
            return new fw(a, b)
        }), u.sizeMapping = N(a, 90, function() {
            return new gw(a, b)
        }), u.enableServices = N(a, 91, function() {
            for (var x = _.y(hw), D = x.next(); !D.done; D = x.next()) D = D.value, D.isEnabled() && b.info(iw()), D.enable()
        }), u.destroySlots = N(a, 75, function(x) {
            return bw(b, x, e)
        }), u.enums = Lo(), u.defineSlot = v, u.defineUnit = v, u.getWindowsThatCanCommunicateWithHostpageLibrary = N(a, 955, function(x) {
            return jw(l, x).map(function(D) {
                var F;
                return (F = Eo(D, document)) == null ? void 0 : F.contentWindow
            }).filter(function(D) {
                return !!D
            })
        }), u.disablePublisherConsole = N(a, 93, Gr), u.onPubConsoleJsLoad = N(a, 731, Jr), u.openConsole = N(a, 732, function(x) {
            Ar = !0;
            var D;
            ((D = Sp()) == null ? 0 : D.console) ? Sp().console.openConsole(x): (x && (Ir = x), Hr = !0, tr(a))
        }), u.setConfig = N(a, 1034, function(x) {
            return void Xv(a, d, b, n, x)
        }), u.apiReady = !0, u);
        yu(a, n, b, m);
        Zv(n, v)
    };
    Tw = function(a, b, c, d, e, f, g, h) {
        var l = window,
            k = qo(),
            m = new L(a.S, 58),
            n = m.g(lw, {}, l).wl;
        var p = new L(a.S, 30);
        var r = new mw(a, l);
        M(p, r);
        p.run();
        p = {
            Jo: r.A,
            Jc: r.Jc,
            Sd: r.Sd
        };
        if (_.ta()) {
            r = new L(a.S, 34);
            var v = new nw(a, window);
            M(r, v);
            r.run();
            r = {
                Qo: v.output
            }
        } else r = void 0;
        var u = _.I(ow);
        v = l.navigator;
        var x = Xi(l.isSecureContext, l.navigator, l.document);
        u = !u && x;
        x = _.K(pw);
        var D = !!v.getInterestGroupAdAuctionData;
        v = _.I(qw) && !!v.createAuctionNonce;
        v = {
            Pi: u,
            nd: x,
            Yo: D,
            aj: v
        };
        if (!_.I(rw)) {
            var F;
            u = new sw(a, document, Sp(), b, k, c, (F = window.location.hash) != null ? F : "", null);
            M(m, u)
        }
        if (e) {
            var C = new L(a.S, 59);
            F = new tw(a, e);
            M(C, F);
            F = uw(vw(C.g(ww, {
                config: F.j
            }), _.K(xw)), F.j);
            C.run();
            C = {
                nm: F.eb,
                Un: F.Bc,
                jn: F.Xc,
                nn: F.le,
                uf: F.ke,
                Me: F.sd,
                Hr: F.Ci,
                Ui: F.Ti,
                eh: F.je,
                Oi: F.Ni,
                Tf: F.od,
                Br: C
            };
            _.I(rw) || M(m, new yw(a, Sp(), null, b, k, c, C.Me, null));
            b = m.g(zw, {
                So: C.Me
            }).dd;
            F = new Aw(a, C.jn);
            M(m, F);
            g = Fu(m, new Bw(a, window, C.Un, g)).Gd;
            u = C.nm;
            x = {
                hc: new Ws,
                Nc: new Ws,
                Mc: new Ws,
                Lc: new Ws,
                xd: new Ws,
                pd: new Ws,
                Uf: new Ws,
                Vf: new Ws,
                Bg: new Ws
            };
            D = new L(a.S, 14);
            M(D, new Cw(a, f, u, window, x));
            D.run();
            f = {
                om: x,
                Ib: D
            };
            C = _.w(Object, "assign").call(Object, {}, C, {
                dd: b,
                Ng: F.output,
                Gd: g,
                Fb: f == null ? void 0 : f.om
            })
        }
        var G;
        f = Fu(m, new Dw(a, window, e, (G = C) == null ? void 0 : G.Gd)).A;
        G = new Ew(a, f);
        M(m, G);
        e = new Fw(a, f);
        M(m, e);
        c = Fu(m, new Gw(a, c, d, window, f, h)).Rc;
        if (_.I(Hw)) {
            d = new Iw(a, window.navigator, c);
            var S = d.j;
            M(m, d)
        }
        d = void 0;
        C && (h = new Jw(a, window, c, C.nn), d = h.output, M(m, h));
        if (C) {
            h = C.uf;
            _.I(Kw) || vp() ? h = void 0 : (f = {
                Vh: new Ws,
                Sb: new Ws
            }, g = new L(a.S, 35), M(g, new Lw(a, h, c, f)), g.run(), h = {
                dg: f,
                Ib: g
            });
            if (h) var P = h.dg;
            m.g(Mw, {}, {
                B: window,
                context: a
            })
        }
        h = window;
        f = !Yi(h.isSecureContext, h.document);
        Zi(h.isSecureContext, h, h.document) || !f ? (f = new L(a.S, 45), a = new Nw(a, h, n, c), M(f, a), f.run(), a = a.j) : a = void 0;
        var J;
        C && (J = {
            Fb: C.Fb,
            dg: P,
            yo: C.Gd,
            Ng: C.Ng,
            dd: C.dd,
            uf: C.uf,
            Af: G.Af,
            yn: e.j,
            Ui: C.Ui,
            Yj: d,
            eh: C.eh,
            Oi: C.Oi,
            Tf: C.Tf,
            Me: C.Me
        });
        P = _.K(Ow);
        d = dj(Pw);
        var U;
        P !== 0 && d && ((U = C) == null ? 0 : U.Fb) && m.g(Qw, {
            pbjs: C.Fb.hc
        }, P === 2, k.g, d);
        var ha;
        _.I(Rw) && (ha = new Sw(l));
        m.run();
        return {
            Io: p,
            Ro: r,
            Rg: n,
            Mp: v,
            xj: {
                Id: new _.z.Set
            },
            pg: a,
            Lm: S,
            Pb: J,
            Rc: c,
            qo: ha
        }
    };
    Vw = function(a) {
        var b = a.toString().toLowerCase();
        if (!(b.indexOf("<!doctype") > -1 || b.indexOf("<html") > -1)) {
            b = _.Qa("<!DOCTYPE html>");
            var c = Ua(Uw.join(""));
            c = Va(c).toString();
            c = _.Qa("<script>" + (c + "\x3c/script>"));
            a = dg([b, lg("html", {}, [lg("head", {}, c), lg("body", {}, a)])])
        }
        return a
    };
    Ww = function(a) {
        var b = {
            threshold: [0, .3, .5, .75, 1]
        };
        return window.IntersectionObserver && new IntersectionObserver(a, b)
    };
    Xw = function(a) {
        a = co(a)[0];
        return Array.isArray(a) && a.every(function(b) {
            return typeof b === "number"
        }) ? new _.mo(a[0], a[1]) : null
    };
    Wx = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u, x, D, F, C) {
        var G = new L(a.S, 62),
            S = bo(!0, window),
            P = l.Z,
            J = l.W[e.getDomId()],
            U = F.Rg,
            ha = F.xj.Id,
            ea = F.pg,
            Ba = new Yw(a, window);
        M(G, Ba);
        var ja = m.height,
            ma = m.width,
            ra = m.Zc,
            ia = m.lb,
            Oa = m.Yd,
            fb = m.isBackfill,
            Ub = m.Xb,
            Uc = m.Bn,
            vc = m.gb,
            Ad = m.tc,
            Zd = m.Ri,
            $d = m.yh,
            Ne = m.oc,
            Nm = m.Ef,
            Om = m.ac,
            Pm = m.ya,
            Oe = m.fa,
            fj = m.sd,
            gj = m.Gm,
            hj = m.Eg,
            nh = new Ws;
        nh.H(p);
        var ig = new Zw(a, window.top, nh);
        M(G, ig);
        var Qm = new $w(a, Wp(J), S.height, vc, ja);
        M(G, Qm);
        var Rm = new ax(a, e, vo(e, n), e.getDomId(), Do(e), n.documentElement, Wp(J), h, f);
        Fu(G, Rm);
        var Nc = Rm.output,
            bD = new bx(a, Pm, Oa, fb, Ub);
        M(G, bD);
        var Sm = new cx(a, window.location.hash, S, e.getAdUnitPath(), J, f, Qm.output, Ad, ma, ja, bD.output, Nc);
        Fu(G, Sm);
        var dD = Sm.A,
            fD = Fu(G, new dx(a, window, window.location.hash, vc, Sm.A.Ka, Sm.A.Oa)).A,
            gD = fD.Ka,
            hD = fD.Oa,
            Tm = G.g(ex, {
                Wn: dD.Vn
            }, P, J, Oa, Ub).output;
        var SS = ig.output;
        if (Xi(window.isSecureContext, window.navigator, window.document) && !_.I(ow) && g) {
            var iD = {
                    bg: new qu,
                    Ka: new Ws,
                    Oa: new Ws,
                    Hd: new Ws
                },
                ms = new L(a.S, 52);
            M(ms, new fx(a, e, SS, J, h, p, f, gD, hD, Nc, r, l, D, ia, Oe, iD, v, C));
            ms.run();
            var jD = {
                Ib: ms,
                Qp: iD
            }
        } else jD = void 0;
        var os = jD;
        if (os) {
            _.Sq(G, os.Ib);
            var Um = os.Qp
        }
        var kD, lD, mD = (lD = (kD = Um) == null ? void 0 : kD.Ka) != null ? lD : gD,
            nD, oD, jj = (oD = (nD = Um) == null ? void 0 : nD.Oa) != null ? oD : hD,
            pD, kj = (pD = Um) == null ? void 0 : pD.bg,
            qD, TS = (qD = Um) == null ? void 0 : qD.Hd;
        if (_.I(gx)) var jg = G.g(hx, {
            Da: Nc,
            Xb: Tm
        }, e, Wp(J), n, h, P, J, l.lc, G).rb;
        else {
            var rD = new ix(a, e, P, J, Wp(J), n, h, Nc, Tm, kj, l.lc);
            M(G, rD);
            jg = rD.output
        }
        var WS = Fu(G, new jx(a, e, h, P, J, d, S, jg, kj)).A,
            uD = new kx(a, window, S, e, J, Nc, jg, ra, jj, dD.tm, ia);
        Fu(G, uD);
        var vD = new lx(a, P, J, Zd, mD, Tm);
        M(G, vD);
        var wD = new mx(a, window, Om, Ba.output, kj);
        M(G, wD);
        var xD = new nx(a, Wp(J), n);
        M(G, xD);
        var Vm = G.l(ox, {}, x, Wp(J), vc, Uc).output,
            YS = new px(a, $d, TS, nh, kj);
        M(G, YS);
        var ZS = window;
        if (_.I(Am) && ea) {
            var us = new L(a.S, 50);
            M(us, new qx(a, ZS, hj, ea));
            us.run();
            var yD = us
        } else yD = void 0;
        var zD = yD;
        zD && _.Sq(G, zD);
        var aT = G.l(rx, {}, {
                context: a,
                K: l,
                slotId: e
            }).complete,
            kc = new sx(a, e, h, d, l, u, k, ra, ia, fb, Ne, Oe, window, mD, Tm, WS, Nc, jg, jj, vD.output, uD.bg, wD.output, xD.output, Vm, U, kj, aT);
        M(G, kc);
        var bT = new tx(a, window, e, kc.j, nh);
        M(G, bT);
        var AD = Wp(J);
        switch (AD) {
            case 2:
            case 3:
                _.I(ux) ? M(G, new vx(a, h, Wp(J), e, window, vc, kc.Fa, Nc, Vm, jj, ig.output)) : M(G, new wx(a, h, Wp(J), e, window, vc, kc.Fa, Nc, Vm, jj, ig.output));
                break;
            case 5:
                M(G, new xx(a, e, l.aq, Uc, n, kc.Fa, Nc, ig.output, Vm, D));
                break;
            case 4:
                var CD = new yx(a, e, u, window, kc.Fa, Nc);
                _.Sq(G, CD);
                CD.run();
                break;
            case 7:
                Fu(G, Ot(a, e, u, kc.Fa, Nc));
                break;
            case 8:
            case 9:
                var cT = new zx(a, window, AD, x, kc.Fa, jg, jj);
                Fu(G, cT)
        }
        var dT = new Ax(a, e, kc.Fa, n, u);
        M(G, dT);
        var Xm = new Bx(a, e, Cx(h, e), window.top);
        M(G, Xm);
        if (_.I(Dx)) {
            var FD = new Ex(a, u, n, kc.Fa, e);
            Fu(G, FD);
            var GD = FD.output
        } else {
            var fT = kc.Fa,
                lj = new L(a.S, 61),
                gT = new Et(e, Fx, lj),
                HD = M(lj, new Gx(a, n, fT, gT.output));
            M(lj, new Hx(a, HD.output, u, e));
            lj.run();
            var hT = HD.output;
            _.Sq(G, lj);
            GD = hT
        }
        if (_.K(Ix) > 0) {
            var iT = kc.Fa,
                jT = GD,
                kT = Xm.output;
            if (!(Wp(J) !== 0 || _.I(Jx) && (_.R(P, 11) || _.R(J, 10)))) {
                var nj = new L(a.S, 68),
                    ID = nj.l(Kx, {
                        Kc: iT
                    }, G),
                    nT = At(ID, jT).output;
                _.I(Lx) && At(ID, kT);
                var qT = At(nj.g(Mx, {}, a, e, Sp()), nT).finished,
                    sT = At(nj.l(Nx, {}, e), qT).output;
                At(nj.g(Ox, {}, a), sT);
                nj.run()
            }
        }
        var uT = new Px(a, Cx(h, e), window.top, kc.Fa, Ba.output, Xm.output, Xm.j);
        M(G, uT);
        _.I(Qx) && G.g(Rx, {
            Fa: kc.Fa
        }, window, e, l, d);
        M(G, new Sx(a, e, ra, Oa, kc.Fa, jg, kc.A));
        var xT = new Tx(a, window, Nm, kc.Fa, jg, Nc);
        M(G, xT);
        for (var JD = _.y(gj), Is = JD.next(); !Is.done; Is = JD.next()) {
            var yT = Is.value;
            Fu(G, new Ux(a, n, Sp(), P, c, b, d, ha, yT, null))
        }
        var LD = new Ws;
        LD.H(fj);
        M(G, new yw(a, Sp(), P, b, c, d, LD, null));
        G.g(Vx, {}, a, J, ja, ma);
        return G
    };
    Yx = function(a, b, c) {
        var d = null;
        try {
            var e = st(b.top.document, b.top).y;
            d = a.map(function(f) {
                var g = c.Z,
                    h = c.W[f.getDomId()];
                g = Zr(g, h);
                var l;
                f = (l = Bo(f, h, b.document, g)) == null ? void 0 : l.y;
                l = bo(!0, b).height;
                return f === void 0 || f === -12245933 || l === -12245933 ? -1 : f < e + l ? 0 : ++Xx
            })
        } catch (f) {}
        return d
    };
    dy = function(a) {
        return pn(a.la.context, 1132, function() {
            if (a.ja.T.length) {
                var b = new _.z.Set(ej(Zx));
                var c = a.la.ba;
                c = _.I($x) && _.R(c, 8) ? "loc gpic cookie ms ppid top etu uule video_doc_id".split(" ") : [];
                c = _.y(c);
                for (var d = c.next(); !d.done; d = c.next()) b.add(d.value);
                c = new _.z.Map;
                d = _.y(ay);
                for (var e = d.next(); !e.done; e = d.next()) e = e.value, e(a, c);
                d = a.la.ba;
                var f, g;
                e = (g = (f = by(a.ja.K.Z)) == null ? void 0 : _.R(f, 9)) != null ? g : !1;
                f = _.I($x) && _.R(d, 8);
                f = "https://" + (e || f || !vi(d) ? "pagead2.googlesyndication.com" : "securepubads.g.doubleclick.net") + "/gampad/ads?";
                g = _.y(c);
                for (c = g.next(); !c.done; c = g.next())
                    if (d = _.y(c.value), c = d.next().value, e = d.next().value, d = e.value, e = e.options === void 0 ? {} : e.options, (new RegExp("[?&]" + c + "=")).test(f), !b.has(c) && d != null) {
                        var h = e.Ia === void 0 ? !1 : e.Ia;
                        if (d = typeof d !== "object" ? d == null || !h && d === 0 ? null : encodeURIComponent(d) : Array.isArray(d) && d.length ? cy(d, e) : null) f[f.length - 1] !== "?" && (f += "&"), f += c + "=" + d
                    }
                b = f
            } else b = "";
            return b
        })
    };
    cy = function(a, b) {
        var c = b.Pa === void 0 ? "," : b.Pa,
            d = b.ge === void 0 ? "" : b.ge,
            e = b.Ia === void 0 ? !1 : b.Ia,
            f = !1;
        a = a.map(function(g) {
            f || (f = !!g);
            return String(g === 0 && e ? g : g || d)
        });
        return f || e ? encodeURIComponent(a.join(c)) : null
    };
    ey = function(a) {
        var b = a;
        return function() {
            var c = _.Ia.apply(0, arguments);
            if (b) {
                var d = b;
                b = null;
                d.apply(null, _.Zk(c))
            }
        }
    };
    hy = function(a, b) {
        var c = 0,
            d = null,
            e = 0,
            f = 0;
        return function() {
            var g, h, l, k, m, n, p, r;
            return _.ug(function(v) {
                if (v.g == 1) return g = _.w(_.z.Promise, "withResolvers").call(_.z.Promise), h = g.promise, l = g.resolve, k = ey(l), m = ++f, v.yield(0, 2);
                if (f !== m) return k(!1), v.return(h);
                (n = d) == null || n(!1);
                p = ey(function() {
                    c = (new Date).getTime();
                    d = null;
                    e = 0;
                    k(!0);
                    f > 1 && Q(b, fy(a.getAdUnitPath(), String(f - 1)));
                    f = 0
                });
                e && clearTimeout(e);
                r = (new Date).getTime() - c;
                r > _.K(gy) ? p() : (e = setTimeout(p, _.K(gy) - r), _.$q(a, function() {
                    return void k(!1)
                }), d = k);
                return v.return(h)
            })
        }
    };
    jy = function(a, b, c) {
        var d, e, f;
        return _.ug(function(g) {
            if (g.g == 1) {
                if (b.J || a.J) return g.return();
                e = (d = iy.get(a)) != null ? d : function() {
                    var h = hy(a, c);
                    iy.set(a, h);
                    _.$q(a, function() {
                        return void iy.delete(a)
                    });
                    return h
                }();
                return g.yield(e(), 2)
            }
            f = g.o;
            return b.J || a.J ? g.return() : f ? g.return(a) : g.return()
        })
    };
    ky = function(a, b) {
        var c = [];
        a = qb(a, function(f) {
            return ln(f.getAdUnitPath())
        });
        a = _.y(_.w(Object, "entries").call(Object, a));
        for (var d = a.next(); !d.done; d = a.next()) {
            var e = _.y(d.value);
            d = e.next().value;
            e = e.next().value;
            d === b ? c.unshift({
                networkCode: d,
                T: e
            }) : c.push({
                networkCode: d,
                T: e
            })
        }
        return c
    };
    sy = function() {
        var a = new ly;
        var b = a.setParameters;
        var c = (new my).setCorrelator(ql(_.ca));
        var d = Ui().join();
        c = _.Ek(c, 5, d);
        c = _.H(c, 2, 1);
        a = b.call(a, c);
        b = new ny;
        c = _.I(oy);
        b = _.$g(b, 7, c);
        c = _.I(py);
        b = _.$g(b, 8, c);
        c = _.I(qy);
        b = _.$g(b, 9, c);
        b = _.$g(b, 10, !0);
        c = _.I(ry);
        b = _.$g(b, 13, c);
        b = _.$g(b, 16, !0);
        a = _.Wg(a, 2, b);
        window.google_rum_config = _.jf(a)
    };
    wy = function() {
        var a = _.I(ty) ? _.ng(uy) : _.ng(vy);
        _.Cr(document, a)
    };
    zy = function(a, b) {
        var c = xy() || (0, _.yy)() ? 1 : _.$i(),
            d = c < .001;
        d ? (b.A = !0, Ti(31067358)) : c < .002 && Ti(31067357);
        fp(23, a);
        return {
            Ai: d,
            fh: 1E3,
            Zb: c
        }
    };
    Dy = function(a, b) {
        var c = window.document.URL,
            d = new Ay(4, b.Ra, 1E3),
            e = new By(Sr(), d, a.Zb);
        return _.w(Object, "assign").call(Object, {}, b, a, {
            S: new Cy(b)
        }, {
            va: d,
            documentUrl: c,
            O: e
        })
    };
    _.aa = [];
    Ey = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    };
    Fy = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };
    Gy = function(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    };
    _.Hy = Gy(this);
    Iy = typeof Symbol === "function" && typeof Symbol("x") === "symbol";
    _.z = {};
    Jy = {};
    _.w = function(a, b, c) {
        if (!c || a != null) {
            c = Jy[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    };
    Ky = function(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in _.z ? f = _.z : f = _.Hy;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = Iy && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? Fy(_.z, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (Jy[d] === void 0 && (a = Math.random() * 1E9 >>> 0, Jy[d] = Iy ? _.Hy.Symbol(d) : "$jscp$" + a + "$" + d), Fy(f, Jy[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    };
    Ky("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.g = f;
            Fy(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.g
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    Ky("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, _.z.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = _.Hy[b[c]];
            typeof d === "function" && typeof d.prototype[a] != "function" && Fy(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return Ly(Ey(this))
                }
            })
        }
        return a
    }, "es6");
    Ly = function(a) {
        a = {
            next: a
        };
        a[_.w(_.z.Symbol, "iterator")] = function() {
            return this
        };
        return a
    };
    Ny = function(a) {
        return My(a, a)
    };
    My = function(a, b) {
        a.raw = b;
        Object.freeze && (Object.freeze(a), Object.freeze(b));
        return a
    };
    _.y = function(a) {
        var b = typeof _.z.Symbol != "undefined" && _.w(_.z.Symbol, "iterator") && a[_.w(_.z.Symbol, "iterator")];
        if (b) return b.call(a);
        if (typeof a.length == "number") return {
            next: Ey(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    };
    _.Zk = function(a) {
        if (!(a instanceof Array)) {
            a = _.y(a);
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            a = c
        }
        return a
    };
    Oy = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    Py = Iy && typeof _.w(Object, "assign") == "function" ? _.w(Object, "assign") : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) Oy(d, e) && (a[e] = d[e])
        }
        return a
    };
    Ky("Object.assign", function(a) {
        return a || Py
    }, "es6");
    var Qy = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        Ry = function() {
            function a() {
                function c() {}
                new c;
                Reflect.construct(c, [], function() {});
                return new c instanceof c
            }
            if (Iy && typeof Reflect != "undefined" && Reflect.construct) {
                if (a()) return Reflect.construct;
                var b = Reflect.construct;
                return function(c, d, e) {
                    c = b(c, d);
                    e && Reflect.setPrototypeOf(c, e.prototype);
                    return c
                }
            }
            return function(c, d, e) {
                e === void 0 && (e = c);
                e = Qy(e.prototype || Object.prototype);
                return Function.prototype.apply.call(c, e, d) || e
            }
        }(),
        Sy;
    if (Iy && typeof _.w(Object, "setPrototypeOf") == "function") Sy = _.w(Object, "setPrototypeOf");
    else {
        var Ty;
        a: {
            var Uy = {
                    a: !0
                },
                Vy = {};
            try {
                Vy.__proto__ = Uy;
                Ty = Vy.a;
                break a
            } catch (a) {}
            Ty = !1
        }
        Sy = Ty ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    Wy = Sy;
    _.T = function(a, b) {
        a.prototype = Qy(b.prototype);
        a.prototype.constructor = a;
        if (Wy) Wy(a, b);
        else
            for (var c in b)
                if (c != "prototype")
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Ap = b.prototype
    };
    Xy = function() {
        this.F = !1;
        this.j = null;
        this.o = void 0;
        this.g = 1;
        this.C = this.l = 0;
        this.J = null
    };
    Yy = function(a) {
        if (a.F) throw new TypeError("Generator is already running");
        a.F = !0
    };
    Xy.prototype.A = function(a) {
        this.o = a
    };
    var Zy = function(a, b) {
        a.J = {
            exception: b,
            isException: !0
        };
        a.g = a.l || a.C
    };
    Xy.prototype.return = function(a) {
        this.J = {
            return: a
        };
        this.g = this.C
    };
    Xy.prototype.yield = function(a, b) {
        this.g = b;
        return {
            value: a
        }
    };
    wg = function(a) {
        a.l = 0;
        var b = a.J.exception;
        a.J = null;
        return b
    };
    $y = function(a) {
        this.g = new Xy;
        this.o = a
    };
    cz = function(a, b) {
        Yy(a.g);
        var c = a.g.j;
        if (c) return az(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.g.return);
        a.g.return(b);
        return bz(a)
    };
    az = function(a, b, c, d) {
        try {
            var e = b.call(a.g.j, c);
            if (!(e instanceof Object)) throw new TypeError("Iterator result " + e + " is not an object");
            if (!e.done) return a.g.F = !1, e;
            var f = e.value
        } catch (g) {
            return a.g.j = null, Zy(a.g, g), bz(a)
        }
        a.g.j = null;
        d.call(a.g, f);
        return bz(a)
    };
    bz = function(a) {
        for (; a.g.g;) try {
            var b = a.o(a.g);
            if (b) return a.g.F = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.g.o = void 0, Zy(a.g, c)
        }
        a.g.F = !1;
        if (a.g.J) {
            b = a.g.J;
            a.g.J = null;
            if (b.isException) throw b.exception;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    };
    dz = function(a) {
        this.next = function(b) {
            Yy(a.g);
            a.g.j ? b = az(a, a.g.j.next, b, a.g.A) : (a.g.A(b), b = bz(a));
            return b
        };
        this.throw = function(b) {
            Yy(a.g);
            a.g.j ? b = az(a, a.g.j["throw"], b, a.g.A) : (Zy(a.g, b), b = bz(a));
            return b
        };
        this.return = function(b) {
            return cz(a, b)
        };
        this[_.w(_.z.Symbol, "iterator")] = function() {
            return this
        }
    };
    ez = function(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new _.z.Promise(function(d, e) {
            function f(g) {
                g.done ? d(g.value) : _.z.Promise.resolve(g.value).then(b, c).then(f, e)
            }
            f(a.next())
        })
    };
    _.ug = function(a) {
        return ez(new dz(new $y(a)))
    };
    _.Ia = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    Ky("Reflect", function(a) {
        return a ? a : {}
    }, "es6");
    Ky("Reflect.construct", function() {
        return Ry
    }, "es6");
    Ky("Reflect.setPrototypeOf", function(a) {
        return a ? a : Wy ? function(b, c) {
            try {
                return Wy(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    }, "es6");
    Ky("Promise", function(a) {
        function b() {
            this.g = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.o = function(g) {
            if (this.g == null) {
                this.g = [];
                var h = this;
                this.l(function() {
                    h.J()
                })
            }
            this.g.push(g)
        };
        var d = _.Hy.setTimeout;
        b.prototype.l = function(g) {
            d(g, 0)
        };
        b.prototype.J = function() {
            for (; this.g && this.g.length;) {
                var g = this.g;
                this.g = [];
                for (var h = 0; h < g.length; ++h) {
                    var l = g[h];
                    g[h] = null;
                    try {
                        l()
                    } catch (k) {
                        this.j(k)
                    }
                }
            }
            this.g = null
        };
        b.prototype.j = function(g) {
            this.l(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.o = 0;
            this.l = void 0;
            this.g = [];
            this.A = !1;
            var h = this.j();
            try {
                g(h.resolve, h.reject)
            } catch (l) {
                h.reject(l)
            }
        };
        e.prototype.j = function() {
            function g(k) {
                return function(m) {
                    l || (l = !0, k.call(h, m))
                }
            }
            var h = this,
                l = !1;
            return {
                resolve: g(this.Va),
                reject: g(this.J)
            }
        };
        e.prototype.Va = function(g) {
            if (g === this) this.J(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof e) this.R(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = g != null;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.X(g) : this.F(g)
            }
        };
        e.prototype.X = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (l) {
                this.J(l);
                return
            }
            typeof h == "function" ? this.U(h, g) : this.F(g)
        };
        e.prototype.J = function(g) {
            this.C(2, g)
        };
        e.prototype.F = function(g) {
            this.C(1, g)
        };
        e.prototype.C = function(g, h) {
            if (this.o != 0) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.o);
            this.o = g;
            this.l = h;
            this.o === 2 && this.da();
            this.G()
        };
        e.prototype.da = function() {
            var g = this;
            d(function() {
                if (g.I()) {
                    var h = _.Hy.console;
                    typeof h !== "undefined" && h.error(g.l)
                }
            }, 1)
        };
        e.prototype.I = function() {
            if (this.A) return !1;
            var g = _.Hy.CustomEvent,
                h = _.Hy.Event,
                l = _.Hy.dispatchEvent;
            if (typeof l === "undefined") return !0;
            typeof g === "function" ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : typeof h === "function" ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = _.Hy.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.l;
            return l(g)
        };
        e.prototype.G = function() {
            if (this.g != null) {
                for (var g = 0; g < this.g.length; ++g) f.o(this.g[g]);
                this.g = null
            }
        };
        var f = new b;
        e.prototype.R = function(g) {
            var h = this.j();
            g.jf(h.resolve, h.reject)
        };
        e.prototype.U = function(g, h) {
            var l = this.j();
            try {
                g.call(h, l.resolve, l.reject)
            } catch (k) {
                l.reject(k)
            }
        };
        e.prototype.then = function(g, h) {
            function l(p, r) {
                return typeof p == "function" ? function(v) {
                    try {
                        k(p(v))
                    } catch (u) {
                        m(u)
                    }
                } : r
            }
            var k, m, n = new e(function(p, r) {
                k = p;
                m = r
            });
            this.jf(l(g, k), l(h, m));
            return n
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.jf = function(g, h) {
            function l() {
                switch (k.o) {
                    case 1:
                        g(k.l);
                        break;
                    case 2:
                        h(k.l);
                        break;
                    default:
                        throw Error("Unexpected state: " + k.o);
                }
            }
            var k = this;
            this.g == null ? f.o(l) : this.g.push(l);
            this.A = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, l) {
                l(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, l) {
                for (var k = _.y(g), m = k.next(); !m.done; m = k.next()) c(m.value).jf(h, l)
            })
        };
        e.all = function(g) {
            var h = _.y(g),
                l = h.next();
            return l.done ? c([]) : new e(function(k, m) {
                function n(v) {
                    return function(u) {
                        p[v] = u;
                        r--;
                        r == 0 && k(p)
                    }
                }
                var p = [],
                    r = 0;
                do p.push(void 0), r++, c(l.value).jf(n(p.length - 1), m), l = h.next(); while (!l.done)
            })
        };
        return e
    }, "es6");
    Ky("Object.setPrototypeOf", function(a) {
        return a || Wy
    }, "es6");
    Ky("Symbol.dispose", function(a) {
        return a ? a : (0, _.z.Symbol)("Symbol.dispose")
    }, "es_next");
    var fz = function(a, b, c) {
        a instanceof String && (a = String(a));
        for (var d = a.length, e = 0; e < d; e++) {
            var f = a[e];
            if (b.call(c, f, e, a)) return {
                ik: e,
                Il: f
            }
        }
        return {
            ik: -1,
            Il: void 0
        }
    };
    Ky("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            return fz(this, b, c).Il
        }
    }, "es6");
    Ky("globalThis", function(a) {
        return a || _.Hy
    }, "es_2020");
    Ky("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return h === "object" && g !== null || h === "function"
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        l = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (l.get(g) != 2 || l.get(h) != 3) return !1;
                    l.delete(g);
                    l.set(h, 4);
                    return !l.has(g) && l.get(h) == 4
                } catch (k) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.g = (e += Math.random() + 1).toString();
                if (g) {
                    g = _.y(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!Oy(g, d)) {
                var l = new b;
                Fy(g, d, {
                    value: l
                })
            }
            if (!Oy(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.g] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && Oy(g, d) ? g[d][this.g] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && Oy(g, d) && Oy(g[d], this.g)
        };
        f.prototype.delete = function(g) {
            return c(g) && Oy(g, d) && Oy(g[d], this.g) ? delete g[d][this.g] : !1
        };
        return f
    }, "es6");
    Ky("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !_.w(a.prototype, "entries") || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        l = new a(_.y([
                            [h, "s"]
                        ]));
                    if (l.get(h) != "s" || l.size != 1 || l.get({
                            x: 4
                        }) || l.set({
                            x: 4
                        }, "t") != l || l.size != 2) return !1;
                    var k = _.w(l, "entries").call(l),
                        m = k.next();
                    if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
                    m = k.next();
                    return m.done || m.value[0].x != 4 || m.value[1] != "t" || !k.next().done ? !1 : !0
                } catch (n) {
                    return !1
                }
            }()) return a;
        var b = new _.z.WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = _.y(h);
                    for (var l; !(l = h.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        c.prototype.set = function(h, l) {
            h = h === 0 ? 0 : h;
            var k = d(this, h);
            k.list || (k.list = this[0][k.id] = []);
            k.entry ? k.entry.value = l : (k.entry = {
                next: this[1],
                previous: this[1].previous,
                head: this[1],
                key: h,
                value: l
            }, k.list.push(k.entry), this[1].previous.next = k.entry, this[1].previous = k.entry, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.previous.next = h.entry.next, h.entry.next.previous = h.entry.previous, h.entry.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].previous = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, l) {
            for (var k = _.w(this, "entries").call(this), m; !(m = k.next()).done;) m = m.value, h.call(l, m[1], m[0], this)
        };
        c.prototype[_.w(_.z.Symbol, "iterator")] = _.w(c.prototype, "entries");
        var d = function(h, l) {
                var k = l && typeof l;
                k == "object" || k == "function" ? b.has(l) ? k = b.get(l) : (k = "" + ++g, b.set(l, k)) : k = "p_" + l;
                var m = h[0][k];
                if (m && Oy(h[0], k))
                    for (h = 0; h < m.length; h++) {
                        var n = m[h];
                        if (l !== l && n.key !== n.key || l === n.key) return {
                            id: k,
                            list: m,
                            index: h,
                            entry: n
                        }
                    }
                return {
                    id: k,
                    list: m,
                    index: -1,
                    entry: void 0
                }
            },
            e = function(h, l) {
                var k = h[1];
                return Ly(function() {
                    if (k) {
                        for (; k.head != h[1];) k = k.previous;
                        for (; k.next != k.head;) return k = k.next, {
                            done: !1,
                            value: l(k)
                        };
                        k = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.previous = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    Ky("Set", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !_.w(a.prototype, "entries") || typeof Object.seal != "function") return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(_.y([c]));
                    if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                            x: 4
                        }) != d || d.size != 2) return !1;
                    var e = _.w(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.g = new _.z.Map;
            if (c) {
                c = _.y(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.g.size
        };
        b.prototype.add = function(c) {
            c = c === 0 ? 0 : c;
            this.g.set(c, c);
            this.size = this.g.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.g.delete(c);
            this.size = this.g.size;
            return c
        };
        b.prototype.clear = function() {
            this.g.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.g.has(c)
        };
        b.prototype.entries = function() {
            return _.w(this.g, "entries").call(this.g)
        };
        b.prototype.values = function() {
            return _.w(this.g, "values").call(this.g)
        };
        b.prototype.keys = _.w(b.prototype, "values");
        b.prototype[_.w(_.z.Symbol, "iterator")] = _.w(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.g.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    var gz = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[_.w(_.z.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    Ky("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return gz(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    Ky("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return gz(this, function(b) {
                return b
            })
        }
    }, "es6");
    var hz = function(a, b, c) {
        if (a == null) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    Ky("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = hz(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    Ky("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = hz(this, b, "endsWith");
            c === void 0 && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; e > 0 && c > 0;)
                if (d[--c] != b[--e]) return !1;
            return e <= 0
        }
    }, "es6");
    Ky("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    }, "es6");
    Ky("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = hz(this, null, "repeat");
            if (b < 0 || b > 1342177279) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    }, "es6");
    Ky("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    Ky("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || _.w(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    Ky("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return hz(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    }, "es6");
    Ky("Array.prototype.findIndex", function(a) {
        return a ? a : function(b, c) {
            return fz(this, b, c).ik
        }
    }, "es6");
    Ky("Array.prototype.flatMap", function(a) {
        return a ? a : function(b, c) {
            var d = [];
            Array.prototype.forEach.call(this, function(e, f) {
                e = b.call(c, e, f, this);
                Array.isArray(e) ? d.push.apply(d, e) : d.push(e)
            });
            return d
        }
    }, "es9");
    Ky("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) Oy(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    Ky("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) Oy(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    Ky("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                f = typeof _.z.Symbol != "undefined" && _.w(_.z.Symbol, "iterator") && b[_.w(_.z.Symbol, "iterator")];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    Ky("Number.EPSILON", function() {
        return 2.220446049250313E-16
    }, "es6");
    Ky("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    Ky("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    }, "es6");
    Ky("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return _.w(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    Ky("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return _.w(Number, "isInteger").call(Number, b) && Math.abs(b) <= _.w(Number, "MAX_SAFE_INTEGER")
        }
    }, "es6");
    Ky("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || b === Infinity || b === -Infinity || b === 0) return b;
            var c = Math.floor(Math.abs(b));
            return b < 0 ? -c : c
        }
    }, "es6");
    Ky("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    }, "es6");
    Ky("Array.prototype.values", function(a) {
        return a ? a : function() {
            return gz(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    Ky("Object.fromEntries", function(a) {
        return a ? a : function(b) {
            var c = {};
            if (!(_.w(_.z.Symbol, "iterator") in b)) throw new TypeError("" + b + " is not iterable");
            b = b[_.w(_.z.Symbol, "iterator")].call(b);
            for (var d = b.next(); !d.done; d = b.next()) {
                d = d.value;
                if (Object(d) !== d) throw new TypeError("iterable for fromEntries should yield objects");
                c[d[0]] = d[1]
            }
            return c
        }
    }, "es_2019");
    Ky("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            c < 0 && (c = Math.max(0, e + c));
            if (d == null || d > e) d = e;
            d = Number(d);
            d < 0 && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    }, "es6");
    var iz = function(a) {
        return a ? a : _.w(Array.prototype, "fill")
    };
    Ky("Int8Array.prototype.fill", iz, "es6");
    Ky("Uint8Array.prototype.fill", iz, "es6");
    Ky("Uint8ClampedArray.prototype.fill", iz, "es6");
    Ky("Int16Array.prototype.fill", iz, "es6");
    Ky("Uint16Array.prototype.fill", iz, "es6");
    Ky("Int32Array.prototype.fill", iz, "es6");
    Ky("Uint32Array.prototype.fill", iz, "es6");
    Ky("Float32Array.prototype.fill", iz, "es6");
    Ky("Float64Array.prototype.fill", iz, "es6");
    var jz = function(a, b) {
        a = a !== void 0 ? String(a) : " ";
        return b > 0 && a ? _.w(a, "repeat").call(a, Math.ceil(b / a.length)).substring(0, b) : ""
    };
    Ky("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = hz(this, null, "padStart");
            return jz(c, b - d.length) + d
        }
    }, "es8");
    Ky("String.prototype.padEnd", function(a) {
        return a ? a : function(b, c) {
            var d = hz(this, null, "padStart");
            return d + jz(c, b - d.length)
        }
    }, "es8");
    Ky("AggregateError", function(a) {
        if (a) return a;
        a = function(b, c) {
            c = Error(c);
            "stack" in c && (this.stack = c.stack);
            this.errors = b;
            this.message = c.message
        };
        _.T(a, Error);
        a.prototype.name = "AggregateError";
        return a
    }, "es_2021");
    Ky("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : _.w(Array, "from").call(Array, b);
            return _.z.Promise.all(b.map(function(c) {
                return _.z.Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new _.z.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    Ky("Object.hasOwn", function(a) {
        return a ? a : function(b, c) {
            return Object.prototype.hasOwnProperty.call(b, c)
        }
    }, "es_next");
    Ky("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = b === void 0 ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && b > 0 ? (d = _.w(Array.prototype, "flat").call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    }, "es9");
    Ky("Promise.prototype.finally", function(a) {
        return a ? a : function(b) {
            return this.then(function(c) {
                return _.z.Promise.resolve(b()).then(function() {
                    return c
                })
            }, function(c) {
                return _.z.Promise.resolve(b()).then(function() {
                    throw c;
                })
            })
        }
    }, "es9");
    Ky("Promise.withResolvers", function(a) {
        return a ? a : function() {
            var b, c;
            return {
                promise: new _.z.Promise(function(d, e) {
                    b = d;
                    c = e
                }),
                resolve: b,
                reject: c
            }
        }
    }, "es_next");
    Ky("String.raw", function(a) {
        return a ? a : function(b, c) {
            if (b == null) throw new TypeError("Cannot convert undefined or null to object");
            for (var d = b.raw, e = d.length, f = "", g = 0; g < e; ++g) f += d[g], g + 1 < e && g + 1 < arguments.length && (f += String(arguments[g + 1]));
            return f
        }
    }, "es6");
    Ky("Math.sign", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            return b === 0 || isNaN(b) ? b : b > 0 ? 1 : -1
        }
    }, "es6");
    var kz, Pc, lz, mz, nz, oz, rz;
    _.ca = this || self;
    kz = function(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = _.ca, e = 0; e < c.length; e++)
                if (d = d[c[e]], d == null) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return a != null ? a : b
    };
    Pc = function(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    };
    _.nb = function(a) {
        var b = Pc(a);
        return b == "array" || b == "object" && typeof a.length == "number"
    };
    _.gb = function(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    };
    _.hb = function(a) {
        return Object.prototype.hasOwnProperty.call(a, lz) && a[lz] || (a[lz] = ++mz)
    };
    lz = "closure_uid_" + (Math.random() * 1E9 >>> 0);
    mz = 0;
    nz = function(a, b, c) {
        return a.call.apply(a.bind, arguments)
    };
    oz = function(a, b, c) {
        if (!a) throw Error();
        if (arguments.length > 2) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    };
    _.pz = function(a, b, c) {
        _.pz = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? nz : oz;
        return _.pz.apply(null, arguments)
    };
    _.qz = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    };
    rz = function(a) {
        return a
    };
    var sz;
    var fa = kz(610401301, !1),
        tz = kz(653718497, kz(1, !0));
    var uz = function(a, b) {
            var c = a.length - b.length;
            return c >= 0 && a.indexOf(b, c) == c
        },
        Dn = function(a) {
            return /^[\s\xa0]*$/.test(a)
        },
        vz = function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        wz = /&/g,
        xz = /</g,
        yz = />/g,
        zz = /"/g,
        Az = /'/g,
        Bz = /\x00/g,
        Cz = /[\x00&<>"']/,
        ni = function(a, b) {
            return a.toLowerCase().indexOf(b.toLowerCase()) != -1
        };
    var ka, Dz = _.ca.navigator;
    ka = Dz ? Dz.userAgentData || null : null;
    var Ez = _.z.globalThis.trustedTypes,
        wa;
    _.ya = function(a) {
        this.g = a
    };
    _.ya.prototype.toString = function() {
        return this.g + ""
    };
    var Fa = function(a) {
        this.g = a
    };
    Fa.prototype.toString = function() {
        return this.g
    };
    var Ga = new Fa("about:invalid#zClosurez");
    var Ca = function(a) {
            this.co = a
        },
        Ea = [Da("data"), Da("http"), Da("https"), Da("mailto"), Da("ftp"), new Ca(function(a) {
            return /^[^:]*([/?#]|$)/.test(a)
        })],
        Ka = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
    _.Pa = function(a) {
        this.g = a
    };
    _.Pa.prototype.toString = function() {
        return this.g + ""
    };
    var Fz = new _.Pa(Ez ? Ez.emptyHTML : "");
    var Gz = {
            Aq: 0,
            yq: 1,
            zq: 2,
            0: "FORMATTED_HTML_CONTENT",
            1: "EMBEDDED_INTERNAL_CONTENT",
            2: "EMBEDDED_TRUSTED_EXTERNAL_CONTENT"
        },
        Hz = function(a, b) {
            b = Error.call(this, a + " cannot be used with intent " + Gz[b]);
            this.message = b.message;
            "stack" in b && (this.stack = b.stack);
            this.type = a;
            this.name = "TypeCannotBeUsedWithIntentError"
        };
    _.T(Hz, Error);
    var Ta = function(a) {
        this.g = a
    };
    Ta.prototype.toString = function() {
        return this.g + ""
    };
    _.Ya = function() {
        this.g = Iz[0]
    };
    _.Ya.prototype.toString = function() {
        return this.g
    };
    _.ab = function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    };
    _.Jz = function(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    };
    _.ok = function(a, b) {
        return Array.prototype.filter.call(a, b, void 0)
    };
    _.Kz = function(a, b) {
        return Array.prototype.map.call(a, b, void 0)
    };
    _.mi = function(a, b) {
        return Array.prototype.some.call(a, b, void 0)
    };
    var Lb = function(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Lz, Mz, Oz;
    Lz = function() {
        return Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36)
    };
    Mz = Math.random() * 2147483648 | 0;
    _.Nz = function(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    Oz = function(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
    _.Pz = function(a) {
        _.Pz[" "](a);
        return a
    };
    _.Pz[" "] = function() {};
    var Qz = function(a, b) {
        try {
            return _.Pz(a[b]), !0
        } catch (c) {}
        return !1
    };
    var Rz = _.qa(),
        Sz = _.na("Gecko") && !(ni(da(), "WebKit") && !_.na("Edge")) && !(_.na("Trident") || _.na("MSIE")) && !_.na("Edge"),
        Tz = ni(da(), "WebKit") && !_.na("Edge");
    _.va();
    _.ta();
    _.ua();
    Rz || _.ua();
    sb(function(a) {
        return function(b) {
            a(this);
            this.message = b ? b.length + " errors occurred during unsubscription:\n" + b.map(function(c, d) {
                return d + 1 + ") " + c.toString()
            }).join("\n  ") : "";
            this.name = "UnsubscriptionError";
            this.errors = b
        }
    });
    sb(function(a) {
        return function() {
            a(this);
            this.name = "ObjectUnsubscribedError";
            this.message = "object unsubscribed"
        }
    });
    sb(function(a) {
        return function() {
            a(this);
            this.name = "EmptyError";
            this.message = "no elements in sequence"
        }
    });
    sb(function(a) {
        return function() {
            a(this);
            this.name = "ArgumentOutOfRangeError";
            this.message = "argument out of range"
        }
    });
    sb(function(a) {
        return function(b) {
            a(this);
            this.name = "NotFoundError";
            this.message = b
        }
    });
    sb(function(a) {
        return function(b) {
            a(this);
            this.name = "SequenceError";
            this.message = b
        }
    });
    sb(function(a) {
        return function(b) {
            b = b === void 0 ? null : b;
            a(this);
            this.message = "Timeout has occurred";
            this.name = "TimeoutError";
            this.info = b
        }
    });
    var wb, vb = typeof String.prototype.isWellFormed === "function",
        ub = typeof TextEncoder !== "undefined";
    var Uz = {},
        Vz = null,
        Wz = Sz || Tz || typeof _.ca.btoa == "function",
        Ab = function(a, b) {
            b === void 0 && (b = 0);
            Xz();
            b = Uz[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    h = a[e + 1],
                    l = a[e + 2],
                    k = b[g >> 2];
                g = b[(g & 3) << 4 | h >> 4];
                h = b[(h & 15) << 2 | l >> 6];
                l = b[l & 63];
                c[f++] = k + g + h + l
            }
            k = 0;
            l = d;
            switch (a.length - e) {
                case 2:
                    k = a[e + 1], l = b[(k & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | k >> 4] + l + d
            }
            return c.join("")
        },
        Yz = function(a, b) {
            if (Wz && !b) a = _.ca.btoa(a);
            else {
                for (var c = [], d = 0, e = 0; e < a.length; e++) {
                    var f = a.charCodeAt(e);
                    f > 255 && (c[d++] = f & 255, f >>= 8);
                    c[d++] = f
                }
                a = Ab(c, b)
            }
            return a
        },
        Jg = function(a) {
            var b = [];
            Zz(a, function(c) {
                b.push(c)
            });
            return b
        },
        $z = function(a) {
            var b = a.length,
                c = b * 3 / 4;
            c % 3 ? c = Math.floor(c) : "=.".indexOf(a[b - 1]) != -1 && (c = "=.".indexOf(a[b - 2]) != -1 ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            Zz(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        Zz = function(a, b) {
            function c(l) {
                for (; d < a.length;) {
                    var k = a.charAt(d++),
                        m = Vz[k];
                    if (m != null) return m;
                    if (!Dn(k)) throw Error("Unknown base64 encoding at char: " + k);
                }
                return l
            }
            Xz();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (h === 64 && e === -1) break;
                b(e << 2 | f >> 4);
                g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
            }
        },
        Xz = function() {
            if (!Vz) {
                Vz = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++) {
                    var d = a.concat(b[c].split(""));
                    Uz[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        Vz[f] === void 0 && (Vz[f] = e)
                    }
                }
            }
        };
    var Eb = typeof Uint8Array !== "undefined",
        zb = !Rz && typeof btoa === "function",
        aA = /[-_.]/g,
        Cb = {
            "-": "+",
            _: "/",
            ".": "="
        },
        Gb = {};
    var ac = function(a, b) {
            Hb(b);
            this.g = a;
            if (a != null && a.length === 0) throw Error("ByteString should be constructed with non-empty values");
        },
        bc = function() {
            return bA || (bA = new ac(null, Gb))
        },
        ke = function(a) {
            var b = a.g;
            return b == null ? "" : typeof b === "string" ? b : a.g = Bb(b)
        },
        Jm = function(a) {
            var b = Uint8Array;
            Hb(Gb);
            var c = a.g;
            if (c != null && !Fb(c))
                if (typeof c === "string")
                    if (zb) {
                        aA.test(c) && (c = c.replace(aA, Db));
                        c = atob(c);
                        for (var d = new Uint8Array(c.length), e = 0; e < c.length; e++) d[e] = c.charCodeAt(e);
                        c = d
                    } else c = $z(c);
            else c = null;
            a = c == null ? c : a.g = c;
            return new b(a || 0)
        };
    ac.prototype.isEmpty = function() {
        return this.g == null
    };
    var bA;
    var cA, Ib;
    var Xe = typeof _.z.Symbol === "function" && typeof(0, _.z.Symbol)() === "symbol",
        dA = Qb(),
        Hd = Qb("0di"),
        eA = Qb("2ex"),
        Ye = Qb("1oa"),
        xe = Qb("0dg");
    var Rb, Vb;
    Rb = Xe ? function(a, b) {
        a[dA] |= b
    } : function(a, b) {
        a.Jb !== void 0 ? a.Jb |= b : Object.defineProperties(a, {
            Jb: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        })
    };
    _.Me = Xe ? function(a, b) {
        a[dA] &= ~b
    } : function(a, b) {
        a.Jb !== void 0 && (a.Jb &= ~b)
    };
    _.dc = Xe ? function(a) {
        return a[dA] | 0
    } : function(a) {
        return a.Jb | 0
    };
    _.se = Xe ? function(a) {
        return a[dA]
    } : function(a) {
        return a.Jb
    };
    Vb = Xe ? function(a, b) {
        a[dA] = b
    } : function(a, b) {
        a.Jb !== void 0 ? a.Jb = b : Object.defineProperties(a, {
            Jb: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        })
    };
    var Ed = {},
        Yb = {},
        Ke, fA = [],
        Ue, Te;
    Vb(fA, 55);
    Ke = Object.freeze(fA);
    var gA = function(a, b, c) {
        this.l = 0;
        this.g = a;
        this.o = b;
        this.j = c
    };
    gA.prototype.next = function() {
        if (this.l < this.g.length) {
            var a = this.g[this.l++];
            return {
                done: !1,
                value: this.o ? this.o.call(this.j, a) : a
            }
        }
        return {
            done: !0,
            value: void 0
        }
    };
    gA.prototype[_.w(_.z.Symbol, "iterator")] = function() {
        return new gA(this.g, this.o, this.j)
    };
    _.Yn = Object.freeze({});
    Ue = Object.freeze({});
    Te = Object.freeze({});
    _.gc = void 0;
    var yc, wc, Ac, Tp, hA, pc, jA, uc;
    yc = ic(function(a) {
        return typeof a === "number"
    });
    wc = ic(function(a) {
        return typeof a === "string"
    });
    Ac = ic(function(a) {
        return typeof a === "boolean"
    });
    Tp = ic(function(a) {
        return a === null
    });
    hA = ic(function(a) {
        return a === void 0
    });
    _.iA = ic(function(a) {
        return typeof a === "function"
    });
    pc = ic(function(a) {
        return !!a && (typeof a === "object" || typeof a === "function")
    });
    jA = tc();
    uc = tc();
    var zc = typeof _.ca.BigInt === "function" && typeof _.ca.BigInt(0) === "bigint";
    var td = ic(function(a) {
            return zc ? a >= kA && a <= lA : a[0] === "-" ? Cc(a, mA) : Cc(a, nA)
        }),
        mA = _.w(Number, "MIN_SAFE_INTEGER").toString(),
        kA = zc ? BigInt(_.w(Number, "MIN_SAFE_INTEGER")) : void 0,
        nA = _.w(Number, "MAX_SAFE_INTEGER").toString(),
        lA = zc ? BigInt(_.w(Number, "MAX_SAFE_INTEGER")) : void 0;
    var If;
    _.Dc = 0;
    _.Ec = 0;
    var Sc = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
    var He, Ld, Nd, Fe, Rd, Md, Qd;
    He = function(a) {
        Rd === void 0 && (Rd = typeof Proxy === "function" ? Pd(Proxy) : null);
        var b;
        (b = !Rd) || (Md === void 0 && (Md = typeof _.z.WeakMap === "function" ? Pd(_.z.WeakMap) : null), b = !Md);
        if (b) return a;
        if (b = Fe(a)) return b;
        if (Math.random() > .01) return a;
        Sd(a);
        b = new Rd(a, {
            set: function(c, d, e) {
                Kd();
                c[d] = e;
                return !0
            }
        });
        Od(a, b);
        return b
    };
    Ld = void 0;
    Nd = void 0;
    Fe = function(a) {
        var b;
        return (b = Ld) == null ? void 0 : b.get(a)
    };
    _.Se = function(a) {
        var b;
        return ((b = Nd) == null ? void 0 : b.get(a)) || a
    };
    Rd = void 0;
    Md = void 0;
    Qd = void 0;
    var Td, Vd, Wd;
    var ge = {},
        oA = function() {
            try {
                var a = function() {
                    return Ry(_.z.Map, [], this.constructor)
                };
                _.T(a, _.z.Map);
                _.Pz(new a);
                return !1
            } catch (b) {
                return !0
            }
        }(),
        pA = function() {
            this.g = new _.z.Map
        };
    _.q = pA.prototype;
    _.q.get = function(a) {
        return this.g.get(a)
    };
    _.q.set = function(a, b) {
        this.g.set(a, b);
        this.size = this.g.size;
        return this
    };
    _.q.delete = function(a) {
        a = this.g.delete(a);
        this.size = this.g.size;
        return a
    };
    _.q.clear = function() {
        this.g.clear();
        this.size = this.g.size
    };
    _.q.has = function(a) {
        return this.g.has(a)
    };
    _.q.entries = function() {
        return _.w(this.g, "entries").call(this.g)
    };
    _.q.keys = function() {
        return _.w(this.g, "keys").call(this.g)
    };
    _.q.values = function() {
        return _.w(this.g, "values").call(this.g)
    };
    _.q.forEach = function(a, b) {
        return this.g.forEach(a, b)
    };
    pA.prototype[_.w(_.z.Symbol, "iterator")] = function() {
        return _.w(this, "entries").call(this)
    };
    var qA = function() {
            if (oA) return _.w(Object, "setPrototypeOf").call(Object, pA.prototype, _.z.Map.prototype), Object.defineProperties(pA.prototype, {
                size: {
                    value: 0,
                    configurable: !0,
                    enumerable: !0,
                    writable: !0
                }
            }), pA;
            var a = function() {
                return Ry(_.z.Map, [], this.constructor)
            };
            _.T(a, _.z.Map);
            return a
        }(),
        fe = function(a, b, c, d) {
            c = c === void 0 ? Yd : c;
            d = d === void 0 ? Yd : d;
            var e = qA.call(this) || this;
            var f = (0, _.dc)(a);
            f |= 64;
            Vb(a, f);
            e.ae = f;
            e.rg = b;
            e.we = c;
            e.Si = e.rg ? be : d;
            for (var g = 0; g < a.length; g++) {
                var h = a[g],
                    l = c(h[0], !1, !0),
                    k = h[1];
                b ? k === void 0 && (k = null) : k = d(h[1], !1, !0, void 0, void 0, f);
                qA.prototype.set.call(e, l, k)
            }
            return e
        };
    _.T(fe, qA);
    var rA = function(a) {
            if (a.ae & 2) throw Error("Cannot mutate an immutable Map");
        },
        le = function(a, b) {
            b = b === void 0 ? ce : b;
            if (a.size !== 0) return ue(a, b)
        },
        ue = function(a, b) {
            b = b === void 0 ? ce : b;
            var c = [];
            a = _.w(qA.prototype, "entries").call(a);
            for (var d; !(d = a.next()).done;) d = d.value, d[0] = b(d[0]), d[1] = b(d[1]), c.push(d);
            return c
        };
    _.q = fe.prototype;
    _.q.clear = function() {
        rA(this);
        qA.prototype.clear.call(this)
    };
    _.q.delete = function(a) {
        rA(this);
        return qA.prototype.delete.call(this, this.we(a, !0, !1))
    };
    _.q.entries = function() {
        var a = _.w(Array, "from").call(Array, _.w(qA.prototype, "keys").call(this));
        return new gA(a, de, this)
    };
    _.q.keys = function() {
        return _.w(qA.prototype, "keys").call(this)
    };
    _.q.values = function() {
        var a = _.w(Array, "from").call(Array, _.w(qA.prototype, "keys").call(this));
        return new gA(a, fe.prototype.get, this)
    };
    _.q.forEach = function(a, b) {
        var c = this;
        qA.prototype.forEach.call(this, function(d, e) {
            a.call(b, c.get(e), e, c)
        })
    };
    _.q.set = function(a, b) {
        rA(this);
        a = this.we(a, !0, !1);
        return a == null ? this : b == null ? (qA.prototype.delete.call(this, a), this) : qA.prototype.set.call(this, a, this.Si(b, !0, !0, this.rg, !1, this.ae))
    };
    _.q.has = function(a) {
        return qA.prototype.has.call(this, this.we(a, !1, !1))
    };
    _.q.get = function(a) {
        a = this.we(a, !1, !1);
        var b = qA.prototype.get.call(this, a);
        if (b !== void 0) {
            var c = this.rg;
            return c ? (c = this.Si(b, !1, !0, c, this.zm, this.ae), c !== b && qA.prototype.set.call(this, a, c), c) : b
        }
    };
    fe.prototype[_.w(_.z.Symbol, "iterator")] = function() {
        return _.w(this, "entries").call(this)
    };
    fe.prototype.toJSON = void 0;
    fe.prototype.ko = Yb;
    var ee;
    var sA, Je, yt, Km, Ck, uA, wA, Fl, xA, yA, xt, Xn, xl, Ov, ev, zA, BA, Dv, CA, FA, GA, Yr, JA, dp;
    sA = Bc(0);
    _.tA = function(a, b) {
        a = a.D;
        return Je(a, (0, _.se)(a), b)
    };
    Je = function(a, b, c, d) {
        if (c === -1) return null;
        var e = b >> 15 & 1023 || 536870912;
        if (c >= e) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var f = a.length;
            if (d && b & 256 && (d = a[f - 1][c], d != null)) {
                if (ze(a, b, e, c) && eA != null) {
                    var g;
                    a = (g = cA) != null ? g : cA = {};
                    g = a[eA] || 0;
                    g >= 4 || (a[eA] = g + 1, Mb())
                }
                return d
            }
            return ze(a, b, e, c)
        }
    };
    _.vj = function(a, b, c) {
        var d = a.D,
            e = (0, _.se)(d);
        _.fc(e);
        Ae(d, e, b, c);
        return a
    };
    _.zs = function(a, b, c) {
        return _.bf(a, b, c, !1) !== void 0
    };
    yt = function(a, b) {
        a = a.D;
        var c = (0, _.se)(a),
            d = Je(a, c, b),
            e = Oc(d);
        e != null && e !== d && Ae(a, c, b, e);
        return e
    };
    _.wl = function(a) {
        return a === _.Yn ? 2 : tz ? 4 : 5
    };
    Km = function(a, b) {
        a = a.D;
        var c = (0, _.se)(a),
            d = Je(a, c, b),
            e = Le(d);
        e != null && e !== d && Ae(a, c, b, e);
        return e == null ? bc() : e
    };
    Ck = function(a, b, c, d) {
        var e = a.D,
            f = (0, _.se)(e);
        _.fc(f);
        if (d == null) {
            var g = Ze(e);
            if ($e(g, e, f, c) === b) g.set(c, 0);
            else return a
        } else f = af(e, f, c, b);
        Ae(e, f, b, d);
        return a
    };
    _.Lm = function(a, b, c) {
        return _.Im(a, b) === c ? c : -1
    };
    _.Im = function(a, b) {
        a = a.D;
        return $e(Ze(a), a, (0, _.se)(a), b)
    };
    _.Aq = function(a, b, c, d) {
        var e = a.D;
        af(e, (0, _.se)(e), d, c);
        return _.Hk(a, b, c)
    };
    _.Hk = function(a, b, c) {
        a = a.D;
        var d = (0, _.se)(a);
        _.fc(d);
        var e = Je(a, d, c);
        b = ae(Gd(e, b, !0, d));
        e !== b && Ae(a, d, c, b);
        return b
    };
    uA = function(a, b, c) {
        return (a = _.bf(a, b, c, !1)) ? a : Fd(b)
    };
    _.Fi = function(a, b, c) {
        b = _.bf(a, b, c, !1);
        if (b == null) return b;
        a = a.D;
        var d = (0, _.se)(a);
        if (!(d & 2)) {
            var e = ae(b);
            e !== b && (b = e, Ae(a, d, c, b))
        }
        return b
    };
    wA = function(a) {
        return _.cf(a, (0, _.se)(a.D), vA, 15, 1)
    };
    _.ul = function(a, b, c, d) {
        var e = (0, _.se)(a.D);
        return _.cf(a, e, b, c, d, void 0, !1, !(2 & e))
    };
    _.Wg = function(a, b, c) {
        c == null && (c = void 0);
        return _.vj(a, b, c)
    };
    _.en = function(a, b, c, d) {
        d == null && (d = void 0);
        return Ck(a, b, c, d)
    };
    _.Qn = function(a, b, c) {
        var d = a.D,
            e = (0, _.se)(d);
        _.fc(e);
        if (c == null) return Ae(d, e, b), a;
        c = _.Se(c);
        for (var f = (0, _.dc)(c), g = f, h = !!(2 & f) || !!(2048 & f), l = h || Object.isFrozen(c), k = !l && (void 0 === Te || void 0 !== Ue), m = !0, n = !0, p = 0; p < c.length; p++) {
            var r = c[p];
            h || (r = !!((0, _.dc)(r.D) & 2), m && (m = !r), n && (n = r))
        }
        h || (f |= 5, f = m ? f | 8 : f & -9, f = n ? f | 16 : f & -17);
        if (k || l && f !== g) c = Pb(c), g = 0, f = Ce(f, e), f = Ge(f, e, !0);
        f !== g && Vb(c, f);
        Ae(d, e, b, c);
        return a
    };
    Fl = function(a, b, c, d) {
        ef(a, b, c, d);
        return a
    };
    xA = function(a, b) {
        a = _.tA(a, b);
        a != null && (typeof a === "bigint" ? a >= 0 && td(a) ? a = Number(a) : (a = BigInt.asUintN(64, a), a = td(a) ? Number(a) : String(a)) : a = Tc(a) ? typeof a === "number" ? od(a) : rd(a) : void 0);
        return a
    };
    yA = function(a, b, c) {
        return Ie(a, b, _.ud, c, void 0, void 0, 0)
    };
    xt = function(a, b) {
        return Zc(_.tA(a, b))
    };
    Xn = function(a, b) {
        return bd(_.tA(a, b))
    };
    xl = function(a, b) {
        return Dd(_.tA(a, b))
    };
    _.R = function(a, b, c) {
        c = c === void 0 ? !1 : c;
        return gf(Rc(_.tA(a, b)), c)
    };
    _.Ct = function(a, b) {
        var c = c === void 0 ? 0 : c;
        return gf(xt(a, b), c)
    };
    Ov = function(a, b) {
        var c = c === void 0 ? 0 : c;
        return gf(Xn(a, b), c)
    };
    _.hi = function(a, b) {
        var c = c === void 0 ? 0 : c;
        return gf(_.ud(_.tA(a, b)), c)
    };
    ev = function(a, b) {
        var c = c === void 0 ? 0 : c;
        return gf(xA(a, b), c)
    };
    zA = function(a, b) {
        var c = c === void 0 ? sA : c;
        a = _.tA(a, b);
        b = typeof a;
        a = a == null ? a : b === "bigint" ? Bc(BigInt.asIntN(64, a)) : Tc(a) ? b === "string" ? ed(a) : fd(a) : void 0;
        return gf(a, c)
    };
    _.t = function(a, b) {
        var c = c === void 0 ? "" : c;
        return gf(xl(a, b), c)
    };
    _.Sh = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return gf(_.Xc(_.tA(a, b)), c)
    };
    _.AA = function(a, b) {
        var c = c === void 0 ? "0" : c;
        a = _.tA(a, b);
        b = !0;
        b = b === void 0 ? !1 : b;
        var d = typeof a;
        a = a == null ? a : d === "bigint" ? String(BigInt.asUintN(64, a)) : Tc(a) ? d === "string" ? rd(a) : b ? pd(a) : od(a) : void 0;
        return gf(a, c)
    };
    BA = function(a, b) {
        var c = c === void 0 ? "0" : c;
        return gf(vd(_.tA(a, b), !0), c)
    };
    Dv = function(a, b) {
        return Ie(a, b, Zc, _.wl())
    };
    _.Ou = function(a, b, c, d, e) {
        return Ie(a, b, Dd, c, d, e)
    };
    CA = function(a, b, c) {
        a = _.Ou(a, b, 3, void 0, !0);
        if (typeof c !== "number" || c < 0 || c >= a.length) throw Error();
        return a[c]
    };
    _.DA = function(a, b) {
        return Ie(a, b, _.Xc, _.wl())
    };
    FA = function(a) {
        return _.hi(a, _.Lm(a, EA, 3))
    };
    GA = function(a, b) {
        return _.t(a, _.Lm(a, b, 2))
    };
    Yr = function(a, b) {
        a = Rc(_.tA(a, b));
        return a == null ? void 0 : a
    };
    _.HA = function(a, b) {
        a = xt(a, b);
        return a == null ? void 0 : a
    };
    _.IA = function(a, b) {
        a = xl(a, b);
        return a == null ? void 0 : a
    };
    JA = function(a, b) {
        a = _.Xc(_.tA(a, b));
        return a == null ? void 0 : a
    };
    _.Dl = function(a, b, c) {
        return _.vj(a, b, c == null ? c : Qc(c))
    };
    _.$g = function(a, b, c) {
        return _.We(a, b, c == null ? c : Qc(c), !1)
    };
    _.Dq = function(a, b, c) {
        return _.vj(a, b, c == null ? c : Yc(c))
    };
    _.Pg = function(a, b, c) {
        return _.We(a, b, c == null ? c : Yc(c), 0)
    };
    _.Dm = function(a, b, c) {
        return _.vj(a, b, id(c))
    };
    _.Fk = function(a, b, c) {
        return _.We(a, b, id(c), "0")
    };
    _.tj = function(a, b, c) {
        return _.vj(a, b, Cd(c))
    };
    _.Ek = function(a, b, c) {
        return _.We(a, b, Cd(c), "")
    };
    _.uj = function(a, b, c) {
        return _.vj(a, b, Wc(c))
    };
    _.H = function(a, b, c) {
        return _.We(a, b, Wc(c), 0)
    };
    dp = function(a, b) {
        return Rc(_.tA(a, b)) != null
    };
    _.yl = function(a, b) {
        return xl(a, b) != null
    };
    var hf;
    _.B = function(a, b, c) {
        this.D = _.A(a, b, c)
    };
    _.B.prototype.toJSON = function() {
        return _.jf(this)
    };
    var Fm = function(a) {
        try {
            return hf = !0, JSON.stringify(_.jf(a), je)
        } finally {
            hf = !1
        }
    };
    _.B.prototype.Lh = Ed;
    var Qf, Pf, KA, LA, MA;
    Qf = function(a, b) {
        this.o = a >>> 0;
        this.g = b >>> 0
    };
    Pf = function(a) {
        if (!a) return KA || (KA = new Qf(0, 0));
        if (!/^\d+$/.test(a)) return null;
        Lc(a);
        return new Qf(_.Dc, _.Ec)
    };
    LA = function(a, b) {
        this.o = a >>> 0;
        this.g = b >>> 0
    };
    _.Nf = function(a) {
        a = BigInt.asUintN(64, a);
        return new LA(Number(a & BigInt(4294967295)), Number(a >> BigInt(32)))
    };
    _.Lf = function(a) {
        if (!a) return MA || (MA = new LA(0, 0));
        if (!/^-?\d+$/.test(a)) return null;
        Lc(a);
        return new LA(_.Dc, _.Ec)
    };
    var NA = function() {
            this.g = []
        },
        OA, Sf, Jf;
    NA.prototype.length = function() {
        return this.g.length
    };
    NA.prototype.end = function() {
        var a = this.g;
        this.g = [];
        return a
    };
    _.Mf = function(a, b, c) {
        for (; c > 0 || b > 127;) a.g.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
        a.g.push(b)
    };
    OA = function(a, b) {
        for (; b > 127;) a.g.push(b & 127 | 128), b >>>= 7;
        a.g.push(b)
    };
    Sf = function(a, b) {
        if (b >= 0) OA(a, b);
        else {
            for (var c = 0; c < 9; c++) a.g.push(b & 127 | 128), b >>= 7;
            a.g.push(1)
        }
    };
    Jf = function(a, b) {
        a.g.push(b >>> 0 & 255);
        a.g.push(b >>> 8 & 255);
        a.g.push(b >>> 16 & 255);
        a.g.push(b >>> 24 & 255)
    };
    var Kh, Th, Ph, Hf, Vf, pf, Mh;
    Kh = function() {
        this.l = [];
        this.o = 0;
        this.g = new NA
    };
    Th = function(a, b) {
        b.length !== 0 && (a.l.push(b), a.o += b.length)
    };
    _.PA = function(a, b) {
        Hf(a, b, 2);
        b = a.g.end();
        Th(a, b);
        b.push(a.o);
        return b
    };
    _.QA = function(a, b) {
        var c = b.pop();
        for (c = a.o + a.g.length() - c; c > 127;) b.push(c & 127 | 128), c >>>= 7, a.o++;
        b.push(c);
        a.o++
    };
    Ph = function(a) {
        Th(a, a.g.end());
        for (var b = new Uint8Array(a.o), c = a.l, d = c.length, e = 0, f = 0; f < d; f++) {
            var g = c[f];
            b.set(g, e);
            e += g.length
        }
        a.l = [b];
        return b
    };
    Hf = function(a, b, c) {
        OA(a.g, b * 8 + c)
    };
    Vf = function(a, b, c) {
        Hf(a, b, 2);
        OA(a.g, c.length);
        Th(a, a.g.end());
        Th(a, c)
    };
    pf = function(a, b, c, d) {
        c != null && (b = _.PA(a, b), d(c, a), _.QA(a, b))
    };
    Mh = function(a, b, c) {
        var d = Oh;
        if (c != null)
            for (var e = 0; e < c.length; e++) {
                var f = _.PA(a, b);
                d(c[e], a);
                _.QA(a, f)
            }
    };
    var mf, RA, SA, TA, XA;
    mf = lf();
    RA = lf();
    SA = lf();
    TA = lf();
    _.UA = lf();
    _.VA = lf();
    _.WA = lf();
    XA = lf();
    var nf = function(a, b) {
            this.g = a;
            a = rz(mf);
            this.o = !!a && b === a || !1
        },
        xf = of (rf),
        Df = of (rf),
        uf = (0, _.z.Symbol)(),
        Af = (0, _.z.Symbol)(),
        vf, wf;
    var Zf, YA, ZA, $A, cB, fB, hB, kB, oB, qB, tB, wB;
    Zf = function(a, b) {
        var c = new Kh;
        Bf(a.D, c, yf(b));
        return Ph(c)
    };
    YA = _.Ff(function(a, b, c) {
        b = Oc(b);
        b != null && (Hf(a, c, 1), a = a.g, c = If || (If = new DataView(new ArrayBuffer(8))), c.setFloat64(0, +b, !0), _.Dc = c.getUint32(0, !0), _.Ec = c.getUint32(4, !0), Jf(a, _.Dc), Jf(a, _.Ec))
    }, lf());
    ZA = _.Ff(_.Kf, _.WA);
    $A = _.Ff(Of, _.UA);
    _.aB = _.Ff(Of, _.UA);
    _.bB = _.Ff(Of, _.UA);
    cB = _.Ff(Of, _.UA);
    _.dB = _.Ff(_.Rf, _.VA);
    _.eB = _.Ff(Tf, TA);
    fB = _.Gf(function(a, b, c) {
        b = _.Ef(Zc, b, !0);
        if (b != null && b.length) {
            c = _.PA(a, c);
            for (var d = 0; d < b.length; d++) Sf(a.g, b[d]);
            _.QA(a, c)
        }
    }, TA);
    _.gB = _.Ff(Tf, TA);
    hB = _.Ff(function(a, b, c) {
        b = bd(b);
        b != null && (Hf(a, c, 5), Jf(a.g, b))
    }, lf());
    _.iB = _.Ff(Uf, RA);
    _.jB = _.Ff(Uf, RA);
    kB = _.Ff(Uf, RA);
    _.lB = _.Ff(Wf, SA);
    _.mB = _.Gf(function(a, b, c) {
        b = _.Ef(Dd, b, !0);
        if (b != null)
            for (var d = 0; d < b.length; d++) {
                var e = a,
                    f = c,
                    g = b[d];
                g != null && Vf(e, f, xb(g))
            }
    }, SA);
    _.nB = _.Ff(Wf, SA);
    oB = _.Ff(Wf, SA);
    qB = void 0;
    qB = qB === void 0 ? mf : qB;
    _.pB = new nf(function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++) Xf(a, b[f], c, d, e)
    }, qB);
    _.rB = of (Xf);
    _.sB = _.Ff(function(a, b, c) {
        b = bd(b);
        b != null && b != null && (Hf(a, c, 0), OA(a.g, b))
    }, lf());
    tB = _.Ff(Yf, XA);
    _.uB = _.Gf(function(a, b, c) {
        b = _.Ef(Zc, b, !0);
        if (b != null && b.length) {
            c = _.PA(a, c);
            for (var d = 0; d < b.length; d++) Sf(a.g, b[d]);
            _.QA(a, c)
        }
    }, XA);
    _.vB = _.Ff(Yf, XA);
    wB = _.Ff(Yf, XA);
    var xB = function(a) {
        this.D = _.A(a)
    };
    _.T(xB, _.B);
    var eg = /^[a-z][a-z\d-]*$/i,
        fg = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" "),
        kg = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" "),
        mg = ["action", "formaction", "href"];
    var yB = Ny(["https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js"]);
    var zg = Ny(["https://tpc.googlesyndication.com/sodar/", ".js"]),
        yg = Ny(["https://ep2.adtrafficquality.google/sodar/", ".js"]),
        zB = Ny(["https://www.google.com/recaptcha/api2/aframe"]);
    _.ng(zB);
    var AB, BB, wo;
    AB = function() {
        return !0
    };
    BB = function(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    };
    wo = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    _.Rs = function(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = null;
                c()
            }
        }
    };
    _.CB = function(a, b) {
        var c = 0,
            d = !1,
            e = [],
            f = function() {
                c = 0;
                d && (d = !1, g())
            },
            g = function() {
                c = _.ca.setTimeout(f, b);
                var h = e;
                e = [];
                a.apply(void 0, h)
            };
        return function(h) {
            e = arguments;
            c ? d = !0 : g()
        }
    };
    var qg;
    qg = wo(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            _.ca.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });
    _.sg = function(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, rg(d)), !0) : !1
    };
    _.Gh = function(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, rg(d)), !0) : !1
    };
    var vg = function(a) {
        return new _.z.Promise(function(b, c) {
            var d = new XMLHttpRequest;
            d.onreadystatechange = function() {
                d.readyState === d.DONE && (d.status >= 200 && d.status < 300 ? b(JSON.parse(d.responseText)) : c())
            };
            d.open("GET", a, !0);
            d.send()
        })
    };
    var DB = function(a) {
        this.D = _.A(a)
    };
    _.T(DB, _.B);
    var EB = function(a) {
        this.D = _.A(a)
    };
    _.T(EB, _.B);
    var FB = function(a) {
            this.g = a.o;
            this.o = a.l;
            this.j = a.j;
            this.ve = a.ve;
            this.B = a.B;
            this.Rd = a.Rd;
            this.Hf = a.Hf;
            this.kg = a.kg;
            this.Gf = a.Gf;
            this.l = a.g;
            this.qc = a.qc
        },
        GB = function(a, b, c) {
            this.o = a;
            this.l = b;
            this.j = c;
            this.B = window;
            this.Rd = "env";
            this.Hf = "n";
            this.kg = "0";
            this.Gf = "1";
            this.g = !0;
            this.qc = !1
        };
    GB.prototype.build = function() {
        return new FB(this)
    };
    var HB = function(a) {
        this.D = _.A(a)
    };
    _.T(HB, _.B);
    HB.prototype.getId = function() {
        return _.t(this, 1)
    };
    var IB = [0, _.lB];
    var JB = function(a) {
        this.D = _.A(a)
    };
    _.T(JB, _.B);
    var KB = [0, _.lB, -3];
    var LB = function(a) {
        this.D = _.A(a)
    };
    _.T(LB, _.B);
    LB.prototype.getWidth = function() {
        return _.Ct(this, 1)
    };
    LB.prototype.getHeight = function() {
        return _.Ct(this, 2)
    };
    LB.prototype.setHeight = function(a) {
        return _.Dq(this, 2, a)
    };
    var MB = [0, _.eB, -1];
    var NB = function(a) {
        this.D = _.A(a)
    };
    _.T(NB, _.B);
    var OB = [0, _.aB, _.iB, _.lB, -1];
    var PB = function(a) {
        this.D = _.A(a)
    };
    _.T(PB, _.B);
    PB.prototype.gk = function() {
        return _.zs(this, LB, 7)
    };
    var QB = [0, _.lB, _.aB, _.lB, _.mB, tB, IB, MB, _.aB, OB, _.lB, KB];
    var Ms = function(a) {
        this.D = _.A(a)
    };
    _.T(Ms, _.B);
    var Ls = function(a, b) {
            return _.uj(a, 1, b)
        },
        Js = function(a, b) {
            return _.Dl(a, 4, b)
        },
        Ks = function(a, b) {
            return _.Dq(a, 2, b)
        };
    var RB = function(a) {
        this.D = _.A(a)
    };
    _.T(RB, _.B);
    var SB = function(a, b) {
            return _.tj(a, 1, b)
        },
        TB = function(a, b) {
            return Fl(a, 3, PB, b)
        },
        UB = function(a, b) {
            return _.uj(a, 4, b)
        };
    RB.prototype.bk = function() {
        return _.Sh(this, 7, 0)
    };
    var VB = [0, tB, _.eB, _.lB, _.iB];
    var WB = [0, _.lB, _.aB, _.pB, QB, tB, VB, _.iB, tB, 2, _.mB];
    var XB = function(a) {
        this.D = _.A(a)
    };
    _.T(XB, _.B);
    var YB = function(a) {
        this.D = _.A(a)
    };
    _.T(YB, _.B);
    var ZB = function(a, b) {
            return ef(a, 2, RB, b)
        },
        $B = function(a, b) {
            _.Wg(a, 5, b)
        },
        aC = function(a, b) {
            _.tj(a, 10, b)
        },
        bC = function(a, b) {
            _.tj(a, 11, b)
        };
    var cC = [0, tB, _.pB, WB, tB, _.lB, VB, _.lB, _.iB, _.eB, [0, tB, _.iB, _.aB], _.lB, -1];
    var dC = function(a) {
        this.D = _.A(a)
    };
    _.T(dC, _.B);
    var eC = function(a) {
        var b = new YB;
        b = _.uj(b, 1, 1);
        return ef(a, 1, YB, b)
    };
    dC.prototype.g = ag([0, _.pB, cC]);
    var fC = function(a) {
        this.D = _.A(a)
    };
    _.T(fC, _.B);
    var EA = [2, 3];
    var gC = function(a) {
        this.D = _.A(a)
    };
    _.T(gC, _.B);
    var hC = function(a) {
        this.D = _.A(a)
    };
    _.T(hC, _.B);
    var iC = function(a) {
        this.D = _.A(a)
    };
    _.T(iC, _.B);
    var jC = [2, 3];
    var kC = function(a) {
        this.D = _.A(a)
    };
    _.T(kC, _.B);
    var lC = function(a) {
        this.D = _.A(a)
    };
    _.T(lC, _.B);
    lC.prototype.getId = function() {
        return Ov(this, 1)
    };
    var mC = function(a) {
        this.D = _.A(a)
    };
    _.T(mC, _.B);
    var nC = function(a) {
        this.D = _.A(a)
    };
    _.T(nC, _.B);
    nC.prototype.getNetworkList = function(a) {
        return _.ul(this, mC, 4, _.wl(a))
    };
    var oC = function(a) {
        this.D = _.A(a)
    };
    _.T(oC, _.B);
    var pC = function(a) {
        this.D = _.A(a)
    };
    _.T(pC, _.B);
    var qC = function(a) {
        this.D = _.A(a)
    };
    _.T(qC, _.B);
    var rC = function(a) {
        this.D = _.A(a)
    };
    _.T(rC, _.B);
    var sC = function(a) {
        this.D = _.A(a)
    };
    _.T(sC, _.B);
    var tC = function(a) {
        this.D = _.A(a)
    };
    _.T(tC, _.B);
    tC.prototype.getAdUnitPath = function() {
        return _.t(this, 2)
    };
    var uC = function(a) {
        this.D = _.A(a)
    };
    _.T(uC, _.B);
    var vC = function(a) {
        this.D = _.A(a)
    };
    _.T(vC, _.B);
    var wC = function(a) {
        this.D = _.A(a)
    };
    _.T(wC, _.B);
    var xC = function(a) {
        this.D = _.A(a)
    };
    _.T(xC, _.B);
    xC.prototype.getEscapedQemQueryId = function() {
        return _.t(this, 1)
    };
    var yC = function(a) {
        this.D = _.A(a)
    };
    _.T(yC, _.B);
    yC.prototype.getAdUnitPath = function() {
        return _.t(this, 1)
    };
    var vA = function(a) {
        this.D = _.A(a)
    };
    _.T(vA, _.B);
    _.zC = function(a) {
        this.D = _.A(a)
    };
    _.T(_.zC, _.B);
    _.AC = function(a) {
        return _.ul(a, vA, 15, _.wl())
    };
    var BC = function(a) {
        this.D = _.A(a)
    };
    _.T(BC, _.B);
    var CC = function(a) {
        this.D = _.A(a)
    };
    _.T(CC, _.B);
    var DC = [5, 7, 8, 9];
    var EC = function(a) {
        this.D = _.A(a)
    };
    _.T(EC, _.B);
    var FC = function(a) {
        this.D = _.A(a)
    };
    _.T(FC, _.B);
    var GC = function(a) {
        this.D = _.A(a)
    };
    _.T(GC, _.B);
    var HC = [0, _.lB, [0, $A],
        [0, tB, _.aB]
    ];
    var IC = function(a) {
        this.D = _.A(a)
    };
    _.T(IC, _.B);
    var JC = bg(IC);
    var KC = function(a) {
        this.D = _.A(a)
    };
    _.T(KC, _.B);
    KC.prototype.getValue = function() {
        return _.t(this, 2)
    };
    KC.prototype.lh = function() {
        return _.yl(this, 2)
    };
    var LC = function(a) {
        this.D = _.A(a)
    };
    _.T(LC, _.B);
    var MC = function(a) {
        this.D = _.A(a)
    };
    _.T(MC, _.B);
    var NC = function(a) {
        this.D = _.A(a)
    };
    _.T(NC, _.B);
    var OC = function(a) {
        this.D = _.A(a)
    };
    _.T(OC, _.B);
    var El = function(a) {
        var b = new OC;
        return _.uj(b, 1, a)
    };
    var PC = [0, tB];
    var vl = function(a) {
        this.D = _.A(a)
    };
    _.T(vl, _.B);
    var QC = function(a) {
            var b = new vl;
            return _.tj(b, 1, a)
        },
        RC = function(a) {
            var b = window.Date.now();
            b = _.w(Number, "isFinite").call(Number, b) ? Math.round(b) : 0;
            return _.Dm(a, 3, b)
        };
    vl.prototype.zb = function(a) {
        return _.Wg(this, 10, a)
    };
    var SC = bg(vl);
    var TC = [0, _.lB, -1, _.aB, _.eB, -2, _.aB, ZA, _.iB, PC, _.iB];
    var UC = [0, 1, [0, _.dB, -2], -1, _.lB, -1, _.iB, [0, 3, tB, _.lB], _.aB, _.uB, _.sB];
    var VC = function(a) {
        this.D = _.A(a)
    };
    _.T(VC, _.B);
    VC.prototype.g = ag([0, _.pB, UC, _.pB, TC]);
    var WC = function(a) {
        this.D = _.A(a)
    };
    _.T(WC, _.B);
    var XC = function(a) {
        this.D = _.A(a)
    };
    _.T(XC, _.B);
    var YC = function(a) {
        this.D = _.A(a)
    };
    _.T(YC, _.B);
    var ZC = function(a) {
        this.D = _.A(a)
    };
    _.T(ZC, _.B);
    var $C = function(a) {
        this.D = _.A(a)
    };
    _.T($C, _.B);
    $C.prototype.getValue = function() {
        return _.t(this, 1)
    };
    $C.prototype.lh = function() {
        return _.yl(this, 1)
    };
    $C.prototype.getVersion = function() {
        return _.Sh(this, 5, 0)
    };
    var aD = function(a) {
        this.D = _.A(a)
    };
    _.T(aD, _.B);
    var cD = function(a) {
        this.D = _.A(a)
    };
    _.T(cD, _.B);
    cD.prototype.getAdUnitPath = function() {
        return _.t(this, 1)
    };
    var eD = function(a) {
        this.D = _.A(a)
    };
    _.T(eD, _.B);
    var sD = function(a) {
        this.D = _.A(a)
    };
    _.T(sD, _.B);
    var tD = function(a) {
        this.D = _.A(a)
    };
    _.T(tD, _.B);
    var BD = function(a) {
        this.D = _.A(a)
    };
    _.T(BD, _.B);
    BD.prototype.getContentUrl = function() {
        return _.t(this, 2)
    };
    var DD = function(a) {
        this.D = _.A(a)
    };
    _.T(DD, _.B);
    DD.prototype.getEscapedQemQueryId = function() {
        return _.t(this, 4)
    };
    var ED = function(a) {
        this.D = _.A(a)
    };
    _.T(ED, _.B);
    var KD = function(a) {
        this.D = _.A(a)
    };
    _.T(KD, _.B);
    var MD = function(a) {
        this.D = _.A(a)
    };
    _.T(MD, _.B);
    var ND = function(a) {
        this.D = _.A(a)
    };
    _.T(ND, _.B);
    var OD = function(a) {
        this.D = _.A(a)
    };
    _.T(OD, _.B);
    var PD = function(a) {
        this.D = _.A(a)
    };
    _.T(PD, _.B);
    PD.prototype.getEscapedQemQueryId = function() {
        return _.t(this, 2)
    };
    var QD = function(a) {
        this.D = _.A(a)
    };
    _.T(QD, _.B);
    var RD = function(a) {
        this.D = _.A(a)
    };
    _.T(RD, _.B);
    var SD = function(a) {
        this.D = _.A(a)
    };
    _.T(SD, _.B);
    var TD = function(a) {
            return _.Fi(a, PD, 5)
        },
        UD = function(a) {
            return uA(a, PD, 5)
        };
    SD.prototype.getWidth = function() {
        return _.Ct(this, 9)
    };
    SD.prototype.getHeight = function() {
        return _.Ct(this, 10)
    };
    SD.prototype.setHeight = function(a) {
        return _.Pg(this, 10, a)
    };
    var VD = function(a) {
        this.D = _.A(a)
    };
    _.T(VD, _.B);
    VD.prototype.getHeight = function() {
        return _.Ct(this, 6)
    };
    VD.prototype.setHeight = function(a) {
        return _.Dq(this, 6, a)
    };
    VD.prototype.getWidth = function() {
        return _.Ct(this, 7)
    };
    VD.prototype.getEscapedQemQueryId = function() {
        return _.t(this, 34)
    };
    var WD = [39, 48];
    var XD = window;
    var ny = function(a) {
        this.D = _.A(a)
    };
    _.T(ny, _.B);
    var my = function(a) {
        this.D = _.A(a)
    };
    _.T(my, _.B);
    my.prototype.getCorrelator = function() {
        return zA(this, 1)
    };
    my.prototype.setCorrelator = function(a) {
        return _.Fk(this, 1, a)
    };
    var ly = function(a) {
        this.D = _.A(a)
    };
    _.T(ly, _.B);
    ly.prototype.setParameters = function(a) {
        return _.Wg(this, 1, a)
    };
    var ZD = function() {
            return fa && ka ? ka.mobile : !YD() && (_.na("iPod") || _.na("iPhone") || _.na("Android") || _.na("IEMobile"))
        },
        YD = function() {
            return fa && ka ? !ka.mobile && (_.na("iPad") || _.na("Android") || _.na("Silk")) : _.na("iPad") || _.na("Android") && !_.na("Mobile") || _.na("Silk")
        };
    var Fg = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
    var aE, Wo, Fr;
    _.$D = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
    aE = function(a) {
        return a ? decodeURI(a) : a
    };
    Wo = function(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) Wo(a, String(b[d]), c);
        else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    };
    Fr = /#|$/;
    var Mm, Vl, bE, Wl, xo, Zq, xy, dE, eE, fE, gE, hE, iE, jE, ri, kE, lE, mE, ts, jl, vs, Cs, nE, pE, qE, rE, sE, tE, ql, uE, Kp, Ip, vE, bp, wE, xE;
    _.um = function(a) {
        try {
            return !!a && a.location.href != null && Qz(a, "foo")
        } catch (b) {
            return !1
        }
    };
    Mm = function(a, b, c, d) {
        b = b === void 0 ? !1 : b;
        d = d === void 0 ? _.ca : d;
        c = (c === void 0 ? 0 : c) ? bE(d) : d;
        for (d = 0; c && d++ < 40 && (!b && !_.um(c) || !a(c));) c = bE(c)
    };
    Vl = function() {
        var a = window;
        Mm(function(b) {
            a = b;
            return !1
        });
        return a
    };
    bE = function(a) {
        try {
            var b = a.parent;
            if (b && b != a) return b
        } catch (c) {}
        return null
    };
    Wl = function(a) {
        return _.um(a.top) ? a.top : null
    };
    _.Cr = function(a, b) {
        var c = _.Fh("SCRIPT", a);
        Xa(c, b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    };
    xo = function(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    };
    _.$i = function() {
        if (!_.z.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            _.z.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    _.$o = function(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };
    _.cE = function(a) {
        var b = [];
        _.$o(a, function(c) {
            b.push(c)
        });
        return b
    };
    Zq = function(a, b) {
        return Eg(a, function(c, d) {
            return Object.prototype.hasOwnProperty.call(a, d) && b(c, d)
        })
    };
    _.aj = function(a) {
        var b = a.length;
        if (b == 0) return 0;
        for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    };
    _.yy = wo(function() {
        return _.mi(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], dE) || Math.random() < 1E-4
    });
    xy = wo(function() {
        return dE("MSIE")
    });
    dE = function(a) {
        return da().indexOf(a) != -1
    };
    eE = /^([0-9.]+)px$/;
    _.yo = function(a) {
        return (a = eE.exec(a)) ? +a[1] : null
    };
    fE = function() {
        var a = window;
        try {
            for (var b = null; b != a; b = a, a = a.parent) switch (a.location.protocol) {
                case "https:":
                    return !0;
                case "file:":
                    return !0;
                case "http:":
                    return !1
            }
        } catch (c) {}
        return !0
    };
    gE = function() {
        var a = _.ca.location.href;
        if (!a) return "";
        var b = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
        try {
            var c = b.exec(decodeURIComponent(a));
            if (c) return c[1] && c[1].length > 1 ? c[1].substring(1) : "true"
        } catch (d) {}
        return ""
    };
    hE = {
        jq: "allow-forms",
        kq: "allow-modals",
        lq: "allow-orientation-lock",
        mq: "allow-pointer-lock",
        nq: "allow-popups",
        oq: "allow-popups-to-escape-sandbox",
        qq: "allow-presentation",
        rq: "allow-same-origin",
        sq: "allow-scripts",
        tq: "allow-top-navigation",
        uq: "allow-top-navigation-by-user-activation"
    };
    iE = wo(function() {
        return _.cE(hE)
    });
    jE = function(a) {
        var b = iE();
        return a.length ? _.ok(b, function(c) {
            return !(_.ab(a, c) >= 0)
        }) : b
    };
    ri = function() {
        var a = _.Fh("IFRAME"),
            b = {};
        _.Jz(iE(), function(c) {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    };
    kE = function(a) {
        a = a && a.toString && a.toString();
        return typeof a === "string" && a.indexOf("[native code]") != -1
    };
    lE = function(a, b) {
        for (var c = 0; c < 50; ++c) {
            try {
                var d = !(!a.frames || !a.frames[b])
            } catch (e) {
                d = !1
            }
            if (d) return a;
            if (!(a = bE(a))) break
        }
        return null
    };
    mE = function(a) {
        if (!a || !a.frames) return null;
        if (a.frames.google_ads_top_frame) return a.frames.google_ads_top_frame.frameElement;
        try {
            var b = a.document,
                c = b.head,
                d, e = (d = b.body) != null ? d : c == null ? void 0 : c.parentElement;
            if (e) {
                var f = _.Fh("IFRAME");
                f.name = "google_ads_top_frame";
                f.id = "google_ads_top_frame";
                f.style.display = "none";
                f.style.position = "fixed";
                f.style.left = "-999px";
                f.style.top = "-999px";
                f.style.width = "0px";
                f.style.height = "0px";
                e.appendChild(f);
                return f
            }
        } catch (g) {}
        return null
    };
    _.Lq = wo(function() {
        return ZD() ? 2 : YD() ? 1 : 0
    });
    ts = function(a, b) {
        var c;
        for (c = c === void 0 ? 100 : c; a && c--;) {
            if (a == b) return !0;
            a = a.parentElement
        }
        return !1
    };
    _.ds = function(a, b) {
        _.$o(b, function(c, d) {
            a.style.setProperty(d, c, "important")
        })
    };
    jl = function(a, b, c) {
        for (c = c === void 0 ? 100 : c; a && c-- && b(a) !== !1;) a = a.parentElement
    };
    vs = function(a, b) {
        for (var c = 100; a && c--;) {
            var d = xo(a, window);
            if (d) {
                if (b(d, a)) return !0;
                a = a.parentElement
            }
        }
        return !1
    };
    Cs = function(a) {
        if (!a) return null;
        a = a.transform;
        if (!a) return null;
        a = a.replace(/^.*\(([0-9., -]+)\)$/, "$1").split(/, /);
        return a.length != 6 ? null : _.Kz(a, parseFloat)
    };
    nE = {};
    _.oE = (nE["http://googleads.g.doubleclick.net"] = !0, nE["http://pagead2.googlesyndication.com"] = !0, nE["https://googleads.g.doubleclick.net"] = !0, nE["https://pagead2.googlesyndication.com"] = !0, nE);
    pE = function(a) {
        _.ca.console && _.ca.console.warn && _.ca.console.warn(a)
    };
    qE = [];
    rE = function() {
        var a = qE;
        qE = [];
        a = _.y(a);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                b()
            } catch (c) {}
        }
    };
    sE = function(a) {
        return a.replace(/\\(n|r|\\)/g, function(b, c) {
            return c == "n" ? "\n" : c == "r" ? "\r" : "\\"
        })
    };
    tE = function() {
        var a = a === void 0 ? Math.random : a;
        return Math.floor(a() * 4503599627370496)
    };
    ql = function(a) {
        if (typeof a.goog_pvsid !== "number") try {
            Object.defineProperty(a, "goog_pvsid", {
                value: tE(),
                configurable: !1
            })
        } catch (b) {}
        return Number(a.goog_pvsid) || -1
    };
    uE = function(a, b) {
        a.readyState === "complete" || a.readyState === "interactive" ? (qE.push(b), qE.length == 1 && (_.z.Promise ? _.z.Promise.resolve().then(rE) : window.setImmediate ? setImmediate(rE) : setTimeout(rE, 0))) : a.addEventListener("DOMContentLoaded", b)
    };
    Kp = function(a) {
        return typeof a === "number" && isFinite(a) && a % 1 == 0 && a > 0
    };
    Ip = function(a) {
        return a === 0 || Kp(a)
    };
    vE = function(a, b) {
        return new _.z.Promise(function(c) {
            setTimeout(function() {
                return void c(b)
            }, a)
        })
    };
    bp = function(a) {
        try {
            var b = JSON.stringify(a)
        } catch (c) {}
        return b || String(a)
    };
    _.Fh = function(a, b) {
        b = b === void 0 ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    wE = function(a) {
        for (var b = a; a && a != a.parent;) a = a.parent, _.um(a) && (b = a);
        return b
    };
    _.ck = function(a) {
        return _.ta() && ZD() ? xE(a, !0) : 1
    };
    xE = function(a, b) {
        var c = (b === void 0 ? 0 : b) ? Wl(a) : a;
        if (!c) return 1;
        a = (0, _.Lq)() === 0;
        b = !!c.document.querySelector('meta[name=viewport][content*="width=device-width"]');
        var d = c.innerWidth;
        c = c.outerWidth;
        if (d === 0) return 1;
        var e = Math.round((c / d + _.w(Number, "EPSILON")) * 100) / 100;
        return e === 1 ? 1 : a || b ? e : Math.round((c / d / .4 + _.w(Number, "EPSILON")) * 100) / 100
    };
    _.io = function(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    };
    _.q = _.io.prototype;
    _.q.equals = function(a) {
        return a instanceof _.io && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    _.q.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    _.q.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    _.q.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    _.q.scale = function(a, b) {
        this.x *= a;
        this.y *= typeof b === "number" ? b : a;
        return this
    };
    _.yE = function(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    };
    _.yE.prototype.getWidth = function() {
        return this.right - this.left
    };
    _.yE.prototype.getHeight = function() {
        return this.bottom - this.top
    };
    _.zE = function(a) {
        return new _.yE(a.top, a.right, a.bottom, a.left)
    };
    _.q = _.yE.prototype;
    _.q.contains = function(a) {
        return this && a ? a instanceof _.yE ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    _.q.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    _.q.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    _.q.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    _.q.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };
    _.mo = function(a, b) {
        this.width = a;
        this.height = b
    };
    _.q = _.mo.prototype;
    _.q.aspectRatio = function() {
        return this.width / this.height
    };
    _.q.isEmpty = function() {
        return !(this.width * this.height)
    };
    _.q.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    _.q.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    _.q.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    _.q.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };
    var AE = function(a, b, c, d) {
            this.left = a;
            this.top = b;
            this.width = c;
            this.height = d
        },
        BE = function(a) {
            return new _.yE(a.top, a.left + a.width, a.top + a.height, a.left)
        },
        CE = function(a, b) {
            var c = Math.max(a.left, b.left),
                d = Math.min(a.left + a.width, b.left + b.width);
            if (c <= d) {
                var e = Math.max(a.top, b.top);
                a = Math.min(a.top + a.height, b.top + b.height);
                if (e <= a) return new AE(c, e, d - c, a - e)
            }
            return null
        };
    _.q = AE.prototype;
    _.q.contains = function(a) {
        return a instanceof _.io ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    _.q.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    _.q.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    _.q.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    _.q.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.width *= a;
        this.top *= b;
        this.height *= b;
        return this
    };
    var DE = function(a) {
        return (a = a === void 0 ? Hg() : a) ? _.um(a.master) ? a.master : null : null
    };
    var Wh, dl, GE, IE, JE, NE;
    Wh = function(a) {
        return a ? new _.EE(_.FE(a)) : sz || (sz = new _.EE)
    };
    dl = function(a, b) {
        Cg(b, function(c, d) {
            d == "style" ? a.style.cssText = c : d == "class" ? a.className = c : d == "for" ? a.htmlFor = c : GE.hasOwnProperty(d) ? a.setAttribute(GE[d], c) : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0 ? a.setAttribute(d, c) : a[d] = c
        })
    };
    GE = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };
    _.HE = function(a) {
        a = a.document;
        a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
        return new _.mo(a.clientWidth, a.clientHeight)
    };
    IE = function(a) {
        return a.scrollingElement ? a.scrollingElement : Tz || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement
    };
    _.nm = function(a) {
        return a ? a.defaultView : window
    };
    JE = function(a, b, c) {
        function d(h) {
            h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!_.nb(f) || _.gb(f) && f.nodeType > 0) d(f);
            else {
                a: {
                    if (f && typeof f.length == "number") {
                        if (_.gb(f)) {
                            var g = typeof f.item == "function" || typeof f.item == "string";
                            break a
                        }
                        if (typeof f === "function") {
                            g = typeof f.item == "function";
                            break a
                        }
                    }
                    g = !1
                }
                _.Jz(g ? _.db(f) : f, d)
            }
        }
    };
    _.KE = function(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    };
    _.LE = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    _.ME = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
        if (typeof a.compareDocumentPosition != "undefined") return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    _.FE = function(a) {
        return a.nodeType == 9 ? a : a.ownerDocument || a.document
    };
    NE = function(a) {
        try {
            return a.contentWindow || (a.contentDocument ? _.nm(a.contentDocument) : null)
        } catch (b) {}
        return null
    };
    _.Lk = function(a, b, c, d) {
        a && !c && (a = a.parentNode);
        for (c = 0; a && (d == null || c <= d);) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    };
    _.EE = function(a) {
        this.g = a || _.ca.document || document
    };
    _.q = _.EE.prototype;
    _.q.getElementsByTagName = function(a, b) {
        return (b || this.g).getElementsByTagName(String(a))
    };
    _.q.createElement = function(a) {
        return _.KE(this.g, a)
    };
    _.q.createTextNode = function(a) {
        return this.g.createTextNode(String(a))
    };
    _.q.append = function(a, b) {
        JE(_.FE(a), a, arguments)
    };
    _.q.Zl = _.LE;
    _.q.getChildren = function(a) {
        return a.children != void 0 ? a.children : Array.prototype.filter.call(a.childNodes, function(b) {
            return b.nodeType == 1
        })
    };
    _.q.contains = _.ME;
    var PE, RE, lo, SE, TE, ho;
    _.uk = function(a, b, c) {
        if (typeof b === "string")(b = _.OE(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = _.OE(c, d);
                f && (c.style[f] = e)
            }
    };
    PE = {};
    _.OE = function(a, b) {
        var c = PE[b];
        if (!c) {
            var d = _.Nz(b);
            c = d;
            a.style[d] === void 0 && (d = (Tz ? "Webkit" : Sz ? "Moz" : Rz ? "ms" : null) + Oz(d), a.style[d] !== void 0 && (c = d));
            PE[b] = c
        }
        return c
    };
    _.QE = function(a, b) {
        var c = _.FE(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    };
    RE = function(a, b) {
        return _.QE(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    };
    lo = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };
    SE = function(a) {
        var b = _.FE(a),
            c = RE(a, "position"),
            d = c == "fixed" || c == "absolute";
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (a.nodeType == 11 && a.host && (a = a.host), c = RE(a, "position"), d = d && c == "static" && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || c == "fixed" || c == "absolute" || c == "relative")) return a;
        return null
    };
    TE = function(a) {
        var b = _.FE(a),
            c = new _.io(0, 0);
        if (a == (b ? _.FE(b) : document).documentElement) return c;
        a = lo(a);
        var d = Wh(b).g;
        b = IE(d);
        d = d.defaultView;
        b = new _.io(d.pageXOffset || b.scrollLeft, d.pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    };
    ho = function(a, b) {
        var c = new _.io(0, 0),
            d = _.nm(_.FE(a));
        if (!Qz(d, "parent")) return c;
        do {
            var e = d == b ? TE(a) : _.UE(a);
            c.x += e.x;
            c.y += e.y
        } while (d && d != b && d != d.parent && (a = d.frameElement) && (d = d.parent));
        return c
    };
    _.UE = function(a) {
        a = lo(a);
        return new _.io(a.left, a.top)
    };
    _.VE = function(a, b) {
        typeof a == "number" && (a = (b ? Math.round(a) : a) + "px");
        return a
    };
    _.ko = function(a, b) {
        if (RE(b, "display") != "none") return a(b);
        var c = b.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = a(b);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    };
    _.WE = function(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = Tz && !b && !c;
        return (b === void 0 || d) && a.getBoundingClientRect ? (a = lo(a), new _.mo(a.right - a.left, a.bottom - a.top)) : new _.mo(b, c)
    };
    var YE, ZE, qs;
    _.XE = Ny(["//fonts.googleapis.com/css?family=", ""]);
    YE = function(a) {
        a = a === void 0 ? XD : a;
        try {
            return a.history.length
        } catch (b) {
            return 0
        }
    };
    ZE = function(a, b) {
        b = b === void 0 ? 1 : b;
        a = DE(Hg(a)) || a;
        a.google_unique_id = (a.google_unique_id || 0) + b
    };
    qs = function(a) {
        a = DE(Hg(a)) || a;
        a = a.google_unique_id;
        return typeof a === "number" ? a : 0
    };
    var $E = {
        Nq: 0,
        Mq: 1,
        Jq: 2,
        Eq: 3,
        Kq: 4,
        Fq: 5,
        Lq: 6,
        Hq: 7,
        Iq: 8,
        Dq: 9,
        Gq: 10,
        Oq: 11
    };
    var aF = {
        Qq: 0,
        Rq: 1,
        Pq: 2
    };
    var sj = function(a) {
        this.D = _.A(a)
    };
    _.T(sj, _.B);
    sj.prototype.getName = function() {
        return _.Sh(this, 1, 0)
    };
    sj.prototype.getVersion = function() {
        return _.t(this, 3)
    };
    var bF = [0, tB, -1, _.lB];
    _.Ik = function(a) {
        this.D = _.A(a)
    };
    _.T(_.Ik, _.B);
    _.Gk = function(a, b) {
        _.df(a, 1, _.Vc, b, _.Xc)
    };
    var cF = [0, _.uB];
    var dF = function(a) {
        this.D = _.A(a)
    };
    _.T(dF, _.B);
    var eF = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var Og = function(a) {
        this.D = _.A(a)
    };
    _.T(Og, _.B);
    Og.prototype.getVersion = function() {
        return _.Ct(this, 2)
    };
    var Xg = function(a) {
        this.D = _.A(a)
    };
    _.T(Xg, _.B);
    var Vg = function(a) {
        this.D = _.A(a)
    };
    _.T(Vg, _.B);
    var Ug = function(a) {
        this.D = _.A(a)
    };
    _.T(Ug, _.B);
    Ug.prototype.getVersion = function() {
        return _.Ct(this, 1)
    };
    var Zg = function(a) {
        this.D = _.A(a)
    };
    _.T(Zg, _.B);
    var fF = function(a) {
        this.D = _.A(a)
    };
    _.T(fF, _.B);
    var Yg = function(a) {
        var b = new fF;
        return _.Wg(b, 1, a)
    };
    var Tg = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        Sg = 6 + Tg.reduce(function(a, b) {
            return a + b
        });
    var eh = function(a) {
        this.D = _.A(a)
    };
    _.T(eh, _.B);
    var dh = function(a) {
        this.D = _.A(a)
    };
    _.T(dh, _.B);
    dh.prototype.getVersion = function() {
        return _.Ct(this, 1)
    };
    var gh = function(a) {
        this.D = _.A(a)
    };
    _.T(gh, _.B);
    var gF = function(a) {
        this.D = _.A(a)
    };
    _.T(gF, _.B);
    var fh = function(a) {
        var b = new gF;
        return _.Wg(b, 1, a)
    };
    var ch = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        bh = 6 + ch.reduce(function(a, b) {
            return a + b
        });
    var mh = function(a) {
        this.D = _.A(a)
    };
    _.T(mh, _.B);
    var lh = function(a) {
        this.D = _.A(a)
    };
    _.T(lh, _.B);
    var kh = function(a) {
        this.D = _.A(a)
    };
    _.T(kh, _.B);
    kh.prototype.getVersion = function() {
        return _.Ct(this, 1)
    };
    var ph = function(a) {
        this.D = _.A(a)
    };
    _.T(ph, _.B);
    var hF = function(a) {
        this.D = _.A(a)
    };
    _.T(hF, _.B);
    var oh = function(a) {
        var b = new hF;
        return _.Wg(b, 1, a)
    };
    var jh = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        ih = 6 + jh.reduce(function(a, b) {
            return a + b
        });
    var vh = function(a) {
        this.D = _.A(a)
    };
    _.T(vh, _.B);
    var uh = function(a) {
        this.D = _.A(a)
    };
    _.T(uh, _.B);
    var th = function(a) {
        this.D = _.A(a)
    };
    _.T(th, _.B);
    th.prototype.getVersion = function() {
        return _.Ct(this, 1)
    };
    var xh = function(a) {
        this.D = _.A(a)
    };
    _.T(xh, _.B);
    var iF = function(a) {
        this.D = _.A(a)
    };
    _.T(iF, _.B);
    var wh = function(a) {
        var b = new iF;
        return _.Wg(b, 1, a)
    };
    var sh = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        rh = 6 + sh.reduce(function(a, b) {
            return a + b
        });
    var Ch = function(a) {
        this.D = _.A(a)
    };
    _.T(Ch, _.B);
    var Bh = function(a) {
        this.D = _.A(a)
    };
    _.T(Bh, _.B);
    Bh.prototype.getVersion = function() {
        return _.Ct(this, 1)
    };
    var Ah = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        zh = 6 + Ah.reduce(function(a, b) {
            return a + b
        });
    var jF = function(a) {
        this.D = _.A(a)
    };
    _.T(jF, _.B);
    var kF = function(a) {
        this.D = _.A(a)
    };
    _.T(kF, _.B);
    var lF = function(a, b) {
            return _.Ve(a, 1, b, _.Vc)
        },
        mF = function(a, b) {
            return _.Ve(a, 2, b, _.Vc)
        },
        nF = function(a, b) {
            return _.Ve(a, 3, b, Yc)
        },
        oF = function(a, b) {
            _.Ve(a, 4, b, Yc)
        };
    var pF = function(a) {
        this.D = _.A(a)
    };
    _.T(pF, _.B);
    var qF = function(a) {
        this.D = _.A(a)
    };
    _.T(qF, _.B);
    qF.prototype.getVersion = function() {
        return _.Ct(this, 1)
    };
    var rF = function(a, b) {
            return _.Pg(a, 1, b)
        },
        sF = function(a, b) {
            return _.Wg(a, 2, b)
        },
        tF = function(a, b) {
            return _.Wg(a, 3, b)
        },
        uF = function(a, b) {
            return _.Pg(a, 4, b)
        },
        vF = function(a, b) {
            return _.Pg(a, 5, b)
        },
        wF = function(a, b) {
            return _.Pg(a, 6, b)
        },
        xF = function(a, b) {
            return _.Ek(a, 7, b)
        },
        yF = function(a, b) {
            return _.Pg(a, 8, b)
        },
        zF = function(a, b) {
            return _.Pg(a, 9, b)
        },
        AF = function(a, b) {
            return _.$g(a, 10, b)
        },
        BF = function(a, b) {
            return _.$g(a, 11, b)
        },
        CF = function(a, b) {
            return _.Ve(a, 12, b, _.Vc)
        },
        DF = function(a, b) {
            return _.Ve(a, 13, b, _.Vc)
        },
        EF = function(a, b) {
            return _.Ve(a, 14, b, _.Vc)
        },
        FF = function(a, b) {
            return _.$g(a, 15, b)
        },
        GF = function(a, b) {
            return _.Ek(a, 16, b)
        },
        HF = function(a, b) {
            return _.Ve(a, 17, b, Yc)
        },
        IF = function(a, b) {
            return _.Ve(a, 18, b, Yc)
        },
        JF = function(a, b) {
            return _.Qn(a, 19, b)
        };
    var KF = function(a) {
        this.D = _.A(a)
    };
    _.T(KF, _.B);
    var LF = "a".charCodeAt(),
        MF = Dg($E),
        NF = Dg(aF);
    var OF = function(a) {
            if (/[^01]/.test(a)) throw Error("Input bitstring " + a + " is malformed!");
            this.o = a;
            this.g = 0
        },
        QF = function(a) {
            a = PF(a, 36);
            var b = new pF;
            b = _.Fk(b, 1, Math.floor(a / 10));
            return _.Pg(b, 2, a % 10 * 1E8)
        },
        RF = function(a) {
            return String.fromCharCode(LF + PF(a, 6)) + String.fromCharCode(LF + PF(a, 6))
        },
        UF = function(a) {
            var b = PF(a, 16);
            return !!PF(a, 1) === !0 ? (a = SF(a), a.forEach(function(c) {
                if (c > b) throw Error("ID " + c + " is past MaxVendorId " + b + "!");
            }), a) : TF(a, b)
        },
        VF = function(a) {
            for (var b = [], c = PF(a, 12); c--;) {
                var d = PF(a, 6),
                    e = PF(a, 2),
                    f = SF(a),
                    g = b,
                    h = g.push,
                    l = new jF;
                d = _.H(l, 1, d);
                e = _.H(d, 2, e);
                f = _.Ve(e, 3, f, Yc);
                h.call(g, f)
            }
            return b
        },
        SF = function(a) {
            for (var b = PF(a, 12), c = []; b--;) {
                var d = !!PF(a, 1) === !0,
                    e = PF(a, 16);
                if (d)
                    for (d = PF(a, 16); e <= d; e++) c.push(e);
                else c.push(e)
            }
            c.sort(function(f, g) {
                return f - g
            });
            return c
        },
        TF = function(a, b, c) {
            for (var d = [], e = 0; e < b; e++)
                if (PF(a, 1)) {
                    var f = e + 1;
                    if (c && c.indexOf(f) === -1) throw Error("ID: " + f + " is outside of allowed values!");
                    d.push(f)
                }
            return d
        },
        PF = function(a, b) {
            if (a.g + b > a.o.length) throw Error("Requested length " + b + " is past end of string.");
            var c = a.o.substring(a.g, a.g + b);
            a.g += b;
            return parseInt(c, 2)
        };
    OF.prototype.skip = function(a) {
        this.g += a
    };
    var WF = function(a) {
        try {
            var b = Jg(a).map(function(f) {
                    return (_.E = f.toString(2), _.w(_.E, "padStart")).call(_.E, 8, "0")
                }).join(""),
                c = new OF(b);
            if (PF(c, 3) !== 3) return null;
            var d = mF(lF(new kF, TF(c, 24, MF)), TF(c, 24, MF)),
                e = PF(c, 6);
            e !== 0 && oF(nF(d, TF(c, e)), TF(c, e));
            return d
        } catch (f) {
            return null
        }
    };
    var XF = function(a) {
        try {
            var b = Jg(a).map(function(d) {
                    return (_.E = d.toString(2), _.w(_.E, "padStart")).call(_.E, 8, "0")
                }).join(""),
                c = new OF(b);
            return JF(IF(HF(GF(FF(EF(DF(CF(BF(AF(zF(yF(xF(wF(vF(uF(tF(sF(rF(new qF, PF(c, 6)), QF(c)), QF(c)), PF(c, 12)), PF(c, 12)), PF(c, 6)), RF(c)), PF(c, 12)), PF(c, 6)), !!PF(c, 1)), !!PF(c, 1)), TF(c, 12, NF)), TF(c, 24, MF)), TF(c, 24, MF)), !!PF(c, 1)), RF(c)), UF(c)), UF(c)), VF(c))
        } catch (d) {
            return null
        }
    };
    var ZF = function(a) {
            if (!a) return null;
            var b = a.split(".");
            if (b.length > 4) return null;
            a = XF(b[0]);
            if (!a) return null;
            var c = new KF;
            a = _.Wg(c, 1, a);
            b.shift();
            b = _.y(b);
            for (c = b.next(); !c.done; c = b.next()) switch (c = c.value, YF(c)) {
                case 1:
                case 2:
                    break;
                case 3:
                    c = WF(c);
                    if (!c) return null;
                    _.Wg(a, 2, c);
                    break;
                default:
                    return null
            }
            return a
        },
        YF = function(a) {
            try {
                var b = Jg(a).map(function(c) {
                    return (_.E = c.toString(2), _.w(_.E, "padStart")).call(_.E, 8, "0")
                }).join("");
                return PF(new OF(b), 3)
            } catch (c) {
                return -1
            }
        };
    var aG = function(a) {
            var b = ZF(a);
            if (!b || !a) return null;
            var c = _.Fi(b, qF, 1),
                d = _.Fi(b, kF, 2) || new kF;
            b = _.Ct(c, 9);
            var e = _.Ct(c, 4),
                f = _.Ct(c, 5),
                g = _.R(c, 10),
                h = _.R(c, 11),
                l = _.t(c, 16),
                k = _.R(c, 15);
            var m = _.DA(c, 13);
            m = $F(m, MF);
            var n = _.DA(c, 14);
            m = {
                consents: m,
                legitimateInterests: $F(n, MF)
            };
            n = Dv(c, 17);
            n = $F(n);
            var p = Dv(c, 18);
            n = {
                consents: n,
                legitimateInterests: $F(p)
            };
            p = _.DA(c, 12);
            p = $F(p, NF);
            var r = _.ul(c, jF, 19, _.wl());
            c = {};
            r = _.y(r);
            for (var v = r.next(); !v.done; v = r.next()) {
                v = v.value;
                var u = _.Sh(v, 1, 0);
                c[u] = c[u] || {};
                for (var x = _.y(Dv(v, 3)), D = x.next(); !D.done; D = x.next()) c[u][D.value] = _.Sh(v, 2, 0)
            }
            r = _.DA(d, 1);
            r = $F(r, MF);
            v = _.DA(d, 2);
            v = $F(v, MF);
            u = Dv(d, 3);
            u = $F(u);
            d = Dv(d, 4);
            return {
                tcString: a,
                tcfPolicyVersion: b,
                gdprApplies: !0,
                cmpId: e,
                cmpVersion: f,
                isServiceSpecific: g,
                useNonStandardStacks: h,
                publisherCC: l,
                purposeOneTreatment: k,
                purpose: m,
                vendor: n,
                specialFeatureOptins: p,
                publisher: {
                    restrictions: c,
                    consents: r,
                    legitimateInterests: v,
                    customPurposes: {
                        consents: u,
                        legitimateInterests: $F(d)
                    }
                }
            }
        },
        $F = function(a, b) {
            var c = {};
            if (Array.isArray(b) && b.length !== 0) {
                b = _.y(b);
                for (var d = b.next(); !d.done; d = b.next()) d = d.value, c[d] = a.indexOf(d) !== -1
            } else
                for (a = _.y(a), b = a.next(); !b.done; b = a.next()) c[b.value] = !0;
            delete c[0];
            return c
        };
    var bG = function(a) {
        this.D = _.A(a)
    };
    _.T(bG, _.B);
    var Nh = _.$f([0, _.vB, _.nB]);
    _.cG = function(a) {
        return !!(a.error && a.meta && a.id)
    };
    var dG = function(a, b, c, d, e) {
            Hh(a, b, c === void 0 ? null : c, d === void 0 ? !1 : d, e === void 0 ? !1 : e)
        },
        Rh = function(a, b) {
            var c = c === void 0 ? !1 : c;
            var d = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + b;
            _.$o(a, function(e, f) {
                if (e || e === 0) d += "&" + f + "=" + encodeURIComponent("" + e)
            });
            sv(d, c)
        },
        sv = function(a, b) {
            var c = window;
            b = b === void 0 ? !1 : b;
            var d = d === void 0 ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : dG(c, a, void 0, b, d)
        };
    var eG = function(a, b) {
        var c = new bG;
        a = _.H(c, 1, a);
        b = _.Ek(a, 2, b);
        this.l = _.we(b)
    };
    var fG = function(a) {
        this.D = _.A(a)
    };
    _.T(fG, _.B);
    var hG = function(a, b) {
            return Ck(a, 1, gG, Cd(b))
        },
        iG = function(a, b) {
            return Ck(a, 2, gG, id(b))
        },
        jG = function(a, b) {
            return Ck(a, 3, gG, b == null ? b : Qc(b))
        },
        gG = [1, 2, 3];
    var kG = [0, gG, oB, cB, kB];
    var lG = function(a) {
        this.D = _.A(a)
    };
    _.T(lG, _.B);
    var nG = function(a, b) {
            return Ck(a, 2, mG, id(b))
        },
        oG = function(a, b) {
            return Ck(a, 4, mG, _.Mc(b))
        },
        mG = [2, 4];
    var pG = [0, mG, 1, cB, 1, YA];
    var qG = function(a) {
        this.D = _.A(a)
    };
    _.T(qG, _.B);
    var rG = function(a) {
            var b = new qG;
            return _.Ek(b, 1, a)
        },
        sG = function(a, b) {
            return _.Wg(a, 3, b)
        },
        tG = function(a, b) {
            return Fl(a, 4, fG, b)
        };
    var uG = _.$f([0, _.nB, 1, pG, _.pB, kG]);
    var lm = function(a) {
        this.D = _.A(a)
    };
    _.T(lm, _.B);
    lm.prototype.getTagSessionCorrelator = function() {
        return zA(this, 1)
    };
    var km = function(a, b) {
            return _.Fk(a, 1, b)
        },
        jm = function(a, b) {
            return _.Fk(a, 2, b)
        };
    var vG = _.$f([0, _.bB, -1, _.vB]);
    var wG = function(a) {
        this.D = _.A(a)
    };
    _.T(wG, _.B);
    var xG = _.$f([0, _.bB, cF]);
    var yG = function(a) {
        this.D = _.A(a)
    };
    _.T(yG, _.B);
    yG.prototype.getAdUnitPath = function() {
        return _.t(this, 1)
    };
    var zG = function(a) {
            var b = new yG;
            return _.tj(b, 1, a)
        },
        AG = function(a, b) {
            return _.tj(a, 2, b)
        },
        BG = function(a, b) {
            return _.Dq(a, 3, b)
        },
        CG = function(a, b) {
            return _.Dq(a, 4, b)
        };
    var DG = [0, _.lB, -1, _.eB, -1];
    var EG = function(a) {
        this.D = _.A(a)
    };
    _.T(EG, _.B);
    EG.prototype.getTagSessionCorrelator = function() {
        return zA(this, 1)
    };
    var FG = [3];
    var GG = _.$f([0, FG, _.bB, -1, _.rB, DG]);
    var HG = function(a) {
        this.D = _.A(a)
    };
    _.T(HG, _.B);
    var IG = [0, _.gB, _.bB, _.jB];
    var JG = function(a) {
        this.D = _.A(a)
    };
    _.T(JG, _.B);
    var KG = [0, _.gB, -1, _.bB];
    var nn = function(a) {
        this.D = _.A(a)
    };
    _.T(nn, _.B);
    var LG = [0, _.vB, _.gB];
    var dn = function(a) {
        this.D = _.A(a)
    };
    _.T(dn, _.B);
    var MG = [0, _.jB, _.gB, _.jB, _.gB, _.jB, _.gB];
    var cn = function(a) {
        this.D = _.A(a)
    };
    _.T(cn, _.B);
    var NG = [0, _.jB, _.bB, MG];
    var $m = function(a) {
        this.D = _.A(a)
    };
    _.T($m, _.B);
    var OG = [0, _.bB, -2];
    var jn = function(a) {
        this.D = _.A(a)
    };
    _.T(jn, _.B);
    var PG = [0, _.bB];
    var QG = function(a) {
        this.D = _.A(a)
    };
    _.T(QG, _.B);
    var RG = function(a) {
        this.D = _.A(a)
    };
    _.T(RG, _.B);
    var SG = [0, _.jB, -1];
    var Zm = function(a) {
        this.D = _.A(a)
    };
    _.T(Zm, _.B);
    Zm.prototype.getTagSessionCorrelator = function() {
        return zA(this, 2)
    };
    var hn = function(a) {
            var b = new QG;
            return _.en(a, 13, fn, b)
        },
        fn = [6, 7, 8, 9, 11, 13, 14];
    var TG = _.$f([0, fn, _.bB, -1, _.nB, fB, _.bB, _.rB, NG, _.rB, IG, _.rB, KG, _.rB, LG, OG, _.rB, SG, _.nB, _.rB, [0], _.rB, PG]);
    var UG = [0, _.lB];
    var VG = function(a) {
        this.D = _.A(a)
    };
    _.T(VG, _.B);
    var WG = [0, _.eB, _.iB];
    var XG = function(a) {
        this.D = _.A(a)
    };
    _.T(XG, _.B);
    var YG = [0, _.eB];
    var Bq = function(a) {
        this.D = _.A(a)
    };
    _.T(Bq, _.B);
    var ZG = [0, _.eB, -1];
    var $G = function(a) {
        this.D = _.A(a)
    };
    _.T($G, _.B);
    $G.prototype.getContent = function() {
        return _.t(this, 1)
    };
    $G.prototype.setContent = function(a) {
        return _.tj(this, 1, a)
    };
    var aH = [0, _.lB];
    var bH = function(a) {
        this.D = _.A(a)
    };
    _.T(bH, _.B);
    var cH = function(a, b) {
        return _.Qn(a, 1, b)
    };
    var dH = [0, _.pB, aH];
    _.Bk = function(a) {
        this.D = _.A(a)
    };
    _.T(_.Bk, _.B);
    _.Bk.prototype.getTagSessionCorrelator = function() {
        return zA(this, 8)
    };
    _.Ak = function(a, b) {
        return _.Pg(a, 10, b)
    };
    _.Dk = [3, 4, 6];
    var zq = function(a) {
        this.D = _.A(a)
    };
    _.T(zq, _.B);
    var eH = function(a) {
            var b = new zq;
            return _.en(b, 2, Cq, a)
        },
        fH = function(a, b) {
            return _.en(a, 9, Cq, b)
        },
        Cq = [1, 2, 4, 5, 6, 8, 9];
    var gH = [0, _.Dk, _.gB, 1, wB, cB, cF, _.rB, [0, [0, tB], _.nB], _.bB, -1, _.nB, _.gB, _.nB];
    var hH = [0, Cq, _.rB, ZG, _.rB, WG, 1, _.rB, gH, _.rB, YG, _.rB, UG, 1, _.rB, aH, _.rB, dH];
    var tq = function(a) {
        this.D = _.A(a)
    };
    _.T(tq, _.B);
    var pq = function(a, b) {
        return _.Fk(a, 1, b)
    };
    tq.prototype.getTagSessionCorrelator = function() {
        return zA(this, 2)
    };
    var sq = function(a, b) {
            return _.Fk(a, 2, b)
        },
        rq = function(a, b) {
            return _.Ek(a, 3, b)
        },
        oq = function(a) {
            var b = Ui();
            return _.Ve(a, 4, b, Yc)
        },
        vq = function(a, b) {
            return _.Fk(a, 5, b)
        },
        qq = function(a, b) {
            return _.Ek(a, 6, b)
        },
        uq = function(a, b) {
            return _.Wg(a, 7, b)
        };
    var iH = _.$f([0, _.bB, -1, _.nB, fB, _.bB, _.nB, hH]);
    var jH = [0, _.nB, -2, _.vB, _.nB];
    var kH = _.$f(gH);
    var lH = [0, _.nB, -1, _.lB, [0, fB]];
    var mH = function(a) {
        this.D = _.A(a)
    };
    _.T(mH, _.B);
    var nH = [0, _.nB, _.gB, _.mB];
    var oH = [0, [1], _.rB, [0, jH],
        [0, _.bB, -1]
    ];
    var pH = [0, [0, _.aB, hB, -1], _.nB];
    var qH = [0, _.nB, -1, _.mB, -1, pH];
    var rH = function(a) {
        this.D = _.A(a)
    };
    _.T(rH, _.B);
    var sH = [0, _.vB, _.nB, -1, _.mB, -1, pH];
    var tH = function(a) {
        this.D = _.A(a)
    };
    _.T(tH, _.B);
    tH.prototype.getTagSessionCorrelator = function() {
        return zA(this, 1)
    };
    var uH = [0, _.bB, fB, _.nB];
    var vH = function(a) {
        this.D = _.A(a)
    };
    _.T(vH, _.B);
    var wH = [1, 7],
        xH = [4, 6, 8];
    var yH = _.$f([0, wH, xH, _.rB, sH, uH, 1, _.rB, nH, _.bB, _.rB, lH, _.rB, qH, _.rB, oH]);
    var zH = function(a) {
        this.D = _.A(a)
    };
    _.T(zH, _.B);
    var AH = function(a, b) {
            return _.tj(a, 1, b)
        },
        BH = function(a, b) {
            return _.Dm(a, 3, b)
        };
    var CH = [0, _.lB, fB, _.aB, -1];
    var DH = function(a) {
        this.D = _.A(a)
    };
    _.T(DH, _.B);
    var EH = function(a, b) {
        return _.tj(a, 1, b)
    };
    var FH = [0, _.lB, _.mB];
    var GH = function(a) {
        this.D = _.A(a)
    };
    _.T(GH, _.B);
    var HH = function(a, b) {
            return _.tj(a, 1, b)
        },
        IH = function(a, b) {
            return _.Dq(a, 2, b)
        };
    var JH = [0, _.lB, _.eB, _.pB, FH];
    var KH = function(a) {
        this.D = _.A(a)
    };
    _.T(KH, _.B);
    var LH = [0, _.pB, JH];
    var MH = function(a) {
        this.D = _.A(a)
    };
    _.T(MH, _.B);
    MH.prototype.getTagSessionCorrelator = function() {
        return zA(this, 1)
    };
    var NH = function(a, b) {
            return _.Fk(a, 1, b)
        },
        OH = function(a, b) {
            return _.Fk(a, 2, b)
        },
        PH = function(a) {
            var b = Ui();
            return _.Ve(a, 4, b, Yc)
        },
        QH = [3, 5];
    var RH = _.$f([0, QH, _.bB, -1, _.rB, CH, fB, _.rB, LH]);
    var Ur = function(a) {
        this.D = _.A(a)
    };
    _.T(Ur, _.B);
    Ur.prototype.getTagSessionCorrelator = function() {
        return zA(this, 1)
    };
    Ur.prototype.getMessageId = function() {
        return _.Sh(this, 8, 0)
    };
    Ur.prototype.getMessageArgs = function(a) {
        return CA(this, 9, a)
    };
    var SH = _.$f([0, _.bB, fB, _.nB, -1, _.bB, _.vB, _.nB, _.vB, _.mB, _.nB, -1, _.mB]);
    var Tt = function(a) {
        this.D = _.A(a)
    };
    _.T(Tt, _.B);
    Tt.prototype.getTagSessionCorrelator = function() {
        return zA(this, 1)
    };
    Tt.prototype.getAdUnitPath = function() {
        return _.t(this, 8)
    };
    var TH = _.$f([0, _.bB, fB, _.nB, 1, _.bB, _.gB, _.nB, -1]);
    var Gv = function(a) {
        this.D = _.A(a)
    };
    _.T(Gv, _.B);
    var UH = [0, _.gB, _.nB, _.vB, _.nB];
    var Hv = function(a) {
        this.D = _.A(a)
    };
    _.T(Hv, _.B);
    var Iv = [3];
    var VH = _.$f([0, Iv, _.gB, cF, _.rB, UH]);
    var XH = function(a) {
            this.M = a;
            this.Ma = new WH(this.M)
        },
        WH = function(a) {
            this.M = a;
            this.hb = new YH(this.M);
            this.Xe = new ZH(this.M)
        },
        YH = function(a) {
            this.M = a;
            this.yj = new $H(this.M);
            this.Ej = new aI(this.M);
            this.Kj = new bI(this.M);
            this.outstream = new cI(this.M);
            this.li = new dI(this.M);
            this.request = new eI(this.M);
            this.threadYield = new fI(this.M);
            this.Yi = new gI(this.M);
            this.lm = new hI(this.M)
        },
        gI = function(a) {
            this.M = a
        };
    gI.prototype.ta = function(a) {
        this.M.Ua(sG(tG(tG(tG(tG(rG("qVcX5d"), jG(new fG, a.Tj)), jG(new fG, a.Bk)), jG(new fG, a.qk)), jG(new fG, a.yk)), nG(new lG, Uh(a.wa))))
    };
    var hI = function(a) {
        this.M = a
    };
    hI.prototype.ta = function(a) {
        this.M.Ua(sG(rG("oHc1rb"), nG(new lG, Uh(a.wa))))
    };
    var $H = function(a) {
            this.M = a;
            this.globalPrivacyControl = new iI(this.M)
        },
        iI = function(a) {
            this.M = a
        };
    iI.prototype.ta = function(a) {
        this.M.Ua(sG(tG(tG(rG("V6BGRd"), jG(new fG, a.rk)), jG(new fG, a.sk)), nG(new lG, Uh(a.wa))))
    };
    var aI = function(a) {
            this.M = a;
            this.Om = new jI(this.M);
            this.Sn = new kI(this.M)
        },
        jI = function(a) {
            this.M = a
        };
    jI.prototype.wb = function(a) {
        this.M.Ua(sG(tG(tG(rG("C2uQt"), jG(new fG, a.didTimeout)), iG(new fG, Uh(a.Fp))), oG(new lG, a.xb)))
    };
    var kI = function(a) {
        this.M = a
    };
    kI.prototype.wb = function(a) {
        this.M.Ua(sG(rG("iAwBu"), oG(new lG, a.xb)))
    };
    var bI = function(a) {
            this.M = a;
            this.Bm = new lI(this.M);
            this.Cm = new mI(this.M)
        },
        lI = function(a) {
            this.M = a
        };
    lI.prototype.ta = function(a) {
        this.M.Ua(sG(tG(tG(rG("G72In"), iG(new fG, Uh(a.Ph))), iG(new fG, Uh(a.ie))), nG(new lG, Uh(a.wa))))
    };
    var mI = function(a) {
        this.M = a
    };
    mI.prototype.ta = function(a) {
        this.M.Ua(sG(tG(tG(rG("djpR8c"), iG(new fG, Uh(a.Ph))), iG(new fG, Uh(a.ie))), nG(new lG, Uh(a.wa))))
    };
    var cI = function(a) {
            this.M = a;
            this.kn = new nI(this.M)
        },
        nI = function(a) {
            this.M = a
        };
    nI.prototype.ta = function(a) {
        this.M.Ua(sG(tG(rG("joavYe"), jG(new fG, a.gk)), nG(new lG, Uh(a.wa))))
    };
    var dI = function(a) {
            this.M = a;
            this.Mm = new oI(this.M);
            this.Fn = new pI(this.M);
            this.no = new qI(this.M)
        },
        oI = function(a) {
            this.M = a
        };
    oI.prototype.wb = function(a) {
        this.M.Ua(sG(tG(rG("WaFkbc"), iG(new fG, Uh(a.dn))), oG(new lG, a.xb)))
    };
    var pI = function(a) {
        this.M = a
    };
    pI.prototype.wb = function(a) {
        this.M.Ua(sG(rG("GodZ8d"), oG(new lG, a.xb)))
    };
    var qI = function(a) {
        this.M = a
    };
    qI.prototype.wb = function(a) {
        this.M.Ua(sG(tG(tG(rG("tyEtBf"), iG(new fG, Uh(a.xo))), jG(new fG, a.Jn)), oG(new lG, a.xb)))
    };
    var eI = function(a) {
            this.M = a;
            this.jp = new rI(this.M)
        },
        rI = function(a) {
            this.M = a
        };
    rI.prototype.ta = function(a) {
        this.M.Ua(sG(tG(tG(tG(rG("tsK0dd"), hG(new fG, a.status)), iG(new fG, Uh(a.lo))), iG(new fG, Uh(a.Pe))), nG(new lG, Uh(a.wa))))
    };
    var fI = function(a) {
            this.M = a;
            this.he = new sI(this.M);
            this.fo = new tI(this.M)
        },
        sI = function(a) {
            this.M = a
        };
    sI.prototype.ta = function(a) {
        this.M.Ua(sG(tG(rG("yVu0td"), iG(new fG, a.reason)), nG(new lG, Uh(a.wa))))
    };
    var tI = function(a) {
        this.M = a
    };
    tI.prototype.wb = function(a) {
        this.M.Ua(sG(tG(rG("gXJzCb"), iG(new fG, a.sn)), oG(new lG, a.xb)))
    };
    var ZH = function(a) {
            this.M = a;
            this.Bi = new uI(this.M);
            this.mm = new vI(this.M);
            this.xm = new wI(this.M)
        },
        vI = function(a) {
            this.M = a
        };
    vI.prototype.wb = function(a) {
        this.M.Ua(sG(rG("rsv8Kc"), oG(new lG, a.xb)))
    };
    var wI = function(a) {
        this.M = a
    };
    wI.prototype.ta = function(a) {
        this.M.Ua(sG(tG(tG(rG("SOomke"), hG(new fG, a.Dg)), hG(new fG, a.status)), nG(new lG, Uh(a.wa))))
    };
    var uI = function(a) {
            this.M = a;
            this.Vi = new xI(this.M)
        },
        xI = function(a) {
            this.M = a
        };
    xI.prototype.ta = function(a) {
        this.M.Ua(sG(tG(rG("TP3y1d"), hG(new fG, a.status)), nG(new lG, Uh(a.wa))))
    };
    var yI = function() {
        eG.apply(this, arguments);
        this.La = new XH(this)
    };
    _.T(yI, eG);
    _.zI = function() {
        yI.apply(this, arguments)
    };
    _.T(_.zI, yI);
    _.q = _.zI.prototype;
    _.q.ll = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 2,
                vb: _.jf(a)
            }
        })))
    };
    _.q.Fc = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 5,
                vb: _.jf(a)
            }
        })))
    };
    _.q.ml = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 15,
                vb: _.jf(a)
            }
        })))
    };
    _.q.eg = ba(1);
    _.q.il = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 16,
                vb: _.jf(a)
            }
        })))
    };
    _.q.ql = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 17,
                vb: _.jf(a)
            }
        })))
    };
    _.q.nl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 19,
                vb: _.jf(a)
            }
        })))
    };
    _.q.tl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 21,
                vb: _.jf(a)
            }
        })))
    };
    _.q.jl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 23,
                vb: _.jf(a)
            }
        })))
    };
    _.q.rl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 24,
                vb: _.jf(a)
            }
        })))
    };
    _.q.pl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 26,
                vb: _.jf(a)
            }
        })))
    };
    _.q.kl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 28,
                vb: _.jf(a)
            }
        })))
    };
    _.q.Ua = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !1,
                za: 1,
                vb: _.jf(a)
            }
        })))
    };
    _.AI = function() {
        yI.apply(this, arguments)
    };
    _.T(_.AI, yI);
    _.q = _.AI.prototype;
    _.q.ll = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 2,
                yb: yH(a)
            }
        })))
    };
    _.q.Fc = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 5,
                yb: TG(a)
            }
        })))
    };
    _.q.ml = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 15,
                yb: iH(a)
            }
        })))
    };
    _.q.eg = ba(0);
    _.q.il = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 16,
                yb: vG(a)
            }
        })))
    };
    _.q.ql = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 17,
                yb: SH(a)
            }
        })))
    };
    _.q.nl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 19,
                yb: kH(a)
            }
        })))
    };
    _.q.tl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 21,
                yb: VH(a)
            }
        })))
    };
    _.q.jl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 23,
                yb: xG(a)
            }
        })))
    };
    _.q.rl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 24,
                yb: TH(a)
            }
        })))
    };
    _.q.pl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 26,
                yb: RH(a)
            }
        })))
    };
    _.q.kl = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !0,
                za: 28,
                yb: GG(a)
            }
        })))
    };
    _.q.Ua = function() {
        this.g.apply(this, _.Zk(_.Ia.apply(0, arguments).map(function(a) {
            return {
                ua: !1,
                za: 1,
                yb: uG(a)
            }
        })))
    };
    var im = function(a, b, c, d) {
        _.AI.call(this, a, b);
        this.j = c;
        this.o = d
    };
    _.T(im, _.AI);
    im.prototype.g = function() {
        var a = _.Ia.apply(0, arguments);
        try {
            var b = encodeURIComponent(Ab(Qh(a, this.l), 3));
            this.o(this.j + "?e=4&d=" + b)
        } catch (c) {
            Ih(c, this.l)
        }
    };
    var BI = function(a, b) {
        if (_.z.globalThis.fetch) _.z.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var CI = function(a, b, c, d, e, f, g, h) {
        _.zI.call(this, a, b);
        this.C = c;
        this.A = d;
        this.X = e;
        this.G = f;
        this.I = g;
        this.J = h;
        this.o = [];
        this.j = null;
        this.F = !1
    };
    _.T(CI, _.zI);
    var DI = function(a) {
        a.j !== null && (clearTimeout(a.j), a.j = null);
        if (a.o.length) {
            var b = Jh(a.o, a.l);
            a.A(a.C + "?e=1", b);
            a.o = []
        }
    };
    CI.prototype.g = function() {
        var a = _.Ia.apply(0, arguments),
            b = this;
        try {
            this.I && Jh(this.o.concat(a), this.l).length >= 65536 && DI(this), this.J && !this.F && (this.F = !0, this.J.g(function() {
                DI(b)
            })), this.o.push.apply(this.o, _.Zk(a)), this.o.length >= this.G && DI(this), this.o.length && this.j === null && (this.j = setTimeout(function() {
                DI(b)
            }, this.X))
        } catch (c) {
            Ih(c, this.l)
        }
    };
    var Ay = function(a, b, c, d, e, f) {
        CI.call(this, a, b, "https://pagead2.googlesyndication.com/pagead/ping", BI, c === void 0 ? 1E3 : c, d === void 0 ? 100 : d, (e === void 0 ? !1 : e) && !!_.z.globalThis.fetch, f)
    };
    _.T(Ay, CI);
    var EI, FI, GI;
    _.V = function(a, b) {
        this.g = a;
        this.defaultValue = b === void 0 ? !1 : b
    };
    EI = function(a, b) {
        this.g = a;
        this.defaultValue = b === void 0 ? 0 : b
    };
    FI = function(a, b) {
        this.g = a;
        this.defaultValue = b === void 0 ? "" : b
    };
    GI = function(a, b) {
        b = b === void 0 ? [] : b;
        this.g = a;
        this.defaultValue = b
    };
    var Qx, HI, is, II, JI, KI, LI, MI, NI, OI, PI, QI, RI, SI, TI, UI, VI, WI, $s, XI, Pw, Ow, YI, ZI, $I, Xt, aJ, bJ, cJ, dJ, eJ, fJ, gr, gJ, hJ, Sl, Rl, Tl, Kw, iJ, jJ, kJ, lJ, mJ, nJ, oJ, pJ, qJ, rJ, sJ, xJ, yJ, Mr, Fq, zJ, Jx, Lx, AJ, Ix, rw, CJ, ux, Jq, Gq, Mq, Ht, EJ, FJ, Nq, Oq, gq, GJ, HJ, xw, Hw, IJ, JJ, KJ, gx, Dx, wr, LJ, MJ, gy, NJ, Vo, So, OJ, PJ, QJ, RJ, SJ, TJ, UJ, WJ, XJ, Zx, YJ, ZJ, $J, aK, Rw, bK, cK, dK, eK, fK, $x, gK, hK, iK, jK, Am, kK, lK, ow, pw, mK, nK, oK, qw, pK, qK, rK, sK, tK, uK, vK, wK, Xu, Vu, Uu, Wu, $u, xK, py, qy, yK, ry, oy, zK, ty, AK;
    Qx = new _.V(673692256);
    HI = new _.V(629691748);
    is = new EI(7, .1);
    II = new _.V(658158409);
    JI = new _.V(212);
    KI = new GI(657770675);
    LI = new EI(659575329);
    MI = new EI(612427114);
    NI = new EI(643185309);
    OI = new EI(643185308);
    PI = new EI(663827948, -1);
    QI = new EI(659579380, -1);
    RI = new EI(659579379, -1);
    SI = new GI(655300591, ["1 dbm/(ad|clkk)"]);
    TI = new EI(643045660);
    UI = new _.V(665511636, !0);
    VI = new EI(643185311);
    WI = new EI(643185310);
    $s = new EI(612427113);
    XI = new EI(462420536);
    Pw = new FI(678438763);
    Ow = new EI(678438762);
    YI = new _.V(667673486);
    ZI = new EI(438663674);
    $I = new EI(564509649);
    Xt = new EI(578655462, 20);
    aJ = new _.V(558225291);
    bJ = new _.V(667794963);
    cJ = new _.V(691188989);
    dJ = new _.V(644381217);
    eJ = new _.V(644381218);
    fJ = new EI(632270607, 1E3);
    gr = new _.V(662648078);
    gJ = new EI(625028672, 50);
    hJ = new EI(629733890, 1E3);
    Sl = new EI(494575051);
    Rl = new GI(489560439);
    Tl = new GI(505762507);
    Kw = new _.V(453);
    iJ = new _.V(454);
    jJ = new EI(377289019, 1E4);
    kJ = new EI(529, 20);
    lJ = new FI(10);
    mJ = new EI(684553008, 100);
    nJ = new _.V(610525552);
    oJ = new _.V(45624259);
    pJ = new _.V(45627954, !0);
    qJ = new _.V(45646888);
    rJ = new _.V(45622305);
    sJ = new _.V(360245597, !0);
    _.tJ = new _.V(629201869);
    _.uJ = new _.V(479390945);
    _.vJ = new _.V(518650310);
    _.wJ = new EI(550718589, 250);
    xJ = new _.V(586382198);
    yJ = new EI(575880738, 10);
    Mr = new EI(586681283, 100);
    Fq = new _.V(630224494);
    zJ = new _.V(85);
    Jx = new _.V(689391026);
    Lx = new _.V(689391027);
    AJ = new EI(666954050);
    Ix = new EI(666954049);
    rw = new _.V(631604026);
    _.BJ = new _.V(684125058, !0);
    CJ = new EI(618260805, 10);
    ux = new _.V(524098256);
    Jq = new _.V(624264748);
    Gq = new _.V(624264747, !0);
    Mq = new _.V(624264746, !0);
    _.DJ = new _.V(677914770, !0);
    Ht = new EI(532520346, 120);
    EJ = new GI(466086960);
    FJ = new EI(630428304, 100);
    Nq = new _.V(624264749);
    Oq = new EI(624264750, -1);
    gq = new _.V(607106222, !0);
    GJ = new EI(398776877, 6E4);
    HJ = new EI(374201269, 6E4);
    xw = new EI(371364213, 6E4);
    Hw = new _.V(570764855, !0);
    IJ = new FI(579921177, "control_1\\.\\d");
    JJ = new EI(570764854, 50);
    KJ = new _.V(578725095, !0);
    gx = new _.V(633341243);
    Dx = new _.V(680619239, !0);
    wr = new function(a, b) {
        b = b === void 0 ? [] : b;
        this.g = a;
        this.defaultValue = b
    }(667640709);
    LJ = new _.V(671083854);
    MJ = new _.V(377936516, !0);
    gy = new EI(599575765, 1E3);
    NJ = new EI(24);
    Vo = new GI(1);
    So = new FI(2, "1-0-40");
    OJ = new _.V(608664189);
    PJ = new EI(626653285, 1E3);
    QJ = new EI(626653286, 2);
    RJ = new EI(642407444, 10);
    SJ = new _.V(686634849, !0);
    TJ = new _.V(686623671, !0);
    UJ = new _.V(673564232, !0);
    _.VJ = new EI(506394061, 100);
    WJ = new EI(665058368);
    XJ = new GI(631604025, ["95335247"]);
    Zx = new GI(489);
    YJ = new _.V(668156121);
    ZJ = new _.V(392065905);
    $J = new _.V(680005527);
    aK = new EI(360245595, 500);
    Rw = new _.V(682414837);
    bK = new _.V(668186629);
    cK = new _.V(561985307);
    dK = new EI(681088477, 100);
    eK = new _.V(616212168);
    fK = new _.V(676934885);
    $x = new _.V(424117738);
    gK = new _.V(563462360, !0);
    hK = new _.V(555237688);
    iK = new _.V(555237687);
    jK = new _.V(555237686);
    Am = new _.V(507033477, !0);
    kK = new EI(638742197, 500);
    lK = new _.V(636731477);
    ow = new _.V(399705355);
    pw = new EI(514795754, 2);
    mK = new _.V(638770075, !0);
    nK = new GI(663711111);
    oK = new GI(603422363, ["679602798", "965728666", "3786422334", "4071951799"]);
    qw = new _.V(590730356);
    pK = new _.V(564724551);
    qK = new EI(682021787);
    rK = new EI(596918936, 500);
    sK = new EI(607730666, 10);
    tK = new EI(641937776);
    uK = new _.V(630167509);
    vK = new _.V(647262744);
    wK = new _.V(616896918, !0);
    Xu = new _.V(638632925, !0);
    Vu = new _.V(647331452, !0);
    Uu = new _.V(647331451, !0);
    Wu = new _.V(638632927);
    $u = new _.V(673692257);
    xK = new _.V(506738118);
    py = new _.V(77);
    qy = new _.V(78);
    yK = new _.V(83);
    ry = new _.V(80);
    oy = new _.V(76);
    zK = new _.V(84);
    ty = new _.V(188);
    AK = new _.V(485990406);
    Dg($E).map(function(a) {
        return Number(a)
    });
    Dg(aF).map(function(a) {
        return Number(a)
    });
    var BK = function(a, b) {
        this.g = Yh(a);
        this.o = b
    };
    BK.prototype[_.w(_.z.Symbol, "iterator")] = function() {
        return this
    };
    BK.prototype.next = function() {
        var a = this.g.next();
        return {
            value: a.done ? void 0 : this.o.call(void 0, a.value),
            done: a.done
        }
    };
    var CK = function(a, b) {
            return new BK(a, b)
        },
        DK = function(a) {
            this.o = a;
            this.g = 0
        };
    DK.prototype[_.w(_.z.Symbol, "iterator")] = function() {
        return this
    };
    DK.prototype.next = function() {
        for (; this.g < this.o.length;) {
            var a = this.o[this.g].next();
            if (!a.done) return a;
            this.g++
        }
        return {
            done: !0
        }
    };
    var EK = function() {
        return new DK(_.Ia.apply(0, arguments).map(Yh))
    };
    var FK = _.ca.URL,
        GK;
    try {
        new FK("http://example.com"), GK = !0
    } catch (a) {
        GK = !1
    }
    var HK = GK,
        IK = function(a) {
            this.g = new _.z.Map;
            a.indexOf("?") == 0 && (a = a.substring(1));
            a = _.y(a.split("&"));
            for (var b = a.next(); !b.done; b = a.next()) {
                var c = b.value;
                b = c;
                var d = "";
                c = c.split("=");
                c.length > 1 && (b = decodeURIComponent(c[0].replace("+", " ")), d = decodeURIComponent(c[1].replace("+", " ")));
                c = this.g.get(b);
                c == null && (c = [], this.g.set(b, c));
                c.push(d)
            }
        };
    IK.prototype.get = function(a) {
        return (a = this.g.get(a)) && a.length ? a[0] : null
    };
    IK.prototype.getAll = function(a) {
        return [].concat(_.Zk(this.g.get(a) || []))
    };
    IK.prototype.has = function(a) {
        return this.g.has(a)
    };
    IK.prototype[_.w(_.z.Symbol, "iterator")] = function() {
        return EK.apply(null, _.Zk(CK(this.g, function(a) {
            var b = a[0];
            return CK(a[1], function(c) {
                return [b, c]
            })
        })))
    };
    IK.prototype.toString = function() {
        return ci(this)
    };
    var ci = function(a) {
            var b = function(c) {
                return encodeURIComponent(c).replace(/[!()~']|(%20)/g, function(d) {
                    return {
                        "!": "%21",
                        "(": "%28",
                        ")": "%29",
                        "%20": "+",
                        "'": "%27",
                        "~": "%7E"
                    }[d]
                })
            };
            return _.w(Array, "from").call(Array, a, function(c) {
                return b(c[0]) + "=" + b(c[1])
            }).join("&")
        },
        KK = function(a) {
            var b = _.KE(document, "A");
            try {
                _.Na(b, new Fa(a));
                var c = b.protocol
            } catch (e) {
                throw Error(a + " is not a valid URL.");
            }
            if (c === "" || c === ":" || c[c.length - 1] != ":") throw Error(a + " is not a valid URL.");
            if (!JK.has(c)) throw Error(a + " is not a valid URL.");
            if (!b.hostname) throw Error(a + " is not a valid URL.");
            var d = b.href;
            a = {
                href: d,
                protocol: b.protocol,
                username: "",
                password: "",
                hostname: b.hostname,
                pathname: "/" + b.pathname,
                search: b.search,
                hash: b.hash,
                toString: function() {
                    return d
                }
            };
            JK.get(b.protocol) === b.port ? (a.host = a.hostname, a.port = "", a.origin = a.protocol + "//" + a.hostname) : (a.host = b.host, a.port = b.port, a.origin = a.protocol + "//" + a.hostname + ":" + a.port);
            return a
        },
        $h = function(a) {
            if (HK) {
                try {
                    var b = new FK(a)
                } catch (d) {
                    throw Error(a + " is not a valid URL.");
                }
                var c = JK.get(b.protocol);
                if (!c) throw Error(a + " is not a valid URL.");
                if (!b.hostname) throw Error(a + " is not a valid URL.");
                b.origin == "null" && (a = {
                    href: b.href,
                    protocol: b.protocol,
                    username: "",
                    password: "",
                    host: b.host,
                    port: b.port,
                    hostname: b.hostname,
                    pathname: b.pathname,
                    search: b.search,
                    hash: b.hash
                }, a.origin = c === b.port ? b.protocol + "//" + b.hostname : b.protocol + "//" + b.hostname + ":" + b.port, b = a)
            } else b = KK(a);
            return b
        },
        JK = new _.z.Map([
            ["http:", "80"],
            ["https:", "443"],
            ["ws:", "80"],
            ["wss:", "443"],
            ["ftp:", "21"]
        ]),
        Zh = function(a) {
            return HK && a.searchParams ? a.searchParams : new IK(a.search)
        };
    var LK = function(a) {
        this.D = _.A(a)
    };
    _.T(LK, _.B);
    var MK = function(a) {
        this.D = _.A(a)
    };
    _.T(MK, _.B);
    var NK = function(a) {
        this.D = _.A(a)
    };
    _.T(NK, _.B);
    NK.prototype.getStatus = function() {
        return _.Fi(this, MK, 2)
    };
    var gi = bg(NK);
    _.W = function() {
        this.J = this.J;
        this.Va = this.Va
    };
    _.W.prototype.J = !1;
    _.W.prototype.dispose = function() {
        this.J || (this.J = !0, this.o())
    };
    _.W.prototype[_.w(_.z.Symbol, "dispose")] = function() {
        this.dispose()
    };
    _.Sq = function(a, b) {
        _.$q(a, _.qz(fi, b))
    };
    _.$q = function(a, b) {
        a.J ? b() : (a.Va || (a.Va = []), a.Va.push(b))
    };
    _.W.prototype.o = function() {
        if (this.Va)
            for (; this.Va.length;) this.Va.shift()()
    };
    var OK = function(a, b, c, d) {
        _.W.call(this);
        this.X = b;
        this.I = c;
        this.G = d;
        this.A = new _.z.Map;
        this.da = 0;
        this.F = new _.z.Map;
        this.C = new _.z.Map;
        this.j = void 0;
        this.l = a
    };
    _.T(OK, _.W);
    OK.prototype.o = function() {
        delete this.g;
        this.A.clear();
        this.F.clear();
        this.C.clear();
        this.j && (_.Gh(this.l, "message", this.j), delete this.j);
        delete this.l;
        delete this.G;
        _.W.prototype.o.call(this)
    };
    var PK = function(a) {
            if (a.g) return a.g;
            a.I && a.I(a.l) ? a.g = a.l : a.g = lE(a.l, a.X);
            var b;
            return (b = a.g) != null ? b : null
        },
        RK = function(a, b, c) {
            if (PK(a))
                if (a.g === a.l)(b = a.A.get(b)) && b(a.g, c);
                else {
                    var d = a.F.get(b);
                    if (d && d.Ae) {
                        QK(a);
                        var e = ++a.da;
                        a.C.set(e, {
                            Jd: d.Jd,
                            Rm: d.Jf(c),
                            persistent: b === "addEventListener"
                        });
                        a.g.postMessage(d.Ae(c, e), "*")
                    }
                }
        },
        QK = function(a) {
            a.j || (a.j = function(b) {
                try {
                    var c = a.G ? a.G(b) : void 0;
                    if (c) {
                        var d = c.ki,
                            e = a.C.get(d);
                        if (e) {
                            e.persistent || a.C.delete(d);
                            var f;
                            (f = e.Jd) == null || f.call(e, e.Rm, c.payload)
                        }
                    }
                } catch (g) {}
            }, _.sg(a.l, "message", a.j))
        };
    var SK = function(a, b) {
            var c = {
                cb: function(d) {
                    d = gi(d);
                    b.zd({
                        ee: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        TK = {
            Jf: function(a) {
                return a.zd
            },
            Ae: function(a, b) {
                return {
                    __fciCall: {
                        callId: b,
                        command: a.command,
                        spsp: a.spsp || void 0
                    }
                }
            },
            Jd: function(a, b) {
                a({
                    ee: b
                })
            }
        },
        UK = function(a) {
            _.W.call(this);
            this.g = this.l = !1;
            this.caller = new OK(a, "googlefcPresent", void 0, ii);
            this.caller.A.set("getDataWithCallback", SK);
            this.caller.F.set("getDataWithCallback", TK)
        };
    _.T(UK, _.W);
    UK.prototype.o = function() {
        this.caller.dispose();
        _.W.prototype.o.call(this)
    };
    UK.prototype.cc = function(a) {
        if (a === void 0 ? 0 : a) return !1;
        this.l || (this.g = !!PK(this.caller), this.l = !0);
        return this.g
    };
    var VK = function(a) {
            return new _.z.Promise(function(b) {
                a.cc() && RK(a.caller, "getDataWithCallback", {
                    command: "loaded",
                    zd: function(c) {
                        b(c.ee)
                    }
                })
            })
        },
        WK = function(a, b) {
            a.cc() && RK(a.caller, "getDataWithCallback", {
                command: "prov",
                spsp: Fm(b),
                zd: function() {}
            })
        };
    var XK = function(a, b) {
        b = b === void 0 ? {} : b;
        _.W.call(this);
        this.g = null;
        this.F = {};
        this.G = 0;
        this.j = null;
        this.l = a;
        var c;
        this.C = (c = b.timeoutMs) != null ? c : 500;
        var d;
        this.A = (d = b.qm) != null ? d : !1
    };
    _.T(XK, _.W);
    XK.prototype.o = function() {
        this.F = {};
        this.j && (_.Gh(this.l, "message", this.j), delete this.j);
        delete this.F;
        delete this.l;
        delete this.g;
        _.W.prototype.o.call(this)
    };
    XK.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.A
            },
            d = _.Rs(function() {
                return a(c)
            }),
            e = 0;
        this.C !== -1 && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.C));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = ji(c), c.internalBlockOnErrors = b.A, h && c.internalErrorState === 0 || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            YK(this, "addEventListener", f)
        } catch (g) {
            c.tcString = "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    XK.prototype.removeEventListener = function(a) {
        a && a.listenerId && YK(this, "removeEventListener", null, a.listenerId)
    };
    var aL = function(a, b) {
            b = b === void 0 ? {} : b;
            return ZK(a) ? a.gdprApplies === !1 ? !0 : a.tcString === "tcunavailable" ? !b.idpcApplies : (b.idpcApplies || a.gdprApplies !== void 0 || b.wr) && (b.idpcApplies || typeof a.tcString === "string" && a.tcString.length) ? $K(a, "1", 0) : !0 : !1
        },
        $K = function(a, b, c) {
            var d = d === void 0 ? "755" : d;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var e = a.publisher.restrictions[b];
                    if (e !== void 0) {
                        e = e[d === void 0 ? "755" : d];
                        break a
                    }
                }
                e = void 0
            }
            if (e === 0) return !1;
            var f = c;
            c === 2 ? (f = 0, e === 2 && (f = 1)) : c === 3 && (f = 1, e === 1 && (f = 0));
            a = f === 0 ? a.purpose && a.vendor ? (c = bL(a.vendor.consents, d === void 0 ? "755" : d)) && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH" ? !0 : c && bL(a.purpose.consents, b) : !0 : f === 1 ? a.purpose && a.vendor ? bL(a.purpose.legitimateInterests, b) && bL(a.vendor.legitimateInterests, d === void 0 ? "755" : d) : !0 : !0;
            return a
        },
        bL = function(a, b) {
            return !(!a || !a[b])
        },
        YK = function(a, b, c, d) {
            c || (c = function() {});
            var e = a.l;
            typeof e.__tcfapi === "function" ? (a = e.__tcfapi, a(b, 2, c, d)) : cL(a) ? (dL(a), e = ++a.G, a.F[e] = c, a.g && (c = {}, a.g.postMessage((c.__tcfapiCall = {
                command: b,
                version: 2,
                callId: e,
                parameter: d
            }, c), "*"))) : c({}, !1)
        },
        cL = function(a) {
            if (a.g) return a.g;
            a.g = lE(a.l, "__tcfapiLocator");
            return a.g
        },
        dL = function(a) {
            if (!a.j) {
                var b = function(c) {
                    try {
                        var d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                        a.F[d.callId](d.returnValue, d.success)
                    } catch (e) {}
                };
                a.j = b;
                _.sg(a.l, "message", b)
            }
        },
        ZK = function(a) {
            if (a.gdprApplies === !1) return !0;
            a.internalErrorState === void 0 && (a.internalErrorState = ji(a));
            return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (Rh({
                e: String(a.internalErrorState)
            }, "tcfe"), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
        },
        eL = function(a, b, c) {
            return a.gdprApplies === !1 ? !0 : b.every(function(d) {
                return $K(a, d, c)
            })
        };
    var ki = Ny(["https://fundingchoicesmessages.google.com/i/", ""]),
        fL = function(a, b, c) {
            this.B = a;
            this.o = b;
            this.g = c === void 0 ? function() {} : c;
            this.O = null
        },
        gL = function(a, b, c) {
            return new fL(a, b, c)
        };
    fL.prototype.start = function(a, b) {
        a = a === void 0 ? !1 : a;
        if (this.B === this.B.top) try {
            ei(this.B), hL(this, a, b)
        } catch (c) {}
    };
    var hL = function(a, b, c) {
        b = b === void 0 ? !1 : b;
        var d = {};
        try {
            var e = ai(a.B),
                f = bi(a.B);
            d.fc = e;
            d.fctype = f
        } catch (h) {}
        try {
            var g = di(a.B.location.href)
        } catch (h) {}
        b && g && (d.href = g);
        b = li(a.o, d);
        Xh(a.B, b, function() {
            a.g(!0)
        }, function() {
            a.g(!1)
        });
        c && WK(new UK(a.B), c)
    };
    var iL = _.z.Promise;
    var jL = function(a) {
        this.o = a
    };
    jL.prototype.send = function(a, b, c) {
        this.o.then(function(d) {
            d.send(a, b, c)
        })
    };
    jL.prototype.g = function(a, b) {
        return this.o.then(function(c) {
            return c.g(a, b)
        })
    };
    var kL = function(a) {
        this.data = a
    };
    var lL = function(a) {
        this.o = a
    };
    lL.prototype.send = function(a, b, c) {
        c = c === void 0 ? [] : c;
        var d = new MessageChannel;
        mL(d.port1, b);
        this.o.postMessage(a, [d.port2].concat(c))
    };
    lL.prototype.g = function(a, b) {
        var c = this;
        return new iL(function(d) {
            c.send(a, d, b)
        })
    };
    var nL = function(a, b) {
            mL(a, b);
            return new lL(a)
        },
        mL = function(a, b) {
            b && (a.onmessage = function(c) {
                b(new kL(c.data, nL(c.ports[0])))
            })
        };
    var oL = function(a) {
            this.g = a
        },
        pL = function(a) {
            var b = Object.create(null);
            (typeof a === "string" ? [a] : a).forEach(function(c) {
                if (c === "null") throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
                b[c] = !0
            });
            return function(c) {
                return b[c] === !0
            }
        };
    var ym = function(a) {
            var b = a.destination;
            var c = a.Fd;
            var d = a.origin;
            var e = a.Ob === void 0 ? "ZNWN1d" : a.Ob;
            var f = a.onMessage === void 0 ? void 0 : a.onMessage;
            a = a.Pf === void 0 ? void 0 : a.Pf;
            return qL({
                destination: b,
                bk: function() {
                    return c.contentWindow
                },
                zo: d instanceof oL ? d : typeof d === "function" ? new oL(d) : new oL(pL(d)),
                Ob: e,
                onMessage: f,
                Pf: a
            })
        },
        qL = function(a) {
            var b = a.destination;
            var c = a.bk;
            var d = a.zo;
            var e = a.token === void 0 ? void 0 : a.token;
            var f = a.Ob;
            var g = a.onMessage === void 0 ? void 0 : a.onMessage;
            var h = a.Pf === void 0 ? void 0 : a.Pf;
            return new jL(new iL(function(l, k) {
                var m = function(n) {
                    n.source && n.source === c() && d.g(n.origin) && (n.data.n || n.data) === f && (b.removeEventListener("message", m, !1), e && n.data.t !== e ? k(Error('Token mismatch while establishing channel "' + f + '". Expected ' + e + ", but received " + n.data.t + ".")) : (l(nL(n.ports[0], g)), h && h(n)))
                };
                b.addEventListener("message", m, !1)
            }))
        };
    var qi = function() {
        this.data = [];
        this.g = -1
    };
    qi.prototype.set = function(a, b) {
        b = b === void 0 ? !0 : b;
        0 <= a && a < 52 && _.w(Number, "isInteger").call(Number, a) && this.data[a] !== b && (this.data[a] = b, this.g = -1)
    };
    qi.prototype.get = function(a) {
        return !!this.data[a]
    };
    var si = function(a) {
        a.g === -1 && (a.g = a.data.reduce(function(b, c, d) {
            return b + (c ? Math.pow(2, d) : 0)
        }, 0));
        return a.g
    };
    var rL = function(a, b) {
            (0, a.__uspapi)("getUSPData", 1, function(c, d) {
                b.zd({
                    ee: c != null ? c : void 0,
                    Rj: d ? void 0 : 2
                })
            })
        },
        sL = {
            Jf: function(a) {
                return a.zd
            },
            Ae: function(a, b) {
                a = {};
                return a.__uspapiCall = {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }, a
            },
            Jd: function(a, b) {
                b = b.__uspapiReturn;
                var c;
                a({
                    ee: (c = b.returnValue) != null ? c : void 0,
                    Rj: b.success ? void 0 : 2
                })
            }
        },
        tL = function(a, b) {
            b = b === void 0 ? {} : b;
            _.W.call(this);
            var c;
            this.timeoutMs = (c = b.timeoutMs) != null ? c : 500;
            this.caller = new OK(a, "__uspapiLocator", function(d) {
                return typeof d.__uspapi === "function"
            }, ui);
            this.caller.A.set("getDataWithCallback", rL);
            this.caller.F.set("getDataWithCallback", sL)
        };
    _.T(tL, _.W);
    tL.prototype.o = function() {
        this.caller.dispose();
        _.W.prototype.o.call(this)
    };
    var uL = function(a, b) {
        var c = {};
        if (PK(a.caller)) {
            var d = _.Rs(function() {
                b(c)
            });
            RK(a.caller, "getDataWithCallback", {
                zd: function(e) {
                    e.Rj || (c = e.ee);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    };
    var Ci = function(a) {
        this.g = a || {
            cookie: ""
        }
    };
    _.q = Ci.prototype;
    _.q.isEnabled = function() {
        if (!_.ca.navigator.cookieEnabled) return !1;
        if (!this.isEmpty()) return !0;
        this.set("TESTCOOKIESENABLED", "1", {
            maxAge: 60
        });
        if (this.get("TESTCOOKIESENABLED") !== "1") return !1;
        this.remove("TESTCOOKIESENABLED");
        return !0
    };
    _.q.set = function(a, b, c) {
        var d = !1;
        if (typeof c === "object") {
            var e = c.sameSite;
            d = c.secure || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.maxAge
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        h === void 0 && (h = -1);
        c = f ? ";domain=" + f : "";
        g = g ? ";path=" + g : "";
        d = d ? ";secure" : "";
        h = h < 0 ? "" : h == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + h * 1E3)).toUTCString();
        this.g.cookie = a + "=" + b + c + g + h + d + (e != null ? ";samesite=" + e : "")
    };
    _.q.get = function(a, b) {
        for (var c = a + "=", d = (this.g.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = vz(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    _.q.remove = function(a, b, c) {
        var d = this.get(a) !== void 0;
        this.set(a, "", {
            maxAge: 0,
            path: b,
            domain: c
        });
        return d
    };
    _.q.isEmpty = function() {
        return !this.g.cookie
    };
    _.q.clear = function() {
        for (var a = (this.g.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = vz(a[f]), d = e.indexOf("="), d == -1 ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; a >= 0; a--) this.remove(b[a])
    };
    var vL = new Ci(typeof document == "undefined" ? null : document);
    var zi;
    var wL = function(a) {
        this.g = a
    };
    wL.prototype.isEnabled = function(a, b) {
        var c = b.Yf;
        b = b.Zf;
        return !Bi(this.g) || _.R(a, 8) || (c || !vi(a)) && b ? !1 : !0
    };
    var xL = function(a, b) {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        yL = function(a, b) {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        zL = {
            Jf: function(a) {
                return a.listener
            },
            Ae: function(a, b) {
                a = {};
                return a.__gppCall = {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }, a
            },
            Jd: function(a, b) {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        AL = {
            Jf: function(a) {
                return a.listener
            },
            Ae: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }, c
            },
            Jd: function(a, b) {
                b = b.__gppReturn;
                var c = b.returnValue.data;
                a == null || a(c, b.success)
            }
        },
        BL = function(a, b) {
            var c = b === void 0 ? {} : b;
            b = c.timeoutMs;
            c = c.cmpInteractionEventReporter;
            _.W.call(this);
            this.caller = new OK(a, "__gppLocator", function(d) {
                return typeof d.__gpp === "function"
            }, Ei);
            this.caller.A.set("addEventListener", xL);
            this.caller.F.set("addEventListener", zL);
            this.caller.A.set("removeEventListener", yL);
            this.caller.F.set("removeEventListener", AL);
            this.timeoutMs = b != null ? b : 500;
            this.cmpInteractionEventReporter = c
        };
    _.T(BL, _.W);
    BL.prototype.o = function() {
        this.caller.dispose();
        _.W.prototype.o.call(this)
    };
    BL.prototype.addEventListener = function(a) {
        var b = this,
            c = _.Rs(function() {
                a(CL, !0)
            }),
            d = this.timeoutMs === -1 ? void 0 : setTimeout(function() {
                c()
            }, this.timeoutMs);
        RK(this.caller, "addEventListener", {
            listener: function(e, f) {
                clearTimeout(d);
                try {
                    var g;
                    if (((g = e.pingData) == null ? void 0 : g.gppVersion) === void 0 || e.pingData.gppVersion === "1" || e.pingData.gppVersion === "1.0") {
                        b.removeEventListener(e.listenerId);
                        var h = {
                            eventName: "signalStatus",
                            data: "ready",
                            pingData: {
                                internalErrorState: 1,
                                gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                applicableSections: [-1]
                            }
                        }
                    } else Array.isArray(e.pingData.applicableSections) ? h = e : (b.removeEventListener(e.listenerId), h = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 2,
                            gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                            applicableSections: [-1]
                        }
                    });
                    a(h, f);
                    var l;
                    (l = b.cmpInteractionEventReporter) != null && l.g && l.M.jl(l.g)
                } catch (k) {
                    if (e == null ? 0 : e.listenerId) try {
                        b.removeEventListener(e.listenerId)
                    } catch (m) {
                        a(DL, !0);
                        return
                    }
                    a(EL, !0)
                }
            }
        })
    };
    BL.prototype.removeEventListener = function(a) {
        RK(this.caller, "removeEventListener", {
            listener: function() {},
            listenerId: a
        })
    };
    var kr = function(a, b) {
            var c = c === void 0 ? !1 : c;
            if (!a) return !1;
            var d = Rg(a.split("~")[0]);
            a = Ig(a);
            d = Dv(d, 3);
            for (var e = 0; e < d.length; ++e) {
                var f = d[e];
                if (_.w(b, "includes").call(b, f)) {
                    var g = a[e];
                    switch (f) {
                        case 2:
                            if (c) {
                                f = aG(g);
                                if (!f) throw Error("Cannot decode TCF V2 section string.");
                                if (!eL(f, ["3", "4"], 0)) return !0
                            }
                            break;
                        case 7:
                            if (Gi(yh(g))) return !0;
                            break;
                        case 8:
                            if (Hi(ah(g))) return !0;
                            break;
                        case 9:
                            if (Ii(Dh(g))) return !0;
                            break;
                        case 10:
                            if (Ji(hh(g))) return !0;
                            break;
                        case 12:
                            if (Ki(qh(g))) return !0
                    }
                }
            }
            return !1
        },
        hr = function(a, b, c) {
            var d = !(_.w(b, "includes").call(b, 2) && (c == null ? 0 : c.idpcApplies)),
                e = !1,
                f = !1;
            if (a && !_.w(a, "startsWith").call(a, "GPP_ERROR_STRING_")) {
                var g = Rg(a.split("~")[0]);
                a = Ig(a);
                g = Dv(g, 3);
                for (var h = 0; h < g.length; ++h) {
                    var l = g[h];
                    if (_.w(b, "includes").call(b, l)) {
                        var k = a[h];
                        switch (l) {
                            case 2:
                                l = void 0;
                                if ((l = c) == null ? 0 : l.supportTcfeu) {
                                    k = aG(k);
                                    if (!k) throw Error("Cannot decode TCF V2 section string.");
                                    d = aL(k);
                                    !eL(k, ["3", "4"], 0) && (e = !0);
                                    !eL(k, ["2", "7", "9", "10"], 3) && (f = !0)
                                }
                                break;
                            case 7:
                                Gi(yh(k)) && (e = !0);
                                break;
                            case 8:
                                Hi(ah(k)) && (e = !0);
                                break;
                            case 9:
                                Ii(Dh(k)) && (e = !0);
                                break;
                            case 10:
                                Ji(hh(k)) && (e = !0);
                                break;
                            case 12:
                                Ki(qh(k)) && (e = !0)
                        }
                    }
                }
            }
            return {
                zp: d,
                vo: e,
                Dp: f
            }
        },
        EL = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        CL = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        DL = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };
    var FL = function(a) {
        var b = _.K(fJ);
        b = b === void 0 ? 1E3 : b;
        this.kb = 17;
        this.M = a;
        this.Ta = b;
        b > 0 && _.$i() < 1 / b && (a = new wG, this.g = _.Fk(a, 1, b), _.Gk(_.Hk(this.g, _.Ik, 2), 17))
    };
    var GL = function(a) {
        _.W.call(this);
        this.value = a
    };
    _.T(GL, _.W);
    GL.prototype.get = function() {
        return this.value
    };
    var HL = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.w(Object, "setPrototypeOf").call(Object, this, HL.prototype)
    };
    _.T(HL, Error);
    HL.prototype.name = "PublisherInputError";
    var IL = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.w(Object, "setPrototypeOf").call(Object, this, IL.prototype)
    };
    _.T(IL, Error);
    IL.prototype.name = "ServerError";
    var JL = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.w(Object, "setPrototypeOf").call(Object, this, JL.prototype)
    };
    _.T(JL, Error);
    JL.prototype.name = "NetworkError";
    var KL = null,
        LL = function() {
            if (KL === null) {
                KL = "";
                try {
                    var a = "";
                    try {
                        a = _.ca.top.location.hash
                    } catch (c) {
                        a = _.ca.location.hash
                    }
                    if (a) {
                        var b = a.match(/\bdeid=([\d,]+)/);
                        KL = b ? b[1] : ""
                    }
                } catch (c) {}
            }
            return KL
        };
    _.Ri = function(a) {
        var b = "gd";
        if (a.gd && a.hasOwnProperty(b)) return a.gd;
        b = new a;
        return a.gd = b
    };
    var Si = function() {};
    Si.prototype.g = function() {};
    Si.prototype.l = function() {};
    Si.prototype.o = function() {
        return []
    };
    Si.prototype.j = function() {
        return []
    };
    var oj = function(a, b) {
        a.g = Qi(1, b, function() {});
        a.o = function(c, d) {
            return Qi(2, b, function() {
                return []
            })(c, 2, d)
        };
        a.j = function() {
            return Qi(3, b, function() {
                return []
            })(2)
        };
        a.l = function(c) {
            Qi(16, b, function() {})(c, 2)
        }
    };
    var cj = function() {
        var a = {};
        this.o = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.j = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.J = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.F = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.l = function(b, c) {
            return a[b] != null ? c.concat(a[b]) : c
        };
        this.g = function() {}
    };
    var ij = function() {
            this.g = function() {}
        },
        qj = function(a, b) {
            a.g = Qi(14, b, function() {})
        };
    var ML = _.$f(bF);
    var bo = function(a, b, c) {
            a && b !== null && b != b.top && (b = b.top);
            try {
                return (c === void 0 ? 0 : c) ? (new _.mo(b.innerWidth, b.innerHeight)).round() : _.HE(b || window).round()
            } catch (d) {
                return new _.mo(-12245933, -12245933)
            }
        },
        NL = function(a) {
            a = a === void 0 ? _.ca : a;
            a = a.devicePixelRatio;
            return typeof a === "number" ? +a.toFixed(3) : null
        },
        OL = function(a) {
            return a.compatMode == "CSS1Compat" ? a.documentElement : a.body
        },
        st = function(a, b) {
            b = b === void 0 ? _.ca : b;
            a = a.scrollingElement || OL(a);
            return new _.io(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
        },
        zo = function(a) {
            try {
                return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
            } catch (b) {
                return !1
            }
        },
        av = function(a, b) {
            var c = bo(!0, b),
                d = c.height;
            c = c.width;
            if (!a || a.y === -12245933 || d === -12245933 || c === -12245933 || !d) return null;
            c = 0;
            try {
                c = st(b.top.document, b.top).y
            } catch (e) {
                return null
            }
            b = c + d;
            return a.y < c ? c - a.y / d : a.y > b ? (a.y - b) / d : 0
        };
    var QL, RL;
    _.PL = function(a) {
        this.B = a
    };
    _.PL.prototype.isSupported = function(a) {
        return Bi(this.B) ? !!vi(a) : !1
    };
    _.gp = function(a, b, c) {
        return c ? yi(b, c, a.B) : null
    };
    QL = function(a, b, c, d) {
        if (d) {
            var e = _.hi(c, 2) - Date.now() / 1E3;
            e = {
                maxAge: Math.max(e, 0),
                path: _.t(c, 3),
                domain: _.t(c, 4),
                secure: !1
            };
            c = c.getValue();
            a = a.B;
            vi(d) && Di(b, c, e, a)
        }
    };
    RL = function(a, b, c) {
        if (c && yi(b, c, a.B)) {
            var d = a.B.location.hostname;
            if (d === "localhost") d = ["localhost"];
            else if (d = d.split("."), d.length < 2) d = [];
            else {
                for (var e = [], f = 0; f < d.length - 1; ++f) e.push(d.slice(f).join("."));
                d = e
            }
            d = _.y(d);
            for (var g = d.next(); !g.done; g = d.next()) e = b, f = a.B, g = g.value, vi(c) && f.origin !== "null" && (new Ci(f.document)).remove(e, "/", g)
        }
    };
    var SL = Ny(["https://s0.2mdn.net/ads/richmedia/studio/mu/templates/hifi/hifi.js"]),
        TL = Ny(["https://s0.2mdn.net/ads/richmedia/studio_canary/mu/templates/hifi/hifi_canary.js"]),
        UL = {},
        VL = (UL[3] = _.ng(SL), UL);
    ({})[3] = _.ng(TL);
    var WL = function(a) {
            this.g = a;
            this.o = Lz()
        },
        XL = function(a) {
            var b = {};
            _.Jz(a, function(c) {
                b[c.g] = c.o
            });
            return b
        };
    _.YL = Ny(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]);
    var By = function(a, b, c) {
        this.configuration = a;
        this.M = b;
        this.g = c
    };
    By.prototype.log = function(a, b, c) {
        var d, e = (d = c.Ta) != null ? d : this.configuration[a].Uc;
        e === 0 || 1 / e < this.g || (b = b(_.w(Object, "assign").call(Object, {}, {
            Ta: e
        }, c))) && this.configuration[a].send(this.M, b)
    };
    var ZL = function(a, b, c, d, e, f) {
        _.W.call(this);
        this.Ob = a;
        this.status = 1;
        this.j = b;
        this.l = c;
        this.I = d;
        this.te = !!e;
        this.F = Math.random();
        this.services = {};
        this.g = null;
        this.A = (0, _.pz)(this.G, this);
        this.P = f
    };
    _.T(ZL, _.W);
    ZL.prototype.G = function(a) {
        if (!(this.l !== "*" && a.origin !== this.l || !this.te && a.source != this.j)) {
            var b = null;
            try {
                b = JSON.parse(a.data)
            } catch (c) {}
            if (_.gb(b) && (a = b.i, b.c === this.Ob && a != this.F)) {
                if (this.status !== 2) this.onConnect();
                a = b.s;
                b = b.p;
                if (typeof a === "string" && (typeof b === "string" || _.gb(b)) && this.services.hasOwnProperty(a)) this.services[a](b)
            }
        }
    };
    var $L = function(a) {
        var b = {};
        b.c = a.Ob;
        b.i = a.F;
        a.P && (b.e = a.P);
        a.j.postMessage(JSON.stringify(b), a.l)
    };
    ZL.prototype.onConnect = function() {
        try {
            this.status = 2, $L(this), this.g && (this.g(), this.g = null)
        } catch (a) {}
    };
    ZL.prototype.C = function() {
        if (this.status === 1) {
            try {
                this.j.postMessage && $L(this)
            } catch (a) {}
            window.setTimeout((0, _.pz)(this.C, this), 50)
        }
    };
    ZL.prototype.connect = function(a) {
        a && (this.g = a);
        _.sg(window, "message", this.A);
        this.I && this.C()
    };
    var aM = function(a, b, c) {
        a.services[b] = c
    };
    ZL.prototype.send = function(a, b) {
        var c = {};
        c.c = this.Ob;
        c.i = this.F;
        c.s = a;
        c.p = b;
        try {
            this.j.postMessage(JSON.stringify(c), this.l)
        } catch (d) {}
    };
    ZL.prototype.o = function() {
        this.status = 3;
        _.Gh(window, "message", this.A);
        _.W.prototype.o.call(this)
    };
    var xj = new _.z.Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        yj = new _.z.Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]),
        Sw = function(a) {
            GL.call(this, zj(a) || 0);
            var b = this;
            a.addEventListener("pageshow", this.g.bind(this));
            _.$q(this, function() {
                a.removeEventListener("pageshow", b.g.bind(b))
            })
        };
    _.T(Sw, GL);
    Sw.prototype.g = function(a) {
        a.persisted && (this.value = 5)
    };
    var bM = function(a) {
        this.D = _.A(a)
    };
    _.T(bM, _.B);
    var cM = bg(bM);
    var dM = function(a) {
        this.D = _.A(a)
    };
    _.T(dM, _.B);
    var eM = function(a) {
        this.D = _.A(a)
    };
    _.T(eM, _.B);
    var fM, gM, hM, iM;
    _.pu = function(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    };
    fM = function(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    };
    gM = function(a) {
        return a.hidden != null ? a.hidden : a.mozHidden != null ? a.mozHidden : a.webkitHidden != null ? a.webkitHidden : null
    };
    hM = function(a, b) {
        if (_.pu(b) == 3) return !1;
        a();
        return !0
    };
    iM = function(a, b) {
        var c = !0;
        c = c === void 0 ? !1 : c;
        if (!hM(a, b))
            if (c) {
                var d = function() {
                    _.Gh(b, "prerenderingchange", d);
                    a()
                };
                _.sg(b, "prerenderingchange", d)
            } else {
                var e = !1,
                    f = fM(b),
                    g = function() {
                        !e && hM(a, b) && (e = !0, _.Gh(b, f, g))
                    };
                f && _.sg(b, f, g)
            }
    };
    _.Aj = function() {
        var a = this;
        this.promise = new _.z.Promise(function(b, c) {
            a.resolve = b;
            a.reject = c
        })
    };
    var Jj = qc({
        vc: wc,
        pn: wc,
        eid: wc,
        vnm: sc(wc),
        js: wc
    });
    var mM, lM, oM, nM;
    _.jM = function() {
        this.l = "&";
        this.o = {};
        this.j = 0;
        this.g = []
    };
    _.kM = function(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    };
    mM = function(a, b, c, d, e) {
        var f = [];
        _.$o(a, function(g, h) {
            (g = lM(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    };
    lM = function(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        typeof c === "string" && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                for (var f = [], g = 0; g < a.length; g++) f.push(lM(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(mM(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    };
    oM = function(a, b) {
        var c = "https://pagead2.googlesyndication.com" + b,
            d = nM(a) - b.length;
        if (d < 0) return "";
        a.g.sort(function(m, n) {
            return m - n
        });
        b = null;
        for (var e = "", f = 0; f < a.g.length; f++)
            for (var g = a.g[f], h = a.o[g], l = 0; l < h.length; l++) {
                if (!d) {
                    b = b == null ? g : b;
                    break
                }
                var k = mM(h[l], a.l, ",$");
                if (k) {
                    k = e + k;
                    if (d >= k.length) {
                        d -= k.length;
                        c += k;
                        e = a.l;
                        break
                    }
                    b = b == null ? g : b
                }
            }
        a = "";
        b != null && (a = e + "trn=" + b);
        return c + a
    };
    nM = function(a) {
        var b = 1,
            c;
        for (c in a.o) c.length > b && (b = c.length);
        return 3997 - b - a.l.length - 1
    };
    _.pM = function() {
        this.g = Math.random()
    };
    _.mk = function(a, b, c, d, e) {
        if (((d === void 0 ? 0 : d) ? a.g : Math.random()) < (e || .001)) try {
            if (c instanceof _.jM) var f = c;
            else f = new _.jM, _.$o(c, function(h, l) {
                var k = f,
                    m = k.j++;
                h = _.kM(l, h);
                k.g.push(m);
                k.o[m] = h
            });
            var g = oM(f, "/pagead/gen_204?id=" + b + "&");
            g && dG(_.ca, g)
        } catch (h) {}
    };
    var qM = /^v?\d{1,3}(\.\d{1,3}){0,2}(-pre)?$/,
        rM = new _.z.Map,
        Mj = function(a, b, c) {
            this.pbjs = a;
            this.slot = b;
            var d;
            this.Ve = (d = c == null ? void 0 : c.Ve) != null ? d : {};
            this.xc = !(c == null || !c.xc);
            var e;
            this.Ac = (e = c == null ? void 0 : c.Ac) != null ? e : new _.z.Map;
            var f;
            this.mi = (f = c == null ? void 0 : c.mi) != null ? f : new _.z.Map;
            var g;
            this.Ag = (g = c == null ? void 0 : c.Ag) != null ? g : new XB;
            this.Zh = c == null ? void 0 : c.Zh;
            this.g = c
        },
        uM = function(a, b, c) {
            var d = a.pbjs.getBidResponsesForAdUnitCode;
            if (d) {
                var e, f, g, h, l, k = (l = (e = d((g = a.slot.Dd) != null ? g : "")) == null ? void 0 : e.bids) != null ? l : (f = d((h = a.slot.adUnitCode) != null ? h : "")) == null ? void 0 : f.bids;
                if (k != null && k.length && (e = k.filter(function(p) {
                        var r = p.auctionId;
                        var v = p.adId;
                        return r !== c && _.w(Object, "values").call(Object, a.Ve).some(function(u) {
                            return _.w(u, "includes").call(u, v)
                        })
                    }), e.length)) {
                    var m, n;
                    d = (m = a.pbjs.adUnits) == null ? void 0 : (n = _.w(m, "find").call(m, function(p) {
                        p = p.code;
                        return p === a.slot.Dd || p === a.slot.adUnitCode
                    })) == null ? void 0 : n.mediaTypes;
                    m = _.y(e);
                    for (n = m.next(); !n.done; n = m.next()) n = n.value, e = sM(a, n, d), e = ZB(b, TB(_.Dl(UB(SB(new RB, n.bidder), 1), 6, !0), e)), tM(a, n.bidder, e), typeof n.timeToRespond === "number" && _.Dm(e, 2, Math.round(n.timeToRespond))
                }
            }
        },
        tM = function(a, b, c) {
            for (var d = []; b && !_.w(d, "includes").call(d, b);) {
                d.unshift(b);
                var e = void 0,
                    f = void 0;
                b = (e = a.pbjs) == null ? void 0 : (f = e.aliasRegistry) == null ? void 0 : f[b]
            }
            _.Ve(c, 10, d, _.Bd)
        },
        vM = function(a, b, c, d, e) {
            e = a.mi.get(e != null ? e : function() {
                return null
            });
            (e == null ? void 0 : _.Sh(e, 1, 0)) !== 1 && _.Wg(c, 5, e);
            _.zs(b, Ms, 5) || (e ? _.Sh(e, 1, 0) === 1 ? $B(b, e) : $B(b, Ks(Ls(Js(new Ms, a.xc), 1), Lj(d, a.Ac))) : $B(b, Ls(Js(new Ms, a.xc), Lj(d, a.Ac) ? 2 : 3)))
        },
        sM = function(a, b, c) {
            var d = b.cpm,
                e = b.originalCpm,
                f = b.currency,
                g = b.originalCurrency,
                h = b.dealId,
                l = b.adserverTargeting,
                k = b.bidder,
                m = b.adId,
                n = b.mediaType,
                p = b.height,
                r = b.width,
                v = b.meta,
                u = new PB;
            typeof d === "number" && (_.Dm(u, 2, Math.round(d * 1E6)), g && g !== f || (d = Math.round(Number(e) * 1E6), isNaN(d) || d === _.hi(u, 2) || _.Dm(u, 8, d)));
            typeof f === "string" && _.tj(u, 3, f);
            (_.E = ["string", "number"], _.w(_.E, "includes")).call(_.E, typeof h) && (f = new HB, h = _.tj(f, 1, String(h)), _.Wg(u, 6, h));
            if (typeof l === "object")
                for (h = _.y(["", "_" + k]), f = h.next(); !f.done; f = h.next()) {
                    d = f.value;
                    f = [];
                    e = _.y(_.w(Object, "entries").call(Object, l));
                    for (g = e.next(); !g.done; g = e.next()) {
                        g = _.y(g.value);
                        var x = g.next().value;
                        g = g.next().value;
                        x = (x + d).slice(0, 20);
                        var D = void 0;
                        if ((D = a.Ve[x]) != null && D.length)
                            if (a.Ve[x][0] === String(g)) f.push(x);
                            else {
                                f = [];
                                break
                            }
                    }
                    d = _.Ou(u, 4, _.wl());
                    _.Ve(u, 4, d.concat(f), _.Bd)
                }
            switch (n || "banner") {
                case "banner":
                    _.uj(u, 5, 1);
                    break;
                case "native":
                    _.uj(u, 5, 2);
                    break;
                case "video":
                    _.uj(u, 5, 3);
                    n = new NB;
                    var F;
                    if ((c == null ? void 0 : (F = c.video) == null ? void 0 : F.context) === "adpod") {
                        var C, G = c == null ? void 0 : (C = c.video) == null ? void 0 : C.adPodDurationSec;
                        _.Dm(n, 1, G)
                    } else C = c == null ? void 0 : (G = c.video) == null ? void 0 : G.maxduration, _.Dm(n, 1, C);
                    var S;
                    if (typeof(c == null ? void 0 : (S = c.video) == null ? void 0 : S.skip) === "number") {
                        var P;
                        c = !!(c == null ? 0 : (P = c.video) == null ? 0 : P.skip);
                        _.Dl(n, 2, c)
                    }
                    var J;
                    P = (J = b.meta) == null ? void 0 : J.adServerCatId;
                    J = _.tj(n, 3, P);
                    if (typeof l !== "object") l = null;
                    else {
                        var U, ha;
                        P = String((ha = (U = l["hb_pb_cat_dur_" + k]) != null ? U : l.hb_pb_cat_dur) != null ? ha : "");
                        var ea, Ba, ja, ma;
                        U = String((ma = (ja = (Ba = (ea = l["hb_cache_id_" + k]) != null ? ea : l["hb_uuid_" + k]) != null ? Ba : l.hb_cache_id) != null ? ja : l.hb_uuid) != null ? ma : "");
                        l = P && U ? P + "_" + U : U ? U : null
                    }
                    _.tj(J, 4, l);
                    _.Wg(u, 9, n)
            }
            _.w(Number, "isFinite").call(Number, p) && _.w(Number, "isFinite").call(Number, r) && (l = new LB, p = _.Dq(l, 1, Math.round(r)).setHeight(Math.round(p)), _.Wg(u, 7, p));
            typeof m === "string" && _.tj(u, 1, m);
            var ra, ia;
            if (((ra = a.g) == null ? 0 : ra.Xi) && Array.isArray(v == null ? void 0 : v.advertiserDomains) && (v == null ? 0 : (ia = v.advertiserDomains[0]) == null ? 0 : ia.length)) {
                var Oa;
                m = v.advertiserDomains[0].substring(0, (Oa = a.g) == null ? void 0 : Oa.Xi);
                _.tj(u, 10, m)
            }
            if (b.meta && a.g) {
                var fb, Ub;
                a.g.cj && typeof b.meta.agencyId === "string" && ((Ub = b.meta.agencyId) == null ? 0 : Ub.length) && (fb != null || (fb = new JB), _.tj(fb, 1, b.meta.agencyId.substring(0, a.g.cj)));
                var Uc;
                a.g.dj && typeof b.meta.agencyId === "string" && ((Uc = b.meta.agencyName) == null ? 0 : Uc.length) && (fb != null || (fb = new JB), _.tj(fb, 2, b.meta.agencyName.substring(0, a.g.dj)));
                var vc;
                a.g.Mj && typeof b.meta.networkId === "string" && ((vc = b.meta.networkId) == null ? 0 : vc.length) && (fb != null || (fb = new JB), _.tj(fb, 3, b.meta.networkId.substring(0, a.g.Mj)));
                var Ad;
                a.g.Nj && typeof b.meta.networkId === "string" && ((Ad = b.meta.networkName) == null ? 0 : Ad.length) && (fb != null || (fb = new JB), _.tj(fb, 4, b.meta.networkName.substring(0, a.g.Nj)));
                fb && _.Wg(u, 11, fb)
            }
            return u
        },
        wM = function(a, b) {
            var c = new _.z.Map,
                d = function(l) {
                    var k = c.get(l);
                    k || (k = {}, c.set(l, k));
                    return k
                },
                e = [];
            a = _.y(a);
            for (var f = a.next(); !f.done; f = a.next()) {
                f = f.value;
                var g = f.args,
                    h = f.eventType;
                f = f.elapsedTime;
                h === "bidTimeout" && e.push.apply(e, _.Zk(g));
                switch (h) {
                    case "bidRequested":
                        if (g.auctionId !== b) continue;
                        if (!Array.isArray(g.bids)) continue;
                        g = _.y(g.bids);
                        for (h = g.next(); !h.done; h = g.next())
                            if (h = h.value.bidId) d(h).requestTime = f;
                        break;
                    case "noBid":
                        g.auctionId === b && g.bidId && (d(g.bidId).hp = f)
                }
            }
            d = new _.z.Map;
            a = _.y(_.w(c, "entries").call(c));
            for (f = a.next(); !f.done; f = a.next()) g = _.y(f.value), f = g.next().value, h = g.next().value, g = h.requestTime, h = h.hp, g && h && d.set(f, {
                latency: h - g,
                zk: !1
            });
            e = _.y(e);
            for (a = e.next(); !a.done; a = e.next())
                if (f = a.value, a = f.bidId, f = f.auctionId, a && f === b && (a = d.get(a))) a.zk = !0;
            return d
        };
    Mj.prototype.fetch = function() {
        var a = this,
            b = new _.z.Map,
            c, d, e = ((d = (c = this.pbjs) == null ? void 0 : c.getEvents) != null ? d : function() {
                return []
            })();
        d = e.filter(function(ja) {
            var ma = ja.eventType;
            ja = ja.args;
            return ma === "auctionEnd" && ja.auctionId
        });
        c = new dC;
        var f = function(ja) {
                return ja === a.slot.Dd || ja === a.slot.adUnitCode
            },
            g, h, l, k = (l = rM.get(((g = this.slot.Dd) != null ? g : "") + ((h = this.slot.adUnitCode) != null ? h : ""))) != null ? l : 0,
            m;
        g = (m = d.filter(function(ja) {
            var ma, ra, ia;
            return Number((ma = ja.args) == null ? void 0 : ma.timestamp) > k && ((ra = ja.args) == null ? void 0 : (ia = ra.adUnitCodes) == null ? void 0 : _.w(ia, "find").call(ia, f))
        })) != null ? m : [];
        if (!g.length) return null;
        var n;
        if (m = (n = g.reduce(function(ja, ma) {
                return Number(ma.args.timestamp) > Number(ja.args.timestamp) ? ma : ja
            })) == null ? void 0 : n.args) {
            g = m.bidderRequests === void 0 ? [] : m.bidderRequests;
            n = m.bidsReceived === void 0 ? [] : m.bidsReceived;
            var p = m.auctionId;
            h = m.timestamp;
            if (p && h != null && g.length) {
                var r, v;
                rM.set(((r = this.slot.Dd) != null ? r : "") + ((v = this.slot.adUnitCode) != null ? v : ""), h);
                r = eC(c);
                this.pbjs.version && qM.test(this.pbjs.version) && _.tj(r, 6, this.pbjs.version);
                var u, x, D, F;
                if ((x = (u = this.pbjs).getConfig) == null ? 0 : (D = x.call(u).cache) == null ? 0 : (F = D.url) == null ? 0 : F.length) {
                    var C, G, S;
                    aC(r, (G = (C = this.pbjs).getConfig) == null ? void 0 : (S = G.call(C).cache) == null ? void 0 : S.url)
                }
                _.Wg(r, 9, this.Ag);
                u = wo(function() {
                    return wM(e, p)
                });
                var P;
                x = _.y(g);
                F = x.next();
                for (D = {}; !F.done; D = {
                        bidderCode: void 0,
                        yl: void 0
                    }, F = x.next())
                    for (C = F.value, D.bidderCode = C.bidderCode, G = C.bids, F = C.timeout, D.yl = C.src, C = C.auctionStart, G = _.y(G), S = G.next(), v = {}; !S.done; v = {
                            ef: void 0
                        }, S = G.next())
                        if (d = S.value, v.ef = d.bidId, l = d.transactionId, g = d.adUnitCode, h = d.getFloor, S = d.mediaTypes, d = d.ortb2Imp, v.ef && f(g)) {
                            _.Xc(_.tA(r, 3)) != null || (g === this.slot.adUnitCode ? _.uj(r, 3, 1) : g === this.slot.Dd && _.uj(r, 3, 2));
                            var J = void 0,
                                U = void 0,
                                ha = void 0;
                            ((J = this.g) == null ? 0 : J.ck) && !_.yl(r, 11) && typeof((U = d) == null ? void 0 : (ha = U.ext) == null ? void 0 : ha.gpid) === "string" && (J = void 0, bC(r, d.ext.gpid.substring(0, (J = this.g) == null ? void 0 : J.ck)));
                            l && (P != null || (P = l), _.yl(r, 4) || _.tj(r, 4, l), b.has(l) || b.set(l, C));
                            xt(r, 8) == null && _.w(Number, "isFinite").call(Number, F) && _.Dq(r, 8, F);
                            d = _.w(n, "find").call(n, function(ja) {
                                return function(ma) {
                                    return ma.requestId === ja.ef
                                }
                            }(v));
                            l = ZB(r, function(ja) {
                                return function() {
                                    var ma = SB(new RB, ja.bidderCode);
                                    tM(a, ja.bidderCode, ma);
                                    switch (ja.yl) {
                                        case null:
                                        case void 0:
                                        case "client":
                                            _.uj(ma, 7, 1);
                                            break;
                                        case "s2s":
                                            _.uj(ma, 7, 2)
                                    }
                                    return ma
                                }
                            }(D)());
                            vM(this, r, l, g, h);
                            if (d) {
                                UB(l, 1);
                                typeof d.timeToRespond === "number" && _.w(Number, "isFinite").call(Number, d.timeToRespond) && _.Dm(l, 2, Math.round(d.timeToRespond));
                                try {
                                    g = v = void 0, (g = (v = this).Zh) == null || g.call(v, d)
                                } catch (ja) {}
                                S = sM(this, d, S);
                                TB(l, S)
                            } else(S = u().get(v.ef)) && !S.zk ? (UB(l, 2), _.w(Number, "isFinite").call(Number, S.latency) && _.Dm(l, 2, Math.round(S.latency))) : (S = UB(l, 3), _.w(Number, "isFinite").call(Number, F) && _.Dm(S, 2, Math.round(F)))
                        }
                var ea, Ba;
                ((Ba = (ea = this.pbjs).getConfig) == null ? 0 : Ba.call(ea).useBidCache) && uM(this, r, p);
                return {
                    Kn: c,
                    transactionId: P,
                    arg: m
                }
            }
        }
    };
    var xM = function(a) {
        this.D = _.A(a)
    };
    _.T(xM, _.B);
    var yM = function(a) {
        this.D = _.A(a)
    };
    _.T(yM, _.B);
    var zM = function(a, b) {
        return _.Ve(a, 1, b, _.Bd)
    };
    var AM = function(a) {
        this.D = _.A(a)
    };
    _.T(AM, _.B);
    var BM = function(a, b) {
        return _.Ve(a, 1, b, $c)
    };
    var CM = function(a) {
        this.D = _.A(a)
    };
    _.T(CM, _.B);
    var DM = function(a) {
        this.D = _.A(a)
    };
    _.T(DM, _.B);
    var EM = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.w(Object, "setPrototypeOf").call(Object, this, EM.prototype);
        this.name = "InputError"
    };
    _.T(EM, Error);
    var FM = function() {
            this.tb = !1
        },
        GM = function() {
            FM.apply(this, arguments);
            this.Pd = new _.Aj
        };
    _.T(GM, FM);
    var HM = function(a, b) {
        a.tb || (a.tb = !0, a.Je = b, a.Pd.resolve(b))
    };
    _.Hy.Object.defineProperties(GM.prototype, {
        promise: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Pd.promise
            }
        },
        Qd: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.tb
            }
        },
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ie
            }
        }
    });
    var Ws = function() {
        GM.apply(this, arguments)
    };
    _.T(Ws, GM);
    _.q = Ws.prototype;
    _.q.H = function(a) {
        HM(this, a)
    };
    _.q.ic = function(a) {
        HM(this, a != null ? a : null)
    };
    _.q.ha = function() {
        HM(this, null)
    };
    _.q.pb = function(a) {
        var b = this;
        a.then(function(c) {
            HM(b, c)
        })
    };
    _.q.zb = function(a) {
        this.tb || (this.tb = !0, this.Je = null, this.Ie = a, this.Pd.reject(a))
    };
    var IM = function() {
        GM.apply(this, arguments)
    };
    _.T(IM, GM);
    IM.prototype.H = function(a) {
        HM(this, a)
    };
    IM.prototype.pb = function(a) {
        var b = this;
        a.then(function(c) {
            return void HM(b, c)
        })
    };
    IM.prototype.zb = function(a) {
        this.tb || (this.tb = !0, this.Ie = a, this.Pd.reject(a))
    };
    var JM = function() {
        IM.apply(this, arguments)
    };
    _.T(JM, IM);
    JM.prototype.ic = function(a) {
        HM(this, a != null ? a : null)
    };
    JM.prototype.ha = function() {
        HM(this, null)
    };
    JM.prototype.pb = function(a) {
        var b = this;
        a.then(function(c) {
            return void b.ic(c)
        })
    };
    var KM = function(a) {
        this.tb = !1;
        this.Cc = a
    };
    _.T(KM, FM);
    KM.prototype.Qd = function() {
        return this.Cc.tb
    };
    KM.prototype.lh = function() {
        return this.Cc.Je != null
    };
    _.Hy.Object.defineProperties(KM.prototype, {
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Cc.Ie
            }
        }
    });
    var LM = function(a) {
        KM.call(this, a);
        this.Cc = a
    };
    _.T(LM, KM);
    _.Hy.Object.defineProperties(LM.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Cc.Je
            }
        }
    });
    var MM = function(a) {
        KM.call(this, a);
        this.Cc = a
    };
    _.T(MM, KM);
    _.Hy.Object.defineProperties(MM.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return (a = this.Cc.Je) != null ? a : null
            }
        }
    });
    var NM = function() {
        KM.apply(this, arguments)
    };
    _.T(NM, KM);
    _.Hy.Object.defineProperties(NM.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return (a = this.Cc.Je) != null ? a : null
            }
        }
    });
    var qu = function() {
        GM.apply(this, arguments)
    };
    _.T(qu, GM);
    qu.prototype.notify = function() {
        HM(this, null)
    };
    var OM = function(a, b) {
            b.then(function() {
                a.notify()
            })
        },
        Mt = function(a, b) {
            b = b === void 0 ? !1 : b;
            Ws.call(this);
            var c = this;
            a = a.map(function(d) {
                return d.promise.then(function(e) {
                    if (b || e != null) return e;
                    throw e;
                }, function(e) {
                    c.tb = !0;
                    c.Ie = e;
                    c.Pd.reject(e);
                    return null
                })
            });
            _.w(_.z.Promise, "any").call(_.z.Promise, a).then(function(d) {
                c.tb || HM(c, d)
            }, function() {
                c.tb || HM(c, null)
            })
        };
    _.T(Mt, Ws);
    var PM = function(a) {
            this.output = new Ws;
            this.output.pb(a)
        },
        QM = function(a) {
            this.output = new qu;
            OM(this.output, a)
        };
    var RM = function() {
        _.W.apply(this, arguments);
        this.g = [];
        this.l = [];
        this.j = []
    };
    _.T(RM, _.W);
    var SM = function(a, b, c) {
        a.l.push({
            rc: c === void 0 ? !1 : c,
            Tg: b
        })
    };
    RM.prototype.rc = function(a) {
        var b = _.w(this.l, "find").call(this.l, function(c) {
            return c.Tg === a
        });
        b && (b.rc = !0)
    };
    RM.prototype.o = function() {
        this.g.length = 0;
        this.j.length = 0;
        this.l.length = 0;
        _.W.prototype.o.call(this)
    };
    var TM = function(a, b) {
        _.W.call(this);
        this.id = a;
        this.timeoutMs = b;
        this.started = !1;
        this.F = new RM;
        _.Sq(this, this.F)
    };
    _.T(TM, _.W);
    TM.prototype.start = function() {
        var a = this,
            b, c;
        return _.ug(function(d) {
            if (d.g == 1) {
                if (a.started) return d.return();
                a.started = !0;
                d.l = 2;
                return d.yield(Oj(a.F.l, (b = a.Db) != null ? b : a.timeoutMs), 4)
            }
            if (d.g != 2) {
                if (!a.J) {
                    for (var e = 0, f = _.y(a.F.j), g = f.next(); !g.done; g = f.next()) {
                        if (!g.value.lh()) throw Error("missing input: " + a.id + "/" + e);
                        ++e
                    }
                    a.g()
                }
                d.g = 0;
                d.l = 0
            } else {
                c = wg(d);
                if (a.J) return d.return();
                c instanceof EM ? a.X(c) : c instanceof Error && (a.da ? a.da(a.id, c) : a.reportError(c), a.l(c));
                d.g = 0
            }
        })
    };
    var X = function(a, b) {
            b = b === void 0 ? new Ws : b;
            a.F.g.push(b);
            return b
        },
        UM = function(a) {
            var b = b === void 0 ? new JM : b;
            a.F.g.push(b);
            return b
        },
        VM = function(a, b) {
            b = b === void 0 ? new qu : b;
            a.F.g.push(b);
            return b
        },
        Y = function(a, b) {
            SM(a.F, b);
            b = new LM(b);
            a.F.j.push(b);
            return b
        },
        WM = function(a, b) {
            SM(a.F, b);
            return new MM(b)
        },
        XM = function(a, b) {
            SM(a.F, b, !0);
            return new MM(b)
        },
        YM = function(a, b) {
            SM(a.F, b)
        };
    TM.prototype.X = function() {};
    TM.prototype.l = function(a) {
        if (this.F.g.length) {
            a = new EM(a.message);
            for (var b = _.y(this.F.g), c = b.next(); !c.done; c = b.next())
                if (c = c.value, !c.Qd) {
                    var d = a;
                    c.tb = !0;
                    c.Ie = d;
                    c.Pd.reject(d)
                }
        }
    };
    var vw = function(a, b) {
        a.Db = b;
        return a
    };
    var ZM = function(a, b, c, d) {
        TM.call(this, a);
        this.f = b;
        this.C = d;
        a = {};
        c = _.y(_.w(Object, "entries").call(Object, c));
        for (b = c.next(); !b.done; b = c.next()) d = _.y(b.value), b = d.next().value, (d = d.next().value) && (a[b] = WM(this, d));
        this.A = a
    };
    _.T(ZM, TM);
    ZM.prototype.g = function() {
        for (var a = this.f, b = a.apply, c = {}, d = _.y(_.w(Object, "entries").call(Object, this.A)), e = d.next(); !e.done; e = d.next()) {
            var f = _.y(e.value);
            e = f.next().value;
            f = f.next().value;
            c[e] = f.value
        }
        a = b.call(a, this, [c].concat(_.Zk(this.C)));
        this.j(a)
    };
    ZM.prototype.X = function(a) {
        this.l(a)
    };
    ZM.prototype.reportError = function() {};
    var At = function(a, b) {
            $M(a);
            YM(a, b);
            return a
        },
        uw = function(a, b) {
            $M(a);
            a.F.rc(b);
            return a
        },
        $M = function(a) {
            if (a.started) throw Error("Invalid operation: producer has already started");
        };
    var Qj = function(a, b, c, d, e) {
        ZM.call(this, a, b, c, e);
        this.Qa = d;
        this.output = X(this, new Ws);
        this.complete = new qu
    };
    _.T(Qj, ZM);
    Qj.prototype.j = function(a) {
        var b = this;
        a.then(function(c) {
            HM(b.output, c);
            b.complete.notify()
        }, function(c) {
            b.Qa ? HM(b.output, b.Qa(c)) : b.output.zb(new EM("output error: " + c.message));
            b.complete.notify()
        })
    };
    Qj.prototype.l = function(a) {
        this.Qa ? (HM(this.output, this.Qa(a)), this.complete.notify()) : ZM.prototype.l.call(this, a)
    };
    var Tj = function(a, b, c, d, e, f) {
        ZM.call(this, a, b, c, f);
        this.Qa = e;
        this.finished = new qu;
        a = _.w(Object, "keys").call(Object, d);
        a = _.y(a);
        for (b = a.next(); !b.done; b = a.next()) this[b.value] = X(this)
    };
    _.T(Tj, ZM);
    Tj.prototype.j = function(a) {
        a = _.y(_.w(Object, "entries").call(Object, a));
        for (var b = a.next(); !b.done; b = a.next()) {
            var c = _.y(b.value);
            b = c.next().value;
            c = c.next().value;
            c instanceof Error && this[b].zb(c);
            HM(this[b], c)
        }
        this.finished.notify()
    };
    Tj.prototype.l = function(a) {
        this.Qa ? this.j(this.Qa(a)) : ZM.prototype.l.call(this, a)
    };
    var aN = function(a) {
        this.g = a === void 0 ? function() {} : a
    };
    aN.prototype.l = function(a, b) {
        var c = Uj.apply(null, [a, b].concat(_.Zk(_.Ia.apply(2, arguments))));
        c.da = this.g;
        return c
    };
    aN.prototype.o = function(a, b) {
        var c = Rj.apply(null, [a, b].concat(_.Zk(_.Ia.apply(2, arguments))));
        c.da = this.g;
        return c
    };
    var L = function(a) {
        _.W.call(this);
        this.F = a;
        this.I = [];
        this.X = [];
        this.R = {};
        this.C = [];
        this.G = new _.Aj;
        this.j = {}
    };
    _.T(L, _.W);
    var M = function(a, b) {
            _.Sq(a, b);
            a.I.push(b);
            return b
        },
        cm = function(a, b) {
            b = _.y(b);
            for (var c = b.next(); !c.done; c = b.next()) M(a, c.value)
        };
    L.prototype.g = function(a, b) {
        var c = this.F.l.apply(this.F, [a, b].concat(_.Zk(_.Ia.apply(2, arguments))));
        return M(this, c)
    };
    L.prototype.l = function(a, b) {
        var c = this.F.o.apply(this.F, [a, b].concat(_.Zk(_.Ia.apply(2, arguments))));
        return M(this, c)
    };
    var Fu = function(a, b) {
            a.X.push(b);
            _.Sq(a, b);
            return b
        },
        Hu = function(a) {
            var b, c, d, e, f, g, h, l, k, m, n, p;
            return _.ug(function(r) {
                switch (r.g) {
                    case 1:
                        if (!a.C.length) {
                            r.g = 2;
                            break
                        }
                        return r.yield(_.z.Promise.all(a.C.map(function(v) {
                            return v.G.promise
                        })), 2);
                    case 2:
                        b = _.y(a.I);
                        for (c = b.next(); !c.done; c = b.next()) d = c.value, d.start();
                        e = _.y(a.X);
                        for (f = e.next(); !f.done; f = e.next()) g = f.value, Hu(g);
                        if (!a.j) {
                            r.g = 4;
                            break
                        }
                        h = _.w(Object, "keys").call(Object, a.j);
                        if (!h.length) {
                            r.g = 4;
                            break
                        }
                        return r.yield(_.z.Promise.all(_.w(Object, "values").call(Object, a.j).map(function(v) {
                            return v.promise
                        })), 6);
                    case 6:
                        for (l = r.o, k = 0, m = _.y(h), n = m.next(); !n.done; n = m.next()) p = n.value, a.R[p] = l[k++];
                    case 4:
                        return a.G.resolve(a.R), r.return(a.G.promise)
                }
            })
        };
    L.prototype.run = function() {
        Hu(this)
    };
    L.prototype.o = function() {
        _.W.prototype.o.call(this);
        this.I.length = 0;
        this.X.length = 0;
        this.C.length = 0
    };
    var bN = function(a) {
        this.D = _.A(a)
    };
    _.T(bN, _.B);
    var cN = [0, _.pB, HC];
    var dN = function(a) {
        this.D = _.A(a)
    };
    _.T(dN, _.B);
    dN.prototype.g = ag([0, _.pB, HC, _.pB, cN]);
    var Kq = 728 * 1.38;
    var fN, eN;
    fN = function() {
        this.wasPlaTagProcessed = !1;
        this.wasReactiveAdConfigReceived = {};
        this.adCount = {};
        this.wasReactiveAdVisible = {};
        this.stateForType = {};
        this.reactiveTypeEnabledInAsfe = {};
        this.wasReactiveTagRequestSent = !1;
        this.reactiveTypeDisabledByPublisher = {};
        this.tagSpecificState = {};
        this.messageValidationEnabled = !1;
        this.floatingAdsStacking = new eN;
        this.sideRailProcessedFixedElements = new _.z.Set;
        this.sideRailAvailableSpace = new _.z.Map;
        this.sideRailPlasParam = new _.z.Map;
        this.sideRailMutationCallbacks = [];
        this.g = null;
        this.clickTriggeredInterstitialMayBeDisplayed = !1
    };
    _.Uk = function(a) {
        a.google_reactive_ads_global_state ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements == null && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new _.z.Set), a.google_reactive_ads_global_state.sideRailAvailableSpace == null && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new _.z.Map), a.google_reactive_ads_global_state.sideRailPlasParam == null && (a.google_reactive_ads_global_state.sideRailPlasParam = new _.z.Map), a.google_reactive_ads_global_state.sideRailMutationCallbacks == null && (a.google_reactive_ads_global_state.sideRailMutationCallbacks = [])) : a.google_reactive_ads_global_state = new fN;
        return a.google_reactive_ads_global_state
    };
    eN = function() {
        this.maxZIndexRestrictions = {};
        this.nextRestrictionId = 0;
        this.maxZIndexListeners = []
    };
    var jN, kN, hN;
    _.gN = function(a) {
        this.g = _.Uk(a).floatingAdsStacking
    };
    _.iN = function(a, b) {
        return new hN(a, b)
    };
    jN = function(a) {
        a = _.cE(a.g.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    };
    _.gN.prototype.addListener = function(a) {
        this.g.maxZIndexListeners.push(a);
        a(jN(this))
    };
    _.gN.prototype.removeListener = function(a) {
        _.cb(this.g.maxZIndexListeners, function(b) {
            return b === a
        })
    };
    kN = function(a) {
        var b = jN(a);
        _.Jz(a.g.maxZIndexListeners, function(c) {
            return c(b)
        })
    };
    hN = function(a, b) {
        this.o = a;
        this.l = b;
        this.g = null
    };
    _.lN = function(a) {
        if (a.g == null) {
            var b = a.o,
                c = a.l,
                d = b.g.nextRestrictionId++;
            b.g.maxZIndexRestrictions[d] = c;
            kN(b);
            a.g = d
        }
    };
    _.mN = function(a) {
        if (a.g != null) {
            var b = a.o;
            delete b.g.maxZIndexRestrictions[a.g];
            kN(b);
            a.g = null
        }
    };
    var Qq, nN;
    _.jk = function(a, b) {
        b = b === void 0 ? {} : b;
        this.ra = a;
        this.settings = b
    };
    _.oN = function(a, b) {
        var c = hk(a.ra.document, b);
        if (c) {
            var d;
            if (!(d = nN(a, c, b))) a: {
                d = a.ra.document;
                for (c = c.offsetParent; c && c !== d.body; c = c.offsetParent) {
                    var e = nN(a, c, b);
                    if (e) {
                        d = e;
                        break a
                    }
                }
                d = null
            }
            a = d || null
        } else a = null;
        return a
    };
    Qq = function(a, b) {
        b = _.y(b);
        for (var c = b.next(); !c.done; c = b.next())
            if (c = _.oN(a, c.value)) return c;
        return null
    };
    nN = function(a, b, c) {
        if (RE(b, "position") !== "fixed") return null;
        var d = b.getAttribute("class") === "GoogleActiveViewInnerContainer" || _.ko(_.WE, b).width <= 1 && _.ko(_.WE, b).height <= 1 || a.settings.Ym && !a.settings.Ym(b) ? !0 : !1;
        a.settings.Vj && a.settings.Vj(b, c, d);
        return d ? null : b
    };
    var Pq = 90 * 1.38;
    var Iz = Ny(["* { pointer-events: none; }"]),
        tk = function() {
            this.g = this.J = this.j = this.l = null;
            this.o = 0
        };
    tk.prototype.apply = function(a, b) {
        this.l = a.body.style.overflow;
        this.j = a.body.style.position;
        this.J = a.body.style.top;
        this.g = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
        this.o = _.ek(b);
        _.uk(a.body, "top", -this.o + "px")
    };
    var Lr = function(a, b) {
        this.g = a;
        this.o = b === void 0 ? 0 : b
    };
    Lr.prototype.send = function(a, b) {
        var c = a.nl,
            d = this.o++;
        b = _.Pg(b, 1, d);
        c.call(a, b)
    };
    _.Hy.Object.defineProperties(Lr.prototype, {
        Uc: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.g()
            }
        }
    });
    var $k = "body div footer header html main section".split(" ");
    var pN = function(a) {
        this.D = _.A(a)
    };
    _.T(pN, _.B);
    var vi = function(a) {
            return _.R(a, 5)
        },
        ir = function(a, b) {
            return _.Dl(a, 8, b)
        },
        qN = function(a, b) {
            return _.Dl(a, 13, b)
        },
        jr = function(a, b) {
            return _.Dl(a, 12, b)
        },
        fr = function(a, b) {
            return _.Ve(a, 10, b, _.hd)
        },
        er = function(a, b) {
            return _.tj(a, 11, b)
        },
        rN = function(a) {
            return ic(function(b) {
                return b instanceof a && !((0, _.dc)(b.D) & 2)
            })
        }(pN);
    var gl = ["auto", "inherit", "100%"],
        hl = gl.concat(["none"]);
    var sN = /^data-(?!xml)[_a-z][_a-z.0-9-]*$/;
    var tN = function(a, b, c, d, e, f) {
            this.l = _.zE(a);
            this.o = _.zE(b);
            this.j = c;
            this.g = _.zE(d);
            this.J = e;
            this.F = f
        },
        uN = function(a) {
            return JSON.stringify({
                windowCoords_t: a.l.top,
                windowCoords_r: a.l.right,
                windowCoords_b: a.l.bottom,
                windowCoords_l: a.l.left,
                frameCoords_t: a.o.top,
                frameCoords_r: a.o.right,
                frameCoords_b: a.o.bottom,
                frameCoords_l: a.o.left,
                styleZIndex: a.j,
                allowedExpansion_t: a.g.top,
                allowedExpansion_r: a.g.right,
                allowedExpansion_b: a.g.bottom,
                allowedExpansion_l: a.g.left,
                xInView: a.J,
                yInView: a.F
            })
        },
        vN = function(a) {
            var b = window,
                c = b.screenX || b.screenLeft || 0,
                d = b.screenY || b.screenTop || 0;
            b = new _.yE(d, c + (b.outerWidth || document.documentElement.clientWidth || 0), d + (b.outerHeight || document.documentElement.clientHeight || 0), c);
            c = TE(a);
            d = _.ko(_.WE, a);
            var e = new AE(c.x, c.y, d.width, d.height);
            c = BE(e);
            d = String(RE(a, "zIndex"));
            var f = new _.yE(0, Infinity, Infinity, 0);
            for (var g = Wh(a), h = g.g.body, l = g.g.documentElement, k = IE(g.g); a = SE(a);)
                if ((!Tz || a.clientHeight != 0 || a != h) && a != h && a != l && RE(a, "overflow") != "visible") {
                    var m = TE(a),
                        n = new _.io(a.clientLeft, a.clientTop);
                    m.x += n.x;
                    m.y += n.y;
                    f.top = Math.max(f.top, m.y);
                    f.right = Math.min(f.right, m.x + a.clientWidth);
                    f.bottom = Math.min(f.bottom, m.y + a.clientHeight);
                    f.left = Math.max(f.left, m.x)
                }
            a = k.scrollLeft;
            k = k.scrollTop;
            f.left = Math.max(f.left, a);
            f.top = Math.max(f.top, k);
            g = _.HE(g.g.defaultView || window);
            f.right = Math.min(f.right, a + g.width);
            f.bottom = Math.min(f.bottom, k + g.height);
            k = (f = (f = f.top >= 0 && f.left >= 0 && f.bottom > f.top && f.right > f.left ? f : null) ? new AE(f.left, f.top, f.right - f.left, f.bottom - f.top) : null) ? CE(e, f) : null;
            g = a = 0;
            k && !(new _.mo(k.width, k.height)).isEmpty() && (a = k.width / e.width, g = k.height / e.height);
            k = new _.yE(0, 0, 0, 0);
            if (h = f)(e = CE(e, f)) ? (l = BE(f), m = BE(e), h = m.right != l.left && l.right != m.left, l = m.bottom != l.top && l.bottom != m.top, h = (e.width != 0 || h) && (e.height != 0 || l)) : h = !1;
            h && (k = new _.yE(Math.max(c.top - f.top, 0), Math.max(f.left + f.width - c.right, 0), Math.max(f.top + f.height - c.bottom, 0), Math.max(c.left - f.left, 0)));
            return new tN(b, c, d, k, a, g)
        };
    var wN = function(a) {
        this.J = a;
        this.j = null;
        this.I = this.status = 0;
        this.o = null;
        this.Ob = "sfchannel" + a
    };
    wN.prototype.getStatus = function() {
        return this.status
    };
    wN.prototype.uh = function() {
        return this.I == 2
    };
    var xN = function(a) {
        this.g = a
    };
    xN.prototype.getValue = function(a, b) {
        return this.g[a] == null || this.g[a][b] == null ? null : this.g[a][b]
    };
    var yN = function(a, b) {
        this.wf = a;
        this.xf = b;
        this.o = this.g = !1
    };
    var zN = function(a, b, c, d, e, f, g, h) {
        h = h === void 0 ? [] : h;
        this.g = a;
        this.o = b;
        this.l = c;
        this.permissions = d;
        this.metadata = e;
        this.j = f;
        this.te = g;
        this.hostpageLibraryTokens = h;
        this.P = ""
    };
    var AN = function(a, b) {
        this.o = a;
        this.P = b
    };
    AN.prototype.g = function(a) {
        this.P && a && (a.sentinel = this.P);
        return JSON.stringify(a)
    };
    var BN = function(a, b, c) {
        AN.call(this, a, c === void 0 ? "" : c);
        this.version = b
    };
    _.T(BN, AN);
    BN.prototype.g = function() {
        return AN.prototype.g.call(this, {
            uid: this.o,
            version: this.version
        })
    };
    var CN = function(a, b, c, d) {
        AN.call(this, a, d === void 0 ? "" : d);
        this.j = b;
        this.l = c
    };
    _.T(CN, AN);
    CN.prototype.g = function() {
        return AN.prototype.g.call(this, {
            uid: this.o,
            initialWidth: this.j,
            initialHeight: this.l
        })
    };
    var DN = function(a, b, c) {
        AN.call(this, a, c === void 0 ? "" : c);
        this.description = b
    };
    _.T(DN, AN);
    DN.prototype.g = function() {
        return AN.prototype.g.call(this, {
            uid: this.o,
            description: this.description
        })
    };
    var EN = function(a, b, c, d) {
        AN.call(this, a, d === void 0 ? "" : d);
        this.l = b;
        this.push = c
    };
    _.T(EN, AN);
    EN.prototype.g = function() {
        return AN.prototype.g.call(this, {
            uid: this.o,
            expand_t: this.l.top,
            expand_r: this.l.right,
            expand_b: this.l.bottom,
            expand_l: this.l.left,
            push: this.push
        })
    };
    var FN = function(a, b) {
        AN.call(this, a, b === void 0 ? "" : b)
    };
    _.T(FN, AN);
    FN.prototype.g = function() {
        return AN.prototype.g.call(this, {
            uid: this.o
        })
    };
    var GN = function(a, b, c) {
        AN.call(this, a, c === void 0 ? "" : c);
        this.j = b
    };
    _.T(GN, AN);
    GN.prototype.g = function() {
        var a = {
            uid: this.o,
            newGeometry: uN(this.j)
        };
        return AN.prototype.g.call(this, a)
    };
    var HN = function(a, b, c, d, e, f) {
        GN.call(this, a, c, f === void 0 ? "" : f);
        this.success = b;
        this.l = d;
        this.push = e
    };
    _.T(HN, GN);
    HN.prototype.g = function() {
        var a = {
            uid: this.o,
            success: this.success,
            newGeometry: uN(this.j),
            expand_t: this.l.top,
            expand_r: this.l.right,
            expand_b: this.l.bottom,
            expand_l: this.l.left,
            push: this.push
        };
        this.P && (a.sentinel = this.P);
        return JSON.stringify(a)
    };
    var IN = function(a, b, c, d) {
        AN.call(this, a, d === void 0 ? "" : d);
        this.width = b;
        this.height = c
    };
    _.T(IN, AN);
    IN.prototype.g = function() {
        return AN.prototype.g.call(this, {
            uid: this.o,
            width: this.width,
            height: this.height
        })
    };
    var nl = function(a) {
        var b;
        if ((b = a.location) == null ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        Mm(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    var JN, MN, NN, LN;
    JN = function() {
        this.g = []
    };
    _.KN = function(a) {
        return a + "px"
    };
    MN = function(a, b, c, d, e) {
        a.g.push(new LN(b, c, d, e))
    };
    NN = function(a) {
        for (var b = a.g.length - 1; b >= 0; b--) {
            var c = a.g[b];
            c.o ? (c.l.style.removeProperty(c.g), c.l.style.setProperty(c.g, String(c.j), c.J)) : c.l.style[c.g] = c.j
        }
        a.g.length = 0
    };
    LN = function(a, b, c, d) {
        this.l = a;
        this.g = (this.o = !(d === void 0 || !a.style || !a.style.getPropertyPriority)) ? String(b).replace(/([A-Z])/g, "-$1").toLowerCase() : b;
        this.j = this.o ? a.style.getPropertyValue(this.g) : a.style[this.g];
        this.J = this.o ? a.style.getPropertyPriority(this.g) : void 0;
        this.o ? (a.style.removeProperty(this.g), a.style.setProperty(this.g, String(c), d)) : a.style[this.g] = String(c)
    };
    var ON, PN;
    ON = function(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    };
    PN = function() {
        var a = window,
            b = _.xk(a);
        b && ON({
            label: "2",
            type: 9,
            value: b
        }, a)
    };
    _.QN = function(a, b, c, d, e) {
        e = e === void 0 ? !1 : e;
        var f = d || window,
            g = typeof queueMicrotask !== "undefined";
        return function() {
            e && g && queueMicrotask(function() {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            var h = _.xk(),
                l = 3;
            try {
                var k = b.apply(this, arguments)
            } catch (n) {
                l = 13;
                if (!c) throw n;
                c(a, n)
            } finally {
                if (f.google_measure_js_timing && h) {
                    var m = _.xk() || 0;
                    ON(_.w(Object, "assign").call(Object, {}, {
                        label: a.toString(),
                        value: h,
                        duration: m - h,
                        type: l
                    }, e && g && {
                        taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                    }), f)
                }
            }
            return k
        }
    };
    var VN = function(a) {
        wN.call(this, a.uniqueId);
        var b = this;
        this.C = a.O;
        this.G = a.size === 1;
        this.U = new yN(a.permissions.wf && !this.G, a.permissions.xf && !this.G);
        this.F = a.ji;
        var c;
        this.Wa = (c = a.hostpageLibraryTokens) != null ? c : [];
        var d = window.location;
        c = d.protocol;
        d = d.host;
        this.Na = c == "file:" ? "*" : c + "//" + d;
        this.Za = !!a.te;
        this.ca = a.cl ? "//" + a.cl + ".safeframe.googlesyndication.com" : "//tpc.googlesyndication.com";
        this.Ea = a.Fd ? "*" : "https:" + this.ca;
        this.oa = RN(a);
        this.l = new JN;
        SN(this, a);
        this.j = this.ka = vN(a.ji);
        this.da = a.mp || "1-0-40";
        var e;
        this.pa = (e = a.ym) != null ? e : "";
        TN(this, a);
        this.X = _.QN(412, function() {
            return UN(b)
        }, a.Hb);
        this.Va = -1;
        this.A = 0;
        var f = _.QN(415, function() {
            b.g && (b.g.name = "", a.Nk && a.Nk(), _.Gh(b.g, "load", f))
        }, a.Hb);
        _.sg(this.g, "load", f);
        this.qh = _.QN(413, this.qh, a.Hb);
        this.ri = _.QN(417, this.ri, a.Hb);
        this.wi = _.QN(419, this.wi, a.Hb);
        this.hh = _.QN(411, this.hh, a.Hb);
        this.Lg = _.QN(409, this.Lg, a.Hb);
        this.R = _.QN(410, this.R, a.Hb);
        this.ai = _.QN(416, this.ai, a.Hb);
        this.o = new ZL(this.Ob, this.g.contentWindow, this.Ea, !1);
        aM(this.o, "init_done", (0, _.pz)(this.qh, this));
        aM(this.o, "register_done", (0, _.pz)(this.ri, this));
        aM(this.o, "report_error", (0, _.pz)(this.wi, this));
        aM(this.o, "expand_request", (0, _.pz)(this.hh, this));
        aM(this.o, "collapse_request", (0, _.pz)(this.Lg, this));
        aM(this.o, "creative_geometry_update", (0, _.pz)(this.R, this));
        this.o.connect((0, _.pz)(this.ai, this))
    };
    _.T(VN, wN);
    var SN = function(a, b) {
            var c = b.ji;
            var d = b.size;
            b = b.xk;
            a.G ? (c.style.width = _.VE("100%", !0), c.style.height = _.VE("auto", !0)) : b || (c.style.width = _.VE(d.width, !0), c.style.height = _.VE(d.height, !0))
        },
        TN = function(a, b) {
            var c = b.Fd;
            var d = b.content;
            var e = b.re;
            var f = b.size;
            var g = b.se === void 0 ? "3rd party ad content" : b.se;
            var h = b.zf;
            var l = b.zg;
            var k = (b = b.xk) || !c;
            d = b || !c ? d != null ? d : "" : "";
            var m = {
                shared: {
                    sf_ver: a.da,
                    ck_on: vL.isEnabled() ? 1 : 0,
                    flash_ver: "0"
                }
            };
            d = a.da + ";" + d.length + ";" + d;
            m = new zN(a.J, a.Na, a.ka, a.U, new xN(m), a.G, a.Za, a.Wa);
            var n = {};
            n.uid = m.g;
            n.hostPeerName = m.o;
            n.initialGeometry = uN(m.l);
            var p = m.permissions;
            p = JSON.stringify({
                expandByOverlay: p.wf,
                expandByPush: p.xf,
                readCookie: p.g,
                writeCookie: p.o
            });
            n = (n.permissions = p, n.metadata = JSON.stringify(m.metadata.g), n.reportCreativeGeometry = m.j, n.isDifferentSourceWindow = m.te, n.goog_safeframe_hlt = XL(m.hostpageLibraryTokens), n);
            m.P && (n.sentinel = m.P);
            m = JSON.stringify(n);
            n = f.width;
            f = f.height;
            a.G && (f = n = 0);
            p = {};
            e = (p.id = e, p.title = g, p.name = d + m, p.scrolling = "no", p.marginWidth = "0", p.marginHeight = "0", p.width = String(n), p.height = String(f), p["data-is-safeframe"] = "true", p);
            k && (g = a.pa, k = a.ca, f = a.da, (d = g) && (d = "?" + d), k = (k === void 0 ? "//tpc.googlesyndication.com" : k) + ("/safeframe/" + f + "/html/container.html" + d), (f = nl(_.nm(_.FE(a.F)))) && (k += (g ? "&" : "?") + "n=" + f), e.src = "https:" + k);
            a.oa !== null && (e.sandbox = a.oa);
            h && (e.allow = h);
            l && (e.credentialless = "true");
            e["aria-label"] = "Advertisement";
            e.tabIndex = "0";
            b ? (a.F.removeChild(c), el(c, e), a.g = c) : c ? (a.g = c, dl(a.g, e)) : (c = _.Fh("IFRAME"), el(c, e), a.g = c);
            a.G && (a.g.style.minWidth = "100%");
            a.F.appendChild(a.g)
        };
    _.q = VN.prototype;
    _.q.ai = function() {
        _.sg(window, "resize", this.X);
        _.sg(window, "scroll", this.X)
    };
    _.q.qh = function(a) {
        try {
            if (this.status != 0) throw Error("Container already initialized");
            if (typeof a !== "string") throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.gb(b) || !ll(b.uid) || typeof b.version !== "string") throw Error("Cannot parse JSON message");
            var c = new BN(b.uid, b.version, b.sentinel);
            if (this.J !== c.o || this.da !== c.version) throw Error("Wrong source container");
            this.status = 1
        } catch (e) {
            var d;
            (d = this.C) == null || d.error("Invalid INITIALIZE_DONE message. Reason: " + e.message)
        }
    };
    _.q.ri = function(a) {
        try {
            if (this.status != 1) throw Error("Container not initialized");
            if (typeof a !== "string") throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.gb(b) || !ll(b.uid) || typeof b.initialWidth !== "number" || typeof b.initialHeight !== "number") throw Error("Cannot parse JSON message");
            if (this.J !== (new CN(b.uid, b.initialWidth, b.initialHeight, b.sentinel)).o) throw Error("Wrong source container");
            this.status = 2
        } catch (d) {
            var c;
            (c = this.C) == null || c.error("Invalid REGISTER_DONE message. Reason: " + d.message)
        }
    };
    _.q.wi = function(a) {
        try {
            if (typeof a !== "string") throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.gb(b) || !ll(b.uid) || typeof b.description !== "string") throw Error("Cannot parse JSON message");
            var c = new DN(b.uid, b.description, b.sentinel);
            if (this.J !== c.o) throw Error("Wrong source container");
            var d;
            (d = this.C) == null || d.info("Ext reported an error. Description: " + c.description)
        } catch (f) {
            var e;
            (e = this.C) == null || e.error("Invalid REPORT_ERROR message. Reason: " + f.message)
        }
    };
    _.q.hh = function(a) {
        try {
            if (this.status != 2) throw Error("Container is not registered");
            if (this.I != 0) throw Error("Container is not collapsed");
            if (typeof a !== "string") throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.gb(b) || !ll(b.uid) || typeof b.expand_t !== "number" || typeof b.expand_r !== "number" || typeof b.expand_b !== "number" || typeof b.expand_l !== "number" || typeof b.push !== "boolean") throw Error("Cannot parse JSON message");
            var c = new EN(b.uid, new _.yE(b.expand_t, b.expand_r, b.expand_b, b.expand_l), b.push, b.sentinel);
            if (this.J !== c.o) throw Error("Wrong source container");
            if (!(c.l.top >= 0 && c.l.left >= 0 && c.l.bottom >= 0 && c.l.right >= 0)) throw Error("Invalid expansion amounts");
            var d;
            if (d = c.push && this.U.xf || !c.push && this.U.wf) {
                var e = c.l,
                    f = c.push,
                    g = this.j = vN(this.g);
                if (e.top <= g.g.top && e.right <= g.g.right && e.bottom <= g.g.bottom && e.left <= g.g.left) {
                    if (!f)
                        for (var h = this.g.parentNode; h && h.style; h = h.parentNode) MN(this.l, h, "overflowX", "visible", "important"), MN(this.l, h, "overflowY", "visible", "important");
                    var l = BE(new AE(0, 0, this.j.o.getWidth(), this.j.o.getHeight()));
                    _.gb(e) ? (l.top -= e.top, l.right += e.right, l.bottom += e.bottom, l.left -= e.left) : (l.top -= e, l.right += Number(void 0), l.bottom += Number(void 0), l.left -= Number(void 0));
                    MN(this.l, this.F, "position", "relative");
                    MN(this.l, this.g, "position", "absolute");
                    if (f) {
                        var k = this.l,
                            m = this.F,
                            n = l.getWidth();
                        MN(k, m, "width", _.KN(n));
                        var p = this.l,
                            r = this.F,
                            v = l.getHeight();
                        MN(p, r, "height", _.KN(v))
                    } else MN(this.l, this.g, "zIndex", "10000");
                    var u = this.l,
                        x = this.g,
                        D = l.getWidth();
                    MN(u, x, "width", _.KN(D));
                    var F = this.l,
                        C = this.g,
                        G = l.getHeight();
                    MN(F, C, "height", _.KN(G));
                    MN(this.l, this.g, "left", _.KN(l.left));
                    MN(this.l, this.g, "top", _.KN(l.top));
                    this.I = 2;
                    this.j = vN(this.g);
                    d = !0
                } else d = !1
            }
            a = d;
            this.o.send("expand_response", (new HN(this.J, a, this.j, c.l, c.push)).g());
            if (!a) throw Error("Viewport or document body not large enough to expand into.");
        } catch (P) {
            var S;
            (S = this.C) == null || S.error("Invalid EXPAND_REQUEST message. Reason: " + P.message)
        }
    };
    _.q.Lg = function(a) {
        try {
            if (this.status != 2) throw Error("Container is not registered");
            if (!this.uh()) throw Error("Container is not expanded");
            if (typeof a !== "string") throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.gb(b) || !ll(b.uid)) throw Error("Cannot parse JSON message");
            if (this.J !== (new FN(b.uid, b.sentinel)).o) throw Error("Wrong source container");
            NN(this.l);
            this.I = 0;
            this.g && (this.j = vN(this.g));
            this.o.send("collapse_response", (new GN(this.J, this.j)).g())
        } catch (d) {
            var c;
            (c = this.C) == null || c.error("Invalid COLLAPSE_REQUEST message. Reason: " + d.message)
        }
    };
    var UN = function(a) {
        if (a.status == 1 || a.status == 2) switch (a.A) {
            case 0:
                WN(a);
                a.Va = window.setTimeout((0, _.pz)(a.ia, a), 1E3);
                a.A = 1;
                break;
            case 1:
                a.A = 2;
                break;
            case 2:
                a.A = 2
        }
    };
    VN.prototype.R = function(a) {
        try {
            if (typeof a !== "string") throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.gb(b) || !ll(b.uid) || typeof b.width !== "number" || typeof b.height !== "number" || b.sentinel && typeof b.sentinel !== "string") throw Error("Cannot parse JSON message");
            var c = new IN(b.uid, b.width, b.height, b.sentinel);
            if (this.J !== c.o) throw Error("Wrong source container");
            var d = String(c.height);
            if (this.G) d !== this.g.height && (this.g.height = d, UN(this));
            else {
                var e;
                (e = this.C) == null || e.error("Got CreativeGeometryUpdate message in non-fluidcontainer. The container is not resized.")
            }
        } catch (g) {
            var f;
            (f = this.C) == null || f.error("Invalid CREATIVE_GEOMETRY_UPDATE message. Reason: " + g.message)
        }
    };
    VN.prototype.ia = function() {
        if (this.status == 1 || this.status == 2) switch (this.A) {
            case 1:
                this.A = 0;
                break;
            case 2:
                WN(this), this.Va = window.setTimeout((0, _.pz)(this.ia, this), 1E3), this.A = 1
        }
    };
    var WN = function(a) {
        a.j = vN(a.g);
        a.o.send("geometry_update", (new GN(a.J, a.j)).g())
    };
    VN.prototype.destroy = function() {
        this.status != 100 && (this.uh() && (NN(this.l), this.I = 0), window.clearTimeout(this.Va), this.Va = -1, this.A = 3, this.o && (this.o.dispose(), this.o = null), _.Gh(window, "resize", this.X), _.Gh(window, "scroll", this.X), this.F && this.g && this.F == (this.g.parentElement || null) && this.F.removeChild(this.g), this.F = this.g = null, this.status = 100)
    };
    var RN = function(a) {
            var b = null;
            a.el && (b = a.el);
            return b == null ? null : b.join(" ")
        },
        XN = ["allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"],
        YN = ["allow-top-navigation"],
        ZN = ["allow-same-origin"],
        $N = jE([].concat(_.Zk(XN), _.Zk(YN)));
    jE([].concat(_.Zk(XN), _.Zk(ZN)));
    jE([].concat(_.Zk(XN), _.Zk(YN), _.Zk(ZN)));
    var aO = Ny(["https://tpc.googlesyndication.com/safeframe/", "/html/container.html"]),
        ml = {
            eo: function(a) {
                if (typeof a.version !== "string") throw new TypeError("version is not a string");
                if (!/^[0-9]+-[0-9]+-[0-9]+$/.test(a.version)) throw new RangeError("Invalid version: " + a.version);
                if (typeof a.lg !== "string") throw new TypeError("subdomain is not a string");
                if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(a.lg)) throw new RangeError("Invalid subdomain: " + a.lg);
                return za("https://" + a.lg + ".safeframe.googlesyndication.com/safeframe/" + a.version + "/html/container.html")
            },
            Gr: function(a) {
                return _.ng(aO, a)
            }
        };
    var Ul = {
        Jg: [],
        sj: 0,
        Wg: [],
        Er: !1
    };
    var bO = function() {};
    bO.g = function() {
        throw Error("Must be overridden");
    };
    var pl = function() {
        this.g = 0
    };
    _.T(pl, bO);
    pl.gd = void 0;
    pl.g = function() {
        return pl.gd ? pl.gd : pl.gd = new pl
    };
    var cO = function() {
            this.cache = {}
        },
        Al = function() {
            dO || (dO = new cO);
            return dO
        },
        Cl = function(a) {
            var b = _.ud(_.tA(a, 3));
            if (!b) return 3;
            if (xl(a, 2) === void 0) return 4;
            a = Date.now();
            return a > b + 2592E5 ? 2 : a > b + 432E5 ? 1 : 0
        };
    cO.prototype.get = function(a, b) {
        if (this.cache[a]) return {
            vd: this.cache[a],
            success: !0
        };
        var c = "_GESPSK-" + a,
            d = "",
            e = !1;
        if (b instanceof Storage) try {
            d = b.getItem(c)
        } catch (l) {
            var f;
            rl(6, a, (f = l) == null ? void 0 : f.message);
            e = !0
        } else rN(b) && (d = Ni(c, b, function(l) {
            rl(6, a, l == null ? void 0 : l.message);
            e = !0
        }));
        if (e) return {
            vd: null,
            success: !1
        };
        if (!d) return {
            vd: null,
            success: !0
        };
        try {
            var g = SC(d);
            this.cache[a] = g;
            return {
                vd: g,
                success: !0
            }
        } catch (l) {
            var h;
            rl(5, a, (h = l) == null ? void 0 : h.message);
            return {
                vd: null,
                success: !1
            }
        }
    };
    cO.prototype.set = function(a, b) {
        var c = xl(a, 1),
            d = "_GESPSK-" + c;
        RC(a);
        if (b instanceof Storage) try {
            b.setItem(d, Fm(a))
        } catch (f) {
            var e;
            rl(7, c, (e = f) == null ? void 0 : e.message);
            return !1
        } else if (rN(b) && !Pi(d, Fm(a), b, function(f) {
                rl(7, c, f == null ? void 0 : f.message)
            })) return !1;
        this.cache[c] = a;
        return !0
    };
    cO.prototype.remove = function(a, b) {
        a = xl(a, 1);
        try {
            b.removeItem("_GESPSK-" + a), delete this.cache[a]
        } catch (d) {
            var c;
            rl(8, a, (c = d) == null ? void 0 : c.message)
        }
    };
    var dO = null;
    var eO = function(a, b) {
        TM.call(this, a);
        this.id = a;
        this.Qa = b
    };
    _.T(eO, TM);
    eO.prototype.reportError = function(a) {
        this.Qa(this.id, a)
    };
    var Jl = function(a, b, c, d) {
        eO.call(this, 1041, d);
        this.A = Y(this, a);
        c ? this.fe = c : b && (this.j = WM(this, b))
    };
    _.T(Jl, eO);
    Jl.prototype.g = function() {
        var a = this.A.value,
            b, c, d = (c = this.fe) != null ? c : (b = this.j) == null ? void 0 : b.value;
        d && Al().set(a, d) && _.yl(a, 2) && rl(27, xl(a, 1))
    };
    var Ll = function(a, b) {
        eO.call(this, 1048, b);
        this.j = X(this);
        this.A = X(this);
        this.C = Y(this, a)
    };
    _.T(Ll, eO);
    Ll.prototype.g = function() {
        var a = this.C.value,
            b = function(c) {
                var d = {};
                rl(c, xl(a, 1), null, (d.tic = String(Math.round((Date.now() - _.ud(_.tA(a, 3))) / 6E4)), d))
            };
        switch (Cl(a)) {
            case 0:
                b(24);
                break;
            case 1:
                b(25);
                this.A.H(a);
                break;
            case 2:
                b(26);
                this.j.H(a);
                break;
            case 3:
                rl(9, xl(a, 1));
                this.j.H(a);
                break;
            case 4:
                b(23), this.j.H(a)
        }
    };
    var fO = function(a, b) {
        eO.call(this, 1094, b);
        this.j = VM(this);
        this.A = WM(this, a)
    };
    _.T(fO, eO);
    fO.prototype.g = function() {
        var a = this.A.value;
        if (a) {
            if (a !== void 0)
                for (var b = _.y(_.w(Object, "keys").call(Object, a)), c = b.next(); !c.done; c = b.next())
                    if (c = c.value, _.w(c, "startsWith").call(c, "_GESPSK")) try {
                        a.removeItem(c)
                    } catch (d) {}
            dO = new cO;
            this.j.notify()
        }
    };
    var bm = function(a, b, c) {
        eO.call(this, 1049, c);
        this.storage = b;
        YM(this, a)
    };
    _.T(bm, eO);
    bm.prototype.g = function() {
        for (var a = _.y(tl(this.storage)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = Al().get(b, this.storage).vd;
            if (c) {
                var d = Cl(c);
                if (d === 2 || d === 3) Al().remove(c, this.storage), rl(40, b)
            }
        }
    };
    var Il = function(a, b, c, d) {
        eO.call(this, 1027, d);
        this.lf = a;
        this.j = X(this);
        this.A = X(this);
        var e;
        this.C = (e = c != null ? c : b) != null ? e : void 0
    };
    _.T(Il, eO);
    Il.prototype.g = function() {
        var a = Al().get(this.lf, this.C).vd;
        a || (a = RC(QC(this.lf)), this.A.H(a.zb(El(100))));
        this.j.H(a)
    };
    var fm = function(a, b) {
        eO.call(this, 1036, b);
        this.j = X(this);
        this.A = Y(this, a)
    };
    _.T(fm, eO);
    fm.prototype.g = function() {
        var a = this.A.value;
        Cl(a) !== 0 && this.j.H(a)
    };
    var Pl = function(a, b, c) {
        eO.call(this, 1046, c);
        this.output = VM(this);
        this.j = X(this);
        this.A = Y(this, b);
        YM(this, a)
    };
    _.T(Pl, eO);
    Pl.prototype.g = function() {
        this.j.H(this.A.value)
    };
    var Ml = function(a, b, c) {
        eO.call(this, 1047, c);
        this.collectorFunction = a;
        this.j = X(this);
        this.A = X(this);
        this.C = X(this);
        this.G = Y(this, b)
    };
    _.T(Ml, eO);
    Ml.prototype.g = function() {
        var a = this,
            b = this.G.value,
            c = xl(b, 1);
        rl(18, c);
        try {
            var d = _.wk();
            this.collectorFunction().then(function(e) {
                rl(29, c, null, {
                    delta: String(_.wk() - d)
                });
                a.j.H(_.tj(b, 2, e));
                a.C.ic(e)
            }).catch(function(e) {
                rl(28, c, Hl(e));
                a.A.H(b.zb(El(106)))
            })
        } catch (e) {
            rl(1, c, Hl(e)), this.A.H(b.zb(El(107)))
        }
    };
    var Kl = function(a, b) {
        eO.call(this, 1028, b);
        this.j = X(this);
        this.A = Y(this, a)
    };
    _.T(Kl, eO);
    Kl.prototype.g = function() {
        var a = this.A.value,
            b = xl(a, 1);
        _.ud(_.tA(a, 3)) != null || rl(35, b);
        this.j.H(a)
    };
    var Nl = function(a, b, c, d) {
        eO.call(this, 1050, d);
        this.C = c;
        this.j = X(this);
        this.A = Y(this, a);
        this.G = WM(this, b)
    };
    _.T(Nl, eO);
    Nl.prototype.g = function() {
        var a = this.A.value,
            b = xl(a, 1),
            c = this.G.value;
        if (c == null) rl(41, b), a.zb(El(111)), this.j.H(a);
        else if (typeof c !== "string") rl(21, b), this.j.H(a.zb(El(113)));
        else {
            if (c.length > this.C) {
                var d = {};
                rl(12, b, null, (d.sl = String(c.length), d));
                b = a.zb(El(108));
                _.vj(b, 2)
            } else c.length || rl(20, b), _.vj(a, 10);
            this.j.H(a)
        }
    };
    var Ol = function(a) {
        eO.call(this, 1046, a);
        this.output = VM(this)
    };
    _.T(Ol, eO);
    Ol.prototype.g = function() {
        var a = this;
        sl().then(function() {
            a.output.notify()
        })
    };
    var gO = function(a, b, c, d, e) {
        eO.call(this, 1059, e);
        this.S = a;
        this.G = c;
        this.C = d;
        this.j = X(this);
        this.I = Y(this, b);
        this.A = WM(this, d)
    };
    _.T(gO, eO);
    gO.prototype.g = function() {
        var a = this.A.value;
        if (a) {
            var b = this.I.value,
                c = b.id,
                d = b.collectorFunction,
                e;
            b = (e = b.networkCode) != null ? e : c;
            c = {};
            rl(42, b, null, (c.ea = String(Number(this.G)), c));
            this.j.pb(Ql(this.S, b, d, a, this.C, this.Qa))
        }
    };
    var hO = function(a, b, c) {
        c = c === void 0 ? Ul : c;
        eO.call(this, 1057, b);
        this.j = a;
        this.A = c;
        this.C = X(this);
        this.G = X(this)
    };
    _.T(hO, eO);
    hO.prototype.g = function() {
        if (this.j)
            if (typeof this.j !== "object") rl(46, "UNKNOWN_COLLECTOR_ID"), iO(this, "UNKNOWN_COLLECTOR_ID", 112);
            else {
                var a = this.j.id,
                    b = this.j.networkCode;
                a && b && (delete this.j.id, rl(47, a + ";" + b));
                a = b != null ? b : a;
                typeof a !== "string" ? (b = {}, rl(37, "INVALID_COLLECTOR_ID", null, (b.ii = JSON.stringify(a), b)), iO(this, "INVALID_COLLECTOR_ID", 102)) : typeof this.j.collectorFunction !== "function" ? (rl(14, a), iO(this, a, 105)) : _.w(this.A.Wg, "includes").call(this.A.Wg, a) ? (rl(22, a), iO(this, a, 104)) : this.G.H(this.j)
            }
        else rl(39, "UNKNOWN_COLLECTOR_ID"), iO(this, "UNKNOWN_COLLECTOR_ID", 110)
    };
    var iO = function(a, b, c) {
        a.C.H(QC(b).zb(El(c)))
    };
    var $l = function(a, b, c, d, e, f) {
        var g = document;
        g = g === void 0 ? document : g;
        f = f === void 0 ? Ul : f;
        this.S = a;
        this.o = c;
        this.j = d;
        this.ga = g;
        this.C = e;
        this.g = f;
        this.A = [];
        this.F = [];
        this.J = [];
        this.l = 0;
        a = _.y(b);
        for (b = a.next(); !b.done; b = a.next()) this.push(b.value)
    };
    _.q = $l.prototype;
    _.q.push = function(a) {
        var b = this;
        this.j || this.C();
        var c = function(f, g) {
            return void b.Qa(f, g)
        };
        a = new hO(a, c, this.g);
        var d = new Jl(a.C, this.o, null, c);
        c = new gO(this.S, a.G, this.j, this.o, c, this.g);
        var e = new L(this.S, 3);
        cm(e, [a, d, c]);
        e.run();
        a = c.j.promise;
        this.A.push(a);
        d = _.y(this.F);
        for (c = d.next(); !c.done; c = d.next()) a.then(c.value)
    };
    _.q.addOnSignalResolveCallback = function(a) {
        this.F.push(a);
        for (var b = _.y(this.A), c = b.next(); !c.done; c = b.next()) c.value.then(a)
    };
    _.q.addErrorHandler = function(a) {
        this.J.push(a)
    };
    _.q.clearAllCache = function() {
        var a = this,
            b = this.ga.currentScript instanceof HTMLScriptElement ? this.ga.currentScript.src : "";
        if (this.l === 1) {
            var c = {};
            rl(49, "", null, (c.url = b, c))
        } else if (_.w(this.g.Jg, "includes").call(this.g.Jg, String(_.aj(b != null ? b : "")))) c = {}, rl(48, "", null, (c.url = b, c));
        else {
            var d = new L(this.S, 4);
            c = new fO(this.o, function(e, f) {
                return void a.Qa(e, f)
            });
            M(d, c);
            d.run();
            this.l = 1;
            setTimeout(function() {
                a.l = 0
            }, this.g.sj * 1E3);
            d = {};
            rl(43, "", null, (d.url = b, d));
            return c.j.promise
        }
    };
    _.q.Qa = function(a, b) {
        for (var c = _.y(this.J), d = c.next(); !d.done; d = c.next()) d = d.value, d(a, b)
    };
    var am = function(a) {
        this.push = function(b) {
            a.push(b)
        };
        this.addOnSignalResolveCallback = function(b) {
            a.addOnSignalResolveCallback(b)
        };
        this.addErrorHandler = function(b) {
            a.addErrorHandler(b)
        };
        this.clearAllCache = function() {
            a.clearAllCache()
        }
    };
    var gm = function(a, b, c) {
        eO.call(this, 1035, c);
        this.A = b;
        this.j = X(this);
        this.C = Y(this, a)
    };
    _.T(gm, eO);
    gm.prototype.g = function() {
        var a = this,
            b = this.C.value,
            c = xl(b, 1),
            d = this.A.toString(),
            e = {};
        rl(30, c, null, (e.url = d, e));
        var f = document.createElement("script");
        f.setAttribute("esp-signal", "true");
        Xa(f, this.A);
        var g = function() {
            var h = {};
            rl(31, c, null, (h.url = d, h));
            a.j.H(b.zb(El(109)));
            _.Gh(f, "error", g)
        };
        document.head.appendChild(f);
        _.sg(f, "error", g)
    };
    var em = new _.z.Set;
    var jO = Ny(["https://securepubads.g.doubleclick.net/pagead/js/car.js"]),
        kO = Ny(["https://securepubads.g.doubleclick.net/pagead/js/cocar.js"]),
        lO = Ny(["https://ep3.adtrafficquality.google/ivt/worklet/caw.js"]);
    _.ng(jO);
    _.ng(kO);
    var om = _.ng(lO);
    var qm = function(a, b) {
        try {
            var c = _.R(b, 6) === void 0 ? !0 : _.R(b, 6),
                d, e, f = Bg(_.Sh(b, 2, 0)),
                g = _.t(b, 3);
            a: switch (_.Sh(b, 4, 0)) {
                case 1:
                    var h = "pt";
                    break a;
                case 2:
                    h = "cr";
                    break a;
                default:
                    h = ""
            }
            var l = new GB(f, g, h),
                k = (e = (d = _.Fi(b, DB, 5)) == null ? void 0 : _.t(d, 1)) != null ? e : "";
            l.ve = k;
            l.g = c;
            var m = !!_.R(b, 7);
            l.qc = m;
            l.B = a;
            var n = l.build();
            Ag(n)
        } catch (p) {}
    };
    var mO = function(a, b, c, d, e) {
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = d === void 0 ? 0 : d;
        this.slotId = e;
        this.taskId = void 0;
        this.uniqueId = Math.random()
    };
    var nO = _.ca.performance,
        oO = !!(nO && nO.mark && nO.measure && nO.clearMarks),
        pO = wo(function() {
            var a;
            if (a = oO) a = LL(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        }),
        qO = function(a, b) {
            this.events = [];
            this.l = b || _.ca;
            var c = null;
            b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.events = b.google_js_reporting_queue, c = b.google_measure_js_timing);
            this.g = pO() || (c != null ? c : Math.random() < a)
        },
        sO;
    qO.prototype.disable = function() {
        this.g = !1;
        this.events != this.l.google_js_reporting_queue && (pO() && _.Jz(this.events, _.rO), this.events.length = 0)
    };
    _.rO = function(a) {
        a && nO && pO() && (nO.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), nO.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
    };
    sO = function(a, b, c, d, e, f) {
        a.g && (b = new mO(b, c, d, e === void 0 ? 0 : e, f), !a.g || a.events.length > 2048 || a.events.push(b))
    };
    qO.prototype.start = function(a, b) {
        if (!this.g) return null;
        var c = _.xk() || _.wk();
        a = new mO(a, b, c);
        b = "goog_" + a.label + "_" + a.uniqueId + "_start";
        nO && pO() && nO.mark(b);
        return a
    };
    qO.prototype.end = function(a) {
        if (this.g && typeof a.value === "number") {
            var b = _.xk() || _.wk();
            a.duration = b - a.value;
            b = "goog_" + a.label + "_" + a.uniqueId + "_end";
            nO && pO() && nO.mark(b);
            !this.g || this.events.length > 2048 || this.events.push(a)
        }
    };
    var Nv = function(a, b, c) {
        var d = _.xk();
        d && sO(a, b, 9, d, 0, c)
    };
    var tO = function(a) {
        this.D = _.A(a)
    };
    _.T(tO, _.B);
    tO.prototype.g = ag([0, _.aB, -3, _.iB]);
    var uO = [.05, .1, .2, .5],
        vO = [0, .5, 1],
        wO = function(a) {
            a = Wl(a);
            if (!a) return -1;
            try {
                var b = OL(a.document);
                var c = new _.mo(b.clientWidth, b.clientHeight)
            } catch (d) {
                c = new _.mo(-12245933, -12245933)
            }
            return c.width == -12245933 || c.height == -12245933 ? -1 : c.width * c.height
        },
        xO = function(a, b) {
            return a <= 0 || b <= 0 ? [] : uO.map(function(c) {
                return Math.min(a / b * c, 1)
            })
        },
        zO = function(a) {
            this.J = a.B;
            this.j = a.Qb;
            this.A = a.timer;
            this.l = null;
            this.g = a.Hb;
            this.o = yO(this);
            this.F = a.sp || !1
        },
        AO = function() {
            var a;
            return !!window.IntersectionObserver && kE((a = window.performance) == null ? void 0 : a.now)
        };
    zO.prototype.getSlotId = function() {
        return this.l
    };
    var CO = function(a, b) {
            if (a.o) {
                if (a.l != null) {
                    try {
                        BO(a, Math.round(performance.now()), 0, 0, 0, !1)
                    } catch (c) {
                        a.g && a.g(c)
                    }
                    a.o && a.o.unobserve(a.j)
                }
                a.l = b;
                a.o.observe(a.j)
            }
        },
        yO = function(a) {
            if (!_.ca.IntersectionObserver) return null;
            var b = a.j.offsetWidth * a.j.offsetHeight,
                c = wO(a.J);
            b = [].concat(_.Zk(vO), _.Zk(xO(c, b)));
            ib(b);
            return new _.ca.IntersectionObserver(function(d) {
                try {
                    for (var e = wO(a.J), f = _.y(d), g = f.next(); !g.done; g = f.next()) {
                        var h = g.value,
                            l = Math.round(h.boundingClientRect.width * h.boundingClientRect.height),
                            k = Math.round(h.intersectionRect.width * h.intersectionRect.height),
                            m = Math.round(h.time);
                        if (_.w(Number, "isSafeInteger").call(Number, l) && _.w(Number, "isSafeInteger").call(Number, k) && _.w(Number, "isSafeInteger").call(Number, e) && _.w(Number, "isSafeInteger").call(Number, m)) a.F && BO(a, m, l, k, e, h.isIntersecting);
                        else {
                            var n = d = void 0;
                            (n = (d = a).g) == null || n.call(d, Error("invalid geometry: " + l + " | " + k + " | " + e + " | " + m))
                        }
                    }
                } catch (p) {
                    a.g && a.g(p)
                }
            }, {
                threshold: b
            })
        },
        BO = function(a, b, c, d, e, f) {
            if (a.l == null) throw Error("Not Attached.");
            var g = new tO;
            c = _.Dm(g, 1, c);
            d = _.Dm(c, 2, d);
            e = _.Dm(d, 3, e);
            b = _.Dm(e, 4, b);
            f = _.Dl(b, 5, f);
            f = Ab(f.g(), 4);
            sO(a.A, "1", 10, f, void 0, a.l)
        };
    var DO = function(a, b) {
            this.g = a;
            this.o = b
        },
        EO = function(a) {
            if (a.g.frames.google_ads_top_frame) return !0;
            var b = mE(a.g);
            b = b && b.contentWindow;
            if (!b) return !1;
            b.addEventListener("message", function(c) {
                var d = c.data;
                c = c.ports;
                d.msgType === "__goog_top_url_req" && c.length && c[0].postMessage({
                    msgType: "__goog_top_url_resp",
                    topUrl: a.o
                })
            }, !1);
            return !0
        };
    var Cm = function(a) {
        this.D = _.A(a)
    };
    _.T(Cm, _.B);
    var Hm = bg(Cm),
        Em = [1, 3];
    var lc = {
        fr: 0,
        br: 1,
        cr: 9,
        Yq: 2,
        Zq: 3,
        er: 5,
        dr: 7,
        ar: 10
    };
    var FO = Ny(["https://securepubads.g.doubleclick.net/static/topics/topics_frame.html"]),
        xm = _.ng(FO);
    var xr = function(a) {
            var b = b === void 0 ? ql(_.ca) : b;
            this.id = a;
            this.g = Math.random() < .001;
            this.params = {
                pvsid: String(b)
            }
        },
        GO = function(a) {
            a = ln(a);
            var b;
            Vr.set(a, ((b = Vr.get(a)) != null ? b : 0) + 1)
        },
        HO = function() {
            return [].concat(_.Zk(_.w(Vr, "values").call(Vr))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        zr = function(a, b, c) {
            typeof c !== "string" && (c = String(c));
            /^\w+$/.test(b) && (c ? a.params[b] = c : delete a.params[b])
        },
        Br = function(a) {
            var b = 1;
            b = b === void 0 ? null : b;
            if (IO()) b = !0;
            else {
                var c = a.g;
                b && b >= 0 && (c = Math.random() < b);
                b = c && !!a.id
            }
            b && dG(window, JO(a) || "", void 0, !0)
        },
        JO = function(a) {
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + encodeURIComponent(a.id);
            _.$o(a.params, function(c, d) {
                c && (b += "&" + d + "=" + encodeURIComponent(c))
            });
            return b
        },
        KO = function(a) {
            var b = [].concat(_.Zk(_.w(Vr, "keys").call(Vr)));
            b = b.map(function(c) {
                return c.replace(/,/g, "\\,")
            });
            b.length <= 3 ? zr(a, "nw_id", b.join()) : (b = b.slice(0, 3), b.push("__extra__"), zr(a, "nw_id", b.join()))
        },
        yr = function(a, b) {
            zr(a, "vrg", b.Df);
            KO(a);
            zr(a, "nslots", HO().toString());
            b = Ui();
            b.length && zr(a, "eid", b.join());
            zr(a, "pub_url", document.URL)
        },
        ks = function(a, b, c) {
            c = c === void 0 ? .001 : c;
            if (c === void 0 || c < 0 || c > 1) c = .001;
            Math.random() < c && (a = new xr(a), b(a), Br(a))
        },
        Vr = new _.z.Map,
        IO = wo(function() {
            return !!gE()
        });
    var po = function() {
        qO.call(this, _.I(zJ) || _.I(zK) ? 1 : 0, _.ca);
        this.o = 0;
        var a = _.I(zJ) || _.I(zK);
        _.ca.google_measure_js_timing = a || _.ca.google_measure_js_timing
    };
    _.T(po, qO);
    _.mn = function(a) {
        this.context = a;
        this.g = !1
    };
    _.q = _.mn.prototype;
    _.q.Lb = function(a, b) {
        return this.Aa(a, b)()
    };
    _.q.Aa = function(a, b) {
        var c = this;
        return function() {
            var d = _.Ia.apply(0, arguments),
                e = void 0,
                f = !1,
                g = null,
                h = _.Ri(po);
            try {
                var l = _.I(zJ);
                l && h && (g = h.start(a.toString(), 3));
                e = b.apply(this, d);
                f = !0;
                l && h && h.end(g)
            } catch (k) {
                try {
                    if (f) c.ob(110, k);
                    else if (c.ob(a, k), !c.g) throw k;
                } catch (m) {
                    if (_.rO(g), !f && !c.g) throw k;
                }
            }
            return e
        }
    };
    _.q.rd = ba(2);
    _.q.ob = function(a, b) {
        if (!this.context.Ai) return this.g;
        b = _.cG(b) ? b.error : b;
        var c = new vH,
            d = new tH;
        try {
            var e = ql(window);
            _.Fk(d, 1, e)
        } catch (n) {}
        try {
            var f = Ui();
            _.Ve(d, 2, f, Yc)
        } catch (n) {}
        try {
            _.Ek(d, 3, window.document.URL)
        } catch (n) {}
        e = _.Wg(c, 2, d);
        f = new rH;
        a = _.H(f, 1, a);
        try {
            var g = wc(b == null ? void 0 : b.name) ? b.name : "Unknown error";
            _.Ek(a, 2, g)
        } catch (n) {}
        try {
            var h = wc(b == null ? void 0 : b.message) ? b.message : "Caught " + b;
            _.Ek(a, 3, h)
        } catch (n) {}
        try {
            var l = wc(b == null ? void 0 : b.stack) ? b.stack : Error().stack;
            l && _.Ve(a, 4, l.split(/\n\s*/), _.Bd)
        } catch (n) {}
        g = _.en(e, 1, wH, a);
        h = this.context;
        l = new mH;
        try {
            _.Ek(l, 1, h.Ra)
        } catch (n) {}
        try {
            var k = HO();
            _.Pg(l, 2, k)
        } catch (n) {}
        try {
            var m = [].concat(_.Zk(_.w(Vr, "keys").call(Vr)));
            _.Ve(l, 3, m, _.Bd)
        } catch (n) {}
        _.en(g, 4, xH, l);
        _.Fk(g, 5, this.context.fh);
        this.context.va.ll(g);
        return this.g
    };
    _.q.Te = function(a) {
        this.g = a
    };
    var LO = function() {
            this.id = "goog_" + Mz++
        },
        MO = function(a) {
            _.W.call(this);
            this.context = a;
            this.g = new _.z.Map
        };
    _.T(MO, _.W);
    MO.prototype.o = function() {
        _.W.prototype.o.call(this);
        this.g.clear()
    };
    MO.prototype.listen = function(a, b) {
        var c = this;
        if (this.J) return function() {};
        var d = typeof a === "string" ? a : a.id,
            e, f, g = (f = (e = this.g.get(d)) == null ? void 0 : e.add(b)) != null ? f : new _.z.Set([b]);
        this.g.set(d, g);
        return function() {
            return void NO(c, a, b)
        }
    };
    var OO = function(a) {
            var b = Fx;
            var c = c === void 0 ? function() {
                return !0
            } : c;
            return new _.z.Promise(function(d) {
                var e = a.listen(b, function(f) {
                    c(f) && (e(), d(f))
                })
            })
        },
        NO = function(a, b, c) {
            var d;
            return !((d = a.g.get(typeof b === "string" ? b : b.id)) == null || !d.delete(c))
        };
    MO.prototype.dispatchEvent = function(a, b, c) {
        var d = this,
            e, f, g, h, l, k, m, n;
        return _.ug(function(p) {
            e = typeof a === "string" ? a : a.id;
            f = d.g.get(e);
            if ((g = f) == null || !g.size) return p.return();
            h = typeof window.CustomEvent === "function" ? new CustomEvent(e, {
                detail: c,
                bubbles: !0,
                cancelable: !0
            }) : function() {
                var r = document.createEvent("CustomEvent");
                r.initCustomEvent(e, !0, !0, c);
                return r
            }();
            l = [];
            k = _.y(f);
            m = k.next();
            for (n = {}; !m.done; n = {
                    Dh: void 0
                }, m = k.next()) n.Dh = m.value, l.push(new _.z.Promise(function(r) {
                return function(v) {
                    return _.ug(function(u) {
                        if (u.g == 1) return u.yield(0, 2);
                        pn(d.context, b, function() {
                            d.g.has(e) && f.has(r.Dh) && (0, r.Dh)(h)
                        }, !0);
                        v();
                        u.g = 0
                    })
                }
            }(n)));
            return p.yield(_.z.Promise.all(l), 0)
        })
    };
    var PO = new LO,
        QO = new LO,
        Pv = new LO,
        RO = new LO,
        Rv = new LO,
        SO = new LO,
        TO = new LO,
        Ft = new LO,
        Fx = new LO,
        UO = new LO;
    var VO = function() {
        this.data = void 0;
        this.status = 0;
        this.g = []
    };
    VO.prototype.getStatus = function() {
        return this.status
    };
    var WO = function(a) {
        a.data = void 0;
        a.status = 1
    };
    var XO, $O, cP, Cx, rt, vt, ZO, YO, dP;
    XO = function() {
        this.g = new _.z.Map;
        this.F = 0;
        this.o = new _.z.Map;
        this.ac = null;
        this.j = this.l = this.G = this.A = 0;
        this.Xj = null;
        this.C = new VO;
        this.J = new VO
    };
    $O = function(a, b) {
        a.g.get(b) || (a.g.set(b, {
            td: !0,
            gi: "",
            Xd: "",
            Zk: 0,
            bi: [],
            di: [],
            cd: !1,
            yr: -1,
            xi: 0,
            fi: 0
        }), _.$q(b, function() {
            a.g.delete(b);
            YO(a, b)
        }), b.listen(QO, function(c) {
            c = c.detail;
            var d = a.g.get(b);
            d.gi = _.t(c, 33) || "";
            d.cd = !0;
            ZO(a, b, function() {
                return void(d.gi = "")
            });
            vt(a, b, function() {
                return void(d.cd = !1)
            })
        }))
    };
    _.Qv = function(a, b) {
        var c;
        return (c = a.g.get(b)) == null ? void 0 : c.td
    };
    _.aP = function(a, b) {
        if (a = a.g.get(b)) a.td = !1
    };
    _.bP = function(a, b) {
        if (a = a.g.get(b)) a.td = !0
    };
    cP = function(a, b) {
        if (!b.length) return [];
        var c = ln(b[0].getAdUnitPath());
        b.every(function(g) {
            return ln(g.getAdUnitPath()) === c
        });
        var d = [];
        a = _.y(a.g);
        for (var e = a.next(); !e.done; e = a.next()) {
            var f = _.y(e.value);
            e = f.next().value;
            (f = f.next().value.gi) && ln(e.getAdUnitPath()) === c && !_.w(b, "includes").call(b, e) && d.push(f)
        }
        return d
    };
    Cx = function(a, b) {
        var c, d;
        return (d = (c = a.g.get(b)) == null ? void 0 : c.Xd) != null ? d : ""
    };
    rt = function(a, b) {
        return (a = a.g.get(b)) ? a.Zk - 1 : 0
    };
    vt = function(a, b, c) {
        (a = a.g.get(b)) && a.bi.push(c)
    };
    ZO = function(a, b, c) {
        (a = a.g.get(b)) && a.di.push(c)
    };
    YO = function(a, b) {
        if (a = a.g.get(b))
            for (b = a.di.slice(), a.di.length = 0, a = _.y(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    dP = function(a, b) {
        if (a = a.g.get(b))
            for (b = a.bi.slice(), a.bi.length = 0, a = _.y(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    XO.prototype.cd = function(a) {
        var b, c;
        return (c = (b = this.g.get(a)) == null ? void 0 : b.cd) != null ? c : !1
    };
    var eP = function(a, b, c) {
            if (a = a.g.get(b)) a.Yk = c
        },
        fP = function(a, b) {
            if (a = a.g.get(b)) {
                var c;
                (c = a.Yk) == null || c.dispose();
                delete a.Yk
            }
        },
        gP = function(a, b) {
            return (a = a.g.get(b)) ? a.xi : 0
        },
        hP = function(a, b) {
            (a = a.g.get(b)) && ++a.xi
        },
        iP = function(a, b) {
            var c;
            return (c = a.g.get(b)) == null ? void 0 : c.fi
        };
    var sn = new _.z.Map,
        rn = new _.z.Map;
    var un = function(a, b) {
        this.messageId = a;
        this.messageArgs = b
    };
    un.prototype.getMessageId = function() {
        return this.messageId
    };
    un.prototype.getMessageArgs = function() {
        return this.messageArgs
    };
    var jP = O(2),
        kP = O(3),
        lP = O(4),
        mP = O(5),
        nP = O(6),
        oP = O(12),
        pP = O(14),
        qP = O(16),
        On = O(19),
        rP = O(20),
        sP = O(23),
        tP = O(26),
        uP = O(28),
        vP = O(149),
        wP = O(30),
        xP = O(31),
        yP = O(34),
        zP = O(35),
        Oo = O(36),
        iw = O(38),
        AP = O(40),
        BP = O(48),
        CP = O(50),
        DP = O(60),
        EP = O(63),
        FP = O(64),
        GP = O(66),
        HP = O(68),
        IP = O(69),
        JP = O(70),
        KP = O(71),
        LP = O(78),
        MP = O(80),
        sp = O(82),
        Pn = O(84),
        NP = O(85),
        OP = O(87),
        In = O(88),
        PP = O(92),
        QP = O(93),
        RP = O(99),
        Rn = O(103),
        qp = O(104),
        SP = O(105),
        kp = O(106),
        lp = O(107),
        rp = O(108),
        TP = O(113),
        UP = O(114),
        VP = O(115),
        WP = O(117),
        XP = O(167),
        YP = O(118),
        ZP = O(120),
        mr = O(119),
        ap = O(121),
        $P = O(122),
        fy = O(123),
        aQ = O(126),
        bQ = O(127),
        cQ = O(144),
        ku = O(129),
        mu = O(132),
        dQ = O(134),
        eQ = O(135),
        fQ = O(136),
        gQ = O(137),
        hQ = O(138),
        iQ = O(139),
        jQ = O(140),
        kQ = O(143),
        lQ = O(145),
        mQ = O(147),
        nQ = O(150),
        oQ = O(164),
        pQ = O(152),
        qQ = O(153),
        rQ = O(154),
        xu = O(155),
        Yp = O(156),
        eq = O(157),
        Zp = O(158),
        $p = O(159),
        Xp = O(160),
        Qu = O(168),
        sQ = O(161),
        tQ = O(162),
        uQ = O(165),
        vQ = O(166),
        wQ = O(169);
    var xQ = function(a, b, c) {
        var d = this;
        this.addEventListener = N(a, 86, function(e, f) {
            if (typeof f !== "function") return Q(b, wn("Service.addEventListener", [e, f])), d;
            var g = xn(e);
            if (!g) return Q(b, QP(e)), d;
            c.addEventListener(g, f);
            return d
        });
        this.removeEventListener = N(a, 904, function(e, f) {
            var g = xn(e);
            typeof f === "function" && g ? c.removeEventListener(g, f) : Q(b, wn("Service.removeEventListener", [e, f]))
        });
        this.getSlots = N(a, 573, function() {
            return c.g.map(function(e) {
                return e.Ba
            })
        });
        this.getSlotIdMap = N(a, 574, function() {
            for (var e = {}, f = _.y(c.g), g = f.next(); !g.done; g = f.next()) g = g.value, e[g.toString()] = g.Ba;
            return e
        });
        this.getName = N(a, 575, function() {
            return c.getName()
        })
    };
    var yn = function(a, b, c) {
        xQ.call(this, a, b, c);
        this.setRefreshUnfilledSlots = N(a, 59, function(d) {
            c.setRefreshUnfilledSlots(d)
        });
        this.notifyUnfilledSlots = N(a, 69, function(d) {
            c.td && yQ(c, zQ(c, d))
        });
        this.refreshAllSlots = N(a, 60, function() {
            c.td && yQ(c)
        });
        this.setVideoSession = N(a, 61, function(d, e, f) {
            c.j = e;
            c.A = f;
            typeof d === "number" && (e = qo().g, _.vj(e, 29, _.xd(d)))
        });
        this.getDisplayAdsCorrelator = N(a, 62, function() {
            return String(xA(qo().g, 26))
        });
        this.getVideoStreamCorrelator = N(a, 63, function() {
            var d = qo().g;
            d = ev(d, 29);
            return d != null ? d : 0
        });
        this.isSlotAPersistentRoadblock = N(a, 64, function(d) {
            var e = _.w(c.g, "find").call(c.g, function(f) {
                return f.Ba === d
            });
            return !!e && AQ(c, e)
        });
        this.onImplementationLoaded = N(a, 65, function() {
            c.V.info(BP("GPT CompanionAds"))
        });
        this.slotRenderEnded = N(a, 67, function(d, e, f) {
            var g = _.w(c.g, "find").call(c.g, function(h) {
                return h.Ba === d
            });
            return g && BQ(c, g, e, f)
        })
    };
    _.T(yn, xQ);
    var An = function(a, b, c) {
        xQ.call(this, a, b, c);
        this.setContent = N(a, 72, function(d) {
            var e = _.w(c.g, "find").call(c.g, function(f) {
                return f.Ba === d
            });
            b.error(cQ(), e)
        })
    };
    _.T(An, xQ);
    var Hn = function(a) {
        this.D = _.A(a)
    };
    _.T(Hn, _.B);
    var Gn = function(a, b) {
            return _.tj(a, 1, b)
        },
        Ln = function(a, b) {
            return _.Ou(a, 2, _.wl(b))
        },
        Fn = function(a, b) {
            return _.Ve(a, 2, b, _.Bd)
        },
        No = function(a, b) {
            return _.df(a, 2, _.Bd, b, Dd)
        };
    var CQ = function(a) {
        this.D = _.A(a)
    };
    _.T(CQ, _.B);
    CQ.prototype.setTagForChildDirectedTreatment = function(a) {
        return _.uj(this, 5, a)
    };
    CQ.prototype.clearTagForChildDirectedTreatment = function() {
        return _.vj(this, 5)
    };
    CQ.prototype.setTagForUnderAgeOfConsent = function(a) {
        return _.uj(this, 6, a)
    };
    var As = function(a) {
        this.D = _.A(a)
    };
    _.T(As, _.B);
    var Up = function(a) {
        var b = new As;
        return _.Dl(b, 1, a)
    };
    var DQ = function(a) {
        this.D = _.A(a)
    };
    _.T(DQ, _.B);
    var EQ = function(a) {
        this.D = _.A(a)
    };
    _.T(EQ, _.B);
    var Zo = function(a) {
        this.D = _.A(a)
    };
    _.T(Zo, _.B);
    var ju = function(a) {
        this.D = _.A(a)
    };
    _.T(ju, _.B);
    var iu = function(a, b) {
            return _.uj(a, 1, b)
        },
        hu = function(a, b) {
            return _.Ve(a, 2, b, _.Bd)
        };
    var FQ = [0, tB, _.mB];
    var GQ = function(a) {
        this.D = _.A(a)
    };
    _.T(GQ, _.B);
    var gu = function(a, b) {
        Fl(a, 1, ju, b)
    };
    var HQ = [0, _.pB, FQ];
    var Su = function(a) {
        this.D = _.A(a)
    };
    _.T(Su, _.B);
    var Ru = function(a) {
        this.D = _.A(a)
    };
    _.T(Ru, _.B);
    var IQ = function(a) {
        this.D = _.A(a)
    };
    _.T(IQ, _.B);
    var jp = function(a) {
        return _.ul(a, Hn, 2, _.wl())
    };
    IQ.prototype.getCategoryExclusions = function(a) {
        return CA(this, 3, a)
    };
    IQ.prototype.Ya = function() {
        return _.ul(this, Hn, 14, _.wl())
    };
    IQ.prototype.bd = function() {
        return _.Fi(this, Zo, 18)
    };
    var by = function(a) {
        return _.Fi(a, CQ, 25)
    };
    IQ.prototype.getCorrelator = function() {
        var a = a === void 0 ? sA : a;
        var b = _.tA(this, 26);
        var c = typeof b;
        b = b == null ? b : c === "bigint" ? Bc(BigInt.asUintN(64, b)) : Tc(b) ? c === "string" ? sd(b) : qd(b) : void 0;
        return gf(b, a)
    };
    IQ.prototype.setCorrelator = function(a) {
        return _.vj(this, 26, _.xd(a))
    };
    var oo = function() {
        this.g = new _.z.Map
    };
    var JQ = {},
        Un = (JQ[253] = !1, JQ[246] = [], JQ[150] = "", JQ[263] = !1, JQ[36] = /^true$/.test("false"), JQ[264] = !1, JQ[172] = null, JQ[260] = void 0, JQ[251] = null, JQ),
        Tn = function() {
            this.g = !1
        };
    var KQ = function() {
            this.bb = {};
            this.g = new IQ;
            this.l = new _.z.Map;
            this.o = {};
            this.g.setCorrelator(tE());
            _.Vn(36) && _.Dl(this.g, 15, !0)
        },
        LQ = function(a) {
            var b = qo(),
                c = a.getDomId();
            if (c && !b.bb.hasOwnProperty(c)) {
                var d = _.Ri(oo),
                    e = ++_.Ri(po).o;
                d.g.set(c, e);
                _.vj(a, 20, _.ad(e));
                b.bb[c] = a
            }
        },
        MQ = function(a, b) {
            return a.bb[b]
        },
        qo = function() {
            return _.Ri(KQ)
        };
    var NQ = {},
        OQ = (NQ.companion_ads = "companionAds", NQ.content = "content", NQ.publisher_ads = "pubads", NQ);
    var PQ = wo(to);
    var Fo = function(a, b, c, d) {
        var e = this,
            f = c.getSlotId(),
            g = qo().g,
            h = MQ(qo(), f.getDomId());
        this.set = N(a, 83, function(l, k) {
            l === "page_url" && k && (l = [Fn(Gn(new Hn, l), [String(k)])], _.Qn(h, 3, l));
            return e
        });
        this.get = N(a, 84, function(l) {
            if (l !== "page_url") return null;
            var k, m;
            return (m = (k = (_.E = h.Ya(), _.w(_.E, "find")).call(_.E, function(n) {
                return xl(n, 1) === l
            })) == null ? void 0 : Ln(k)[0]) != null ? m : null
        });
        this.setClickUrl = N(a, 79, function(l) {
            Cn(l, h, f, b);
            return e
        });
        this.setTargeting = N(a, 81, function(l, k) {
            Jn(l, k, f, h, b);
            return e
        });
        this.updateTargetingFromMap = N(a, 85, function(l) {
            Kn(l, f, h, b);
            return e
        });
        this.display = N(a, 78, function() {
            var l = ro(g, qo().bb);
            var k = k === void 0 ? document : k;
            var m;
            (m = l.W[f.getDomId()]) != null && _.Dl(m, 19, !0);
            m = f.getDomId();
            Cz.test(m) && (m.indexOf("&") != -1 && (m = m.replace(wz, "&amp;")), m.indexOf("<") != -1 && (m = m.replace(xz, "&lt;")), m.indexOf(">") != -1 && (m = m.replace(yz, "&gt;")), m.indexOf('"') != -1 && (m = m.replace(zz, "&quot;")), m.indexOf("'") != -1 && (m = m.replace(Az, "&#39;")), m.indexOf("\x00") != -1 && (m = m.replace(Bz, "&#0;")));
            var n = {
                id: m
            };
            var p = p === void 0 ? Fz : p;
            var r = _.w(Object, "assign").call(Object, {}, n);
            m = n.id;
            var v = n.style;
            n = n.data;
            r = (delete r.id, delete r.style, delete r.data, r);
            if (_.w(Object, "keys").call(Object, r).length) throw Error("Invalid attribute(s): " + _.w(Object, "keys").call(Object, r));
            m = {
                id: m,
                style: v ? v : void 0
            };
            if (n)
                for (v = _.y(_.w(n, "entries").call(n)), n = v.next(); !n.done; n = v.next()) r = _.y(n.value), n = r.next().value, r = r.next().value, hc(sN.test(n)), m[n] = r;
            p = lg("div", m, p);
            k.write(_.Ra(p));
            vo(f, k) && (d.enable(), $O(d.L, f), QQ(d, l, f))
        });
        this.setTagForChildDirectedTreatment = N(a, 80, function(l) {
            if (l === 0 || l === 1) {
                var k = by(g) || new CQ;
                k.setTagForChildDirectedTreatment(l);
                _.Wg(g, 25, k)
            }
            return e
        });
        this.setForceSafeFrame = N(a, 567, function(l) {
            typeof l === "boolean" ? _.Dl(h, 12, l) : Q(b, wn("PassbackSlot.setForceSafeFrame", [String(l)]), f);
            return e
        });
        this.setTagForUnderAgeOfConsent = N(a, 448, function(l) {
            if (l === 0 || l === 1) {
                var k = by(g) || new CQ;
                k.setTagForUnderAgeOfConsent(l);
                _.Wg(g, 25, k)
            }
            return e
        })
    };
    var cu = {
        Xq: 0,
        Uq: 1,
        Vq: 2,
        Wq: 3
    };
    var Io = {
            REWARDED: 4,
            TOP_ANCHOR: 2,
            BOTTOM_ANCHOR: 3,
            INTERSTITIAL: 5,
            GAME_MANUAL_INTERSTITIAL: 7,
            LEFT_SIDE_RAIL: 8,
            RIGHT_SIDE_RAIL: 9
        },
        Ko = {
            IAB_AUDIENCE_1_1: 1,
            IAB_CONTENT_2_1: 2,
            IAB_CONTENT_2_2: 3
        },
        Jo = {
            PURCHASED: 1,
            ORGANIC: 2
        };
    var RQ = "",
        Uo = null;
    var Bp = function(a, b, c) {
        MO.call(this, a);
        this.slotId = b;
        this.l = c
    };
    _.T(Bp, MO);
    Bp.prototype.getSlotId = function() {
        return this.slotId
    };
    var nc = function(a, b, c, d) {
        MO.call(this, a);
        this.adUnitPath = b;
        this.Qb = d;
        this.Ba = null;
        this.id = this.adUnitPath + "_" + c
    };
    _.T(nc, MO);
    _.q = nc.prototype;
    _.q.getId = function() {
        return this.id
    };
    _.q.getAdUnitPath = function() {
        return this.adUnitPath
    };
    _.q.getName = function() {
        return this.adUnitPath
    };
    _.q.toString = function() {
        return this.getId()
    };
    _.q.getDomId = function() {
        return this.Qb
    };
    var SQ = function(a, b) {
        a.Ba = b
    };
    var up = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js)/;
    var yp = _.Rs(function() {
            return void pE("google_DisableInitialLoad is deprecated and will be removed. Please use googletag.pubads().isInitialLoadDisabled() instead to check if initial load has been disabled.")
        }),
        TQ = _.Rs(function() {
            return void pE("googletag.pubads().setCookieOptions() has been removed, and no longer has any effect. Consider migrating to Limited Ads.")
        }),
        UQ = _.Rs(function() {
            return void pE("The following functions are deprecated: googletag.pubads().setTagForChildDirectedTreatment(), googletag.pubads().clearTagForChildDirectedTreatment(), googletag.pubads().setRequestNonPersonalizedAds(), and googletag.pubads().setTagForUnderAgeOfConsent(). Please use googletag.pubads().setPrivacySettings() instead.")
        }),
        Dp = function(a, b, c, d, e) {
            xQ.call(this, a, b, c);
            var f = this,
                g = qo().g,
                h = qo().bb,
                l = !1;
            this.setTargeting = N(a, 1, function(k, m) {
                np({
                    key: k,
                    value: m,
                    settings: g,
                    serviceName: c.getName(),
                    qp: c.isEnabled(),
                    Bb: e,
                    V: b,
                    context: a
                });
                return f
            });
            this.clearTargeting = N(a, 2, function(k) {
                tp(k, g, c.getName(), b);
                return f
            });
            this.getTargeting = N(a, 38, function(k) {
                return op(k, g, b)
            });
            this.getTargetingKeys = N(a, 39, function() {
                return pp(g)
            });
            this.setCategoryExclusion = N(a, 3, function(k) {
                typeof k !== "string" || Dn(k) ? Q(b, wn("PubAdsService.setCategoryExclusion", [k])) : ((_.E = _.Ou(g, 3, _.wl()), _.w(_.E, "includes")).call(_.E, k) || _.df(g, 3, _.Bd, k, Dd), b.info(NP(k)));
                return f
            });
            this.clearCategoryExclusions = N(a, 4, function() {
                _.vj(g, 3);
                b.info(OP());
                return f
            });
            this.disableInitialLoad = N(a, 5, function() {
                _.Dl(g, 4, !0);
                l || (l = !0, zp())
            });
            this.enableSingleRequest = N(a, 6, function() {
                if (c.isEnabled() && !_.R(g, 6)) return Q(b, DP("PubAdsService.enableSingleRequest")), !1;
                b.info(EP("single request"));
                _.Dl(g, 6, !0);
                return !0
            });
            this.enableAsyncRendering = N(a, 7, function() {
                return !0
            });
            this.enableSyncRendering = N(a, 8, function() {
                pE("GPT synchronous rendering is no longer supported, ads will be requested and rendered asynchronously. See https://support.google.com/admanager/answer/9212594 for more details.");
                return !1
            });
            this.enableLazyLoad = N(a, 485, function(k) {
                var m = new DQ;
                m = _.Dq(m, 1, 800);
                m = _.Dq(m, 2, 400);
                m = _.vj(m, 3, _.Mc(3));
                if (_.gb(k)) {
                    var n = k.fetchMarginPercent;
                    typeof n === "number" && (n >= 0 ? _.Dq(m, 1, n) : n === -1 && _.vj(m, 1));
                    n = k.renderMarginPercent;
                    typeof n === "number" && (n >= 0 ? _.Dq(m, 2, n) : n === -1 && _.vj(m, 2));
                    k = k.mobileScaling;
                    typeof k === "number" && (k > 0 ? _.vj(m, 3, _.Mc(k)) : k === -1 && _.vj(m, 3, _.Mc(1)))
                }
                window.IntersectionObserver || !xt(m, 1) && !xt(m, 2) ? _.Wg(g, 5, m) : Q(b, nQ())
            });
            this.setCentering = N(a, 9, function(k) {
                k = !!k;
                b.info(FP("centering", String(k)));
                _.Dl(g, 15, k)
            });
            this.definePassback = N(a, 10, function(k, m) {
                return (k = Cp(a, b, c, k, m, d)) && k.Rk
            });
            this.refresh = N(a, 11, function() {
                var k = _.Ia.apply(0, arguments),
                    m = _.y(k),
                    n = m.next().value;
                m = m.next().value;
                m = m === void 0 ? {} : m;
                n && !Array.isArray(n) || !_.gb(m) || m.changeCorrelator && typeof m.changeCorrelator !== "boolean" ? Q(b, wn("PubAdsService.refresh", k)) : (m && m.changeCorrelator === !1 || g.setCorrelator(tE()), n = n ? xp(n, c) : _.I(OJ) ? c.g.filter(function(p) {
                    var r = h[p.getDomId()];
                    return !(!vo(p) && !fo(Wp(r)))
                }) : c.g, c.refresh(ro(g, h), n) || Q(b, wn("PubAdsService.refresh", k)))
            });
            this.enableVideoAds = N(a, 12, function() {
                _.Dl(g, 21, !0);
                VQ(c, g)
            });
            this.setVideoContent = N(a, 13, function(k, m) {
                WQ(c, k, m, g)
            });
            this.collapseEmptyDivs = N(a, 14, function(k) {
                k = k === void 0 ? !1 : k;
                k = k === void 0 ? !1 : k;
                _.Dl(g, 11, !0);
                k = !!k;
                _.Dl(g, 10, k);
                b.info(LP(String(k)));
                return !!_.R(g, 11)
            });
            this.clear = N(a, 15, function(k) {
                if (Array.isArray(k)) {
                    if (!k.length) return !0;
                    var m = xp(k, c);
                    if (m.length) return XQ(c, g, h, m)
                } else if (k === void 0) return XQ(c, g, h, c.g);
                Q(b, wn("PubAdsService.clear", [k]));
                return !1
            });
            this.setLocation = N(a, 16, function(k) {
                typeof k !== "string" ? Q(b, wn("PubAdsService.setLocation", [k])) : _.tj(g, 8, k);
                return f
            });
            this.setCookieOptions = N(a, 17, function() {
                TQ();
                return f
            });
            this.setTagForChildDirectedTreatment = N(a, 18, function(k) {
                UQ();
                if (k !== 1 && k !== 0) return Q(b, $P("PubadsService.setTagForChildDirectedTreatment", bp(k), "0,1")), f;
                var m = by(g) || new CQ;
                m.setTagForChildDirectedTreatment(k);
                _.Wg(g, 25, m);
                return f
            });
            this.clearTagForChildDirectedTreatment = N(a, 19, function() {
                UQ();
                var k = by(g);
                if (!k) return f;
                k.clearTagForChildDirectedTreatment();
                _.Wg(g, 25, k);
                return f
            });
            this.setPublisherProvidedId = N(a, 20, function(k) {
                k = String(k);
                b.info(FP("PPID", k));
                _.tj(g, 16, k);
                return f
            });
            this.set = N(a, 21, function(k, m) {
                Po(k, m, g, c.getName(), b);
                return f
            });
            this.get = N(a, 22, function(k) {
                return Qo(k, g, b)
            });
            this.getAttributeKeys = N(a, 23, function() {
                return Ro(g)
            });
            this.display = N(a, 24, function(k, m, n, p) {
                return void c.display(k, m, d, n, p)
            });
            this.updateCorrelator = N(a, 25, function() {
                pE(wp("update"));
                Q(b, VP());
                g.setCorrelator(tE());
                return f
            });
            this.defineOutOfPagePassback = N(a, 35, function(k) {
                k = Cp(a, b, c, k, [1, 1], d);
                if (!k) return null;
                _.uj(k.settings, 15, 1);
                return k.Rk
            });
            this.setForceSafeFrame = N(a, 36, function(k) {
                typeof k !== "boolean" ? Q(b, wn("PubAdsService.setForceSafeFrame", [bp(k)])) : _.Dl(g, 13, k);
                return f
            });
            this.setSafeFrameConfig = N(a, 37, function(k) {
                var m = cp(b, k);
                m ? _.Wg(g, 18, m) : Q(b, wn("PubAdsService.setSafeFrameConfig", [k]));
                return f
            });
            this.setRequestNonPersonalizedAds = N(a, 445, function(k) {
                UQ();
                if (k !== 0 && k !== 1) return Q(b, $P("PubAdsService.setRequestNonPersonalizedAds", bp(k), "0,1")), f;
                var m = by(g) || new CQ;
                _.Dl(m, 8, !!k);
                _.Wg(g, 25, m);
                return f
            });
            this.setTagForUnderAgeOfConsent = N(a, 447, function(k) {
                k = k === void 0 ? 2 : k;
                UQ();
                if (k !== 2 && k !== 0 && k !== 1) return Q(b, $P("PubadsService.setTagForUnderAgeOfConsent", bp(k), "2,0,1")), f;
                var m = by(g) || new CQ;
                m.setTagForUnderAgeOfConsent(k);
                _.Wg(g, 25, m);
                return f
            });
            this.getCorrelator = N(a, 27, function() {
                return String(xA(g, 26))
            });
            this.getTagSessionCorrelator = N(a, 631, function() {
                return ql(_.ca)
            });
            this.getVideoContent = N(a, 30, function() {
                return YQ(c, g)
            });
            this.getVersion = N(a, 568, function() {
                return a.Df
            });
            this.forceExperiment = N(a, 569, function(k) {
                return void c.forceExperiment(k)
            });
            this.setCorrelator = N(a, 28, function(k) {
                pE(wp("set"));
                Q(b, UP());
                if (pi(window)) return f;
                if (!Kp(k)) return Q(b, wn("PubadsService.setCorrelator", [bp(k)])), f;
                k = g.setCorrelator(k);
                _.Dl(k, 27, !0);
                return f
            });
            this.markAsAmp = N(a, 570, function() {
                window.console && window.console.warn && window.console.warn("googletag.pubads().markAsAmp() is deprecated and ignored.")
            });
            this.isSRA = N(a, 571, function() {
                return !!_.R(g, 6)
            });
            this.setImaContent = N(a, 328, function(k, m) {
                _.yl(g, 22) ? WQ(c, k, m, g) : (_.Dl(g, 21, !0), VQ(c, g), typeof k === "string" && _.tj(g, 19, k), typeof m === "string" && _.tj(g, 20, m))
            });
            this.getImaContent = N(a, 329, function() {
                return _.yl(g, 22) ? YQ(c, g) : c.isEnabled() ? {
                    vid: _.t(g, 19) || "",
                    cmsid: _.t(g, 20) || ""
                } : null
            });
            this.isInitialLoadDisabled = N(a, 572, function() {
                return !!_.R(g, 4)
            });
            this.setPrivacySettings = N(a, 648, function(k) {
                if (!_.gb(k)) return Q(b, wn("PubAdsService.setPrivacySettings", [k])), f;
                var m = k.restrictDataProcessing,
                    n = k.childDirectedTreatment,
                    p = k.underAgeOfConsent,
                    r = k.limitedAds,
                    v = k.nonPersonalizedAds,
                    u = k.userOptedOutOfPersonalization,
                    x = k.trafficSource,
                    D = k.isSpecialCategoryData,
                    F, C = (F = by(g)) != null ? F : new CQ;
                typeof v === "boolean" ? _.Dl(C, 8, v) : v !== void 0 && Q(b, ap("PubAdsService.setPrivacySettings", bp(k), "nonPersonalizedAds", bp(v)));
                typeof u === "boolean" ? _.Dl(C, 13, u) : u !== void 0 && Q(b, ap("PubAdsService.setPrivacySettings", bp(k), "userOptedOutOfPersonalization", bp(u)));
                typeof m === "boolean" ? _.Dl(C, 1, m) : m !== void 0 && Q(b, ap("PubAdsService.setPrivacySettings", bp(k), "restrictDataProcessing", bp(m)));
                if (typeof r === "boolean") {
                    m = vp();
                    if (r && !_.R(C, 9) && (F = bn(a), F.ud)) {
                        v = a.va;
                        u = v.Fc;
                        F = an(a, F.kd);
                        var G = new RG;
                        G = _.$g(G, 1, !0);
                        G = _.$g(G, 2, m);
                        F = _.en(F, 11, fn, G);
                        u.call(v, F)
                    }
                    m ? _.Dl(C, 9, r) : r && Q(b, mQ())
                } else r !== void 0 && Q(b, ap("PubAdsService.setPrivacySettings", bp(k), "limitedAds", bp(r)));
                p !== void 0 && (p === null ? C.setTagForUnderAgeOfConsent(2) : p === !1 ? C.setTagForUnderAgeOfConsent(0) : p === !0 ? C.setTagForUnderAgeOfConsent(1) : Q(b, ap("PubAdsService.setPrivacySettings", bp(k), "underAgeOfConsent", bp(p))));
                n !== void 0 && (n === null ? C.clearTagForChildDirectedTreatment() : n === !1 ? C.setTagForChildDirectedTreatment(0) : n === !0 ? C.setTagForChildDirectedTreatment(1) : Q(b, ap("PubAdsService.setPrivacySettings", bp(k), "childDirectedTreatment", bp(n))));
                x !== void 0 && (x === null ? _.vj(C, 10) : (_.E = _.w(Object, "values").call(Object, Jo), _.w(_.E, "includes")).call(_.E, x) ? _.uj(C, 10, x) : Q(b, ap("PubAdsService.setPrivacySettings", bp(k), "trafficSource", bp(x))));
                D !== void 0 && (D === null ? _.vj(C, 14) : D === !0 ? _.Dl(C, 14, !0) : Q(b, ap("PubAdsService.setPrivacySettings", bp(k), "isSpecialCategoryData", bp(D))));
                _.Wg(g, 25, C);
                return f
            })
        };
    _.T(Dp, xQ);
    var ZQ = function(a, b) {
        this.getId = N(a, 593, function() {
            return b.getId()
        });
        this.getAdUnitPath = N(a, 594, function() {
            return b.getAdUnitPath()
        });
        this.getName = N(a, 595, function() {
            return b.getName()
        });
        this.toString = N(a, 596, function() {
            return b.toString()
        });
        this.getDomId = N(a, 597, function() {
            return b.getDomId()
        })
    };
    var $Q = function() {
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.creativeId = this.campaignId = this.advertiserId = null;
            this.isBackfill = !1;
            this.encryptedTroubleshootingInfo = this.creativeTemplateId = this.companyIds = this.yieldGroupIds = null
        },
        aR = function(a, b) {
            a.advertiserId = b
        },
        bR = function(a, b) {
            a.campaignId = b
        },
        cR = function(a, b) {
            a.yieldGroupIds = b
        },
        dR = function(a, b) {
            a.companyIds = b
        };
    var Wn = function(a) {
        this.D = _.A(a)
    };
    _.T(Wn, _.B);
    Wn.prototype.getWidth = function() {
        return Ov(this, 1)
    };
    Wn.prototype.getHeight = function() {
        return Ov(this, 2)
    };
    Wn.prototype.setHeight = function(a) {
        return _.vj(this, 2, _.ad(a))
    };
    var Np = function() {
        var a = new Wn;
        return _.Dl(a, 3, !0)
    };
    var $n = function(a) {
        this.D = _.A(a)
    };
    _.T($n, _.B);
    var dq = function(a) {
        this.D = _.A(a)
    };
    _.T(dq, _.B);
    var cq = function(a) {
        var b = new dq;
        return _.uj(b, 1, a)
    };
    dq.prototype.setEnabled = function(a) {
        return _.Dl(this, 2, a)
    };
    var aq = function(a) {
        this.D = _.A(a)
    };
    _.T(aq, _.B);
    var hq = function(a) {
        this.D = _.A(a)
    };
    _.T(hq, _.B);
    var eR = function(a) {
        this.D = _.A(a)
    };
    _.T(eR, _.B);
    eR.prototype.getAdUnitPath = function() {
        return _.t(this, 1)
    };
    eR.prototype.getDomId = function() {
        return _.t(this, 2)
    };
    var fR = function(a, b) {
        _.tj(a, 2, b)
    };
    eR.prototype.Ya = function() {
        return _.ul(this, Hn, 3, _.wl())
    };
    eR.prototype.getServices = function(a) {
        return CA(this, 4, a)
    };
    var gR = function(a, b) {
        _.Qn(a, 5, b)
    };
    eR.prototype.getClickUrl = function() {
        return _.t(this, 7)
    };
    eR.prototype.setClickUrl = function(a) {
        return _.tj(this, 7, a)
    };
    eR.prototype.getCategoryExclusions = function(a) {
        return CA(this, 8, a)
    };
    var En = function(a) {
        return _.ul(a, Hn, 9, _.wl())
    };
    eR.prototype.bd = function() {
        return _.Fi(this, Zo, 13)
    };
    var Wp = function(a) {
        return _.Sh(a, 15, 0)
    };
    var hR = function(a, b) {
        this.width = a;
        this.height = b
    };
    hR.prototype.getWidth = function() {
        return this.width
    };
    hR.prototype.getHeight = function() {
        return this.height
    };
    var bq = new _.z.Set(["unhideWindow", "navBar"]);
    var kq = {
        componentAuction: {
            Cb: function(a, b, c, d) {
                jq(a, d)
            },
            methodName: 1292
        },
        interstitial: {
            Cb: fq,
            methodName: 1293
        },
        adExpansion: {
            Cb: Vp,
            methodName: 1294
        },
        outstream: {
            Cb: iq,
            methodName: 1295
        }
    };
    var mq = function(a, b, c) {
        var d = this,
            e = MQ(qo(), c.getDomId()),
            f = "",
            g = null,
            h = function() {
                return ""
            },
            l = "",
            k = !1;
        _.$q(c, function() {
            e = new eR;
            f = "";
            g = null;
            h = function() {
                return ""
            };
            l = ""
        });
        c.listen(Pv, function(n) {
            var p = n.detail;
            n = p.Cj;
            p = p.isBackfill;
            n && (f = n, k = p)
        });
        this.set = N(a, 40, function(n, p) {
            Fp(n, p, c, e, b);
            return d
        });
        this.get = N(a, 41, function(n) {
            return Gp(n, c, e, b)
        });
        this.getAttributeKeys = N(a, 42, function() {
            return Hp(e)
        });
        this.addService = N(a, 43, function(n) {
            n = sn.get(n);
            if (!n) return Q(b, wn("Slot.addService", [n]), c), d;
            var p = n.getName();
            if ((_.E = _.Ou(e, 4, _.wl()), _.w(_.E, "includes")).call(_.E, p)) return b.info(oP(p, c.toString()), c), d;
            n.slotAdded(c, e);
            return d
        });
        this.defineSizeMapping = N(a, 44, function(n) {
            n = Rp(n);
            typeof n === "string" ? Q(b, wn("Slot.defineSizeMapping", [n]), c) : _.Qn(e, 6, n);
            return d
        });
        this.setClickUrl = N(a, 45, function(n) {
            Cn(n, e, c, b);
            return d
        });
        this.setCategoryExclusion = N(a, 46, function(n) {
            var p = e;
            typeof n !== "string" || Dn(n) ? Q(b, wn("Slot.setCategoryExclusion", [n]), c) : ((_.E = _.Ou(p, 8, _.wl()), _.w(_.E, "includes")).call(_.E, n) || _.df(p, 8, _.Bd, n, Dd), b.info(pP(n), c));
            return d
        });
        this.clearCategoryExclusions = N(a, 47, function() {
            _.vj(e, 8);
            b.info(qP(), c);
            return d
        });
        this.getCategoryExclusions = N(a, 48, function() {
            return _.Ou(e, 8, _.wl()).slice()
        });
        this.setTargeting = N(a, 49, function(n, p) {
            Jn(n, p, c, e, b);
            return d
        });
        this.updateTargetingFromMap = N(a, 649, function(n) {
            Kn(n, c, e, b);
            return d
        });
        this.clearTargeting = N(a, 50, function(n) {
            Sn(n, c, e, b);
            return d
        });
        this.getTargeting = N(a, 51, function(n) {
            return Mn(n, c, e, b)
        });
        this.getTargetingKeys = N(a, 52, function() {
            return Nn(e)
        });
        this.setCollapseEmptyDiv = N(a, 53, function(n, p) {
            var r = e;
            p = p === void 0 ? !1 : p;
            p = p === void 0 ? !1 : p;
            typeof n !== "boolean" || typeof p !== "boolean" ? Q(b, wn("Slot.setCollapseEmptyDiv", [n, p]), c) : (r = _.Dl(r, 10, n), _.Dl(r, 11, n && p), p && !n && Q(b, rP(c.toString()), c));
            return d
        });
        this.getAdUnitPath = N(a, 54, function() {
            return c.getAdUnitPath()
        });
        this.getSlotElementId = N(a, 598, function() {
            return c.getDomId()
        });
        this.setForceSafeFrame = N(a, 55, function(n) {
            var p = e;
            typeof n !== "boolean" ? Q(b, wn("Slot.setForceSafeFrame", [String(n)]), c) : _.Dl(p, 12, n);
            return d
        });
        this.setSafeFrameConfig = N(a, 56, function(n) {
            var p = e,
                r = cp(b, n);
            r ? _.Wg(p, 13, r) : b.error(wn("Slot.setSafeFrameConfig", [n]), c);
            return d
        });
        c.listen(QO, function(n) {
            n = n.detail;
            if (_.R(n, 8)) g = null;
            else {
                g = new $Q;
                var p = !!_.R(n, 9);
                g.isBackfill = p;
                var r = yA(n, 15, _.wl()),
                    v = yA(n, 16, _.wl());
                r.length && v.length && (g.sourceAgnosticCreativeId = r[0], g.sourceAgnosticLineItemId = v[0], p || (g.creativeId = r[0], g.lineItemId = v[0], (p = yA(n, 22, _.wl())) && p.length && (g.creativeTemplateId = p[0])));
                yA(n, 17, _.wl()).length && aR(g, yA(n, 17, _.wl())[0]);
                yA(n, 18, _.wl()).length && bR(g, yA(n, 18, _.wl())[0]);
                yA(n, 19, _.wl()).length && cR(g, yA(n, 19, _.wl(_.Yn)));
                yA(n, 20, _.wl()).length && dR(g, yA(n, 20, _.wl(_.Yn)));
                n = Ie(n, 45, Le, _.wl()).map(function(u) {
                    return ke(u)
                });
                n.length && (g.encryptedTroubleshootingInfo = n[0])
            }
        });
        this.getResponseInformation = N(a, 355, function() {
            return g
        });
        this.getName = N(a, 170, function() {
            b.error(kQ());
            return c.getAdUnitPath()
        });
        var m = new ZQ(a, c);
        this.getSlotId = N(a, 579, function() {
            return m
        });
        this.getServices = N(a, 580, function() {
            return _.Ou(e, 4, _.wl()).map(function(n) {
                var p = OQ[n];
                if (p) {
                    var r, v, u;
                    n = (u = (v = (r = Sp())[p]) == null ? void 0 : v.call(r)) != null ? u : null
                } else n = null;
                return n
            })
        });
        this.getSizes = N(a, 581, function(n, p) {
            var r, v;
            return (v = (r = ao(e, n, p)) == null ? void 0 : r.map(function(u) {
                return _.R(u, 3) ? "fluid" : new hR(u.getWidth(), u.getHeight())
            })) != null ? v : null
        });
        this.getClickUrl = N(a, 582, function() {
            var n;
            return (n = e.getClickUrl()) != null ? n : ""
        });
        this.getTargetingMap = N(a, 583, function() {
            for (var n = {}, p = _.y(En(e)), r = p.next(); !r.done; r = p.next()) r = r.value, _.t(r, 1) && (n[xl(r, 1)] = Ln(r, _.Yn));
            return n
        });
        this.getOutOfPage = N(a, 584, function(n) {
            return typeof n === "number" ? Wp(e) === n : Wp(e) !== 0
        });
        this.getCollapseEmptyDiv = N(a, 585, function() {
            var n = e;
            return dp(n, 10) ? _.R(n, 10) : null
        });
        this.getDivStartsCollapsed = N(a, 586, function() {
            var n = e;
            return dp(n, 11) ? _.R(n, 11) : null
        });
        c.listen(RO, function(n) {
            h = n.detail.Km
        });
        this.getContentUrl = N(a, 587, function() {
            return h()
        });
        this.getFirstLook = N(a, 588, function() {
            pE("The getFirstLook method of SlotInterface is deprecated. Please update your code to no longer call this method.");
            return 0
        });
        c.listen(QO, function(n) {
            var p;
            l = (p = n.detail.getEscapedQemQueryId()) != null ? p : ""
        });
        this.getEscapedQemQueryId = N(a, 591, function() {
            return l
        });
        this.getHtml = N(a, 592, function() {
            return k ? (window.console && console.warn && console.warn("This ad's html cannot be accessed using the getHtml method on googletag.Slot. Returning the empty string instead."), "") : f
        });
        this.setConfig = N(a, 1022, function(n) {
            if (_.I(TJ)) lq(a, e, b, c, n);
            else {
                var p = e;
                if (pc(n)) {
                    var r = n.componentAuction,
                        v = n.adExpansion,
                        u = n.outstream;
                    r != null && (r = {
                        componentAuction: r
                    }, _.gb(r) ? jq(p, r.componentAuction) : Q(b, wn("googletag.Slot.setConfig", [r])));
                    _.w(Object, "hasOwn").call(Object, n, "interstitial") && fq(p, b, c, n.interstitial);
                    _.w(Object, "hasOwn").call(Object, n, "adExpansion") && Vp(p, b, c, v);
                    _.I(gq) && _.w(Object, "hasOwn").call(Object, n, "outstream") && iq(p, b, c, u)
                } else Q(b, wn("googletag.slot.setConfig", [n]), c)
            }
        })
    };
    var iR = {},
        xq = (iR[64] = dQ, iR[134217728] = eQ, iR[32768] = fQ, iR[536870912] = gQ, iR[8] = hQ, iR[512] = iQ, iR[1048576] = jQ, iR[4194304] = lQ, iR);
    var jR = function(a) {
        return ln(a.getAdUnitPath()) === "22639388115"
    };
    var kR = Sj(1199, function(a, b) {
        if (a = a.Ba) b = MQ(b, a.getSlotElementId()), _.Dl(b, 30, !0);
        return {}
    }, {});
    var lR = Sj(1109, function(a, b, c, d, e, f, g) {
        var h = a.Ba;
        h && (g.push(function() {
            h.addService(d)
        }), uE(b, function() {
            f();
            e(h);
            _.R(c, 4) && d.refresh([h], _.I(cJ) ? {
                changeCorrelator: !1
            } : void 0)
        }));
        return {}
    }, {});
    var Du = Sj(1255, function(a) {
        a = a.jb;
        var b;
        if (((b = a == null ? void 0 : wA(a).length) != null ? b : 0) > 0)
            for (b = _.y(ej(XJ)), a = b.next(); !a.done; a = b.next()) Ti(Number(a.value));
        return {}
    }, {});
    var mR = Pj(1249, function(a, b, c, d) {
        return _.ug(function(e) {
            if (a.ul && a.jb && a.fg) {
                var f = e.return,
                    g = a.ul,
                    h = g.fm;
                var l = new BC;
                l = _.Wg(l, 1, a.jb);
                e = f.call(e, h.call(g, l, a.fe, c, d, b, a.fg))
            } else e = e.return();
            return e
        })
    });
    var nR = function(a) {
        this.module = a
    };
    nR.prototype.toString = function() {
        return String(this.module)
    };
    _.oR = new nR(2);
    _.pR = new nR(5);
    _.qR = new nR(6);
    var rR = Pj(1095, function(a, b) {
        return _.ug(function(c) {
            return a.jb && wA(a.jb).length > 0 && a.fg ? c.return(b.load(_.pR)) : c.return(null)
        })
    });
    var Eu = function(a, b, c, d, e, f, g) {
        L.call(this, d.S, 38);
        e = this.l(rR, {
            jb: a,
            fg: c
        }, e);
        this.l(mR, {
            fe: b,
            jb: a,
            fg: c,
            ul: e.output
        }, d.va, f, g)
    };
    _.T(Eu, L);
    var sR = function(a, b, c, d, e, f) {
        this.jc = a;
        f ? this.slotId = f : (b = e.add(c, d, b, [1, 1], {
            Qb: void 0,
            format: 6,
            Kb: !0
        }), a = b.slotId, b = b.settings, a && b ? (_.uj(b, 15, 6), this.slotId = a) : this.slotId = null)
    };
    var Cu = Sj(1252, function(a, b, c, d, e, f) {
        var g = a.adUnitPath;
        a = a.Ec;
        return !g && !f || a ? {
            output: null
        } : {
            output: new sR(b, g != null ? g : null, c, d, e, f)
        }
    }, {
        output: void 0
    });
    var Uq = Sj(1246, function(a) {
        if (!a.data) return {
            jb: null
        };
        var b;
        return {
            jb: (b = _.Fi(JC(a.data), _.zC, 2)) != null ? b : null
        }
    }, {
        jb: void 0
    }, function() {
        return {
            jb: null
        }
    });
    var Tq = Pj(1245, function(a, b, c) {
        var d, e;
        return _.ug(function(f) {
            if (f.g == 1) {
                if (!a.adUnitPath && !c) return f.return(null);
                d = new URL("https://securepubads.g.doubleclick.net/pagead/purl_config");
                d.searchParams.set("url", b.location.href);
                d.searchParams.set("puc_types", "1");
                return f.yield(b.fetch(d, {
                    credentials: "omit"
                }), 2)
            }
            e = f.o;
            return e.ok ? f.return(e.text()) : f.return(null)
        })
    });
    var ar = function(a, b, c, d, e, f) {
        var g = f.Tb;
        var h = f.kh;
        var l = f.fe;
        var k = f.jc;
        L.call(this, a.S, 42);
        f = Vq(a, d, null, e, this);
        b = this.g(Cu, {}, k, a, b, c, e).output;
        this.g(Du, {
            jb: f
        });
        a = new Eu(f, l, b, a, g, d, h);
        Fu(this, a)
    };
    _.T(ar, L);
    var tR = Sj(1108, function(a, b, c, d, e, f, g, h) {
        a = Yq(b, g, f, h, {
            Lj: d,
            adUnitPath: c,
            Kb: e
        });
        return {
            Gi: a,
            slot: a ? a.Ba : null
        }
    }, {
        Gi: void 0,
        slot: void 0
    });
    var uR = Sj(1111, function(a, b, c) {
        if (a = a.Ba) b = MQ(b, a.getSlotElementId()), Fl(b, 27, xC, c);
        return {}
    }, {});
    var vR = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u) {
        L.call(this, a.S, 25);
        this.context = a;
        this.ga = b;
        this.adUnitPath = c;
        this.format = d;
        this.Kb = e;
        this.jc = f;
        this.ka = g;
        this.oa = h;
        this.ia = l;
        this.Z = k;
        this.A = m;
        this.ca = n;
        this.V = p;
        this.pa = r;
        this.U = v;
        this.da = u;
        b = this.g(tR, {}, this.context, this.adUnitPath, this.format, this.Kb, this.ca, this.V, this.U);
        a = b.Gi;
        b = b.slot;
        this.da && this.g(uR, {
            Ba: b
        }, this.A, this.da);
        this.pa && this.g(kR, {
            Ba: b
        }, this.A);
        this.g(lR, {
            Ba: b
        }, this.ga, this.Z, this.jc, this.ka, this.oa, this.ia);
        this.j = {
            Gi: a
        }
    };
    _.T(vR, L);
    var Z = function(a, b, c) {
        TM.call(this, b, c);
        this.context = a
    };
    _.T(Z, TM);
    Z.prototype.reportError = function(a) {
        qn(this.context, this.id, a);
        var b, c;
        (b = window.console) == null || (c = b.error) == null || c.call(b, a)
    };
    var wR = [{
            name: "Interstitial",
            format: 1,
            He: 5
        }, {
            name: "TopAnchor",
            format: 2,
            He: 2
        }, {
            name: "BottomAnchor",
            format: 3,
            He: 3
        }, {
            name: "LeftSideRail",
            format: 4,
            He: 8
        }, {
            name: "RightSideRail",
            format: 5,
            He: 9
        }],
        sw = function(a, b, c, d, e, f, g, h) {
            Z.call(this, a, 789);
            this.ga = b;
            this.googletag = c;
            this.C = d;
            this.j = e;
            this.V = f;
            this.G = g;
            this.A = h
        };
    _.T(sw, Z);
    sw.prototype.g = function() {
        var a = this;
        wR.filter(function(b) {
            return (new RegExp("gam" + b.name + "Demo", "i")).test(a.G)
        }).forEach(function(b) {
            var c = b.name;
            b = b.He;
            var d, e;
            (d = window.console) == null || (e = d.warn) == null || e.call(d, "GPT - Demo " + c + " ENABLED");
            c = new vR(a.context, a.ga, "/22639388115/example/" + c.toLowerCase(), b, !1, a.googletag.pubads(), function(f) {
                return void a.googletag.display(f)
            }, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, a.googletag.cmd, a.j.g, a.j, a.C, a.V, !1, a.A);
            _.Sq(a, c);
            c.run()
        })
    };
    var xR = new _.z.Map([
            [1, 5],
            [2, 2],
            [3, 3]
        ]),
        yR = function(a, b, c, d, e, f, g, h, l, k) {
            Z.call(this, a, 1079);
            this.ga = b;
            this.googletag = c;
            this.Z = d;
            this.I = e;
            this.j = f;
            this.V = g;
            this.A = h;
            this.C = l;
            this.G = k
        };
    _.T(yR, Z);
    yR.prototype.g = function() {
        var a = this,
            b = this.A.getAdUnitPath(),
            c = xR.get(_.Sh(this.A, 2, 0));
        if (b && c) {
            var d, e = (d = this.Z) != null ? d : this.j.g;
            b = new vR(this.context, this.ga, b, c, !0, this.googletag.pubads(), this.googletag.display, function() {
                a.googletag.pubadsReady || a.googletag.enableServices()
            }, this.googletag.cmd, e, this.j, this.I, this.V, !1, this.G, this.C);
            _.Sq(this, b);
            b.run()
        }
    };
    var yw = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1082);
        this.googletag = b;
        this.Z = c;
        this.C = d;
        this.j = e;
        this.V = f;
        this.A = h;
        this.G = Y(this, g)
    };
    _.T(yw, Z);
    yw.prototype.g = function() {
        if (_.I(MJ)) {
            var a = new L(this.context.S, 60);
            _.Sq(this, a);
            for (var b = _.y(this.G.value.filter(function(e) {
                    return _.Im(e, DC) === 5
                })), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = void 0;
                M(a, new yR(this.context, document, this.googletag, (d = this.Z) != null ? d : this.j.g, this.C, this.j, this.V, _.Fi(c, yC, _.Lm(c, DC, 5)), _.Fi(c, xC, 4), this.A))
            }
            a.run()
        }
    };
    var zR = function(a, b, c, d, e, f, g) {
        L.call(this, a.S);
        var h, l = new sw(a, document, b, d, e, c, (h = window.location.hash) != null ? h : "", g);
        M(this, l);
        f && (a = new yw(a, b, null, d, e, c, f, g), M(this, a))
    };
    _.T(zR, L);
    var AR = function(a) {
        this.D = _.A(a)
    };
    _.T(AR, _.B);
    var BR = function(a) {
        this.D = _.A(a)
    };
    _.T(BR, _.B);
    var br = function(a) {
            return function(b) {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("Expected jspb data to be an array, got " + Pc(b) + ": " + b);
                Sb(b);
                return new a(b)
            }
        }(BR),
        cr = function(a) {
            return function() {
                return Fd(a)
            }
        }(BR);
    var CR = Sj(959, function(a, b) {
        var c = a.Qn,
            d = a.Cp,
            e = a.Xp;
        a = a.Gn;
        var f = _.I(gr) ? dp(a, 5) ? vi(a) : dp(d, 5) ? vi(d) : vi(c) : dp(d, 5) ? vi(d) : vi(c),
            g = new pN,
            h;
        if (h = f) h = dp(d, 5) ? !1 : vp(), h = !(b ? _.R(b, 9) : h);
        b = _.Dl(g, 5, h);
        b = _.Dl(b, 15, f);
        f = _.I(gr) ? dp(a, 8) ? _.R(a, 8) : dp(d, 8) ? _.R(d, 8) : void 0 : Yr(d, 8);
        b = ir(b, f);
        c = Yr(c, 14);
        c = _.Dl(b, 14, c);
        b = Yr(d, 3);
        c = _.Dl(c, 3, b);
        b = _.IA(d, 2);
        c = _.tj(c, 2, b);
        b = _.IA(d, 4);
        c = _.tj(c, 4, b);
        b = JA(d, 7);
        c = _.uj(c, 7, b);
        d = Yr(d, 9);
        d = _.Dl(c, 9, d);
        c = _.IA(e, 1);
        d = _.tj(d, 1, c);
        return {
            ba: jr(fr(er(qN(d, Yr(e, 13)), _.IA(a, 11)), yA(a, 10, _.wl())), Yr(a, 12))
        }
    }, {
        ba: void 0
    });
    var DR = Pj(1172, function(a, b, c, d, e, f, g) {
        var h, l, k;
        return _.ug(function(m) {
            h = new BL(e, {
                cmpInteractionEventReporter: new FL(b.va)
            });
            _.Sq(g, h);
            l = new pN;
            if (!PK(h.caller)) return m.return(l);
            k = new _.z.Promise(function(n) {
                var p = d.J,
                    r = p.getStatus(),
                    v = function(u) {
                        u.internalErrorState ? er(l, u.gppString) : Li(u.applicableSections) ? (jr(fr(l, u.applicableSections.filter(function(x) {
                            return _.w(Number, "isInteger").call(Number, x)
                        })), !1), _.I(gr) && _.Dl(l, 5, !0)) : lr(b, f, l, u);
                        n(l)
                    };
                switch (r) {
                    case 2:
                        v(p.data);
                        break;
                    case 1:
                        p.g.push(v);
                        break;
                    case 0:
                        WO(p);
                        p.g.push(v);
                        c.info(ZP());
                        h.addEventListener(on(b, 1173, function(u) {
                            if (u.pingData.signalStatus === "ready" || Li(u.pingData.applicableSections)) p.data = u.pingData, p.status = 2, p.g.forEach(function(x) {
                                x(u.pingData)
                            }), p.g = []
                        }));
                        break;
                    default:
                        throw Error("Impossible CacheStatus: " + r);
                }
            });
            return m.return(k)
        })
    });
    var ER = Pj(874, function(a, b, c, d, e) {
        var f;
        return _.ug(function(g) {
            f = new _.z.Promise(function(h) {
                var l = new XK(d, {
                        timeoutMs: -1,
                        qm: !0
                    }),
                    k = new pN;
                if (typeof l.l.__tcfapi === "function" || cL(l) != null) {
                    var m = c.C,
                        n = m.getStatus(),
                        p = function(r) {
                            var v;
                            var u = aL(r, {
                                idpcApplies: e
                            });
                            u = _.Dl(k, 5, u);
                            var x = !eL(r, ["3", "4"], 0);
                            u = _.Dl(u, 9, x);
                            u = _.tj(u, 2, r.tcString);
                            x = (v = r.addtlConsent) != null ? v : "";
                            v = _.tj(u, 4, x);
                            _.uj(v, 7, r.internalErrorState);
                            r.gdprApplies != null && _.Dl(k, 3, r.gdprApplies);
                            !eL(r, ["2", "7", "9", "10"], 3) && ir(k, !0);
                            h(k)
                        };
                    switch (n) {
                        case 2:
                            p(m.data);
                            break;
                        case 1:
                            m.g.push(p);
                            break;
                        case 0:
                            WO(m);
                            m.g.push(p);
                            b.info(YP());
                            l.addEventListener(function(r) {
                                ZK(r) ? (nr(b, r), m.data = r, m.status = 2, m.g.forEach(function(v) {
                                    v(r)
                                }), m.g = []) : WO(m)
                            });
                            break;
                        default:
                            throw Error("Impossible CacheStatus: " + n);
                    }
                } else h(k)
            });
            return g.return(f)
        })
    });
    var FR = Pj(875, function(a, b, c, d, e) {
        var f, g;
        return _.ug(function(h) {
            f = new tL(c);
            _.Sq(e, f);
            g = new pN;
            return PK(f.caller) ? h.return(new _.z.Promise(function(l) {
                var k = on(b, 660, function(m) {
                    m && _.w(Object, "keys").call(Object, m).length === 0 && Q(d, XP());
                    m && typeof m.uspString === "string" && qN(_.tj(g, 1, m.uspString), on(b, 1187, function() {
                        var n = m.uspString;
                        var p = n = n.toUpperCase();
                        p.length == 4 && (p.indexOf("-") == -1 || p.substring(1) === "---") && p[0] >= "1" && p[0] <= "9" && eF.hasOwnProperty(p[1]) && eF.hasOwnProperty(p[2]) && eF.hasOwnProperty(p[3]) ? (p = new dF, p = _.Pg(p, 1, parseInt(n[0], 10)), p = _.H(p, 2, eF[n[1]]), p = _.H(p, 3, eF[n[2]]), n = _.H(p, 4, eF[n[3]])) : n = null;
                        return (n == null ? void 0 : _.Sh(n, 3, 0)) === 2
                    })());
                    l(g)
                });
                d.info(WP());
                uL(f, k)
            })) : h.return(g)
        })
    });
    var GR = Sj(958, function(a, b, c) {
        a = new pN;
        c = _.Dl(a, 5, !c);
        a = _.Vn(263);
        var d = !!navigator.globalPrivacyControl;
        a && d && _.Dl(c, 14, !0);
        d ? b.va.La.Ma.hb.yj.globalPrivacyControl.ta({
            wa: 1,
            rk: a,
            sk: d
        }) : b.Zb < .001 && b.va.La.Ma.hb.yj.globalPrivacyControl.ta({
            wa: 1E3,
            rk: a,
            sk: d
        });
        return {
            ba: c
        }
    }, {
        ba: void 0
    });
    var Gw = function(a, b, c, d, e, f, g) {
        L.call(this, a.S, 6);
        var h = f && !oi();
        f = this.g(GR, {}, a, h).ba;
        var l = At(this.l(FR, {}, a, d, b, this), e).output,
            k = At(this.l(ER, {}, b, c, d, h), e).output;
        a = At(this.l(DR, {}, a, b, c, d, h, this), e).output;
        this.Rc = this.g(CR, {
            Qn: f,
            Cp: k,
            Xp: l,
            Gn: a
        }, g).ba
    };
    _.T(Gw, L);
    var HR = Sj(1103, function(a, b, c, d) {
        if (a = !!vi(c) && !_.R(c, 9) && !_.R(c, 13) && !_.R(c, 12) && !_.R(c, 14)) a = b ? _.R(b, 9) || _.R(b, 8) || _.R(b, 1) || _.Sh(b, 6, 2) === 1 || JA(b, 5) === 1 || _.w(d, "includes").call(d, 1) ? !1 : !0 : !0;
        return {
            output: a
        }
    }, {
        output: void 0
    });
    var qr = function(a) {
        this.V = a;
        this.o = this.g = 0
    };
    qr.prototype.push = function() {
        for (var a = _.y(_.Ia.apply(0, arguments)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                typeof b === "function" && (b.call(_.z.globalThis), this.g++)
            } catch (c) {
                this.o++, b = void 0, (b = window.console) == null || b.error("Exception in queued GPT command", c), this.V.error(wP(String(c)))
            }
        }
        this.V.info(xP(String(this.g), String(this.o)));
        return this.g
    };
    var or = function(a, b) {
        this.push = N(a, 76, b.push.bind(b))
    };
    var IR = ["Debug", "Info", "Warning", "Error", "Fatal"],
        JR = function(a, b, c) {
            this.level = a;
            this.message = b;
            this.Ba = c;
            this.timestamp = new Date
        };
    _.q = JR.prototype;
    _.q.getSlot = function() {
        return this.Ba
    };
    _.q.getLevel = function() {
        return this.level
    };
    _.q.getTimestamp = function() {
        return this.timestamp
    };
    _.q.getMessage = function() {
        return this.message
    };
    _.q.toString = function() {
        return this.timestamp.toTimeString() + ": " + IR[this.level] + ": " + this.message
    };
    var KR = Ny(["https://console.googletagservices.com/pubconsole/loader.js"]),
        Dr = Ny(["https://console.googletagservices.com/pubconsole/loader.js#exp=", ""]),
        Er = _.ng(KR),
        Ir, Hr = !1,
        vr = !1,
        Ar = !1;
    var fw = function(a, b) {
        this.getAllEvents = N(a, 563, function() {
            return vr ? LR(b).slice() : []
        });
        this.getEventsBySlot = N(a, 565, function(c) {
            return vr ? MR(b, c).slice() : []
        });
        this.getEventsByLevel = N(a, 566, function(c) {
            return vr ? NR(b, c).slice() : []
        })
    };
    var Kr = function() {
        this.Uc = 1E3
    };
    Kr.prototype.send = function(a, b) {
        a.ml(b)
    };
    var Pr = function() {
        this.Uc = 10
    };
    Pr.prototype.send = function(a, b) {
        a.ql(b)
    };
    var Nr = function() {
        this.Uc = _.K(sK);
        this.kb = 17
    };
    Nr.prototype.send = function(a, b) {
        _.Gk(_.Hk(b, _.Ik, 2), this.kb);
        a.tl(b)
    };
    var Or = function() {};
    Or.prototype.send = function(a, b) {
        a.rl(b)
    };
    _.Hy.Object.defineProperties(Or.prototype, {
        Uc: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return _.K(FJ)
            }
        }
    });
    var Qr = function() {};
    Qr.prototype.send = function(a, b) {
        a.pl(b)
    };
    _.Hy.Object.defineProperties(Qr.prototype, {
        Uc: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return _.K(TI)
            }
        }
    });
    var Rr = function() {};
    Rr.prototype.send = function(a, b) {
        a.kl(b)
    };
    _.Hy.Object.defineProperties(Rr.prototype, {
        Uc: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return _.K(TI)
            }
        }
    });
    var OR = {
            20: function(a) {
                return "Ignoring a call to setCollapseEmptyDiv(false, true). Slots that start out collapsed should also collapse when empty. Slot: " + a[0] + "."
            },
            23: function(a) {
                return 'Error in googletag.display: could not find div with id "' + a[1] + '" in DOM for slot: ' + a[0] + "."
            },
            34: function(a) {
                return "Size mapping is null because invalid mappings were added: " + a[0] + "."
            },
            60: function(a) {
                return "Ignoring the " + a[0] + "(" + (a[1] || "") + ") call since the service is already enabled."
            },
            66: function(a) {
                return "Slot " + a[0] + " cannot be refreshed until PubAdsService is enabled."
            },
            68: function() {
                return "Slots cannot be cleared until service is enabled."
            },
            80: function(a) {
                return "Slot object at position " + a[0] + " is of incorrect type."
            },
            93: function(a) {
                return "Failed to register listener. Unknown event type: " + a[0] + "."
            },
            96: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + ")."
            },
            122: function(a) {
                return "Invalid argument: " + a[0] + "(" + a[1] + "). Valid values: " + a[2] + "."
            },
            121: function(a) {
                return "Invalid object passed to " + a[0] + "(" + a[1] + "), for " + a[2] + ": " + a[3] + "."
            },
            151: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + "). All zero-area slot sizes were removed."
            },
            105: function(a) {
                return "SRA requests may include a maximum of 30 ad slots. " + a[1] + " were requested, so the last " + a[2] + " were ignored."
            },
            106: function(a) {
                return "Publisher betas " + a[0] + " were declared after enableServices() was called."
            },
            107: function(a) {
                return "Publisher betas may only be declared once. " + a[0] + " were added after betas had already been declared."
            },
            108: function(a) {
                return "Beta keys cannot be cleared. clearTargeting() was called on " + a[0] + "."
            },
            123: function(a) {
                return "Refresh was throttled " + a[1] + " time(s) for slot: " + a[0]
            },
            113: function(a) {
                return a[0] + " ad slot ineligible as page is not mobile optimized: " + a[1] + "."
            },
            114: function() {
                return 'setCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            115: function() {
                return 'updateCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            132: function(a) {
                return "Taxonomy with id " + a[0] + " has reached the limit of " + a[1] + " values."
            },
            133: function() {
                return "No taxonomy values were cleared, either due to an invalid taxonomy or no values present."
            },
            134: function(a) {
                return Tr(a[0]) + " " + a[1] + " not requested: Format already created on the page."
            },
            135: function(a) {
                return Tr(a[0]) + " " + a[1] + " not requested: Frequency cap of 1 has been exceeded."
            },
            136: function(a) {
                return Tr(a[0]) + " " + a[1] + " not requested: The viewport exceeds the current maximum width of 2500px."
            },
            137: function(a) {
                return Tr(a[0]) + " " + a[1] + " not requested: Format currently only supported on mobile."
            },
            138: function(a) {
                return Tr(a[0]) + " " + a[1] + " not requested: Format currently only supports portrait orientation."
            },
            139: function(a) {
                return Tr(a[0]) + " " + a[1] + " not requested: GPT is not running in the top-level window."
            },
            140: function(a) {
                return Tr(a[0]) + " " + a[1] + " not requested: Detected browser is currently unsupported."
            },
            145: function(a) {
                return Tr(a[0]) + " " + a[1] + " not requested: Unable to access local storage to determine if the frequency cap has been exceeded due to insufficient user consent."
            },
            143: function() {
                return "getName on googletag.Slot is deprecated and will be removed. Use getAdUnitPath instead."
            },
            147: function() {
                return "GPT must be loaded from the limited ads URL to configure limited ads functionality via the PrivacySettings API."
            },
            167: function() {
                return "An IAB US Privacy Consent Management Provider was detected, but was unresponsive. Please review USP integration to ensure an optimal setup."
            },
            150: function() {
                return "Legacy browser does not support intersection observer causing lazy render/fetch as well as viewability events not to work properly."
            },
            164: function() {
                return "Lazy loading is not supported for Side Rail formats. Invocation will have no effect."
            },
            154: function(a) {
                return "Refresh is disabled for " + Tr(a[0]) + " " + a[1] + "."
            },
            152: function() {
                return "Attempted to load GPT multiple times."
            },
            158: function(a) {
                return "Unrecognized property encountered when calling setConfig: " + a[0] + "." + a[1]
            },
            159: function(a) {
                return "Invalid value encountered when calling setConfig: " + a[0] + "." + a[1] + ": " + a[2]
            },
            160: function(a) {
                return "slot.setConfig key " + a[0] + " is not valid for this slot."
            },
            168: function(a) {
                return "setConfig key " + a[0] + " is deprecated and " + a[1] + " should be used instead."
            },
            162: function(a) {
                return "GPT script src version " + a[0] + " is deprecated and will soon expire and fail to show ads. https://developers.google.com/publisher-tag/release-notes#2023-06-19"
            },
            165: function() {
                return "Rendering delayed due to slot element not being attached to the DOM.  It is recommended that the slot element or its ancestor be appended to the document prior to calling display."
            },
            166: function() {
                return "Creative content has successfully rendered after being delayed due to slot element not being attached to the DOM."
            },
            169: function(a) {
                return "Slot " + a[0] + " rendered inside of the viewport."
            }
        },
        PR = {
            26: function(a) {
                return "Div ID passed to googletag.display() does not match any defined slots: " + a[0] + "."
            },
            28: function(a) {
                return "Error in googletag.defineSlot: Cannot create slot " + a[1] + '. Div element "' + a[0] + '" is already associated with another slot: ' + a[2] + "."
            },
            149: function(a) {
                return "Error in googletag.defineSlot: Invalid ad unit path provided " + a[0] + ", see https://support.google.com/admanager/answer/10477476 for more information."
            },
            92: function(a) {
                return "Exception in " + a[1] + ' event listener: "' + a[0] + '".'
            },
            30: function(a) {
                return "Exception in googletag.cmd function: " + a[0] + "."
            },
            126: function() {
                return "Attempted to collect prebid data but window.pbjs is undefined."
            },
            153: function() {
                return "Attempted to load GPT from both standard and limited ads domains."
            },
            127: function(a) {
                return "Encountered the following error while attempting to collect prebid metadata: " + a[0] + "."
            },
            144: function() {
                return "ContentService is no longer available. Use the browser's built-in DOM APIs to directly add content to div elements instead."
            },
            161: function(a) {
                return "403 HTTP Response: " + a[0] + "."
            }
        };
    var QR = function(a) {
            this.context = a;
            this.o = this.g = 0;
            this.l = window;
            this.events = [];
            this.events.length = 1E3
        },
        LR = function(a) {
            return [].concat(_.Zk(a.events.slice(a.g)), _.Zk(a.events.slice(0, a.g))).filter(function(b) {
                return !!b
            })
        },
        MR = function(a, b) {
            return LR(a).filter(function(c) {
                return c.getSlot() === b
            })
        },
        NR = function(a, b) {
            return LR(a).filter(function(c) {
                return c.getLevel() >= b
            })
        };
    QR.prototype.log = function(a, b, c) {
        c = c === void 0 ? null : c;
        var d, e, f = new JR(a, b, (e = (d = c) == null ? void 0 : d.Ba) != null ? e : null);
        this.events[this.g] = f;
        this.g = (this.g + 1) % 1E3;
        var g = a === 2 || a === 3,
            h = b.getMessageArgs();
        e = b.getMessageId();
        var l = OR[e] || PR[e];
        d = void 0;
        if (l && (d = l(h), g = this.o < _.K(kJ) && g && _.ca.console, this.l === this.l.top && g || _.w(_.ca.navigator.userAgent, "includes").call(_.ca.navigator.userAgent, "Lighthouse"))) {
            e = "[GPT] " + d + "\nhttps://goo.gle/gpt-message#" + e;
            var k, m, n, p;
            a === 2 ? (m = (k = _.ca.console).warn) == null || m.call(k, e) : (p = (n = _.ca.console).error) == null || p.call(n, e);
            this.o++
        }
        a: {
            switch (a) {
                case 2:
                    a = 1;
                    break;
                case 3:
                    a = 2;
                    break;
                default:
                    break a
            }
            this.context.O.log(633226268, Wr, _.w(Object, "assign").call(Object, {}, this.context, {
                jo: a,
                mo: d,
                message: b,
                slotId: c === void 0 ? null : c
            }))
        }
        return f
    };
    QR.prototype.info = function(a, b) {
        return this.log(1, a, b === void 0 ? null : b)
    };
    var Q = function(a, b, c) {
        a.log(2, b, c)
    };
    QR.prototype.error = function(a, b) {
        return this.log(3, a, b)
    };
    var RR = function() {
            var a = {
                    Z: qo().g,
                    Bl: new Date(Date.now()),
                    Fj: window.location.href
                },
                b = this;
            a = a === void 0 ? {} : a;
            var c = a.Z === void 0 ? qo().g : a.Z;
            var d = a.Bl === void 0 ? new Date(Date.now()) : a.Bl;
            var e = a.Fj === void 0 ? window.location.href : a.Fj;
            this.g = "";
            this.j = this.o = null;
            this.F = this.J = this.A = !1;
            this.l = function() {
                return !1
            };
            a = {};
            var f = {},
                g = {};
            this.C = (g[3] = (a[72] = function(h, l) {
                var k = b.o;
                h = Number(h);
                l = Number(l);
                k = k !== null ? _.aj("w5uHecUBa2S:" + h + ":" + k) % l === Math.floor(d.valueOf() / 864E5) % l : void 0;
                return k
            }, a[13] = function() {
                return _.Ia.apply(0, arguments).some(function(h) {
                    return _.w(b.g, "startsWith").call(b.g, h)
                })
            }, a[12] = function() {
                return !!_.R(c, 6)
            }, a[15] = function(h) {
                return b.l(h)
            }, a[67] = function() {
                return b.A
            }, a[68] = function() {
                return b.J
            }, a[83] = function() {
                return b.F
            }, a[74] = function() {
                return _.w(_.Ia.apply(0, arguments), "includes").call(_.Ia.apply(0, arguments), String(_.aj(e)))
            }, a), g[4] = (f[14] = function() {
                var h = Number(b.j || void 0);
                isNaN(h) ? h = void 0 : (h = new Date(h * 1E3), h = h.getFullYear() * 1E4 + (h.getMonth() + 1) * 100 + h.getDate());
                return h
            }, f), g[5] = {}, g)
        },
        SR = function(a, b) {
            if (b && !a.o) {
                b = b.split(":");
                a.o = _.w(b, "find").call(b, function(d) {
                    return d.indexOf("ID=") === 0
                }) || null;
                var c;
                a.j = ((c = _.w(b, "find").call(b, function(d) {
                    return d.indexOf("T=") === 0
                })) == null ? void 0 : c.substring(2)) || null
            }
        };
    var Rx = Sj(1297, function(a, b, c, d, e) {
        if (b !== b.top) return {};
        a = d.Z;
        d = d.W[c.getDomId()];
        b: {
            var f = _.y(_.ul(d, Wn, 5, _.wl()));
            for (var g = f.next(); !g.done; g = f.next())
                if (g = g.value, g.getWidth() >= 50 && g.getHeight() >= 50) {
                    f = !0;
                    break b
                }
            f = !1
        }
        f ? (a = Bo(c, d, b.document, Zr(a, d)), b = !a || a.y < bo(!0, b).height ? !1 : av(a, b) === 0) : b = !1;
        b && Q(e, wQ(c.getDomId()), c);
        return {}
    }, {});
    var Px = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 863);
        this.Xd = b;
        this.A = c;
        this.j = Y(this, d);
        this.G = Y(this, e);
        this.I = Y(this, f);
        this.C = Y(this, g)
    };
    _.T(Px, Z);
    Px.prototype.g = function() {
        var a = this.I.value,
            b = this.j.value,
            c = this.C.value,
            d = this.G.value,
            e = this.A,
            f = Number(this.Xd);
        var g = $r(e);
        var h = b.getBoundingClientRect();
        e = _.um(e) ? ho(b, e) : {
            x: 0,
            y: 0
        };
        b = e.x;
        e = e.y;
        b = new _.yE(e, b + h.right, e + h.bottom, b);
        var l = b.top;
        e = b.bottom;
        h = b.left;
        b = b.right;
        var k = new eM;
        f = _.vj(k, 1, _.ad(f));
        d = _.Dl(f, 2, !d);
        f = new dM;
        f = _.Dq(f, 1, l);
        f = _.Dq(f, 3, e);
        f = _.Dq(f, 2, h);
        f = _.Dq(f, 4, b);
        f = _.we(f);
        d = _.Wg(d, 3, f);
        c = _.Dq(d, 4, c);
        g = _.Dq(c, 5, g);
        g = _.we(g);
        g = {
            type: "asmres",
            payload: Fm(g)
        };
        a.ports[0].postMessage(g)
    };
    var TR = function(a, b, c, d) {
        Z.call(this, a, 1061);
        var e = this;
        this.output = X(this);
        this.output.pb(new _.z.Promise(function(f) {
            var g = b.listen(c, function(h) {
                h = d(h);
                h !== null && (g(), f(h))
            });
            _.$q(e, g)
        }))
    };
    _.T(TR, Z);
    TR.prototype.g = function() {};
    var Bx = function(a, b, c, d) {
        TR.call(this, a, b, Ft, function(e) {
            e = e.detail;
            var f;
            return ((f = e.data) == null ? void 0 : f.type) === "asmreq" && Ov(cM(e.data.payload), 1) === Number(c) ? e : null
        });
        this.A = d;
        this.j = X(this)
    };
    _.T(Bx, TR);
    Bx.prototype.g = function() {
        this.j.H($r(this.A))
    };
    var UR = /(<head(\s+[^>]*)?>)/i,
        bx = function(a, b, c, d, e) {
            Z.call(this, a, 665);
            this.ya = b;
            this.Yd = c;
            this.isBackfill = d;
            this.Xb = e;
            this.output = X(this)
        };
    _.T(bx, Z);
    bx.prototype.g = function() {
        var a;
        this.ya.kind !== 0 || (a = this.Yd) == null || !_.t(a, 1) || this.Xb ? this.output.H(this.ya) : (a = this.ya.nb, _.sa() || (a = a.replace(UR, "$1<meta http-equiv=Content-Security-Policy content=\"script-src https://cdn.ampproject.org/;object-src 'none';child-src blob:;frame-src 'none'\">")), this.isBackfill && (a = a.replace(UR, '$1<meta name="referrer" content="origin">')), this.output.H({
            kind: 0,
            nb: a
        }))
    };
    var VR = function(a, b, c) {
        Z.call(this, a, 1124);
        this.Ge = VM(this);
        this.A = Y(this, b);
        this.j = Y(this, c)
    };
    _.T(VR, Z);
    VR.prototype.g = function() {
        _.uk(this.j.value, {
            "min-width": "100%",
            visibility: "hidden"
        });
        _.uk(this.A.value, "min-width", "100%");
        this.Ge.notify()
    };
    var WR = function(a, b, c, d, e) {
        Z.call(this, a, 1125);
        this.A = Y(this, b);
        this.j = Y(this, c);
        YM(this, d);
        YM(this, e)
    };
    _.T(WR, Z);
    WR.prototype.g = function() {
        var a = this.A.value,
            b = a.contentDocument;
        b && (a.setAttribute("height", String(b.body.offsetHeight)), a.setAttribute("width", String(b.body.offsetWidth)), _.uk(this.j.value, "visibility", "visible"))
    };
    var Vt = function(a, b, c, d) {
        PM.call(this, new _.z.Promise(function(e) {
            var f = a.listen(b, function(g) {
                g = c(g);
                g !== null && (f(), e(g))
            });
            _.$q(d, f)
        }))
    };
    _.T(Vt, PM);
    var Et = function(a, b, c, d) {
        d = d === void 0 ? function() {
            return !0
        } : d;
        QM.call(this, new _.z.Promise(function(e) {
            var f = a.listen(b, function(g) {
                d(g) && (f(), e())
            });
            _.$q(c, f)
        }))
    };
    _.T(Et, QM);
    var Sx = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 718);
        this.slotId = b;
        this.Zc = c;
        this.Yd = d;
        this.Fa = e;
        this.j = f;
        this.output = X(this);
        this.C = new Et(this.slotId, Fx, this);
        this.A = Y(this, g)
    };
    _.T(Sx, Z);
    Sx.prototype.g = function() {
        var a = !this.A.value;
        if (!this.Yd || this.Zc !== "height" || a) this.output.H(!1);
        else {
            a = new L(this.context.S, 7);
            _.Sq(this, a);
            var b = new VR(this.context, this.Fa, this.j);
            M(a, b);
            M(a, new WR(this.context, this.Fa, this.j, this.C.output, b.Ge));
            a.run();
            this.output.H(!0)
        }
    };
    var YR = [2, 1];
    var ZR = Sj(699, function(a, b, c, d, e, f, g, h) {
        var l = a.Da,
            k = a.rb,
            m = a.size,
            n = a.yp;
        k.style.width = "";
        k.style.height = "";
        if (g === "height") return {};
        var p;
        a = (p = a.tc) != null ? p : 0;
        p = !1;
        switch (a) {
            case 1:
            case 2:
            case 4:
            case 5:
                var r, v = l.parentElement ? (r = xo(l.parentElement, window)) == null ? void 0 : r.width : void 0;
                r = m.width;
                p = m.height;
                var u = g = 0;
                var x = co(e);
                x = _.y(x);
                for (var D = x.next(); !D.done; D = x.next()) {
                    var F = D.value;
                    Array.isArray(F) && (D = F[0], F = F[1], g < D && (g = D), u < F && (u = F))
                }
                u = [g, u];
                g = u[0] < r;
                p = u[1] < p;
                if (g || p) {
                    u = r + "px";
                    x = {
                        "max-height": "none",
                        "max-width": u,
                        padding: "0px",
                        width: u
                    };
                    p && (x.height = "auto");
                    es(k, l, x);
                    k = {};
                    if ((_.E = [2, 5], _.w(_.E, "includes")).call(_.E, a) || g && r > bs(n.width)) k.width = u, k["max-width"] = u;
                    p && (k.height = "auto", k["max-height"] = "none");
                    c: {
                        for (C in k)
                            if (Object.prototype.hasOwnProperty.call(k, C)) {
                                var C = !1;
                                break c
                            }
                        C = !0
                    }
                    C ? k = !1 : (k["padding-" + (n.direction === "ltr" ? "left" : "right")] = "0px", _.ds(l, k), k = !0)
                } else k = !1;
                b: {
                    p = m.width;C = c.defaultView || c.parentWindow || _.ca;
                    switch (a) {
                        case 2:
                        case 5:
                            l = fs(l, C, p, n, f);
                            break b;
                        case 1:
                        case 4:
                            if (r = l.parentElement)
                                if (f = no(r)) {
                                    g = f.width;
                                    f = vo(d, C.document);
                                    x = xo(f, C);
                                    f = x.position;
                                    u = bs(x.width) || 0;
                                    n = xo(r, C);
                                    C = n.direction === "rtl" ? "Right" : "Left";
                                    p = Math.max(Math.round((g - Math.max(u, p)) / 2), 0);
                                    g = {};
                                    u = 0;
                                    if (D = Cs(x))
                                        if (u = D[4] * (C === "Right" ? -1 : 1), F = D[3] || 1, (D[0] || 1) !== 1 || F !== 1) D[0] = 1, D[3] = 1, g.transform = "matrix(" + D.join(",") + ")";
                                    F = 0;
                                    D = C.toLowerCase();
                                    switch (f) {
                                        case "fixed":
                                            var G, S = (G = Number(_.yo(x.getPropertyValue(D)))) != null ? G : 0,
                                                P;
                                            G = (P = r.getBoundingClientRect().left) != null ? P : 0;
                                            F = S - G;
                                            break;
                                        case "relative":
                                            F = (S = Number(_.yo(x.getPropertyValue(D)))) != null ? S : 0;
                                            break;
                                        case "absolute":
                                            g[D] = "0"
                                    }
                                    P = n.justifyContent === "center" && _.I(II);
                                    G = n.direction === "rtl" ? "Left" : "Right";
                                    S = f === "absolute" ? 0 : bs(n["padding" + C]) - (P ? bs(n["padding" + G]) : 0);
                                    P = bs(n["border" + C + "Width"]) - (P ? bs(n["border" + G + "Width"]) : 0);
                                    g["margin-" + D] = p - S - P - F - u + "px";
                                    _.ds(l, g);
                                    l = !0
                                } else l = !1;
                            else l = !1;
                            break b;
                        default:
                            l = !1;
                            break b
                    }
                    l = void 0
                }
                k || l ? (_.w(YR, "includes").call(YR, a) && hs(b, c, d, e, a, m.width, m.height, v, "gpt_slotexp", h), p = !0) : p = !1;
                break;
            case 3:
                a = l.parentElement ? (v = xo(l.parentElement, window)) == null ? void 0 : v.width : void 0, v = m.width, P = m.height, G = bs(n.height) || 0, P >= G || n.display === "none" || n.visibility === "hidden" || !f || f.width === -12245933 || l.getBoundingClientRect().bottom <= f.height ? p = !1 : (G = {
                    height: P + "px"
                }, es(k, l, G), _.ds(l, G), hs(b, c, d, e, 3, v, P, a, "gpt_slotred", h), p = !0)
        }!p && _.I(JI) && hs(b, c, d, e, 0, m.width, m.height, void 0, "gpt_pgbrk", h);
        return {}
    }, {});
    var $R = Sj(1114, function(a, b, c, d, e) {
        if (!b) return {
            wc: null,
            Tc: []
        };
        b = b.split(":");
        if (b.length !== 2 || b[0] !== "#flexibleAdSlotDebugSize") return {
            wc: null,
            Tc: []
        };
        b = b[1];
        a = a.Da;
        var f = /(?:.*)width=(parent|viewport|[0-9]+)(?:;.*|$)/.exec(b);
        if (f) {
            if (f = f[1], f !== "viewport")
                if (f === "parent") {
                    var g, h;
                    c = (a = (h = (g = no(a.parentElement)) == null ? void 0 : g.width) != null ? h : null) ? Math.min(a, c) : null
                } else c = Number(f), c = c >= 0 ? c : null
        } else c = null;
        (g = /(?:.*)height=(ratio|[0-9]+)(?:;.*|$)/.exec(b)) ? (g = g[1], g === "ratio" ? g = c && d && e ? Math.floor(e / d * c) : null : (g = Number(g), g = g >= 0 ? g : null)) : g = null;
        b = (b = /(?:.*)ius=(.+,?)+(?:;.*|$)/.exec(b)) ? b[1].split(",") : [];
        if (!c && !g) return {
            wc: null,
            Tc: []
        };
        var l, k;
        return {
            wc: new _.mo((l = c != null ? c : d) != null ? l : 0, (k = g != null ? g : e) != null ? k : 0),
            Tc: b
        }
    }, {
        wc: void 0,
        Tc: void 0
    });
    var aS = Sj(681, function(a, b, c, d, e, f) {
        if (d) {
            var g, h;
            return {
                ya: a.ya,
                Cd: new _.mo(f != null ? f : 0, (g = a.ei) != null ? g : 0),
                tc: (h = e) != null ? h : null,
                Ff: !1
            }
        }
        c = ws(c);
        (d = !c || !a.wc) || (d = a.Tc, d.length ? (b = b.split("/"), b = _.w(d, "includes").call(d, b[b.length - 1])) : b = !0, d = !b);
        if (d) {
            if (f == null) throw new HL("Missing 'width'.");
            if (a.ei == null) throw new HL("Missing 'height'.");
            var l;
            return {
                ya: a.ya,
                Cd: new _.mo(f, a.ei),
                tc: (l = e) != null ? l : null,
                Ff: !1
            }
        }
        f = a.Da;
        var k, m;
        e = (m = (k = no(f.parentElement)) == null ? void 0 : k.width) != null ? m : 0;
        k = a.wc;
        a = k.width;
        k = k.height;
        e = a <= e ? 1 : 2;
        m = '<html><body style="height:' + (k - 2 + "px;width:" + (a - 2 + 'px;background-color:#ddd;color:#000;border:1px solid #f00;margin:0;"><p>Requested size:')) + (c.width + "x" + c.height + "</p><p>Rendered size:") + (a + "x" + k + "</p></body></html>");
        _.uk(f, "opacity", .5);
        return {
            ya: {
                kind: 0,
                nb: m
            },
            Cd: new _.mo(a, k),
            tc: e,
            Ff: !0
        }
    }, {
        ya: void 0,
        Cd: void 0,
        tc: void 0,
        Ff: void 0
    });
    var cx = function(a, b, c, d, e, f, g, h, l, k, m, n) {
        L.call(this, a.S, 8);
        a = this.g($R, {
            Da: n
        }, b, c.width, l, k);
        d = this.g(aS, {
            ei: g,
            wc: a.wc,
            Tc: a.Tc,
            ya: m,
            Da: n
        }, d, e, f, h, l);
        this.A = {
            Ka: d.ya,
            Oa: d.Cd,
            tm: d.tc,
            Vn: d.Ff
        }
    };
    _.T(cx, L);
    var bS = Sj(698, function(a, b) {
        return {
            output: xo(a.element, b)
        }
    }, {
        output: void 0
    });
    var kx = function(a, b, c, d, e, f, g, h, l, k, m) {
        L.call(this, a.S, 9);
        var n = this.g(bS, {
            element: f
        }, b).output;
        this.bg = this.g(ZR, {
            Da: f,
            rb: g,
            size: l,
            tc: k,
            yp: n
        }, a, b.document, d, e, c, h, m).finished
    };
    _.T(kx, L);
    var cS = Sj(1266, function(a) {
        var b = {
                output: []
            },
            c = ej(KI);
        if (!c.length) return b;
        a = a.Kp;
        if (a == null || !a.size) return b;
        c = _.y(c);
        for (var d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = d.split(" ");
            e.length !== 4 && Hs("Invalid path: " + d);
            var f = _.y(e);
            e = f.next().value;
            var g = f.next().value,
                h = f.next().value;
            f = f.next().value;
            var l = g;
            g = f;
            e && h && g || Hs("Invalid path: " + d);
            d = Number(e);
            isNaN(d) && Hs("Non-numeric entity ID: " + e);
            e = l.length ? l.split(".") : [];
            h = h.split(".");
            g = (f = g[g.length - 1] === "?") ? g.slice(0, -1).split(".") : g.split(".");
            l = _.y(a);
            for (var k = l.next(); !k.done; k = l.next()) {
                var m = _.y(k.value);
                k = m.next().value;
                m = m.next().value;
                var n = e.length ? (_.E = Gs(m, e), _.w(_.E, "flat")).call(_.E) : [m];
                m = [];
                n = _.y(n);
                for (var p = n.next(); !p.done; p = n.next()) {
                    p = p.value;
                    var r = Gs(p, h);
                    r.length < 1 && Hs("No key found for " + h);
                    r.length > 1 && Hs("Matched multiple keys w/ " + h);
                    m.push({
                        key: String(r[0]),
                        data: Gs(p, g).map(f ? function() {
                            return "1"
                        } : function(v) {
                            return JSON.stringify(v)
                        })
                    })
                }
                b.output.push({
                    transactionId: k,
                    en: d,
                    Qm: m
                })
            }
        }
        return b
    }, {
        output: void 0
    });
    var dS = Sj(1267, function(a, b) {
        var c = _.K(LI);
        if (!c || !a.pj.length) return {};
        var d = PH(OH(NH(new MH, b.pvsid), c)),
            e = _.Aq(d, KH, 5, QH);
        a = _.y(a.pj);
        for (var f = a.next(); !f.done; f = a.next()) {
            var g = f.value;
            f = IH(HH(new GH, g.transactionId), g.en);
            Fl(e, 1, GH, f);
            g = _.y(g.Qm);
            for (var h = g.next(); !h.done; h = g.next()) {
                var l = h.value;
                h = EH(new DH, l.key);
                Fl(f, 3, DH, h);
                l = _.y(l.data);
                for (var k = l.next(); !k.done; k = l.next()) _.df(h, 2, _.Bd, k.value, Dd)
            }
        }
        b.O.log(655300591, function() {
            return d
        }, {
            Ta: c
        });
        return {}
    }, {});
    var eS = function(a, b, c) {
        L.call(this, a.S, 10);
        _.R(b, 13) || _.R(b, 3) && _.R(b, 9) || (b = this.g(cS, {
            Kp: c
        }).output, this.g(dS, {
            pj: b
        }, a))
    };
    _.T(eS, L);
    var fS = function(a, b, c, d, e) {
        Z.call(this, a, 937, _.K(GJ));
        this.eb = b;
        this.j = X(this);
        this.A = X(this);
        this.C = X(this);
        this.Nc = c;
        this.Lc = d;
        this.xd = e
    };
    _.T(fS, Z);
    fS.prototype.g = function() {
        var a = {},
            b;
        if ((b = _.Fi(this.eb, pC, 2)) == null ? 0 : _.R(b, 2)) a["*"] = {
            Mf: !0
        };
        b = new _.z.Set;
        for (var c = _.y(_.ul(this.eb, oC, 1, _.wl())), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            for (var e = _.y([_.t(d, 2), _.t(d, 1)].filter(function(p) {
                    return !!p
                })), f = e.next(); !f.done; f = e.next()) a[f.value] = {
                Mf: _.R(d, 3)
            };
            d = _.y(Dv(d, 4));
            for (e = d.next(); !e.done; e = d.next()) b.add(e.value)
        }
        this.Nc.H(a);
        this.j.H([].concat(_.Zk(b)));
        var g, h;
        a = (g = _.Fi(this.eb, pC, 2)) == null ? void 0 : (h = _.Fi(g, hC, 1)) == null ? void 0 : _.ul(h, gC, 1, _.wl(_.Yn));
        this.A.ic((a == null ? 0 : a.length) ? a : null);
        var l;
        this.Lc.H(!((l = _.Fi(this.eb, pC, 2)) == null || !_.R(l, 4)));
        var k;
        this.xd.H(!((k = _.Fi(this.eb, pC, 2)) == null || !_.R(k, 5)));
        var m, n;
        g = (m = _.Fi(this.eb, pC, 2)) == null ? void 0 : (n = _.Fi(m, hC, 3)) == null ? void 0 : _.ul(n, gC, 1, _.wl(_.Yn));
        this.C.ic((g == null ? 0 : g.length) ? g : null)
    };
    fS.prototype.X = function(a) {
        this.l(a)
    };
    fS.prototype.l = function() {
        this.Nc.H({});
        this.j.H([]);
        this.A.ha();
        this.Lc.H(!1);
        this.xd.H(!1);
        this.C.ha()
    };
    var gS = function(a, b, c, d) {
        Z.call(this, a, 980);
        this.Bb = b;
        this.output = new qu;
        this.j = Y(this, c);
        this.A = Y(this, d)
    };
    _.T(gS, Z);
    gS.prototype.g = function() {
        for (var a = _.y(_.w(Object, "entries").call(Object, this.j.value)), b = a.next(); !b.done; b = a.next()) {
            b = _.y(b.value);
            var c = b.next().value;
            b = b.next().value;
            var d = void 0;
            if ((d = b) == null ? 0 : d.Mf) c !== "*" ? this.Bb.J = !0 : this.Bb.F = !0
        }
        fp(25, this.context);
        a = _.y(this.A.value);
        for (b = a.next(); !b.done; b = a.next()) Ti(b.value);
        this.output.notify()
    };
    var hS = function(a, b, c, d) {
        Z.call(this, a, 931);
        this.j = WM(this, b);
        this.pd = c;
        this.Mc = d
    };
    _.T(hS, Z);
    hS.prototype.g = function() {
        var a = this.j.value,
            b = new _.z.Map;
        this.pd.H(new _.z.Map);
        if (a) {
            var c;
            a = _.y((c = this.j.value) != null ? c : []);
            for (c = a.next(); !c.done; c = a.next()) {
                var d = c.value;
                c = _.ul(d, fC, 1, _.wl());
                c = _.Sh(c[0], 1, 0) === 1 ? FA(c[0]) : GA(c[0], EA);
                d = _.hi(d, 2);
                var e = void 0;
                b.set(c, Math.min((e = b.get(c)) != null ? e : Number.MAX_VALUE, d))
            }
        }
        this.Mc.H(b)
    };
    hS.prototype.l = function() {
        this.pd.H(new _.z.Map);
        this.Mc.H(new _.z.Map)
    };
    var iS = function(a, b, c) {
        Z.call(this, a, 981);
        this.A = X(this);
        this.C = WM(this, b);
        this.j = c
    };
    _.T(iS, Z);
    iS.prototype.g = function() {
        var a = new _.z.Map,
            b, c = _.y((b = this.C.value) != null ? b : []);
        for (b = c.next(); !b.done; b = c.next()) {
            b = b.value;
            var d = _.ul(b, fC, 1, _.wl());
            d = _.Sh(d[0], 1, 0) === 1 ? FA(d[0]) : GA(d[0], EA);
            a.set(d, _.hi(b, 2))
        }
        this.A.H(a);
        this.j.H(new XB)
    };
    iS.prototype.l = function() {
        this.A.H(new _.z.Map);
        var a = this.j,
            b = a.H;
        var c = new XB;
        c = _.uj(c, 1, 2);
        b.call(a, c)
    };
    var jS = function(a, b, c, d, e, f) {
        Z.call(this, a, 976);
        this.nextFunction = d;
        this.j = e;
        this.requestBidsConfig = f;
        YM(this, b);
        YM(this, c)
    };
    _.T(jS, Z);
    jS.prototype.g = function() {
        var a;
        (a = this.nextFunction) == null || a.apply(this.j, [this.requestBidsConfig])
    };
    var kS = function(a, b, c, d, e, f) {
        Z.call(this, a, 975);
        this.Ac = b;
        this.xc = c;
        this.j = d;
        this.pbjs = e;
        this.requestBidsConfig = f;
        this.output = new qu
    };
    _.T(kS, Z);
    kS.prototype.g = function() {
        Ns(this.pbjs, this.Ac, this.xc, this.j, this.requestBidsConfig);
        this.output.notify()
    };
    kS.prototype.l = function() {
        this.output.notify()
    };
    var lS = function(a, b, c, d, e, f) {
        Z.call(this, a, 1100);
        this.pbjs = b;
        this.A = c;
        this.j = d;
        this.C = e;
        this.requestBidsConfig = f;
        this.output = new qu
    };
    _.T(lS, Z);
    lS.prototype.g = function() {
        var a, b, c = (b = (a = this.A) == null ? void 0 : a.get("*")) != null ? b : _.K(ZI);
        if (c) this.rc(c);
        else {
            var d, e, f, g;
            a = (g = (f = (d = this.requestBidsConfig) == null ? void 0 : d.adUnits) != null ? f : (e = this.pbjs) == null ? void 0 : e.adUnits) != null ? g : [];
            d = _.y(a);
            for (e = d.next(); !e.done; e = d.next())
                if (e = e.value.code) a = g = f = void 0, (b = this.A) == null ? b = void 0 : (c = e.match(/\/?([0-9]+)(?:,[0-9]+)?((?:\/.+?)+?)(?:\/*)$/), b = b.get((c == null ? void 0 : c.length) !== 3 ? e : "/" + c[1] + c[2])), b = (f = (g = b) != null ? g : (a = this.A) == null ? void 0 : a.get(_.aj(e))) != null ? f : 0, this.rc(b)
        }
        this.output.notify()
    };
    lS.prototype.rc = function(a) {
        var b;
        (b = this.j) != null && _.Dl(b, 2, this.C);
        if (a) {
            var c;
            (c = this.j) == null || _.uj(c, 1, 1);
            var d;
            (d = this.j) != null && _.Dm(d, 3, a);
            if (!this.C) {
                this.requestBidsConfig.timeout = a;
                var e, f, g;
                b = (g = (f = (e = this.pbjs).getConfig) == null ? void 0 : f.call(e).s2sConfig) != null ? g : [];
                if (Array.isArray(b))
                    for (e = _.y(b), f = e.next(); !f.done; f = e.next()) f.value.timeout = a;
                else b.timeout = a;
                var h, l;
                (l = (h = this.pbjs).setConfig) == null || l.call(h, {
                    bidderTimeout: a
                })
            }
        }
    };
    lS.prototype.l = function() {
        this.output.notify()
    };
    var mS = function(a, b, c, d, e, f, g, h) {
        _.W.call(this);
        this.g = a;
        this.Ac = b;
        this.xc = c;
        this.l = d;
        this.F = e;
        this.j = f;
        this.A = g;
        this.pbjs = h
    };
    _.T(mS, _.W);
    mS.prototype.push = function(a) {
        var b = a.context;
        var c = a.nextFunction;
        a = a.requestBidsConfig;
        if (this.pbjs) {
            var d = new L(this.g.S, 17);
            _.Sq(this, d);
            var e = new lS(this.g, this.pbjs, this.F, this.j, this.A, a),
                f = new kS(this.g, this.Ac, this.xc, this.l, this.pbjs, a);
            M(d, e);
            M(d, f);
            M(d, new jS(this.g, f.output, e.output, c, b, a));
            d.run()
        }
    };
    var Ps = function(a, b) {
        this.push = N(a, 932, function(c) {
            b.push(c)
        })
    };
    var nS = function(a, b, c, d, e, f, g, h, l, k, m) {
        Z.call(this, a, 951);
        this.B = window;
        this.G = Y(this, b);
        this.A = WM(this, d);
        this.C = Y(this, e);
        this.R = Y(this, f);
        this.j = WM(this, g);
        this.U = WM(this, h);
        this.I = Y(this, l);
        YM(this, c);
        this.Uf = k != null ? k : X(this);
        this.Vf = m != null ? m : X(this)
    };
    _.T(nS, Z);
    nS.prototype.g = function() {
        var a = !!Sp().pbjs_hooks,
            b = a ? null : _.wk(),
            c, d = (c = this.A.value) == null ? void 0 : c.size,
            e;
        c = ((e = this.j.value) == null ? void 0 : e.size) || _.K(ZI);
        e = this.G.value;
        var f, g = (f = Sp().pbjs_hooks) != null ? f : [];
        f = new mS(this.context, this.A.value, this.C.value, this.R.value, this.j.value, this.U.value, this.I.value, e);
        _.Sq(this, f);
        g = _.y(g);
        for (var h = g.next(); !h.done; h = g.next()) f.push(h.value);
        if (d || c || a) Sp().pbjs_hooks = Qs(this.context, f);
        !d && !c || a || Os(e, this.B);
        this.Vf.H(a);
        this.Uf.ic(b)
    };
    var oS = function(a, b, c) {
        Z.call(this, a, 966);
        this.B = b;
        this.hc = c
    };
    _.T(oS, Z);
    oS.prototype.g = function() {
        var a = this,
            b = Kj(this.B);
        if (b) this.hc.H(b);
        else if (b = Object.getOwnPropertyDescriptor(this.B, "_pbjsGlobals"), !b || b.configurable) {
            var c = null;
            Object.defineProperty(this.B, "_pbjsGlobals", {
                set: function(d) {
                    c = d;
                    (d = Kj(a.B)) && a.hc.H(d)
                },
                get: function() {
                    return c
                }
            })
        }
    };
    oS.prototype.l = function() {};
    var Cw = function(a, b, c, d, e) {
        Z.call(this, a, 1146, _.K(GJ));
        this.Bb = b;
        this.B = d;
        this.j = e;
        this.A = XM(this, c)
    };
    _.T(Cw, Z);
    Cw.prototype.g = function() {
        var a = this.A.value,
            b = new L(this.context.S, 11);
        _.Sq(this, b);
        var c = new oS(this.context, this.B, this.j.hc);
        M(b, c);
        if (a) {
            a = new fS(this.context, a, this.j.Nc, this.j.Lc, this.j.xd);
            M(b, a);
            var d = new gS(this.context, this.Bb, a.Nc, a.j);
            M(b, d);
            var e = new hS(this.context, a.A, this.j.pd, this.j.Mc);
            M(b, e);
            var f = new iS(this.context, a.C, this.j.Bg);
            M(b, f);
            c = new nS(this.context, c.hc, d.output, e.Mc, this.j.Lc, e.pd, f.A, f.j, a.xd, this.j.Uf, this.j.Vf);
            M(b, c)
        } else pS(this);
        b.run()
    };
    var pS = function(a) {
        a.j.Nc.H({});
        a.j.Mc.H(new _.z.Map);
        a.j.Lc.H(!1);
        a.j.pd.H(new _.z.Map);
        a.j.Uf.ha();
        a.j.Vf.H(!1);
        a.j.Bg.H(new XB);
        a.j.xd.H(!1)
    };
    Cw.prototype.X = function(a) {
        this.l(a)
    };
    Cw.prototype.l = function() {
        pS(this)
    };
    var qS = function(a, b, c, d, e, f, g, h, l, k) {
        Z.call(this, a, 920);
        this.V = b;
        this.W = c;
        this.pbjs = l;
        this.U = k;
        this.G = X(this);
        this.ca = [];
        this.C = new _.z.Map;
        this.j = X(this);
        this.I = Y(this, d);
        this.ka = WM(this, e);
        this.ia = Y(this, f);
        this.pa = Y(this, g);
        this.oa = WM(this, h);
        a = _.y(ej(SI));
        for (b = a.next(); !b.done; b = a.next()) {
            b = b.value.split(" ");
            c = Number(b[0]);
            d = b.splice(1, b.length).join(" ");
            e = encodeURI(d);
            f = encodeURI(e);
            try {
                if (isNaN(c)) throw Error("Non-numeric entity ID " + b[0]);
                this.C.set(c, new RegExp(d + "|" + e + "|" + f, "g"))
            } catch (m) {
                qn(this.context, 920, m)
            }
        }
        this.A = _.K(TI);
        this.R = _.K(RI)
    };
    _.T(qS, Z);
    qS.prototype.g = function() {
        for (var a = this, b = Date.now(), c = new _.z.Map, d = new _.z.Map, e = !1, f = _.y(this.I.value), g = f.next(), h = {}; !g.done; h = {
                Ii: void 0
            }, g = f.next()) {
            g = g.value;
            for (var l = {}, k = _.y(En(this.W[g.getDomId()])), m = k.next(); !m.done; m = k.next()) m = m.value, l[_.t(m, 1)] = Ln(m, _.Yn);
            var n = m = k = void 0,
                p = void 0,
                r = void 0,
                v = void 0;
            (l = Nj(this.pbjs, {
                Dd: g.getDomId(),
                adUnitCode: g.getAdUnitPath()
            }, {
                Ve: l,
                Ac: (r = (k = this.ka) == null ? void 0 : k.value) != null ? r : void 0,
                xc: (m = this.ia) == null ? void 0 : m.value,
                mi: (n = this.pa) == null ? void 0 : n.value,
                Ag: (v = (p = this.oa) == null ? void 0 : p.value) != null ? v : void 0,
                ck: _.K($s),
                Xi: _.K(MI),
                dj: _.K(OI),
                cj: _.K(NI),
                Nj: _.K(WI),
                Mj: _.K(VI),
                Zh: this.A ? function(u) {
                    return void rS(a, u)
                } : void 0
            })) ? (e = l, l = e.Kn, k = e.transactionId, m = e.arg, e = !0, c.set(g, l), k && d.set(k, m)) : (l === null && this.ca.push(g), c.set(g, new dC));
            h.Ii = g.getDomId() + g.getAdUnitPath();
            rM.has(h.Ii) || _.$q(g, function(u) {
                return function() {
                    return rM.delete(u.Ii)
                }
            }(h))
        }
        e ? (this.U.ic(c), this.G.H(this.ca), this.j.H(d)) : sS(this);
        this.context.va.La.Ma.hb.li.no.wb({
            xb: Date.now() - b,
            xo: this.I.value.length,
            Jn: e
        })
    };
    qS.prototype.X = function(a) {
        this.l(a)
    };
    qS.prototype.l = function(a) {
        this.V.error(bQ(a.message));
        sS(this)
    };
    var sS = function(a) {
            a.U.ha();
            a.G.ha();
            a.j.ha()
        },
        rS = function(a, b) {
            var c = b.ad;
            var d = b.adId;
            var e, f, g, h;
            return _.ug(function(l) {
                if (!d || !c) return l.return();
                e = _.K(PI);
                f = a.context.va.La.Ma.hb.li;
                g = function() {
                    var k, m, n, p, r, v, u, x, D, F, C, G, S, P;
                    return _.ug(function(J) {
                        switch (J.g) {
                            case 1:
                                k = BH(AH(new zH, d), c.length), m = a.R >= 0 ? c.slice(0, a.R) : c, n = 0, p = Date.now(), r = _.y(_.w(a.C, "entries").call(a.C)), v = r.next();
                            case 2:
                                if (v.done) {
                                    J.g = 4;
                                    break
                                }
                                u = v.value;
                                x = _.y(u);
                                D = x.next().value;
                                F = x.next().value;
                                C = D;
                                G = F;
                                S = Date.now();
                                G.test(m) && (_.df(k, 2, Yc, Number(C), Zc), n = G.lastIndex, G.lastIndex = 0);
                                P = Date.now();
                                _.I(UI) && f.Mm.wb({
                                    xb: P - S,
                                    dn: C
                                });
                                if (!(e >= 0 && P - p > e)) {
                                    J.g = 3;
                                    break
                                }
                                return J.yield(0, 6);
                            case 6:
                                p = Date.now();
                            case 3:
                                v = r.next();
                                J.g = 2;
                                break;
                            case 4:
                                n && _.Dm(k, 4, n), a.context.O.log(655300591, function() {
                                    var U = PH(OH(NH(new MH, a.context.pvsid), a.A));
                                    return _.en(U, 3, QH, k)
                                }, {
                                    Ta: a.A
                                }), J.g = 0
                        }
                    })
                };
                h = _.K(QI);
                return l.return(h >= 0 ? Ss(g, h) : g())
            })
        };
    var tS = function(a, b, c, d) {
        Z.call(this, a, 1019);
        this.W = c;
        this.pbjs = d;
        this.j = WM(this, b)
    };
    _.T(tS, Z);
    tS.prototype.g = function() {
        uS(this)
    };
    var uS = function(a) {
        if (!(Math.random() >= _.K(XI))) {
            var b = (a.j.value || []).filter(function(l) {
                return En(a.W[l.getDomId()]).some(function(k) {
                    return xl(k, 1) === "hb_pb"
                })
            });
            if (b.length) {
                var c, d, e, f, g, h = ((c = a.pbjs) == null ? 0 : (d = c.adUnits) == null ? 0 : d.length) ? [].concat(_.Zk(new _.z.Set((e = a.pbjs) == null ? void 0 : e.adUnits.map(function(l) {
                    return l.code
                })))) : _.w(Object, "keys").call(Object, ((f = a.pbjs) == null ? void 0 : (g = f.getAdserverTargeting) == null ? void 0 : g.call(f)) || {});
                c = new xr("haux");
                zr(c, "ius", b.map(function(l) {
                    return l.getAdUnitPath()
                }).join("~"));
                zr(c, "dids", b.map(function(l) {
                    return l.getDomId()
                }).join("~"));
                zr(c, "paucs", h.join("~"));
                yr(c, a.context);
                Br(c)
            }
        }
    };
    var Xs = function(a, b, c, d, e, f, g, h, l, k) {
        Z.call(this, a, 1153);
        this.V = b;
        this.Z = c;
        this.W = d;
        this.networkCode = e;
        this.ba = f;
        this.C = g;
        this.Fb = h;
        this.j = k;
        this.G = Y(this, h.Nc);
        this.A = new NM(h.hc);
        l && (this.I = WM(this, l))
    };
    _.T(Xs, Z);
    Xs.prototype.g = function() {
        var a, b = (a = this.A) == null ? void 0 : a.value;
        if (a = vS(this)) b != null && b.libLoaded ? typeof b.getEvents !== "function" ? (this.V.error(aQ()), a = !1) : a = !0 : a = !1;
        if (a) {
            a = new L(this.context.S, 12);
            _.Sq(this, a);
            var c = new qS(this.context, this.V, this.W, this.C, this.Fb.Mc, this.Fb.Lc, this.Fb.pd, this.Fb.Bg, b, this.j.Hi);
            M(a, c);
            M(a, new tS(this.context, c.G, this.W, b));
            Fu(a, new eS(this.context, this.ba, c.j));
            a.run()
        } else this.j.Hi.ha()
    };
    var vS = function(a) {
        if (_.R(a.Z, 38)) return !0;
        var b;
        if ((b = a.I) == null ? 0 : b.value) return !0;
        var c = a.G.value;
        if (!c) return !1;
        var d;
        return !((d = c["*"]) == null || !d.Mf) || a.networkCode.split(",").some(function(e) {
            var f;
            return !((f = c[e]) == null || !f.Mf)
        })
    };
    var wS = function(a, b, c, d, e) {
        Z.call(this, a, 982);
        this.Xb = b;
        this.lb = c;
        this.j = d;
        this.Le = e
    };
    _.T(wS, Z);
    wS.prototype.g = function() {
        for (var a = this, b = _.y(["bidWon", "staleRender", "adRenderFailed", "adRenderSucceeded"]), c = b.next(), d = {}; !c.done; d = {
                vf: void 0,
                ci: void 0
            }, c = b.next()) d.vf = c.value, d.ci = function(e) {
            return function(f) {
                if (a.j === f.adId) {
                    var g = new xr("hbm_brt");
                    yr(g, a.context);
                    zr(g, "et", e.vf);
                    zr(g, "sf", a.Xb);
                    zr(g, "qqid", a.lb);
                    var h, l, k;
                    zr(g, "bc", String((k = (l = f.bidderCode) != null ? l : (h = f.bid) == null ? void 0 : h.bidder) != null ? k : ""));
                    Br(g)
                }
            }
        }(d), (0, this.Le.onEvent)(d.vf, d.ci), _.$q(this, function(e) {
            return function() {
                return void pn(a.context, a.id, function() {
                    var f, g;
                    return void((g = (f = a.Le).offEvent) == null ? void 0 : g.call(f, e.vf, e.ci))
                }, !0)
            }
        }(d))
    };
    wS.prototype.l = function() {};
    var xS = function(a, b, c, d, e) {
        Z.call(this, a, 1134);
        this.A = b;
        this.Xb = c;
        this.lb = d;
        this.j = new NM(e)
    };
    _.T(xS, Z);
    xS.prototype.g = function() {
        var a;
        if (this.A && (a = this.j.value) != null && a.onEvent) {
            a = new L(this.context.S, 13);
            var b = new wS(this.context, this.Xb, this.lb, this.A, this.j.value);
            M(a, b);
            a.run()
        }
    };
    var Qw = Sj(1277, function(a, b, c, d) {
        b ? (a = Fn(Gn(new Hn, d), ["1"]), Fl(c, 2, Hn, a)) : (a = Fn(Gn(new Hn, d), ["0"]), Fl(c, 2, Hn, a));
        return {}
    }, {});
    var yS = Sj(1276, function(a) {
        a = a.pbjs;
        try {
            var b;
            (b = a.setConfig) == null || b.call(a, {
                useBidCache: !1
            })
        } catch (c) {}
        return {}
    }, {});
    var Zs = new _.z.Map;
    var CS = function(a, b, c, d) {
            var e = this;
            this.context = a;
            this.L = c;
            this.g = new _.z.Map;
            this.o = new _.z.Map;
            this.timer = _.Ri(po);
            AO() && (a = on(a, 334, function() {
                for (var f = _.y(e.g), g = f.next(); !g.done; g = f.next()) {
                    var h = _.y(g.value);
                    g = h.next().value;
                    h = h.next().value;
                    zS(e, g, h) && e.g.delete(g)
                }
            }), _.sg(window, "DOMContentLoaded", a), b.listen(SO, function(f) {
                var g = f.detail;
                f = g.Fi;
                g = g.W;
                return void AS(e, BS(d, f), Ov(g, 20))
            }), b.listen(TO, function(f) {
                var g = f.detail;
                f = g.Fi;
                g = g.W;
                f = BS(d, f);
                g = Ov(g, 20);
                var h = e.o.get(f);
                h != null ? CO(h, g) : AS(e, f, g)
            }))
        },
        AS = function(a, b, c) {
            zS(a, b, c) ? a.g.delete(b) : (a.g.set(b, c), _.$q(b, function() {
                return a.g.delete(b)
            }))
        },
        zS = function(a, b, c) {
            var d = vo(b);
            if ((d == null ? void 0 : d.nodeName) !== "DIV") return !1;
            d = new zO({
                B: window,
                timer: a.timer,
                Qb: d,
                Hb: function(e) {
                    return void qn(a.context, 336, e)
                },
                sp: _.I(zK)
            });
            if (!d.o) return !1;
            CO(d, c);
            a.o.set(b, d);
            vt(a.L, b, function() {
                return void a.o.delete(b)
            });
            return !0
        };
    var DS = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1058);
        this.B = b;
        this.C = c;
        this.Z = d;
        this.ba = e;
        this.output = VM(this);
        f && (this.j = WM(this, f));
        _.I(bJ) && g && (this.A = WM(this, g));
        YM(this, h)
    };
    _.T(DS, Z);
    DS.prototype.g = function() {
        var a = Zi(this.B.isSecureContext, this.B, this.B.document);
        if (a && _.I(bJ)) {
            var b, c = !((b = this.B.sharedStorage) == null || !b.createWorklet);
            b = new wL(this.B);
            var d, e = (d = this.A) == null ? void 0 : d.value;
            d = this.C.some(function(l) {
                l = ln(l.getAdUnitPath());
                var k;
                return !e || !Qe(e, 1, Id).get((k = l.split(",")) == null ? void 0 : k[0])
            });
            var f, g = !((f = by(this.Z)) == null || !_.R(f, 9));
            f = b.isEnabled(this.ba, {
                Zf: d,
                Yf: g
            });
            c && f && pm(this.context.pvsid)
        }
        var h;
        a && (h = this.j) != null && h.value && !_.I(aJ) && vi(this.ba) && (a = this.j.value, a({
            message: "goog:spam:client_age",
            pvsid: this.context.pvsid,
            source: 2
        }));
        this.output.notify()
    };
    var Ux = function(a, b, c, d, e, f, g, h, l, k) {
        L.call(this, a.S);
        var m = l.getAdUnitPath();
        l = _.Sh(l, 2, 0);
        m && l && (h.add(ln(m)), Fu(this, new vR(a, b, m, l, !0, c.pubads(), c.display, function() {
            c.pubadsReady || c.enableServices()
        }, c.cmd, d, e, f, g, !0, k)))
    };
    _.T(Ux, L);
    var lw = Sj(1110, function(a, b) {
        return {
            wl: _.I(dJ) && b.credentialless !== void 0 && (_.I(eJ) || b.crossOriginIsolated)
        }
    }, {
        wl: void 0
    });
    var ES = function(a, b, c, d, e, f) {
        Z.call(this, a, 935);
        this.L = b;
        this.K = c;
        this.ga = d;
        this.output = VM(this);
        this.j = Y(this, e);
        YM(this, f)
    };
    _.T(ES, Z);
    ES.prototype.g = function() {
        var a = this.K,
            b = a.Z;
        a = a.W;
        for (var c = _.y(this.j.value), d = c.next(); !d.done; d = c.next()) {
            var e = d.value;
            d = e;
            var f = b;
            e = a[e.getDomId()];
            var g = this.L,
                h = this.ga;
            bt(e, f) && !g.cd(d) && ct(d, h, e, f)
        }
        this.output.notify()
    };
    var FS = Sj(864, function(a, b, c, d) {
        a = _.y(a.T);
        for (var e = a.next(); !e.done; e = a.next())
            if (e = e.value, _.Qv(b, e)) {
                var f = c,
                    g = f.Z;
                f = f.W[e.getDomId()];
                bt(f, g) && ct(e, d, f, g);
                dP(b, e);
                var h = void 0,
                    l = void 0;
                (h = (l = Yr(f, 10)) != null ? l : _.R(g, 11)) != null && h && ct(e, d, f, g)
            }
        return {}
    }, {});
    var GS = Sj(1260, function(a) {
        var b = a.Wo,
            c = a.Im;
        a = a.maxHeight;
        if (c && a) {
            b = c.width;
            c = c.height;
            var d = "background-color:#ddd;color:#000;border:1px solid #f00;margin:0;width:" + (b - 2 + "px;");
            a = {
                kind: 0,
                nb: "  <html>    <head>  <style>    @media (min-height: " + (c + 1 + "px) {      #collapsedDiv {        display:none      }      #expandedDiv {        display:block      }    }    @media (max-height: " + (c - 1 + 'px) {      #collapsedDiv {         display:block      }      #expandedDiv {        display:none      }    }  </style></head>    <body>      <div id="collapsedDiv" style="')) + (d + "height:" + (c - 2) + 'px;">        <p>Collapsed State</p>        <p>Rendered size:') + (b + "x" + c + '</p>      </div>      <div id="expandedDiv" style="') + (d + "height:" + (a - 2) + 'px;">        <p>Expanded State</p>        <p>Rendered size:') + (b + "x" + a + "</p>      </div>    </body></html>")
            }
        } else a = b;
        return {
            ya: a
        }
    }, {
        ya: void 0
    });
    var HS = Sj(1261, function(a, b) {
        var c = a.size;
        a = a.maxHeight;
        b = b.gb;
        if (a) {
            var d = new LC;
            a = _.Dq(d, 1, a);
            a = _.Wg(b, 16, a);
            a = _.Dq(a, 4, c.width);
            _.Dq(a, 5, c.height)
        }
        return {
            gb: b
        }
    }, {
        gb: void 0
    });
    var IS = Sj(1262, function(a, b) {
        var c = b.Tp;
        b = b.B;
        /(?:.*)collapsibleBannerDemo(?:.*)/.exec(c) ? (a = /(?:.*)height=([0-9]+)(?:;.*|$)/.exec(c), a = {
            size: new _.mo(b.document.documentElement.clientWidth, 100),
            maxHeight: a ? Number(a[1]) : Math.floor(b.innerHeight / 2)
        }) : a = {
            size: a.Ue,
            maxHeight: null
        };
        return a
    }, {
        size: void 0,
        maxHeight: void 0
    });
    var dx = function(a, b, c, d, e, f) {
        L.call(this, a.S, 19);
        d ? (a = this.g(IS, {
            Ue: f
        }, {
            B: b,
            Tp: c
        }), this.g(HS, {
            size: a.size,
            maxHeight: a.maxHeight
        }, {
            gb: d
        }), this.A = {
            Ka: this.g(GS, {
                Wo: e,
                Im: a.size,
                maxHeight: a.maxHeight
            }).ya,
            Oa: a.size
        }) : this.A = {
            Ka: e,
            Oa: f
        }
    };
    _.T(dx, L);
    var JS = Pj(1238, function(a, b, c, d) {
        var e, f, g, h, l, k, m, n, p, r, v;
        return _.ug(function(u) {
            e = a;
            f = e.T;
            g = new _.z.Set;
            l = h = !1;
            k = _.K(hJ);
            m = k > 0 && c.Zb < 1 / k;
            n = _.wk();
            p = new _.z.Map;
            r = new _.z.Promise(function(x) {
                var D = on(c, 1239, function(S) {
                        h || (m && c.va.La.Ma.hb.Ej.Sn.wb({
                            xb: _.wk() - n
                        }), h = !0);
                        l ? F.disconnect() : (S.forEach(function(P) {
                            var J;
                            (J = p.get(P.target)) == null || J.forEach(function(U) {
                                P.intersectionRatio >= .8 ? g.add(U) : g.delete(U)
                            })
                        }), x(g))
                    }),
                    F = new IntersectionObserver(D, {
                        threshold: [.8]
                    });
                D = _.y(f);
                for (var C = D.next(); !C.done; C = D.next()) {
                    C = C.value;
                    var G = dt(vo(C, b));
                    G && (p.has(G) ? p.get(G).add(C) : p.set(G, new _.z.Set([C])), F.observe(G))
                }
            });
            _.$q(d, function() {
                l = !0
            });
            v = _.K(gJ);
            return u.return(_.z.Promise.race([r, vE(v, null)]).then(function(x) {
                m && c.va.La.Ma.hb.Ej.Om.wb({
                    xb: _.wk() - n,
                    didTimeout: x === null,
                    Fp: v
                });
                return x
            }))
        })
    });
    var KS = Sj(1208, function(a, b, c) {
        a = b == null ? void 0 : _.Fi(b, $C, 1);
        if (!a) return {};
        c = new wL(c);
        b = _.hi(a, 2) - Date.now() / 1E3;
        b = {
            maxAge: Math.max(b, 0),
            path: _.t(a, 3),
            domain: _.t(a, 4),
            secure: !1
        };
        Di("__eoi", a.getValue(), b, c.g);
        return {}
    }, {});
    var LS = Pj(879, function(a, b) {
        var c;
        return _.ug(function(d) {
            return ((c = a.cc) != null ? c : b.Zj.cc()) ? d.return(VK(b.Zj)) : d.return(null)
        })
    });
    var MS = Sj(896, function(a, b, c) {
        return {
            cc: b.cc(c === ".google.cn")
        }
    }, {
        cc: void 0
    });
    var Dw = function(a, b, c, d) {
        L.call(this, a.S, 21);
        a = new UK(b);
        _.Sq(this, a);
        b = this.g(MS, {}, a, _.Vn(150));
        d && uw(vw(At(b, d), _.K(HJ)), d);
        d = b.cc;
        this.A = this.l(LS, {
            cc: c ? d : void 0
        }, {
            Zj: a
        }).output
    };
    _.T(Dw, L);
    var Ew = function(a, b) {
        Z.call(this, a, 1018);
        this.Af = VM(this);
        this.j = WM(this, b)
    };
    _.T(Ew, Z);
    Ew.prototype.g = function() {
        var a, b, c;
        if ((a = this.j.value) == null) a = void 0;
        else {
            var d;
            (b = _.Fi(a, LK, 5)) == null ? d = void 0 : d = Dv(b, 1);
            a = d
        }
        a = _.y((c = a) != null ? c : []);
        for (c = a.next(); !c.done; c = a.next()) Ti(c.value);
        this.Af.notify()
    };
    var Fw = function(a, b) {
        Z.call(this, a, 1070);
        this.j = X(this);
        this.A = WM(this, b)
    };
    _.T(Fw, Z);
    Fw.prototype.g = function() {
        var a, b = (a = this.A.value) == null ? void 0 : _.Fi(a, LK, 5);
        if (b) {
            a = [];
            for (var c = _.y(Ie(b, 2, ff, 1, void 0, void 0, 4096)), d = c.next(); !d.done; d = c.next()) {
                var e = d.value;
                d = new xC;
                var f = new wC;
                e = _.vj(f, 1, id(e));
                d = _.Wg(d, 2, e);
                xt(b, 3) != null && (e = new vC, e = _.uj(e, 1, 1), f = _.Ct(b, 3), e = _.Dm(e, 2, f), _.Wg(d, 3, e));
                a.push(d)
            }
            this.j.H(a)
        } else this.j.H([])
    };
    var NS = Sj(1016, function(a) {
        var b = a.Bc,
            c = a.bn;
        if (!b) return {
            networkCode: null
        };
        var d, e = (d = a.yc) != null ? d : c;
        return _.ul(b, rC, 1, _.wl()).some(function(f) {
            return _.t(f, 1) === e
        }) ? {
            networkCode: e
        } : {
            networkCode: null
        }
    }, {
        networkCode: void 0
    }, function() {
        return {
            networkCode: null
        }
    });
    var OS = Sj(1056, function(a) {
        return {
            networkCode: ln(a.bb.getAdUnitPath())
        }
    }, {
        networkCode: void 0
    }, function() {
        return {
            networkCode: null
        }
    });
    var PS = Sj(1015, function(a) {
        if (!a.Bc) return {
            yc: null
        };
        a = _.ul(a.Bc, rC, 1, _.wl());
        if (!a.length) return {
            yc: null
        };
        var b = a[0];
        if ((_.E = [2, 3], _.w(_.E, "includes")).call(_.E, _.Sh(b, 3, 0))) {
            if (a.length !== 1) throw Error("list length is not 1");
            return {
                yc: _.t(b, 1)
            }
        }
        return {
            yc: null
        }
    }, {
        yc: void 0
    }, function() {
        return {
            yc: null
        }
    });
    var QS = Pj(1017, function(a, b) {
        var c;
        return _.ug(function(d) {
            c = new _.z.Promise(function(e) {
                if (a.networkCode) {
                    var f = gL(b, a.networkCode, function(g) {
                        if (!g) {
                            g = Wh(f.B);
                            for (var h = _.y(document.getElementsByName("googlefcPresent")), l = h.next(); !l.done; l = h.next()) g.Zl(l.value)
                        }
                        e()
                    });
                    f.start(_.I(nJ))
                } else e()
            });
            return d.return(c)
        })
    }, function() {});
    var Bw = function(a, b, c, d) {
        L.call(this, a.S, 22);
        b === b.top ? (d = new Vt(d, SO, function(e) {
            return e.detail.W
        }, this), a = this.g(PS, {
            Bc: c
        }).yc, d = this.g(OS, {
            bb: d.output
        }).networkCode, d = new Mt([a, d]), c = this.g(NS, {
            Bc: c,
            yc: a,
            bn: d
        }).networkCode, this.Gd = this.l(QS, {
            networkCode: c
        }, b).complete) : (this.Gd = new qu, this.Gd.notify())
    };
    _.T(Bw, L);
    var RS = !0;
    var tx = function(a, b, c, d, e) {
        Z.call(this, a, 934);
        this.B = b;
        this.slotId = c;
        YM(this, d);
        this.j = Y(this, e)
    };
    _.T(tx, Z);
    tx.prototype.g = function() {
        var a = this;
        this.slotId.listen(Ft, function(b) {
            b = b.detail.data;
            try {
                var c = JSON.parse(b);
                if (c.googMsgType === "gpi-uoo") {
                    var d = c.userOptOut;
                    var e = c.clearAdsData;
                    var f = a.j.value,
                        g = new $C;
                    var h = _.tj(g, 1, d ? "1" : "0");
                    var l = _.tj(_.Dm(h, 2, 2147483647), 3, "/");
                    var k = _.tj(l, 4, a.B.location.hostname);
                    var m = new _.PL(a.B);
                    QL(m, "__gpi_opt_out", k, f);
                    if (d || e) RL(m, "__gads", f), RL(m, "__gpi", f)
                }
            } catch (n) {}
        })
    };
    var US = function(a, b, c, d) {
        Z.call(this, a, 944);
        this.B = b;
        this.j = c;
        this.A = Y(this, d)
    };
    _.T(US, Z);
    US.prototype.g = function() {
        var a = this.A.value;
        if (this.j.isSupported(a)) {
            var b = _.gp(this.j, "__gpi_opt_out", a);
            if (b) {
                var c = new $C;
                b = _.tj(c, 1, b);
                b = _.tj(_.Dm(b, 2, 2147483647), 3, "/");
                b = _.tj(b, 4, this.B.location.hostname);
                QL(this.j, "__gpi_opt_out", b, a)
            }
        }
    };
    var VS = Sj(821, function(a, b, c) {
        if (!vi(b)) return {};
        var d = new _.z.Set;
        a = _.ul(a.ec, $C, 14, _.wl());
        a = _.y(a);
        for (var e = a.next(); !e.done; e = a.next()) {
            e = e.value;
            var f = void 0,
                g = (f = JA(e, 5)) != null ? f : 1;
            d.has(g) || (QL(c, g === 2 ? "__gpi" : "__gads", e, b), d.add(g))
        }
        return {}
    }, {});
    var XS = function() {
            this.o = [];
            this.hostpageLibraryTokens = [];
            this.g = {}
        },
        jw = function(a, b) {
            var c, d;
            a = (d = (c = a.g[b]) == null ? void 0 : _.w(c, "values").call(c)) != null ? d : [];
            return [].concat(_.Zk(a))
        };
    var $S = Sj(822, function(a, b, c) {
        a = _.DA(a.ec, 23);
        a = _.y(a);
        for (var d = a.next(); !d.done; d = a.next()) {
            d = d.value;
            var e = c;
            if (!_.w(e.o, "includes").call(e.o, d) && (_.E = [1, 2, 3], _.w(_.E, "includes")).call(_.E, d)) {
                var f = VL[d];
                if (f) {
                    var g = d + "_hostpage_library";
                    if (f = _.Cr(document, f)) f.id = g
                }
                e.o.push(d);
                g = new WL(d);
                e.hostpageLibraryTokens.push(g);
                e = Sp();
                e.hostpageLibraryTokens || (e.hostpageLibraryTokens = {});
                e.hostpageLibraryTokens[g.g] = g.o
            }
            e = void 0;
            g = c;
            f = b;
            g.g[d] = (e = g.g[d]) != null ? e : new _.z.Set;
            g.g[d].add(f)
        }
        return {}
    }, {});
    var mt = 0;
    var Tx = function(a, b, c, d, e, f) {
        Z.call(this, a, 721);
        this.B = b;
        this.Ef = c;
        this.A = Y(this, d);
        this.j = Y(this, e);
        this.C = Y(this, f)
    };
    _.T(Tx, Z);
    Tx.prototype.g = function() {
        var a = this,
            b, c, d = (b = this.Ef) == null ? void 0 : (c = _.t(b, 1)) == null ? void 0 : c.toUpperCase(),
            e, f;
        b = (e = this.Ef) == null ? void 0 : (f = _.t(e, 2)) == null ? void 0 : f.toUpperCase();
        if (d && b) {
            e = this.A.value;
            f = this.j.value;
            var g = this.C.value,
                h = g.style.height,
                l = g.style.width,
                k = g.style.display,
                m = g.style.position,
                n = qt(e.id + "_top", d),
                p = qt(e.id + "_bottom", b);
            _.ds(p, {
                position: "relative",
                top: "calc(100vh - 48px)"
            });
            g.appendChild(n);
            g.appendChild(p);
            _.ds(f, {
                position: "absolute",
                top: "24px",
                clip: "rect(0, auto, auto, 0)",
                width: "100vw",
                height: "calc(100vh - 48px)"
            });
            _.ds(e, {
                position: "fixed",
                top: "0",
                height: "100vh"
            });
            var r;
            _.ds(g, {
                position: "relative",
                display: ((r = this.B.screen.orientation) == null ? 0 : r.angle) ? "none" : "block",
                width: "100vw",
                height: "100vh"
            });
            pt(this, 722, this.B, "orientationchange", function() {
                var v;
                ((v = a.B.screen.orientation) == null ? 0 : v.angle) ? _.ds(g, {
                    display: "none"
                }): _.ds(g, {
                    display: "block"
                })
            });
            _.$q(this, function() {
                _.LE(n);
                _.LE(p);
                g.style.position = m;
                g.style.height = h;
                g.style.width = l;
                g.style.display = k
            })
        }
    };
    var eT = Ny(["https://td.doubleclick.net/td/kb?kbli=", ""]),
        px = function(a, b, c, d, e) {
            Z.call(this, a, 1007);
            this.yh = b;
            this.j = Y(this, d);
            c && (this.A = Y(this, c));
            e && YM(this, e)
        };
    _.T(px, Z);
    px.prototype.g = function() {
        if (vi(this.j.value)) {
            var a;
            if ((a = this.A) == null || !a.value) {
                var b = this.yh;
                if (b.length && document.getElementById("koelBirdIGRegisterIframe") === null) {
                    a = document.createElement("iframe");
                    b = Ja(eT, encodeURIComponent(b.join()));
                    a.removeAttribute("srcdoc");
                    if (b instanceof _.ya) throw new Hz("TrustedResourceUrl", 2);
                    var c = "allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-storage-access-by-user-activation".split(" ");
                    a.setAttribute("sandbox", "");
                    for (var d = 0; d < c.length; d++) a.sandbox.supports && !a.sandbox.supports(c[d]) || a.sandbox.add(c[d]);
                    b = _.Ma(b);
                    b !== void 0 && (a.src = b);
                    a.id = "koelBirdIGRegisterIframe";
                    document.head.appendChild(a)
                }
            }
        }
    };
    var lT = Pj(664, function(a, b, c, d, e, f) {
        var g, h, l, k, m, n, p;
        return _.ug(function(r) {
            h = (g = a.ye) != null ? g : 0;
            l = a;
            k = l.jg;
            m = (0, _.Lq)() !== 0 || h > 0;
            if (!m) return r.return(_.z.Promise.resolve());
            n = fM(document);
            p = gM(document) && n && tt(b, c, d, k);
            return r.return(new _.z.Promise(function(v) {
                if (p && n) var u = ot(e, f, 324, document, n, function() {
                    gM(document) || (u && u(), v())
                });
                else v()
            }))
        })
    });
    var mT = Pj(666, function(a, b, c, d) {
        d = d === void 0 ? ut : d;
        var e, f, g;
        return _.ug(function(h) {
            e = a;
            f = e.cp;
            g = e.rb;
            return f == null || f < 0 || !zo(g) ? h.return(_.z.Promise.resolve()) : h.return(new _.z.Promise(function(l) {
                var k = d(f, on(b, 291, function(m, n) {
                    m = _.y(m);
                    for (var p = m.next(); !p.done; p = m.next())
                        if (p = p.value, !(p.intersectionRatio <= 0)) {
                            n.unobserve(p.target);
                            l();
                            break
                        }
                }));
                k ? (_.$q(c, function() {
                    k.disconnect()
                }), k.observe(g)) : l()
            }))
        })
    });
    var oT = Sj(1176, function(a, b, c, d) {
        a = b != null ? b : new DQ;
        return (a = xt(a, 2) != null ? yt(a, 3) != null && (0, _.Lq)() !== 0 ? xt(a, 2) * yt(a, 3) : xt(a, 2) : null) && (_.E = [8, 9], _.w(_.E, "includes")).call(_.E, Wp(c)) ? (Q(d, oQ()), {
            ye: null
        }) : {
            ye: a
        }
    }, {
        ye: void 0
    });
    var pT = Sj(676, function(a) {
        return {
            jg: jo(a.measuringElement)
        }
    }, {
        jg: void 0
    });
    var jx = function(a, b, c, d, e, f, g, h, l) {
        L.call(this, a.S, 23);
        d = this.g(oT, {}, _.Fi(d, DQ, 5), e, f).ye;
        e = this.g(pT, {
            measuringElement: h
        }).jg;
        b = this.l(lT, {
            jg: e,
            ye: d
        }, b, c, g, a, this);
        l && At(b, l);
        a = At(this.l(mT, {
            rb: h,
            cp: d
        }, a, this), b.complete);
        l && At(a, l);
        this.A = a.complete
    };
    _.T(jx, L);
    var zt = Pj(886, function(a, b, c, d, e, f) {
        a = f != null ? f : _.z.globalThis.IntersectionObserver;
        return !a || b.some(function(g) {
            return !zo(vo(g))
        }) ? _.z.Promise.resolve() : wt(b, d, c, e, a)
    });
    var Mx = Sj(1271, function(a, b, c, d) {
        a = _.K(Ix);
        var e = _.K(AJ);
        b = b.va.La.Ma.hb.Kj;
        d.pubads().clear([c.Ba]);
        b.Bm.ta({
            wa: 1,
            Ph: a,
            ie: e
        });
        return {}
    }, {});
    var Nx = Pj(1274, function(a, b) {
        var c = new _.Aj;
        a = document.getElementById(b.getDomId());
        if (!a) return c.promise;
        var d = new IntersectionObserver(function(e) {
            e = _.y(e);
            for (var f = e.next(); !f.done; f = e.next()) f.value.isIntersecting && (c.resolve(), d.disconnect())
        });
        d.observe(a);
        return c.promise
    });
    var Kx = Pj(1273, function(a, b) {
        var c = _.K(Ix),
            d = _.K(AJ),
            e = new _.Aj,
            f, g = new IntersectionObserver(function(h) {
                h = _.y(h);
                for (var l = h.next(); !l.done; l = h.next()) l.value.isIntersecting ? (clearTimeout(f), f = 0) : f || (f = setTimeout(function() {
                    g.disconnect();
                    a.Kc && e.resolve()
                }, d))
            }, {
                rootMargin: c * 100 + "%"
            });
        g.observe(a.Kc);
        _.$q(b, function() {
            clearTimeout(f);
            g.disconnect()
        });
        return e.promise
    });
    var Ox = Sj(1275, function(a, b) {
        a = _.K(Ix);
        var c = _.K(AJ);
        b.va.La.Ma.hb.Kj.Cm.ta({
            wa: 1,
            Ph: a,
            ie: c
        });
        return {}
    }, {});
    var rT = function(a, b, c) {
        Z.call(this, a, 1163);
        _.I(ux);
        this.j = Y(this, b);
        c && YM(this, c)
    };
    _.T(rT, Z);
    rT.prototype.g = function() {
        this.j.value.Yl();
        this.j.value.Wa()
    };
    var wx = function(a, b, c, d, e, f, g, h, l, k, m) {
        Z.call(this, a, 682);
        this.L = b;
        this.format = c;
        this.slotId = d;
        this.B = e;
        this.gb = f;
        this.j = X(this);
        this.A = Y(this, g);
        this.G = Y(this, h);
        this.C = WM(this, l);
        this.Ue = Y(this, k);
        this.I = WM(this, m)
    };
    _.T(wx, Z);
    wx.prototype.g = function() {
        var a = this,
            b;
        if ((b = this.gb) != null && _.R(b, 12, !1)) {
            b = this.C.value.rn;
            var c = _.Qv(this.L, this.slotId),
                d = this.G.value,
                e = this.A.value,
                f = this.I.value,
                g, h = (g = this.gb) == null ? void 0 : _.Fi(g, LC, 16);
            _.ds(e, {
                "max-height": h ? "none" : "30vh",
                overflow: "hidden"
            });
            if (tT) tT.Tl(e, this.Ue.value, _.Dt(h));
            else {
                tT = new b(this.context, this.format, e, this.B, d, this.L, this.slotId, f, h);
                g = {};
                b = _.y(_.ul(this.gb, KC, 13, _.wl()));
                for (d = b.next(); !d.done; d = b.next()) d = d.value, g[xl(d, 1)] = xl(d, 2);
                tT.Xl(g);
                _.I(ux) ? (tT.Ul(), this.j.H(tT)) : tT.Wa();
                ZO(this.L, this.slotId, function() {
                    tT && (tT.dispose(), tT = null);
                    c && _.bP(a.L, a.slotId)
                })
            }
            _.$q(this, function() {
                return _.LE(e)
            })
        }
    };
    var tT = null;
    var vx = function(a, b, c, d, e, f, g, h, l, k, m) {
        Z.call(this, a, 1155);
        this.L = b;
        this.format = c;
        this.slotId = d;
        this.B = e;
        this.gb = f;
        this.Fa = g;
        this.A = h;
        this.j = l;
        this.G = k;
        this.C = m
    };
    _.T(vx, Z);
    vx.prototype.g = function() {
        var a = this,
            b;
        if ((b = this.gb) != null && dp(b, 12)) {
            var c = new L(this.context.S, 26);
            _.Sq(this, c);
            var d, e = !((d = this.gb) == null || !_.R(d, 15));
            b = function() {
                if (e) return (new Et(a.slotId, Ft, c, function(f) {
                    f = f.detail.data;
                    try {
                        var g = JSON.parse(f);
                        return g.type === "floating" && g.message === "loaded"
                    } catch (h) {}
                    return !1
                })).output
            }();
            d = new wx(this.context, this.L, this.format, this.slotId, this.B, this.gb, this.Fa, this.A, this.j, this.G, this.C);
            M(c, d);
            b = new rT(this.context, d.j, b);
            M(c, b);
            c.run()
        }
    };
    var Lt = function(a, b, c) {
        Z.call(this, a, 1150);
        this.B = b;
        this.output = VM(this);
        YM(this, c)
    };
    _.T(Lt, Z);
    Lt.prototype.g = function() {
        var a = this;
        this.B.location.hash = "goog_game_inter";
        _.$q(this, function() {
            "goog_game_inter" === a.B.location.hash && (a.B.location.hash = "")
        });
        OM(this.output, new _.z.Promise(function(b) {
            return void pt(a, a.id, a.B, "hashchange", function(c) {
                uz(c.oldURL, "#goog_game_inter") && b()
            })
        }))
    };
    var vT = function(a, b) {
            this.serviceName = b;
            this.slot = a.Ba
        },
        wT = function(a, b) {
            vT.call(this, a, b);
            this.isEmpty = !1;
            this.slotContentChanged = !0;
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.labelIds = this.creativeTemplateId = this.creativeId = this.campaignId = this.advertiserId = this.size = null;
            this.isBackfill = !1;
            this.vast = this.companyIds = this.yieldGroupIds = null
        };
    _.T(wT, vT);
    var zT = function() {
        vT.apply(this, arguments)
    };
    _.T(zT, vT);
    var AT = function(a, b, c) {
        vT.call(this, a, b);
        this.inViewPercentage = c
    };
    _.T(AT, vT);
    var BT = function() {
        vT.apply(this, arguments)
    };
    _.T(BT, vT);
    var CT = function() {
        vT.apply(this, arguments)
    };
    _.T(CT, vT);
    var DT = function() {
        vT.apply(this, arguments)
    };
    _.T(DT, vT);
    var ET = function() {
        vT.apply(this, arguments)
    };
    _.T(ET, vT);
    var FT = function(a, b, c, d) {
        vT.call(this, a, b);
        this.makeRewardedVisible = c;
        this.payload = d
    };
    _.T(FT, vT);
    var GT = function(a, b, c) {
        vT.call(this, a, b);
        this.payload = c
    };
    _.T(GT, vT);
    var HT = function() {
        vT.apply(this, arguments)
    };
    _.T(HT, vT);
    var IT = function(a, b, c) {
        vT.call(this, a, b);
        this.makeGameManualInterstitialVisible = c
    };
    _.T(IT, vT);
    var JT = function() {
        vT.apply(this, arguments)
    };
    _.T(JT, vT);
    var Nt = function(a, b, c, d, e) {
        Z.call(this, a, 1151);
        this.slotId = b;
        this.Ha = c;
        YM(this, d);
        YM(this, e)
    };
    _.T(Nt, Z);
    Nt.prototype.g = function() {
        this.Ha.dispatchEvent("gameManualInterstitialSlotClosed", 1148, new JT(this.slotId, "publisher_ads"))
    };
    var Jt = function(a, b, c, d) {
        Z.call(this, a, 1149);
        this.slotId = b;
        this.Ha = c;
        this.output = VM(this);
        YM(this, d)
    };
    _.T(Jt, Z);
    Jt.prototype.g = function() {
        var a = new _.Aj,
            b = a.promise;
        this.Ha.dispatchEvent("gameManualInterstitialSlotReady", 1147, new IT(this.slotId, "publisher_ads", a.resolve));
        OM(this.output, b.then(function() {
            return vE(10)
        }))
    };
    var It = function(a, b, c) {
        c = c === void 0 ? KT : c;
        Z.call(this, a, 1158);
        this.j = c;
        this.A = _.K(Ht) * 1E3;
        this.output = VM(this);
        YM(this, b)
    };
    _.T(It, Z);
    It.prototype.g = function() {
        var a = this;
        this.j.Sf++ ? OM(this.output, vE(this.A * (this.j.Sf - 2) + (this.A - (Date.now() - this.j.Ah))).then(function() {
            a.j.Ah = Date.now();
            a.j.Sf--
        })) : (this.j.Ah = Date.now(), vE(this.A).then(function() {
            return void a.j.Sf--
        }), this.output.notify())
    };
    var KT = {
        Sf: 0,
        Ah: Date.now()
    };
    var LT = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        MT = {
            width: "100%",
            height: "100%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        Kt = function(a, b, c, d, e) {
            Z.call(this, a, 1150);
            this.B = b;
            this.j = Y(this, c);
            this.C = Y(this, d);
            YM(this, e);
            this.A = new _.gN(this.B)
        };
    _.T(Kt, Z);
    Kt.prototype.g = function() {
        var a = (0, _.Lq)() === 0 ? "rgba(1,1,1,0.5)" : "white";
        _.ds(this.j.value, _.w(Object, "assign").call(Object, {
            position: "absolute"
        }, (0, _.Lq)() === 0 ? MT : LT));
        _.ds(this.C.value, _.w(Object, "assign").call(Object, {
            "background-color": a,
            opacity: "1",
            position: "fixed",
            margin: "0",
            padding: "0",
            "z-index": "2147483647",
            display: "block"
        }, LT));
        _.$q(this, _.vk(this.B.document, this.B));
        a = {};
        NE(this.j.value).postMessage(JSON.stringify((a.googMsgType = "sth", a.msg_type = "i-view", a)), "*");
        if (this.B === this.B.top) {
            var b = _.iN(this.A, 2147483646);
            _.lN(b);
            _.$q(this, function() {
                return void _.mN(b)
            })
        }
    };
    var NT = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 683);
        this.slotId = b;
        this.R = c;
        this.j = d;
        this.A = X(this);
        this.C = Y(this, e);
        this.U = Y(this, f);
        this.G = WM(this, g);
        this.I = WM(this, h);
        this.context.O.log(578856259, _.Kk, {
            pvsid: this.context.pvsid,
            documentUrl: this.context.documentUrl,
            kb: 17,
            Ub: this.context.Ra,
            P: 7
        })
    };
    _.T(NT, Z);
    NT.prototype.g = function() {
        var a = this;
        this.context.O.log(578856259, _.Kk, {
            pvsid: this.context.pvsid,
            documentUrl: this.context.documentUrl,
            kb: 17,
            Ub: this.context.Ra,
            P: 8
        });
        var b = this.U.value,
            c = this.C.value,
            d = this.I.value.Tn,
            e = new _.mn(this.context),
            f = Xn(this.j, 14) != null ? Ov(this.j, 14) * 60 : 604800;
        b = new d(this.context, window, c, b, e, this.R, OT(this), new _.z.Set(_.DA(this.j, 15)), jR(this.slotId), function() {
            return void a.dispose()
        }, function() {
            Pt(a.context, {
                Ta: 1,
                payload: function() {
                    var g = new zq,
                        h = _.Aq(g, XG, 5, Cq),
                        l = _.xk();
                    _.Dq(h, 1, l);
                    return g
                }
            });
            a.dispose()
        }, f, this.G.value);
        b.R();
        _.Sq(this, b);
        this.A.H(b);
        this.context.O.log(578856259, _.Kk, {
            pvsid: this.context.pvsid,
            documentUrl: this.context.documentUrl,
            kb: 17,
            Ub: this.context.Ra,
            P: 9
        })
    };
    var OT = function(a) {
        var b = {};
        a = _.ul(a.j, KC, 13, _.wl());
        a = _.y(a);
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, b[xl(c, 1)] = xl(c, 2);
        return b
    };
    var PT = function(a, b, c, d) {
        Z.call(this, a, 1210);
        this.action = b;
        this.j = WM(this, c);
        YM(this, d)
    };
    _.T(PT, Z);
    PT.prototype.g = function() {
        var a;
        (a = this.j.value) != null && a.qb() && this.action()
    };
    var QT = function(a, b, c) {
        Z.call(this, a, 1121);
        this.ga = b;
        this.output = VM(this);
        this.C = !1;
        this.G = Y(this, c)
    };
    _.T(QT, Z);
    QT.prototype.g = function() {
        var a = this;
        if (this.A = Qt(on(this.context, this.id, function(b) {
                b = _.y(b);
                for (var c = b.next(); !c.done; c = b.next()) c = c.value.intersectionRatio * 100, _.w(Number, "isFinite").call(Number, c) && c >= 50 ? a.j || (a.C = !0, gM(a.ga) || RT(a)) : (a.C = !1, ST(a))
            }))) _.$q(this, function() {
            var b;
            (b = a.A) == null || b.disconnect();
            ST(a)
        }), this.A.observe(this.G.value), this.I = pt(this, this.id, this.ga, "visibilitychange", function() {
            gM(a.ga) ? ST(a) : a.C && !a.j && RT(a)
        })
    };
    var RT = function(a) {
            a.j = setTimeout(function() {
                a.j = void 0;
                if (!gM(a.ga)) {
                    a.output.notify();
                    var b;
                    (b = a.A) == null || b.disconnect();
                    var c;
                    (c = a.I) == null || c.call(a)
                }
            }, 1E3)
        },
        ST = function(a) {
            clearTimeout(a.j);
            a.j = void 0
        };
    var xx = function(a, b, c, d, e, f, g, h, l, k, m) {
        m = m === void 0 ? function() {
            return _.xk()
        } : m;
        Z.call(this, a, 1141);
        this.slotId = b;
        this.G = c;
        this.j = d;
        this.ga = e;
        this.Fa = f;
        this.I = g;
        this.Sb = h;
        this.C = l;
        this.A = k;
        this.Ic = m;
        this.output = X(this)
    };
    _.T(xx, Z);
    xx.prototype.g = function() {
        var a = this;
        if (this.j) {
            var b = new L(this.context.S, 28);
            _.Sq(this, b);
            var c = new Ws;
            c.ha();
            c = M(b, new NT(this.context, this.slotId, this.G, this.j, this.Fa, this.I, _.I(Fq) ? c : this.Sb, this.C));
            _.$q(c, function() {
                return void a.dispose()
            });
            this.output.pb(c.A.promise.then(function() {
                return !0
            }));
            if (_.I(xJ) || _.K(yJ)) {
                var d = M(b, new QT(this.context, this.ga, this.Fa));
                _.K(yJ) && M(b, new PT(this.context, function() {
                    Pt(a.context, {
                        Ta: _.K(yJ),
                        payload: function() {
                            var e = new VG,
                                f = a.Ic();
                            f !== null && _.Dq(e, 1, f);
                            return eH(e)
                        }
                    })
                }, c.A, d.output));
                _.I(xJ) && M(b, new PT(this.context, function() {
                    Pt(a.context, {
                        Ta: 1,
                        payload: function() {
                            var e = new VG,
                                f = a.Ic();
                            f !== null && _.Dq(e, 1, f);
                            _.Dl(e, 2, !0);
                            return eH(e)
                        }
                    });
                    a.A()
                }, c.A, d.output))
            }
            b.run()
        } else this.output.H(!1)
    };
    var ox = Pj(846, function(a, b, c, d, e) {
        var f, g, h;
        return _.ug(function(l) {
            g = (c === 2 || c === 3) && !((f = d) == null || !_.R(f, 12, !1));
            h = c === 5 && e;
            return g || h ? l.return(b.load(_.oR)) : l.return(null)
        })
    });
    var TT = function(a, b, c, d, e) {
        Z.call(this, a, 905);
        this.K = b;
        this.Tb = c;
        this.output = VM(this);
        this.j = Y(this, d);
        YM(this, e)
    };
    _.T(TT, Z);
    TT.prototype.g = function() {
        for (var a = _.y(this.j.value), b = a.next(); !b.done; b = a.next()) {
            var c = void 0;
            b = (c = this.K.W[b.value.getDomId()]) == null ? void 0 : Wp(c);
            if (b === 2 || b === 3 || b === 5) {
                this.Tb.load(_.oR);
                return
            }
        }
        this.output.notify()
    };
    var UT = function(a, b, c, d, e) {
        Z.call(this, a, 696);
        this.slotId = b;
        this.Ha = c;
        YM(this, d);
        YM(this, e)
    };
    _.T(UT, Z);
    UT.prototype.g = function() {
        this.Ha.dispatchEvent("rewardedSlotClosed", 703, new HT(this.slotId, "publisher_ads"))
    };
    var VT = function(a, b, c, d, e) {
        Z.call(this, a, 694);
        this.slotId = b;
        this.Ha = c;
        YM(this, d);
        this.j = WM(this, e)
    };
    _.T(VT, Z);
    VT.prototype.g = function() {
        var a, b = (a = this.j.value) == null ? void 0 : a.payload;
        this.Ha.dispatchEvent("rewardedSlotGranted", 702, new GT(this.slotId, "publisher_ads", b != null ? b : null))
    };
    var WT = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        XT = function(a, b, c, d, e, f) {
            Z.call(this, a, 693);
            this.B = b;
            this.output = VM(this);
            this.A = Y(this, c);
            this.C = Y(this, d);
            this.G = Y(this, f);
            YM(this, e);
            this.j = new _.gN(this.B)
        };
    _.T(XT, Z);
    XT.prototype.g = function() {
        var a = this;
        if (!this.G.value) {
            var b = (0, _.Lq)() === 0 ? "rgba(1,1,1,0.5)" : "white";
            _.ds(this.C.value, _.w(Object, "assign").call(Object, {
                "background-color": b,
                opacity: "1",
                position: "fixed",
                margin: "0",
                padding: "0",
                "z-index": "2147483647",
                display: "block"
            }, WT));
            _.$q(this, _.vk(this.B.document, this.B));
            NE(this.A.value).postMessage(JSON.stringify({
                type: "rewarded",
                message: "visible"
            }), "*");
            if (this.B === this.B.top) {
                this.B.location.hash = "goog_rewarded";
                var c = _.iN(this.j, 2147483646);
                _.lN(c);
                _.$q(this, function() {
                    _.mN(c);
                    "goog_rewarded" === a.B.location.hash && (a.B.location.hash = "")
                })
            }
            this.output.notify()
        }
    };
    var YT = function(a, b, c, d) {
        Z.call(this, a, 695);
        this.B = b;
        this.j = Y(this, c);
        YM(this, d)
    };
    _.T(YT, Z);
    YT.prototype.g = function() {
        if (this.B === this.B.top) var a = NE(this.j.value),
            b = pt(this, 503, this.B, "hashchange", function(c) {
                uz(c.oldURL, "#goog_rewarded") && (a.postMessage(JSON.stringify({
                    type: "rewarded",
                    message: "back_button"
                }), "*"), b())
            })
    };
    var ZT = function(a, b, c, d) {
        Z.call(this, a, 692);
        this.slotId = b;
        this.Ha = c;
        this.output = VM(this);
        this.j = X(this);
        this.A = WM(this, d)
    };
    _.T(ZT, Z);
    ZT.prototype.g = function() {
        var a = this.A.value;
        if (a) {
            var b = new _.Aj,
                c = b.promise,
                d;
            this.Ha.dispatchEvent("rewardedSlotReady", 701, new FT(this.slotId, "publisher_ads", N(this.context, 1235, b.resolve), (d = a.payload) != null ? d : null));
            this.j.H(_.wk());
            OM(this.output, c)
        }
    };
    var $T = Sj(1237, function(a, b) {
        Ut(b.context, b.adUnitPath, a.Vo);
        return {}
    }, {});
    var aU = Sj(691, function(a) {
        if (a.message.message === "ha_before_make_visible") return {
            oi: null,
            nh: !0
        };
        _.ds(a.Fd, {
            position: "absolute",
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        });
        return {
            oi: a.message,
            nh: !1
        }
    }, {
        oi: void 0,
        nh: void 0
    });
    var yx = function(a, b, c, d, e, f) {
        L.call(this, a.S, 29);
        var g = Wt(b, "granted", this),
            h = Wt(b, "prefetched", this),
            l = Wt(b, "closed", this),
            k = Wt(b, "ha_before_make_visible", this);
        h = this.g(aU, {
            Fd: e,
            message: new Mt([h.output, k.output])
        }, {});
        var m = h.nh;
        h = new ZT(a, b, c, h.oi);
        M(this, h);
        f = new XT(a, d, e, f, h.output, m);
        M(this, f);
        M(this, new YT(a, d, e, f.output));
        M(this, new VT(a, b, c, h.output, g.output));
        d = new Mt([l.output, k.output]);
        M(this, new UT(a, b, c, h.output, d));
        _.K(FJ) && At(this.g($T, {
            Vo: h.j
        }, {
            context: a,
            adUnitPath: b.getAdUnitPath()
        }), h.output)
    };
    _.T(yx, L);
    var bU = [2, 3, 8, 9, 5],
        Mw = Sj(1242, function(a, b) {
            a = b.context;
            b = b.B;
            for (var c = _.y(bU), d = c.next(); !d.done; d = c.next()) {
                d = d.value;
                var e = Rq(d, b, !0, !1);
                e !== null && Yt(a, e, d)
            }
            return {}
        }, {});
    var $t = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
    var cU = qc({
            paw_id: wc,
            signal: wc,
            error: sc(wc),
            eids: sc(xc()),
            sdk_ttl_ms: sc(yc)
        }),
        dU = function(a, b, c, d, e) {
            b = b === void 0 ? new _.z.Set : b;
            c = c === void 0 ? null : c;
            d = d === void 0 ? null : d;
            e = e === void 0 ? null : e;
            _.W.call(this);
            this.B = a;
            this.ports = b;
            this.g = c;
            this.j = d;
            this.l = e
        };
    _.T(dU, _.W);
    dU.prototype.o = function() {
        _.W.prototype.o.call(this);
        eU(this);
        for (var a = _.y(this.ports), b = a.next(); !b.done; b = a.next()) b = b.value, this.ports.delete(b), b.onmessage = null
    };
    var fU = function(a, b, c) {
            b.onmessage = c;
            a.ports.add(b)
        },
        eU = function(a) {
            a.g !== null && (_.Gh(a.B, "message", a.g), a.g = null)
        },
        gU = function(a, b) {
            fU(a, b, function(c) {
                a: {
                    try {
                        var d = JSON.parse(c.data);
                        if (cU(d)) {
                            var e = d;
                            break a
                        }
                    } catch (g) {}
                    e = void 0
                }
                if (c = e) {
                    if (a.j === null) {
                        e = _.y(a.ports);
                        for (d = e.next(); !d.done; d = e.next()) d = d.value, d !== b && (a.ports.delete(d), d.onmessage = null);
                        eU(a);
                        a.j = b
                    }
                    var f;
                    (f = a.l) == null || f.resolve(c);
                    a.l = null
                }
            });
            au(b)
        },
        hU = function(a) {
            if (a.l) return a.l.promise;
            if (a.g !== null) throw Error("a poll message listener is already registered");
            a.l = new _.Aj;
            a.j === null ? (a.g = function(b) {
                b = b.data != null && b.data !== "" || b.origin.indexOf("android-app://") !== 0 ? void 0 : b.ports[0];
                b && gU(a, b)
            }, _.sg(a.B, "message", a.g)) : au(a.j);
            return a.l.promise
        };
    var mw = function(a, b, c, d) {
        c = c === void 0 ? Ej : c;
        d = d === void 0 ? new dU(b) : d;
        Z.call(this, a, 1063);
        this.B = b;
        this.G = c;
        this.C = d;
        this.A = X(this);
        this.Jc = X(this);
        this.Sd = X(this);
        this.j = !1;
        _.Sq(this, d)
    };
    _.T(mw, Z);
    mw.prototype.g = function() {
        var a = this;
        if (_.I(sJ)) {
            if (_.I(qJ)) {
                var b = Ij(this.B);
                b ? this.Sd.H(b) : this.Sd.ha()
            } else this.Sd.ha();
            this.j = Fj(this.B);
            var c = !this.j && _.I(oJ) && _.Vn(264) ? hU(this.C) : void 0,
                d = null,
                e = 0,
                f = 0,
                g = function() {
                    if (!_.I(oJ) || !_.Vn(264)) {
                        var k, m;
                        return (m = (k = a.G(a.B)) == null ? void 0 : k.then(function(n) {
                            var p;
                            f = (p = n.sdk_ttl_ms) != null ? p : 0;
                            return n.signal
                        })) != null ? m : null
                    }
                    return c ? c.then(function(n) {
                        c = void 0;
                        return n.signal
                    }) : hU(a.C).then(function(n) {
                        return n.signal
                    })
                },
                h = on(this.context, this.id, function() {
                    var k, m, n, p, r, v;
                    return _.ug(function(u) {
                        switch (u.g) {
                            case 1:
                                return k = "0", u.l = 2, u.yield(g(), 4);
                            case 4:
                                m = u.o;
                                k = (n = m) != null ? n : "0";
                                k.length > 1E4 && (qn(a.context, a.id, new HL("ML:" + k.length)), k = "0");
                                u.g = 3;
                                u.l = 0;
                                break;
                            case 2:
                                p = wg(u), qn(a.context, a.id, p);
                            case 3:
                                _.I(pJ) ? (v = Math.max(3E5 - f, 5E3), r = _.wk(a.B) + v) : r = _.wk(a.B) + 3E5, d = k, e = r, u.g = 0
                        }
                    })
                });
            if (!_.I(oJ) || this.j) var l = (_.E = h(), _.w(_.E, "finally")).call(_.E, function() {
                l = void 0
            });
            this.A.H(function() {
                var k, m, n;
                return _.ug(function(p) {
                    if (p.g == 1) {
                        k = _.I(oJ) && _.Vn(264);
                        if (!a.j && !k) return p.return("");
                        m = _.wk(a.B) >= e;
                        n = d === null || d === "0";
                        if (!m && !n) {
                            p.g = 2;
                            return
                        }
                        l || (l = (_.E = h(), _.w(_.E, "finally")).call(_.E, function() {
                            l = void 0
                        }));
                        return p.yield(l, 2)
                    }
                    return p.return(d)
                })
            });
            this.j ? this.Jc.H("WEBVIEW_SDK_PAW") : this.Jc.H("WEBVIEW_SDK_PACT")
        } else this.A.H(function() {
            return _.z.Promise.resolve("")
        }), this.Jc.H("WEBVIEW_SDK_UNKNOWN")
    };
    mw.prototype.l = function() {
        this.A.H(function() {
            return _.z.Promise.resolve("")
        });
        this.j ? this.Jc.H("WEBVIEW_SDK_PAW") : this.Jc.H("WEBVIEW_SDK_PACT")
    };
    var iU = function(a, b) {
        Z.call(this, a, 1091);
        this.output = X(this);
        b && (this.j = WM(this, b))
    };
    _.T(iU, Z);
    iU.prototype.g = function() {
        var a;
        (a = this.j) != null && a.value ? this.output.pb(this.j.value()) : this.output.H("")
    };
    iU.prototype.l = function() {
        this.output.H("")
    };
    var bu = new _.z.Map([
            ["IAB_AUDIENCE_1_1", 3],
            ["IAB_CONTENT_2_2", 5],
            ["IAB_CONTENT_3_0", 6]
        ]),
        du = new _.z.Map([
            [1, 3],
            [2, 4],
            [3, 5]
        ]);
    var jU = _.$f(HQ);
    var nu = new _.z.Set(["disablePersonalization"]);
    var ru = function(a, b, c) {
        Z.call(this, a, 1122);
        this.ga = b;
        this.j = c;
        VM(this, c)
    };
    _.T(ru, Z);
    ru.prototype.g = function() {
        var a = this,
            b = kn(this.context);
        OM(this.j, new _.z.Promise(function(c) {
            return void iM(function() {
                c();
                b()
            }, a.ga)
        }))
    };
    var nw = function(a, b) {
        Z.call(this, a, 1107);
        this.B = b;
        this.output = X(this)
    };
    _.T(nw, Z);
    nw.prototype.g = function() {
        var a = Xi(this.B.isSecureContext, this.B.navigator, this.B.document),
            b = Yi(this.B.isSecureContext, this.B.document),
            c = Zi(this.B.isSecureContext, this.B, this.B.document),
            d = !(!this.B.isSecureContext || !Vi("attribution-reporting", this.B.document)),
            e = 0;
        a && (e |= 1);
        b && (e |= 4);
        c && (e |= 8);
        d && (e |= 2);
        this.output.ic(e === 0 ? null : e)
    };
    nw.prototype.l = function() {
        this.output.ha()
    };
    var kU = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1118, _.K(JJ));
        this.C = b;
        this.I = e;
        this.K = f;
        X(this, e);
        c && (this.R = WM(this, c));
        d && (this.G = WM(this, d));
        g && (this.A = Y(this, g));
        h && (this.j = XM(this, h))
    };
    _.T(kU, Z);
    kU.prototype.g = function() {
        var a = new DM;
        a = _.We(a, 1, _.ad(this.C), 0);
        if (this.j)
            if (this.j.value) {
                var b = _.Ek(a, 3, this.j.value.label);
                _.H(b, 4, this.j.value.status)
            } else this.j.Qd() || _.H(a, 4, 5);
        if (this.C & 1) {
            var c, d;
            b = lU(this, (c = this.R) == null ? void 0 : c.value, (d = this.G) == null ? void 0 : d.value);
            _.Wg(a, 2, b)
        }
        this.I.H(a)
    };
    var lU = function(a, b, c) {
            var d = new CM;
            b == null || b.forEach(function(g, h) {
                if (g.length) {
                    var l = BM(new AM, g),
                        k;
                    (k = c == null ? void 0 : c.get(h)) == null || k.forEach(function(m, n) {
                        var p = new xM;
                        m = _.We(p, 2, _.ad(m), 0);
                        n = _.We(m, 1, _.ad(_.aj(n)), 0);
                        Fl(l, 2, xM, n)
                    });
                    Re(d, 2, AM).set(h, l)
                }
            });
            var e;
            if (((e = a.A) == null ? 0 : e.value) && a.K.W) {
                var f;
                b = _.y((f = a.A) == null ? void 0 : f.value);
                for (f = b.next(); !f.done; f = b.next()) f = f.value, (e = mU(a, f)) && Re(d, 3, yM).set(f.getAdUnitPath(), e)
            }
            navigator.deprecatedRunAdAuctionEnforcesKAnonymity && _.Ek(d, 4, "deprecated_kanon");
            return d
        },
        mU = function(a, b) {
            var c, d;
            a = (d = (c = a.K.Bd) == null ? void 0 : c[b.getDomId()]) != null ? d : [];
            if (a.length !== 0) return zM(new yM, a.map(function(e) {
                return e.seller
            }))
        };
    var tu = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1165);
        this.I = c;
        this.G = d;
        this.Wf = e;
        this.K = f;
        this.C = g;
        this.A = h;
        this.j = WM(this, b.Qo)
    };
    _.T(tu, Z);
    tu.prototype.g = function() {
        if (this.j.value) {
            var a = new L(this.context.S, 33),
                b = new kU(this.context, this.j.value, this.I, this.G, this.Wf.pi, this.K, this.C, this.A);
            M(a, b);
            a.run()
        } else this.Wf.pi.ha()
    };
    var Iw = function(a, b, c) {
        Z.call(this, a, 1206);
        this.A = b;
        this.j = X(this);
        this.ba = Y(this, c)
    };
    _.T(Iw, Z);
    Iw.prototype.g = function() {
        var a = this;
        this.A.cookieDeprecationLabel ? vi(this.ba.value) ? this.j.pb(this.A.cookieDeprecationLabel.getValue().then(function(b) {
            return {
                status: 1,
                label: b
            }
        }).catch(function(b) {
            a.reportError(b);
            return {
                status: 2
            }
        })) : this.j.H({
            status: 4
        }) : this.j.H({
            status: 3
        })
    };
    var nU = Sj(1213, function(a) {
        var b, c;
        return {
            vl: !((c = (b = a.Qg) == null ? void 0 : b.label) == null || !c.match(dj(IJ)))
        }
    }, {
        vl: void 0
    });
    var oU = Sj(1212, function(a) {
        var b;
        return (a = (b = a.Qg) == null ? void 0 : b.label) ? {
            Ei: !!a.match(dj(IJ)),
            Di: !0
        } : {
            Ei: !1,
            Di: !1
        }
    }, {
        Ei: void 0,
        Di: void 0
    });
    var pU = function(a, b, c) {
        Z.call(this, a, 873);
        this.B = b;
        this.j = Y(this, c)
    };
    _.T(pU, Z);
    pU.prototype.g = function() {
        var a = this.context,
            b = this.j.value,
            c = this.B;
        !Sp()._pubconsole_disable_ && (b = yi("google_pubconsole", b, c)) && (b = b.split("|"), b[0] !== "1" && b[0] !== "0" || tr(a, c))
    };
    var qU = function() {
            this.g = {}
        },
        sU = function(a, b) {
            var c = PQ();
            c = Yo(ol({
                version: RQ ? RQ : RQ = To(),
                lg: c
            }, b));
            var d;
            if (!(a.g[c.toString()] || ((d = Sp()) == null ? 0 : d.fifWin))) {
                a.g[c.toString()] = 1;
                var e = rU(b.document, c);
                e.addEventListener("load", function() {
                    e.remove()
                })
            }
        },
        rU = function(a, b) {
            var c = _.Fh("IFRAME");
            c.src = _.Aa(b).toString();
            c.style.visibility = "hidden";
            c.style.display = "none";
            a = a.getElementsByTagName("script");
            a.length && (a = a[a.length - 1], a.parentNode && a.parentNode.insertBefore(c, a.nextSibling));
            return c
        };
    var ex = Sj(669, function(a, b, c, d, e) {
        return a.Wn ? {
            output: !0
        } : {
            output: !!((d == null ? 0 : _.t(d, 1)) && (_.R(c, 12) || Yr(b, 13)) || e)
        }
    }, {
        output: void 0
    });
    var vu = "3rd party ad content";
    var tU = function(a, b, c) {
        _.W.call(this);
        this.context = a;
        this.ya = b;
        this.g = c;
        a = c.slotId;
        b = c.size;
        this.l = c.Zc === "height" ? "fluid" : [b.width, b.height];
        this.re = Co(a);
        this.se = vu
    };
    _.T(tU, _.W);
    tU.prototype.render = function() {
        var a = this.ya,
            b = this.g,
            c = b.slotId,
            d = b.K.W,
            e = b.size,
            f = b.lb,
            g = b.isBackfill,
            h = b.oc;
        fk(b.Da, _.nm(b.ga), f != null ? f : "", !1);
        Nv(_.Ri(po), "5", Ov(d[c.getDomId()], 20));
        c.dispatchEvent(Pv, 801, {
            Cj: a.kind === 0 ? a.nb : "",
            isBackfill: g
        });
        a = this.F();
        h && a && a.setAttribute("data-google-container-id", h);
        c.dispatchEvent(Rv, 825, {
            size: e,
            isEmpty: !1
        });
        return a
    };
    tU.prototype.loaded = function(a) {
        var b = this.g,
            c = b.slotId,
            d = b.Ha;
        b = b.K.W;
        c.dispatchEvent(Fx, 844, void 0);
        a && a.setAttribute("data-load-complete", !0);
        d.dispatchEvent("slotOnload", 710, new BT(c, "publisher_ads"));
        Nv(_.Ri(po), "6", Ov(b[c.getDomId()], 20))
    };
    var uU = function(a) {
        a = a.ya;
        if (a = a.kind === 0 ? a.nb : "") {
            var b = a.toLowerCase();
            a = b.indexOf("<!doctype") > -1 || b.indexOf("<html") > -1 ? a : "<!doctype html><html><head></head><body>" + a + "</body></html>"
        }
        return a
    };
    tU.prototype.o = function() {
        _.W.prototype.o.call(this);
        this.g.Da.removeAttribute("data-google-query-id")
    };
    tU.prototype.A = function(a) {
        var b = this,
            c = vU(this, function() {
                return void b.loaded(c.g)
            }, a);
        _.$q(this, function() {
            return void c.destroy()
        });
        return c
    };
    var vU = function(a, b, c) {
        var d = a.g,
            e = d.dl,
            f = d.isBackfill,
            g = d.oc,
            h = d.zf,
            l = d.zg,
            k = d.Ab,
            m;
        return new VN({
            ji: d.rb,
            re: a.re,
            se: a.se,
            content: uU(a),
            size: Array.isArray(a.l) ? new _.mo(Number(a.l[0]), Number(a.l[1])) : 1,
            Nk: b,
            el: e != null ? e : void 0,
            permissions: {
                wf: dp(c, 1) ? !!_.R(c, 1) : !f,
                xf: dp(c, 2) ? !!_.R(c, 2) : !1
            },
            te: !!Sp().fifWin,
            mp: RQ ? RQ : RQ = To(),
            ym: Xo(),
            hostpageLibraryTokens: k.hostpageLibraryTokens,
            Hb: function(n, p) {
                return void qn(a.context, n, p)
            },
            uniqueId: g,
            cl: PQ(),
            zf: h != null ? h : void 0,
            Fd: (m = a.g.K.lc) != null ? m : void 0,
            zg: l != null ? l : void 0,
            xk: !!a.g.K.lc
        })
    };
    var wU = function() {
        tU.apply(this, arguments)
    };
    _.T(wU, tU);
    wU.prototype.F = function() {
        var a = this.g,
            b = a.K,
            c = b.Z;
        a = b.W[a.slotId.getDomId()];
        b = new Zo;
        c = ep([b, c.bd(), a == null ? void 0 : a.bd()]);
        return tU.prototype.A.call(this, c).g
    };
    wU.prototype.j = function() {
        return !1
    };
    var xU = Sj(833, function(a, b) {
        sU(b.qd, b.B);
        return {}
    }, {});
    var yU = Sj(1135, function(a, b) {
        a = new kC;
        var c = new _.z.Map,
            d = new _.z.Set;
        b = _.y(b);
        for (var e = b.next(); !e.done; e = b.next()) {
            var f = e.value;
            if (_.yl(f, 1)) {
                e = new _.z.Set;
                c.set(_.t(f, 1).toString(), e);
                f = _.y(_.ul(f, iC, 2, _.wl()));
                for (var g = f.next(); !g.done; g = f.next()) {
                    g = g.value;
                    var h = _.t(g, 1);
                    e.add(h);
                    d.has(h) || Fl(a, 2, iC, g);
                    d.add(h)
                }
            }
        }
        return {
            Uj: a,
            Jk: c
        }
    }, {
        Uj: void 0,
        Jk: void 0
    });
    var zU = function(a, b, c) {
        Z.call(this, a, 1051);
        this.A = b;
        this.j = WM(this, c)
    };
    _.T(zU, Z);
    zU.prototype.g = function() {
        var a = this;
        this.j.value && dm(this.context.S, this.j.value, function(b, c) {
            qn(a.context, b, c);
            var d, e;
            (d = a.A) == null || (e = d.error) == null || e.call(d, c)
        })
    };
    var AU = Sj(1040, function(a) {
        return (a = a.np) ? {
            Qe: _.ul(a, iC, 2, _.wl()).map(function(b) {
                var c = GA(b, jC);
                b = _.t(b, 1);
                c = c && (_.w(c, "startsWith").call(c, location.protocol) || _.w(c, "startsWith").call(c, "data:") && c.length <= 80) ? za(zu(c)) : void 0;
                return {
                    lf: b,
                    url: c
                }
            })
        } : {
            Qe: []
        }
    }, {
        Qe: void 0
    });
    var BU = Sj(813, function(a, b, c, d) {
        var e = a.Qe;
        a = a.localStorage;
        if ((e == null ? 0 : e.length) && a) {
            e = _.y(e);
            for (var f = e.next(); !f.done; f = e.next()) {
                var g = f.value;
                f = g.lf;
                (g = g.url) && _.Sq(d, hm(b.S, f, g, a, c, function(h, l) {
                    qn(b, h, l);
                    var k, m;
                    (m = (k = console).error) == null || m.call(k, l)
                }))
            }
        }
        return {}
    }, {});
    var CU = function(a, b, c) {
        Z.call(this, a, 1045);
        this.j = b;
        this.Sb = c
    };
    _.T(CU, Z);
    CU.prototype.g = function() {
        var a = new L(this.context.S, 36);
        _.Sq(this, a);
        var b = a.g(AU, {
            np: this.j
        }).Qe;
        a.g(BU, {
            Qe: b,
            localStorage: this.Sb
        }, this.context, this.Sb, a);
        a.run()
    };
    var Zw = function(a, b, c, d) {
        Z.call(this, a, 706);
        this.B = b;
        this.output = d != null ? d : X(this);
        this.j = Y(this, c)
    };
    _.T(Zw, Z);
    Zw.prototype.g = function() {
        this.output.ic(wi(this.j.value, this.B))
    };
    var Lw = function(a, b, c, d) {
        Z.call(this, a, 1154);
        this.Rc = c;
        this.j = d;
        this.A = WM(this, b)
    };
    _.T(Lw, Z);
    Lw.prototype.g = function() {
        if (this.A.value) {
            var a = new L(this.context.S, 37);
            _.Sq(this, a);
            var b = new Zw(this.context, window, this.Rc, this.j.Sb);
            M(a, b);
            b = a.g(yU, {}, this.A.value);
            var c = b.Uj;
            this.j.Vh = b.Jk;
            M(a, new CU(this.context, c, this.j.Sb));
            b = new zU(this.context, console, this.j.Sb);
            M(a, b);
            a.run()
        } else this.j.Vh.ha(), this.j.Sb.ha()
    };
    var Bu = Sj(1263, function(a, b) {
        if (b.toLowerCase() === "#enableshoppitdemo") return {
            adUnitPath: "/6499/shoppit_test",
            Ec: !1
        };
        var c;
        return (c = a.od) != null && _.yl(uA(c, tC, 1), 2) ? {
            adUnitPath: uA(a.od, tC, 1).getAdUnitPath(),
            Ec: _.R(uA(a.od, tC, 1), 3)
        } : {
            adUnitPath: null,
            Ec: !1
        }
    }, {
        adUnitPath: void 0,
        Ec: void 0
    });
    var Gu = Pj(1248, function(a, b, c, d, e) {
        var f, g, h, l, k, m, n, p, r, v, u, x;
        return _.ug(function(D) {
            f = a;
            g = f.adUnitPath;
            h = f.jb;
            l = f.Ec;
            if (!(l && g && h && wA(h).length)) return D.return();
            k = e.add(c, d, g, [1, 1], {
                Qb: void 0,
                format: 6,
                Kb: !0
            });
            m = k.slotId;
            n = k.settings;
            if (m && n) {
                var F = _.uj(n, 15, 6);
                _.Dl(F, 33, !0)
            } else return D.return();
            p = document.createElement("div");
            p.style.display = "none";
            p.style.position = "absolute";
            p.style.top = "-10000px";
            p.style.left = "-10000px";
            document.body.appendChild(p);
            var C = _.AC(h);
            F = _.K(WJ);
            if (F >= C.length) F = C;
            else {
                C = C.slice();
                for (var G = C.length - 1; G > 0; G--) {
                    var S = Math.floor(Math.random() * (G + 1)),
                        P = _.y([C[S], C[G]]);
                    C[G] = P.next().value;
                    C[S] = P.next().value
                }
                F = C.slice(0, F)
            }
            r = _.y(F);
            for (v = r.next(); !v.done; v = r.next()) u = v.value, x = document.createElement("iframe"), x.style.display = "none", p.appendChild(x), _.DU(b, m, _.t(u, 1), x);
            D.g = 0
        })
    });
    var EU = Sj(1205, function(a, b, c, d, e) {
        var f = a.module;
        a = new f.up(a.Kc, c, a.rb, d, a.Cd, new _.mn(b), new f.qn(c), void 0, void 0, void 0, !0, !0);
        _.Sq(e, a);
        return {}
    }, {});
    var FU = Pj(1204, function(a, b) {
        return _.ug(function(c) {
            return c.return(b.load(_.qR))
        })
    });
    var zx = function(a, b, c, d, e, f, g) {
        L.call(this, a.S, 43);
        c = c === 8 ? 3 : 4;
        d = this.l(FU, {}, d);
        this.g(EU, {
            module: d.output,
            Kc: e,
            rb: f,
            Cd: g
        }, a, b, c, this)
    };
    _.T(zx, L);
    var gw = function(a, b) {
        var c = this,
            d = [],
            e = [];
        this.addSize = on(a, 88, function(f, g) {
            var h;
            if (h = Mp(f)) h = g, h = Jp(h) || Array.isArray(h) && h.every(Jp);
            if (h) {
                var l = Ku(g);
                h = l.size;
                l.vi && (g = vn([f, g]), g = g.substring(1, g.length - 1), Q(b, new un(151, ["SizeMappingBuilder.addSize", g])), g = h);
                d.push([f, g])
            } else e.push([f, g]), Q(b, wn("SizeMappingBuilder.addSize", [f, g]));
            return c
        });
        this.build = on(a, 89, function() {
            if (e.length) return Q(b, yP(bp(e))), null;
            mb(d);
            return d
        })
    };
    var GU = Sj(939, function(a, b) {
        var c = b.context,
            d = b.Co;
        a = b.B;
        var e = b.ba;
        b = b.Rn;
        var f = new EB,
            g = new DB;
        d = _.Ek(g, 1, String(d));
        d = _.Wg(f, 5, d);
        d = _.H(d, 4, 1);
        d = _.H(d, 2, 2);
        c = _.Ek(d, 3, c.Ra);
        e = vi(e);
        e = _.$g(c, 6, e);
        _.I(fK) && _.$g(e, 7, !0);
        b(a, e);
        return {}
    }, {});
    var rx = Pj(1240, function(a, b) {
        return Zu(b.K, b.slotId, b.context)
    });
    var mx = function(a, b, c, d, e) {
        Z.call(this, a, 807);
        this.B = b;
        this.ac = c;
        this.output = VM(this);
        this.j = Y(this, d);
        e && YM(this, e)
    };
    _.T(mx, Z);
    mx.prototype.g = function() {
        if (this.ac && !this.j.value) {
            var a = wE(this.B);
            EO(new DO(a, this.ac)) || this.reportError(new HL("Cannot create top window frame"))
        }
        this.output.notify()
    };
    var HU = function(a, b) {
        Z.call(this, a, 820);
        this.B = b;
        this.output = X(this)
    };
    _.T(HU, Z);
    HU.prototype.g = function() {
        var a = this;
        this.output.pb(vm(this.B).then(function(b) {
            var c = b.ac;
            var d = b.status;
            ks("gpt_etu", function(e) {
                yr(e, a.context);
                zr(e, "rsn", d)
            }, c ? void 0 : 0);
            return c != null ? c : ""
        }))
    };
    var IU = function(a, b, c, d) {
        Z.call(this, a, 979);
        this.B = b;
        this.j = WM(this, d);
        this.output = c
    };
    _.T(IU, Z);
    IU.prototype.g = function() {
        var a = this;
        if (_.I(jK) || vp()) this.output.ha();
        else {
            var b;
            zm(this.B, (b = this.j.value) != null ? b : !1).then(function(c) {
                a.output.H(c)
            })
        }
    };
    IU.prototype.l = function() {
        this.output.ha()
    };
    var Nw = function(a, b, c, d) {
        Z.call(this, a, 1156);
        this.B = b;
        this.Rg = c;
        this.j = {
            Td: new Ws
        };
        this.A = Y(this, d)
    };
    _.T(Nw, Z);
    Nw.prototype.g = function() {
        if (vi(this.A.value)) {
            var a = new L(this.context.S, 47);
            _.Sq(this, a);
            var b = new IU(this.context, this.B, this.j.Td, this.Rg);
            M(a, b);
            a.run()
        } else this.j.Td.ha()
    };
    var JU = function(a, b, c) {
        Z.call(this, a, 1123);
        this.j = b;
        this.A = c;
        X(this, b);
        X(this, c)
    };
    _.T(JU, Z);
    JU.prototype.g = function() {
        _.I(hK) ? (this.j.H(!1), this.A.ha()) : (this.j.H(!0), this.A.H(10))
    };
    var KU = function(a, b, c, d, e) {
        Z.call(this, a, 978);
        this.B = b;
        this.localStorage = c;
        this.j = e;
        X(this, e);
        this.A = WM(this, d)
    };
    _.T(KU, Z);
    KU.prototype.g = function() {
        if (_.I(iK)) this.j.ha();
        else if (this.A.value) {
            var a = Gm(this.A.value, this.B, new _.mn(this.context), this.localStorage);
            this.j.pb(a)
        } else this.j.ha()
    };
    KU.prototype.l = function() {
        this.j.ha()
    };
    var bv = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 1164);
        this.networkCode = b;
        this.localStorage = c;
        this.pg = d;
        this.j = f;
        this.C = Y(this, e);
        h && (this.A = WM(this, h));
        g && (this.G = Y(this, g))
    };
    _.T(bv, Z);
    bv.prototype.g = function() {
        var a = Yi(window.isSecureContext, window.document),
            b, c = !((b = this.A) == null || !b.value),
            d, e, f;
        b = (e = this.A) == null ? void 0 : (f = e.value) == null ? void 0 : Qe(f, 1, Id).get((d = this.networkCode.split(",")) == null ? void 0 : d[0]);
        var g;
        !a || c && b === !1 || ((g = this.G) == null ? 0 : g.value) ? (this.j.We.ha(), this.j.ng.H(!1), this.j.og.ha()) : this.C.value ? (a = new L(this.context.S, 48), _.Sq(this, a), M(a, new KU(this.context, window, this.localStorage, this.pg.Td, this.j.We)), c = new JU(this.context, this.j.ng, this.j.og), M(a, c), a.run()) : (this.j.We.H(5), this.j.ng.H(!1), this.j.og.H(5))
    };
    var LU = function(a, b, c) {
        Z.call(this, a, 1101);
        this.B = b;
        this.j = c
    };
    _.T(LU, Z);
    LU.prototype.g = function() {
        if (!_.I(iK)) {
            var a = this.j,
                b = wm(this.B);
            b.setTopicsCalled ? _.z.Promise.resolve() : (b.setTopicsCalled = !0, a({
                message: "goog:topics:frame:get:topics",
                skipTopicsObservation: !1
            }))
        }
    };
    var qx = function(a, b, c, d) {
        Z.call(this, a, 1180);
        this.B = b;
        this.Eg = c;
        this.j = WM(this, d.Td)
    };
    _.T(qx, Z);
    qx.prototype.g = function() {
        if (this.Eg && this.j.value) {
            var a = new L(this.context.S, 51);
            _.Sq(this, a);
            M(a, new LU(this.context, this.B, this.j.value));
            a.run()
        }
    };
    var zv = function(a) {
        this.D = _.A(a)
    };
    _.T(zv, _.B);
    var gv = function(a, b) {
        return _.We(a, 2, _.xd(b), "0")
    };
    var MU = function(a) {
        this.D = _.A(a)
    };
    _.T(MU, _.B);
    var kv = function(a, b) {
            return _.ul(a, zv, 1, _.wl(b))
        },
        jv = bg(MU);
    var Jw = function(a, b, c, d) {
        Z.call(this, a, 1186);
        this.B = b;
        this.j = Date.now();
        this.output = X(this);
        this.ba = Y(this, c);
        this.le = Y(this, d)
    };
    _.T(Jw, Z);
    Jw.prototype.g = function() {
        if (Xi(this.B.isSecureContext, this.B.navigator, this.B.document) && !_.I(ow) && nv(this.j)) {
            var a = _.gp(new _.PL(this.B), "__gpi", this.ba.value);
            if (a) this.output.H(_.aj(a) % 63001);
            else {
                a = this.j / 1E3;
                for (var b = _.y(this.le.value), c = b.next(); !c.done; c = b.next())
                    if (c = c.value, a < Number(_.AA(c, 2))) {
                        if (c.getId() >= 63001) {
                            this.output.ha();
                            return
                        }
                        this.output.H(c.getId());
                        return
                    }
                this.output.ha()
            }
        } else this.output.ha()
    };
    var NU = function(a, b, c) {
        Z.call(this, a, 1171);
        this.j = c;
        X(this, c);
        this.ti = Y(this, b)
    };
    _.T(NU, Z);
    NU.prototype.g = function() {
        this.j.H(this.ti.value.kind === 0)
    };
    var OU = function(a, b, c) {
        Z.call(this, a, 1160);
        this.j = c;
        X(this, c);
        this.A = Y(this, b)
    };
    _.T(OU, Z);
    OU.prototype.g = function() {
        if (this.A.value.requestId != null) {
            var a = this.A.value.request;
            this.context.va.La.Ma.Xe.mm.wb({
                xb: a.byteLength
            });
            a.byteLength > (_.K(tK) || 33792) ? this.j.H({
                kind: 1,
                reason: 3
            }) : (a = Ab(a, 3), a.length ? this.j.H({
                kind: 0,
                signal: a,
                requestId: this.A.value.requestId
            }) : this.j.H({
                kind: 1,
                reason: 5
            }))
        } else this.j.H({
            kind: 1,
            reason: this.A.value
        })
    };
    OU.prototype.l = function() {
        this.j.H({
            kind: 1,
            reason: 4
        })
    };
    var PU = function(a, b) {
        Z.call(this, a, 1159);
        this.output = X(this);
        this.navigator = b
    };
    _.T(PU, Z);
    PU.prototype.g = function() {
        var a = this,
            b = {
                seller: "https://securepubads.g.doubleclick.net"
            },
            c = _.K(tK);
        c && (b.requestSize = c);
        c = ej(nK);
        if (c.length) {
            b.perBuyerConfig = {};
            c = _.y(c);
            for (var d = c.next(); !d.done; d = c.next()) b.perBuyerConfig[d.value] = {}
        }
        this.output.pb(this.navigator.getInterestGroupAdAuctionData(b).catch(function(e) {
            a.reportError(e);
            return 4
        }))
    };
    PU.prototype.l = function() {
        this.output.H(4)
    };
    var qv = function(a, b, c, d, e, f) {
        Z.call(this, a, 1177);
        this.C = b;
        this.j = e;
        this.A = f;
        X(this, e);
        X(this, f);
        this.G = Y(this, c);
        d && (this.I = Y(this, d))
    };
    _.T(qv, Z);
    qv.prototype.g = function() {
        if (this.G.value) {
            var a;
            if ((a = this.I) == null ? 0 : a.value) this.j.H({
                kind: 1,
                reason: 6
            }), this.A.H(!1);
            else {
                a = new L(this.context.S, 57);
                _.Sq(this, a);
                var b = new PU(this.context, this.C);
                M(a, b);
                b = new OU(this.context, b.output, this.j);
                M(a, b);
                b = new NU(this.context, this.j, this.A);
                M(a, b);
                a.run()
            }
        } else this.j.H({
            kind: 1,
            reason: 2
        }), this.A.H(!1)
    };
    qc({
        google_signals: qc({
            buyer_reporting_id: wc
        })
    });
    var QU = function(a, b, c, d, e, f) {
        Z.call(this, a, 881);
        this.slotId = b;
        this.K = c;
        this.fa = d;
        this.j = e;
        this.A = f;
        this.output = X(this)
    };
    _.T(QU, Z);
    QU.prototype.g = function() {
        if (_.K(pw) === 4) {
            var a = _.Fi(this.fa, ND, 23);
            if (a) {
                var b;
                if (((b = this.j) == null ? void 0 : b.kind) !== 0) throw new TypeError("Received remote auction config despite " + (this.j ? "invalid" : "absent") + " remarketing input.");
                this.output.H({
                    seller: "https://securepubads.g.doubleclick.net",
                    interestGroupBuyers: _.Ou(this.fa, 3, _.wl(_.Yn)),
                    requestId: this.j.requestId,
                    serverResponse: Jm(Km(a, 1)),
                    resolveToConfig: !_.R(this.fa, 14)
                })
            } else(b = TD(this.fa)) ? tv(0, 0, b) : reportError(new TypeError("Missing seller signals in B&A error case.")), this.output.ha()
        } else {
            b = _.K(kK);
            var c = b > 0 && this.context.Zb < 1 / b,
                d;
            b = this.output;
            a = b.H;
            var e = this.fa,
                f = (d = this.K.Bd) == null ? void 0 : d[this.slotId.getDomId()],
                g = this.context.va,
                h = this.A,
                l = _.I(mK),
                k = _.K(qK);
            d = !_.R(e, 14);
            var m = {};
            var n = _.ul(e, ED, 7, _.wl());
            n = _.y(n);
            for (var p = n.next(); !p.done; p = n.next()) {
                p = p.value;
                var r = {},
                    v = void 0,
                    u = (v = g) == null ? void 0 : v.La.Ma.Xe.xm;
                v = _.t(p, 1);
                if (_.t(p, 2).length) try {
                    if (r = JSON.parse(_.t(p, 2)), _.$i() * 100 < 1) {
                        var x = void 0;
                        (x = u) == null || x.ta({
                            Dg: v,
                            status: "SUCCESS",
                            wa: 100
                        })
                    }
                } catch (G) {
                    x = void 0, (x = u) == null || x.ta({
                        Dg: v,
                        status: "ERROR",
                        wa: 1
                    })
                } else x = void 0, (x = u) == null || x.ta({
                    Dg: v,
                    status: "EMPTY",
                    wa: 1
                });
                m[_.t(p, 1)] = r
            }
            if (g = _.Fi(e, DD, 6)) m["https://googleads.g.doubleclick.net"] = _.jf(g), m["https://td.doubleclick.net"] = _.jf(g);
            g = {};
            n = _.y(_.ul(e, MD, 11, _.wl()));
            for (p = n.next(); !p.done; p = n.next()) p = p.value, g[_.t(p, 1)] = _.Ct(p, 2);
            n = {};
            _.Ct(e, 21) !== 0 && (n["*"] = _.Ct(e, 21));
            if (_.ul(e, KD, 32, _.wl()).length > 0) {
                var D = {};
                p = _.y(_.ul(e, KD, 32, _.wl()));
                for (r = p.next(); !r.done; r = p.next()) r = r.value, D[_.t(r, 1)] = _.Ct(r, 2)
            }
            p = {};
            Xn(e, 18) != null && (p["https://googleads.g.doubleclick.net"] = Ov(e, 18), p["https://td.doubleclick.net"] = Ov(e, 18));
            r = _.y(Re(e, 24, RD));
            for (u = r.next(); !u.done; u = r.next()) v = _.y(u.value), u = v.next().value, v = v.next().value, Ov(v, 4) && (p[u] = Ov(v, 4));
            r = {};
            u = _.y(Re(e, 24, RD));
            for (v = u.next(); !v.done; v = u.next()) x = _.y(v.value), v = x.next().value, x = x.next().value, x = _.t(x, 5), x.length && (r[v] = {
                type: x
            });
            u = {};
            k && k > 1 && (u["*"] = k);
            k = _.t(e, 1).split("/td/")[0];
            var F;
            v = (F = TD(e)) == null ? void 0 : _.ve(F);
            var C;
            v != null && (C = _.Fi(v, OD, 5)) != null && _.vj(C, 2);
            D = _.w(Object, "assign").call(Object, {}, {
                seller: k,
                decisionLogicUrl: _.t(e, 1),
                trustedScoringSignalsUrl: _.t(e, 2),
                interestGroupBuyers: _.Ou(e, 3, _.wl(_.Yn)),
                sellerExperimentGroupId: Ov(e, 17),
                auctionSignals: JSON.parse(_.t(e, 4) || "{}"),
                sellerSignals: (v == null ? void 0 : _.jf(v)) || [],
                sellerTimeout: _.Ct(e, 15) || 50,
                perBuyerExperimentGroupIds: p,
                perBuyerSignals: m,
                perBuyerTimeouts: g,
                perBuyerCumulativeTimeouts: n,
                perBuyerRealTimeReportingConfig: r,
                perBuyerMultiBidLimits: u,
                reportingTimeout: 5E3
            }, D ? {
                perBuyerGroupLimits: D
            } : {}, d ? {
                resolveToConfig: d
            } : {});
            if (e == null ? 0 : _.R(UD(e), 25)) D.sellerCurrency = "USD", D.perBuyerCurrencies = _.w(Object, "fromEntries").call(Object, Qe(e, 22, Jd));
            _.t(e, 28) && (D.directFromSellerSignalsHeaderAdSlot = _.t(e, 28));
            uv(D.interestGroupBuyers, c) && (D.auctionReportBuyerKeys = D.interestGroupBuyers.map(pv), D.auctionReportBuyers = vv(l), D.auctionReportBuyerDebugModeConfig = wv());
            h && (D.auctionNonce = h, D.additionalBids = _.z.Promise.resolve());
            Qe(e, 33, Jd).size && (D.deprecatedRenderURLReplacements = _.w(Object, "fromEntries").call(Object, (_.E = Qe(e, 33, Jd), _.w(_.E, "entries")).call(_.E)), (F = D.deprecatedRenderURLReplacements["${RENDER_DATA_td.doubleclick.net_GDA}"]) && (D.deprecatedRenderURLReplacements["${RENDER_DATA}"] = F));
            F = Object;
            C = F.assign;
            c = _.t(e, 1);
            h = Ov(e, 17);
            l = new PD;
            _.zs(UD(e), OD, 5) && (m = new OD, g = BA(uA(UD(e), OD, 5), 2), m = _.We(m, 2, id(g), "0"), g = BA(uA(UD(e), OD, 5), 4), m = _.We(m, 4, id(g), "0"), _.Wg(l, 5, m));
            UD(e).getEscapedQemQueryId() && (m = UD(e).getEscapedQemQueryId(), _.Ek(l, 2, m));
            _.t(UD(e), 6) && (m = _.t(UD(e), 6), _.Ek(l, 6, m));
            _.R(UD(e), 21) && _.$g(l, 21, !0);
            _.R(UD(e), 4) && _.$g(l, 4, !0);
            _.t(UD(e), 11) && (m = _.t(UD(e), 11), _.Ek(l, 11, m));
            _.R(UD(e), 32) && _.$g(l, 32, !0);
            l = _.jf(l);
            m = _.Ct(e, 15) || 50;
            if (_.R(e, 30)) {
                if (f == null || !f.length) throw Error("top_td_without_component_auction");
            } else f = [D].concat(_.Zk(f != null ? f : []));
            f = C.call(F, {}, {
                seller: k,
                decisionLogicUrl: c,
                sellerExperimentGroupId: h,
                sellerSignals: l,
                sellerTimeout: m,
                interestGroupBuyers: [],
                auctionSignals: {},
                perBuyerExperimentGroupIds: {},
                perBuyerSignals: {},
                perBuyerTimeouts: {},
                perBuyerCumulativeTimeouts: {},
                componentAuctions: f
            }, d ? {
                resolveToConfig: d
            } : {});
            _.t(e, 28) && (f.directFromSellerSignalsHeaderAdSlot = _.t(e, 28));
            a.call(b, f)
        }
    };
    QU.prototype.l = function() {
        this.output.ha()
    };
    var RU = function(a, b, c, d) {
        Z.call(this, a, 1105);
        this.adUnitPath = b;
        this.fa = c;
        this.storage = d
    };
    _.T(RU, Z);
    RU.prototype.g = function() {
        var a = Date.now();
        if (nv(a)) {
            var b = _.Ou(this.fa, 3, _.wl()),
                c = dv(this.adUnitPath);
            if (_.R(this.fa, 20)) {
                var d, e = ((d = _.Fi(this.fa, QD, 29)) == null ? void 0 : Ov(d, 2)) || 864E5;
                a = Av(b, a + e);
                d = (b = this.storage.getItem(c)) ? kv(jv(b), _.Yn) : [];
                var f;
                b = new MU;
                a = hv(d, a);
                a = _.Qn(b, 1, a);
                b = !((f = _.Fi(this.fa, QD, 29)) == null || !_.R(f, 3));
                f = _.Dl(a, 2, b);
                this.storage.setItem(c, Fm(f))
            } else this.storage.removeItem(c)
        }
    };
    var Cv = navigator;
    var SU = function() {
            var a = this;
            this.promise = new _.z.Promise(function(b, c) {
                a.reject = c;
                a.resolve = b
            })
        },
        TU = function() {
            this.auctionSignals = new SU;
            this.topLevelSellerSignals = new SU;
            this.g = new SU;
            this.perBuyerSignals = new SU;
            this.perBuyerTimeouts = new SU;
            this.perBuyerCumulativeTimeouts = new SU;
            this.directFromSellerSignals = new SU;
            this.directFromSellerSignalsHeaderAdSlot = new SU;
            this.perBuyerCurrencies = new SU;
            this.resolveToConfig = new SU;
            this.deprecatedRenderURLReplacements = new SU;
            this.o = new SU
        },
        UU = function(a, b, c, d) {
            this.g = a;
            this.Sg = b;
            this.interestGroupBuyers = c;
            this.Nb = d
        };
    var VU = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u) {
        Z.call(this, a, 1201);
        this.navigator = b;
        this.ba = c;
        this.fa = d;
        this.ia = e;
        this.U = l;
        this.G = k;
        this.I = m;
        this.R = n;
        this.C = p;
        this.j = r;
        this.ka = VM(this);
        this.A = X(this);
        this.pa = WM(this, f);
        this.Ea = Y(this, g);
        this.oa = Y(this, h);
        this.ca = Y(this, u);
        Y(this, v);
        X(this, p);
        X(this, n.bc);
        X(this, n.Ka);
        X(this, n.Oa);
        X(this, this.j)
    };
    _.T(VU, Z);
    VU.prototype.g = function() {
        var a = this.Ea.value,
            b = Math.round(performance.now() - a),
            c = this.oa.value;
        a = this.pa.value;
        var d = TD(this.fa),
            e = _.R(d, 10),
            f = _.R(d, 9),
            g = typeof a === "string" || Fv(a),
            h = a !== 3 && a !== 2 && a !== 1;
        this.j.H(g && !f);
        h && Lv(this.context, g, c, b, d);
        this.context.O.log(607368714, Jv, {
            ie: b,
            km: a,
            To: d.getEscapedQemQueryId(),
            Hn: _.t(d, 6)
        });
        var l, k;
        h = (k = (l = this.ca.value.componentAuctions) == null ? void 0 : l.length) != null ? k : 0;
        Kv(this.context, a, b, c, !!this.ia, d, h, g);
        if (g)
            if (e) this.navigator.deprecatedURNToURL(a, !0), this.C.H(!0), this.A.ha();
            else if (f) {
            _.R(d, 17) ? tv(0, 0, d) : this.navigator.deprecatedURNToURL(a, !0);
            var m;
            Bv(this.R, this.j, this.G, this.I, this.U, (m = this.fa) == null ? void 0 : _.t(m, 25));
            this.C.H(!0);
            this.A.ha()
        } else {
            this.A.H(a);
            this.C.H(!0);
            k = this.ca.value;
            m = this.fa;
            var n;
            l = ((n = k.componentAuctions) == null ? void 0 : n.length) === 1 && ov(k.componentAuctions[0].seller) && _.zs(m, BD, 26) ? Yz(Fm(uA(m, BD, 26)), 3) : "";
            var p, r, v, u;
            n = {
                gdprApplies: dp(this.ba, 3) ? _.R(this.ba, 3) ? "1" : "0" : null,
                jh: _.IA(this.ba, 2),
                im: _.IA(this.ba, 4),
                Og: (p = this.fa) == null ? void 0 : (r = TD(p)) == null ? void 0 : (v = _.Fi(r, ZC, 1)) == null ? void 0 : (u = _.Fi(v, YC, 2)) == null ? void 0 : uA(u, XC, 3),
                dm: this.fa.getWidth().toString(),
                bm: this.fa.getHeight().toString(),
                bp: l
            };
            OM(this.ka, Ev(a, n))
        } else {
            tv(b, a === 2 ? c : 0, d);
            if (!e) {
                var x;
                Bv(this.R, this.j, this.G, this.I, this.U, (x = this.fa) == null ? void 0 : _.t(x, 25))
            }
            this.C.H(!0);
            this.A.ha()
        }
    };
    VU.prototype.l = function() {
        var a, b, c = (a = this.fa) == null ? void 0 : TD(a);
        a = this.ia;
        var d = this.R,
            e = this.j,
            f = this.G,
            g = this.I,
            h = this.U;
        (b = this.fa) == null || _.t(b, 25);
        c && tv(0, 0, c);
        a == null || a.Nb.abort();
        Bv(d, e, f, g, h)
    };
    var WU = function(a, b, c, d, e, f, g, h, l, k, m, n, p) {
        Z.call(this, a, 1200);
        this.L = b;
        this.navigator = c;
        this.j = d;
        this.fa = e;
        this.ca = g;
        this.I = h;
        this.R = l;
        this.U = m;
        this.ia = n;
        this.C = UM(this);
        this.pa = X(this);
        this.oa = X(this);
        this.ka = X(this);
        this.A = WM(this, f);
        Y(this, k);
        X(this, m.bc);
        X(this, m.Ka);
        X(this, m.Oa);
        X(this, n);
        p && (this.G = Y(this, p))
    };
    _.T(WU, Z);
    WU.prototype.g = function() {
        if (this.A.value) {
            var a = UD(this.fa);
            Mv(this.context, a);
            var b = performance.now();
            this.pa.H(b);
            b = _.Ct(this.fa, 8) || 1E3;
            this.oa.H(b);
            var c, d, e, f;
            if (((c = this.G) == null ? void 0 : c.value) === 4 || ((d = this.G) == null ? void 0 : (e = d.value) == null ? void 0 : e.requestId) != null && ((f = this.G) == null ? void 0 : f.value).request.byteLength > (_.K(tK) || 33792)) {
                var g;
                (g = this.j) == null || g.Nb.abort();
                this.C.H(1)
            } else if (c = _.Ct(a, 14) || -1, a = _.Ct(a, 13) || -1, a = a > 0 && this.L.j >= a, c > 0 && this.L.l >= c || a) this.C.H(1);
            else {
                ++this.L.l;
                ++this.L.j;
                this.A.value.signal = AbortSignal.timeout(b);
                if (this.j && this.A.value.serverResponse) throw new TypeError("Attempted to provide a RemoteAuctionConfig in parallelized auction.");
                b = this.j ? XU(this.A.value, b, this.j) : YU(this, this.A.value);
                --this.L.l;
                this.C.pb(b)
            }
        } else(b = this.j) == null || b.Nb.abort(), Bv(this.U, this.ia, this.I, this.R, this.ca, _.t(this.fa, 25)), this.ka.H(!1)
    };
    var YU = function(a, b) {
            var c, d;
            return (d = (c = a.navigator).runAdAuction) == null ? void 0 : d.call(c, b).catch(function(e) {
                if (e instanceof DOMException && e.name === "TimeoutError") return 2;
                e instanceof Error && a.reportError(e);
                return 3
            })
        },
        XU = function(a, b, c) {
            yv(a, c);
            setTimeout(function() {
                c.Nb.abort(new DOMException("runAdAuction", "TimeoutError"))
            }, b);
            return c.g
        };
    WU.prototype.l = function() {
        var a, b = (a = this.fa) == null ? void 0 : TD(a);
        a = this.j;
        var c = this.U,
            d = this.ia,
            e = this.I,
            f = this.R,
            g = this.ca;
        _.t(this.fa, 25);
        b && tv(0, 0, b);
        a == null || a.Nb.abort();
        Bv(c, d, e, f, g)
    };
    var ZU = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1202);
        this.fa = b;
        this.G = c;
        this.j = d;
        this.A = WM(this, f);
        this.C = Y(this, e);
        YM(this, g);
        X(this, d.bc);
        X(this, d.Ka);
        X(this, d.Oa)
    };
    _.T(ZU, Z);
    ZU.prototype.g = function() {
        if (this.A.value) {
            var a = this.G;
            if (!fo(a) || (_.E = [8, 9], _.w(_.E, "includes")).call(_.E, a)) this.C.value.style.display = "";
            var b = this.A.value,
                c = this.fa;
            a = this.context.va;
            var d = _.t(c, 31);
            d ? Fv(b) ? (a.La.Ma.Xe.Bi.Vi.ta({
                wa: 1,
                status: "FAILED_FENCED_FRAME"
            }), a = null) : ((c = TD(c)) && _.R(c, 27) ? (c = tb(c), d = d.replace("%%activeview_prefix%%", c).replace("%%activeview_script%%", "https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js")) : d = d.replace("%%activeview_prefix%%", "").replace("%%activeview_script%%", ""), b = d.replace("%%srcfledge%%", b), b.length === d.length && b === d ? (a.La.Ma.Xe.Bi.Vi.ta({
                wa: 1,
                status: "FAILED_UNMODIFIED"
            }), a = null) : (a.La.Ma.Xe.Bi.Vi.ta({
                wa: 1,
                status: "OK"
            }), a = b)) : a = null;
            a ? this.j.Ka.H({
                kind: 0,
                nb: a
            }) : this.j.Ka.H({
                kind: 1,
                token: this.A.value
            });
            this.j.Oa.H(new _.mo(this.fa.getWidth(), this.fa.getHeight()));
            this.j.bc.H(!1)
        }
    };
    var $U = function(a, b, c) {
        Z.call(this, a, 1054);
        this.j = b;
        this.output = VM(this);
        this.A = Y(this, c)
    };
    _.T($U, Z);
    $U.prototype.g = function() {
        this.A.value || this.j();
        this.output.notify()
    };
    var aV = function(a, b, c, d, e, f) {
        Z.call(this, a, 1053);
        this.slotId = b;
        this.K = c;
        this.L = d;
        this.lb = e;
        this.j = X(this);
        this.A = Y(this, f)
    };
    _.T(aV, Z);
    aV.prototype.g = function() {
        var a = this.A.value;
        a && Sv(this.slotId, this.L, this.K, this.lb);
        this.j.H(!a)
    };
    var bV = function(a, b, c, d) {
        Z.call(this, a, 1055);
        this.j = d;
        YM(this, c);
        this.A = Y(this, b);
        VM(this, this.j)
    };
    _.T(bV, Z);
    bV.prototype.g = function() {
        this.A.value && this.j.notify()
    };
    var fx = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u, x, D) {
        Z.call(this, a, 1179);
        this.slotId = b;
        this.W = d;
        this.L = e;
        this.ba = f;
        this.A = g;
        this.R = k;
        this.C = m;
        this.K = n;
        this.ca = p;
        this.lb = r;
        this.fa = v;
        this.j = u;
        this.ka = x;
        this.ia = D;
        this.G = Y(this, h);
        this.I = Y(this, l);
        this.U = WM(this, c)
    };
    _.T(fx, Z);
    fx.prototype.g = function() {
        var a = new L(this.context.S, 53);
        _.Sq(this, a);
        var b = X(this);
        if (this.fa) {
            var c = UD(this.fa),
                d = _.R(c, 10);
            if (this.fa.getWidth() && this.fa.getHeight())
                if (d)
                    if (Bv({
                            bc: b,
                            Ka: this.j.Ka,
                            Oa: this.j.Oa
                        }, this.j.Hd, this.G.value, this.I.value, this.A), _.R(c, 17)) {
                        tv(0, 0, c);
                        var e;
                        (e = this.C) == null || e.Nb.abort()
                    } else cV(this, a, this.fa);
            else b = cV(this, a, this.fa);
            else {
                Bv({
                    bc: b,
                    Ka: this.j.Ka,
                    Oa: this.j.Oa
                }, this.j.Hd, this.G.value, this.I.value, this.A);
                tv(0, 0, c);
                var f;
                (f = this.C) == null || f.Nb.abort();
                this.reportError(Error("Missing width or height"))
            }
        } else Bv({
            bc: b,
            Ka: this.j.Ka,
            Oa: this.j.Oa
        }, this.j.Hd, this.G.value, this.I.value, this.A), (c = this.C) == null || c.Nb.abort(new DOMException("runAdAuction", "ThrottledError"));
        e = new aV(this.context, this.slotId, this.K, this.L, this.lb, b);
        M(a, e);
        b = new $U(this.context, this.ca, b);
        M(a, b);
        b = new bV(this.context, e.j, b.output, this.j.bg);
        M(a, b);
        a.run()
    };
    var cV = function(a, b, c) {
        if (_.K(pw) === 2 && a.U.value && _.R(c, 20) && _.Ou(c, 3, _.wl()).length !== 0) {
            var d = new RU(a.context, a.slotId.getAdUnitPath(), c, a.U.value);
            M(b, d)
        }
        var e = new QU(a.context, a.slotId, a.K, c, a.ka, a.ia);
        M(b, e);
        var f = navigator,
            g = {
                Ka: a.j.Ka,
                Oa: a.j.Oa,
                bc: new Ws
            };
        d = g.bc;
        var h = void 0;
        _.I(lK) && (h = new PU(a.context, f), M(b, h));
        var l;
        h = new WU(a.context, a.L, f, a.C, c, e.output, a.A, a.G.value, a.I.value, a.R, g, a.j.Hd, (l = h) == null ? void 0 : l.output);
        M(b, h);
        l = new VU(a.context, f, a.ba, c, a.C, h.C, h.pa, h.oa, a.A, a.G.value, a.I.value, g, h.ka, a.j.Hd, a.R, e.output);
        M(b, l);
        a = new ZU(a.context, c, Wp(a.W), g, a.R, l.A, l.ka);
        M(b, a);
        return d
    };
    var dV = function() {
        tU.apply(this, arguments)
    };
    _.T(dV, tU);
    var eV = function(a, b) {
            var c = a.g.K.lc;
            c = c ? c : _.Fh(b ? "fencedframe" : "IFRAME");
            b && (c.mode = "opaque-ads");
            c.id = a.re;
            c.name = a.re;
            c.title = a.se;
            Array.isArray(a.l) ? a.l[0] != null && a.l[1] != null && (c.width = String(a.l[0]), c.height = String(a.l[1])) : (c.width = "100%", c.height = "0");
            c.allowTransparency = "true";
            c.scrolling = "no";
            c.marginWidth = "0";
            c.marginHeight = "0";
            c.frameBorder = "0";
            c.style.border = "0";
            c.style.verticalAlign = "bottom";
            c.setAttribute("aria-label", "Advertisement");
            c.tabIndex = 0;
            return c
        },
        fV = function(a, b) {
            typeof a.l !== "string" && (b.width = String(a.l[0]), b.height = String(a.l[1]));
            var c = on(a.context, 774, function() {
                a.loaded(b);
                _.Gh(b, "load", c)
            });
            _.sg(b, "load", c);
            _.$q(a, function() {
                return _.Gh(b, "load", c)
            });
            a.g.K.lc || a.g.rb.appendChild(b)
        };
    var gV = function() {
        dV.apply(this, arguments)
    };
    _.T(gV, dV);
    gV.prototype.F = function() {
        var a = eV(this, !this.g.Up);
        if (typeof this.ya.token === "string") {
            var b = this.ya.token;
            /^(uuid-in-package|urn:uuid):[0-9a-fA-F-]*$/.test(b) && (b = za(b), a.src = _.Aa(b).toString())
        } else a.config = this.ya.token;
        if (_.I(wK) && this.g.hl) {
            b = this.g.rb;
            var c = tb(this.g.hl);
            var d = new xB;
            a.setAttribute("class", "GoogleActiveViewElement");
            a.setAttribute("data-google-av-cxn", c);
            a.setAttribute("data-google-av-itpl", (40).toString());
            a.setAttribute("data-google-av-ufs-integrator-metadata", btoa(Fm(d)));
            c = b.appendChild;
            d = document.createElement("script");
            d.setAttribute("id", "googleActiveViewDisplayScript");
            var e = _.ng(yB);
            Xa(d, e);
            d.async = !0;
            c.call(b, d)
        }
        fV(this, a);
        return a
    };
    gV.prototype.j = function() {
        return !1
    };
    var hV = navigator,
        iV = function(a, b, c, d, e, f, g, h, l) {
            Z.call(this, a, 1089);
            this.nd = b;
            this.T = c;
            this.K = d;
            this.C = f;
            this.I = h;
            this.j = l;
            X(this, l);
            e && (this.A = WM(this, e));
            g && (this.G = WM(this, g))
        };
    _.T(iV, Z);
    iV.prototype.g = function() {
        var a = {};
        if (this.nd === 2) {
            var b, c = (b = this.A) == null ? void 0 : b.value;
            if (!c) {
                this.j.ha();
                return
            }
            var d;
            b = (d = this.G) == null ? void 0 : d.value;
            d = _.y(this.T);
            for (var e = d.next(); !e.done; e = d.next()) {
                e = e.value;
                var f = c.get(e.getId()),
                    g = void 0;
                if ((g = f) != null && g.length) {
                    var h = void 0;
                    g = (h = b) == null ? void 0 : h.get(e.getAdUnitPath());
                    h = void 0;
                    var l = (h = this.I) == null ? void 0 : h.get(e);
                    a[e.getId()] = jV(this, e, f, this.C, g, l)
                }
            }
        }
        this.j.H(a)
    };
    var jV = function(a, b, c, d, e, f) {
        var g = new TU,
            h = new AbortController,
            l = _.K(kK);
        l = l > 0 && a.context.Zb < 1 / l;
        var k, m = xv({
            Sg: g,
            Nb: h,
            interestGroupBuyers: c,
            Bd: (k = a.K.Bd) == null ? void 0 : k[b.getDomId()],
            En: d,
            mn: e,
            gm: l,
            ap: _.I(mK),
            sellerTimeout: _.K(rK),
            multiBidLimit: _.K(qK),
            auctionNonce: f
        });
        b = hV.runAdAuction(m).catch(function(n) {
            if (n instanceof DOMException && n.name === "TimeoutError") return 2;
            if (n instanceof DOMException && n.name === "ThrottledError") return 4;
            n instanceof Error && a.reportError(n);
            return 3
        });
        return new UU(b, g, c, h)
    };
    var kV = function(a, b, c, d) {
        Z.call(this, a, 1230);
        this.T = b;
        this.A = d;
        this.j = WM(this, c);
        X(this, d)
    };
    _.T(kV, Z);
    kV.prototype.g = function() {
        var a = this.j.value,
            b = new _.z.Map;
        if (a != null && a.size && !(0, _.yy)()) {
            var c = ej(oK);
            if (c.length !== 0)
                for (var d = _.y(this.T), e = d.next(); !e.done; e = d.next()) {
                    e = e.value;
                    var f = a.get(e.getId()),
                        g = void 0;
                    if ((g = f) != null && g.length) {
                        g = new _.z.Map;
                        f = _.y(f);
                        for (var h = f.next(); !h.done; h = f.next()) h = h.value, _.w(c, "includes").call(c, _.aj(h).toString()) && g.set(h, Math.floor(_.$i() * 63001));
                        g.size && b.set(e.getAdUnitPath(), g)
                    }
                }
        }
        this.A.H(b)
    };
    var lV = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1106);
        this.ba = b;
        this.localStorage = c;
        this.A = d;
        this.T = e;
        this.C = f;
        this.G = g;
        this.j = X(this);
        X(this, g)
    };
    _.T(lV, Z);
    lV.prototype.g = function() {
        for (var a = lv(this.A, this.localStorage, this.ba, _.I(uK), this.C), b = new _.z.Map, c = Tv(a), d = new _.z.Map, e = _.y(this.T), f = e.next(); !f.done; f = e.next()) {
            var g = f.value;
            f = g.getAdUnitPath();
            var h = a.get(dv(f)),
                l = void 0,
                k = void 0,
                m = void 0,
                n = (m = (k = c) != null ? k : (l = h) == null ? void 0 : kv(l).map(function(p) {
                    return _.t(p, 1)
                })) != null ? m : [];
            b.set(g.getId(), n);
            if (!d.has(f)) {
                g = [];
                n = _.y(n.sort());
                for (h = n.next(); !h.done; h = n.next()) g.push(_.aj(h.value));
                d.set(f, g)
            }
        }
        this.j.H(b);
        this.G.H(d)
    };
    var Uv = function(a, b, c, d, e, f, g, h, l, k) {
        Z.call(this, a, 1170);
        this.nd = b;
        this.K = c;
        this.ba = d;
        this.localStorage = e;
        this.A = Date.now();
        this.j = {
            hi: X(this)
        };
        b === 2 && this.localStorage && (this.j.rh = X(this), this.j.yf = X(this));
        this.I = Y(this, f);
        this.G = Y(this, g);
        h && (this.C = WM(this, h));
        l && (this.U = Y(this, l));
        k && _.I(vK) && (this.R = WM(this, k))
    };
    _.T(Uv, Z);
    Uv.prototype.g = function() {
        var a = this.I.value,
            b;
        if (this.G.value && a.length && ((b = this.U) == null || !b.value) && nv(this.A)) {
            b = new L(this.context.S, 56);
            _.Sq(this, b);
            if (this.nd === 2 && this.localStorage) {
                var c, d;
                var e = new lV(this.context, this.ba, this.localStorage, this.A, a, (d = (c = this.C) == null ? void 0 : c.value) != null ? d : void 0, this.j.rh);
                M(b, e);
                e = e.j;
                c = new kV(this.context, a, e, this.j.yf);
                M(b, c)
            }
            var f, g, h, l;
            a = new iV(this.context, this.nd, a, this.K, e, (h = (f = this.C) == null ? void 0 : f.value) != null ? h : void 0, this.j.yf, (l = (g = this.R) == null ? void 0 : g.value) != null ? l : void 0, this.j.hi);
            M(b, a);
            b.run()
        } else {
            this.j.hi.ha();
            var k;
            (k = this.j.rh) == null || k.ha();
            var m;
            (m = this.j.yf) == null || m.ha()
        }
    };
    var mV = function(a, b, c) {
        Z.call(this, a, 1216);
        this.j = b;
        this.output = UM(this);
        this.A = Y(this, c)
    };
    _.T(mV, Z);
    mV.prototype.g = function() {
        var a = this,
            b = this.A.value,
            c = new _.z.Map;
        if (b.length) {
            var d = this.j;
            b = b.map(function(e) {
                return d.createAuctionNonce().then(function(f) {
                    c.set(e, f)
                }).catch(function(f) {
                    a.reportError(f)
                })
            });
            this.output.pb(_.z.Promise.all(b).then(function() {
                return c
            }))
        } else this.output.H(c)
    };
    var Wv = {
        pps: {
            Cb: function(a, b, c) {
                c === null ? (b = _.Hk(a, Ru, 33), _.vj(b, 2)) : (a = _.Hk(_.Hk(a, Ru, 33), GQ, 2), _.vj(a, 1), pc(c) && c.hasOwnProperty("taxonomies") ? lu(c.taxonomies, a, b, c) : Q(b, wn("googletag.setConfig.pps", [c])))
            },
            methodName: 1283
        },
        privacyTreatments: {
            Cb: function(a, b, c) {
                _.vj(a, 36);
                a: {
                    if (c !== null && pc(c) && _.w(Object, "hasOwn").call(Object, c, "treatments")) {
                        c = c.treatments;
                        if (jA(c) && c.every(ou)) {
                            c = {
                                treatments: c
                            };
                            break a
                        }
                        Q(b, wn("googletag.setConfig", [c]))
                    }
                    c = void 0
                }
                var d = c;
                if (d !== void 0) {
                    c = new _.z.Set;
                    d = _.y(d.treatments);
                    for (var e = d.next(); !e.done; e = d.next()) {
                        e = e.value;
                        a: {
                            switch (e) {
                                case "disablePersonalization":
                                    var f = 1;
                                    break a
                            }
                            f = void 0
                        }
                        f === void 0 ? Q(b, wn("googletag.setConfig", [e])) : c.add(f)
                    }
                    c.size && (b = new EQ, b = _.df(b, 1, _.Vc, c, _.Xc, void 0, !0), _.Wg(a, 36, b))
                }
            },
            methodName: 1284
        },
        headerBidding: {
            Cb: function(a, b, c) {
                !Tp(c) && pc(c) && _.w(Object, "hasOwn").call(Object, c, "enableHeaderBiddingTraffickingPrebidIntegration") && (b = c.enableHeaderBiddingTraffickingPrebidIntegration, Ac(b) && _.Dl(a, 38, b))
            },
            methodName: 1285
        },
        adExpansion: {
            Cb: function(a, b, c) {
                _.vj(a, 34);
                Tp(c) || (pc(c) ? _.w(Object, "hasOwn").call(Object, c, "enabled") && (c = c.enabled, Ac(c) ? (b = Up(c), _.Wg(a, 34, b)) : Q(b, wn("googletag.setConfig.adExpansion.enabled", [c]))) : Q(b, wn("googletag.setConfig.adExpansion", [c])))
            },
            methodName: 1286
        },
        threadYield: {
            Cb: function(a, b, c) {
                Tu(a, b, c, "threadYield")
            },
            methodName: 1287
        },
        adYield: {
            Cb: function(a, b, c) {
                Q(b, Qu("adYield", "threadYield"));
                Tu(a, b, c, "adYield")
            },
            methodName: 1289
        },
        pair: {
            Cb: function(a, b, c, d) {
                if (!hA(c)) {
                    if (Tp(c)) {
                        var e;
                        d.secureSignalProviders = (e = d.secureSignalProviders) != null ? e : [];
                        Zt(d.secureSignalProviders) ? d.secureSignalProviders.length = 0 : d.secureSignalProviders.clearAllCache()
                    }
                    if (typeof c === "function") {
                        var f;
                        d.secureSignalProviders = (f = d.secureSignalProviders) != null ? f : [];
                        d.secureSignalProviders.push({
                            id: "google.com",
                            collectorFunction: c
                        })
                    }
                }
            },
            methodName: 1290
        }
    };
    var hw = new _.z.Set,
        nV = function(a, b, c) {
            var d = 0,
                e = function() {
                    d = 0
                };
            return function(f) {
                d || (d = _.ca.setTimeout(e, b), a.apply(c, arguments))
            }
        }(function() {
            throw new HL("Reached Limit for addEventListener");
        }, 3E5),
        oV = function(a, b, c) {
            _.W.call(this);
            this.context = a;
            this.V = b;
            this.l = c;
            this.g = [];
            this.enabled = !1;
            this.C = 0;
            this.F = new _.z.Map;
            hw.add(this);
            this.V.info(zP(this.getName()))
        };
    _.T(oV, _.W);
    _.q = oV.prototype;
    _.q.isEnabled = function() {
        return this.enabled
    };
    _.q.enable = function() {
        this.enabled || (this.enabled = !0, fp(6, this.context), this.G())
    };
    _.q.slotAdded = function(a, b) {
        this.g.push(a);
        var c = new CT(a, this.getName());
        this.l.dispatchEvent("slotAdded", 818, c);
        this.V.info(AP(this.getName(), a.getAdUnitPath()), a);
        a = this.getName();
        _.df(b, 4, _.Bd, a, Dd)
    };
    _.q.destroySlots = function(a) {
        var b = this;
        return a.filter(function(c) {
            return bb(b.g, c)
        })
    };
    _.q.addEventListener = function(a, b, c) {
        var d = this;
        c = c === void 0 ? window : c;
        if (this.C >= _.K(jJ) && _.K(jJ) > 0) return nV(), !1;
        if (!c.IntersectionObserver && (_.E = ["impressionViewable", "slotVisibilityChanged"], _.w(_.E, "includes")).call(_.E, a)) return Q(this.V, nQ()), !1;
        var e;
        if ((e = this.F.get(a)) == null ? 0 : e.has(b)) return !1;
        this.F.has(a) || this.F.set(a, new _.z.Map);
        c = function(f) {
            f = f.detail;
            try {
                b(f)
            } catch (g) {
                d.V.error(PP(String(g), a))
            }
        };
        this.F.get(a).set(b, c);
        this.l.listen(a, c);
        this.C++;
        return !0
    };
    _.q.removeEventListener = function(a, b) {
        var c, d = (c = this.F.get(a)) == null ? void 0 : c.get(b);
        if (!d || !NO(this.l, a, d)) return !1;
        this.C--;
        return this.F.get(a).delete(b)
    };
    var $v = function(a) {
        for (var b = _.y(hw), c = b.next(); !c.done; c = b.next()) c.value.destroySlots(a)
    };
    var dw = function(a, b, c, d) {
        oV.call(this, a, b, d);
        this.jc = c;
        this.ads = new _.z.Map;
        this.td = !1
    };
    _.T(dw, oV);
    dw.prototype.setRefreshUnfilledSlots = function(a) {
        typeof a === "boolean" && (this.td = a)
    };
    var AQ = function(a, b) {
            var c;
            return a.jc.isEnabled() && !((c = a.ads.get(b)) == null || !c.Ko)
        },
        BQ = function(a, b, c, d) {
            b = new wT(b, a.getName());
            c != null && d != null && (b.size = [c, d]);
            a.l.dispatchEvent("slotRenderEnded", 67, b)
        };
    dw.prototype.getName = function() {
        return "companion_ads"
    };
    dw.prototype.slotAdded = function(a, b) {
        var c = this;
        a.listen(QO, function(d) {
            _.R(d.detail, 11) && (pV(c, a).Ko = !0)
        });
        oV.prototype.slotAdded.call(this, a, b)
    };
    dw.prototype.G = function() {};
    var pV = function(a, b) {
            var c = a.ads.get(b);
            c || (c = {}, a.ads.set(b, c), _.$q(b, function() {
                return a.ads.delete(b)
            }));
            return c
        },
        yQ = function(a, b) {
            var c = qo().g,
                d = qo().bb;
            if (a.jc.isEnabled()) {
                var e = {
                    kc: 3
                };
                a.j && (e.Ud = a.j);
                a.A && (e.Vd = a.A);
                b = b != null ? b : a.g;
                c = ro(c, d);
                d = e.Ud;
                var f = e.Vd;
                d && typeof d !== "number" || f && typeof f !== "number" || a.jc.refresh(c, b, e)
            } else(b == null ? 0 : b[0]) && a.V.error(GP(b[0].getDomId()))
        },
        zQ = function(a, b) {
            return a.g.filter(function(c) {
                return _.w(b, "includes").call(b, c.toString())
            })
        };
    var ew = function(a, b, c) {
        oV.call(this, a, b, c)
    };
    _.T(ew, oV);
    ew.prototype.getName = function() {
        return "content"
    };
    ew.prototype.G = function() {};
    var qV = Ny(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl_", ".js"]),
        rV = Ny(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl_", ".js"]),
        sV = new _.z.Map([
            [2, {
                Th: "page_level_ads"
            }],
            [5, {
                Th: "shoppit"
            }],
            [6, {
                Th: "side_rails"
            }]
        ]),
        tV = function(a) {
            var b = b === void 0 ? sV : b;
            this.context = a;
            this.g = b;
            this.o = new _.z.Map;
            this.loaded = new _.z.Set
        },
        vV;
    tV.prototype.load = function(a) {
        var b = _.uV(this, a),
            c, d = ((c = this.g.get(a.module)) != null ? c : {}).Th;
        if (!d) throw Error("cannot load invalid module: " + d);
        if (!this.loaded.has(a.module)) {
            d = (c = _.Vn(172)) && aE((c.src || "").match(_.$D)[3] || null) === "pagead2.googlesyndication.com" ? _.ng(rV, this.context.Ra, d) : _.ng(qV, this.context.Ra, d);
            c = {};
            var e = _.K(NJ);
            e && (c.cb = e);
            d = _.w(Object, "keys").call(Object, c).length ? pg(d, new _.z.Map(_.w(Object, "entries").call(Object, c))) : d;
            vV(this, a);
            _.Cr(document, d);
            this.loaded.add(a.module)
        }
        return b.promise
    };
    _.uV = function(a, b) {
        b = b.module;
        a.o.has(b) || a.o.set(b, new _.Aj);
        return a.o.get(b)
    };
    vV = function(a, b) {
        var c = b.module;
        b = "_gpt_js_load_" + c + "_";
        var d = on(a.context, 340, function(e) {
            if (a.g.has(c) && typeof e === "function") {
                var f = a.g.get(c);
                f = (f.Sm === void 0 ? [] : f.Sm).map(function(g) {
                    return _.uV(a, g).promise
                });
                _.z.Promise.all(f).then(function() {
                    e.call(window, _, a)
                })
            }
        });
        Object.defineProperty(Sp(), b, {
            value: function(e) {
                if (d) {
                    var f = d;
                    d = null;
                    f(e)
                }
            },
            writable: !1,
            enumerable: !1
        })
    };
    var Aw = function(a, b) {
        Z.call(this, a, 980);
        this.output = new qu;
        this.j = Y(this, b)
    };
    _.T(Aw, Z);
    Aw.prototype.g = function() {
        for (var a = _.y(this.j.value), b = a.next(); !b.done; b = a.next()) Ti(b.value);
        this.output.notify()
    };
    var ww = Sj(892, function(a) {
        a = a.config;
        if (!a) throw Error("no per-pub config");
        var b, c, d, e, f, g, h, l = (c = _.Fi(a, qC, 3)) != null ? c : null;
        c = (d = _.Fi(a, sC, 2)) != null ? d : null;
        d = Dv(a, 4);
        d = d != null ? d : [];
        var k = _.ul(a, lC, 11, _.wl());
        k = k != null ? k : [];
        var m = _.ul(a, kC, 6, _.wl());
        var n = _.ul(a, CC, 5, _.wl());
        var p = (e = _.Fi(a, BC, 7)) != null ? e : null;
        e = _.z.Set;
        var r;
        (b = _.Fi(a, nC, 1)) == null ? r = void 0 : r = _.Ou(b, 6, _.wl());
        return {
            eb: l,
            Bc: c,
            Xc: d,
            le: k,
            ke: m,
            sd: n,
            Ci: p,
            Ti: new e(r),
            je: (f = _.Fi(a, EC, 8)) != null ? f : null,
            Ni: (g = _.Fi(a, FC, 9)) != null ? g : null,
            od: (h = _.Fi(a, uC, 10)) != null ? h : null
        }
    }, {
        eb: void 0,
        Bc: void 0,
        Xc: void 0,
        le: void 0,
        ke: void 0,
        sd: void 0,
        Ci: void 0,
        Ti: void 0,
        je: void 0,
        Ni: void 0,
        od: void 0
    }, function(a) {
        return {
            eb: a,
            Bc: a,
            Xc: [],
            le: [],
            ke: [],
            sd: [],
            Ci: null,
            Ti: new _.z.Set,
            je: null,
            Ni: null,
            od: null
        }
    });
    var tw = function(a, b) {
        Z.call(this, a, 891);
        var c = this;
        this.j = X(this);
        this.error = void 0;
        var d = X(this);
        this.A = Y(this, d);
        b(function(e, f) {
            if (f) c.error = f, d.H([]);
            else try {
                if (typeof e === "string") {
                    var g = JSON.parse(e || "[]");
                    Array.isArray(g) && d.H(g)
                }
            } catch (h) {} finally {
                d.Qd || (c.error = Error("malformed response"), d.H([]))
            }
        })
    };
    _.T(tw, Z);
    tw.prototype.g = function() {
        if (this.error) throw this.error;
        this.j.H(kf(GC, this.A.value))
    };
    var zw = Sj(1281, function(a) {
        a = _.y(a.So);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = _.Fi(b, xC, 4);
            if (c && _.Im(b, DC) === 8) return {
                dd: c
            }
        }
        return {
            dd: null
        }
    }, {
        dd: void 0
    });
    var Cy = function(a) {
        aN.call(this, function(b, c) {
            qn(a, b, c);
            var d;
            (d = console) == null || d.error(c)
        })
    };
    _.T(Cy, aN);
    var Uw = Ny(["var inDapIF=true,inGptIF=true;"]),
        wV = function() {
            dV.apply(this, arguments)
        };
    _.T(wV, dV);
    wV.prototype.F = function() {
        var a = this.g,
            b = a.dl;
        a = a.zf;
        var c = eV(this);
        if (b == null ? 0 : b.length)
            if (Rz) {
                b = _.y(b);
                for (var d = b.next(); !d.done; d = b.next()) c.sandbox.add(d.value)
            } else c.sandbox.add.apply(c.sandbox, _.Zk(b));
        a && (c.allow = a);
        fV(this, c);
        xV(this, c, this.ya.nb);
        return c
    };
    wV.prototype.j = function() {
        return !0
    };
    var xV = function(a, b, c) {
        function d() {
            var k, m, n = (m = (k = b.contentWindow) == null ? void 0 : k.document) != null ? m : b.contentDocument;
            if (!n) return !1;
            _.sa() && n.open("text/html", "replace");
            n.write(_.Ra(e));
            var p, r, v;
            if (uz((v = (p = b.contentWindow) == null ? void 0 : (r = p.location) == null ? void 0 : r.href) != null ? v : "", "#")) {
                var u, x;
                (u = b.contentWindow) == null || (x = u.history) == null || x.replaceState(null, "", "#" + Math.random())
            }
            n.close();
            return !0
        }
        var e = Vw(Au(c));
        if (!d()) {
            c = a.g;
            var f = c.ga,
                g = c.V,
                h = c.slotId,
                l = new MutationObserver(function() {
                    d() && (Q(g, vQ(), h), l.disconnect())
                });
            _.$q(a, function() {
                return void l.disconnect()
            });
            l.observe(f, {
                childList: !0,
                subtree: !0
            });
            Q(g, uQ(), h)
        }
    };
    var sx = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u, x, D, F, C, G, S, P, J, U, ha, ea) {
        Z.call(this, a, 680);
        this.slotId = b;
        this.L = c;
        this.V = d;
        this.K = e;
        this.Ha = f;
        this.Ab = g;
        this.Zc = h;
        this.lb = l;
        this.isBackfill = k;
        this.oc = m;
        this.fa = n;
        this.B = p;
        this.Fa = X(this);
        this.A = X(this);
        this.j = VM(this);
        this.G = Y(this, r);
        this.ca = Y(this, v);
        YM(this, u);
        this.I = Y(this, x);
        this.C = Y(this, D);
        this.Ue = Y(this, F);
        YM(this, G);
        this.ia = WM(this, C);
        YM(this, S);
        this.U = Y(this, P);
        YM(this, J);
        ha && YM(this, ha);
        U && (this.R = WM(this, U));
        ea && YM(this, ea)
    };
    _.T(sx, Z);
    sx.prototype.g = function() {
        var a = this.G.value;
        if (a.kind === 0 && a.nb == null) throw new IL("invalid html");
        var b, c, d;
        a: {
            var e = this.context,
                f = {
                    ga: document,
                    slotId: this.slotId,
                    L: this.L,
                    V: this.V,
                    K: this.K,
                    Ha: this.Ha,
                    size: this.Ue.value,
                    Da: this.I.value,
                    rb: this.C.value,
                    lb: this.lb,
                    Zc: this.Zc,
                    dl: this.ia.value,
                    isBackfill: this.isBackfill,
                    oc: this.oc,
                    zf: this.U.value,
                    Up: (b = this.fa) == null ? void 0 : _.R(b, 14),
                    zg: (c = this.R) == null ? void 0 : c.value,
                    Ab: this.Ab,
                    hl: _.I(wK) ? (d = this.fa) == null ? void 0 : TD(d) : void 0
                };b = this.ca.value;c = a.kind;
            switch (c) {
                case 0:
                    a = new(b ? wU : wV)(e, a, f);
                    break a;
                case 1:
                    a = new gV(e, a, f);
                    break a;
                default:
                    Sa(c)
            }
            a = void 0
        }
        _.Sq(this, a);
        e = a.render();
        yV(this, this.B, e);
        this.B.top && this.B.top !== this.B && _.um(this.B.top) && yV(this, this.B.top, e);
        this.j.notify();
        this.Fa.H(e);
        this.A.H(a.j())
    };
    var yV = function(a, b, c) {
        pt(a, a.id, b, "message", function(d) {
            c.contentWindow === d.source && a.slotId.dispatchEvent(Ft, 824, d)
        })
    };
    var $w = function(a, b, c, d, e) {
        Z.call(this, a, 720);
        this.format = b;
        this.sa = c;
        this.gb = d;
        this.height = e;
        this.output = X(this)
    };
    _.T($w, Z);
    $w.prototype.g = function() {
        if (this.height == null) this.output.ha();
        else {
            var a = Math.round(this.sa * .3),
                b;
            this.format !== 2 && this.format !== 3 || (b = this.gb) == null || !_.R(b, 12, !1) || a <= 0 || this.height <= a ? this.output.H(this.height) : this.output.H(a)
        }
    };
    var ix = function(a, b, c, d, e, f, g, h, l, k, m) {
        Z.call(this, a, 674);
        this.slotId = b;
        this.Z = c;
        this.bb = d;
        this.ga = f;
        this.L = g;
        this.lc = m;
        this.output = X(this);
        this.C = e === 2 || e === 3;
        this.j = Y(this, h);
        this.A = Y(this, l);
        k && YM(this, k)
    };
    _.T(ix, Z);
    ix.prototype.g = function() {
        var a;
        if ((a = this.lc) == null ? 0 : a.parentElement) this.output.H(this.lc.parentElement);
        else {
            a = Zr(this.Z, this.bb);
            var b = uo(this.slotId, this.ga) || xs(this.j.value, Do(this.slotId), a);
            this.A.value && !a && (b.style.display = "inline-block");
            this.C ? ZO(this.L, this.slotId, function() {
                return void _.LE(b)
            }) : _.$q(this, function() {
                return void _.LE(b)
            });
            this.output.H(b)
        }
    };
    var Yw = function(a, b) {
        Z.call(this, a, 859);
        this.B = b;
        this.output = X(this)
    };
    _.T(Yw, Z);
    Yw.prototype.g = function() {
        this.output.H(!_.um(this.B.top))
    };
    var nx = function(a, b, c) {
        Z.call(this, a, 840);
        this.format = b;
        this.ga = c;
        this.output = X(this)
    };
    _.T(nx, Z);
    nx.prototype.g = function() {
        for (var a = [], b = _.y(["private-state-token-redemption", "attribution-reporting"]), c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            var d = void 0,
                e = c,
                f = this.ga;
            f = f === void 0 ? document : f;
            (d = f.featurePolicy) != null && (_.E = d.features(), _.w(_.E, "includes")).call(_.E, e) && a.push(c)
        }
        switch (this.format) {
            case 5:
            case 4:
            case 7:
                a.push("autoplay")
        }
        this.output.H(a.join(";"))
    };
    var Hx = function(a, b, c, d) {
        Z.call(this, a, 1207);
        this.Ha = c;
        this.slotId = d;
        YM(this, b)
    };
    _.T(Hx, Z);
    Hx.prototype.g = function() {
        this.Ha.dispatchEvent("impressionViewable", 715, new zT(this.slotId, "publisher_ads"))
    };
    var Gx = function(a, b, c, d) {
        QT.call(this, a, b, c);
        YM(this, d)
    };
    _.T(Gx, QT);
    var Ex = function(a, b, c, d, e) {
        L.call(this, a.S);
        var f = new Et(e, Fx, this);
        c = M(this, new Gx(a, c, d, f.output));
        M(this, new Hx(a, c.output, b, e));
        this.output = c.output
    };
    _.T(Ex, L);
    var hx = Sj(674, function(a, b, c, d, e, f, g, h, l) {
        if (h == null ? 0 : h.parentElement) return {
            rb: h.parentElement
        };
        h = a.Da;
        a = a.Xb;
        f = Zr(f, g);
        var k, m = (k = uo(b, d)) != null ? k : xs(h, Do(b), f);
        a && !f && (m.style.display = "inline-block");
        c === 2 || c === 3 ? ZO(e, b, function() {
            return void _.LE(m)
        }) : _.$q(l, function() {
            return void _.LE(m)
        });
        return {
            rb: m
        }
    }, {
        rb: void 0
    });
    var Ax = function(a, b, c, d, e, f) {
        f = f === void 0 ? Ww : f;
        Z.call(this, a, 783);
        var g = this;
        this.slotId = b;
        this.ga = d;
        this.Ha = e;
        this.G = f;
        this.j = this.A = -1;
        this.I = _.CB(function() {
            g.Ha.dispatchEvent("slotVisibilityChanged", 716, new AT(g.slotId, "publisher_ads", g.j))
        }, 200);
        this.C = Y(this, c);
        var h = new qu;
        OO(this.slotId).then(function() {
            return void h.notify()
        });
        YM(this, h)
    };
    _.T(Ax, Z);
    Ax.prototype.g = function() {
        var a = this,
            b = on(this.context, this.id, function(d) {
                d = _.y(d);
                for (var e = d.next(); !e.done; e = d.next()) a.A = e.value.intersectionRatio * 100, _.w(Number, "isFinite").call(Number, a.A) && zV(a)
            }),
            c = this.G(b);
        c && (c.observe(this.C.value), pt(this, this.id, this.ga, "visibilitychange", function() {
            zV(a)
        }), _.$q(this, function() {
            c.disconnect()
        }))
    };
    var zV = function(a) {
        var b = Math.floor(gM(a.ga) ? 0 : a.A);
        if (b < 0 || b > 100 || b === a.j ? 0 : a.j !== -1 || b !== 0) a.j = b, a.I()
    };
    var AV = new _.z.Set,
        Vx = Sj(1291, function(a, b, c, d, e) {
            a = Xw(c);
            var f = c.getAdUnitPath(),
                g = _.IA(c, 2),
                h = _.K(mJ);
            if (!(a && f && g && d && e)) return {};
            if (Wp(c) === 1 && a.height === 1 && a.width === 1 && (d !== 1 || e !== 1) && !AV.has(g)) {
                var l = CG(BG(AG(zG(f), g), e), d);
                b.O.log(684553008, function() {
                    var k = new EG;
                    k = _.Fk(k, 1, b.pvsid);
                    k = _.Fk(k, 2, h);
                    return _.en(k, 3, FG, l)
                }, {
                    Ta: h
                });
                AV.add(g)
            }
            return {}
        }, {});
    var lx = function(a, b, c, d, e, f) {
        Z.call(this, a, 719);
        this.Z = b;
        this.bb = c;
        this.Ri = d;
        this.output = X(this);
        this.j = Y(this, e);
        this.A = Y(this, f)
    };
    _.T(lx, Z);
    lx.prototype.g = function() {
        if (this.j.value.kind !== 0) this.output.ha();
        else if (this.j.value.nb)
            if (this.A.value) {
                var a = new Zo;
                a = _.Dl(a, 3, this.Ri);
                _.R(ep([a, this.Z.bd(), this.bb.bd()]), 3) ? this.output.H($N) : this.output.ha()
            } else this.output.ha();
        else this.output.ha()
    };
    var BV = Sj(1119, function(a, b, c, d, e, f, g) {
        var h = _.Fh("INS");
        a = function() {
            return void _.LE(h)
        };
        if (f === 6) return _.$q(g, a), {
            Da: h
        };
        h.id = c;
        fo(f) && !(_.E = [8, 9], _.w(_.E, "includes")).call(_.E, f) && _.ds(h, {
            display: "none"
        });
        d.appendChild(h);
        (_.E = [2, 3], _.w(_.E, "includes")).call(_.E, f) ? ZO(e, b, a) : _.$q(g, a);
        return {
            Da: h
        }
    }, {
        Da: void 0
    });
    var CV = Sj(1120, function(a, b, c, d) {
        if ((_.E = [2, 3], _.w(_.E, "includes")).call(_.E, c)) return {
            Da: a.Da
        };
        c = _.y(_.w(Array, "from").call(Array, a.Da.childNodes));
        for (var e = c.next(); !e.done; e = c.next()) e = e.value, e.nodeType === 1 && e.id !== b && _.LE(e);
        d || (a.Da.style.display = "");
        return {
            Da: a.Da
        }
    }, {
        Da: void 0
    });
    var ax = function(a, b, c, d, e, f, g, h, l) {
        L.call(this, a.S, 63);
        c ? (a = new Ws, a.H(c), e = this.g(CV, {
            Da: a
        }, e, g, l).Da) : fo(g) ? e = this.g(BV, {}, b, d, f, h, g, this).Da : (c = new Vt(b, PO, function(k) {
            return k.detail
        }, this), e = this.g(CV, {
            Da: c.output
        }, e, g, l).Da);
        this.output = e
    };
    _.T(ax, L);
    var DV = function(a, b) {
            var c = qo();
            this.context = a;
            this.L = b;
            this.g = c
        },
        EV = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u, x) {
            var D = document,
                F = window;
            e || f || fP(a.L, d);
            var C = Wx(a.context, b, a.g, c, d, e, f, g, h, l, k, D, m, n, p, r, v, function() {
                fP(a.L, d);
                eP(a.L, d, C)
            }, u, x);
            f || eP(a.L, d, C);
            _.$q(d, function() {
                fP(a.L, d)
            });
            F.top !== F && F.addEventListener("pagehide", function(G) {
                G.persisted || fP(a.L, d)
            });
            C.run()
        };
    var FV = function(a, b, c, d) {
        Z.call(this, a, 884);
        this.Xa = b;
        this.Bb = c;
        this.A = X(this);
        this.j = Y(this, d)
    };
    _.T(FV, Z);
    FV.prototype.g = function() {
        SR(this.Bb, _.gp(this.Xa, "__gads", this.j.value));
        ip(20, this.context, this.Xa, this.j.value);
        ip(2, this.context, this.Xa, this.j.value);
        this.A.H(Ui())
    };
    var Xx = 0,
        GV = new _.io(-9, -9);
    var ay = new _.z.Set([function(a, b) {
        var c = a.la.context.pvsid;
        a = a.ja.K.Z;
        b.set("pvsid", {
            value: c
        }).set("correlator", {
            value: ev(a, 26)
        })
    }, function(a, b) {
        var c = a.ja.K.Z;
        var d = a.Yp;
        a = d.Vd;
        d = d.Ud;
        var e = _.R(c, 21);
        b = b.set("hxva", {
            value: e ? 1 : null
        }).set("cmsid", {
            value: e ? xl(c, 23) : null
        }).set("vid", {
            value: e ? xl(c, 22) : null
        }).set("pod", {
            value: d
        }).set("ppos", {
            value: a
        });
        a = b.set;
        c = xA(c, 29);
        a.call(b, "scor", {
            value: c == null ? void 0 : c
        })
    }, function(a, b) {
        var c = a.la.Xc;
        var d = a.ja;
        var e = d.T;
        var f = d.K.W;
        a = a.sd;
        var g = a.Ln;
        var h = a.zn;
        c = {
            value: c
        };
        _.I(eK) && (c.options = {
            Pa: "~"
        });
        b.set("eid", c).set("debug_experiment_id", {
            value: LL().split(",")
        }).set("expflags", {
            value: _.Vn(253) ? dj(lJ) || null : null
        }).set("pied", {
            value: function() {
                var l = new dN,
                    k = !1,
                    m = !1;
                g && (k = !0, Fl(l, 1, xC, g));
                var n = e.map(function(r) {
                    var v = new bN,
                        u, x;
                    (u = f[r.getDomId()]) == null ? x = void 0 : x = _.ul(u, xC, 27, _.wl());
                    r = x;
                    if (r == null || !r.length) return v;
                    m = k = !0;
                    r = _.y(r);
                    for (u = r.next(); !u.done; u = r.next()) Fl(v, 1, xC, u.value);
                    return v
                });
                m && _.Qn(l, 2, n);
                n = _.y(h != null ? h : []);
                for (var p = n.next(); !p.done; p = n.next()) Fl(l, 1, xC, p.value), k = !0;
                return k ? Ab(l.g(), 3) : null
            }()
        })
    }, function(a, b) {
        var c = a.la;
        a = c.context;
        c = c.hd;
        b.set("output", {
            value: "ldjh"
        }).set("gdfp_req", {
            value: 1
        }).set("vrg", {
            value: a.Df
        }).set("ptt", {
            value: 17
        }).set("impl", {
            value: c ? "fifs" : "fif"
        })
    }, function(a, b) {
        var c = a.ja.K.Z;
        a = a.la.ba;
        c = by(c) || new CQ;
        var d = _.Sh(c, 6, 2);
        b.set("rdp", {
            value: _.R(c, 1) ? "1" : null
        }).set("ltd", {
            value: _.R(c, 9) ? "1" : null
        }).set("gdpr_consent", {
            value: _.IA(a, 2)
        }).set("gdpr", {
            value: dp(a, 3) ? _.R(a, 3) ? "1" : "0" : null,
            options: {
                Ia: !0
            }
        }).set("addtl_consent", {
            value: _.IA(a, 4)
        }).set("tcfe", {
            value: JA(a, 7)
        }).set("us_privacy", {
            value: _.IA(a, 1)
        }).set("npa", {
            value: _.R(c, 8) ? 1 : null
        }).set("tfua", {
            value: d !== 2 ? d : null,
            options: {
                Ia: !0
            }
        }).set("tfcd", {
            value: _.Xc(_.tA(c, 5)) != null ? _.Sh(c, 5, 0) : null,
            options: {
                Ia: !0
            }
        }).set("trt", {
            value: _.Xc(_.tA(c, 10)) != null ? _.Sh(c, 10, 0) : null,
            options: {
                Ia: !0
            }
        }).set("tad", {
            value: _.I($x) && dp(a, 8) ? _.R(a, 8) ? "1" : "0" : null,
            options: {
                Ia: !0
            }
        }).set("gpp", {
            value: _.IA(a, 11)
        }).set("gpp_sid", {
            value: yA(a, 10, _.wl()).join(",") || void 0
        }).set("scd", {
            value: dp(c, 14) ? "1" : null
        })
    }, function(a, b) {
        var c = a.ja;
        var d = c.K;
        var e = c.T;
        var f = c.th;
        a = a.la;
        var g = a.L;
        var h = a.B;
        var l = e.map(function(m) {
                return d.W[m.getDomId()]
            }),
            k = [];
        a = e.map(function(m) {
            return m.getAdUnitPath().replace(/,/g, ":").split("/").map(function(n) {
                if (!n) return "";
                var p = _.w(k, "findIndex").call(k, function(r) {
                    return r === n
                });
                return p >= 0 ? p : k.push(n) - 1
            }).join("/")
        });
        b.set("iu_parts", {
            value: k
        }).set("enc_prev_ius", {
            value: a
        }).set("prev_iu_szs", {
            value: l.map(function(m) {
                return eo(m)
            })
        }).set("fluid", {
            value: function() {
                var m = !1,
                    n = l.map(function(p) {
                        p = (_.E = co(p), _.w(_.E, "includes")).call(_.E, "fluid");
                        m || (m = p);
                        return p ? "height" : "0"
                    });
                return m ? n : null
            }()
        }).set("ifi", {
            value: function() {
                if (_.K(QJ) > 0 && gP(g, e[0]) > 0) return iP(g, e[0]);
                var m = qs(h);
                f || (m += 1, _.K(QJ) > 0 && e.forEach(function(n) {
                    var p = m;
                    if (n = g.g.get(n)) n.fi = p
                }), ZE(h, e.length));
                return m
            }()
        }).set("didk", {
            value: _.I(ZJ) ? Vs(e, function(m) {
                return _.aj(m.getDomId())
            }) : null,
            options: _.w(Object, "assign").call(Object, {}, {
                Pa: "~"
            }, {
                jd: !0
            })
        })
    }, function(a, b) {
        var c = a.ja;
        a = c.T;
        c = c.K;
        var d = c.Z;
        var e = c.W;
        b.set("sfv", {
            value: RQ ? RQ : RQ = To()
        }).set("fsfs", {
            value: Vs(a, function(f) {
                f = e[f.getDomId()];
                var g;
                return Number((g = f == null ? void 0 : Yr(f, 12)) != null ? g : Rc(_.tA(d, 13)))
            }),
            options: {
                Pa: ",",
                ge: 0,
                jd: !0
            }
        }).set("fsbs", {
            value: Vs(a, function(f) {
                f = e[f.getDomId()].bd();
                var g = d.bd(),
                    h;
                return ((h = f == null ? void 0 : Yr(f, 3)) != null ? h : g == null ? 0 : _.R(g, 3)) ? 1 : 0
            }),
            options: {
                ge: 0,
                jd: !0
            }
        })
    }, function(a, b) {
        var c = a.la.L;
        var d = a.ja;
        a = d.T;
        var e = d.th;
        b.set("rcs", {
            value: Vs(a, function(f) {
                if (!(e || _.K(QJ) !== 0 && gP(c, f) !== 0)) {
                    var g = c.g.get(f);
                    g && g.Zk++
                }
                return rt(c, f)
            }),
            options: {
                ge: 0,
                jd: !0
            }
        })
    }, function(a, b) {
        var c = a.ja;
        var d = c.K.W;
        c = c.T;
        a = a.la.hd;
        d = d[c[0].getDomId()];
        b.set("click", {
            value: !a && d.getClickUrl() ? xl(d, 7) : null
        })
    }, function(a, b, c) {
        var d = a.ja;
        var e = d.T;
        var f = d.K.W;
        a = a.la;
        var g = a.ba;
        var h = a.B;
        c = c === void 0 ? function(n, p) {
            return wi(n, p)
        } : c;
        a = e.map(function(n) {
            return f[n.getDomId()]
        });
        var l, k, m;
        b.set("ists", {
            value: Ts(a, St) || null
        }).set("fas", {
            value: Vs(a, function(n) {
                return Iq(Wp(n))
            }),
            options: {
                ge: 0,
                jd: !0
            }
        }).set("itsi", {
            value: e.some(function(n) {
                var p;
                return !jR(n) && ((p = f[n.getDomId()]) == null ? void 0 : Wp(p)) === 5
            }) ? function() {
                var n = c(g, h);
                if (!n || _.I(Fq)) {
                    var p, r, v;
                    n = (v = (p = (_.E = _.w(Object, "values").call(Object, f), _.w(_.E, "find")).call(_.E, function(u) {
                        return _.zs(u, aq, 29)
                    })) == null ? void 0 : (r = _.Fi(p, aq, 29)) == null ? void 0 : _.R(r, 2)) != null ? v : !1;
                    return _.I(_.tJ) && !n ? -1 : 1
                }
                p = Rt(_.rk(n, 604800, "__lsv__"));
                return isFinite(p) ? Math.floor(Math.max((Date.now() - p) / 6E4, 1)) : null
            }() : null
        }).set("fsapi", {
            value: Ts(a, function(n) {
                return Wp(n) === 5
            }) || null
        }).set("ifs", {
            value: (m = (l = (_.E = _.w(Object, "values").call(Object, f), _.w(_.E, "find")).call(_.E, function(n) {
                return _.zs(n, aq, 29)
            })) == null ? void 0 : (k = _.Fi(l, aq, 29)) == null ? void 0 : Fm(k)) != null ? m : null
        }).set("dap", {
            value: function() {
                if (e.every(function(p) {
                        var r;
                        return jR(p) || !(_.E = [2, 3], _.w(_.E, "includes")).call(_.E, (r = f[p.getDomId()]) == null ? void 0 : Wp(r))
                    })) return null;
                var n = Rt(_.rk(c(g, h), 604800, "__lsa__"));
                return isFinite(n) ? Math.floor(Math.max((Date.now() - n) / 6E4, 1)) <= _.K(CJ) ? 3 : null : null
            }()
        })
    }, function(a, b) {
        var c = a.ja;
        a = c.T;
        var d = c.K.W;
        a = a.map(function(e) {
            return d[e.getDomId()]
        });
        b.set("rbvs", {
            value: Ts(a, function(e) {
                return Wp(e) === 4
            }) || null
        })
    }, function(a, b) {
        var c = a.ja;
        var d = c.K;
        var e = c.T;
        var f = c.kc;
        c = c.vh;
        var g = a.la;
        a = g.isSecureContext;
        var h = g.L;
        g = g.B;
        var l = b.set,
            k = d.Z,
            m = d.W,
            n = new qi;
        n.set(0, f !== 1);
        m = m[e[0].getDomId()];
        n.set(1, !!_.R(m, 17));
        n.set(2, lt(e, d));
        n.set(3, _.R(k, 27) || !1);
        n.set(4, f === 3);
        n.set(5, !c);
        _.K(QJ) > 0 && n.set(6, gP(h, e[0]) > 0);
        d = si(n);
        l.call(b, "eri", {
            value: d
        }).set("gct", {
            value: ft("google_preview", g)
        }).set("sc", {
            value: a ? 1 : 0,
            options: {
                Ia: !0
            }
        })
    }, function(a, b) {
        var c;
        a = (c = _.Fi(a.ja.K.Z, DQ, 5)) == null ? void 0 : _.HA(c, 2);
        a !== void 0 && a >= 0 && b.set("lrm", {
            value: a,
            options: {
                Ia: !0
            }
        })
    }, function(a, b) {
        a = a.la;
        var c = a.ba;
        var d = a.Xa;
        var e = _.gp(d, "__gads", c);
        a = _.gp(d, "__gpi_opt_out", c) === "1" ? "1" : null;
        b = b.set("cookie", {
            value: e,
            options: {
                Ia: !0
            }
        }).set("cookie_enabled", {
            value: !e && d.isSupported(c) ? "1" : null
        });
        e = b.set;
        c = (c = _.gp(d, "__gpi", c)) && !_.w(c, "includes").call(c, "&") ? c : null;
        e.call(b, "gpic", {
            value: c
        }).set("pdopt", {
            value: a
        })
    }, function(a, b) {
        var c = a.la.B;
        a = ht(a.ja.K.Z.Ya());
        var d = c.document,
            e = d.domain;
        b.set("cdm", {
            value: (a || go(c)) === d.URL ? "" : e
        })
    }, function(a, b) {
        a = a.la.B;
        b.set("arp", {
            value: as(a) ? 1 : null
        }).set("abxe", {
            value: _.um(a.top) || kE(a.IntersectionObserver) ? 1 : null
        })
    }, function(a, b) {
        var c = a.ja.K.Z;
        a = a.la.B;
        c = ht(c.Ya());
        b.set("dt", {
            value: (new Date).getTime()
        });
        if (!c) {
            try {
                var d = Math.round(Date.parse(a.document.lastModified) / 1E3) || null
            } catch (e) {
                d = null
            }
            b.set("lmt", {
                value: d
            })
        }
    }, function(a, b) {
        var c = a.ja;
        var d = c.K;
        c = c.T;
        a = a.la.B;
        for (var e = bo(!0, a), f = d.Z, g = a.document, h = d.W, l = [], k = [], m = _.y(c), n = m.next(); !n.done; n = m.next()) {
            var p = n.value,
                r = h[p.getDomId()],
                v = Zr(f, r);
            n = void 0;
            p = (n = Bo(p, r, g, v)) != null ? n : GV;
            l.push(Math.round(p.x));
            k.push(Math.round(p.y))
        }
        e && (d.aq = e);
        f = pi(a) ? null : bo(!1, a);
        try {
            var u = a.top;
            var x = st(u.document, u)
        } catch (D) {
            x = new _.io(-12245933, -12245933)
        }
        b.set("adxs", {
            value: l,
            options: {
                Ia: !0
            }
        }).set("adys", {
            value: k,
            options: {
                Ia: !0
            }
        }).set("biw", {
            value: e ? e.width : null
        }).set("bih", {
            value: e ? e.height : null
        }).set("isw", {
            value: e ? f == null ? void 0 : f.width : null
        }).set("ish", {
            value: e ? f == null ? void 0 : f.height : null
        }).set("scr_x", {
            value: Math.round(x.x),
            options: {
                Ia: !0
            }
        }).set("scr_y", {
            value: Math.round(x.y),
            options: {
                Ia: !0
            }
        }).set("btvi", {
            value: Yx(c, a, d),
            options: {
                Ia: !0,
                Pa: "|"
            }
        })
    }, function(a, b) {
        var c = a.ja.T;
        a = a.la;
        var d = a.L;
        var e = a.B;
        b.set("ucis", {
            value: c.map(function(f) {
                (f = d.g.get(f)) ? (f.oc != null || (f.oc = e === e.top ? (++d.G).toString(36) : Lz()), f = f.oc) : f = "";
                return f
            }),
            options: {
                Pa: "|"
            }
        }).set("oid", {
            value: 2
        })
    }, function(a, b) {
        a = a.ja;
        var c = a.T;
        a = a.K;
        var d = a.Z;
        var e = a.W;
        a = new _.z.Map;
        var f = Array(c.length),
            g = !1;
        d = _.y(d.Ya());
        for (var h = d.next(); !h.done; h = d.next())
            if (h = h.value, _.t(h, 1) === "tag_origin") {
                g = !0;
                for (var l = 0; l < c.length; l++) f[l] = [].concat(_.Zk(Ln(h)))
            } else a.set(_.t(h, 1), [Ln(h)[0]]);
        for (d = 0; d < c.length; d++)
            if (h = e[c[d].getDomId()])
                for (h = _.y(h.Ya()), l = h.next(); !l.done; l = h.next()) {
                    l = l.value;
                    var k = _.t(l, 1);
                    if (_.t(l, 1) === "tag_origin") {
                        g = !0;
                        var m = k = void 0;
                        (k = f)[m = d] || (k[m] = []);
                        f[d].push.apply(f[d], _.Zk(Ln(l)))
                    } else m = a.get(k) || [], l = Ln(l)[0], c.length === 1 ? m[0] = l : l !== m[0] && (m[d + 1] = l), a.set(k, m)
                }
        c = [];
        e = _.y(_.w(a, "keys").call(a));
        for (d = e.next(); !d.done; d = e.next()) h = d.value, d = Mo()[h], h = a.get(h), d && h && d !== "to" && (h.length > 1 ? (h = h.map(function(n) {
            return encodeURIComponent(n || "")
        }).join(), c.push(d + "," + h)) : h.length === 1 && d !== "url" && b.set(d, {
            value: h[0]
        }));
        c.length && b.set("sps", {
            value: c,
            options: {
                Pa: "|"
            }
        });
        b.set("tos", {
            value: g ? f.map(function(n) {
                return _.w(Array, "from").call(Array, new _.z.Set(n)).join("+")
            }) : void 0,
            options: {
                Pa: "~"
            }
        })
    }, function(a, b) {
        var c = a.la;
        a = c.context;
        var d = c.B;
        c = c.Do;
        var e, f, g, h, l, k, m;
        b.set("u_his", {
            value: YE(d)
        }).set("u_h", {
            value: (e = d.screen) == null ? void 0 : e.height
        }).set("u_w", {
            value: (f = d.screen) == null ? void 0 : f.width
        }).set("u_ah", {
            value: (g = d.screen) == null ? void 0 : g.availHeight
        }).set("u_aw", {
            value: (h = d.screen) == null ? void 0 : h.availWidth
        }).set("u_cd", {
            value: (l = d.screen) == null ? void 0 : l.colorDepth
        }).set("u_sd", {
            value: NL(d)
        }).set("u_tz", {
            value: -(new Date).getTimezoneOffset()
        }).set("dmc", {
            value: (m = (k = d.navigator) == null ? void 0 : k.deviceMemory) != null ? m : null
        }).set("bc", {
            value: ti(d)
        }).set("nvt", {
            value: c != null ? c : zj(d)
        }).set("bz", {
            value: function() {
                var p = _.K($I);
                return p === 0 ? null : xE(d, p === 2)
            }()
        }).set("tl", {
            value: _.I(cK) ? pn(a, 1232, function() {
                var p;
                var r;
                if (r = _.ta()) {
                    var v;
                    r = (p = d.document) == null ? void 0 : (v = p.documentElement) == null ? void 0 : v.classList;
                    r = !!((r == null ? 0 : r.contains("translated-rtl")) || (r == null ? 0 : r.contains("translated-ltr")))
                }
                p = r ? d.document.documentElement.lang : void 0;
                return p
            }, !0) : null
        });
        var n;
        _.I(bK) && ((n = d.matchMedia) == null ? 0 : n.call(d, "(prefers-color-scheme: dark)").matches) && b.set("dmp", {
            value: 1
        })
    }, function(a, b) {
        (a = _.Vn(251)) && b.set("uach", {
            value: Yz(a, 3)
        })
    }, function(a, b) {
        var c = a.la;
        a = c.B;
        if (!c.Rb || _.I(YJ)) {
            var d;
            if (a = (d = a.navigator) == null ? void 0 : d.userActivation) {
                d = 0;
                if (a == null ? 0 : a.hasBeenActive) d |= 1;
                if (a == null ? 0 : a.isActive) d |= 2
            } else d = void 0;
            d && b.set("uas", {
                value: d
            })
        }
    }, function(a, b) {
        var c = a.la;
        var d = c.B;
        var e = c.L;
        c = c.hd;
        a = a.ja;
        var f = a.T;
        a = a.K;
        var g = a.Z;
        var h = a.W;
        a = gt("google_preview", d);
        var l = d.document,
            k = a ? jt(l.URL) : l.URL;
        l = a ? jt(l.referrer) : l.referrer;
        a = !1;
        if (c) c = ht(g.Ya());
        else {
            var m;
            c = (m = ht(h[f[0].getDomId()].Ya())) != null ? m : ht(g.Ya())
        }
        if (c != null) {
            var n = k;
            pi(d) || (l = "", a = !0)
        } else c = k;
        m = kt(d);
        b.set("nhd", {
            value: m || null
        }).set("url", {
            value: c
        }).set("loc", {
            value: n !== null && n !== c ? n : null
        }).set("ref", {
            value: l
        });
        if (m) {
            n = b.set;
            var p, r;
            m = _.um(d.top) && ((p = d.top) == null ? void 0 : (r = p.location) == null ? void 0 : r.href);
            var v;
            p = (v = d.location) == null ? void 0 : v.ancestorOrigins;
            d = Wm(d) || "";
            v = (p == null ? void 0 : p[p.length - 1]) || "";
            d = (d = m || d || v) ? a ? aE(d.match(_.$D)[3] || null) : d : null;
            n.call(b, "top", {
                value: d
            }).set("etu", {
                value: e.ac
            })
        }
    }, function(a, b) {
        a = a.la.context.pvsid;
        b.set("rumc", {
            value: _.I(zK) || _.Ri(po).g ? a : null
        }).set("rume", {
            value: _.I(yK) ? 1 : null
        })
    }, function(a, b) {
        b.set("vis", {
            value: _.pu(a.la.B.document)
        })
    }, function(a, b) {
        var c = a.ja;
        var d = c.T;
        var e = c.K;
        c = e.Z;
        e = e.W;
        a = a.la.B;
        var f = Bs(d, e, c);
        e = Es(d, f, a);
        c = e.Eo;
        e = e.xp;
        var g = Fs(d, f, a),
            h = g.un;
        g = g.Bo;
        var l = !1;
        d = d.map(function(m) {
            var n;
            m = (n = f.get(m)) != null ? n : 0;
            if (m === 0) return null;
            l = !0;
            return m === 2 ? "1" : "0"
        });
        var k;
        b.set("aee", {
            value: l ? d : null,
            options: {
                Pa: "|"
            }
        }).set("psz", {
            value: c,
            options: {
                Pa: "|"
            }
        }).set("msz", {
            value: e,
            options: {
                Pa: "|"
            }
        }).set("fws", {
            value: h,
            options: {
                Ia: !0
            }
        }).set("ohw", {
            value: g,
            options: {
                Ia: !0
            }
        }).set("efat", {
            value: ((k = a.location) == null ? void 0 : k.hash) === "#flexibleAdSlotTest" ? "1" : null
        })
    }, function(a, b) {
        b.set("psts", {
            value: cP(a.la.L, a.ja.T)
        })
    }, function(a, b) {
        var c = a.ja.T;
        var d = a.la.B;
        var e = a.Rp;
        a = e.ti;
        var f = e.Xj;
        var g = e.rp;
        var h = e.jm;
        if (!_.I(AK) && !g) {
            (g = Xi(d.isSecureContext, d.navigator, d.document)) && b.set("td", {
                value: 1
            });
            if (a) switch (a.kind) {
                case 0:
                    b.set("eig", {
                        value: a.signal
                    });
                    break;
                case 1:
                    b.set("eigir", {
                        value: a.reason,
                        options: {
                            Ia: !0
                        }
                    });
                    break;
                default:
                    Sa(a)
            }
            f !== void 0 && b.set("egid", {
                value: f,
                options: {
                    Ia: !0
                }
            });
            (h == null ? 0 : h.size) && b.set("tan", {
                value: c.map(function(l) {
                    return h.get(l)
                })
            });
            g && (c = new qi, c.set(1, Wi(d.navigator)), b.set("tdf", {
                value: si(c)
            }))
        }
    }, function(a, b) {
        var c = a.la.B;
        var d = a.Gp;
        a = d.Jp;
        d = d.Hp;
        Yi(c.isSecureContext, c.document) && (b.set("topics", {
            value: a instanceof Uint8Array ? Ab(a, 3) : a
        }), !a || a instanceof Uint8Array || b.set("tps", {
            value: a
        }), d && b.set("htps", {
            value: d
        }))
    }, function(a, b) {
        var c = a.la;
        var d = c.B;
        var e = c.ba;
        var f = a.ja.T;
        a = a.gl;
        c = a.Le;
        var g = a.ke;
        var h = a.ro;
        if (!_.I(iJ)) {
            a = b.set;
            d = wi(e, d);
            e = ln(f[0].getAdUnitPath());
            f = new VC;
            var l = {};
            rl(56, "", null, e ? (l.nc = e, l) : void 0);
            g = g != null ? g : [];
            if (e && c && g && typeof c.getUserIdsAsEidBySource === "function") {
                if (typeof c.getUserIdsAsEids === "function") try {
                    for (var k = _.y(c.getUserIdsAsEids()), m = k.next(); !m.done; m = k.next()) {
                        var n = m.value;
                        if (typeof n.source === "string") {
                            var p = l = void 0,
                                r = void 0,
                                v = void 0,
                                u = {};
                            rl(52, n.source, null, (u.sl = String((v = (l = n.uids) == null ? void 0 : (p = l[0]) == null ? void 0 : (r = p.id) == null ? void 0 : r.length) != null ? v : -1), u))
                        }
                    }
                } catch (D) {
                    var x;
                    rl(45, "", (x = D) == null ? void 0 : x.message)
                }
                k = e.split(",");
                m = _.y(g);
                for (n = m.next(); !n.done; n = m.next())
                    if (n = n.value, _.w(k, "includes").call(k, _.t(n, 1)))
                        for (n = _.y(_.ul(n, iC, 2, _.wl())), x = n.next(); !x.done; x = n.next())
                            if (x = x.value, _.R(x, _.Lm(x, jC, 3)) && (x = _.t(x, 1), !zl(f, x))) {
                                g = null;
                                try {
                                    r = p = l = void 0, g = (l = c.getUserIdsAsEidBySource(x)) == null ? void 0 : (p = l.uids) == null ? void 0 : (r = p[0]) == null ? void 0 : r.id
                                } catch (D) {
                                    g = void 0;
                                    rl(45, x, (g = D) == null ? void 0 : g.message);
                                    continue
                                }
                                g ? g.length > 1024 ? (l = {}, rl(12, x, null, (l.sl = String(g.length), l.fp = "1", l))) : (l = QC(x), p = _.tj(l, 2, g), l = f, p = _.Dl(p, 11, !0), Fl(l, 2, vl, p), l = {}, rl(19, x, null, (l.fp = "1", l.hs = "1", l.sl = String(g.length), l))) : rl(57, x)
                            }
            }
            Gl(f, d, e, h);
            _.ul(f, vl, 2, _.wl()).length ? (c = {}, rl(50, "", null, (c.ns = String(_.ul(f, vl, 2, _.wl()).length), c)), c = Ab(f.g(), 3)) : c = null;
            a.call(b, "a3p", {
                value: c
            })
        }
    }, function(a, b) {
        var c = a.eb.df;
        var d = a.ja.T;
        a = function() {
            return c ? d.map(function(e) {
                return c.get(e)
            }) : []
        }();
        b.set("cbidsp", {
            value: Vs(a, function(e) {
                return Ab(e.g(), 3)
            }),
            options: _.w(Object, "assign").call(Object, {}, {
                Pa: "~"
            }, {
                jd: !0
            })
        })
    }, function(a, b) {
        var c = a.ja.K.Z;
        if (_.zs(uA(c, Ru, 33), GQ, 2))
            if (_.I(LJ)) {
                a = new GQ;
                c = _.y(_.ul(uA(uA(c, Ru, 33), GQ, 2), ju, 1, _.wl()));
                for (var d = c.next(); !d.done; d = c.next()) d = d.value, _.Ou(d, 2, _.wl()).length && gu(a, d);
                _.ul(a, ju, 1, _.wl()).length && (a = Ab(jU(a), 3), b.set("ppss", {
                    value: a
                }))
            } else {
                a = [];
                c = _.y(_.ul(uA(uA(c, Ru, 33), GQ, 2), ju, 1, _.wl()));
                for (d = c.next(); !d.done; d = c.next())
                    if (d = d.value, _.Ou(d, 2, _.wl()).length) {
                        var e = _.Ou(d, 2, _.wl()).join("|");
                        a.push(_.Sh(d, 1, 0) + "=" + e)
                    }
                b.set("pps", {
                    value: a,
                    options: {
                        Pa: "~"
                    }
                })
            }
    }, function(a, b) {
        var c = a.Ho;
        a = c.Cn;
        var d = c.bq;
        c = c.Dn;
        b.set("scar", {
            value: a
        });
        _.I(rJ) && (a == null ? 0 : a.length) && d != null && b.set("wst", {
            value: a === "0" ? d === "WEBVIEW_SDK_PAW" ? (3).toString() : (5).toString() : d === "WEBVIEW_SDK_PAW" ? (2).toString() : (4).toString()
        });
        _.I(qJ) && c && (b.set("js", {
            value: c.js
        }), b.set("vnm", {
            value: c.vnm
        }), b.set("an", {
            value: c.an
        }))
    }, function(a, b) {
        a = a.la.B;
        a = !(!a.isSecureContext || !Vi("attribution-reporting", a.document));
        !_.I(xK) && a && b.set("nt", {
            value: 1
        })
    }, function(a, b) {
        if (a = a.Po.Oo) a = Yz(Fm(a), 3), b.set("psd", {
            value: a
        })
    }, function(a, b) {
        a = _.zk(a.la.B);
        var c = mt;
        a > 0 && c >= a && b.set("dlt", {
            value: a
        }).set("idt", {
            value: c - a
        })
    }, function(a, b) {
        a = a.ja.K.Z;
        b.set("ppid", {
            value: _.yl(a, 16) ? _.t(a, 16) : null,
            options: {
                Ia: !0
            }
        })
    }, function(a, b) {
        var c = b.set;
        (a = xl(a.ja.K.Z, 8)) ? (a.length > 50 && (a = a.substring(0, 50)), a = "a " + Yz('role:1 producer:12 loc:"' + a + '"')) : a = "";
        c.call(b, "uule", {
            value: a
        })
    }, function(a, b) {
        var c = a.ja;
        a = c.K;
        var d = c.K.Z;
        b.set("prev_scp", {
            value: Mu(c.T, a),
            options: {
                jd: !0,
                Pa: "|"
            }
        }).set("cust_params", {
            value: Pu(d),
            options: {
                Pa: "&"
            }
        })
    }, function(a, b) {
        var c = a.ja;
        var d = c.K;
        c = c.T;
        a = a.la;
        var e = a.L;
        var f = a.hd;
        b.set("adks", {
            value: c.map(function(g) {
                if (f) {
                    var h = d.W[g.getDomId()];
                    h = Xr(h);
                    if (g = e.g.get(g)) g.Xd = h;
                    return h
                }
                h = d.Z;
                var l = d.W[g.getDomId()],
                    k;
                if (!(k = Cx(e, g))) {
                    h = Xr(l, _.R(h, 6) || _.R(l, 17) ? null : vo(g));
                    if (g = e.g.get(g)) g.Xd = h;
                    k = h
                }
                return k
            })
        })
    }, function(a, b) {
        var c = b.set;
        a = a.la.B;
        var d = wE(a);
        a: {
            var e = a.google_ad_width || a.google_ad_width;
            var f = a.google_ad_height || a.google_ad_height;
            if (pi(a)) e = !1;
            else {
                var g = a.document,
                    h = g.documentElement;
                if (e && f) {
                    var l = 1,
                        k = 1;
                    a.innerHeight ? (l = a.innerWidth, k = a.innerHeight) : h && h.clientHeight ? (l = h.clientWidth, k = h.clientHeight) : g.body && (l = g.body.clientWidth, k = g.body.clientHeight);
                    if (k > 2 * f || l > 2 * e) {
                        e = !1;
                        break a
                    }
                }
                e = !0
            }
        }
        f = d.location.href;
        d === d.top ? d = !0 : (g = !1, (h = d.document) && h.referrer && (f = h.referrer, d.parent === d.top && (g = !0)), (d = d.location.ancestorOrigins) && (d = d[d.length - 1]) && f.indexOf(d) === -1 && (g = !1), d = g);
        f = a.top == a ? 0 : _.um(a.top) ? 1 : 2;
        g = 4;
        e || f !== 1 ? e || f !== 2 ? e && f === 1 ? g = 7 : e && f === 2 && (g = 8) : g = 6 : g = 5;
        d && (g |= 16);
        d = String(g);
        if (a !== a.top)
            for (e = a; e && e !== e.top && _.um(e) && !a.sf_ && !a.$sf && !a.inGptIF && !a.inDapIF; e = e.parent);
        c.call(b, "frm", {
            value: d || null
        })
    }, function(a, b) {
        b.set("ppt", {
            value: _.DA(uA(a.ja.K.Z, EQ, 36), 1),
            options: {
                Pa: "~"
            }
        })
    }, function(a, b) {
        a = a.la.B;
        try {
            var c, d, e = (c = a.external) == null ? void 0 : (d = c.getHostEnvironmentValue) == null ? void 0 : d.call(c, "os-mode");
            if (e) {
                var f = Number(JSON.parse(e)["os-mode"]);
                f < 0 || b.set("wsm", {
                    value: f + 1
                })
            }
        } catch (g) {}
    }, function(a, b) {
        var c = a.ja;
        var d = c.networkCode;
        var e = c.T;
        c = c.K.W;
        a = a.Hm.Id;
        var f = [],
            g = !1;
        e = _.y(e);
        for (var h = e.next(); !h.done; h = e.next()) {
            var l = void 0;
            ((l = c[h.value.getDomId()]) == null ? 0 : _.R(l, 30)) ? (f.push("1"), g = !0) : f.push("")
        }
        b.set("is_cau", {
            value: g ? f : null
        });
        b.set("no_cau_info", {
            value: a.has(d) ? "1" : null
        })
    }, function(a, b) {
        var c = a.ja;
        var d = c.T;
        c = c.K.W;
        a = a.la.B;
        var e = [],
            f = !1;
        d = _.y(d);
        for (var g = d.next(); !g.done; g = d.next()) g = Wp(c[g.value.getDomId()]), (_.E = [8, 9], _.w(_.E, "includes")).call(_.E, g) ? (f = g === 9 ? "right" : "left", e.push(_.Uk(a).sideRailPlasParam.get(f)), f = !0) : e.push("");
        f && b.set("plas", {
            value: e,
            options: {
                Pa: "|"
            }
        })
    }, function(a, b) {
        var c = a.la;
        var d = c.B;
        c = c.ba;
        var e = a.ja;
        var f = e.K.Z;
        e = e.networkCode;
        a = a.fn.je;
        var g;
        a = !a || !Qe(a, 1, Id).get((g = e.split(",")) == null ? void 0 : g[0]);
        var h;
        g = !((h = by(f)) == null || !_.R(h, 9));
        d = new wL(d);
        h = {
            Zf: a,
            Yf: g
        };
        if (d.isEnabled(c, {
                Yf: h.Yf,
                Zf: h.Zf
            })) {
            var l;
            g = (l = xi("__eoi", d.g)) != null ? l : void 0
        } else g = void 0;
        (l = g) ? b.set("eo_id_str", {
            value: l
        }): d.isEnabled(c, h) && b.set("eoidce", {
            value: "1"
        })
    }, function(a, b) {
        var c = a.ja;
        a = c.T;
        var d = c.K.W;
        _.I(gq) && b.set("eov", {
            value: Ts(a, function(e) {
                var f, g;
                return !!((f = d[e.getDomId()]) == null ? 0 : (g = _.Fi(f, hq, 31)) == null ? 0 : _.R(g, 1))
            })
        })
    }, function(a, b) {
        var c = a.ja;
        a = c.T;
        var d = c.ue;
        d != null && d.size && b.set("xatfs", {
            value: Ts(a, function(e) {
                return d.has(e)
            })
        })
    }, function(a, b) {
        var c = a.la.B;
        a = a.ja;
        a = a.K.W[a.T[0].getDomId()];
        if (_.yl(a, 32) && Wp(a) === 6) {
            b.set("ait_q", {
                value: _.t(a, 32)
            });
            var d = b.set,
                e = (0, _.Lq)() !== 0;
            d.call(b, "dsz", {
                value: (e ? c.innerWidth : Math.min(c.document.body.clientWidth, Infinity)) + "x" + (e ? .95 * c.innerHeight - 30 : c.innerHeight)
            });
            _.R(a, 33) && _.K(WJ) && b.set("adtest", {
                value: "on"
            })
        }
    }, function(a, b) {
        var c = a.gl.Le;
        var d = a.ja.T;
        var e = a.la.context;
        if (_.I(YI) && _.K($s) && typeof(c == null ? void 0 : c.getEvents) === "function") {
            var f = null;
            b.set("gblpids", {
                value: d.map(function(g) {
                    return pn(e, 1269, function() {
                        var h, l, k;
                        return (k = Zs.get(g)) != null ? k : at((l = f) != null ? l : f = (h = c.getEvents) == null ? void 0 : h.call(c).filter(function(m) {
                            return m.eventType === "auctionEnd"
                        }), g, e)
                    })
                }),
                options: {
                    Pa: "~",
                    jd: !0
                }
            })
        }
    }, function(a, b) {
        a = a.la;
        var c = a.context;
        var d = a.B.document;
        _.I($J) && pn(c, 1278, function() {
            var e = wj(d),
                f = e.Sp;
            b.set("pgls", {
                value: e.labels.map(function(h) {
                    return Ab(ML(h), 3)
                }),
                options: {
                    Pa: "~"
                }
            });
            var g = _.K(dK);
            c.O.log(576944485, function() {
                return uq(vq(oq(pq(qq(rq(sq(new tq, c.pvsid), c.Ra), c.documentUrl), _.wk())), g), fH(new zq, cH(new bH, f.map(function(h) {
                    h = h.content;
                    return (new $G).setContent(h)
                }))))
            }, {
                Ta: f.length && RS ? g : 0
            });
            RS = !1
        }, !0)
    }]);
    var HV = function(a, b, c) {
        Z.call(this, a, 798);
        this.output = X(this);
        this.j = WM(this, b);
        this.A = Y(this, c)
    };
    _.T(HV, Z);
    HV.prototype.g = function() {
        var a = this,
            b = new _.z.Map;
        if (this.j.value) {
            var c = this.j.value,
                d = c.la.hd,
                e = c.eb.df;
            c = _.y(c.ja.T);
            for (var f = c.next(); !f.done; f = c.next()) {
                f = f.value;
                var g = void 0,
                    h = (g = e) == null ? void 0 : g.get(f);
                b.set(f, d ? IV(this, f, h) : function() {
                    return a.A.value
                })
            }
        }
        this.output.H(b)
    };
    var IV = function(a, b, c) {
        return wo(function() {
            var d = _.w(Object, "assign").call(Object, {}, a.j.value);
            d.ja.th = !0;
            d.ja.T = [b];
            c && (d.eb.df = new _.z.Map, d.eb.df.set(b, c));
            return et(dy(d)).url
        })
    };
    var JV = Sj(810, function(a, b, c, d, e, f, g, h) {
        var l = c;
        !d && c.length > 1 && (l = l.slice(0, 1));
        l = l.filter(function(k) {
            if (k.J) return !1;
            var m = e.W[k.getDomId()],
                n;
            if (n = !(Wq(Wp(m)) && (_.E = ej(EJ), _.w(_.E, "includes")).call(_.E, String(Wp(m)))))((n = _.Zj(g)) ? n > 1.05 || n < .95 : 1) && Wp(m) === 4 ? (Q(f, TP("googletag.enums.OutOfPageFormat.REWARDED", String(k.getAdUnitPath()))), n = !0) : n = !1, n = !n;
            if (n) {
                n = Wp(m);
                if (n !== 5) k = !1;
                else {
                    b.O.log(578856259, _.Kk, {
                        pvsid: b.pvsid,
                        documentUrl: b.documentUrl,
                        kb: 17,
                        Ub: b.Ra,
                        P: 1
                    });
                    var p = Hq(g, _.I(_.tJ) ? !1 : !jR(k), h);
                    if (p) {
                        var r = _.I(Fq) ? p & -4194305 : p;
                        yq(f, r, n, k.getAdUnitPath());
                        b.O.log(578856259, Jk, {
                            pvsid: b.pvsid,
                            documentUrl: b.documentUrl,
                            kb: 17,
                            Ub: b.Ra,
                            uo: r
                        });
                        b.O.log(578856259, _.Kk, {
                            pvsid: b.pvsid,
                            documentUrl: b.documentUrl,
                            kb: 17,
                            Ub: b.Ra,
                            P: 2
                        })
                    } else b.O.log(578856259, _.Kk, {
                        pvsid: b.pvsid,
                        documentUrl: b.documentUrl,
                        kb: 17,
                        Ub: b.Ra,
                        P: 3
                    });
                    k = !!p
                }
                n = !k
            }(k = n) && !(k = !_.I(UJ)) && (k = l.length, k = !(Wp(m) !== 6 ? 0 : k > 1 || !_.yl(m, 32)));
            return k
        });
        l.length > 30 && (Q(f, SP("30", String(l.length), String(l.length - 30))), l = l.slice(0, 30));
        return {
            T: l
        }
    }, {
        T: void 0
    });
    var KV = function(a, b, c) {
        Z.call(this, a, 919);
        this.j = b;
        this.ba = c;
        this.output = X(this)
    };
    _.T(KV, Z);
    KV.prototype.g = function() {
        var a, b = !((a = this.j) == null ? 0 : _.R(a, 9)) && !!vi(this.ba);
        this.output.H(b)
    };
    var LV = Sj(1221, function(a, b) {
        a.status === 403 && b.V.error(sQ(a.responseText));
        return {}
    }, {});
    var MV = function(a, b, c, d, e, f) {
        Z.call(this, a, 928);
        this.requestId = b;
        this.C = f;
        this.output = VM(this);
        this.A = Y(this, c);
        e && (this.j = Y(this, e));
        YM(this, d)
    };
    _.T(MV, Z);
    var NV = function(a) {
        return a.j ? a.C.split(",").some(function(b) {
            var c;
            return (c = a.j) == null ? void 0 : c.value.has(b)
        }) : !1
    };
    MV.prototype.g = function() {
        var a = this.context,
            b = this.requestId,
            c = this.A.value.length,
            d = NV(this),
            e = bn(a);
        if (e.ud) {
            var f = a.va,
                g = f.Fc;
            a = an(a, e.kd);
            e = new HG;
            b = _.Fk(e, 2, b);
            c = _.Pg(b, 1, c);
            d = _.$g(c, 3, d);
            d = _.en(a, 7, fn, d);
            g.call(f, d)
        }
        this.output.notify()
    };
    var OV = function(a, b, c, d) {
        Z.call(this, a, 867);
        this.Ha = b;
        this.K = c;
        this.output = VM(this);
        this.j = Y(this, d)
    };
    _.T(OV, Z);
    OV.prototype.g = function() {
        for (var a = _.y(this.j.value), b = a.next(); !b.done; b = a.next()) {
            var c = _.y(b.value);
            b = c.next().value;
            c = c.next().value;
            var d = Xn(this.K.W[b.getDomId()], 20);
            b.dispatchEvent(RO, 808, {
                Km: c,
                lp: d
            });
            this.Ha.dispatchEvent("slotRequested", 705, new DT(b, "publisher_ads"))
        }
        this.output.notify()
    };
    var PV = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u, x, D, F, C, G, S, P, J, U, ha, ea, Ba, ja, ma, ra, ia, Oa, fb, Ub, Uc, vc, Ad, Zd, $d, Ne) {
        Z.call(this, a, 785, _.K(aK));
        this.hd = b;
        this.L = c;
        this.Xa = d;
        this.K = e;
        this.kc = f;
        this.networkCode = g;
        this.Vd = h;
        this.Ud = l;
        this.Xc = k;
        this.timer = m;
        this.ba = n;
        this.isSecureContext = p;
        this.Rb = r;
        this.vh = v;
        this.B = u;
        this.Id = x;
        this.ca = D;
        this.j = X(this);
        this.A = X(this);
        YM(this, Ba);
        this.Wa = XM(this, F);
        this.qe = XM(this, C);
        this.Za = XM(this, G);
        this.R = XM(this, S);
        this.G = Y(this, P);
        U && ha && (this.C = _.I(gK) ? new NM(ha) : XM(this, ha), U && (this.Yc = WM(this, U)));
        ea && (this.I = _.I(gK) ? new NM(ea) : XM(this, ea));
        ja && (this.Yb = Y(this, ja));
        ma && (this.ia = new NM(ma));
        ra && (this.qb = WM(this, ra));
        ia && (this.pa = Y(this, ia));
        Oa && YM(this, Oa);
        fb && (this.Na = Y(this, fb));
        Ne && (this.Eb = WM(this, Ne));
        J && (this.oa = WM(this, J));
        Ub && (this.Pc = WM(this, Ub));
        Uc && (this.pe = Y(this, Uc));
        vc && (this.Ea = WM(this, vc));
        Ad && (this.U = WM(this, Ad));
        Zd && (this.Sc = Y(this, Zd));
        $d && (this.ka = XM(this, $d))
    };
    _.T(PV, Z);
    PV.prototype.g = function() {
        if (this.G.value.length) {
            var a = null;
            if (this.C) {
                var b = this.C.value;
                a = b ? b : this.I && !this.I.Qd() ? 9 : this.C.Qd() ? null : 1
            }
            this.R.value && (this.L.ac = this.R.value);
            var c, d, e, f, g, h, l, k, m, n, p, r, v, u, x, D, F;
            b = {
                la: {
                    B: this.B,
                    context: this.context,
                    L: this.L,
                    Xa: this.Xa,
                    ba: this.ba,
                    hd: this.hd,
                    Xc: this.Xc,
                    isSecureContext: this.isSecureContext,
                    Rb: this.Rb,
                    Do: this.ca
                },
                ja: {
                    networkCode: this.networkCode,
                    T: this.G.value,
                    K: this.K,
                    kc: this.kc,
                    th: !1,
                    vh: this.vh,
                    ue: (c = this.Eb) == null ? void 0 : c.value
                },
                Yp: {
                    Vd: this.Vd,
                    Ud: this.Ud
                },
                Ho: {
                    Cn: (x = this.Wa.value) != null ? x : "0",
                    bq: (D = this.qe.value) != null ? D : "WEBVIEW_SDK_PAW",
                    Dn: this.Za.value
                },
                eb: {
                    df: (d = this.oa) == null ? void 0 : d.value
                },
                Gp: {
                    Jp: a,
                    Hp: (e = this.Yc) == null ? void 0 : e.value
                },
                gl: {
                    ro: (F = (f = this.Yb) == null ? void 0 : f.value) != null ? F : void 0,
                    Le: (g = this.ia) == null ? void 0 : g.value,
                    ke: (h = this.pa) == null ? void 0 : h.value
                },
                sd: {
                    Ln: (l = this.qb) == null ? void 0 : l.value,
                    zn: (k = this.Na) == null ? void 0 : k.value
                },
                Po: {
                    Oo: (m = this.Pc) == null ? void 0 : m.value
                },
                Rp: {
                    ti: (n = this.pe) == null ? void 0 : n.value,
                    Xj: (p = this.Ea) == null ? void 0 : p.value,
                    rp: (r = this.Sc) == null ? void 0 : r.value,
                    jm: (v = this.ka) == null ? void 0 : v.value
                },
                fn: {
                    je: (u = this.U) == null ? void 0 : u.value
                },
                Hm: {
                    Id: this.Id
                }
            };
            c = et(dy(b));
            d = c.url;
            sO(this.timer, (9).toString(), 9, c.tj);
            this.A.H(b);
            this.j.H(d)
        } else this.j.H(""), this.A.ha()
    };
    var QV = function(a, b, c, d, e, f) {
        Z.call(this, a, 878);
        this.j = b;
        this.ga = c;
        this.K = d;
        this.B = e;
        this.output = VM(this);
        f && YM(this, f)
    };
    _.T(QV, Z);
    QV.prototype.g = function() {
        for (var a = _.y(this.j), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = vo(b, this.ga);
            if (!uo(b, this.ga) && c) {
                a: {
                    var d = c;
                    var e = this.K.W[b.getDomId()],
                        f = 0,
                        g = 0;e = _.y(co(e));
                    for (var h = e.next(); !h.done; h = e.next())
                        if (h = h.value, Array.isArray(h)) {
                            var l = _.y(h);
                            h = l.next().value;
                            l = l.next().value;
                            if (!(typeof h !== "number" || typeof l !== "number" || h <= 1 || l <= 1 || (f = f || h, g = Math.min(g || Infinity, l), ys(xo(d, this.B)) || !d.parentElement || ys(xo(d.parentElement, this.B))))) {
                                d = [f, 0];
                                break a
                            }
                        }
                    d = f || g ? [f, g] : null
                }
                g = this.K;f = g.Z;g = g.W[b.getDomId()];xs(c, Do(b), Zr(f, g), d)
            }
        }
        this.output.notify()
    };
    var RV = Sj(1254, function(a, b) {
        b = b.context;
        var c = _.K(QJ),
            d = _.K(RJ);
        d > 0 && b.Zb < 1 / d && b.va.La.Ma.hb.request.jp.ta({
            wa: d,
            lo: c,
            Pe: a.Pe,
            status: a.Pe === 0 ? "NOT_RETRIED" : a.Pe > c ? "OVER_MAX_RETRIES/ABANDONED" : "RECOVERED"
        });
        return {}
    }, {});
    var SV = function(a, b, c, d, e, f, g, h) {
            this.J = a;
            this.A = b;
            this.j = c;
            this.T = d;
            this.ba = e;
            this.G = f;
            this.F = g;
            this.C = h;
            this.l = "";
            this.o = -1;
            this.state = 1;
            this.g = ""
        },
        UV = function(a, b) {
            if (b)
                if (a.state !== 1 && a.state !== 2) TV(a, new IL("state err: (" + ([a.state, a.g.length].join() + ")")));
                else {
                    a.g && (b = a.g + b);
                    var c = 0;
                    do {
                        var d = b.indexOf("\n", c);
                        var e = d !== -1;
                        if (!e) break;
                        var f = a;
                        c = b.substr(c, d - c);
                        if (f.state === 1) f.l = c, ++f.o, f.state = 2;
                        else {
                            var g = void 0;
                            try {
                                f.J(f.o, f.l, {
                                    kind: 0,
                                    nb: sE(c)
                                }, f.T, f.ba, f.G, f.F, (g = f.C) != null ? g : void 0), f.l = ""
                            } catch (h) {}
                            f.state = 1
                        }
                        c = d + 1
                    } while (e && c < b.length);
                    a.g = b.substr(c)
                }
        },
        TV = function(a, b) {
            a.state = 4;
            try {
                a.A(b)
            } catch (c) {}
        },
        VV = function(a) {
            a.state !== 1 || a.g ? TV(a, new IL("state err (" + ([a.state, a.g.length].join() + ")"))) : (a.state = 3, a.j(a.o, a.T, a.ba))
        };
    var WV = function(a, b, c, d, e, f, g, h, l, k, m, n, p) {
        Z.call(this, a, 788);
        this.ka = b;
        this.ia = c;
        this.ca = d;
        this.ba = e;
        this.L = f;
        this.K = g;
        this.G = VM(this);
        this.C = X(this);
        this.A = X(this);
        this.U = 0;
        this.R = !1;
        this.j = p != null ? p : new XMLHttpRequest;
        this.I = Y(this, h);
        l && (this.pa = WM(this, l));
        this.Ea = Y(this, k);
        YM(this, m);
        this.oa = Y(this, n)
    };
    _.T(WV, Z);
    WV.prototype.g = function() {
        var a = this,
            b = this.Ea.value;
        if (b) {
            var c, d = new SV(this.ka, this.ia, this.ca, this.I.value, this.ba, (c = this.pa) == null ? void 0 : c.value);
            this.j.open("GET", b);
            this.j.withCredentials = this.oa.value;
            this.j.onreadystatechange = function() {
                XV(a, d, !1)
            };
            this.j.onload = function() {
                XV(a, d, !0);
                a.C.H(a.j.status);
                if (a.j.status >= 300) {
                    var e;
                    a.A.H((e = a.j.responseText) != null ? e : "")
                } else a.A.H("")
            };
            this.j.onerror = function() {
                TV(d, new JL("XHR error"));
                a.I.value.forEach(function(e) {
                    Sv(e, a.L, a.K, "")
                });
                a.C.H(0);
                a.A.H("")
            };
            this.j.send()
        }
        this.G.notify()
    };
    var XV = function(a, b, c) {
        try {
            if (a.j.readyState === 3 || a.j.readyState === 4)
                if (a.j.status >= 300) a.R || (TV(b, new JL("xhr_err-" + a.j.status)), a.R = !0);
                else {
                    var d = a.j.responseText.substr(a.U);
                    d && UV(b, d);
                    a.U = a.j.responseText.length;
                    c && a.j.readyState === 4 && VV(b)
                }
        } catch (e) {
            TV(b, e)
        }
    };
    var YV = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u, x, D) {
        Z.call(this, a, 1078);
        this.ia = b;
        this.ca = c;
        this.U = d;
        this.Na = e;
        this.ba = f;
        this.L = g;
        this.K = h;
        this.googletag = l;
        this.R = VM(this);
        this.G = X(this);
        this.A = X(this);
        this.I = X(this);
        this.C = 0;
        this.j = Y(this, k);
        m && (this.oa = WM(this, m));
        n && (this.pa = Y(this, n));
        this.Ea = Y(this, p);
        YM(this, r);
        this.ka = Y(this, v);
        u && (this.Za = WM(this, u));
        x && (this.Wa = Y(this, x));
        D && (this.qb = WM(this, D))
    };
    _.T(YV, Z);
    YV.prototype.g = function() {
        var a = this,
            b = this.Ea.value;
        if (b) {
            var c, d, e, f = new SV(this.ia, this.ca, this.U, this.j.value, this.ba, (c = this.oa) == null ? void 0 : c.value, (d = this.pa) == null ? void 0 : d.value, (e = this.qb) == null ? void 0 : e.value);
            c = this.ka.value ? "include" : "omit";
            var g;
            d = (g = this.Za) == null ? void 0 : g.value;
            var h;
            g = (h = this.Wa) == null ? void 0 : h.value;
            h = _.w(Object, "assign").call(Object, {}, {
                credentials: c
            }, d ? {
                browsingTopics: d
            } : {}, g ? {
                adAuctionHeaders: g
            } : {});
            fetch(b, h).then(function(l) {
                if (_.K(QJ) > 0) {
                    a.I.H(gP(a.L, a.j.value[0]));
                    for (var k = _.y(a.j.value), m = k.next(); !m.done; m = k.next()) {
                        m = m.value;
                        var n = a.L.g.get(m);
                        n && (n.xi = 0);
                        if (m = a.L.g.get(m)) m.fi = 0
                    }
                }
                ZV(a, l, f)
            }).catch(function(l) {
                _.K(QJ) > 0 ? $V(a, l, f) : aW(a, l, f)
            })
        }
        this.R.notify()
    };
    var $V = function(a, b, c) {
            var d = on(a.context, 1253, function() {
                    a.C = 0;
                    for (var f = _.y(a.j.value), g = f.next(); !g.done; g = f.next()) hP(a.L, g.value);
                    a.googletag.pubads().refresh(a.j.value.map(function(h) {
                        return h.Ba
                    }));
                    a.G.H(0);
                    a.A.H("");
                    a.Na()
                }),
                e = _.K(QJ);
            a.j.value.every(function(f) {
                return gP(a.L, f) < e
            }) ? (a.C = setTimeout(d, _.K(PJ)), _.$q(a, function() {
                a.C && (clearTimeout(a.C), a.C = 0, aW(a, b, c))
            })) : (a.I.H(e + 1), aW(a, b, c))
        },
        aW = function(a, b, c) {
            bW(a, b, c);
            a.j.value.forEach(function(d) {
                Sv(d, a.L, a.K, "")
            })
        },
        ZV = function(a, b, c) {
            a.G.H(b.status);
            if (b.status >= 300) a.A.pb(b.text()), TV(c, new JL("fetch_status-" + b.status));
            else {
                a.A.H("");
                var d, e = (d = b.body) == null ? void 0 : d.pipeThrough(new TextDecoderStream).getReader();
                e ? e.read().then(function(f) {
                    cW(a, f, e, c)
                }).catch(function(f) {
                    bW(a, f, c)
                }) : TV(c, new JL("failed_reader"))
            }
        },
        cW = function(a, b, c, d) {
            var e = b.value;
            b.done ? VV(d) : (UV(d, e), c.read().then(function(f) {
                cW(a, f, c, d)
            }).catch(function(f) {
                bW(a, f, d)
            }))
        },
        bW = function(a, b, c) {
            TV(c, new JL("fetch error: " + (b instanceof Error ? b.message : void 0)));
            a.G.H(0);
            a.A.H("")
        };
    var dW = function(a, b, c, d, e) {
        Z.call(this, a, 918);
        this.K = b;
        this.timer = c;
        this.output = VM(this);
        this.j = Y(this, e);
        YM(this, d)
    };
    _.T(dW, Z);
    dW.prototype.g = function() {
        var a = this.j.value;
        a.length && Nv(this.timer, "3", Ov(this.K.W[a[0].getDomId()], 20));
        this.output.notify()
    };
    var eW = Sj(1229, function(a, b) {
        a = a.ec;
        var c = b.ya,
            d, e;
        b = _.HA(a, 6);
        var f = _.HA(a, 7),
            g = !!_.R(a, 8),
            h = _.IA(a, 10),
            l = (e = a.getEscapedQemQueryId()) != null ? e : "";
        e = _.Fi(a, aD, 43);
        var k = !!_.R(a, 9),
            m = !!_.R(a, 12),
            n = _.Fi(a, NC, _.Lm(a, WD, 48)),
            p = _.Fi(a, MC, _.Lm(a, WD, 39)),
            r = _.Sh(a, 36, 0),
            v = !!_.R(a, 13),
            u = _.IA(a, 49),
            x = _.Fi(a, sD, 51),
            D = _.IA(a, 61);
        if (!_.I(SJ) && c.kind !== 0) {
            var F;
            c = {
                kind: 0,
                nb: (F = _.t(a, 4)) != null ? F : ""
            }
        }
        F = c;
        c = _.Fi(a, SD, 58);
        var C = (d = _.Fi(a, WC, 56)) == null ? void 0 : _.IA(d, 1);
        d = _.ul(a, CC, 62, _.wl());
        var G = _.ul(a, cD, 67, _.wl());
        var S = Ie(a, 63, vd, _.wl(), void 0, void 0, 0);
        return {
            output: {
                height: b,
                width: f,
                isEmpty: g,
                Zc: h,
                lb: l,
                Yd: e,
                isBackfill: k,
                Xb: m,
                Bn: n,
                gb: p,
                tc: r,
                Ri: v,
                oc: u,
                Ef: x,
                ac: D,
                ya: F,
                fa: c,
                cq: C,
                sd: d,
                Gm: G,
                yh: S,
                Eg: !!_.R(a, 64),
                gn: _.Fi(a, eD, 68),
                Nm: _.I(gq) ? _.IA(a, 1) : void 0
            }
        }
    }, {
        output: void 0
    });
    var fW = Sj(1220, function(a, b) {
        var c = b.V;
        b = b.context;
        var d;
        ((d = _.Fi(a.ec, tD, 69)) == null ? 0 : _.R(d, 1)) && Q(c, tQ(b.Ra));
        return {}
    }, {});
    var gW = Sj(803, function(a, b, c, d, e, f) {
        a = JSON.parse(c);
        var g = Zq(a, AB);
        if (!g) throw Error("missing ad unit path");
        if (a == null || !a[g]) throw Error("invalid ad unit path: " + g);
        a = a[g];
        if (!Array.isArray(a)) throw Error("dictionary not an array: " + c);
        c = kf(VD, a);
        a = Dv(c, 27);
        a = _.y(a);
        for (g = a.next(); !g.done; g = a.next()) g = g.value, _.Ri(Si).g(g);
        ip(4, b, e, f);
        d.dispatchEvent(QO, 800, c);
        return {
            output: c
        }
    }, {
        output: void 0
    });
    var hW = Sj(823, function(a, b, c) {
        Yr(a.ec, 11) && (_.aP(c, b), ZO(c, b, function() {
            _.bP(c, b)
        }));
        return {}
    }, {});
    var iW = function(a, b, c, d) {
        L.call(this, a.S, 67);
        this.context = a;
        this.slotId = b;
        a = d.L;
        b = d.ba;
        var e = d.Ab;
        var f = d.Xa;
        var g = d.ya;
        d = d.V;
        c = this.g(gW, {}, this.context, c, this.slotId, f, b).output;
        this.g(VS, {
            ec: c
        }, b, f);
        this.g($S, {
            ec: c
        }, this.slotId, e);
        this.g(hW, {
            ec: c
        }, this.slotId, a);
        a = this.g(eW, {
            ec: c
        }, {
            ya: g
        });
        this.g(fW, {
            ec: c
        }, {
            V: d,
            context: this.context
        });
        this.j = {
            oo: a.output
        }
    };
    _.T(iW, L);
    var jW = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u, x, D, F, C, G, S, P, J, U) {
        Z.call(this, a, 973);
        var ha = this;
        this.U = b;
        this.V = c;
        this.I = d;
        this.R = e;
        this.K = f;
        this.L = g;
        this.Xa = h;
        this.qd = l;
        this.Tb = k;
        this.G = m;
        this.Ne = n;
        this.ia = p;
        this.networkCode = r;
        this.isSecureContext = v;
        this.Rb = u;
        this.Ab = x;
        this.B = D;
        this.ga = F;
        this.j = P;
        this.ka = J;
        this.ue = U;
        this.A = [];
        this.oa = _.Rs(function() {
            return void qn(ha.context, 646, new HL("response slot array length exceeded"))
        });
        this.C = WM(this, C);
        this.ca = Y(this, G);
        this.pa = Y(this, S);
        this.j.Pb && YM(this, this.j.Pb.Ng)
    };
    _.T(jW, Z);
    jW.prototype.g = function() {
        var a = this,
            b = new L(this.context.S, 65);
        _.Sq(this, b);
        var c = this.ca.value,
            d = by(this.K.Z);
        this.C.value && this.ka.H(this.C.value);
        var e = su(this.context, this.ga);
        e && _.Sq(b, e.Ib);
        var f = Bt(this.context, _.Fi(this.K.Z, DQ, 5), this.L, this.I, e == null ? void 0 : e.Mo.Ge);
        e = f.Ch;
        (f = f.ho) && _.Sq(b, f);
        f = new QV(this.context, this.I, this.ga, this.K, this.B, e);
        M(b, f);
        var g = !!_.R(this.K.Z, 6);
        e = b.g(JV, {}, this.context, this.I, g, this.K, this.V, this.B, c).T;
        var h, l, k = b.g(HR, {}, d, c, (l = (h = _.Fi(this.K.Z, EQ, 36)) == null ? void 0 : _.DA(h, 1)) != null ? l : []).output;
        h = this.j;
        var m = h.Io,
            n = h.Ro,
            p = h.Mp,
            r = h.xj,
            v = h.Lm;
        h = h.pg;
        var u, x = (u = this.j.Pb) != null ? u : {},
            D = x.Fb,
            F = x.dg,
            C = x.dd,
            G = x.uf,
            S = x.Af,
            P = x.yn;
        l = x.Ui;
        var J = x.Yj;
        u = x.eh;
        x = x.Oi;
        if (_.I(KJ)) {
            var U = b.g(nU, {
                Qg: v
            }, {});
            v && uw(vw(U, _.K(JJ)), v);
            var ha = U.vl;
            U = b.g(oU, {
                Qg: v
            });
            v && uw(vw(U, _.K(JJ)), v);
            var ea = U.Ei;
            U = U.Di
        }
        if (_.I(vK) && p.aj) {
            _.I(qw);
            var Ba = new mV(this.context, this.B.navigator, e);
            M(b, Ba);
            Ba = Ba.output
        }
        if (J = Vv(this.context, p, this.K, c, this.C.value, e, k, J, ea, Ba)) {
            var ja = J.Op;
            J = J.Np;
            var ma = ja.hi;
            var ra = ja.rh;
            ja = ja.yf;
            _.Sq(b, J)
        }
        if (U = rv(this.context, p, this.B.navigator, k, U)) {
            var ia = U.Dl;
            U = U.Pp;
            var Oa = ia.Xk;
            ia = ia.jk;
            U && _.Sq(b, U)
        }
        _.I(pK) && (ia = X(this), ia.H(p.Pi));
        J = new HU(this.context, this.B);
        M(b, J);
        U = (D != null ? D : {}).hc;
        var fb = new iU(this.context, m.Jo);
        M(b, fb);
        if (D = Ys(this.context, this.V, this.K.Z, this.K.W, this.networkCode, c, e, D, C)) {
            var Ub = D.pm;
            _.Sq(this, D.Ib)
        }
        if (ra = uu(this.context, n, ra, ja, this.K, e, v)) {
            var Uc = ra.Wf;
            _.Sq(this, ra.Ib)
        }
        if (ha = cv(this.context, this.C.value, this.networkCode, h, k, ha, x)) {
            var vc = ha.Ip;
            _.Sq(this, ha.Ib);
            this.A.push(vc.We.promise)
        }!_.I(vK) && p.aj && (_.I(qw), Ba = new mV(this.context, this.B.navigator, e), M(b, Ba), Ba = Ba.output);
        ha = !!window.fetch && !!window.TextDecoderStream;
        var Ad = ++this.L.A;
        ra = this.Ne;
        var Zd, $d, Ne, Nm, Om, Pm;
        g = new PV(this.context, g, this.L, this.Xa, this.K, ra.kc, this.networkCode, ra.Vd, ra.Ud, this.pa.value, _.Ri(po), c, this.isSecureContext, this.Rb, ha, this.B, r.Id, (Zd = this.j.qo) == null ? void 0 : Zd.get(), fb.output, m.Jc, m.Sd, J.output, e, ($d = Ub) == null ? void 0 : $d.Hi, (Ne = vc) == null ? void 0 : Ne.og, (Nm = vc) == null ? void 0 : Nm.We, h == null ? void 0 : h.Td, f.output, F == null ? void 0 : F.Vh, U, C, G, S, P, (Om = Uc) == null ? void 0 : Om.pi, Oa, (Pm = this.j.Pb) == null ? void 0 : Pm.Yj, u, ea, Ba, this.ue);
        M(b, g);
        Ub = new dW(this.context, this.K, _.Ri(po), g.j, e);
        M(b, Ub);
        d = new KV(this.context, d, c);
        M(b, d);
        Uc = on(this.context, 646, function(fj, gj, hj, nh, ig, Qm, Rm, Nc) {
            return void kW(a, ig, fj, gj, hj, nh, Qm, Rm, Nc)
        });
        Zd = on(this.context, 647, function(fj, gj, hj) {
            return void lW(a, Ad, hj, gj, fj)
        });
        var Oe;
        $d = mW(this);
        Ne = nW(this);
        ha ? (ma = new YV(this.context, Uc, $d, Zd, Ne, c, this.L, this.K, Sp(), e, ma, Oa, g.j, Ub.output, d.output, (Oe = vc) == null ? void 0 : Oe.ng, ia, Ba), M(b, ma), Oe = ma.R, Oa = ma.G, ia = ma.A, _.K(QJ) > 0 && _.K(RJ) > 0 && b.g(RV, {
            Pe: ma.I
        }, {
            context: this.context
        })) : (ma = new WV(this.context, Uc, $d, Zd, c, this.L, this.K, e, ma, g.j, Ub.output, d.output), M(b, ma), Oe = ma.G, Oa = ma.C, ia = ma.A);
        ma = b.g(LV, {
            status: Oa,
            responseText: ia
        }, {
            V: this.V
        }).finished;
        this.A.push(ma.promise);
        ma = new MV(this.context, Ad, e, Oe, l, this.networkCode);
        M(b, ma);
        Oa = new HV(this.context, g.A, g.j);
        M(b, Oa);
        Oa = new OV(this.context, this.G.Ha, this.K, Oa.output);
        M(b, Oa);
        Oa = At(b.g(xU, {}, {
            qd: this.qd,
            B: this.B
        }), Oa.output).finished;
        Oa = new TT(this.context, this.K, this.Tb, e, Oa);
        M(b, Oa);
        e = new ES(this.context, this.L, this.K, this.ga, e, Oa.output);
        M(b, e);
        Oa = b.g(GU, {}, {
            context: this.context,
            Co: ql(this.B),
            B: this.B,
            ba: c,
            Rn: rm
        }).finished;
        Ad === 1 && (c = new DS(this.context, this.B, [].concat(_.Zk(this.U.T)), this.K.Z, c, h == null ? void 0 : h.Td, u, Oe), M(b, c), this.A.push(c.output.promise), U && _.K(Ow) === 2 && b.g(yS, {
            pbjs: U
        }));
        this.A.push(ma.output.promise, e.output.promise, Oa.promise);
        b.run()
    };
    var kW = function(a, b, c, d, e, f, g, h, l) {
            var k, m, n, p;
            return _.ug(function(r) {
                if (c >= f.length) return a.oa(), r.return();
                k = f[c];
                if (!k) return qn(a.context, 646, Error("missing slot")), r.return();
                c === 0 && (m = Ov(a.K.W[k.getDomId()], 20), Nv(_.Ri(po), "4", m));
                return r.yield(oW(a, k, d, e, b, (n = g) == null ? void 0 : n[k.getId()], h, (p = l) == null ? void 0 : p.get(k)), 0)
            })
        },
        lW = function(a, b, c, d, e) {
            var f, g, h;
            return _.ug(function(l) {
                if (l.g == 1) {
                    var k = a.context,
                        m = e + 1,
                        n = d.length,
                        p = bn(k);
                    if (p.ud) {
                        var r = k.va,
                            v = r.Fc;
                        k = an(k, p.kd);
                        p = new JG;
                        p = _.Fk(p, 3, b);
                        m = _.Pg(p, 1, m);
                        n = _.Pg(m, 2, n);
                        n = _.en(k, 8, fn, n);
                        v.call(r, n)
                    }
                    f = e + 1
                }
                if (l.g != 3) {
                    if (!(f < d.length)) return l.yield(pW(a), 0);
                    if (!d[f]) {
                        l.g = 3;
                        return
                    }
                    r = new VD;
                    r = _.Dl(r, 8, !0);
                    g = Fm(r);
                    h = '{"empty":' + g + "}";
                    return l.yield(kW(a, c, f, h, {
                        kind: 0,
                        nb: ""
                    }, d), 3)
                }++f;
                l.g = 2
            })
        },
        oW = function(a, b, c, d, e, f, g, h) {
            var l, k, m, n, p, r, v, u, x, D, F, C, G, S, P, J, U, ha;
            return _.ug(function(ea) {
                if (ea.g == 1) return l = {
                    ba: e,
                    Ab: a.Ab,
                    L: a.L,
                    Xa: a.Xa,
                    ya: d,
                    V: a.V
                }, k = new iW(a.context, b, c, l), ea.yield(Hu(k), 2);
                m = ea.o;
                p = n = m.oo;
                r = p.isEmpty;
                v = p.lb;
                u = p.fa;
                x = p.cq;
                D = p.Xb;
                F = p.gn;
                C = p.Nm;
                G = p.ya;
                S = p.height;
                P = p.width;
                var Ba = a.context,
                    ja = (J = a.j.Pb) == null ? void 0 : J.Fb;
                if (ja && !(Math.random() > .01)) {
                    var ma = new L(Ba.S, 16);
                    M(ma, new xS(Ba, x, D, v, ja.hc));
                    ma.run()
                }
                Ba = F;
                ja = a.B;
                ma = new L(a.context.S, 20);
                ma.g(KS, {}, Ba, ja);
                ma.run();
                Ba = a.context;
                var ra;
                ja = (ra = uA(a.K.W[b.getDomId()], hq, 31)) == null ? void 0 : _.R(ra, 1);
                ra = C === "vast";
                ma = b.J;
                var ia = bn(Ba),
                    Oa = ia.ud;
                ia = ia.kd;
                ja ? Ba.va.La.Ma.hb.Yi.ta({
                    wa: 1,
                    Tj: !0,
                    Bk: ra,
                    qk: r,
                    yk: ma
                }) : Oa && Ba.va.La.Ma.hb.Yi.ta({
                    wa: ia,
                    Tj: !1,
                    Bk: ra,
                    qk: r,
                    yk: ma
                });
                if (b.J) return ea.return();
                U = !!u || !!f;
                (ha = gt("google_norender")) || r && !U ? Sv(b, a.L, a.K, v) : _.I(gq) && C === "vast" ? (qc({
                    kind: jc(),
                    nb: wc
                }), ra = P === void 0 || S === void 0 ? void 0 : new _.mo(P, S), a.context.va.La.Ma.hb.outstream.kn.ta({
                    wa: 1,
                    gk: !!ra
                }), b.dispatchEvent(Rv, 825, {
                    isEmpty: !1,
                    vast: G.nb,
                    size: ra
                })) : EV(a.ia, a.U, a.V, b, r || ha, U, a.L, a.K, a.Ab, n, e, f, g, a.G.Ha, a.Tb, a.j, h);
                k.dispose();
                ea.g = 0
            })
        },
        mW = function(a) {
            return on(a.context, 289, function(b) {
                b = b instanceof Error ? b : Error();
                b.message = b.message || "strm_err";
                qn(a.context, 289, b);
                pW(a)
            })
        },
        nW = function(a) {
            return on(a.context, 1280, function() {
                pW(a)
            })
        },
        pW = function(a) {
            return _.ug(function(b) {
                if (b.g == 1) {
                    var c = a.L,
                        d = a.R,
                        e = c.o.get(d) - 1;
                    e === 0 ? c.o.delete(d) : c.o.set(d, e);
                    return e ? b.return() : b.yield(_.z.Promise.all(a.A), 2)
                }
                a.G.dk.dispatchEvent(UO, 965, a.R);
                b.g = 0
            })
        };
    var qW = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u, x, D, F, C, G, S, P, J) {
        Z.call(this, a, 885);
        this.R = b;
        this.V = c;
        this.K = d;
        this.L = e;
        this.Xa = f;
        this.Ne = g;
        this.qd = h;
        this.Tb = l;
        this.j = k;
        this.A = m;
        this.I = n;
        this.isSecureContext = p;
        this.Bb = r;
        this.G = v;
        this.Rb = u;
        this.Ab = x;
        this.B = D;
        this.ga = F;
        this.C = S;
        this.U = P;
        this.ue = J;
        this.ca = Y(this, C);
        YM(this, G)
    };
    _.T(qW, Z);
    qW.prototype.g = function() {
        var a = this.ca.value;
        if (a.length) {
            var b = this.L,
                c = this.j,
                d = a.length;
            b.o.has(c);
            b.o.set(c, d);
            a = _.y(a);
            for (b = a.next(); !b.done; b = a.next()) {
                c = b.value;
                var e = void 0;
                b = c.networkCode;
                d = c.T;
                c = new L(this.context.S, 64);
                _.Sq(this, c);
                var f = Fu(c, new Dw(this.context, window, this.G, (e = this.C.Pb) == null ? void 0 : e.yo)).A;
                e = Fu(c, new Gw(this.context, this.V, this.L, this.B, f, this.Rb, by(this.K.Z))).Rc;
                f = new pU(this.context, this.B, e);
                M(c, f);
                f = new US(this.context, this.B, new _.PL(this.B), e);
                M(c, f);
                f = new Zw(this.context, this.B, e);
                M(c, f);
                var g = new FV(this.context, this.Xa, this.Bb, e);
                M(c, g);
                b = new jW(this.context, this.R, this.V, d, this.j, this.K, this.L, this.Xa, this.qd, this.Tb, this.A, this.Ne, this.I, b, this.isSecureContext, this.Rb, this.Ab, this.B, this.ga, f.output, e, g.A, this.C, this.U, this.ue);
                M(c, b);
                c.run()
            }
        } else this.A.dk.dispatchEvent(UO, 965, this.j)
    };
    var rW = function(a, b, c) {
        PM.call(this, _.z.Promise.all(a.map(function(d) {
            return jy(d, b, c)
        })).then(function(d) {
            return d.filter(function(e) {
                return e != null && !e.J
            })
        }))
    };
    _.T(rW, PM);
    var iy = new _.z.Map;
    var sW = Sj(847, function(a, b, c, d) {
        a = a.T;
        if (!a.length) return {
            Ke: []
        };
        for (var e = _.y(a), f = e.next(); !f.done; f = e.next()) dP(b, f.value);
        return d ? {
            Ke: []
        } : c ? (b = ln(a[0].getAdUnitPath()), {
            Ke: ky(a, b)
        }) : {
            Ke: a.map(function(g) {
                return {
                    networkCode: ln(g.getAdUnitPath()),
                    T: [g]
                }
            })
        }
    }, {
        Ke: void 0
    });
    var tW = Sj(845, function(a, b) {
        a = a.T;
        var c = function(d) {
            return !!co(b[d.getDomId()]).length
        };
        return {
            xl: a.filter(c),
            Gl: a.filter(BB(c))
        }
    }, {
        xl: void 0,
        Gl: void 0
    });
    var uW = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r, v, u, x, D) {
        _.W.call(this);
        var F = this;
        this.context = a;
        this.C = b;
        this.V = c;
        this.L = d;
        this.Xa = e;
        this.Ha = f;
        this.qd = g;
        this.Tb = h;
        this.A = l;
        this.isSecureContext = k;
        this.Bb = m;
        this.F = n;
        this.Rb = p;
        this.Ab = r;
        this.ga = v;
        this.B = u;
        this.j = x;
        this.G = D;
        this.g = new _.z.Map;
        this.l = new MO(a);
        _.Sq(this, this.l);
        this.l.listen(UO, function(C) {
            C = C.detail;
            var G = F.g.get(C);
            G && (F.g.delete(C), G.dispose())
        })
    };
    _.T(uW, _.W);
    var vW = function(a, b, c, d) {
        var e = ++a.L.F;
        a.g.has(e);
        var f = new L(a.context.S, 66);
        a.g.set(e, f);
        b = (new rW(b, f, a.V)).output;
        if (!_.um(a.B.top) && window.IntersectionObserver) var g = f.l(JS, {
            T: b
        }, a.ga, a.context, f).output;
        var h = f.g(tW, {
            T: b
        }, d.W);
        b = h.Gl;
        h = f.g(sW, {
            T: h.xl
        }, a.L, !!_.R(d.Z, 6), gt("google_nofetch")).Ke;
        b = f.g(FS, {
            T: b
        }, a.L, d, a.ga).finished;
        a = new qW(a.context, a.C, a.V, d, a.L, a.Xa, c, a.qd, a.Tb, e, {
            dk: a.l,
            Ha: a.Ha
        }, a.A, a.isSecureContext, a.Bb, a.F, a.Rb, a.Ab, a.B, a.ga, h, b, a.j, a.G, g);
        M(f, a);
        f.run()
    };
    var wW = function(a, b, c, d, e, f, g, h, l, k, m, n, p, r) {
            oV.call(this, a, c, h);
            this.context = a;
            this.L = d;
            this.j = new _.z.Set;
            this.A = {};
            this.X = new DV(a, d);
            this.I = new uW(a, b, c, d, new _.PL(window), this.l, m, e, this.X, f, g, l, k, n, document, window, p, r);
            _.Sq(this, this.I)
        },
        zW, yW, QQ, BW, CW, DW;
    _.T(wW, oV);
    wW.prototype.getName = function() {
        return "publisher_ads"
    };
    wW.prototype.display = function(a, b, c, d, e) {
        d = d === void 0 ? "" : d;
        e = e === void 0 ? "" : e;
        var f = "";
        if (d)
            if (_.gb(d) && d.nodeType == 1) {
                var g = d;
                f = g.id
            } else f = d;
        this.enable();
        var h = Ap(c, this.context, this.V, a, b, f),
            l = h.slotId;
        h = h.settings;
        if (l && h) {
            g && !f && (g.id = l.getDomId());
            this.slotAdded(l, h);
            h.setClickUrl(e);
            var k;
            cw(this, (k = g) != null ? k : l.getDomId(), c)
        } else Q(this.V, wn("PubAdsService.display", [a, b, d]))
    };
    var cw = function(a, b, c) {
        var d = xW(b, c);
        c = d.slotId;
        var e = d.Vm;
        d = d.Wm;
        if (c) {
            if (d = qo(), (b = MQ(d, c.getDomId())) && !_.R(b, 19))
                if (e && d.l.set(c, e), vo(c) || fo(Wp(b))) {
                    if (_.Dl(b, 19, !0), e = ro(d.g, d.bb), _.I(HI) && !_.w(a.g, "includes").call(a.g, c) && (a.slotAdded(c, b), a.context.va.La.Ma.hb.lm.ta({
                            wa: 1
                        })), a.isEnabled()) {
                        a.enable();
                        yW(a, c);
                        a.V.info(CP());
                        b = e.Z;
                        d = e.W;
                        var f = _.R(b, 6);
                        if (f || !a.L.cd(c)) f && (f = vo(c)) && c.dispatchEvent(PO, 778, f), _.R(b, 4) && (d = d[c.getDomId()], f = a.L, bt(d, b) && !f.cd(c) && ct(c, document, d, b)), QQ(a, e, c)
                    }
                } else Q(a.V, sP(String(xl(b, 1)), String(xl(b, 2))), c)
        } else d ? a.V.error(tP(d)) : a.V.error(wn("googletag.display", [String(b)]))
    };
    wW.prototype.slotAdded = function(a, b) {
        var c = this;
        _.R(b, 17) || yW(this, a);
        this.l.dispatchEvent(SO, 724, {
            Fi: a.getDomId(),
            W: b
        });
        a.listen(Rv, function(d) {
            var e = d.detail;
            d = e.size;
            var f = e.isEmpty;
            var g = e.vast;
            e = new wT(a, "publisher_ads");
            f && (e.isEmpty = !0, e.slotContentChanged = !1);
            g && _.I(gq) && (e.vast = g);
            f = a.Ba.getResponseInformation();
            d && f && (e.size = [d.width, d.height], e.sourceAgnosticCreativeId = f.sourceAgnosticCreativeId, e.sourceAgnosticLineItemId = f.sourceAgnosticLineItemId, e.isBackfill = f.isBackfill, e.creativeId = f.creativeId, e.lineItemId = f.lineItemId, e.creativeTemplateId = f.creativeTemplateId, e.advertiserId = f.advertiserId, e.campaignId = f.campaignId, e.yieldGroupIds = f.yieldGroupIds, e.companyIds = f.companyIds);
            c.l.dispatchEvent("slotRenderEnded", 708, e)
        });
        a.listen(QO, function() {
            c.l.dispatchEvent("slotResponseReceived", 709, new ET(a, c.getName()))
        });
        Wp(b) === 4 && zW(this, "rewardedSlotClosed", a, b);
        Wp(b) === 7 && zW(this, "gameManualInterstitialSlotClosed", a, b);
        oV.prototype.slotAdded.call(this, a, b)
    };
    zW = function(a, b, c, d) {
        _.$q(c, a.l.listen(b, function(e) {
            c.Ba === e.detail.slot && (e = {}, AW(a, [c], qo().g, (e[c.getDomId()] = d, e), a.L))
        }))
    };
    yW = function(a, b) {
        a.isEnabled() && $O(a.L, b)
    };
    QQ = function(a, b, c) {
        var d = BW(a, b, c);
        CW(a, d, b, {
            kc: 1
        });
        b = c.getAdUnitPath();
        if (c = a.A[b]) {
            c = _.y(c);
            for (d = c.next(); !d.done; d = c.next()) d = d.value, CW(a, d.T, d.K, d.Ne);
            delete a.A[b]
        }
    };
    BW = function(a, b, c) {
        var d = b.Z,
            e = b.W[c.getDomId()];
        return _.R(d, 4) ? [] : !_.R(d, 6) || (e == null ? 0 : _.R(e, 17)) ? (a.j.add(c), _.$q(c, function() {
            return void a.j.delete(c)
        }), [c]) : a.g.filter(function(f) {
            if (a.j.has(f) || _.I(OJ) && !vo(f) && !fo(Wp(e))) return !1;
            a.j.add(f);
            _.$q(f, function() {
                return void a.j.delete(f)
            });
            return !0
        })
    };
    CW = function(a, b, c, d) {
        a.V.info(JP());
        if (DW(a, b, d, c) && d.kc !== 1)
            for (b = _.y(b), d = b.next(); !d.done; d = b.next()) d = d.value.getDomId(), a.l.dispatchEvent(TO, 725, {
                Fi: d,
                W: c.W[d]
            })
    };
    _.DU = function(a, b, c, d) {
        var e = qo(),
            f = MQ(e, b.getDomId());
        f && (_.tj(f, 32, c), vW(a.I, [b], {
            kc: 1
        }, ro(e.g, e.bb, d)))
    };
    DW = function(a, b, c, d) {
        b = b.filter(function(e) {
            var f = d.W[e.getDomId()],
                g = _.Qv(a.L, e);
            g === !1 && Q(a.V, rQ(String(Wp(f)), e.getAdUnitPath()));
            if (!g) return !1;
            (_.E = [5, 4, 7], _.w(_.E, "includes")).call(_.E, Wp(f)) && _.aP(a.L, e);
            return !0
        });
        if (!b.length) return null;
        vW(a.I, b, c, d);
        return b
    };
    wW.prototype.refresh = function(a, b, c) {
        c = c === void 0 ? {
            kc: 2
        } : c;
        b = EW(this, b);
        b.length && FW(this, a, b, c);
        return !0
    };
    var EW = function(a, b) {
            return b.filter(function(c, d) {
                if (!c.J) return !0;
                Q(a.V, MP(String(d)));
                return !1
            })
        },
        FW = function(a, b, c, d) {
            var e = c[0],
                f, g = (f = e == null ? void 0 : e.getDomId()) != null ? f : "";
            if (a.isEnabled()) {
                var h = _.y(c);
                e = h.next();
                for (f = {}; !e.done; f = {
                        ig: void 0
                    }, e = h.next()) f.ig = e.value, a.j.add(f.ig), _.$q(f.ig, function(l) {
                    return function() {
                        return void a.j.delete(l.ig)
                    }
                }(f));
                CW(a, c, b, d)
            } else c.length && _.R(b.Z, 6) ? (Q(a.V, IP(g), e), e = e.getAdUnitPath(), f = (h = a.A[e]) != null ? h : [], f.push({
                T: c,
                K: b,
                Ne: d
            }), a.A[e] = f) : Q(a.V, GP(g), e)
        };
    wW.prototype.G = function() {
        var a = qo().g;
        if (_.R(a, 6))
            for (var b = _.y(this.g), c = b.next(); !c.done; c = b.next()) yW(this, c.value);
        VQ(this, a);
        a = Sp();
        a.hasOwnProperty("pubadsReady") || (a.pubadsReady = !0)
    };
    wW.prototype.destroySlots = function(a) {
        a = oV.prototype.destroySlots.call(this, a);
        if (a.length && this.isEnabled()) {
            var b = qo();
            GW(this, a, b.g, b.bb)
        }
        return a
    };
    var XQ = function(a, b, c, d) {
            if (!a.isEnabled()) return Q(a.V, HP(), d[0]), !1;
            var e = EW(a, d);
            if (!e.length) return Q(a.V, wn("PubAdsService.clear", [d].filter(function(f) {
                return f !== void 0
            }))), !1;
            a.V.info(KP());
            GW(a, e, b, c);
            return !0
        },
        GW = function(a, b, c, d) {
            for (var e = _.y(b), f = e.next(); !f.done; f = e.next()) YO(a.L, f.value);
            AW(a, b, c, d, a.L)
        };
    wW.prototype.forceExperiment = function(a) {
        a = Number(a);
        a > 0 && _.Ri(Si).g(a)
    };
    var AW = function(a, b, c, d, e) {
            var f = f === void 0 ? window : f;
            b = _.y(b);
            for (var g = b.next(); !g.done; g = b.next()) {
                g = g.value;
                fP(a.X.L, g);
                var h = d[g.getDomId()];
                bt(h, c) && ct(g, f.document, h, c);
                dP(e, g)
            }
        },
        WQ = function(a, b, c, d) {
            if (typeof b !== "string" || typeof c !== "string") Q(a.V, wn("PubAdsService.setVideoContent", [b, c]));
            else {
                var e = _.Dl(d, 21, !0);
                b = _.tj(e, 22, b);
                _.tj(b, 23, c);
                VQ(a, d)
            }
        },
        YQ = function(a, b) {
            if (!a.isEnabled()) return null;
            var c, d;
            return {
                vid: (c = _.t(b, 22)) != null ? c : "",
                cmsid: (d = _.t(b, 23)) != null ? d : ""
            }
        },
        VQ = function(a, b) {
            _.R(b, 21) && a.isEnabled() && (a = tE(), _.vj(b, 29, _.xd(a)))
        },
        xW = function(a, b) {
            var c = "";
            if (typeof a === "string") c = a, b = BS(b, c);
            else if (_.gb(a) && a.nodeType == 1) {
                var d = a;
                c = d.id;
                b = BS(b, c)
            } else b = (_.E = [].concat(_.Zk(b.T)), _.w(_.E, "find")).call(_.E, function(e) {
                return e.Ba === a
            });
            return {
                slotId: b,
                Vm: d,
                Wm: c
            }
        };
    var uy = Ny(["https://pagead2.googlesyndication.com/pagead/js/rum_debug.js"]),
        vy = Ny(["https://pagead2.googlesyndication.com/pagead/js/rum.js"]);
    var HW = My(["^[-p{L}p{M}p{N}_,.!*<>():/]*$"], ["^[-\\p{L}\\p{M}\\p{N}_,\\.!*<>():/]*$"]),
        IW = _.Rs(function() {
            pE("The googletag.pubads().definePassback function has been deprecated. The function may break in certain contexts, see https://developers.google.com/publisher-tag/guides/passback-tags#construct_passback_tags for how to correctly create a passback.")
        }),
        KW = function(a, b) {
            var c = this;
            var d = d === void 0 ? _.w(String, "raw").call(String, HW) : d;
            this.L = a;
            this.o = d;
            this.g = new _.z.Map;
            this.T = new _.z.Set;
            b.l = function(e) {
                return JW(c, e)
            }
        };
    KW.prototype.defineSlot = function(a, b, c, d, e) {
        a = Ap(this, a, b, c, d, e);
        var f = a.slotId;
        if (f) return f.Ba;
        a.tf || b.error(wn("googletag.defineSlot", [c, d, e]));
        return null
    };
    var Ap = function(a, b, c, d, e, f, g) {
        return typeof d === "string" && d.length > 0 && e && (f === void 0 || typeof f === "string") ? a.add(b, c, d, e, {
            Qb: f,
            Qk: g === void 0 ? !1 : g
        }) : {}
    };
    KW.prototype.add = function(a, b, c, d, e, f) {
        var g = this;
        var h = e.Qb;
        var l = e.format === void 0 ? 0 : e.format;
        var k = e.Qk === void 0 ? !1 : e.Qk;
        e = e.Kb === void 0 ? !1 : e.Kb;
        f = f === void 0 ? _.ca : f;
        try {
            var m = new RegExp(this.o, "u");
            if (m.test("/1") && !m.test(c)) return b.error(vP(c)), {
                tf: !0
            }
        } catch (p) {}
        f = Rq(l, f, e);
        f === null || _.w(bU, "includes").call(bU, l) || Yt(a, f, l);
        if (f) return yq(b, f, l, c), {};
        k && IW();
        l = this.g.get(c) || Number(k);
        b = LW(this, a, b, c, l, d, h || "gpt_unit_" + c + "_" + l);
        a = b.settings;
        var n = b.slotId;
        b = b.tf;
        if (!n) return {
            tf: b
        };
        this.g.set(c, l + 1);
        this.T.add(n);
        _.$q(n, function() {
            return void g.T.delete(n)
        });
        GO(c);
        return {
            slotId: n,
            settings: a
        }
    };
    var BS = function(a, b) {
            a = _.y(a.T);
            for (var c = a.next(); !c.done; c = a.next())
                if (c = c.value, c.getDomId() === b) return c
        },
        aw = function(a) {
            a = _.y(a);
            for (var b = a.next(); !b.done; b = a.next()) b.value.dispose()
        },
        LW = function(a, b, c, d, e, f, g) {
            var h = BS(a, g);
            if (h) return c.error(uP(g, d, h.getAdUnitPath())), {
                tf: !0
            };
            var l = new eR;
            fR(_.tj(l, 1, d), g);
            gR(l, Qp(f));
            LQ(l);
            var k = new nc(b, d, e, g);
            SQ(k, nq(b, c, k));
            _.$q(k, function() {
                var m = qo(),
                    n = k.getDomId();
                delete m.bb[n];
                m.l.delete(k);
                delete m.o[n];
                m = k.getAdUnitPath();
                m = ln(m);
                var p;
                n = ((p = Vr.get(m)) != null ? p : 0) - 1;
                n <= 0 ? Vr.delete(m) : Vr.set(m, n);
                c.info(RP(k.toString()), k);
                (p = rn.get(k)) && sn.delete(p);
                rn.delete(k)
            });
            c.info(jP(k.toString()), k);
            k.listen(RO, function(m) {
                m = m.detail.lp;
                c.info(kP(k.getAdUnitPath()), k);
                sO(_.Ri(po), "7", 9, rt(a.L, k), 0, m)
            });
            k.listen(QO, function(m) {
                var n = m.detail;
                c.info(lP(k.getAdUnitPath()), k);
                var p;
                m = _.Ri(po);
                var r = Ov(l, 20);
                n = (p = n.getEscapedQemQueryId()) != null ? p : "";
                m.g && (_.ca.google_timing_params = _.ca.google_timing_params || {}, _.ca.google_timing_params["qqid." + r] = n)
            });
            k.listen(Pv, function() {
                return void c.info(mP(k.getAdUnitPath()), k)
            });
            k.listen(Rv, function() {
                return void c.info(nP(k.getAdUnitPath()), k)
            });
            return {
                settings: l,
                slotId: k
            }
        },
        JW = function(a, b) {
            var c = new RegExp("(^|,|/)" + b + "($|,|/)");
            return [].concat(_.Zk(a.T)).some(function(d) {
                return c.test(ln(d.getAdUnitPath()))
            })
        };
    (function(a, b) {
        var c = a != null ? a : {
            pvsid: ql(window),
            Ra: "m202411060201",
            Df: "202411060201",
            va: new Ay(3, "m202411060201", 0),
            Ai: !0,
            fh: 1
        };
        try {
            Jb(function(ia) {
                qn(c, 1190, ia)
            });
            var d = Sp();
            hc(!_.Ri(Tn).g);
            _.w(Object, "assign").call(Object, Un, d._vars_);
            d._vars_ = Un;
            if (d.evalScripts) d.evalScripts();
            else {
                PN();
                try {
                    rj()
                } catch (ia) {
                    qn(c, 408, ia)
                }
                nt();
                var e = new RR;
                try {
                    mj(e.C), fp(13, c), fp(3, c)
                } catch (ia) {
                    qn(c, 408, ia)
                }
                var f = zy(c, e),
                    g = a != null ? a : Dy(f, c),
                    h = b != null ? b : new QR(g);
                gn(g);
                var l = dr(d, new _.mn(g));
                ks("gpt_fifwin", function(ia) {
                    yr(ia, g)
                }, d.fifWin ? .01 : 0);
                var k = new XO,
                    m = new KW(k, e),
                    n = new tV(g),
                    p = _.Vn(260),
                    r = new MO(g),
                    v = new MO(g),
                    u = new MO(g),
                    x = _.Vn(150),
                    D = fE(),
                    F = _.R(uA(l.data, AR, 1), 5),
                    C = Tw(g, m, h, k, p, e, r, F),
                    G = new qU,
                    S = new XS,
                    P, J, U, ha = (U = (P = C.Pb) == null ? void 0 : (J = P.dg) == null ? void 0 : J.Sb) != null ? U : new Ws,
                    ea = new wW(g, m, h, k, n, D, e, r, p, F, G, S, C, ha),
                    Ba = {
                        Tb: n,
                        kh: x,
                        fe: C.Rc,
                        jc: ea
                    };
                if (_.I(rw)) {
                    var ja;
                    (new zR(g, d, h, m, qo(), (ja = C.Pb) == null ? void 0 : ja.Me, Ba)).run()
                }
                _.I(zK) && new CS(g, r, k, m);
                var ma = qo().g;
                kw(g, h, ea, ma, m, v, u, e, S, Ba, ha);
                rr(g, d, h);
                window.setTimeout(function() {
                    for (var ia = window.document.scripts, Oa = 0, fb = 0, Ub = 0; Ub < ia.length; Ub++) ia[Ub].src.match("securepubads.g.doubleclick.net/tag/js/gpt.js") ? Oa++ : ia[Ub].src.match("www.googletagservices.com/tag/js/gpt.js") && fb++;
                    Oa > 1 && fb === 0 || fb > 1 && Oa === 0 ? Q(h, pQ()) : fb > 0 && Oa > 0 && h.error(qQ())
                }, 1E3);
                Yv();
                if (_.I(zK) || _.Ri(po).g) sy(), wy();
                ur(g);
                var ra;
                ((ra = C.Pb) == null ? 0 : ra.Tf) && Iu(g, ea, h, m, n, x, C.Pb.Tf, C.Rc)
            }
        } catch (ia) {
            qn(c, 106, ia)
        }
    })();
    _.MW = _.ca.requestAnimationFrame || _.ca.webkitRequestAnimationFrame;
    _.NW = !!_.MW && !/'iPhone'/.test(_.ca.navigator.userAgent);
    _.OW = function(a, b, c) {
        _.W.call(this);
        var d = this;
        this.j = a;
        this.l = b;
        this.g = c;
        this.ia = null;
        _.$q(this, function() {
            return d.ia = null
        })
    };
    _.T(_.OW, _.W);
}).call(this, {});