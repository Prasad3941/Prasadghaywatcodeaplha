"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6417], {
        66417: function(e, t, n) {
            n.d(t, {
                oC: function() {
                    return $
                },
                VY: function() {
                    return D
                },
                ZA: function() {
                    return T
                },
                ck: function() {
                    return U
                },
                wU: function() {
                    return W
                },
                __: function() {
                    return F
                },
                Uv: function() {
                    return N
                },
                Ee: function() {
                    return S
                },
                Rk: function() {
                    return A
                },
                fC: function() {
                    return y
                },
                Z0: function() {
                    return Y
                },
                Tr: function() {
                    return I
                },
                tu: function() {
                    return j
                },
                fF: function() {
                    return V
                },
                xz: function() {
                    return O
                }
            });
            var r = n(87462),
                o = n(67294);

            function u(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (null == e || e(r), !1 === n || !r.defaultPrevented) return null == t ? void 0 : t(r)
                }
            }
            n(73935);
            var a = n(4222);
            let i = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                let n = (0, o.forwardRef)((e, n) => {
                    let {
                        asChild: u,
                        ...i
                    } = e, l = u ? a.g7 : t;
                    return (0, o.useEffect)(() => {
                        window[Symbol.for("radix-ui")] = !0
                    }, []), (0, o.createElement)(l, (0, r.Z)({}, i, {
                        ref: n
                    }))
                });
                return n.displayName = `Primitive.${t}`, { ...e,
                    [t]: n
                }
            }, {});
            var l = n(7821);

            function c(e) {
                let t = (0, o.useRef)(e);
                return (0, o.useEffect)(() => {
                    t.current = e
                }), (0, o.useMemo)(() => (...e) => {
                    var n;
                    return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                }, [])
            }
            let f = "ContextMenu",
                [d, p] = function(e, t = []) {
                    let n = [],
                        r = () => {
                            let t = n.map(e => (0, o.createContext)(e));
                            return function(n) {
                                let r = (null == n ? void 0 : n[e]) || t;
                                return (0, o.useMemo)(() => ({
                                    [`__scope${e}`]: { ...n,
                                        [e]: r
                                    }
                                }), [n, r])
                            }
                        };
                    return r.scopeName = e, [function(t, r) {
                        let u = (0, o.createContext)(r),
                            a = n.length;

                        function i(t) {
                            let {
                                scope: n,
                                children: r,
                                ...i
                            } = t, l = (null == n ? void 0 : n[e][a]) || u, c = (0, o.useMemo)(() => i, Object.values(i));
                            return (0, o.createElement)(l.Provider, {
                                value: c
                            }, r)
                        }
                        return n = [...n, r], i.displayName = t + "Provider", [i, function(n, i) {
                            let l = (null == i ? void 0 : i[e][a]) || u,
                                c = (0, o.useContext)(l);
                            if (c) return c;
                            if (void 0 !== r) return r;
                            throw Error(`\`${n}\` must be used within \`${t}\``)
                        }]
                    }, function(...e) {
                        let t = e[0];
                        if (1 === e.length) return t;
                        let n = () => {
                            let n = e.map(e => ({
                                useScope: e(),
                                scopeName: e.scopeName
                            }));
                            return function(e) {
                                let r = n.reduce((t, {
                                    useScope: n,
                                    scopeName: r
                                }) => {
                                    let o = n(e)[`__scope${r}`];
                                    return { ...t,
                                        ...o
                                    }
                                }, {});
                                return (0, o.useMemo)(() => ({
                                    [`__scope${t.scopeName}`]: r
                                }), [r])
                            }
                        };
                        return n.scopeName = t.scopeName, n
                    }(r, ...t)]
                }(f, [l.Wf]),
                s = (0, l.Wf)(),
                [m, h] = d(f),
                x = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        disabled: a = !1,
                        ...c
                    } = e, f = h("ContextMenuTrigger", n), d = s(n), p = (0, o.useRef)({
                        x: 0,
                        y: 0
                    }), m = (0, o.useRef)({
                        getBoundingClientRect: () => DOMRect.fromRect({
                            width: 0,
                            height: 0,
                            ...p.current
                        })
                    }), x = (0, o.useRef)(0), v = (0, o.useCallback)(() => window.clearTimeout(x.current), []), C = e => {
                        p.current = {
                            x: e.clientX,
                            y: e.clientY
                        }, f.onOpenChange(!0)
                    };
                    return (0, o.useEffect)(() => v, [v]), (0, o.useEffect)(() => void(a && v()), [a, v]), (0, o.createElement)(o.Fragment, null, (0, o.createElement)(l.ee, (0, r.Z)({}, d, {
                        virtualRef: m
                    })), (0, o.createElement)(i.span, (0, r.Z)({
                        "data-state": f.open ? "open" : "closed",
                        "data-disabled": a ? "" : void 0
                    }, c, {
                        ref: t,
                        style: {
                            WebkitTouchCallout: "none",
                            ...e.style
                        },
                        onContextMenu: a ? e.onContextMenu : u(e.onContextMenu, e => {
                            v(), C(e), e.preventDefault()
                        }),
                        onPointerDown: a ? e.onPointerDown : u(e.onPointerDown, k(e => {
                            v(), x.current = window.setTimeout(() => C(e), 700)
                        })),
                        onPointerMove: a ? e.onPointerMove : u(e.onPointerMove, k(v)),
                        onPointerCancel: a ? e.onPointerCancel : u(e.onPointerCancel, k(v)),
                        onPointerUp: a ? e.onPointerUp : u(e.onPointerUp, k(v))
                    })))
                }),
                v = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = h("ContextMenuContent", n), i = s(n), c = (0, o.useRef)(!1);
                    return (0, o.createElement)(l.VY, (0, r.Z)({}, i, u, {
                        ref: t,
                        side: "right",
                        sideOffset: 2,
                        align: "start",
                        onCloseAutoFocus: t => {
                            var n;
                            null === (n = e.onCloseAutoFocus) || void 0 === n || n.call(e, t), !t.defaultPrevented && c.current && t.preventDefault(), c.current = !1
                        },
                        onInteractOutside: t => {
                            var n;
                            null === (n = e.onInteractOutside) || void 0 === n || n.call(e, t), t.defaultPrevented || a.modal || (c.current = !0)
                        },
                        style: { ...e.style,
                            "--radix-context-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
                            "--radix-context-menu-content-available-width": "var(--radix-popper-available-width)",
                            "--radix-context-menu-content-available-height": "var(--radix-popper-available-height)",
                            "--radix-context-menu-trigger-width": "var(--radix-popper-anchor-width)",
                            "--radix-context-menu-trigger-height": "var(--radix-popper-anchor-height)"
                        }
                    }))
                }),
                C = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = s(n);
                    return (0, o.createElement)(l.ZA, (0, r.Z)({}, a, u, {
                        ref: t
                    }))
                }),
                _ = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = s(n);
                    return (0, o.createElement)(l.__, (0, r.Z)({}, a, u, {
                        ref: t
                    }))
                }),
                g = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = s(n);
                    return (0, o.createElement)(l.ck, (0, r.Z)({}, a, u, {
                        ref: t
                    }))
                }),
                w = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = s(n);
                    return (0, o.createElement)(l.oC, (0, r.Z)({}, a, u, {
                        ref: t
                    }))
                }),
                E = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = s(n);
                    return (0, o.createElement)(l.Ee, (0, r.Z)({}, a, u, {
                        ref: t
                    }))
                }),
                M = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = s(n);
                    return (0, o.createElement)(l.Rk, (0, r.Z)({}, a, u, {
                        ref: t
                    }))
                }),
                R = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = s(n);
                    return (0, o.createElement)(l.wU, (0, r.Z)({}, a, u, {
                        ref: t
                    }))
                }),
                P = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = s(n);
                    return (0, o.createElement)(l.Z0, (0, r.Z)({}, a, u, {
                        ref: t
                    }))
                }),
                b = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = s(n);
                    return (0, o.createElement)(l.fF, (0, r.Z)({}, a, u, {
                        ref: t
                    }))
                }),
                Z = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeContextMenu: n,
                        ...u
                    } = e, a = s(n);
                    return (0, o.createElement)(l.tu, (0, r.Z)({}, a, u, {
                        ref: t,
                        style: { ...e.style,
                            "--radix-context-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
                            "--radix-context-menu-content-available-width": "var(--radix-popper-available-width)",
                            "--radix-context-menu-content-available-height": "var(--radix-popper-available-height)",
                            "--radix-context-menu-trigger-width": "var(--radix-popper-anchor-width)",
                            "--radix-context-menu-trigger-height": "var(--radix-popper-anchor-height)"
                        }
                    }))
                });

            function k(e) {
                return t => "mouse" !== t.pointerType ? e(t) : void 0
            }
            let y = e => {
                    let {
                        __scopeContextMenu: t,
                        children: n,
                        onOpenChange: u,
                        dir: a,
                        modal: i = !0
                    } = e, [f, d] = (0, o.useState)(!1), p = s(t), h = c(u), x = (0, o.useCallback)(e => {
                        d(e), h(e)
                    }, [h]);
                    return (0, o.createElement)(m, {
                        scope: t,
                        open: f,
                        onOpenChange: x,
                        modal: i
                    }, (0, o.createElement)(l.fC, (0, r.Z)({}, p, {
                        dir: a,
                        open: f,
                        onOpenChange: x,
                        modal: i
                    }), n))
                },
                O = x,
                N = e => {
                    let {
                        __scopeContextMenu: t,
                        ...n
                    } = e, u = s(t);
                    return (0, o.createElement)(l.h_, (0, r.Z)({}, u, n))
                },
                D = v,
                T = C,
                F = _,
                U = g,
                $ = w,
                S = E,
                A = M,
                W = R,
                Y = P,
                I = e => {
                    let {
                        __scopeContextMenu: t,
                        children: n,
                        onOpenChange: u,
                        open: a,
                        defaultOpen: i
                    } = e, f = s(t), [d, p] = function({
                        prop: e,
                        defaultProp: t,
                        onChange: n = () => {}
                    }) {
                        let [r, u] = function({
                            defaultProp: e,
                            onChange: t
                        }) {
                            let n = (0, o.useState)(e),
                                [r] = n,
                                u = (0, o.useRef)(r),
                                a = c(t);
                            return (0, o.useEffect)(() => {
                                u.current !== r && (a(r), u.current = r)
                            }, [r, u, a]), n
                        }({
                            defaultProp: t,
                            onChange: n
                        }), a = void 0 !== e, i = a ? e : r, l = c(n);
                        return [i, (0, o.useCallback)(t => {
                            if (a) {
                                let n = "function" == typeof t ? t(e) : t;
                                n !== e && l(n)
                            } else u(t)
                        }, [a, e, u, l])]
                    }({
                        prop: a,
                        defaultProp: i,
                        onChange: u
                    });
                    return (0, o.createElement)(l.Tr, (0, r.Z)({}, f, {
                        open: d,
                        onOpenChange: p
                    }), n)
                },
                V = b,
                j = Z
        }
    }
]);