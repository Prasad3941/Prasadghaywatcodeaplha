"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6885], {
        45781: function(e, t) {
            t.Z = {
                src: "/_next/static/media/globe-image.6a4598d5.png",
                height: 824,
                width: 824,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAABlBMVEUKCgoBAQFOLwmMAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAFklEQVR4nGNgZGRkAAMkBoTGz0DTBQADTgAVHwIAjQAAAABJRU5ErkJggg==",
                blurWidth: 8,
                blurHeight: 8
            }
        },
        77754: function(e, t, n) {
            n.d(t, {
                d: function() {
                    return a
                }
            });
            var s = n(85893),
                r = n(93967),
                l = n.n(r);
            n(67294);
            var i = n(37559);

            function a(e) {
                let {
                    value: t = 0,
                    minDigits: n = 1,
                    className: r
                } = e, a = (0, i.Z)(t).split(""), c = n - a.length;
                if (c > 0)
                    for (let e = 0; e < c; e++) a.unshift("0");
                return (0, s.jsx)("div", {
                    className: l()("relative inline-flex overflow-hidden", r),
                    children: a.map((e, t) => {
                        let n = "," === e ? 10 : parseInt(e);
                        return (0, s.jsxs)("div", {
                            className: "relative",
                            children: [(0, s.jsx)("span", {
                                className: "opacity-0",
                                "aria-live": "polite",
                                children: e
                            }), (0, s.jsxs)("div", {
                                "aria-hidden": "true",
                                className: "pointer-events-none absolute left-0 top-0 flex flex-col transition-transform duration-1000 ease-out-bounce",
                                style: {
                                    transform: "translateY(".concat(-(n / 11 * 100), "%)")
                                },
                                children: [(0, s.jsx)("span", {
                                    children: "0"
                                }), (0, s.jsx)("span", {
                                    children: "1"
                                }), (0, s.jsx)("span", {
                                    children: "2"
                                }), (0, s.jsx)("span", {
                                    children: "3"
                                }), (0, s.jsx)("span", {
                                    children: "4"
                                }), (0, s.jsx)("span", {
                                    children: "5"
                                }), (0, s.jsx)("span", {
                                    children: "6"
                                }), (0, s.jsx)("span", {
                                    children: "7"
                                }), (0, s.jsx)("span", {
                                    children: "8"
                                }), (0, s.jsx)("span", {
                                    children: "9"
                                }), (0, s.jsx)("span", {
                                    children: ","
                                })]
                            })]
                        }, t)
                    })
                })
            }
        },
        37559: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return s
                }
            });

            function s(e) {
                return Intl.NumberFormat("en-us").format(e).toString()
            }
        },
        13492: function(e, t, n) {
            n.r(t);
            var s = n(85893),
                r = n(93967),
                l = n.n(r),
                i = n(93792),
                a = n(24368),
                c = n(4960),
                o = n(19575),
                u = n(25675),
                d = n.n(u),
                f = n(67294),
                h = n(45781),
                m = n(55112),
                g = n(33613),
                p = n(77754),
                x = n(21611),
                A = n(72748),
                v = n(46178);

            function j(e) {
                let {
                    showResults: t,
                    ping: n,
                    running: r,
                    edgeLocation: i,
                    onPing: a
                } = e;
                return (0, s.jsxs)("div", {
                    className: "absolute bottom-gutter left-gutter right-gutter z-30 flex flex-row items-end justify-between gap-2.5 sm:gap-3",
                    children: [(0, s.jsx)("div", {
                        className: "flex flex-col gap-1 font-mono text-2xs uppercase tracking-wide",
                        children: t && (0, s.jsxs)(s.Fragment, {
                            children: [(0, s.jsx)("div", {
                                className: "font-semibold text-marketing-subtler",
                                children: "Edge location"
                            }), i && (0, s.jsxs)("div", {
                                className: "inline-flex items-center gap-1.5",
                                children: [(0, s.jsxs)("span", {
                                    children: [(0, s.jsx)("svg", {
                                        className: "fill-marketing",
                                        width: "12",
                                        height: "12",
                                        viewBox: "0 0 12 12",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, s.jsx)("path", {
                                            fillRule: "evenodd",
                                            clipRule: "evenodd",
                                            d: "M6.5 6C7.88071 6 9 4.88071 9 3.5C9 2.11929 7.88071 1 6.5 1C5.11929 1 4 2.11929 4 3.5C4 4.88071 5.11929 6 6.5 6ZM6.5 6H7V11H6V6H6.5Z",
                                            fill: "fill-current"
                                        })
                                    }), (0, s.jsx)("span", {
                                        className: "sr-only",
                                        children: "Location"
                                    })]
                                }), " ", (0, s.jsxs)("span", {
                                    className: l()({
                                        "text-marketing-subtler": r
                                    }),
                                    children: [i.city, ",", i.countryCode]
                                })]
                            }), (0, s.jsxs)("div", {
                                className: "inline-flex items-center gap-1.5",
                                children: [(0, s.jsxs)("span", {
                                    children: [(0, s.jsxs)("svg", {
                                        className: "fill-marketing",
                                        width: "12",
                                        height: "12",
                                        viewBox: "0 0 12 12",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: [(0, s.jsx)("path", {
                                            d: "M5 1L1 5H12V4H5V1Z",
                                            fill: "fill-current"
                                        }), (0, s.jsx)("path", {
                                            d: "M8 11L12 7H1V8H8V11Z",
                                            fill: "fill-current"
                                        })]
                                    }), (0, s.jsx)("span", {
                                        className: "sr-only",
                                        children: "Ping"
                                    })]
                                }), " ", (0, s.jsxs)("span", {
                                    className: l()({
                                        "text-marketing-subtler": r
                                    }),
                                    children: [(0, s.jsx)(p.d, {
                                        value: Math.round(n)
                                    }), (0, s.jsx)("span", {
                                        className: "lowercase",
                                        children: "ms"
                                    })]
                                })]
                            })]
                        })
                    }), (0, s.jsx)(g.z, {
                        size: "sm",
                        className: "pointer-events-auto backdrop-blur-sm",
                        disabled: r,
                        onClick: a,
                        children: "Ping"
                    })]
                })
            }
            t.default = function() {
                let [e, t] = (0, f.useState)(!1), {
                    ping: n,
                    running: r,
                    refresh: l,
                    ready: u
                } = (0, v.F)(), g = (0, A.M)(), p = (0, f.useRef)(null), [, b] = (0, x.Z)(p), w = (0, f.useRef)(), k = (0, f.useMemo)(() => (e && (null == g ? void 0 : g.longitude) ? (0, a.v)(g.longitude, [180, -180], [0, 2 * Math.PI]) : 4.8) + 1.1, [g, e]), N = (0, c.c)(k), [R, C] = (0, f.useState)(!1);
                (0, f.useEffect)(() => {
                    if (!p.current) return;
                    let e = 0,
                        t = (null != b ? b : 588) * window.devicePixelRatio;
                    try {
                        w.current = (0, i.Z)(p.current, {
                            devicePixelRatio: window.devicePixelRatio,
                            width: t,
                            height: t,
                            phi: N.get(),
                            theta: .3,
                            dark: 1,
                            diffuse: 2,
                            mapSamples: 16e3,
                            mapBrightness: 1.2,
                            scale: 1.4,
                            offset: [t / 2, 0],
                            baseColor: [.3, .3, .3],
                            markerColor: [1, 1, 1],
                            glowColor: [.1, .1, .1],
                            opacity: .95,
                            markers: m.ar.map(e => {
                                let {
                                    longitude: t,
                                    latitude: n
                                } = e;
                                return {
                                    location: [n, t],
                                    size: .03
                                }
                            }),
                            onRender: t => {
                                t.phi = N.get(), w.current && !N.isAnimating() && e++ > 60 && (w.current.shouldRender = !1)
                            }
                        })
                    } catch (e) {
                        C(!0)
                    }
                    return () => {
                        var e;
                        null === (e = w.current) || void 0 === e || e.destroy()
                    }
                }, [b, N]);
                let E = (0, f.useCallback)(() => {
                    t(!0), l()
                }, [l]);
                return (0, f.useEffect)(() => {
                    w.current && e && ((0, o.j)(N, k, {
                        duration: 1,
                        ease: [.6, 0, .4, 1]
                    }), w.current.shouldRender = !0, w.current.render())
                }, [k, N, e]), (0, s.jsxs)(s.Fragment, {
                    children: [R ? (0, s.jsx)("div", {
                        className: "absolute bottom-0 right-0 z-10 aspect-square h-full w-auto overflow-hidden mix-blend-screen",
                        children: (0, s.jsx)(d(), {
                            src: h.Z,
                            alt: "A globe"
                        })
                    }) : (0, s.jsx)("canvas", {
                        className: "absolute bottom-0 right-0 z-10 aspect-square h-full w-auto overflow-hidden mix-blend-screen",
                        ref: p
                    }), n && u ? (0, s.jsx)(j, {
                        ping: n,
                        running: r,
                        edgeLocation: g,
                        onPing: E,
                        showResults: e
                    }) : null]
                })
            }
        },
        25111: function(e, t, n) {
            n.d(t, {
                d: function() {
                    return l
                }
            });
            var s = n(67294),
                r = n(48529);

            function l(e) {
                let t = (0, s.useRef)(e);
                return (0, r.L)(() => {
                    t.current = e
                }), t
            }
        },
        46178: function(e, t, n) {
            n.d(t, {
                F: function() {
                    return o
                }
            });
            var s = n(10893),
                r = n(67294),
                l = n(25111);
            let i = {
                    publicApiKey: "pk_prod_5rf_6bmkkT7gmksNnVdSStdIz8gXmSHFaBV2SkkhyRfHAOVxHFGfsILgGNfUabLQ",
                    throttle: 80
                },
                a = (0, s.eI)(i),
                c = (0, s.eI)(i);

            function o() {
                let [e, t] = (0, r.useState)(), n = (0, r.useRef)(), s = (0, r.useRef)(), [i, o] = (0, r.useState)(!1), [u, d] = (0, r.useState)(!1), [f, h] = (0, r.useState)(!1), m = i && u;
                (0, r.useEffect)(() => {
                    let e = "liveblocks.io-ping-test-" + Math.random().toString(36).slice(-8),
                        {
                            room: r,
                            leave: l
                        } = a.enterRoom(e, {
                            initialPresence: {}
                        }),
                        {
                            room: i,
                            leave: u
                        } = c.enterRoom(e, {
                            initialPresence: {}
                        });
                    return n.current = r, s.current = i, n.current.subscribe("event", e => {
                        let {
                            event: n
                        } = e;
                        t(performance.now() - n.time), h(!1)
                    }), n.current.subscribe("status", e => {
                        o("connected" === e)
                    }), s.current.subscribe("status", e => {
                        d("connected" === e)
                    }), () => {
                        l(), u()
                    }
                }, []);
                let g = (0, r.useCallback)(() => {
                        !f && s.current && (h(!0), s.current.broadcastEvent({
                            type: "PING_TEST",
                            time: performance.now()
                        }))
                    }, [f, s]),
                    p = (0, l.d)(g);
                return (0, r.useEffect)(() => {
                    m && (h(!1), setTimeout(() => {
                        p.current()
                    }, 140))
                }, [p, m]), {
                    refresh: g,
                    ready: m,
                    running: f,
                    ping: e
                }
            }
        }
    }
]);