"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4919], {
        92936: function(e, t, r) {
            r.d(t, {
                M: function() {
                    return i
                }
            });
            var n = r(67294),
                o = r.t(n, 2);
            let u = (null == globalThis ? void 0 : globalThis.document) ? n.useLayoutEffect : () => {},
                l = o["useId".toString()] || (() => void 0),
                c = 0;

            function i(e) {
                let [t, r] = n.useState(l());
                return u(() => {
                    e || r(e => null != e ? e : String(c++))
                }, [e]), e || (t ? `radix-${t}` : "")
            }
        },
        74919: function(e, t, r) {
            r.d(t, {
                ck: function() {
                    return A
                },
                fC: function() {
                    return _
                },
                Pc: function() {
                    return E
                }
            });
            var n = r(87462),
                o = r(67294);

            function u(e, t, {
                checkForDefaultPrevented: r = !0
            } = {}) {
                return function(n) {
                    if (null == e || e(n), !1 === r || !n.defaultPrevented) return null == t ? void 0 : t(n)
                }
            }

            function l(e, t = []) {
                let r = [],
                    n = () => {
                        let t = r.map(e => (0, o.createContext)(e));
                        return function(r) {
                            let n = (null == r ? void 0 : r[e]) || t;
                            return (0, o.useMemo)(() => ({
                                [`__scope${e}`]: { ...r,
                                    [e]: n
                                }
                            }), [r, n])
                        }
                    };
                return n.scopeName = e, [function(t, n) {
                    let u = (0, o.createContext)(n),
                        l = r.length;

                    function c(t) {
                        let {
                            scope: r,
                            children: n,
                            ...c
                        } = t, i = (null == r ? void 0 : r[e][l]) || u, a = (0, o.useMemo)(() => c, Object.values(c));
                        return (0, o.createElement)(i.Provider, {
                            value: a
                        }, n)
                    }
                    return r = [...r, n], c.displayName = t + "Provider", [c, function(r, c) {
                        let i = (null == c ? void 0 : c[e][l]) || u,
                            a = (0, o.useContext)(i);
                        if (a) return a;
                        if (void 0 !== n) return n;
                        throw Error(`\`${r}\` must be used within \`${t}\``)
                    }]
                }, function(...e) {
                    let t = e[0];
                    if (1 === e.length) return t;
                    let r = () => {
                        let r = e.map(e => ({
                            useScope: e(),
                            scopeName: e.scopeName
                        }));
                        return function(e) {
                            let n = r.reduce((t, {
                                useScope: r,
                                scopeName: n
                            }) => {
                                let o = r(e)[`__scope${n}`];
                                return { ...t,
                                    ...o
                                }
                            }, {});
                            return (0, o.useMemo)(() => ({
                                [`__scope${t.scopeName}`]: n
                            }), [n])
                        }
                    };
                    return r.scopeName = t.scopeName, r
                }(n, ...t)]
            }

            function c(...e) {
                return (0, o.useCallback)(function(...e) {
                    return t => e.forEach(e => {
                        "function" == typeof e ? e(t) : null != e && (e.current = t)
                    })
                }(...e), e)
            }
            var i = r(4222),
                a = r(92936);
            r(73935);
            let f = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                let r = (0, o.forwardRef)((e, r) => {
                    let {
                        asChild: u,
                        ...l
                    } = e, c = u ? i.g7 : t;
                    return (0, o.useEffect)(() => {
                        window[Symbol.for("radix-ui")] = !0
                    }, []), (0, o.createElement)(c, (0, n.Z)({}, l, {
                        ref: r
                    }))
                });
                return r.displayName = `Primitive.${t}`, { ...e,
                    [t]: r
                }
            }, {});

            function s(e) {
                let t = (0, o.useRef)(e);
                return (0, o.useEffect)(() => {
                    t.current = e
                }), (0, o.useMemo)(() => (...e) => {
                    var r;
                    return null === (r = t.current) || void 0 === r ? void 0 : r.call(t, ...e)
                }, [])
            }
            let d = (0, o.createContext)(void 0),
                p = "rovingFocusGroup.onEntryFocus",
                m = {
                    bubbles: !1,
                    cancelable: !0
                },
                v = "RovingFocusGroup",
                [b, g, w] = function(e) {
                    let t = e + "CollectionProvider",
                        [r, n] = l(t),
                        [u, a] = r(t, {
                            collectionRef: {
                                current: null
                            },
                            itemMap: new Map
                        }),
                        f = e + "CollectionSlot",
                        s = o.forwardRef((e, t) => {
                            let {
                                scope: r,
                                children: n
                            } = e, u = c(t, a(f, r).collectionRef);
                            return o.createElement(i.g7, {
                                ref: u
                            }, n)
                        }),
                        d = e + "CollectionItemSlot",
                        p = "data-radix-collection-item";
                    return [{
                        Provider: e => {
                            let {
                                scope: t,
                                children: r
                            } = e, n = o.useRef(null), l = o.useRef(new Map).current;
                            return o.createElement(u, {
                                scope: t,
                                itemMap: l,
                                collectionRef: n
                            }, r)
                        },
                        Slot: s,
                        ItemSlot: o.forwardRef((e, t) => {
                            let {
                                scope: r,
                                children: n,
                                ...u
                            } = e, l = o.useRef(null), f = c(t, l), s = a(d, r);
                            return o.useEffect(() => (s.itemMap.set(l, {
                                ref: l,
                                ...u
                            }), () => void s.itemMap.delete(l))), o.createElement(i.g7, {
                                [p]: "",
                                ref: f
                            }, n)
                        })
                    }, function(t) {
                        let r = a(e + "CollectionConsumer", t);
                        return o.useCallback(() => {
                            let e = r.collectionRef.current;
                            if (!e) return [];
                            let t = Array.from(e.querySelectorAll(`[${p}]`));
                            return Array.from(r.itemMap.values()).sort((e, r) => t.indexOf(e.ref.current) - t.indexOf(r.ref.current))
                        }, [r.collectionRef, r.itemMap])
                    }, n]
                }(v),
                [h, E] = l(v, [w]),
                [R, C] = h(v),
                S = (0, o.forwardRef)((e, t) => (0, o.createElement)(b.Provider, {
                    scope: e.__scopeRovingFocusGroup
                }, (0, o.createElement)(b.Slot, {
                    scope: e.__scopeRovingFocusGroup
                }, (0, o.createElement)(I, (0, n.Z)({}, e, {
                    ref: t
                }))))),
                I = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeRovingFocusGroup: r,
                        orientation: l,
                        loop: i = !1,
                        dir: a,
                        currentTabStopId: v,
                        defaultCurrentTabStopId: b,
                        onCurrentTabStopIdChange: w,
                        onEntryFocus: h,
                        ...E
                    } = e, C = (0, o.useRef)(null), S = c(t, C), I = function(e) {
                        let t = (0, o.useContext)(d);
                        return e || t || "ltr"
                    }(a), [F = null, y] = function({
                        prop: e,
                        defaultProp: t,
                        onChange: r = () => {}
                    }) {
                        let [n, u] = function({
                            defaultProp: e,
                            onChange: t
                        }) {
                            let r = (0, o.useState)(e),
                                [n] = r,
                                u = (0, o.useRef)(n),
                                l = s(t);
                            return (0, o.useEffect)(() => {
                                u.current !== n && (l(n), u.current = n)
                            }, [n, u, l]), r
                        }({
                            defaultProp: t,
                            onChange: r
                        }), l = void 0 !== e, c = l ? e : n, i = s(r);
                        return [c, (0, o.useCallback)(t => {
                            if (l) {
                                let r = "function" == typeof t ? t(e) : t;
                                r !== e && i(r)
                            } else u(t)
                        }, [l, e, u, i])]
                    }({
                        prop: v,
                        defaultProp: b,
                        onChange: w
                    }), [_, A] = (0, o.useState)(!1), x = s(h), P = g(r), k = (0, o.useRef)(!1), [T, D] = (0, o.useState)(0);
                    return (0, o.useEffect)(() => {
                        let e = C.current;
                        if (e) return e.addEventListener(p, x), () => e.removeEventListener(p, x)
                    }, [x]), (0, o.createElement)(R, {
                        scope: r,
                        orientation: l,
                        dir: I,
                        loop: i,
                        currentTabStopId: F,
                        onItemFocus: (0, o.useCallback)(e => y(e), [y]),
                        onItemShiftTab: (0, o.useCallback)(() => A(!0), []),
                        onFocusableItemAdd: (0, o.useCallback)(() => D(e => e + 1), []),
                        onFocusableItemRemove: (0, o.useCallback)(() => D(e => e - 1), [])
                    }, (0, o.createElement)(f.div, (0, n.Z)({
                        tabIndex: _ || 0 === T ? -1 : 0,
                        "data-orientation": l
                    }, E, {
                        ref: S,
                        style: {
                            outline: "none",
                            ...e.style
                        },
                        onMouseDown: u(e.onMouseDown, () => {
                            k.current = !0
                        }),
                        onFocus: u(e.onFocus, e => {
                            let t = !k.current;
                            if (e.target === e.currentTarget && t && !_) {
                                let t = new CustomEvent(p, m);
                                if (e.currentTarget.dispatchEvent(t), !t.defaultPrevented) {
                                    let e = P().filter(e => e.focusable);
                                    M([e.find(e => e.active), e.find(e => e.id === F), ...e].filter(Boolean).map(e => e.ref.current))
                                }
                            }
                            k.current = !1
                        }),
                        onBlur: u(e.onBlur, () => A(!1))
                    })))
                }),
                F = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeRovingFocusGroup: r,
                        focusable: l = !0,
                        active: c = !1,
                        tabStopId: i,
                        ...s
                    } = e, d = (0, a.M)(), p = i || d, m = C("RovingFocusGroupItem", r), v = m.currentTabStopId === p, w = g(r), {
                        onFocusableItemAdd: h,
                        onFocusableItemRemove: E
                    } = m;
                    return (0, o.useEffect)(() => {
                        if (l) return h(), () => E()
                    }, [l, h, E]), (0, o.createElement)(b.ItemSlot, {
                        scope: r,
                        id: p,
                        focusable: l,
                        active: c
                    }, (0, o.createElement)(f.span, (0, n.Z)({
                        tabIndex: v ? 0 : -1,
                        "data-orientation": m.orientation
                    }, s, {
                        ref: t,
                        onMouseDown: u(e.onMouseDown, e => {
                            l ? m.onItemFocus(p) : e.preventDefault()
                        }),
                        onFocus: u(e.onFocus, () => m.onItemFocus(p)),
                        onKeyDown: u(e.onKeyDown, e => {
                            if ("Tab" === e.key && e.shiftKey) {
                                m.onItemShiftTab();
                                return
                            }
                            if (e.target !== e.currentTarget) return;
                            let t = function(e, t, r) {
                                var n;
                                let o = (n = e.key, "rtl" !== r ? n : "ArrowLeft" === n ? "ArrowRight" : "ArrowRight" === n ? "ArrowLeft" : n);
                                if (!("vertical" === t && ["ArrowLeft", "ArrowRight"].includes(o)) && !("horizontal" === t && ["ArrowUp", "ArrowDown"].includes(o))) return y[o]
                            }(e, m.orientation, m.dir);
                            if (void 0 !== t) {
                                e.preventDefault();
                                let o = w().filter(e => e.focusable).map(e => e.ref.current);
                                if ("last" === t) o.reverse();
                                else if ("prev" === t || "next" === t) {
                                    var r, n;
                                    "prev" === t && o.reverse();
                                    let u = o.indexOf(e.currentTarget);
                                    o = m.loop ? (r = o, n = u + 1, r.map((e, t) => r[(n + t) % r.length])) : o.slice(u + 1)
                                }
                                setTimeout(() => M(o))
                            }
                        })
                    })))
                }),
                y = {
                    ArrowLeft: "prev",
                    ArrowUp: "prev",
                    ArrowRight: "next",
                    ArrowDown: "next",
                    PageUp: "first",
                    Home: "first",
                    PageDown: "last",
                    End: "last"
                };

            function M(e) {
                let t = document.activeElement;
                for (let r of e)
                    if (r === t || (r.focus(), document.activeElement !== t)) return
            }
            let _ = S,
                A = F
        }
    }
]);