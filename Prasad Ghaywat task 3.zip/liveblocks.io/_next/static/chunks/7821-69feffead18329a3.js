"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7821], {
        7821: function(e, t, n) {
            n.d(t, {
                ee: function() {
                    return eP
                },
                Eh: function() {
                    return e$
                },
                oC: function() {
                    return eA
                },
                VY: function() {
                    return ek
                },
                ZA: function() {
                    return eS
                },
                ck: function() {
                    return eD
                },
                wU: function() {
                    return eI
                },
                __: function() {
                    return eO
                },
                h_: function() {
                    return eR
                },
                Ee: function() {
                    return eT
                },
                Rk: function() {
                    return eZ
                },
                fC: function() {
                    return ex
                },
                Z0: function() {
                    return eF
                },
                Tr: function() {
                    return eL
                },
                tu: function() {
                    return eK
                },
                fF: function() {
                    return eN
                },
                Wf: function() {
                    return Z
                }
            });
            var r = n(87462),
                o = n(67294);

            function l(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (null == e || e(r), !1 === n || !r.defaultPrevented) return null == t ? void 0 : t(r)
                }
            }

            function u(e, t = []) {
                let n = [],
                    r = () => {
                        let t = n.map(e => (0, o.createContext)(e));
                        return function(n) {
                            let r = (null == n ? void 0 : n[e]) || t;
                            return (0, o.useMemo)(() => ({
                                [`__scope${e}`]: { ...n,
                                    [e]: r
                                }
                            }), [n, r])
                        }
                    };
                return r.scopeName = e, [function(t, r) {
                    let l = (0, o.createContext)(r),
                        u = n.length;

                    function i(t) {
                        let {
                            scope: n,
                            children: r,
                            ...i
                        } = t, a = (null == n ? void 0 : n[e][u]) || l, c = (0, o.useMemo)(() => i, Object.values(i));
                        return (0, o.createElement)(a.Provider, {
                            value: c
                        }, r)
                    }
                    return n = [...n, r], i.displayName = t + "Provider", [i, function(n, i) {
                        let a = (null == i ? void 0 : i[e][u]) || l,
                            c = (0, o.useContext)(a);
                        if (c) return c;
                        if (void 0 !== r) return r;
                        throw Error(`\`${n}\` must be used within \`${t}\``)
                    }]
                }, function(...e) {
                    let t = e[0];
                    if (1 === e.length) return t;
                    let n = () => {
                        let n = e.map(e => ({
                            useScope: e(),
                            scopeName: e.scopeName
                        }));
                        return function(e) {
                            let r = n.reduce((t, {
                                useScope: n,
                                scopeName: r
                            }) => {
                                let o = n(e)[`__scope${r}`];
                                return { ...t,
                                    ...o
                                }
                            }, {});
                            return (0, o.useMemo)(() => ({
                                [`__scope${t.scopeName}`]: r
                            }), [r])
                        }
                    };
                    return n.scopeName = t.scopeName, n
                }(r, ...t)]
            }

            function i(...e) {
                return t => e.forEach(e => {
                    "function" == typeof e ? e(t) : null != e && (e.current = t)
                })
            }

            function a(...e) {
                return (0, o.useCallback)(i(...e), e)
            }
            var c = n(4222);
            let d = (0, o.createContext)(void 0);
            var s = n(40666),
                f = n(27552),
                p = n(72371),
                m = n(92936),
                v = n(93536),
                h = n(18304),
                g = n(438),
                w = n(73935);
            let E = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                let n = (0, o.forwardRef)((e, n) => {
                    let {
                        asChild: l,
                        ...u
                    } = e, i = l ? c.g7 : t;
                    return (0, o.useEffect)(() => {
                        window[Symbol.for("radix-ui")] = !0
                    }, []), (0, o.createElement)(i, (0, r.Z)({}, u, {
                        ref: n
                    }))
                });
                return n.displayName = `Primitive.${t}`, { ...e,
                    [t]: n
                }
            }, {});
            var y = n(74919);

            function _(e) {
                let t = (0, o.useRef)(e);
                return (0, o.useEffect)(() => {
                    t.current = e
                }), (0, o.useMemo)(() => (...e) => {
                    var n;
                    return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                }, [])
            }
            var C = n(23541),
                b = n(42026);
            let M = ["Enter", " "],
                x = ["ArrowUp", "PageDown", "End"],
                P = ["ArrowDown", "PageUp", "Home", ...x],
                R = {
                    ltr: [...M, "ArrowRight"],
                    rtl: [...M, "ArrowLeft"]
                },
                k = {
                    ltr: ["ArrowLeft"],
                    rtl: ["ArrowRight"]
                },
                S = "Menu",
                [O, D, A] = function(e) {
                    let t = e + "CollectionProvider",
                        [n, r] = u(t),
                        [l, i] = n(t, {
                            collectionRef: {
                                current: null
                            },
                            itemMap: new Map
                        }),
                        d = e + "CollectionSlot",
                        s = o.forwardRef((e, t) => {
                            let {
                                scope: n,
                                children: r
                            } = e, l = a(t, i(d, n).collectionRef);
                            return o.createElement(c.g7, {
                                ref: l
                            }, r)
                        }),
                        f = e + "CollectionItemSlot",
                        p = "data-radix-collection-item";
                    return [{
                        Provider: e => {
                            let {
                                scope: t,
                                children: n
                            } = e, r = o.useRef(null), u = o.useRef(new Map).current;
                            return o.createElement(l, {
                                scope: t,
                                itemMap: u,
                                collectionRef: r
                            }, n)
                        },
                        Slot: s,
                        ItemSlot: o.forwardRef((e, t) => {
                            let {
                                scope: n,
                                children: r,
                                ...l
                            } = e, u = o.useRef(null), d = a(t, u), s = i(f, n);
                            return o.useEffect(() => (s.itemMap.set(u, {
                                ref: u,
                                ...l
                            }), () => void s.itemMap.delete(u))), o.createElement(c.g7, {
                                [p]: "",
                                ref: d
                            }, r)
                        })
                    }, function(t) {
                        let n = i(e + "CollectionConsumer", t);
                        return o.useCallback(() => {
                            let e = n.collectionRef.current;
                            if (!e) return [];
                            let t = Array.from(e.querySelectorAll(`[${p}]`));
                            return Array.from(n.itemMap.values()).sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current))
                        }, [n.collectionRef, n.itemMap])
                    }, r]
                }(S),
                [T, Z] = u(S, [A, v.D7, y.Pc]),
                I = (0, v.D7)(),
                F = (0, y.Pc)(),
                [$, L] = T(S),
                [N, K] = T(S),
                z = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        ...l
                    } = e, u = I(n);
                    return (0, o.createElement)(v.ee, (0, r.Z)({}, u, l, {
                        ref: t
                    }))
                }),
                V = "MenuPortal",
                [Y, B] = T(V, {
                    forceMount: void 0
                }),
                H = "MenuContent",
                [W, X] = T(H),
                G = (0, o.forwardRef)((e, t) => {
                    let n = B(H, e.__scopeMenu),
                        {
                            forceMount: l = n.forceMount,
                            ...u
                        } = e,
                        i = L(H, e.__scopeMenu),
                        a = K(H, e.__scopeMenu);
                    return (0, o.createElement)(O.Provider, {
                        scope: e.__scopeMenu
                    }, (0, o.createElement)(g.z, {
                        present: l || i.open
                    }, (0, o.createElement)(O.Slot, {
                        scope: e.__scopeMenu
                    }, a.modal ? (0, o.createElement)(U, (0, r.Z)({}, u, {
                        ref: t
                    })) : (0, o.createElement)(j, (0, r.Z)({}, u, {
                        ref: t
                    })))))
                }),
                U = (0, o.forwardRef)((e, t) => {
                    let n = L(H, e.__scopeMenu),
                        u = (0, o.useRef)(null),
                        i = a(t, u);
                    return (0, o.useEffect)(() => {
                        let e = u.current;
                        if (e) return (0, C.Ry)(e)
                    }, []), (0, o.createElement)(q, (0, r.Z)({}, e, {
                        ref: i,
                        trapFocus: n.open,
                        disableOutsidePointerEvents: n.open,
                        disableOutsideScroll: !0,
                        onFocusOutside: l(e.onFocusOutside, e => e.preventDefault(), {
                            checkForDefaultPrevented: !1
                        }),
                        onDismiss: () => n.onOpenChange(!1)
                    }))
                }),
                j = (0, o.forwardRef)((e, t) => {
                    let n = L(H, e.__scopeMenu);
                    return (0, o.createElement)(q, (0, r.Z)({}, e, {
                        ref: t,
                        trapFocus: !1,
                        disableOutsidePointerEvents: !1,
                        disableOutsideScroll: !1,
                        onDismiss: () => n.onOpenChange(!1)
                    }))
                }),
                q = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        loop: u = !1,
                        trapFocus: i,
                        onOpenAutoFocus: d,
                        onCloseAutoFocus: m,
                        disableOutsidePointerEvents: h,
                        onEntryFocus: g,
                        onEscapeKeyDown: w,
                        onPointerDownOutside: E,
                        onFocusOutside: _,
                        onInteractOutside: C,
                        onDismiss: M,
                        disableOutsideScroll: R,
                        ...k
                    } = e, S = L(H, n), O = K(H, n), A = I(n), T = F(n), Z = D(n), [$, N] = (0, o.useState)(null), z = (0, o.useRef)(null), V = a(t, z, S.onContentChange), Y = (0, o.useRef)(0), B = (0, o.useRef)(""), X = (0, o.useRef)(0), G = (0, o.useRef)(null), U = (0, o.useRef)("right"), j = (0, o.useRef)(0), q = R ? b.Z : o.Fragment, J = R ? {
                        as: c.g7,
                        allowPinchZoom: !0
                    } : void 0, Q = e => {
                        var t, n;
                        let r = B.current + e,
                            o = Z().filter(e => !e.disabled),
                            l = document.activeElement,
                            u = null === (t = o.find(e => e.ref.current === l)) || void 0 === t ? void 0 : t.textValue,
                            i = function(e, t, n) {
                                var r;
                                let o = t.length > 1 && Array.from(t).every(e => e === t[0]) ? t[0] : t,
                                    l = (r = Math.max(n ? e.indexOf(n) : -1, 0), e.map((t, n) => e[(r + n) % e.length]));
                                1 === o.length && (l = l.filter(e => e !== n));
                                let u = l.find(e => e.toLowerCase().startsWith(o.toLowerCase()));
                                return u !== n ? u : void 0
                            }(o.map(e => e.textValue), r, u),
                            a = null === (n = o.find(e => e.textValue === i)) || void 0 === n ? void 0 : n.ref.current;
                        ! function e(t) {
                            B.current = t, window.clearTimeout(Y.current), "" !== t && (Y.current = window.setTimeout(() => e(""), 1e3))
                        }(r), a && setTimeout(() => a.focus())
                    };
                    (0, o.useEffect)(() => () => window.clearTimeout(Y.current), []), (0, f.EW)();
                    let ee = (0, o.useCallback)(e => {
                        var t, n, r;
                        return U.current === (null === (t = G.current) || void 0 === t ? void 0 : t.side) && !!(r = null === (n = G.current) || void 0 === n ? void 0 : n.area) && function(e, t) {
                            let {
                                x: n,
                                y: r
                            } = e, o = !1;
                            for (let e = 0, l = t.length - 1; e < t.length; l = e++) {
                                let u = t[e].x,
                                    i = t[e].y,
                                    a = t[l].x,
                                    c = t[l].y;
                                i > r != c > r && n < (a - u) * (r - i) / (c - i) + u && (o = !o)
                            }
                            return o
                        }({
                            x: e.clientX,
                            y: e.clientY
                        }, r)
                    }, []);
                    return (0, o.createElement)(W, {
                        scope: n,
                        searchRef: B,
                        onItemEnter: (0, o.useCallback)(e => {
                            ee(e) && e.preventDefault()
                        }, [ee]),
                        onItemLeave: (0, o.useCallback)(e => {
                            var t;
                            ee(e) || (null === (t = z.current) || void 0 === t || t.focus(), N(null))
                        }, [ee]),
                        onTriggerLeave: (0, o.useCallback)(e => {
                            ee(e) && e.preventDefault()
                        }, [ee]),
                        pointerGraceTimerRef: X,
                        onPointerGraceIntentChange: (0, o.useCallback)(e => {
                            G.current = e
                        }, [])
                    }, (0, o.createElement)(q, J, (0, o.createElement)(p.M, {
                        asChild: !0,
                        trapped: i,
                        onMountAutoFocus: l(d, e => {
                            var t;
                            e.preventDefault(), null === (t = z.current) || void 0 === t || t.focus()
                        }),
                        onUnmountAutoFocus: m
                    }, (0, o.createElement)(s.XB, {
                        asChild: !0,
                        disableOutsidePointerEvents: h,
                        onEscapeKeyDown: w,
                        onPointerDownOutside: E,
                        onFocusOutside: _,
                        onInteractOutside: C,
                        onDismiss: M
                    }, (0, o.createElement)(y.fC, (0, r.Z)({
                        asChild: !0
                    }, T, {
                        dir: O.dir,
                        orientation: "vertical",
                        loop: u,
                        currentTabStopId: $,
                        onCurrentTabStopIdChange: N,
                        onEntryFocus: l(g, e => {
                            O.isUsingKeyboardRef.current || e.preventDefault()
                        })
                    }), (0, o.createElement)(v.VY, (0, r.Z)({
                        role: "menu",
                        "aria-orientation": "vertical",
                        "data-state": e_(S.open),
                        "data-radix-menu-content": "",
                        dir: O.dir
                    }, A, k, {
                        ref: V,
                        style: {
                            outline: "none",
                            ...k.style
                        },
                        onKeyDown: l(k.onKeyDown, e => {
                            let t = e.target.closest("[data-radix-menu-content]") === e.currentTarget,
                                n = e.ctrlKey || e.altKey || e.metaKey,
                                r = 1 === e.key.length;
                            t && ("Tab" === e.key && e.preventDefault(), !n && r && Q(e.key));
                            let o = z.current;
                            if (e.target !== o || !P.includes(e.key)) return;
                            e.preventDefault();
                            let l = Z().filter(e => !e.disabled).map(e => e.ref.current);
                            x.includes(e.key) && l.reverse(),
                                function(e) {
                                    let t = document.activeElement;
                                    for (let n of e)
                                        if (n === t || (n.focus(), document.activeElement !== t)) return
                                }(l)
                        }),
                        onBlur: l(e.onBlur, e => {
                            e.currentTarget.contains(e.target) || (window.clearTimeout(Y.current), B.current = "")
                        }),
                        onPointerMove: l(e.onPointerMove, eM(e => {
                            let t = e.target,
                                n = j.current !== e.clientX;
                            if (e.currentTarget.contains(t) && n) {
                                let t = e.clientX > j.current ? "right" : "left";
                                U.current = t, j.current = e.clientX
                            }
                        }))
                    })))))))
                }),
                J = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        ...l
                    } = e;
                    return (0, o.createElement)(E.div, (0, r.Z)({
                        role: "group"
                    }, l, {
                        ref: t
                    }))
                }),
                Q = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        ...l
                    } = e;
                    return (0, o.createElement)(E.div, (0, r.Z)({}, l, {
                        ref: t
                    }))
                }),
                ee = "MenuItem",
                et = "menu.itemSelect",
                en = (0, o.forwardRef)((e, t) => {
                    let {
                        disabled: n = !1,
                        onSelect: u,
                        ...i
                    } = e, c = (0, o.useRef)(null), d = K(ee, e.__scopeMenu), s = X(ee, e.__scopeMenu), f = a(t, c), p = (0, o.useRef)(!1);
                    return (0, o.createElement)(er, (0, r.Z)({}, i, {
                        ref: f,
                        disabled: n,
                        onClick: l(e.onClick, () => {
                            let e = c.current;
                            if (!n && e) {
                                let t = new CustomEvent(et, {
                                    bubbles: !0,
                                    cancelable: !0
                                });
                                e.addEventListener(et, e => null == u ? void 0 : u(e), {
                                    once: !0
                                }), e && (0, w.flushSync)(() => e.dispatchEvent(t)), t.defaultPrevented ? p.current = !1 : d.onClose()
                            }
                        }),
                        onPointerDown: t => {
                            var n;
                            null === (n = e.onPointerDown) || void 0 === n || n.call(e, t), p.current = !0
                        },
                        onPointerUp: l(e.onPointerUp, e => {
                            var t;
                            p.current || null === (t = e.currentTarget) || void 0 === t || t.click()
                        }),
                        onKeyDown: l(e.onKeyDown, e => {
                            let t = "" !== s.searchRef.current;
                            !n && (!t || " " !== e.key) && M.includes(e.key) && (e.currentTarget.click(), e.preventDefault())
                        })
                    }))
                }),
                er = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        disabled: u = !1,
                        textValue: i,
                        ...c
                    } = e, d = X(ee, n), s = F(n), f = (0, o.useRef)(null), p = a(t, f), [m, v] = (0, o.useState)(!1), [h, g] = (0, o.useState)("");
                    return (0, o.useEffect)(() => {
                        let e = f.current;
                        if (e) {
                            var t;
                            g((null !== (t = e.textContent) && void 0 !== t ? t : "").trim())
                        }
                    }, [c.children]), (0, o.createElement)(O.ItemSlot, {
                        scope: n,
                        disabled: u,
                        textValue: null != i ? i : h
                    }, (0, o.createElement)(y.ck, (0, r.Z)({
                        asChild: !0
                    }, s, {
                        focusable: !u
                    }), (0, o.createElement)(E.div, (0, r.Z)({
                        role: "menuitem",
                        "data-highlighted": m ? "" : void 0,
                        "aria-disabled": u || void 0,
                        "data-disabled": u ? "" : void 0
                    }, c, {
                        ref: p,
                        onPointerMove: l(e.onPointerMove, eM(e => {
                            u ? d.onItemLeave(e) : (d.onItemEnter(e), e.defaultPrevented || e.currentTarget.focus())
                        })),
                        onPointerLeave: l(e.onPointerLeave, eM(e => d.onItemLeave(e))),
                        onFocus: l(e.onFocus, () => v(!0)),
                        onBlur: l(e.onBlur, () => v(!1))
                    }))))
                }),
                eo = (0, o.forwardRef)((e, t) => {
                    let {
                        checked: n = !1,
                        onCheckedChange: u,
                        ...i
                    } = e;
                    return (0, o.createElement)(ed, {
                        scope: e.__scopeMenu,
                        checked: n
                    }, (0, o.createElement)(en, (0, r.Z)({
                        role: "menuitemcheckbox",
                        "aria-checked": eC(n) ? "mixed" : n
                    }, i, {
                        ref: t,
                        "data-state": eb(n),
                        onSelect: l(i.onSelect, () => null == u ? void 0 : u(!!eC(n) || !n), {
                            checkForDefaultPrevented: !1
                        })
                    })))
                }),
                [el, eu] = T("MenuRadioGroup", {
                    value: void 0,
                    onValueChange: () => {}
                }),
                ei = (0, o.forwardRef)((e, t) => {
                    let {
                        value: n,
                        onValueChange: l,
                        ...u
                    } = e, i = _(l);
                    return (0, o.createElement)(el, {
                        scope: e.__scopeMenu,
                        value: n,
                        onValueChange: i
                    }, (0, o.createElement)(J, (0, r.Z)({}, u, {
                        ref: t
                    })))
                }),
                ea = (0, o.forwardRef)((e, t) => {
                    let {
                        value: n,
                        ...u
                    } = e, i = eu("MenuRadioItem", e.__scopeMenu), a = n === i.value;
                    return (0, o.createElement)(ed, {
                        scope: e.__scopeMenu,
                        checked: a
                    }, (0, o.createElement)(en, (0, r.Z)({
                        role: "menuitemradio",
                        "aria-checked": a
                    }, u, {
                        ref: t,
                        "data-state": eb(a),
                        onSelect: l(u.onSelect, () => {
                            var e;
                            return null === (e = i.onValueChange) || void 0 === e ? void 0 : e.call(i, n)
                        }, {
                            checkForDefaultPrevented: !1
                        })
                    })))
                }),
                ec = "MenuItemIndicator",
                [ed, es] = T(ec, {
                    checked: !1
                }),
                ef = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        forceMount: l,
                        ...u
                    } = e, i = es(ec, n);
                    return (0, o.createElement)(g.z, {
                        present: l || eC(i.checked) || !0 === i.checked
                    }, (0, o.createElement)(E.span, (0, r.Z)({}, u, {
                        ref: t,
                        "data-state": eb(i.checked)
                    })))
                }),
                ep = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        ...l
                    } = e;
                    return (0, o.createElement)(E.div, (0, r.Z)({
                        role: "separator",
                        "aria-orientation": "horizontal"
                    }, l, {
                        ref: t
                    }))
                }),
                em = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeMenu: n,
                        ...l
                    } = e, u = I(n);
                    return (0, o.createElement)(v.Eh, (0, r.Z)({}, u, l, {
                        ref: t
                    }))
                }),
                ev = "MenuSub",
                [eh, eg] = T(ev),
                ew = "MenuSubTrigger",
                eE = (0, o.forwardRef)((e, t) => {
                    let n = L(ew, e.__scopeMenu),
                        u = K(ew, e.__scopeMenu),
                        a = eg(ew, e.__scopeMenu),
                        c = X(ew, e.__scopeMenu),
                        d = (0, o.useRef)(null),
                        {
                            pointerGraceTimerRef: s,
                            onPointerGraceIntentChange: f
                        } = c,
                        p = {
                            __scopeMenu: e.__scopeMenu
                        },
                        m = (0, o.useCallback)(() => {
                            d.current && window.clearTimeout(d.current), d.current = null
                        }, []);
                    return (0, o.useEffect)(() => m, [m]), (0, o.useEffect)(() => {
                        let e = s.current;
                        return () => {
                            window.clearTimeout(e), f(null)
                        }
                    }, [s, f]), (0, o.createElement)(z, (0, r.Z)({
                        asChild: !0
                    }, p), (0, o.createElement)(er, (0, r.Z)({
                        id: a.triggerId,
                        "aria-haspopup": "menu",
                        "aria-expanded": n.open,
                        "aria-controls": a.contentId,
                        "data-state": e_(n.open)
                    }, e, {
                        ref: i(t, a.onTriggerChange),
                        onClick: t => {
                            var r;
                            null === (r = e.onClick) || void 0 === r || r.call(e, t), e.disabled || t.defaultPrevented || (t.currentTarget.focus(), n.open || n.onOpenChange(!0))
                        },
                        onPointerMove: l(e.onPointerMove, eM(t => {
                            c.onItemEnter(t), t.defaultPrevented || e.disabled || n.open || d.current || (c.onPointerGraceIntentChange(null), d.current = window.setTimeout(() => {
                                n.onOpenChange(!0), m()
                            }, 100))
                        })),
                        onPointerLeave: l(e.onPointerLeave, eM(e => {
                            var t, r;
                            m();
                            let o = null === (t = n.content) || void 0 === t ? void 0 : t.getBoundingClientRect();
                            if (o) {
                                let t = null === (r = n.content) || void 0 === r ? void 0 : r.dataset.side,
                                    l = "right" === t,
                                    u = o[l ? "left" : "right"],
                                    i = o[l ? "right" : "left"];
                                c.onPointerGraceIntentChange({
                                    area: [{
                                        x: e.clientX + (l ? -5 : 5),
                                        y: e.clientY
                                    }, {
                                        x: u,
                                        y: o.top
                                    }, {
                                        x: i,
                                        y: o.top
                                    }, {
                                        x: i,
                                        y: o.bottom
                                    }, {
                                        x: u,
                                        y: o.bottom
                                    }],
                                    side: t
                                }), window.clearTimeout(s.current), s.current = window.setTimeout(() => c.onPointerGraceIntentChange(null), 300)
                            } else {
                                if (c.onTriggerLeave(e), e.defaultPrevented) return;
                                c.onPointerGraceIntentChange(null)
                            }
                        })),
                        onKeyDown: l(e.onKeyDown, t => {
                            let r = "" !== c.searchRef.current;
                            if (!e.disabled && (!r || " " !== t.key) && R[u.dir].includes(t.key)) {
                                var o;
                                n.onOpenChange(!0), null === (o = n.content) || void 0 === o || o.focus(), t.preventDefault()
                            }
                        })
                    })))
                }),
                ey = (0, o.forwardRef)((e, t) => {
                    let n = B(H, e.__scopeMenu),
                        {
                            forceMount: u = n.forceMount,
                            ...i
                        } = e,
                        c = L(H, e.__scopeMenu),
                        d = K(H, e.__scopeMenu),
                        s = eg("MenuSubContent", e.__scopeMenu),
                        f = (0, o.useRef)(null),
                        p = a(t, f);
                    return (0, o.createElement)(O.Provider, {
                        scope: e.__scopeMenu
                    }, (0, o.createElement)(g.z, {
                        present: u || c.open
                    }, (0, o.createElement)(O.Slot, {
                        scope: e.__scopeMenu
                    }, (0, o.createElement)(q, (0, r.Z)({
                        id: s.contentId,
                        "aria-labelledby": s.triggerId
                    }, i, {
                        ref: p,
                        align: "start",
                        side: "rtl" === d.dir ? "left" : "right",
                        disableOutsidePointerEvents: !1,
                        disableOutsideScroll: !1,
                        trapFocus: !1,
                        onOpenAutoFocus: e => {
                            var t;
                            d.isUsingKeyboardRef.current && (null === (t = f.current) || void 0 === t || t.focus()), e.preventDefault()
                        },
                        onCloseAutoFocus: e => e.preventDefault(),
                        onFocusOutside: l(e.onFocusOutside, e => {
                            e.target !== s.trigger && c.onOpenChange(!1)
                        }),
                        onEscapeKeyDown: l(e.onEscapeKeyDown, e => {
                            d.onClose(), e.preventDefault()
                        }),
                        onKeyDown: l(e.onKeyDown, e => {
                            let t = e.currentTarget.contains(e.target),
                                n = k[d.dir].includes(e.key);
                            if (t && n) {
                                var r;
                                c.onOpenChange(!1), null === (r = s.trigger) || void 0 === r || r.focus(), e.preventDefault()
                            }
                        })
                    })))))
                });

            function e_(e) {
                return e ? "open" : "closed"
            }

            function eC(e) {
                return "indeterminate" === e
            }

            function eb(e) {
                return eC(e) ? "indeterminate" : e ? "checked" : "unchecked"
            }

            function eM(e) {
                return t => "mouse" === t.pointerType ? e(t) : void 0
            }
            let ex = e => {
                    let {
                        __scopeMenu: t,
                        open: n = !1,
                        children: r,
                        dir: l,
                        onOpenChange: u,
                        modal: i = !0
                    } = e, a = I(t), [c, s] = (0, o.useState)(null), f = (0, o.useRef)(!1), p = _(u), m = function(e) {
                        let t = (0, o.useContext)(d);
                        return e || t || "ltr"
                    }(l);
                    return (0, o.useEffect)(() => {
                        let e = () => {
                                f.current = !0, document.addEventListener("pointerdown", t, {
                                    capture: !0,
                                    once: !0
                                }), document.addEventListener("pointermove", t, {
                                    capture: !0,
                                    once: !0
                                })
                            },
                            t = () => f.current = !1;
                        return document.addEventListener("keydown", e, {
                            capture: !0
                        }), () => {
                            document.removeEventListener("keydown", e, {
                                capture: !0
                            }), document.removeEventListener("pointerdown", t, {
                                capture: !0
                            }), document.removeEventListener("pointermove", t, {
                                capture: !0
                            })
                        }
                    }, []), (0, o.createElement)(v.fC, a, (0, o.createElement)($, {
                        scope: t,
                        open: n,
                        onOpenChange: p,
                        content: c,
                        onContentChange: s
                    }, (0, o.createElement)(N, {
                        scope: t,
                        onClose: (0, o.useCallback)(() => p(!1), [p]),
                        isUsingKeyboardRef: f,
                        dir: m,
                        modal: i
                    }, r)))
                },
                eP = z,
                eR = e => {
                    let {
                        __scopeMenu: t,
                        forceMount: n,
                        children: r,
                        container: l
                    } = e, u = L(V, t);
                    return (0, o.createElement)(Y, {
                        scope: t,
                        forceMount: n
                    }, (0, o.createElement)(g.z, {
                        present: n || u.open
                    }, (0, o.createElement)(h.h, {
                        asChild: !0,
                        container: l
                    }, r)))
                },
                ek = G,
                eS = J,
                eO = Q,
                eD = en,
                eA = eo,
                eT = ei,
                eZ = ea,
                eI = ef,
                eF = ep,
                e$ = em,
                eL = e => {
                    let {
                        __scopeMenu: t,
                        children: n,
                        open: r = !1,
                        onOpenChange: l
                    } = e, u = L(ev, t), i = I(t), [a, c] = (0, o.useState)(null), [d, s] = (0, o.useState)(null), f = _(l);
                    return (0, o.useEffect)(() => (!1 === u.open && f(!1), () => f(!1)), [u.open, f]), (0, o.createElement)(v.fC, i, (0, o.createElement)($, {
                        scope: t,
                        open: r,
                        onOpenChange: f,
                        content: d,
                        onContentChange: s
                    }, (0, o.createElement)(eh, {
                        scope: t,
                        contentId: (0, m.M)(),
                        triggerId: (0, m.M)(),
                        trigger: a,
                        onTriggerChange: c
                    }, n)))
                },
                eN = eE,
                eK = ey
        },
        93536: function(e, t, n) {
            n.d(t, {
                ee: function() {
                    return S
                },
                Eh: function() {
                    return D
                },
                VY: function() {
                    return O
                },
                fC: function() {
                    return k
                },
                D7: function() {
                    return v
                }
            });
            var r = n(87462),
                o = n(67294),
                l = n(1371),
                u = n(63853);
            n(73935);
            var i = n(4222);
            let a = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = (0, o.forwardRef)((e, n) => {
                        let {
                            asChild: l,
                            ...u
                        } = e, a = l ? i.g7 : t;
                        return (0, o.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, o.createElement)(a, (0, r.Z)({}, u, {
                            ref: n
                        }))
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {}),
                c = (0, o.forwardRef)((e, t) => {
                    let {
                        children: n,
                        width: l = 10,
                        height: u = 5,
                        ...i
                    } = e;
                    return (0, o.createElement)(a.svg, (0, r.Z)({}, i, {
                        ref: t,
                        width: l,
                        height: u,
                        viewBox: "0 0 30 10",
                        preserveAspectRatio: "none"
                    }), e.asChild ? n : (0, o.createElement)("polygon", {
                        points: "0,0 30,0 15,10"
                    }))
                });

            function d(...e) {
                return (0, o.useCallback)(function(...e) {
                    return t => e.forEach(e => {
                        "function" == typeof e ? e(t) : null != e && (e.current = t)
                    })
                }(...e), e)
            }
            let s = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = (0, o.forwardRef)((e, n) => {
                        let {
                            asChild: l,
                            ...u
                        } = e, a = l ? i.g7 : t;
                        return (0, o.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, o.createElement)(a, (0, r.Z)({}, u, {
                            ref: n
                        }))
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {}),
                f = (null == globalThis ? void 0 : globalThis.document) ? o.useLayoutEffect : () => {},
                p = "Popper",
                [m, v] = function(e, t = []) {
                    let n = [],
                        r = () => {
                            let t = n.map(e => (0, o.createContext)(e));
                            return function(n) {
                                let r = (null == n ? void 0 : n[e]) || t;
                                return (0, o.useMemo)(() => ({
                                    [`__scope${e}`]: { ...n,
                                        [e]: r
                                    }
                                }), [n, r])
                            }
                        };
                    return r.scopeName = e, [function(t, r) {
                        let l = (0, o.createContext)(r),
                            u = n.length;

                        function i(t) {
                            let {
                                scope: n,
                                children: r,
                                ...i
                            } = t, a = (null == n ? void 0 : n[e][u]) || l, c = (0, o.useMemo)(() => i, Object.values(i));
                            return (0, o.createElement)(a.Provider, {
                                value: c
                            }, r)
                        }
                        return n = [...n, r], i.displayName = t + "Provider", [i, function(n, i) {
                            let a = (null == i ? void 0 : i[e][u]) || l,
                                c = (0, o.useContext)(a);
                            if (c) return c;
                            if (void 0 !== r) return r;
                            throw Error(`\`${n}\` must be used within \`${t}\``)
                        }]
                    }, function(...e) {
                        let t = e[0];
                        if (1 === e.length) return t;
                        let n = () => {
                            let n = e.map(e => ({
                                useScope: e(),
                                scopeName: e.scopeName
                            }));
                            return function(e) {
                                let r = n.reduce((t, {
                                    useScope: n,
                                    scopeName: r
                                }) => {
                                    let o = n(e)[`__scope${r}`];
                                    return { ...t,
                                        ...o
                                    }
                                }, {});
                                return (0, o.useMemo)(() => ({
                                    [`__scope${t.scopeName}`]: r
                                }), [r])
                            }
                        };
                        return n.scopeName = t.scopeName, n
                    }(r, ...t)]
                }(p),
                [h, g] = m(p),
                w = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopePopper: n,
                        virtualRef: l,
                        ...u
                    } = e, i = g("PopperAnchor", n), a = (0, o.useRef)(null), c = d(t, a);
                    return (0, o.useEffect)(() => {
                        i.onAnchorChange((null == l ? void 0 : l.current) || a.current)
                    }), l ? null : (0, o.createElement)(s.div, (0, r.Z)({}, u, {
                        ref: c
                    }))
                }),
                E = "PopperContent",
                [y, _] = m(E),
                C = (0, o.forwardRef)((e, t) => {
                    var n, i, a, c, p, m, v, h;
                    let {
                        __scopePopper: w,
                        side: _ = "bottom",
                        sideOffset: C = 0,
                        align: b = "center",
                        alignOffset: M = 0,
                        arrowPadding: k = 0,
                        avoidCollisions: S = !0,
                        collisionBoundary: O = [],
                        collisionPadding: D = 0,
                        sticky: A = "partial",
                        hideWhenDetached: T = !1,
                        updatePositionStrategy: Z = "optimized",
                        onPlaced: I,
                        ...F
                    } = e, $ = g(E, w), [L, N] = (0, o.useState)(null), K = d(t, e => N(e)), [z, V] = (0, o.useState)(null), Y = function(e) {
                        let [t, n] = (0, o.useState)(void 0);
                        return f(() => {
                            if (e) {
                                n({
                                    width: e.offsetWidth,
                                    height: e.offsetHeight
                                });
                                let t = new ResizeObserver(t => {
                                    let r, o;
                                    if (!Array.isArray(t) || !t.length) return;
                                    let l = t[0];
                                    if ("borderBoxSize" in l) {
                                        let e = l.borderBoxSize,
                                            t = Array.isArray(e) ? e[0] : e;
                                        r = t.inlineSize, o = t.blockSize
                                    } else r = e.offsetWidth, o = e.offsetHeight;
                                    n({
                                        width: r,
                                        height: o
                                    })
                                });
                                return t.observe(e, {
                                    box: "border-box"
                                }), () => t.unobserve(e)
                            }
                            n(void 0)
                        }, [e]), t
                    }(z), B = null !== (n = null == Y ? void 0 : Y.width) && void 0 !== n ? n : 0, H = null !== (i = null == Y ? void 0 : Y.height) && void 0 !== i ? i : 0, W = "number" == typeof D ? D : {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0,
                        ...D
                    }, X = Array.isArray(O) ? O : [O], G = X.length > 0, U = {
                        padding: W,
                        boundary: X.filter(x),
                        altBoundary: G
                    }, {
                        refs: j,
                        floatingStyles: q,
                        placement: J,
                        isPositioned: Q,
                        middlewareData: ee
                    } = (0, l.YF)({
                        strategy: "fixed",
                        placement: _ + ("center" !== b ? "-" + b : ""),
                        whileElementsMounted: (...e) => (0, u.Me)(...e, {
                            animationFrame: "always" === Z
                        }),
                        elements: {
                            reference: $.anchor
                        },
                        middleware: [(0, l.cv)({
                            mainAxis: C + H,
                            alignmentAxis: M
                        }), S && (0, l.uY)({
                            mainAxis: !0,
                            crossAxis: !1,
                            limiter: "partial" === A ? (0, l.dr)() : void 0,
                            ...U
                        }), S && (0, l.RR)({ ...U
                        }), (0, l.dp)({ ...U,
                            apply: ({
                                elements: e,
                                rects: t,
                                availableWidth: n,
                                availableHeight: r
                            }) => {
                                let {
                                    width: o,
                                    height: l
                                } = t.reference, u = e.floating.style;
                                u.setProperty("--radix-popper-available-width", `${n}px`), u.setProperty("--radix-popper-available-height", `${r}px`), u.setProperty("--radix-popper-anchor-width", `${o}px`), u.setProperty("--radix-popper-anchor-height", `${l}px`)
                            }
                        }), z && (0, l.x7)({
                            element: z,
                            padding: k
                        }), P({
                            arrowWidth: B,
                            arrowHeight: H
                        }), T && (0, l.Cp)({
                            strategy: "referenceHidden",
                            ...U
                        })]
                    }), [et, en] = R(J), er = function(e) {
                        let t = (0, o.useRef)(e);
                        return (0, o.useEffect)(() => {
                            t.current = e
                        }), (0, o.useMemo)(() => (...e) => {
                            var n;
                            return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                        }, [])
                    }(I);
                    f(() => {
                        Q && (null == er || er())
                    }, [Q, er]);
                    let eo = null === (a = ee.arrow) || void 0 === a ? void 0 : a.x,
                        el = null === (c = ee.arrow) || void 0 === c ? void 0 : c.y,
                        eu = (null === (p = ee.arrow) || void 0 === p ? void 0 : p.centerOffset) !== 0,
                        [ei, ea] = (0, o.useState)();
                    return f(() => {
                        L && ea(window.getComputedStyle(L).zIndex)
                    }, [L]), (0, o.createElement)("div", {
                        ref: j.setFloating,
                        "data-radix-popper-content-wrapper": "",
                        style: { ...q,
                            transform: Q ? q.transform : "translate(0, -200%)",
                            minWidth: "max-content",
                            zIndex: ei,
                            "--radix-popper-transform-origin": [null === (m = ee.transformOrigin) || void 0 === m ? void 0 : m.x, null === (v = ee.transformOrigin) || void 0 === v ? void 0 : v.y].join(" ")
                        },
                        dir: e.dir
                    }, (0, o.createElement)(y, {
                        scope: w,
                        placedSide: et,
                        onArrowChange: V,
                        arrowX: eo,
                        arrowY: el,
                        shouldHideArrow: eu
                    }, (0, o.createElement)(s.div, (0, r.Z)({
                        "data-side": et,
                        "data-align": en
                    }, F, {
                        ref: K,
                        style: { ...F.style,
                            animation: Q ? void 0 : "none",
                            opacity: null !== (h = ee.hide) && void 0 !== h && h.referenceHidden ? 0 : void 0
                        }
                    }))))
                }),
                b = {
                    top: "bottom",
                    right: "left",
                    bottom: "top",
                    left: "right"
                },
                M = (0, o.forwardRef)(function(e, t) {
                    let {
                        __scopePopper: n,
                        ...l
                    } = e, u = _("PopperArrow", n), i = b[u.placedSide];
                    return (0, o.createElement)("span", {
                        ref: u.onArrowChange,
                        style: {
                            position: "absolute",
                            left: u.arrowX,
                            top: u.arrowY,
                            [i]: 0,
                            transformOrigin: {
                                top: "",
                                right: "0 0",
                                bottom: "center 0",
                                left: "100% 0"
                            }[u.placedSide],
                            transform: {
                                top: "translateY(100%)",
                                right: "translateY(50%) rotate(90deg) translateX(-50%)",
                                bottom: "rotate(180deg)",
                                left: "translateY(50%) rotate(-90deg) translateX(50%)"
                            }[u.placedSide],
                            visibility: u.shouldHideArrow ? "hidden" : void 0
                        }
                    }, (0, o.createElement)(c, (0, r.Z)({}, l, {
                        ref: t,
                        style: { ...l.style,
                            display: "block"
                        }
                    })))
                });

            function x(e) {
                return null !== e
            }
            let P = e => ({
                name: "transformOrigin",
                options: e,
                fn(t) {
                    var n, r, o, l, u;
                    let {
                        placement: i,
                        rects: a,
                        middlewareData: c
                    } = t, d = (null === (n = c.arrow) || void 0 === n ? void 0 : n.centerOffset) !== 0, s = d ? 0 : e.arrowWidth, f = d ? 0 : e.arrowHeight, [p, m] = R(i), v = {
                        start: "0%",
                        center: "50%",
                        end: "100%"
                    }[m], h = (null !== (r = null === (o = c.arrow) || void 0 === o ? void 0 : o.x) && void 0 !== r ? r : 0) + s / 2, g = (null !== (l = null === (u = c.arrow) || void 0 === u ? void 0 : u.y) && void 0 !== l ? l : 0) + f / 2, w = "", E = "";
                    return "bottom" === p ? (w = d ? v : `${h}px`, E = `${-f}px`) : "top" === p ? (w = d ? v : `${h}px`, E = `${a.floating.height+f}px`) : "right" === p ? (w = `${-f}px`, E = d ? v : `${g}px`) : "left" === p && (w = `${a.floating.width+f}px`, E = d ? v : `${g}px`), {
                        data: {
                            x: w,
                            y: E
                        }
                    }
                }
            });

            function R(e) {
                let [t, n = "center"] = e.split("-");
                return [t, n]
            }
            let k = e => {
                    let {
                        __scopePopper: t,
                        children: n
                    } = e, [r, l] = (0, o.useState)(null);
                    return (0, o.createElement)(h, {
                        scope: t,
                        anchor: r,
                        onAnchorChange: l
                    }, n)
                },
                S = w,
                O = C,
                D = M
        }
    }
]);