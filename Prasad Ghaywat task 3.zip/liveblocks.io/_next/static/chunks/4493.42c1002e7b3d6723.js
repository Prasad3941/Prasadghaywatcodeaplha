"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4493], {
        20780: function(e, t, n) {
            n.d(t, {
                S: function() {
                    return i
                }
            });
            var r = n(67294);
            let o = (0, r.createContext)(null);
            class i extends r.Component {
                static getDerivedStateFromError(e) {
                    return {
                        error: e
                    }
                }
                componentDidCatch(e, t) {
                    console.error(e, t)
                }
                reset() {
                    this.setState({
                        error: null
                    })
                }
                render() {
                    return null === this.state.error ? this.props.children : (0, r.createElement)(o.Provider, {
                        value: {
                            error: this.state.error,
                            reset: this.reset.bind(this)
                        }
                    }, this.props.fallback)
                }
                constructor(e) {
                    super(e), this.state = {
                        error: null
                    }
                }
            }
        },
        35710: function(e, t, n) {
            n.d(t, {
                u: function() {
                    return r
                }
            });

            function r(e, t, n) {
                return isNaN(e) && (e = 0), Math.min(Math.max(e, t), n)
            }
        },
        6123: function(e, t, n) {
            n.d(t, {
                R: function() {
                    return o
                }
            });
            var r = n(67294);

            function o(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "0px",
                    [n, o] = (0, r.useState)(!1);
                return (0, r.useEffect)(() => {
                    if (!("IntersectionObserver" in window)) {
                        o(!0);
                        return
                    }
                    let n = new IntersectionObserver(e => {
                        let [t] = e;
                        o(t.isIntersecting)
                    }, {
                        rootMargin: t
                    });
                    e.current && n.observe(e.current);
                    let r = e.current;
                    return () => {
                        r && n.unobserve(r)
                    }
                }, []), n
            }
        },
        64493: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return tt
                }
            });
            var r = n(85893),
                o = n(85769),
                i = n(49637),
                a = n(90319),
                s = n(51007),
                l = n(52314),
                c = n(5964),
                u = n(97134),
                d = n(70587),
                f = n(38198),
                m = n(19390),
                h = n(15029),
                p = n(63467),
                v = n(49972),
                g = n(3937),
                x = n(87316),
                y = n(79716),
                S = n(63301),
                b = n(10105),
                j = n(4960),
                C = n(14025),
                w = n(19575),
                M = n(24368),
                k = n(4002),
                P = n(61215),
                I = n(51818),
                z = n(54735),
                E = n(23279),
                R = n.n(E),
                B = n(19188),
                L = n(67294),
                D = n(99477),
                N = n(20780),
                A = n(35710),
                O = n(6123),
                T = n(81634),
                F = n(97547);
            let V = Array.from({
                length: 200
            });

            function G(e) {
                return e * (Math.random() - Math.random())
            }

            function _(e, t) {
                return e + (t - e) * Math.random()
            }

            function W() {
                return {
                    life: 0,
                    maxDuration: _(1, 3),
                    position: {
                        x: 0,
                        y: 0,
                        z: 0
                    },
                    destination: {
                        x: (Math.random() - .5) * 30 * Math.random(),
                        y: _(-15, 0),
                        z: (Math.random() - .5) * 30 * Math.random()
                    },
                    rotation: {
                        x: Math.random() * Math.PI * 2,
                        y: Math.random() * Math.PI * 2,
                        z: Math.random() * Math.PI * 2
                    },
                    rotationSpeed: {
                        x: G(20),
                        y: G(20),
                        z: G(20)
                    }
                }
            }

            function J(e) {
                let {
                    explosionKey: t
                } = e, n = (0, L.useRef)(), o = (0, L.useRef)(null);
                return (0, L.useEffect)(() => {
                    n.current && !(t <= 0) && (o.current = W(), n.current.position.set(0, 0, 0), n.current.rotation.set(0, 0, 0), n.current.scale.set(0, 0, 0))
                }, [t]), (0, m.C)((e, r) => {
                    if (t <= 0 || (o.current || (o.current = W()), o.current.life >= o.current.maxDuration)) return;
                    o.current.life += r, o.current.destination.x -= .2 * o.current.destination.x * r, o.current.destination.y -= _(.5, 1.5) * r, o.current.destination.z -= .2 * o.current.destination.z * r;
                    let i = (o.current.destination.x - o.current.position.x) / 2,
                        a = (o.current.destination.y - o.current.position.y) / 2,
                        s = (o.current.destination.z - o.current.position.z) / 2;
                    if (o.current.position.x += i * r, o.current.position.y += a * r, o.current.position.z += s * r, o.current.rotation.x += o.current.rotationSpeed.x * r, o.current.rotation.y += o.current.rotationSpeed.y * r, o.current.rotation.z += o.current.rotationSpeed.z * r, !n.current) return;
                    n.current.visible = !0, n.current.position.set(o.current.position.x + .2 * Math.cos(o.current.position.y), o.current.position.y, o.current.position.z + .2 * Math.sin(o.current.position.y)), n.current.rotation.set(o.current.rotation.x, o.current.rotation.y, o.current.rotation.z);
                    let l = 1 - o.current.life / o.current.maxDuration;
                    n.current.scale.set(l, l, l), o.current.life >= o.current.maxDuration && (n.current.visible = !1)
                }), (0, r.jsx)(F.K4, {
                    ref: n
                })
            }
            let U = new D.PlaneGeometry(.15, .15),
                H = new D.MeshStandardMaterial({
                    roughness: 1,
                    color: "#000",
                    side: D.DoubleSide
                }),
                K = (0, L.memo)(e => {
                    let {
                        explosionKey: t
                    } = e;
                    return (0, r.jsx)(F.EJ, {
                        limit: 200,
                        position: [0, 8, 0],
                        frustumCulled: !1,
                        material: H,
                        geometry: U,
                        children: V.map((e, n) => (0, r.jsx)(J, {
                            explosionKey: t
                        }, n))
                    })
                });
            var Z = n(4950),
                q = n(99137),
                Q = n(53840);

            function X() {
                let {
                    nodes: e
                } = (0, Q.L)("/three-hero/models.glb");
                return e
            }
            Q.L.preload("/three-hero/models.glb");
            var Y = n(86611),
                $ = n(77470);
            let ee = new D.Vector3(0, 0, 0),
                et = new D.Vector3,
                en = new D.Vector3,
                er = new D.Vector3,
                eo = new D.Raycaster;
            eo.layers.disableAll();
            let ei = new D.Vector3,
                ea = new D.Vector3,
                es = new D.Plane(new D.Vector3(0, 1, 0), 0);

            function el(e, t, n) {
                return t.updateMatrixWorld(), eo.setFromCamera(e, t), eo.ray.at(n, ei), ei.y < 0 ? (eo.ray.intersectPlane(es, ei), ea.copy(es.normal)) : (t.getWorldDirection(ea), ea.negate()), [ei.clone(), ea.clone()]
            }
            let ec = new D.Vector3;

            function eu(e, t) {
                return ec.copy(e).sub(t.position).normalize(), e.clone().sub(ec.multiplyScalar(Y.QF))
            }
            let ed = new D.Matrix4,
                ef = new D.Quaternion,
                em = new D.Vector3(0, 0, 1);

            function eh(e) {
                let t = e.face.normal.clone().transformDirection(e.object.matrixWorld).normalize().add(e.point);
                return ed.lookAt(t, e.point, em), ef.setFromRotationMatrix(ed), ef.clone()
            }

            function ep(e) {
                return {
                    x: e.x,
                    y: e.y,
                    z: e.z
                }
            }

            function ev(e) {
                return {
                    w: e.w,
                    x: e.x,
                    y: e.y,
                    z: e.z
                }
            }

            function eg(e) {
                return e.length ? [e.reduce((e, t) => t.distance < e.distance ? t : e)] : e
            }

            function ex() {
                z.ZP.update(() => {
                    document.body.style.removeProperty("cursor")
                })
            }
            var ey = n(20745);

            function eS(e) {
                var t;
                let {
                    portal: n,
                    children: o
                } = e, {
                    gl: i
                } = (0, m.A)(), [a] = (0, L.useState)(() => document.createElement("div")), s = (0, L.useRef)(), l = null !== (t = null == n ? void 0 : n.current) && void 0 !== t ? t : i.domElement.parentNode;
                return (0, L.useLayoutEffect)(() => {
                    s.current = (0, ey.createRoot)(a);
                    let e = s.current;
                    return l && l.appendChild(a), () => {
                        l && l.removeChild(a), null == e || e.unmount()
                    }
                }, [a, l]), (0, L.useLayoutEffect)(() => {
                    var e;
                    null === (e = s.current) || void 0 === e || e.render((0, r.jsx)(r.Fragment, {
                        children: o
                    }))
                }), null
            }
            var eb = n(43893),
                ej = n.n(eb);

            function eC() {
                let e = X();
                return (0, o.m)("/three-hero/cursor-matcap.png"), (0, r.jsx)("mesh", {
                    geometry: e.cursor.geometry,
                    visible: !1,
                    children: (0, r.jsx)("cursorMaterial", {}, ew.key)
                })
            }
            let ew = (0, Z.g)({
                uColor: new D.Color("#fff"),
                uMatcap: null,
                uOpacity: 0
            }, "\n  varying vec3 vNormal;\n  varying vec3 vViewPosition;\n\n  void main() {\n    vNormal = normalize(normalMatrix * normal);\n    vec4 modelViewPosition = modelViewMatrix * vec4(position, 1.0);\n    vViewPosition = -modelViewPosition.xyz;\n\n    gl_Position = projectionMatrix * modelViewPosition;\n  }\n", "\nvarying vec3 vNormal;\nvarying vec3 vViewPosition;\n\nuniform vec3 uColor;\nuniform sampler2D uMatcap;\nuniform float uOpacity;\n\nvoid main() {\n  vec3 normal = normalize(vNormal);\n  vec3 viewDir = normalize(vViewPosition);\n\n  vec3 reflectionVector = reflect(viewDir, normal);\n  float reflectionVectorScale = 2.0 * sqrt(\n    pow(reflectionVector.x, 2.0) +\n    pow(reflectionVector.y, 2.0) +\n    (reflectionVector.z + 1.0) * (reflectionVector.z + 1.0)\n  );\n\n  vec2 matcapUv = reflectionVector.xy / reflectionVectorScale + 0.5;\n  vec4 matcapColor = texture2D(uMatcap, matcapUv);\n\n  float matcapGrayscale = matcapColor.r;\n\n  vec3 color0 = vec3(0.0, 0.0, 0.0);\n  vec3 color55 = uColor * 0.4;\n  vec3 color90 = uColor;\n  vec3 color100 = vec3(1.0, 1.0, 1.0);\n\n  vec3 gradientColor;\n\n  if (matcapGrayscale < 0.55) {\n      gradientColor = mix(color0, color55, matcapGrayscale / 0.55);\n  } else if (matcapGrayscale < 0.9) {\n      gradientColor = mix(color55, color90, (matcapGrayscale - 0.55) / 0.35);\n  } else {\n      gradientColor = mix(color90, color100, (matcapGrayscale - 0.9) / 0.1);\n  }\n\n  gl_FragColor = vec4(gradientColor, uOpacity);\n\n  #include <tonemapping_fragment>\n  #include <colorspace_fragment>\n}\n");
            (0, m.e)({
                CursorMaterial: ew
            });
            let eM = (0, L.memo)(e => {
                    let {
                        connectionId: t
                    } = e, n = (0, o.m)("/three-hero/cursor-matcap.png"), i = (0, $.iv)(), a = X(), s = (0, q.NW)(), l = i(e => e.cursorsContainerRef), c = i(e => e.supportFlagEmojis), u = (0, L.useRef)(null), d = (0, L.useRef)(null), f = (0, L.useRef)(null), h = (0, L.useRef)(null), p = (0, L.useRef)(null), v = (0, L.useRef)(), g = (0, L.useRef)(!0), [x, y] = (0, L.useState)(""), [S, b] = (0, L.useState)(!1), k = (0, q.v8)(t, e => e.info.color), P = (0, q.v8)(t, e => e.info.emoji), I = (0, q.v8)(t, e => e.info.city), z = (0, q.v8)(t, e => e.info.country), E = (0, j.c)(0);
                    return (0, C.W)(E, "change", e => {
                        e <= 0 && (g.current = !0), d.current && (d.current.material.uniforms.uOpacity.value = e)
                    }), (0, L.useEffect)(() => {
                        (0, w.j)(E, S ? 1 : 0, {
                            duration: .12,
                            ease: "easeInOut"
                        })
                    }, [S]), (0, L.useLayoutEffect)(() => s.subscribe("others", e => {
                        var n;
                        if (!u.current) return;
                        let r = e.find(e => e.connectionId === t);
                        (null == r ? void 0 : r.presence.cursor) ? (v.current = r.presence.cursor, b(!0)) : b(!1), y(null !== (n = null == r ? void 0 : r.presence.chat) && void 0 !== n ? n : "")
                    }), [t, s]), (0, m.C)((0, L.useCallback)((e, t) => {
                        var n, r, o, i;
                        if (!u.current || !d.current || !f.current || !h.current || !p.current || !v.current) return;
                        g.current ? (u.current.position.copy(v.current.position), u.current.quaternion.copy(v.current.rotation), g.current = !1) : ((0, B.G0)(u.current.position, v.current.position, Y.l5, t), (0, B.OZ)(u.current.quaternion, v.current.rotation, Y.pq, t));
                        let a = (n = f.current, r = e.camera, o = Math.round(e.size.width), i = Math.round(e.size.height), n.updateMatrixWorld(), n.getWorldPosition(er), r.updateMatrixWorld(), er.project(r), er.x = (er.x + 1) * o / 2, er.y = -(er.y - 1) * i / 2, er.z = 0, er.clone()),
                            s = (0, M.v)(e.size.width, [300, 1400], [.5, 1]);
                        h.current.style.transform = "translate(".concat(Math.round(a.x), "px, ").concat(Math.round(a.y), "px) scale(").concat(s, ")")
                    }, [S])), (0, r.jsxs)("group", {
                        ref: u,
                        children: [(0, r.jsx)("group", {
                            position: [-.16, 0, .12],
                            ref: f
                        }), (0, r.jsx)("group", {
                            rotation: [0, 0, -Math.PI / 2],
                            children: (0, r.jsxs)("group", {
                                rotation: [.3 * Math.PI, -(.6 * Math.PI), 0],
                                children: [(0, r.jsx)("mesh", {
                                    ref: d,
                                    geometry: a.cursor.geometry,
                                    scale: [.2, .2, .2],
                                    renderOrder: 1e7,
                                    children: (0, r.jsx)("cursorMaterial", {
                                        transparent: !0,
                                        toneMapped: !1,
                                        depthTest: !1,
                                        depthWrite: !1,
                                        uColor: k,
                                        uMatcap: n
                                    }, ew.key)
                                }), (0, r.jsx)(eS, {
                                    portal: l,
                                    children: (0, r.jsx)("div", {
                                        ref: h,
                                        className: ej().cursorBubblePosition,
                                        children: (0, r.jsxs)("div", {
                                            ref: p,
                                            className: ej().cursorBubble,
                                            style: {
                                                opacity: S ? 1 : 0,
                                                background: k
                                            },
                                            "data-chat": x ? "" : void 0,
                                            children: [(0, r.jsx)("span", {
                                                className: ej().cursorBubbleName,
                                                children: c ? (0, r.jsxs)(r.Fragment, {
                                                    children: [(0, r.jsx)("span", {
                                                        "data-emoji": !0,
                                                        children: P
                                                    }), " ", I]
                                                }) : (0, r.jsxs)(r.Fragment, {
                                                    children: [I, ", ", z]
                                                })
                                            }), x && (0, r.jsx)("span", {
                                                className: ej().cursorBubbleChat,
                                                children: x
                                            })]
                                        })
                                    })
                                })]
                            })
                        })]
                    })
                }),
                ek = new D.PlaneGeometry(10 * Y.MJ, 10 * Y.MJ, 1, 1),
                eP = new D.MeshStandardMaterial({
                    color: "#000",
                    roughness: 1,
                    metalness: .95,
                    transparent: !0
                });
            eP.customProgramCacheKey = () => "ground", eP.onBeforeCompile = e => {
                e.vertexShader = "\nvarying vec3 vLocalPosition;\nvarying vec3 vWorldPosition;\n".concat(e.vertexShader, "\n"), e.fragmentShader = "\nvarying vec3 vLocalPosition;\nvarying vec3 vWorldPosition;\n".concat(e.fragmentShader, "\n"), e.vertexShader = e.vertexShader.replace("#include <worldpos_vertex>", "\n#include <worldpos_vertex>\nvLocalPosition = position.xzy;\nvWorldPosition = (modelMatrix * vec4(vLocalPosition, 1.0)).xyz;\n"), e.fragmentShader = e.fragmentShader.replace("#include <color_fragment>", "\n#include <color_fragment>\n\nfloat cell = 1.0;\nfloat thickness = 0.5;\n\nvec2 size = vLocalPosition.xz / cell;\nvec2 grid = abs(fract(size - 0.5) - 0.5) / fwidth(size);\nfloat line = min(grid.x, grid.y) + 1.0 - thickness;\nfloat pattern = 1.0 - min(line, 1.0);\n\nvec2 index = floor(size);\n\n// Make holes for the 4 buttons\nif ((index == vec2(-4.0, -4.0)) || (index == vec2(-4.0, 3.0)) || (index == vec2(3.0, 3.0)) || (index == vec2(3.0, -4.0))) {\n  discard;\n}\n\nfloat offset = distance(vWorldPosition.xyz, vec3(0.0, 0.0, 0.0));\nfloat strength = (1.0 - (offset / 20.0)) * 0.005;\n\nfloat color = pattern * strength;\nvec4 gridColor = vec4(color, color, color, 1.0);\nfloat randomOpacity = (0.2 + fract(sin(dot(index ,vec2(12.9898,78.233))) * 43758.5453) * 0.3) * strength;\nvec4 randomWhiteOverlay = vec4(1.0, 1.0, 1.0, randomOpacity);\n\n// Blend the grid color with the random white overlay\ndiffuseColor = mix(gridColor, randomWhiteOverlay, randomWhiteOverlay.a);\n")
            };
            let eI = (0, L.memo)(() => (0, r.jsx)("mesh", {
                geometry: ek,
                material: eP,
                position: [0, -.05, 0],
                rotation: [-Math.PI / 2, 0, 0],
                receiveShadow: !0
            }));
            var ez = n(69015),
                eE = n(39332);

            function eR(e) {
                let {
                    minimum: t
                } = e, n = (0, $.iv)(), r = (0, ez.S)().total >= t, o = (0, eE.usePathname)();
                return (0, L.useLayoutEffect)(() => {
                    n.getState().isLoaded || n.setState({
                        isLoaded: r
                    })
                }, [r]), (0, L.useEffect)(() => {
                    let e = () => {
                        n.setState({
                            isLoaded: !1
                        })
                    };
                    return window.addEventListener("beforeunload", e), () => {
                        window.removeEventListener("beforeunload", e)
                    }
                }, []), (0, L.useEffect)(() => {
                    n.setState({
                        isLoaded: !1
                    })
                }, [o]), null
            }
            class eB extends D.MeshPhysicalMaterial {
                constructor(e = 6, t = !1) {
                    super(), this.uniforms = {
                        chromaticAberration: {
                            value: .05
                        },
                        transmission: {
                            value: 0
                        },
                        _transmission: {
                            value: 1
                        },
                        transmissionMap: {
                            value: null
                        },
                        roughness: {
                            value: 0
                        },
                        roughnessBlurFactor: {
                            value: 1
                        },
                        thickness: {
                            value: 0
                        },
                        thicknessMap: {
                            value: null
                        },
                        attenuationDistance: {
                            value: 1 / 0
                        },
                        attenuationColor: {
                            value: new D.Color("white")
                        },
                        anisotropicBlur: {
                            value: .1
                        },
                        time: {
                            value: 0
                        },
                        distortion: {
                            value: 0
                        },
                        distortionScale: {
                            value: .5
                        },
                        temporalDistortion: {
                            value: 0
                        },
                        buffer: {
                            value: null
                        }
                    }, this.onBeforeCompile = n => {
                        n.uniforms = { ...n.uniforms,
                            ...this.uniforms
                        }, this.anisotropy > 0 && (n.defines.USE_ANISOTROPY = ""), t ? n.defines.USE_SAMPLER = "" : n.defines.USE_TRANSMISSION = "", n.fragmentShader = "\n      uniform float chromaticAberration;         \n      uniform float anisotropicBlur;      \n      uniform float time;\n      uniform float distortion;\n      uniform float distortionScale;\n      uniform float temporalDistortion;\n      uniform sampler2D buffer;\n\n      vec3 random3(vec3 c) {\n        float j = 4096.0*sin(dot(c,vec3(17.0, 59.4, 15.0)));\n        vec3 r;\n        r.z = fract(512.0*j);\n        j *= .125;\n        r.x = fract(512.0*j);\n        j *= .125;\n        r.y = fract(512.0*j);\n        return r-0.5;\n      }\n\n      uint hash( uint x ) {\n        x += ( x << 10u );\n        x ^= ( x >>  6u );\n        x += ( x <<  3u );\n        x ^= ( x >> 11u );\n        x += ( x << 15u );\n        return x;\n      }\n\n      // Compound versions of the hashing algorithm I whipped together.\n      uint hash( uvec2 v ) { return hash( v.x ^ hash(v.y)                         ); }\n      uint hash( uvec3 v ) { return hash( v.x ^ hash(v.y) ^ hash(v.z)             ); }\n      uint hash( uvec4 v ) { return hash( v.x ^ hash(v.y) ^ hash(v.z) ^ hash(v.w) ); }\n\n      // Construct a float with half-open range [0:1] using low 23 bits.\n      // All zeroes yields 0.0, all ones yields the next smallest representable value below 1.0.\n      float floatConstruct( uint m ) {\n        const uint ieeeMantissa = 0x007FFFFFu; // binary32 mantissa bitmask\n        const uint ieeeOne      = 0x3F800000u; // 1.0 in IEEE binary32\n        m &= ieeeMantissa;                     // Keep only mantissa bits (fractional part)\n        m |= ieeeOne;                          // Add fractional part to 1.0\n        float  f = uintBitsToFloat( m );       // Range [1:2]\n        return f - 1.0;                        // Range [0:1]\n      }\n\n      // Pseudo-random value in half-open range [0:1].\n      float randomBase( float x ) { return floatConstruct(hash(floatBitsToUint(x))); }\n      float randomBase( vec2  v ) { return floatConstruct(hash(floatBitsToUint(v))); }\n      float randomBase( vec3  v ) { return floatConstruct(hash(floatBitsToUint(v))); }\n      float randomBase( vec4  v ) { return floatConstruct(hash(floatBitsToUint(v))); }\n      float rand(float seed) {\n        float result = randomBase(vec3(gl_FragCoord.xy, seed));\n        return result;\n      }\n\n      const float F3 =  0.3333333;\n      const float G3 =  0.1666667;\n\n      float snoise(vec3 p) {\n        vec3 s = floor(p + dot(p, vec3(F3)));\n        vec3 x = p - s + dot(s, vec3(G3));\n        vec3 e = step(vec3(0.0), x - x.yzx);\n        vec3 i1 = e*(1.0 - e.zxy);\n        vec3 i2 = 1.0 - e.zxy*(1.0 - e);\n        vec3 x1 = x - i1 + G3;\n        vec3 x2 = x - i2 + 2.0*G3;\n        vec3 x3 = x - 1.0 + 3.0*G3;\n        vec4 w, d;\n        w.x = dot(x, x);\n        w.y = dot(x1, x1);\n        w.z = dot(x2, x2);\n        w.w = dot(x3, x3);\n        w = max(0.6 - w, 0.0);\n        d.x = dot(random3(s), x);\n        d.y = dot(random3(s + i1), x1);\n        d.z = dot(random3(s + i2), x2);\n        d.w = dot(random3(s + 1.0), x3);\n        w *= w;\n        w *= w;\n        d *= w;\n        return dot(d, vec4(52.0));\n      }\n\n      float snoiseFractal(vec3 m) {\n        return 0.5333333* snoise(m)\n              +0.2666667* snoise(2.0*m)\n              +0.1333333* snoise(4.0*m)\n              +0.0666667* snoise(8.0*m);\n      }\n" + n.fragmentShader, n.fragmentShader = n.fragmentShader.replace("#include <transmission_pars_fragment>", "\n        #ifdef USE_TRANSMISSION\n          // Transmission code is based on glTF-Sampler-Viewer\n          // https://github.com/KhronosGroup/glTF-Sample-Viewer\n          uniform float _transmission;\n          uniform float thickness;\n          uniform float roughnessBlurFactor;\n          uniform float attenuationDistance;\n          uniform vec3 attenuationColor;\n          #ifdef USE_TRANSMISSIONMAP\n            uniform sampler2D transmissionMap;\n          #endif\n          #ifdef USE_THICKNESSMAP\n            uniform sampler2D thicknessMap;\n          #endif\n          uniform vec2 transmissionSamplerSize;\n          uniform sampler2D transmissionSamplerMap;\n          uniform mat4 modelMatrix;\n          uniform mat4 projectionMatrix;\n          varying vec3 vWorldPosition;\n          vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {\n            // Direction of refracted light.\n            vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );\n            // Compute rotation-independant scaling of the model matrix.\n            vec3 modelScale;\n            modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );\n            modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );\n            modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );\n            // The thickness is specified in local space.\n            return normalize( refractionVector ) * thickness * modelScale;\n          }\n          float applyIorToRoughness( const in float roughness, const in float ior ) {\n            // Scale roughness with IOR so that an IOR of 1.0 results in no microfacet refraction and\n            // an IOR of 1.5 results in the default amount of microfacet refraction.\n            return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );\n          }\n          vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {\n            float framebufferLod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );            \n            #ifdef USE_SAMPLER\n              #ifdef texture2DLodEXT\n                return texture2DLodEXT(transmissionSamplerMap, fragCoord.xy, framebufferLod);\n              #else\n                return texture2D(transmissionSamplerMap, fragCoord.xy, framebufferLod);\n              #endif\n            #else\n              return texture2D(buffer, fragCoord.xy);\n            #endif\n          }\n          vec3 applyVolumeAttenuation( const in vec3 radiance, const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {\n            if ( isinf( attenuationDistance ) ) {\n              // Attenuation distance is +∞, i.e. the transmitted color is not attenuated at all.\n              return radiance;\n            } else {\n              // Compute light attenuation using Beer's law.\n              vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;\n              vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance ); // Beer's law\n              return transmittance * radiance;\n            }\n          }\n          vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,\n            const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,\n            const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,\n            const in vec3 attenuationColor, const in float attenuationDistance ) {\n            vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );\n            vec3 refractedRayExit = position + transmissionRay;\n            // Project refracted vector on the framebuffer, while mapping to normalized device coordinates.\n            vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n            vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n            refractionCoords += 1.0;\n            refractionCoords /= 2.0;\n            // Sample framebuffer to get pixel the refracted ray hits.\n            vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );\n            vec3 attenuatedColor = applyVolumeAttenuation( transmittedLight.rgb, length( transmissionRay ), attenuationColor, attenuationDistance );\n            // Get the specular component.\n            vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );\n            return vec4( ( 1.0 - F ) * attenuatedColor * diffuseColor, transmittedLight.a );\n          }\n        #endif\n"), n.fragmentShader = n.fragmentShader.replace("#include <transmission_fragment>", "  \n        // Improve the refraction to use the world pos\n        material.transmission = _transmission;\n        material.transmissionAlpha = 1.0;\n        material.thickness = thickness;\n        material.attenuationDistance = attenuationDistance;\n        material.attenuationColor = attenuationColor;\n        #ifdef USE_TRANSMISSIONMAP\n          material.transmission *= texture2D( transmissionMap, vUv ).r;\n        #endif\n        #ifdef USE_THICKNESSMAP\n          material.thickness *= texture2D( thicknessMap, vUv ).g;\n        #endif\n        \n        vec3 pos = vWorldPosition;\n        float runningSeed = 0.0;\n        vec3 v = normalize( cameraPosition - pos );\n        vec3 n = inverseTransformDirection( normal, viewMatrix );\n        vec3 transmission = vec3(0.0);\n        float transmissionR, transmissionB, transmissionG;\n        float randomCoords = rand(runningSeed++);\n        roughnessFactor = roughnessFactor * roughnessBlurFactor;\n        float thickness_smear = thickness * max(pow(roughnessFactor, 0.33), anisotropicBlur);\n        vec3 distortionNormal = vec3(0.0);\n        vec3 temporalOffset = vec3(time, -time, -time) * temporalDistortion;\n        if (distortion > 0.0) {\n          distortionNormal = distortion * vec3(snoiseFractal(vec3((pos * distortionScale + temporalOffset))), snoiseFractal(vec3(pos.zxy * distortionScale - temporalOffset)), snoiseFractal(vec3(pos.yxz * distortionScale + temporalOffset)));\n        }\n        for (float i = 0.0; i < ".concat(e, ".0; i ++) {\n          vec3 sampleNorm = normalize(n + roughnessFactor * roughnessFactor * 2.0 * normalize(vec3(rand(runningSeed++) - 0.5, rand(runningSeed++) - 0.5, rand(runningSeed++) - 0.5)) * pow(rand(runningSeed++), 0.33) + distortionNormal);\n          transmissionR = getIBLVolumeRefraction(\n            sampleNorm, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,\n            pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness  + thickness_smear * (i + randomCoords) / float(").concat(e, "),\n            material.attenuationColor, material.attenuationDistance\n          ).r;\n          transmissionG = getIBLVolumeRefraction(\n            sampleNorm, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,\n            pos, modelMatrix, viewMatrix, projectionMatrix, material.ior  * (1.0 + chromaticAberration * (i + randomCoords) / float(").concat(e, ")) , material.thickness + thickness_smear * (i + randomCoords) / float(").concat(e, "),\n            material.attenuationColor, material.attenuationDistance\n          ).g;\n          transmissionB = getIBLVolumeRefraction(\n            sampleNorm, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,\n            pos, modelMatrix, viewMatrix, projectionMatrix, material.ior * (1.0 + 2.0 * chromaticAberration * (i + randomCoords) / float(").concat(e, ")), material.thickness + thickness_smear * (i + randomCoords) / float(").concat(e, "),\n            material.attenuationColor, material.attenuationDistance\n          ).b;\n          transmission.r += transmissionR;\n          transmission.g += transmissionG;\n          transmission.b += transmissionB;\n        }\n        transmission /= ").concat(e, ".0;\n        totalDiffuse = mix( totalDiffuse, transmission.rgb, material.transmission );\n"))
                    }, Object.keys(this.uniforms).forEach(e => Object.defineProperty(this, e, {
                        get: () => this.uniforms[e].value,
                        set: t => this.uniforms[e].value = t
                    }))
                }
            }
            let eL = e => {
                let {
                    buffer: t,
                    side: n = D.FrontSide,
                    transmission: o = 1,
                    thickness: i = 0,
                    samples: a = 10,
                    background: s,
                    anisotropy: l,
                    anisotropicBlur: c,
                    ...u
                } = e;
                return (0, m.e)({
                    MeshTransmissionMaterialForked: eB
                }), (0, r.jsx)("meshTransmissionMaterialForked", {
                    args: [a, !1],
                    ...u,
                    buffer: t,
                    _transmission: o,
                    anisotropicBlur: null != c ? c : l,
                    transmission: 0,
                    thickness: i,
                    side: n
                })
            };

            function eD() {
                return (0, o.m)("/three-hero/spotlight-2.0.png"), null
            }

            function eN(e) {
                let {
                    type: t
                } = e, n = (0, $.iv)(), i = n(e => e.shouldPreloadKonamiCode), a = n(e => e.isKonamiCodeActive), s = (0, o.m)(a ? "/three-hero/spotlight-2.0.png" : "404" === t ? "/three-hero/spotlight-404.png" : "/three-hero/spotlight.png");
                return (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)(L.Suspense, {
                        children: i && (0, r.jsx)(eD, {})
                    }), (0, r.jsx)("spotLight", {
                        intensity: 75e3,
                        position: [0, 20, -12],
                        color: "#fff",
                        distance: 30,
                        decay: .8,
                        angle: .2,
                        penumbra: 1,
                        castShadow: !0,
                        map: s
                    })]
                })
            }
            let eA = (0, L.memo)(e => {
                    let {
                        children: t,
                        rigidBodyProps: n,
                        physicsMeshProps: o,
                        visualMeshProps: i
                    } = e, a = X();
                    return (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)(S.ib, {
                            type: "kinematicPosition",
                            colliders: "cuboid",
                            includeInvisible: !0,
                            ...n,
                            restitution: .2,
                            friction: .8,
                            density: 4,
                            children: (0, r.jsx)("mesh", {
                                geometry: a["cube-simple"].geometry,
                                ...o,
                                layers: e_,
                                visible: !1
                            })
                        }), (0, r.jsx)("mesh", {
                            geometry: a.cube.geometry,
                            castShadow: !0,
                            receiveShadow: !0,
                            scale: [.99, .99, .99],
                            ...i,
                            children: t
                        })]
                    })
                }),
                eO = (0, L.memo)(e => {
                    let {
                        children: t,
                        rigidBodyProps: n,
                        physicsMeshProps: o,
                        visualMeshProps: i
                    } = e, a = X();
                    return (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)(S.ib, {
                            type: "kinematicPosition",
                            colliders: "ball",
                            includeInvisible: !0,
                            ...n,
                            restitution: .2,
                            friction: .8,
                            density: 4,
                            children: (0, r.jsx)("mesh", {
                                geometry: a.sphere.geometry,
                                ...o,
                                layers: e_,
                                visible: !1
                            })
                        }), (0, r.jsx)("mesh", {
                            geometry: a.sphere.geometry,
                            castShadow: !0,
                            receiveShadow: !0,
                            scale: [.99, .99, .99],
                            ...i,
                            children: t
                        })]
                    })
                }),
                eT = (0, L.memo)(e => {
                    let {
                        children: t,
                        rigidBodyProps: n,
                        physicsMeshProps: o,
                        visualMeshProps: i
                    } = e, a = X();
                    return (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)(S.ib, {
                            type: "kinematicPosition",
                            colliders: "hull",
                            includeInvisible: !0,
                            scale: [.99, .99, .99],
                            ...n,
                            restitution: .2,
                            friction: .8,
                            density: 4,
                            children: (0, r.jsx)("mesh", {
                                geometry: a["icosahedron-simple"].geometry,
                                ...o,
                                layers: e_,
                                visible: !1
                            })
                        }), (0, r.jsx)("mesh", {
                            geometry: a.icosahedron.geometry,
                            castShadow: !0,
                            receiveShadow: !0,
                            ...i,
                            children: t
                        })]
                    })
                }),
                eF = (0, L.memo)(e => {
                    let {
                        children: t,
                        rigidBodyProps: n,
                        physicsMeshProps: o,
                        visualMeshProps: i
                    } = e, a = X();
                    return (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)(S.ib, {
                            type: "kinematicPosition",
                            colliders: "hull",
                            includeInvisible: !0,
                            ...n,
                            restitution: .2,
                            friction: .8,
                            density: 7,
                            children: (0, r.jsx)("mesh", {
                                geometry: a["pyramid-simple"].geometry,
                                ...o,
                                layers: e_,
                                visible: !1
                            })
                        }), (0, r.jsx)("mesh", {
                            geometry: a.pyramid.geometry,
                            castShadow: !0,
                            receiveShadow: !0,
                            scale: [.99, .99, .99],
                            ...i,
                            children: t
                        })]
                    })
                }),
                eV = (0, L.memo)(e => {
                    let {
                        children: t,
                        rigidBodyProps: n,
                        physicsMeshProps: o,
                        visualMeshProps: i
                    } = e, a = X();
                    return (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)(S.ib, {
                            type: "kinematicPosition",
                            colliders: "hull",
                            includeInvisible: !0,
                            ...n,
                            restitution: .2,
                            friction: .8,
                            density: 8,
                            children: (0, r.jsx)("mesh", {
                                geometry: a["logo-simple"].geometry,
                                ...o,
                                layers: e_,
                                visible: !1
                            })
                        }), (0, r.jsx)("mesh", {
                            geometry: a.logo.geometry,
                            castShadow: !0,
                            receiveShadow: !0,
                            ...i,
                            children: t
                        })]
                    })
                }),
                eG = {
                    dynamic: 0,
                    kinematicPosition: 2
                },
                e_ = new D.Layers;
            e_.disableAll(), e_.enable(1);
            let eW = [eA, eA, eA, eA, eA, eA, eO, eT, eF, eV, eV],
                eJ = new D.PlaneGeometry(.96, .96),
                eU = new f.l;

            function eH(e) {
                let {
                    index: t,
                    shapeIndex: n,
                    x: i,
                    z: a,
                    floorRef: s,
                    buffer: l
                } = e, c = X(), {
                    color: u,
                    colorIntensityFactor: d,
                    product: f
                } = Y.HS[n], h = (0, $.iv)(), p = h(e => e.setPuzzleButtonCompleted), [v, g] = (0, L.useState)([]), x = (0, L.useRef)(null), y = (0, L.useMemo)(() => v.includes(n), [v]), b = (0, o.m)("/three-hero/".concat(f, ".png")), M = (0, L.useRef)(), k = (0, L.useRef)(null), P = (0, L.useRef)(null), I = (0, j.c)(0), z = (0, j.c)(4), E = h(e => 0 === n ? e.isProduct0Hover : 1 === n ? e.isProduct1Hover : 2 === n ? e.isProduct2Hover : 3 === n && e.isProduct3Hover);
                (0, C.W)(I, "change", e => {
                    k.current && (k.current.material.emissiveIntensity = e)
                }), (0, L.useEffect)(() => {
                    (0, w.j)(I, y ? 4 * d : 0, {
                        duration: .5,
                        ease: "easeInOut"
                    })
                }, [y]), (0, C.W)(z, "change", e => {
                    P.current && (P.current.material.emissiveIntensity = e)
                }), (0, L.useEffect)(() => {
                    (0, w.j)(z, y || E ? 12 * d : 4 * d, {
                        duration: .5,
                        ease: "easeInOut"
                    })
                }, [y, E]), (0, S.Ji)(x, s, [
                    [0, Y.Kr, 0],
                    [i, Y.ft, a], 0, Y.AN, Y.KU
                ]);
                let R = (0, L.useCallback)(e => {
                        var t, n;
                        let r = null === (n = e.rigidBodyObject) || void 0 === n ? void 0 : null === (t = n.userData) || void 0 === t ? void 0 : t.shapeIndex;
                        void 0 !== r && g(e => [...e, r])
                    }, []),
                    B = (0, L.useCallback)(e => {
                        var t, n;
                        let r = null === (n = e.rigidBodyObject) || void 0 === n ? void 0 : null === (t = n.userData) || void 0 === t ? void 0 : t.shapeIndex;
                        void 0 !== r && g(e => {
                            let t = e.indexOf(r);
                            return t < 0 ? e : [...e.slice(0, t), ...e.slice(t + 1)]
                        })
                    }, []);
                return (0, L.useEffect)(() => {
                    p(t, y)
                }, [p, y]), (0, S.MZ)((0, L.useCallback)(() => {
                    if (!x.current) return;
                    let e = x.current.translation();
                    e.y > -1.82 ? x.current.setTranslation({ ...e,
                        y: -1.82
                    }, !0) : e.y < -2 && x.current.setTranslation({ ...e,
                        y: -2
                    }, !0)
                }, [])), (0, m.C)(() => {
                    k.current && (M.current = k.current.material, k.current.material = eU)
                }, -3), (0, m.C)(() => {
                    k.current && M.current && (k.current.material = M.current)
                }, -1), (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsxs)(S.ib, {
                        ref: x,
                        ccd: !0,
                        position: [i, Y.ft, a],
                        canSleep: !1,
                        enabledTranslations: [!1, !0, !1],
                        enabledRotations: [!1, !1, !1],
                        children: [(0, r.jsxs)("mesh", {
                            ref: k,
                            position: [0, 1.65, 0],
                            geometry: c.button.geometry,
                            rotation: [0, 3 === n ? 0 : 2 === n ? -Math.PI / 2 : 1 === n ? 3 * Math.PI : -Math.PI / 2, 0],
                            children: [(0, r.jsx)(eL, {
                                color: "#444",
                                buffer: l.texture,
                                thickness: 1.1,
                                ior: 1.05,
                                anisotropicBlur: 1,
                                metalness: .05,
                                roughness: .95,
                                reflectivity: .1,
                                roughnessBlurFactor: .5,
                                clearcoat: .05,
                                clearcoatRoughness: .1,
                                emissive: u,
                                emissiveIntensity: 0,
                                emissiveMap: b
                            }), (0, r.jsx)("mesh", {
                                geometry: eJ,
                                rotation: [0 === n ? Math.PI / 2 : -Math.PI / 2, 0, 3 === n ? Math.PI / 2 : 2 === n ? Math.PI : 1 === n ? -Math.PI / 2 : -(2 * Math.PI)],
                                position: [0, .1, 0],
                                ref: P,
                                children: (0, r.jsx)("meshStandardMaterial", {
                                    color: "#000",
                                    emissive: u,
                                    side: 0 === n ? D.BackSide : void 0,
                                    emissiveIntensity: 4 * d,
                                    emissiveMap: b
                                })
                            })]
                        }), (0, r.jsx)(S.jc, {
                            args: [.5, Y.Ln / 2, .5],
                            restitution: .2,
                            friction: .8
                        })]
                    }), (0, r.jsx)(S.jc, {
                        position: [i, 0, a],
                        args: [.5, .05, .5],
                        sensor: !0,
                        onIntersectionEnter: R,
                        onIntersectionExit: B
                    })]
                })
            }

            function eK(e) {
                let {
                    buffer: t
                } = e, n = (0, L.useRef)(null);
                return (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)(S.ib, {
                        ref: n,
                        position: [0, 0, 0],
                        type: "fixed"
                    }), (0, r.jsx)(eH, {
                        index: 0,
                        shapeIndex: 0,
                        x: -(Y.CG + .5),
                        z: -(Y.CG + .5),
                        floorRef: n,
                        buffer: t
                    }), (0, r.jsx)(eH, {
                        index: 1,
                        shapeIndex: 1,
                        x: Y.CG + .5,
                        z: -(Y.CG + .5),
                        floorRef: n,
                        buffer: t
                    }), (0, r.jsx)(eH, {
                        index: 2,
                        shapeIndex: 2,
                        x: Y.CG + .5,
                        z: Y.CG + .5,
                        floorRef: n,
                        buffer: t
                    }), (0, r.jsx)(eH, {
                        index: 3,
                        shapeIndex: 3,
                        x: -(Y.CG + .5),
                        z: Y.CG + .5,
                        floorRef: n,
                        buffer: t
                    })]
                })
            }
            let eZ = new D.Vector3,
                eq = new D.PlaneGeometry(.8, .8);

            function eQ(e) {
                let {
                    index: t
                } = e, n = (0, $.iv)(), a = X(), {
                    color: s,
                    colorIntensityFactor: l,
                    product: c
                } = Y.HS[t], u = n(e => 0 === t ? e.isPuzzleButton0Completed : 1 === t ? e.isPuzzleButton1Completed : 2 === t ? e.isPuzzleButton2Completed : 3 === t && e.isPuzzleButton3Completed), d = n(e => 0 === t ? e.isProduct0Hover : 1 === t ? e.isProduct1Hover : 2 === t ? e.isProduct2Hover : 3 === t && e.isProduct3Hover), f = (0, o.m)("/three-hero/inner-cube.png"), m = (0, o.m)("/three-hero/".concat(c, "-inner.png")), h = (0, L.useRef)(null), p = (0, L.useRef)(null), v = (0, j.c)(3 * l), g = (0, j.c)(1 * l);
                return (0, C.W)(v, "change", e => {
                    h.current && (h.current.material.emissiveIntensity = e)
                }), (0, L.useEffect)(() => {
                    (0, w.j)(v, (u && d ? 20 : u || d ? 12 : 3) * l, {
                        duration: .24,
                        ease: "easeInOut"
                    })
                }, [u, d]), (0, C.W)(g, "change", e => {
                    p.current && (p.current.material.emissiveIntensity = e)
                }), (0, L.useEffect)(() => {
                    (0, w.j)(g, (u && d ? 8 : u || d ? 4 : 1) * l, {
                        duration: .24,
                        ease: "easeInOut"
                    })
                }, [u, d]), (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)("mesh", {
                        geometry: a.cube.geometry,
                        ref: h,
                        children: (0, r.jsx)("meshStandardMaterial", {
                            color: "#000",
                            alphaMap: f,
                            emissive: s,
                            emissiveIntensity: 3 * l,
                            transparent: !0,
                            side: D.BackSide
                        })
                    }), (0, r.jsx)(i.V, {
                        children: (0, r.jsx)("mesh", {
                            geometry: eq,
                            ref: p,
                            children: (0, r.jsx)("meshStandardMaterial", {
                                color: "#000",
                                alphaMap: m,
                                emissive: s,
                                emissiveIntensity: 1 * l,
                                transparent: !0,
                                opacity: .35
                            })
                        })
                    })]
                })
            }
            let eX = new f.l,
                eY = new D.Quaternion,
                e$ = new D.Euler,
                e0 = (0, L.memo)(e => {
                    var t;
                    let {
                        index: n,
                        onDragStart: o,
                        onDragEnd: i,
                        onHover: a,
                        buffer: s,
                        isActive: l
                    } = e, {
                        groundOffset: c,
                        wallsOffset: u,
                        product: d,
                        position: f,
                        rotation: h
                    } = Y.HS[n], p = eW[n], v = (0, L.useMemo)(() => (eY.set(h.w, h.x, h.y, h.z), e$.setFromQuaternion(eY), e$.clone()), [h.w, h.x, h.y, h.z]), g = (0, $.iv)(), x = (0, L.useMemo)(() => String(n), [n]), y = (0, q.NW)(), b = (0, m.A)(e => e.pointer), k = (0, m.A)(e => e.camera), P = (0, m.A)(e => e.setEvents), I = (0, L.useRef)(null), z = (0, L.useRef)(null), E = (0, L.useRef)(null), R = (0, L.useRef)(), D = (0, L.useRef)(), N = (0, L.useRef)(), O = (0, L.useRef)(null), T = (0, L.useRef)(), F = null !== (t = (0, q.y$)(e => {
                        var t;
                        return null === (t = e.shapes.get(x)) || void 0 === t ? void 0 : t.isDraggedBy
                    })) && void 0 !== t && t, V = (0, L.useMemo)(() => {
                        if (!1 === F) return null;
                        let e = y.getOthers().find(e => e.connectionId === F);
                        return e ? e.info.color : null
                    }, [F, y]), G = (0, j.c)("#fff"), _ = (0, j.c)(0);
                    (0, C.W)(G, "change", e => {
                        E.current && E.current.material.emissive.set(e)
                    }), (0, C.W)(_, "change", e => {
                        E.current && (E.current.material.emissiveIntensity = e)
                    }), (0, L.useEffect)(() => {
                        (0, w.j)(G, null != V ? V : "#fff", {
                            duration: .12,
                            ease: "easeInOut"
                        })
                    }, [V]), (0, L.useEffect)(() => {
                        (0, w.j)(_, V ? .1 : l ? .01 : 0, {
                            duration: .12,
                            ease: "easeInOut"
                        })
                    }, [V, l]);
                    let W = (0, L.useCallback)(() => {
                            if (!I.current) return;
                            let e = g.getState().getShapeLiveObject(x);
                            if (!e) return;
                            let t = e.get("position"),
                                n = e.get("rotation"),
                                r = e.get("linearVelocity"),
                                o = e.get("angularVelocity");
                            I.current.wakeUp(), I.current.setTranslation(t, !0), I.current.setRotation(n, !0), I.current.setLinvel(r, !0), I.current.setAngvel(o, !0)
                        }, []),
                        J = (0, L.useCallback)(() => {
                            if (!I.current) return;
                            let e = g.getState().getShapeLiveObject(x);
                            e && (e.set("position", ep(I.current.translation())), e.set("rotation", ev(I.current.rotation())), e.set("linearVelocity", ep(I.current.linvel())), e.set("angularVelocity", ep(I.current.angvel())))
                        }, []);
                    (0, L.useEffect)(() => {
                        let e = g.getState().getShapeLiveObject(x);
                        if (e) return W(), y.subscribe(e, () => {
                            let t = g.getState().connectionId,
                                n = g.getState().isAuthority,
                                r = e.get("isLockedBy"),
                                o = r === t;
                            (!1 === r || o) && (n || o) || W()
                        })
                    }, [y]);
                    let U = (0, L.useCallback)(e => {
                            if (!I.current || !z.current || !E.current || !e.target) return;
                            let t = g.getState().connectionId;
                            if (null === t) return;
                            let r = g.getState().getShapeLiveObject(x);
                            if (!r) return;
                            let i = r.get("isLockedBy");
                            if (!1 !== i && i !== t) return;
                            let a = eZ.copy(e.point).sub(z.current.parent.position);
                            R.current = a, N.current = e.distance, D.current = eh(e);
                            let s = g.getState().cameraControls;
                            s && (s.smoothTime = 0, s.azimuthRotateSpeed = 0), r.set("isDraggedBy", t), r.set("isLockedBy", t), J(), o(n), O.current = null, I.current.wakeUp(), e.target.setPointerCapture(e.pointerId), P({
                                filter: void 0
                            })
                        }, [o, P]),
                        H = (0, L.useCallback)(e => {
                            let t = g.getState().connectionId;
                            if (null === t || g.getState().currentDragging3dPointer) return;
                            let r = !1,
                                o = g.getState().getShapeLiveObject(x);
                            if (o) {
                                let e = o.get("isLockedBy");
                                r = !!(e && e !== t)
                            }
                            g.setState({
                                currentShapePointer: {
                                    position: eu(e.point, k),
                                    rotation: eh(e),
                                    shapeId: x,
                                    isLockedByOther: r
                                }
                            }), a(n)
                        }, [k]),
                        K = (0, L.useCallback)(e => {
                            if (!I.current || !e.target) return;
                            let t = g.getState().connectionId;
                            if (null === t) return;
                            e.target.releasePointerCapture(e.pointerId), P({
                                filter: eg
                            });
                            let r = g.getState().cameraControls;
                            r && (r.smoothTime = Y.nH, r.azimuthRotateSpeed = Y.BL);
                            let o = g.getState().getShapeLiveObject(x);
                            if (!o || o.get("isDraggedBy") !== t) return;
                            let a = g.getState().currentDragging3dPointer;
                            a && g.setState({
                                currentDragging3dPointer: void 0,
                                currentShapePointer: { ...a,
                                    shapeId: x,
                                    isLockedByOther: !1
                                }
                            }), o.set("isDraggedBy", !1), J(), O.current = Y.Cb, i(n), g.setState({
                                bodyCursor: null
                            }), ex()
                        }, [i]),
                        Z = (0, L.useCallback)(() => {
                            let e = g.getState().connectionId;
                            if (null === e) return;
                            let t = g.getState().getShapeLiveObject(x);
                            t && t.get("isLockedBy") === e && null !== O.current && (O.current -= 1, O.current <= 0 && (t.set("isLockedBy", !1), O.current = null))
                        }, []);
                    return (0, S.DL)((0, L.useCallback)(() => {
                        if (!I.current) return;
                        let e = g.getState().connectionId;
                        if (null === e) return;
                        let t = g.getState().getShapeLiveObject(x);
                        if (!t) return;
                        let n = t.get("isDraggedBy");
                        !1 !== n ? I.current.setBodyType(eG.kinematicPosition, !1) : I.current.setBodyType(eG.dynamic, !1);
                        let r = g.getState().isAuthority,
                            o = g.getState().shouldApplyRemainingExplosionsIfAuthority;
                        if (r && o > 0) {
                            if (!1 === n) {
                                t.set("isLockedBy", !1);
                                let e = I.current.translation(),
                                    n = (0, A.u)(e.x, -Y.MJ + u, Y.MJ - u),
                                    r = (0, A.u)(e.z, -Y.MJ + u, Y.MJ - u),
                                    o = (0, A.u)(e.y, c, Y.DG);
                                I.current.setTranslation({
                                    x: n,
                                    y: o,
                                    z: r
                                }, !0);
                                let i = function(e) {
                                    et.copy(e);
                                    let t = et.distanceToSquared(ee);
                                    return en.copy(et).sub(ee).normalize().multiplyScalar((0, M.v)(t, [2, 12], [20, -20])), en.setY((0, M.v)(t, [0, 20], [16, 24])), en.clone()
                                }(I.current.translation());
                                I.current.wakeUp(), I.current.applyImpulse(i, !0)
                            }
                            g.setState({
                                shouldApplyRemainingExplosionsIfAuthority: o - 1
                            })
                        }
                        if (n !== e || !R.current || !D.current) return;
                        let [i] = el(b, k, N.current), a = i.sub(R.current);
                        a.y <= c && (a.y = c), a.z <= -Y.MJ + u ? a.z = -Y.MJ + u : a.z >= Y.MJ - u && (a.z = Y.MJ - u), a.x <= -Y.MJ + u ? a.x = -Y.MJ + u : a.x >= Y.MJ - u && (a.x = Y.MJ - u), I.current.setNextKinematicTranslation(a), J();
                        let s = eu(a.add(R.current), k),
                            l = D.current.clone();
                        g.setState({
                            currentDragging3dPointer: {
                                position: s,
                                rotation: l
                            }
                        })
                    }, [k, b])), (0, S.MZ)((0, L.useCallback)(() => {
                        if (!I.current) return;
                        let e = g.getState().connectionId;
                        if (null === e) return;
                        let t = g.getState().getShapeLiveObject(x);
                        if (!t) return;
                        let n = t.get("isLockedBy"),
                            r = n === e;
                        r && null !== O.current && (O.current -= 1, O.current <= 0 && (t.set("isLockedBy", !1), O.current = null));
                        let o = g.getState().isAuthority;
                        (r || o && !(!1 !== n)) && J()
                    }, [])), (0, m.C)((0, L.useCallback)((e, t) => {
                        if (!z.current || !E.current) return;
                        let n = g.getState().connectionId;
                        if (null === n) return;
                        let r = !1,
                            o = g.getState().getShapeLiveObject(x);
                        if (o) {
                            let e = g.getState().isAuthority,
                                t = o.get("isLockedBy");
                            r = t === n || e && !(!1 !== t)
                        }
                        let i = r ? Y.$6 : Y.Xh;
                        (0, B.G0)(E.current.position, z.current.parent.position, i, t), (0, B.OZ)(E.current.quaternion, z.current.parent.quaternion, i, t)
                    }, [])), (0, L.useEffect)(() => () => {
                        let e = g.getState().connectionId;
                        if (null === e) return;
                        let t = g.getState().getShapeLiveObject(x);
                        if (t) {
                            let n = t.get("isDraggedBy") === e,
                                r = t.get("isLockedBy") === e;
                            n && t.set("isDraggedBy", !1), r && t.set("isLockedBy", !1)
                        }
                    }, []), (0, m.C)(() => {
                        E.current && (T.current = E.current.material, E.current.material = eX)
                    }, -3), (0, m.C)(() => {
                        E.current && T.current && (E.current.material = T.current)
                    }, -1), (0, r.jsxs)(p, {
                        rigidBodyProps: {
                            ref: I,
                            onSleep: Z,
                            userData: {
                                shapeIndex: n
                            },
                            position: [f.x, f.y, f.z],
                            rotation: v
                        },
                        physicsMeshProps: {
                            ref: z,
                            onPointerDown: U,
                            onPointerUp: K,
                            onPointerMove: H
                        },
                        visualMeshProps: {
                            ref: E
                        },
                        children: [(0, r.jsx)(eL, {
                            color: "#555",
                            emissive: "#fff",
                            emissiveIntensity: 0,
                            buffer: s.texture,
                            thickness: 2,
                            ior: 1.5,
                            anisotropicBlur: 1.2,
                            metalness: .1,
                            roughness: 1,
                            reflectivity: .1,
                            clearcoat: .1,
                            clearcoatRoughness: .1,
                            roughnessBlurFactor: .35,
                            chromaticAberration: .15
                        }), d ? (0, r.jsx)(eQ, {
                            index: n
                        }) : null]
                    })
                }),
                e1 = (0, L.memo)(() => (0, r.jsxs)("group", {
                    children: [(0, r.jsx)(S.jc, {
                        args: [Y.CG, Y.f, Y.f],
                        position: [0, -Y.f, 0],
                        restitution: .2,
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        args: [Y.f, Y.f, Y.CG],
                        position: [0, -Y.f, 0],
                        restitution: .2,
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        args: [Y.f, Y.f, Y.f],
                        position: [Y.f + Y.CG + 1, -Y.f, 0],
                        restitution: .2,
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        args: [Y.f, Y.f, Y.f],
                        position: [-(Y.f + Y.CG + 1), -Y.f, 0],
                        restitution: .2,
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        args: [Y.f, Y.f, Y.f],
                        position: [0, -Y.f, Y.f + Y.CG + 1],
                        restitution: .2,
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        args: [Y.f, Y.f, Y.f],
                        position: [0, -Y.f, -(Y.f + Y.CG + 1)],
                        restitution: .2,
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        position: [0, -Y.f - Y.Ln, 0],
                        args: [2 * Y.f, Y.f, 2 * Y.f],
                        restitution: .2,
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        args: [2 * Y.f, Y.f, 2 * Y.f],
                        position: [0, Y.f / 2 + 2 * Y.DG, 0],
                        restitution: .2,
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        args: [Y.f, Y.f, Y.f],
                        position: [0, Y.MJ / 2, Y.f + Y.MJ],
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        args: [Y.f, Y.f, Y.f],
                        position: [0, Y.MJ / 2, -(Y.f + Y.MJ)],
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        args: [Y.f, Y.f, Y.f],
                        position: [-(Y.f + Y.MJ), Y.MJ / 2, 0],
                        friction: .8
                    }), (0, r.jsx)(S.jc, {
                        args: [Y.f, Y.f, Y.f],
                        position: [Y.f + Y.MJ, Y.MJ / 2, 0],
                        friction: .8
                    })]
                })),
                e3 = (0, L.memo)(e => {
                    let {
                        buffer: t
                    } = e, n = (0, $.iv)(), o = (0, m.A)(e => e.camera), i = (0, m.A)(e => e.pointer), a = (0, q.YT)(), s = (0, q.pw)(), [l, c] = (0, L.useState)(!1), u = n(e => e.isDragging), d = !1 !== u ? u : l, f = (0, L.useCallback)(e => {
                        n.setState({
                            currentShapePointer: void 0
                        }), n.setState({
                            last3dPointer: {
                                position: eu(e.point, o),
                                rotation: eh(e)
                            }
                        }), c(!1)
                    }, [o]), h = (0, L.useCallback)(e => {
                        c(e)
                    }, []), p = (0, L.useCallback)(e => {
                        n.setState({
                            bodyCursor: "grabbing"
                        }), n.setState({
                            isDragging: e
                        })
                    }, []), v = (0, L.useCallback)(() => {
                        n.setState({
                            isDragging: !1
                        }), c(!1)
                    }, []);
                    return (0, L.useEffect)(() => {
                        function e(e) {
                            e.preventDefault()
                        }
                        if (!1 !== u) return window.addEventListener("wheel", e, {
                            passive: !1
                        }), () => {
                            window.removeEventListener("wheel", e)
                        }
                    }, [u]), (0, L.useEffect)(() => {
                        let e = null,
                            t = n.subscribe(t => {
                                var r, a;
                                if ((!n.getState().isCameraMoving || n.getState().isDragging) && ((null === (r = t.pointer) || void 0 === r ? void 0 : r.x) !== (null == e ? void 0 : e.x) || (null === (a = t.pointer) || void 0 === a ? void 0 : a.y) !== (null == e ? void 0 : e.y))) {
                                    let r, a;
                                    if (e = t.pointer, !n.getState().isActive || !t.pointer) {
                                        n.setState({
                                            bodyCursor: null
                                        }), ex(), s({
                                            cursor: null
                                        });
                                        return
                                    }
                                    let l = n.getState().currentDragging3dPointer,
                                        c = n.getState().currentShapePointer,
                                        u = n.getState().last3dPointer;
                                    if (l) n.setState({
                                        bodyCursor: "grabbing"
                                    }), r = l.position, a = l.rotation;
                                    else if (c) n.setState({
                                        bodyCursor: c.isLockedByOther ? "not-allowed" : "grab"
                                    }), r = c.position, a = c.rotation;
                                    else {
                                        n.setState({
                                            bodyCursor: "auto"
                                        });
                                        let e = u ? o.position.distanceTo(u.position) : o.position.length(),
                                            [t, s] = el(i, o, e);
                                        r = t, a = function(e, t) {
                                            let n = t.clone().add(e);
                                            return ed.lookAt(n, e, em), ef.setFromRotationMatrix(ed), ef.clone()
                                        }(t, s)
                                    }
                                    if (!r || !a) return;
                                    s({
                                        cursor: {
                                            position: ep(r),
                                            rotation: ev(a)
                                        }
                                    })
                                }
                            });
                        return () => {
                            t(), ex()
                        }
                    }, []), (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)(eC, {}), a.map(e => (0, r.jsx)(eM, {
                            connectionId: e
                        }, e)), (0, r.jsx)("group", {
                            onPointerLeave: f,
                            layers: e_,
                            children: eW.map((e, n) => (0, r.jsx)(e0, {
                                index: n,
                                onHover: h,
                                onDragStart: p,
                                onDragEnd: v,
                                buffer: t,
                                isActive: d === n
                            }, n))
                        })]
                    })
                }),
                e2 = (0, L.memo)(e => {
                    let {
                        type: t
                    } = e, n = (0, $.iv)(), o = n(e => e.isStorageReady), i = n(e => e.isAuthority), c = n(e => e.isPuzzleButton0Completed && e.isPuzzleButton1Completed && e.isPuzzleButton2Completed && e.isPuzzleButton3Completed), u = (0, m.A)(e => e.size), d = (0, L.useMemo)(() => (0, M.v)(u.width, [500, 2e3], [2, 6]), [u.width]), f = (0, a.R)(u.width / d, u.height / d), [h, p] = (0, L.useState)(0), v = (0, L.useRef)(null);
                    return (0, m.C)(e => {
                        e.gl.setRenderTarget(f), e.gl.render(e.scene, e.camera), e.gl.setRenderTarget(null)
                    }, -2), (0, L.useEffect)(() => {
                        let e = !1,
                            t = n.subscribe(t => {
                                t.isKonamiCodeActive !== e && (e = t.isKonamiCodeActive, p(e => e + 1))
                            });
                        return () => {
                            t()
                        }
                    }, []), (0, L.useEffect)(() => (null !== v.current && window.clearTimeout(v.current), c ? v.current = window.setTimeout(() => {
                        p(e => e + 1), v.current = window.setTimeout(() => {
                            n.getState().isAuthority && n.setState({
                                shouldApplyRemainingExplosionsIfAuthority: Y.HS.length
                            })
                        }, Y.kr)
                    }, Y.X3) : n.setState({
                        shouldApplyRemainingExplosionsIfAuthority: 0
                    }), () => {
                        null !== v.current && window.clearTimeout(v.current), n.setState({
                            shouldApplyRemainingExplosionsIfAuthority: 0
                        })
                    }), [c, i]), (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)(K, {
                            explosionKey: h
                        }), (0, r.jsx)(s.qA, {
                            resolution: 256,
                            children: (0, r.jsxs)("group", {
                                rotation: [-Math.PI / 3, 0, 1],
                                children: [(0, r.jsx)(l.D, {
                                    form: "rect",
                                    "rotation-x": Math.PI / 2,
                                    position: [0, 5, -9],
                                    scale: 2
                                }), (0, r.jsx)(l.D, {
                                    form: "rect",
                                    "rotation-y": Math.PI / 2,
                                    position: [-5, 1, -1],
                                    scale: 2
                                }), (0, r.jsx)(l.D, {
                                    form: "rect",
                                    "rotation-y": Math.PI / 2,
                                    position: [-5, -1, -1],
                                    scale: 2
                                }), (0, r.jsx)(l.D, {
                                    form: "rect",
                                    "rotation-y": -Math.PI / 2,
                                    position: [10, 1, 0],
                                    scale: 8
                                })]
                            })
                        }), (0, r.jsx)("directionalLight", {
                            position: [0, 20, -12],
                            intensity: 2
                        }), (0, r.jsx)("directionalLight", {
                            position: [-12, 20, 12],
                            intensity: 2
                        }), (0, r.jsx)("directionalLight", {
                            position: [12, 20, -12],
                            intensity: 2
                        }), (0, r.jsx)(L.Suspense, {
                            fallback: null,
                            children: (0, r.jsx)(eN, {
                                type: t
                            })
                        }), (0, r.jsx)("spotLight", {
                            intensity: 1500,
                            position: [0, 20, 0],
                            color: "#aaa",
                            distance: 25,
                            decay: .8,
                            angle: .35,
                            penumbra: 1,
                            castShadow: !0
                        }), (0, r.jsx)(eI, {}), (0, r.jsxs)(S.wI, {
                            colliders: !1,
                            timeStep: Y.Mc,
                            paused: !o,
                            children: [(0, r.jsx)(L.Suspense, {
                                fallback: null,
                                children: (0, r.jsx)(e3, {
                                    buffer: f
                                })
                            }), (0, r.jsx)(eK, {
                                buffer: f
                            }), (0, r.jsx)(e1, {})]
                        })]
                    })
                }),
                e5 = e => ({ ...(0, h.U3)(e),
                    filter: eg
                });

            function e4() {
                let e = (0, $.iv)(),
                    t = (0, q.pw)();
                return (0, L.useEffect)(() => {
                    function n(n) {
                        let r = e.getState().cursorChat;
                        switch (n.key) {
                            case "/":
                                r || (n.preventDefault(), e.setState({
                                    cursorChat: {
                                        previousChat: null,
                                        chat: null
                                    },
                                    bodyCursor: "auto"
                                }));
                                break;
                            case "Escape":
                                if (r) {
                                    n.preventDefault(), t({
                                        chat: ""
                                    });
                                    let r = e.getState().cursorChatInputRef;
                                    r.current && r.current.blur(), e.setState({
                                        cursorChat: null
                                    })
                                }
                        }
                    }
                    return document.addEventListener("keydown", n), () => {
                        document.removeEventListener("keydown", n), e.setState({
                            cursorChat: null
                        })
                    }
                }, []), null
            }
            let e9 = (0, L.memo)(() => {
                    let e = (0, $.iv)(),
                        t = e(e => null !== e.pointer),
                        n = (0, q.pw)(),
                        o = (0, q.Sk)(e => e.info.color),
                        i = (0, L.useRef)(null),
                        a = (0, L.useRef)(null),
                        s = (0, L.useRef)(null),
                        l = e(e => null !== e.cursorChat),
                        c = e(e => {
                            var t, n;
                            return null !== (n = null === (t = e.cursorChat) || void 0 === t ? void 0 : t.chat) && void 0 !== n ? n : null
                        }),
                        u = e(e => {
                            var t, n;
                            return null !== (n = null === (t = e.cursorChat) || void 0 === t ? void 0 : t.previousChat) && void 0 !== n ? n : null
                        });
                    (0, L.useEffect)(() => {
                        if (l) {
                            var t;
                            null === (t = e.getState().cursorChatInputRef.current) || void 0 === t || t.focus({
                                preventScroll: !0
                            })
                        }
                    }, [l]), (0, L.useLayoutEffect)(() => {
                        let t = null,
                            n = e.subscribe(e => {
                                var n, r;
                                null !== e.cursorChat && ((null === (n = e.pointer) || void 0 === n ? void 0 : n.x) !== (null == t ? void 0 : t.x) || (null === (r = e.pointer) || void 0 === r ? void 0 : r.y) !== (null == t ? void 0 : t.y)) && (t = e.pointer, z.ZP.update(() => {
                                    a.current && (e.pointer ? a.current.style.transform = "translate3d(".concat(e.pointer.x, "px, ").concat(e.pointer.y, "px, 0)") : a.current.style.transform = "translate3d(-9999px, -9999px, 0)")
                                }))
                            });
                        return () => {
                            n()
                        }
                    }, []);
                    let d = (0, L.useCallback)(() => {
                            var t;
                            null !== i.current && window.clearTimeout(i.current), null === (t = s.current) || void 0 === t || t.removeAttribute("data-fade"), i.current = window.setTimeout(() => {
                                var t;
                                null === (t = s.current) || void 0 === t || t.setAttribute("data-fade", ""), i.current = window.setTimeout(() => {
                                    e.setState({
                                        cursorChat: null
                                    }), n({
                                        chat: ""
                                    })
                                }, Y.wB)
                            }, Y.Ir)
                        }, []),
                        f = (0, L.useCallback)(t => {
                            if (null !== e.getState().cursorChat && "Enter" === t.key) {
                                var r;
                                t.preventDefault(), e.setState(e => {
                                    var t, n;
                                    return {
                                        cursorChat: {
                                            previousChat: null !== (n = null === (t = e.cursorChat) || void 0 === t ? void 0 : t.chat) && void 0 !== n ? n : null,
                                            chat: null
                                        }
                                    }
                                }), (null === (r = e.getState().cursorChat) || void 0 === r ? void 0 : r.previousChat) || n({
                                    chat: ""
                                })
                            }
                        }, []),
                        m = (0, L.useCallback)(R()(t => {
                            e.getState().cursorChat && (0, T.u)(t) && (n({
                                chat: ""
                            }), e.setState({
                                cursorChat: {
                                    previousChat: null,
                                    chat: ""
                                }
                            }))
                        }, 500, {
                            leading: !1,
                            trailing: !0
                        }), []),
                        h = (0, L.useCallback)(t => {
                            let r = t.target.value;
                            r.length > Y.kf && (r = r.slice(1)), n({
                                chat: r
                            }), e.setState({
                                cursorChat: {
                                    previousChat: u,
                                    chat: r
                                }
                            }), m(r), d()
                        }, []),
                        p = (0, L.useCallback)(e => {
                            e.preventDefault(), e.target.focus({
                                preventScroll: !0
                            }), d()
                        }, []);
                    (0, L.useEffect)(() => () => {
                        null !== i.current && window.clearTimeout(i.current)
                    }, []);
                    let v = (0, L.useCallback)(t => {
                        t && e.setState({
                            cursorChatInputRef: {
                                current: t
                            }
                        })
                    }, []);
                    return (0, r.jsx)("div", {
                        className: "pointer-events-none absolute left-0 top-0 z-10 h-full w-full",
                        children: t ? (0, r.jsxs)("div", {
                            ref: a,
                            className: ej().cursorChatPosition,
                            children: [(0, r.jsx)(e4, {}), l ? (0, r.jsx)("div", {
                                ref: s,
                                style: {
                                    animationDuration: "".concat(Y.wB, "ms"),
                                    background: o
                                },
                                className: ej().cursorChatBubble,
                                children: (0, r.jsxs)("div", {
                                    className: "relative",
                                    children: [(0, r.jsxs)("div", {
                                        className: "pointer-events-none whitespace-nowrap opacity-0",
                                        "aria-hidden": !0,
                                        children: [c || Y.$Q, "\xa0"]
                                    }), (0, r.jsx)("input", {
                                        className: "no-focus-ring absolute inset-0 w-full border-none bg-transparent text-white placeholder-white placeholder-opacity-60",
                                        ref: v,
                                        spellCheck: !1,
                                        onChange: h,
                                        onKeyDown: f,
                                        onFocus: p,
                                        placeholder: Y.$Q,
                                        value: c || "",
                                        maxLength: Y.kf + 1
                                    })]
                                })
                            }) : null]
                        }) : null
                    })
                }),
                e8 = (0, L.memo)(() => {
                    let e = (0, $.iv)(),
                        t = e(e => e.isActive),
                        n = e(e => e.cursorsContainerRef),
                        o = e(e => e.usersInOtherLobbies),
                        i = (0, q.YT)(),
                        a = (0, L.useMemo)(() => i.length + 1, [i]),
                        s = function(e) {
                            let t = (0, k.q)(e, {
                                    stiffness: 500,
                                    damping: 50
                                }),
                                n = (0, P.H)(() => Math.round(t.get()).toLocaleString("en-US", {
                                    maximumFractionDigits: 2
                                }));
                            return (0, L.useEffect)(() => {
                                t.set(e)
                            }, [e]), n
                        }((0, L.useMemo)(() => a + o, [a, o]));
                    return (0, r.jsxs)("div", {
                        className: "pointer-events-none absolute left-0 top-0 h-full w-full",
                        children: [(0, r.jsx)("div", {
                            className: ej().cursorsContainer,
                            ref: n
                        }), (0, r.jsx)("div", {
                            className: ej().canvasGradientOverlay
                        }), (0, r.jsxs)("div", {
                            className: "pointer-events-none absolute bottom-[4%] z-20 flex w-full items-center justify-center font-mono text-xs sm:bottom-[6%] lg:bottom-[8%]",
                            children: [(0, r.jsx)("div", {
                                className: "flex h-8 w-full items-center justify-center sm:w-[100px]",
                                children: (0, r.jsxs)("div", {
                                    className: "flex items-center gap-2.5",
                                    children: [(0, r.jsx)("div", {
                                        className: ej().countPing
                                    }), (0, r.jsx)(I.E.span, {
                                        children: s
                                    })]
                                })
                            }), (0, r.jsx)("div", {
                                className: "hidden h-8 items-center justify-center sm:flex sm:w-[100px]",
                                children: (0, r.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, r.jsx)("kbd", {
                                        className: "pointer-events-none flex aspect-square h-5 w-5 items-center justify-center rounded border border-marketing-divider bg-marketing-surface-base-bold px-1.5 text-xs font-medium text-marketing-subtle",
                                        children: (0, r.jsx)("abbr", {
                                            title: "Splash",
                                            className: "font-sans no-underline",
                                            children: "/"
                                        })
                                    }), (0, r.jsx)("span", {
                                        children: "Chat"
                                    })]
                                })
                            })]
                        }), t && (0, r.jsx)(e9, {}), (0, r.jsx)("div", {
                            className: ej().canvasGradientSmallerOverlay
                        })]
                    })
                });

            function e6() {
                let e = (0, $.iv)(),
                    t = e(e => e.cameraControls),
                    n = (0, m.A)(e => e.setEvents);
                return (0, L.useEffect)(() => {
                    if (!t) return;
                    let r = () => {
                            e.setState({
                                isCameraMoving: !0
                            }), n({
                                enabled: !1
                            })
                        },
                        o = () => {
                            e.setState({
                                isCameraMoving: !1
                            }), n({
                                enabled: !0
                            })
                        };
                    return t.addEventListener("controlstart", r), t.addEventListener("controlend", o), () => {
                        t.removeEventListener("controlstart", r), t.removeEventListener("controlend", o)
                    }
                }, [t]), null
            }

            function e7(e) {
                let {
                    type: t
                } = e, n = (0, $.iv)(), o = (0, q.pw)(), i = (0, q.Sk)(e => e.connectionId), a = (0, q.NW)(), s = (0, q.YT)(), l = (0, q.$z)(), f = n(e => e.isStorageReady), m = n(e => e.isLoaded), S = n(e => e.tier), [j, C] = (0, L.useState)(!0);
                (0, L.useEffect)(() => {
                    C(!1)
                }, []), (0, L.useLayoutEffect)(() => {
                    n.setState({
                        connectionId: i
                    })
                }, [i]), (0, L.useLayoutEffect)(() => {
                    n.setState({
                        others: s
                    })
                }, [s]), (0, L.useLayoutEffect)(() => {
                    n.setState({
                        isAuthority: 0 === s.length || Math.min(...s, i) === i
                    })
                }, [i, s]), (0, L.useEffect)(() => {
                    if ("connected" === l) a.getStorage().then(e => {
                        let {
                            root: t
                        } = e;
                        n.setState({
                            storage: t
                        });
                        let r = t.get("shapes"),
                            o = n.getState().others;
                        for (let e of r.values()) {
                            let t = e.get("isDraggedBy"),
                                n = e.get("isLockedBy"),
                                r = e.get("position");
                            r.x = (0, A.u)(r.x, -Y.MJ + 2, Y.MJ - 2), r.z = (0, A.u)(r.z, -Y.MJ + 2, Y.MJ - 2), r.y = (0, A.u)(r.y, -1, Y.DG), e.set("position", r), !1 === t || o.includes(t) || e.set("isDraggedBy", !1), !1 === n || o.includes(n) || e.set("isLockedBy", !1)
                        }
                        "connected" === a.getStatus() && n.setState({
                            isStorageReady: !0
                        })
                    });
                    else {
                        n.setState({
                            isStorageReady: !1
                        }), o({
                            cursor: null
                        });
                        let e = n.getState().storage;
                        if (!e) return;
                        let t = n.getState().connectionId;
                        for (let n of e.get("shapes").values()) {
                            let e = n.get("isDraggedBy"),
                                r = n.get("isLockedBy");
                            e === t && n.set("isDraggedBy", !1), r === t && n.set("isLockedBy", !1)
                        }
                    }
                    return () => {
                        n.setState({
                            isStorageReady: !1
                        })
                    }
                }, [a, l]);
                let w = (0, L.useRef)(null),
                    M = (0, L.useCallback)(e => {
                        if (!w.current) return;
                        let {
                            canvasContainerPosition: t,
                            scrollTop: r
                        } = n.getState();
                        if (!t) return;
                        let o = e.clientX - t.x,
                            i = e.clientY - t.y + r;
                        n.setState({
                            pointer: {
                                x: o,
                                y: i
                            }
                        })
                    }, []),
                    k = (0, L.useCallback)(() => {
                        n.setState({
                            pointer: null
                        }), o({
                            cursor: null
                        })
                    }, [o]),
                    P = (0, L.useCallback)(() => {
                        n.setState({
                            bodyCursor: null
                        })
                    }, [o]),
                    I = (0, L.useCallback)(() => {
                        o({
                            chat: ""
                        }), n.setState({
                            cursorChat: null
                        })
                    }, [o]),
                    z = (0, L.useCallback)(e => {
                        e && e.setFocalOffset(0, Y.VU, 0), n.setState({
                            cameraControls: e
                        })
                    }, []);
                return (0, r.jsxs)("div", {
                    className: ej().canvasContainer,
                    ref: w,
                    style: {
                        background: Y.qg,
                        opacity: m && !j ? 1 : 0,
                        pointerEvents: m && !j ? "auto" : "none"
                    },
                    children: [(0, r.jsxs)(h.Xz, {
                        onPointerEnter: M,
                        onPointerMove: M,
                        onPointerLeave: k,
                        onPointerUp: P,
                        onPointerDown: I,
                        camera: {
                            position: [1, 0, 1],
                            fov: 10,
                            near: 10,
                            far: 200
                        },
                        gl: {
                            antialias: !1,
                            alpha: !1
                        },
                        dpr: [Y.Pi, Y.yP],
                        shadows: !0,
                        events: e5,
                        raycaster: {
                            layers: e_
                        },
                        frameloop: f ? "always" : "never",
                        className: ej().canvas,
                        flat: !0,
                        children: [(0, r.jsx)(L.Suspense, {
                            fallback: null,
                            children: (0, r.jsx)(e2, {
                                type: t
                            })
                        }), (0, r.jsx)("color", {
                            attach: "background",
                            args: [Y.qg]
                        }), S >= 2 ? (0, r.jsx)(c.A, {
                            focus: 1
                        }) : null, (0, r.jsx)(u.B, {
                            distance: Y.uf,
                            smoothTime: Y.nH,
                            makeDefault: !0,
                            ref: z,
                            polarAngle: Y.VW,
                            azimuthRotateSpeed: Y.BL,
                            mouseButtons: {
                                left: b.Z.ACTION.ROTATE,
                                middle: b.Z.ACTION.NONE,
                                right: b.Z.ACTION.NONE,
                                wheel: b.Z.ACTION.NONE
                            },
                            touches: {
                                one: b.Z.ACTION.TOUCH_ROTATE,
                                two: b.Z.ACTION.NONE,
                                three: b.Z.ACTION.NONE
                            },
                            polarRotateSpeed: 0
                        }), (0, r.jsx)(e6, {}), (0, r.jsx)(L.Suspense, {
                            children: (0, r.jsx)(eR, {
                                minimum: 15
                            })
                        }), (0, r.jsxs)(p.x, {
                            multisampling: 0,
                            children: [(0, r.jsx)(v.g, {}), (0, r.jsx)(g.l, {}), (0, r.jsx)(x.d, {
                                mipmapBlur: !0,
                                radius: .8,
                                intensity: 2,
                                luminanceThreshold: .02,
                                luminanceSmoothing: .1
                            }), (0, r.jsx)(y.c, {
                                opacity: .04
                            })]
                        }), (0, r.jsx)(d.q, {
                            all: !0
                        })]
                    }), (0, r.jsx)(e8, {})]
                })
            }

            function te(e) {
                let {
                    type: t
                } = e, n = (0, $.iv)(), o = (0, q.NW)(), i = (0, L.useRef)(null), a = (0, O.R)(i), s = function() {
                    let [e, t] = (0, L.useState)(!1);
                    return (0, L.useEffect)(() => {
                        function e() {
                            t("hidden" === document.visibilityState)
                        }
                        return document.addEventListener("visibilitychange", e), () => {
                            document.removeEventListener("visibilitychange", e)
                        }
                    }, []), e
                }(), l = a && !s, c = (0, L.useRef)(null);
                return (0, L.useLayoutEffect)(() => {
                    let e = o.getStatus();
                    n.setState({
                        isActive: l
                    }), l ? (null !== c.current && (window.clearTimeout(c.current), c.current = null), "connected" !== e && o.connect()) : "disconnected" !== e && (c.current = window.setTimeout(() => {
                        o.disconnect()
                    }, Y.WW))
                }, [l, o]), (0, L.useEffect)(() => () => {
                    null !== c.current && (window.clearTimeout(c.current), c.current = null)
                }, []), (0, L.useEffect)(() => {
                    let e = null,
                        t = n.subscribe(t => {
                            if (t.bodyCursor !== e && (e = t.bodyCursor, !t.cameraControls || t.cameraControls.currentAction === b.Z.ACTION.NONE)) {
                                if (t.bodyCursor) {
                                    var n;
                                    n = t.bodyCursor, z.ZP.update(() => {
                                        document.body.style.cursor = n
                                    })
                                } else ex()
                            }
                        });
                    return () => {
                        t(), ex()
                    }
                }, []), (0, r.jsx)("div", {
                    className: "absolute left-0 top-0 z-10 h-full w-full overflow-hidden",
                    ref: i,
                    children: (0, r.jsx)(N.S, {
                        children: (0, r.jsx)(L.Suspense, {
                            fallback: null,
                            children: (0, r.jsx)(e7, {
                                type: t
                            })
                        })
                    })
                })
            }
            var tt = function(e) {
                let {
                    type: t
                } = e;
                return (0, L.useContext)(q.BU) ? (0, r.jsx)(te, {
                    type: t
                }) : null
            }
        },
        81634: function(e, t, n) {
            n.d(t, {
                u: function() {
                    return o
                }
            });
            let r = RegExp("\\b(".concat("anal|anus|arse|arses|ass|asses|asshole|assholes|balls|ballsack|bastard|biatch|bitch|bitches|blowjob|blowjobs|boner|boob|boobs|butt|butts|butthole|clit|clitoris|clits|cock|cocks|crap|cum|cumming|cums|cumshot|cunt|cunts|dick|dickhead|dildo|dildos|dyke|fag|faggot|faggs|fags|fanny|fuck|fucked|fucker|fuckers|fuckhead|fuckheads|fuckin|fucking|fuckings|fucks|gangbang|gangbanged|gangbangs|homo|horny|jizz|mofo|motherfuck|motherfucker|motherfuckers|nazi|nigga|niggas|nigger|niggers|penis|poop|porn|porno|pornography|pron|pussies|pussy|rectum|retard|semen|sex|shag|shemale|shit|shite|shits|shitter|shitty|skank|slut|sluts|spunk|tit|tits|titties|turd|twat|vagina|wank|whore", ")\\b"), "ig");

            function o(e) {
                return r.lastIndex = 0, r.test(e)
            }
        }
    }
]);