"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2944], {
        10893: function(e, t, n) {
            n.d(t, {
                EU: function() {
                    return eY
                },
                F0: function() {
                    return e7
                },
                MT: function() {
                    return ey
                },
                OU: function() {
                    return N
                },
                PO: function() {
                    return D
                },
                Pz: function() {
                    return ep
                },
                Q8: function() {
                    return R
                },
                VB: function() {
                    return tT
                },
                W_: function() {
                    return eh
                },
                Xd: function() {
                    return tk
                },
                Zb: function() {
                    return v
                },
                Ze: function() {
                    return tu
                },
                as: function() {
                    return ej
                },
                eI: function() {
                    return tw
                },
                hu: function() {
                    return _
                },
                iK: function() {
                    return e8
                },
                iV: function() {
                    return b
                },
                iz: function() {
                    return tb
                },
                l8: function() {
                    return p
                },
                nn: function() {
                    return m
                },
                oV: function() {
                    return eG
                },
                x0: function() {
                    return e$
                },
                x3: function() {
                    return tI
                },
                yO: function() {
                    return z
                },
                yg: function() {
                    return M
                }
            });
            var i, r, o, s, a, d = Object.defineProperty,
                l = "@liveblocks/core",
                c = "2.8.0",
                u = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : {};

            function h(e) {
                console.error(e)
            }

            function p(e, t, n) {
                let i = Symbol.for(e),
                    r = n ? `${t||"dev"} (${n})` : t || "dev";
                u[i] ? u[i] === r || h(`Multiple copies of Liveblocks are being loaded in your project. This will cause issues! See https://liveblocks.io/docs/errors/dupes 

Conflicts:
- ${e} ${u[i]} (already loaded)
- ${e} ${r} (trying to load this now)`) : u[i] = r, t && c && t !== c && h(`Cross-linked versions of Liveblocks found, which will cause issues! See https://liveblocks.io/docs/errors/cross-linked 

Conflicts:
- ${l} is at ${c}
- ${e} is at ${t}

Always upgrade all Liveblocks packages to the same version number.`)
            }

            function f(e, t) {
                throw Error(t)
            }

            function _(e, t) {}

            function m(e, t = "Expected value to be non-nullable") {
                return e
            }

            function y() {
                let e, t;
                return [new Promise((n, i) => {
                    e = n, t = i
                }), e, t]
            }

            function g() {
                let [e, t, n] = y();
                return {
                    promise: e,
                    resolve: t,
                    reject: n
                }
            }

            function v() {
                let e = new Set,
                    t = new Set,
                    n = null;

                function i(e) {
                    return t.add(e), () => t.delete(e)
                }

                function r(t) {
                    return e.add(t), () => e.delete(t)
                }
                async function o(e) {
                    let t;
                    return new Promise(n => {
                        t = i(t => {
                            (void 0 === e || e(t)) && n(t)
                        })
                    }).finally(() => t ? .())
                }

                function s(n) {
                    e.forEach(e => e(n)), e.clear(), t.forEach(e => e(n))
                }
                return {
                    notify: function(e) {
                        null !== n ? n.push(e) : s(e)
                    },
                    subscribe: i,
                    subscribeOnce: r,
                    clear: function() {
                        e.clear(), t.clear()
                    },
                    count: function() {
                        return e.size + t.size
                    },
                    waitUntil: o,
                    pause: function() {
                        n = []
                    },
                    unpause: function() {
                        if (null !== n) {
                            for (let e of n) s(e);
                            n = null
                        }
                    },
                    observable: {
                        subscribe: i,
                        subscribeOnce: r,
                        waitUntil: o
                    }
                }
            }
            var b = {};
            ((e, t) => {
                for (var n in t) d(e, n, {
                    get: t[n],
                    enumerable: !0
                })
            })(b, {
                error: () => S,
                errorWithTitle: () => k,
                warn: () => T,
                warnWithTitle: () => I
            });
            var E = "background:#0e0d12;border-radius:9999px;color:#fff;padding:3px 7px;font-family:sans-serif;font-weight:600;";

            function w(e) {
                return "undefined" == typeof window ? console[e] : (t, ...n) => console[e]("%cLiveblocks", E, t, ...n)
            }
            var T = w("warn"),
                S = w("error");

            function O(e) {
                return "undefined" == typeof window ? console[e] : (t, n, ...i) => console[e](`%cLiveblocks%c ${t}`, E, "font-weight:600", n, ...i)
            }
            var I = O("warn"),
                k = O("error"),
                A = class {
                    constructor(e) {
                        this.curr = e
                    }
                    get current() {
                        return this.curr
                    }
                    allowPatching(e) {
                        let t = this,
                            n = !0;
                        e({ ...this.curr,
                            patch(e) {
                                if (n)
                                    for (let n of (t.curr = Object.assign({}, t.curr, e), Object.entries(e))) {
                                        let [e, t] = n;
                                        "patch" !== e && (this[e] = t)
                                    } else throw Error("Can no longer patch stale context")
                            }
                        }), n = !1
                    }
                },
                C = 1,
                P = class {
                    get initialState() {
                        let e = this.states.values()[Symbol.iterator]().next();
                        if (!e.done) return e.value;
                        throw Error("No states defined yet")
                    }
                    get currentState() {
                        if (null === this.currentStateOrNull) {
                            if (0 === this.runningState) throw Error("Not started yet");
                            throw Error("Already stopped")
                        }
                        return this.currentStateOrNull
                    }
                    start() {
                        if (0 !== this.runningState) throw Error("State machine has already started");
                        return this.runningState = 1, this.currentStateOrNull = this.initialState, this.enter(null), this
                    }
                    stop() {
                        if (1 !== this.runningState) throw Error("Cannot stop a state machine that hasn't started yet");
                        this.exit(null), this.runningState = 2, this.currentStateOrNull = null
                    }
                    constructor(e) {
                        this.id = C++, this.runningState = 0, this.currentStateOrNull = null, this.states = new Set, this.enterFns = new Map, this.cleanupStack = [], this.knownEventTypes = new Set, this.allowedTransitions = new Map, this.currentContext = new A(e), this.eventHub = {
                            didReceiveEvent: v(),
                            willTransition: v(),
                            didIgnoreEvent: v(),
                            willExitState: v(),
                            didEnterState: v()
                        }, this.events = {
                            didReceiveEvent: this.eventHub.didReceiveEvent.observable,
                            willTransition: this.eventHub.willTransition.observable,
                            didIgnoreEvent: this.eventHub.didIgnoreEvent.observable,
                            willExitState: this.eventHub.willExitState.observable,
                            didEnterState: this.eventHub.didEnterState.observable
                        }
                    }
                    get context() {
                        return this.currentContext.current
                    }
                    addState(e) {
                        if (0 !== this.runningState) throw Error("Already started");
                        return this.states.add(e), this
                    }
                    onEnter(e, t) {
                        if (0 !== this.runningState) throw Error("Already started");
                        if (this.enterFns.has(e)) throw Error(`enter/exit function for ${e} already exists`);
                        return this.enterFns.set(e, t), this
                    }
                    onEnterAsync(e, t, n, i) {
                        return this.onEnter(e, () => {
                            let e = new AbortController,
                                r = e.signal,
                                o = !1;
                            return t(this.currentContext.current, r).then(e => {
                                r.aborted || (o = !0, this.transition({
                                    type: "ASYNC_OK",
                                    data: e
                                }, n))
                            }, e => {
                                r.aborted || (o = !0, this.transition({
                                    type: "ASYNC_ERROR",
                                    reason: e
                                }, i))
                            }), () => {
                                o || e.abort()
                            }
                        })
                    }
                    getStatesMatching(e) {
                        let t = [];
                        if ("*" === e)
                            for (let e of this.states) t.push(e);
                        else if (e.endsWith(".*")) {
                            let n = e.slice(0, -1);
                            for (let e of this.states) e.startsWith(n) && t.push(e)
                        } else this.states.has(e) && t.push(e);
                        if (0 === t.length) throw Error(`No states match ${JSON.stringify(e)}`);
                        return t
                    }
                    addTransitions(e, t) {
                        if (0 !== this.runningState) throw Error("Already started");
                        for (let n of this.getStatesMatching(e)) {
                            let i = this.allowedTransitions.get(n);
                            for (let [r, o] of (void 0 === i && (i = new Map, this.allowedTransitions.set(n, i)), Object.entries(t))) {
                                if (i.has(r)) throw Error(`Trying to set transition "${r}" on "${n}" (via "${e}"), but a transition already exists there.`);
                                let t = o;
                                if (this.knownEventTypes.add(r), void 0 !== t) {
                                    let e = "function" == typeof t ? t : () => t;
                                    i.set(r, e)
                                }
                            }
                        }
                        return this
                    }
                    addTimedTransition(e, t, n) {
                        return this.onEnter(e, () => {
                            let e = setTimeout(() => {
                                this.transition({
                                    type: "TIMER"
                                }, n)
                            }, "function" == typeof t ? t(this.currentContext.current) : t);
                            return () => {
                                clearTimeout(e)
                            }
                        })
                    }
                    getTargetFn(e) {
                        return this.allowedTransitions.get(this.currentState) ? .get(e)
                    }
                    exit(e) {
                        this.eventHub.willExitState.notify(this.currentState), this.currentContext.allowPatching(t => {
                            e = e ? ? this.cleanupStack.length;
                            for (let n = 0; n < e; n++) this.cleanupStack.pop() ? .(t)
                        })
                    }
                    enter(e) {
                        let t = function(e, t) {
                            let n = e.split(".");
                            if (t < 1 || t > n.length + 1) throw Error("Invalid number of levels");
                            let i = [];
                            t > n.length && i.push("*");
                            for (let e = n.length - t + 1; e < n.length; e++) {
                                let t = n.slice(0, e);
                                t.length > 0 && i.push(t.join(".") + ".*")
                            }
                            return i.push(e), i
                        }(this.currentState, e ? ? this.currentState.split(".").length + 1);
                        this.currentContext.allowPatching(e => {
                            for (let n of t) {
                                let t = this.enterFns.get(n),
                                    i = t ? .(e);
                                "function" == typeof i ? this.cleanupStack.push(i) : this.cleanupStack.push(null)
                            }
                        }), this.eventHub.didEnterState.notify(this.currentState)
                    }
                    send(e) {
                        if (!this.knownEventTypes.has(e.type)) throw Error(`Invalid event ${JSON.stringify(e.type)}`);
                        if (2 === this.runningState) return;
                        let t = this.getTargetFn(e.type);
                        if (void 0 !== t) return this.transition(e, t);
                        this.eventHub.didIgnoreEvent.notify(e)
                    }
                    transition(e, t) {
                        let n, i;
                        this.eventHub.didReceiveEvent.notify(e);
                        let r = this.currentState,
                            o = ("function" == typeof t ? t : () => t)(e, this.currentContext.current);
                        if (null === o) {
                            this.eventHub.didIgnoreEvent.notify(e);
                            return
                        }
                        if ("string" == typeof o ? n = o : (n = o.target, i = Array.isArray(o.effect) ? o.effect : [o.effect]), !this.states.has(n)) throw Error(`Invalid next state name: ${JSON.stringify(n)}`);
                        this.eventHub.willTransition.notify({
                            from: r,
                            to: n
                        });
                        let [s, a] = function(e, t) {
                            if (e === t) return [0, 0];
                            let n = e.split("."),
                                i = t.split("."),
                                r = Math.min(n.length, i.length),
                                o = 0;
                            for (; o < r && n[o] === i[o]; o++);
                            return [n.length - o, i.length - o]
                        }(this.currentState, n);
                        if (s > 0 && this.exit(s), this.currentStateOrNull = n, void 0 !== i) {
                            let t = i;
                            this.currentContext.allowPatching(n => {
                                for (let i of t) "function" == typeof i ? i(n, e) : n.patch(i)
                            })
                        }
                        a > 0 && this.enter(a)
                    }
                };

            function N(e) {
                throw Error(e)
            }

            function D(e) {
                return null !== e && "object" == typeof e && "[object Object]" === Object.prototype.toString.call(e)
            }

            function L(e) {
                return Object.entries(e)
            }

            function R(e, t) {
                let n = {};
                for (let i of Object.entries(e)) {
                    let e = i[0];
                    if ("__proto__" === e) continue;
                    let r = i[1];
                    n[e] = t(r, e)
                }
                return n
            }

            function x(e) {
                try {
                    return JSON.parse(e)
                } catch (e) {
                    return
                }
            }

            function U(e) {
                return JSON.parse(JSON.stringify(e))
            }

            function $(e) {
                return e.filter(e => null != e)
            }

            function M(e) {
                let t = { ...e
                };
                return Object.keys(e).forEach(e => {
                    void 0 === t[e] && delete t[e]
                }), t
            }
            async function K(e, t, n) {
                let i;
                return Promise.race([e, new Promise((e, r) => {
                    i = setTimeout(() => {
                        r(Error(n))
                    }, t)
                })]).finally(() => clearTimeout(i))
            }

            function j(e) {
                let t = null;
                return () => (null === t && (t = e().catch(e => {
                    throw setTimeout(() => {
                        t = null
                    }, 5e3), e
                })), t)
            }
            var z = ((i = z || {})[i.UPDATE_PRESENCE = 100] = "UPDATE_PRESENCE", i[i.USER_JOINED = 101] = "USER_JOINED", i[i.USER_LEFT = 102] = "USER_LEFT", i[i.BROADCASTED_EVENT = 103] = "BROADCASTED_EVENT", i[i.ROOM_STATE = 104] = "ROOM_STATE", i[i.INITIAL_STORAGE_STATE = 200] = "INITIAL_STORAGE_STATE", i[i.UPDATE_STORAGE = 201] = "UPDATE_STORAGE", i[i.REJECT_STORAGE_OP = 299] = "REJECT_STORAGE_OP", i[i.UPDATE_YDOC = 300] = "UPDATE_YDOC", i[i.THREAD_CREATED = 400] = "THREAD_CREATED", i[i.THREAD_DELETED = 407] = "THREAD_DELETED", i[i.THREAD_METADATA_UPDATED = 401] = "THREAD_METADATA_UPDATED", i[i.THREAD_UPDATED = 408] = "THREAD_UPDATED", i[i.COMMENT_CREATED = 402] = "COMMENT_CREATED", i[i.COMMENT_EDITED = 403] = "COMMENT_EDITED", i[i.COMMENT_DELETED = 404] = "COMMENT_DELETED", i[i.COMMENT_REACTION_ADDED = 405] = "COMMENT_REACTION_ADDED", i[i.COMMENT_REACTION_REMOVED = 406] = "COMMENT_REACTION_REMOVED", i),
                H = ((r = H || {})[r.CLOSE_NORMAL = 1e3] = "CLOSE_NORMAL", r[r.CLOSE_ABNORMAL = 1006] = "CLOSE_ABNORMAL", r[r.UNEXPECTED_CONDITION = 1011] = "UNEXPECTED_CONDITION", r[r.TRY_AGAIN_LATER = 1013] = "TRY_AGAIN_LATER", r[r.INVALID_MESSAGE_FORMAT = 4e3] = "INVALID_MESSAGE_FORMAT", r[r.NOT_ALLOWED = 4001] = "NOT_ALLOWED", r[r.MAX_NUMBER_OF_MESSAGES_PER_SECONDS = 4002] = "MAX_NUMBER_OF_MESSAGES_PER_SECONDS", r[r.MAX_NUMBER_OF_CONCURRENT_CONNECTIONS = 4003] = "MAX_NUMBER_OF_CONCURRENT_CONNECTIONS", r[r.MAX_NUMBER_OF_MESSAGES_PER_DAY_PER_APP = 4004] = "MAX_NUMBER_OF_MESSAGES_PER_DAY_PER_APP", r[r.MAX_NUMBER_OF_CONCURRENT_CONNECTIONS_PER_ROOM = 4005] = "MAX_NUMBER_OF_CONCURRENT_CONNECTIONS_PER_ROOM", r[r.ROOM_ID_UPDATED = 4006] = "ROOM_ID_UPDATED", r[r.KICKED = 4100] = "KICKED", r[r.TOKEN_EXPIRED = 4109] = "TOKEN_EXPIRED", r[r.CLOSE_WITHOUT_RETRY = 4999] = "CLOSE_WITHOUT_RETRY", r);

            function W(e) {
                return 4999 === e || e >= 4e3 && e < 4100
            }

            function F(e) {
                return 1013 === e || e >= 4200 && e < 4300
            }

            function J(e) {
                let t = e.currentState;
                switch (t) {
                    case "@ok.connected":
                    case "@ok.awaiting-pong":
                        return "connected";
                    case "@idle.initial":
                        return "initial";
                    case "@auth.busy":
                    case "@auth.backoff":
                    case "@connecting.busy":
                    case "@connecting.backoff":
                    case "@idle.zombie":
                        return e.context.successCount > 0 ? "reconnecting" : "connecting";
                    case "@idle.failed":
                        return "disconnected";
                    default:
                        return f(t, "Unknown state")
                }
            }
            var B = [250, 500, 1e3, 2e3, 4e3, 8e3, 1e4],
                V = B[0] - 1,
                q = [2e3, 3e4, 6e4, 3e5],
                G = class extends Error {
                    constructor(e) {
                        super(e)
                    }
                },
                Y = class extends Error {
                    constructor(e, t) {
                        super(e), this.code = t
                    }
                };

            function X(e, t) {
                return t.find(t => t > e) ? ? t[t.length - 1]
            }

            function Z(e) {
                e.patch({
                    backoffDelay: X(e.backoffDelay, B)
                })
            }

            function Q(e) {
                e.patch({
                    backoffDelay: X(e.backoffDelay, q)
                })
            }

            function ee(e) {
                e.patch({
                    successCount: 0
                })
            }

            function et(e, t) {
                let n = 2 === e ? S : 1 === e ? T : () => {};
                return () => {
                    n(t)
                }
            }

            function en(e) {
                let t = "Connection to Liveblocks websocket server";
                return n => {
                    e instanceof Error ? T(`${t} could not be established. ${String(e)}`) : T(eo(e) ? `${t} closed prematurely (code: ${e.code}). Retrying in ${n.backoffDelay}ms.` : `${t} could not be established.`)
                }
            }

            function ei(e) {
                let t = [`code: ${e.code}`];
                return e.reason && t.push(`reason: ${e.reason}`), e => {
                    T(`Connection to Liveblocks websocket server closed (${t.join(", ")}). Retrying in ${e.backoffDelay}ms.`)
                }
            }
            var er = et(1, "Connection to WebSocket closed permanently. Won't retry.");

            function eo(e) {
                return !(e instanceof Error) && "close" === e.type
            }
            var es = e => t => t.patch(e),
                ea = class {
                    constructor(e, t = !1, n = !0) {
                        let {
                            machine: i,
                            events: r,
                            cleanups: o
                        } = function(e, t) {
                            let n = v();
                            n.pause();
                            let i = v();

                            function r(e, t) {
                                return () => {
                                    let n = new Y(e, t);
                                    i.notify(n)
                                }
                            }
                            let o = new P({
                                successCount: 0,
                                authValue: null,
                                socket: null,
                                backoffDelay: V
                            }).addState("@idle.initial").addState("@idle.failed").addState("@idle.zombie").addState("@auth.busy").addState("@auth.backoff").addState("@connecting.busy").addState("@connecting.backoff").addState("@ok.connected").addState("@ok.awaiting-pong");
                            o.addTransitions("*", {
                                RECONNECT: {
                                    target: "@auth.backoff",
                                    effect: [Z, ee]
                                },
                                DISCONNECT: "@idle.initial"
                            }), o.onEnter("@idle.*", ee).addTransitions("@idle.*", {
                                CONNECT: (e, t) => null !== t.authValue ? "@connecting.busy" : "@auth.busy"
                            }), o.addTransitions("@auth.backoff", {
                                NAVIGATOR_ONLINE: {
                                    target: "@auth.busy",
                                    effect: es({
                                        backoffDelay: V
                                    })
                                }
                            }).addTimedTransition("@auth.backoff", e => e.backoffDelay, "@auth.busy").onEnterAsync("@auth.busy", () => K(e.authenticate(), 1e4, "Timed out during auth"), e => ({
                                target: "@connecting.busy",
                                effect: es({
                                    authValue: e.data
                                })
                            }), e => e.reason instanceof G ? {
                                target: "@idle.failed",
                                effect: [et(2, e.reason.message), r(e.reason.message, -1)]
                            } : {
                                target: "@auth.backoff",
                                effect: [Z, et(2, `Authentication failed: ${e.reason instanceof Error?e.reason.message:String(e.reason)}`)]
                            });
                            let s = e => o.send({
                                    type: "EXPLICIT_SOCKET_ERROR",
                                    event: e
                                }),
                                a = e => o.send({
                                    type: "EXPLICIT_SOCKET_CLOSE",
                                    event: e
                                }),
                                d = e => "pong" === e.data ? o.send({
                                    type: "PONG"
                                }) : n.notify(e);

                            function l(e) {
                                e && (e.removeEventListener("error", s), e.removeEventListener("close", a), e.removeEventListener("message", d), e.close())
                            }
                            o.addTransitions("@connecting.backoff", {
                                NAVIGATOR_ONLINE: {
                                    target: "@connecting.busy",
                                    effect: es({
                                        backoffDelay: V
                                    })
                                }
                            }).addTimedTransition("@connecting.backoff", e => e.backoffDelay, "@connecting.busy").onEnterAsync("@connecting.busy", async (n, i) => {
                                let r = null,
                                    o = null;
                                return K(new Promise((i, l) => {
                                    if (null === n.authValue) throw Error("No auth authValue");
                                    let c = e.createSocket(n.authValue);

                                    function u(e) {
                                        r = e, c.removeEventListener("message", d), l(e)
                                    }
                                    o = c;
                                    let [h, p] = y();

                                    function f(e) {
                                        let t = x(e.data);
                                        t ? .type === 104 && p()
                                    }
                                    t.waitForActorId || p(), c.addEventListener("message", d), t.waitForActorId && c.addEventListener("message", f), c.addEventListener("error", u), c.addEventListener("close", u), c.addEventListener("open", () => {
                                        c.addEventListener("error", s), c.addEventListener("close", a);
                                        let e = () => {
                                            c.removeEventListener("error", u), c.removeEventListener("close", u), c.removeEventListener("message", f)
                                        };
                                        h.then(() => {
                                            i([c, e])
                                        })
                                    })
                                }), 1e4, "Timed out during websocket connection").then(([e, t]) => {
                                    if (t(), i.aborted) throw Error("Aborted");
                                    if (r) throw r;
                                    return e
                                }).catch(e => {
                                    throw l(o), e
                                })
                            }, e => ({
                                target: "@ok.connected",
                                effect: es({
                                    socket: e.data,
                                    backoffDelay: V
                                })
                            }), e => {
                                let t = e.reason;
                                if (t instanceof G) return {
                                    target: "@idle.failed",
                                    effect: [et(2, t.message), r(t.message, -1)]
                                };
                                if (eo(t)) {
                                    if (4109 === t.code) return "@auth.busy";
                                    if (F(t.code)) return {
                                        target: "@connecting.backoff",
                                        effect: [Q, en(t)]
                                    };
                                    if (W(t.code)) return {
                                        target: "@idle.failed",
                                        effect: [et(2, t.reason), r(t.reason, t.code)]
                                    }
                                }
                                return {
                                    target: "@auth.backoff",
                                    effect: [Z, en(t)]
                                }
                            });
                            let c = {
                                    target: "@ok.awaiting-pong",
                                    effect: e => {
                                        e.socket ? .send("ping")
                                    }
                                },
                                u = () => {
                                    let t = "undefined" != typeof document ? document : void 0;
                                    return t ? .visibilityState === "hidden" && e.canZombie() ? "@idle.zombie" : c
                                };
                            if (o.addTimedTransition("@ok.connected", 3e4, u).addTransitions("@ok.connected", {
                                    NAVIGATOR_OFFLINE: u,
                                    WINDOW_GOT_FOCUS: c
                                }), o.addTransitions("@idle.zombie", {
                                    WINDOW_GOT_FOCUS: "@connecting.backoff"
                                }), o.onEnter("@ok.*", e => {
                                    e.patch({
                                        successCount: e.successCount + 1
                                    });
                                    let t = setTimeout(n.unpause, 0);
                                    return e => {
                                        l(e.socket), e.patch({
                                            socket: null
                                        }), clearTimeout(t), n.pause()
                                    }
                                }).addTransitions("@ok.awaiting-pong", {
                                    PONG: "@ok.connected"
                                }).addTimedTransition("@ok.awaiting-pong", 2e3, {
                                    target: "@connecting.busy",
                                    effect: et(1, "Received no pong from server, assume implicit connection loss.")
                                }).addTransitions("@ok.*", {
                                    EXPLICIT_SOCKET_ERROR: (e, t) => t.socket ? .readyState === 1 ? null : {
                                        target: "@connecting.backoff",
                                        effect: Z
                                    },
                                    EXPLICIT_SOCKET_CLOSE: e => {
                                        var t;
                                        return W(e.event.code) ? {
                                            target: "@idle.failed",
                                            effect: [er, r(e.event.reason, e.event.code)]
                                        } : (t = e.event.code) >= 4100 && t < 4200 ? 4109 === e.event.code ? "@auth.busy" : {
                                            target: "@auth.backoff",
                                            effect: [Z, ei(e.event)]
                                        } : F(e.event.code) ? {
                                            target: "@connecting.backoff",
                                            effect: [Q, ei(e.event)]
                                        } : {
                                            target: "@connecting.backoff",
                                            effect: [Z, ei(e.event)]
                                        }
                                    }
                                }), "undefined" != typeof document) {
                                let e = "undefined" != typeof document ? document : void 0,
                                    t = "undefined" != typeof window ? window : void 0,
                                    n = t ? ? e;
                                o.onEnter("*", i => {
                                    function r() {
                                        o.send({
                                            type: "NAVIGATOR_OFFLINE"
                                        })
                                    }

                                    function s() {
                                        o.send({
                                            type: "NAVIGATOR_ONLINE"
                                        })
                                    }

                                    function a() {
                                        e ? .visibilityState === "visible" && o.send({
                                            type: "WINDOW_GOT_FOCUS"
                                        })
                                    }
                                    return t ? .addEventListener("online", s), t ? .addEventListener("offline", r), n ? .addEventListener("visibilitychange", a), () => {
                                        n ? .removeEventListener("visibilitychange", a), t ? .removeEventListener("online", s), t ? .removeEventListener("offline", r), l(i.socket)
                                    }
                                })
                            }
                            let h = [],
                                {
                                    statusDidChange: p,
                                    didConnect: f,
                                    didDisconnect: _,
                                    unsubscribe: m
                                } = function(e) {
                                    let t = v(),
                                        n = v(),
                                        i = v(),
                                        r = null,
                                        o = e.events.didEnterState.subscribe(() => {
                                            let o = J(e);
                                            o !== r && t.notify(o), "connected" === r && "connected" !== o ? i.notify() : "connected" !== r && "connected" === o && n.notify(), r = o
                                        });
                                    return {
                                        statusDidChange: t.observable,
                                        didConnect: n.observable,
                                        didDisconnect: i.observable,
                                        unsubscribe: o
                                    }
                                }(o);
                            return h.push(m), t.enableDebugLogging && h.push(function(e) {
                                let t = new Date().getTime();

                                function n(...i) {
                                    T(`${((new Date().getTime()-t)/1e3).toFixed(2)} [FSM #${e.id}]`, ...i)
                                }
                                let i = [e.events.didReceiveEvent.subscribe(e => n(`Event ${e.type}`)), e.events.willTransition.subscribe(({
                                    from: e,
                                    to: t
                                }) => n("Transitioning", e, "→", t)), e.events.didIgnoreEvent.subscribe(e => n("Ignored event", e.type, e, "(current state won't handle it)"))];
                                return () => {
                                    for (let e of i) e()
                                }
                            }(o)), o.start(), {
                                machine: o,
                                cleanups: h,
                                events: {
                                    statusDidChange: p,
                                    didConnect: f,
                                    didDisconnect: _,
                                    onMessage: n.observable,
                                    onLiveblocksError: i.observable
                                }
                            }
                        }(e, {
                            waitForActorId: n,
                            enableDebugLogging: t
                        });
                        this.machine = i, this.events = r, this.cleanups = o
                    }
                    getStatus() {
                        try {
                            return J(this.machine)
                        } catch {
                            return "initial"
                        }
                    }
                    get authValue() {
                        return this.machine.context.authValue
                    }
                    connect() {
                        this.machine.send({
                            type: "CONNECT"
                        })
                    }
                    reconnect() {
                        this.machine.send({
                            type: "RECONNECT"
                        })
                    }
                    disconnect() {
                        this.machine.send({
                            type: "DISCONNECT"
                        })
                    }
                    destroy() {
                        let e;
                        for (this.machine.stop(); e = this.cleanups.pop();) e()
                    }
                    send(e) {
                        let t = this.machine.context ? .socket;
                        null === t ? T("Cannot send: not connected yet", e) : 1 !== t.readyState ? T("Cannot send: WebSocket no longer open", e) : t.send(e)
                    }
                    _privateSendMachineEvent(e) {
                        this.machine.send(e)
                    }
                };

            function ed(e) {
                return e.includes("room:write")
            }

            function el(e) {
                return e.includes("comments:write") || e.includes("room:write")
            }

            function ec(e) {
                var t;
                let n = e.split(".");
                if (3 !== n.length) throw Error("Authentication error: invalid JWT token");
                let i = x(function(e) {
                    try {
                        let t = e.replace(/-/g, "+").replace(/_/g, "/");
                        return decodeURIComponent(atob(t).split("").map(function(e) {
                            return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2)
                        }).join(""))
                    } catch (t) {
                        return atob(e)
                    }
                }(n[1]));
                if (!(i && D(t = i) && ("acc" === t.k || "id" === t.k || "sec-legacy" === t.k))) throw Error("Authentication error: expected a valid token but did not get one. Hint: if you are using a callback, ensure the room is passed when creating the token. For more information: https://liveblocks.io/docs/api-reference/liveblocks-client#createClientCallback");
                return {
                    raw: e,
                    parsed: i
                }
            }
            async function eu(e, t, n) {
                let i;
                let r = await e(t, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(n)
                });
                if (!r.ok) {
                    let e = `${(await r.text()).trim()||"reason not provided in auth response"} (${r.status} returned by POST ${t})`;
                    if (401 === r.status || 403 === r.status) throw new G(`Unauthorized: ${e}`);
                    throw Error(`Failed to authenticate: ${e}`)
                }
                try {
                    i = await r.json()
                } catch (e) {
                    throw Error(`Expected a JSON response when doing a POST request on "${t}". ${String(e)}`)
                }
                if (!D(i) || "string" != typeof i.token) throw Error(`Expected a JSON response of the form \`{ token: "..." }\` when doing a POST request on "${t}", but got ${JSON.stringify(i)}`);
                let {
                    token: o
                } = i;
                return {
                    token: o
                }
            }
            var eh = Symbol();

            function ep(e, ...t) {
                return "object" != typeof e || null === e || Array.isArray(e) ? JSON.stringify(e, ...t) : JSON.stringify(Object.keys(e).sort().reduce((t, n) => (t[n] = e[n], t), {}), ...t)
            }
            v().observable, Date.now();
            var ef = class {
                    constructor(e) {
                        this.input = e;
                        let {
                            promise: t,
                            resolve: n,
                            reject: i
                        } = g();
                        this.promise = t, this.resolve = n, this.reject = i
                    }
                },
                e_ = class {
                    constructor(e, t) {
                        this.queue = [], this.error = !1, this.callback = e, this.size = t.size ? ? 50, this.delay = t.delay
                    }
                    clearDelayTimeout() {
                        void 0 !== this.delayTimeoutId && (clearTimeout(this.delayTimeoutId), this.delayTimeoutId = void 0)
                    }
                    schedule() {
                        this.queue.length === this.size ? this.flush() : 1 === this.queue.length && (this.clearDelayTimeout(), this.delayTimeoutId = setTimeout(() => void this.flush(), this.delay))
                    }
                    async flush() {
                        if (0 === this.queue.length) return;
                        let e = this.queue.splice(0),
                            t = e.map(e => e.input);
                        try {
                            let n = await this.callback(t);
                            this.error = !1, e.forEach((t, i) => {
                                let r = n ? .[i];
                                Array.isArray(n) ? e.length !== n.length ? t.reject(Error(`Callback must return an array of the same length as the number of provided items. Expected ${e.length}, but got ${n.length}.`)) : r instanceof Error ? t.reject(r) : t.resolve(r) : t.reject(Error("Callback must return an array."))
                            })
                        } catch (t) {
                            this.error = !0, e.forEach(e => {
                                e.reject(t)
                            })
                        }
                    }
                    get(e) {
                        let t = this.queue.find(t => ep(t.input) === ep(e));
                        if (t) return t.promise;
                        let n = new ef(e);
                        return this.queue.push(n), this.schedule(), n.promise
                    }
                    clear() {
                        this.queue = [], this.error = !1, this.clearDelayTimeout()
                    }
                };

            function em(e) {
                let t = new Map,
                    n = v();

                function i(e, i) {
                    t.set(e, i), n.notify()
                }
                async function r(n) {
                    let r = ep(n);
                    if (!t.has(r)) try {
                        i(r, {
                            isLoading: !0
                        });
                        let t = await e.get(n);
                        i(r, {
                            isLoading: !1,
                            data: t
                        })
                    } catch (e) {
                        i(r, {
                            isLoading: !1,
                            error: e
                        })
                    }
                }
                return { ...n.observable,
                    get: r,
                    getState: function(e) {
                        let n = ep(e);
                        return t.get(n)
                    }
                }
            }

            function ey(e) {
                let t = !0,
                    n = !1,
                    i = e,
                    r = new Set;

                function o() {
                    if (n)
                        for (let e of (n = !1, r)) e(i)
                }
                return {
                    get: function() {
                        return i
                    },
                    set: function(e) {
                        let r = i,
                            s = e(r);
                        s !== r && (i = s, n = !0), t && o()
                    },
                    batch: function(e) {
                        if (!1 === t) return e();
                        t = !1;
                        try {
                            e()
                        } finally {
                            t = !0, o()
                        }
                    },
                    subscribe: function(e) {
                        return r.add(e), () => {
                            r.delete(e)
                        }
                    }
                }
            }

            function eg(e) {
                let t = e.editedAt ? new Date(e.editedAt) : void 0,
                    n = new Date(e.createdAt),
                    i = e.reactions.map(e => ({ ...e,
                        createdAt: new Date(e.createdAt)
                    }));
                if (e.body) return { ...e,
                    reactions: i,
                    createdAt: n,
                    editedAt: t
                }; {
                    let r = new Date(e.deletedAt);
                    return { ...e,
                        reactions: i,
                        createdAt: n,
                        editedAt: t,
                        deletedAt: r
                    }
                }
            }

            function ev(e) {
                let t = e.updatedAt ? new Date(e.updatedAt) : void 0,
                    n = new Date(e.createdAt),
                    i = e.comments.map(e => eg(e));
                return { ...e,
                    createdAt: n,
                    updatedAt: t,
                    comments: i
                }
            }

            function eb(e) {
                let t = new Date(e.notifiedAt),
                    n = e.readAt ? new Date(e.readAt) : null;
                if ("activities" in e) {
                    let i = e.activities.map(e => ({ ...e,
                        createdAt: new Date(e.createdAt)
                    }));
                    return { ...e,
                        notifiedAt: t,
                        readAt: n,
                        activities: i
                    }
                }
                return { ...e,
                    notifiedAt: t,
                    readAt: n
                }
            }

            function eE(e) {
                let t = new Date(e.deletedAt);
                return { ...e,
                    deletedAt: t
                }
            }

            function ew(e) {
                let t = new Date(e.deletedAt);
                return { ...e,
                    deletedAt: t
                }
            }

            function eT(e, t, n) {
                let i = new URL(t, e);
                return void 0 !== n && (i.search = (n instanceof URLSearchParams ? n : function(e) {
                    let t = new URLSearchParams;
                    for (let [n, i] of Object.entries(e)) null != i && t.set(n, i.toString());
                    return t
                }(n)).toString()), i.toString()
            }

            function eS(e, ...t) {
                return e.reduce((e, n, i) => e + encodeURIComponent(t[i - 1] ? ? "") + n)
            }
            var eO = eA(0),
                eI = eA(1),
                ek = eO + eA(-1);

            function eA(e) {
                let t = 32 + (e < 0 ? 95 + e : e);
                if (t < 32 || t > 126) throw Error(`Invalid n value: ${e}`);
                return String.fromCharCode(t)
            }

            function eC(e, t) {
                return void 0 !== e && void 0 !== t ? function(e, t) {
                    if (e < t) return eP(e, t);
                    if (e > t) return eP(t, e);
                    throw Error("Cannot compute value between two equal positions")
                }(e, t) : void 0 !== e ? function(e) {
                    for (let t = 0; t <= e.length - 1; t++) {
                        let n = e.charCodeAt(t);
                        if (!(n >= 126)) return e.substring(0, t) + String.fromCharCode(n + 1)
                    }
                    return e + eI
                }(e) : void 0 !== t ? function(e) {
                    let t = e.length - 1;
                    for (let n = 0; n <= t; n++) {
                        let i = e.charCodeAt(n);
                        if (!(i <= 32)) {
                            if (n !== t) return e.substring(0, n + 1);
                            if (33 === i) return e.substring(0, n) + ek;
                            return e.substring(0, n) + String.fromCharCode(i - 1)
                        }
                    }
                    return eI
                }(t) : eI
            }

            function eP(e, t) {
                let n = 0,
                    i = e.length,
                    r = t.length;
                for (;;) {
                    let s = n < i ? e.charCodeAt(n) : 32,
                        a = n < r ? t.charCodeAt(n) : 126;
                    if (s === a) {
                        n++;
                        continue
                    }
                    if (a - s != 1) {
                        var o;
                        return ((o = n) < e.length ? e.substring(0, o) : e + eO.repeat(o - e.length)) + String.fromCharCode(a + s >> 1)
                    } {
                        let t = n + 1,
                            i = e.substring(0, t);
                        return i.length < t && (i += eO.repeat(t - i.length)), i + eP(e.substring(t), "")
                    }
                }
            }

            function eN(e) {
                return ! function(e) {
                    if ("" === e) return !1;
                    let t = e.length - 1,
                        n = e.charCodeAt(t);
                    if (n < 33 || n > 126) return !1;
                    for (let n = 0; n < t; n++) {
                        let t = e.charCodeAt(n);
                        if (t < 32 || t > 126) return !1
                    }
                    return !0
                }(e) ? function(e) {
                    let t = [];
                    for (let n = 0; n < e.length; n++) {
                        let i = e.charCodeAt(n);
                        t.push(i < 32 ? 32 : i > 126 ? 126 : i)
                    }
                    for (; t.length > 0 && 32 === t[t.length - 1];) t.length--;
                    return t.length > 0 ? String.fromCharCode(...t) : eI
                }(e) : e
            }
            var eD = ((o = eD || {})[o.INIT = 0] = "INIT", o[o.SET_PARENT_KEY = 1] = "SET_PARENT_KEY", o[o.CREATE_LIST = 2] = "CREATE_LIST", o[o.UPDATE_OBJECT = 3] = "UPDATE_OBJECT", o[o.CREATE_OBJECT = 4] = "CREATE_OBJECT", o[o.DELETE_CRDT = 5] = "DELETE_CRDT", o[o.DELETE_OBJECT_KEY = 6] = "DELETE_OBJECT_KEY", o[o.CREATE_MAP = 7] = "CREATE_MAP", o[o.CREATE_REGISTER = 8] = "CREATE_REGISTER", o);

            function eL(e, t, n = eN(t)) {
                return Object.freeze({
                    type: "HasParent",
                    node: e,
                    key: t,
                    pos: n
                })
            }
            var eR = Object.freeze({
                    type: "NoParent"
                }),
                ex = class {
                    constructor() {
                        this._parent = eR
                    }
                    _getParentKeyOrThrow() {
                        switch (this.parent.type) {
                            case "HasParent":
                                return this.parent.key;
                            case "NoParent":
                                throw Error("Parent key is missing");
                            case "Orphaned":
                                return this.parent.oldKey;
                            default:
                                return f(this.parent, "Unknown state")
                        }
                    }
                    get _parentPos() {
                        switch (this.parent.type) {
                            case "HasParent":
                                return this.parent.pos;
                            case "NoParent":
                                throw Error("Parent key is missing");
                            case "Orphaned":
                                return this.parent.oldPos;
                            default:
                                return f(this.parent, "Unknown state")
                        }
                    }
                    get _pool() {
                        return this.__pool
                    }
                    get roomId() {
                        return this.__pool ? this.__pool.roomId : null
                    }
                    get _id() {
                        return this.__id
                    }
                    get parent() {
                        return this._parent
                    }
                    get _parentKey() {
                        switch (this.parent.type) {
                            case "HasParent":
                                return this.parent.key;
                            case "NoParent":
                                return null;
                            case "Orphaned":
                                return this.parent.oldKey;
                            default:
                                return f(this.parent, "Unknown state")
                        }
                    }
                    _apply(e, t) {
                        return 5 === e.type && "HasParent" === this.parent.type ? this.parent.node._detachChild(this) : {
                            modified: !1
                        }
                    }
                    _setParentLink(e, t) {
                        switch (this.parent.type) {
                            case "HasParent":
                                if (this.parent.node !== e) throw Error("Cannot set parent: node already has a parent");
                                this._parent = eL(e, t);
                                return;
                            case "Orphaned":
                            case "NoParent":
                                this._parent = eL(e, t);
                                return;
                            default:
                                return f(this.parent, "Unknown state")
                        }
                    }
                    _attach(e, t) {
                        if (this.__id || this.__pool) throw Error("Cannot attach node: already attached");
                        t.addNode(e, this), this.__id = e, this.__pool = t
                    }
                    _detach() {
                        switch (this.__pool && this.__id && this.__pool.deleteNode(this.__id), this.parent.type) {
                            case "HasParent":
                                this._parent = function(e, t = eN(e)) {
                                    return Object.freeze({
                                        type: "Orphaned",
                                        oldKey: e,
                                        oldPos: t
                                    })
                                }(this.parent.key, this.parent.pos);
                                break;
                            case "NoParent":
                                this._parent = eR;
                                break;
                            case "Orphaned":
                                break;
                            default:
                                f(this.parent, "Unknown state")
                        }
                        this.__pool = void 0
                    }
                    invalidate() {
                        (void 0 !== this._cachedImmutable || void 0 !== this._cachedTreeNode) && (this._cachedImmutable = void 0, this._cachedTreeNode = void 0, "HasParent" === this.parent.type && this.parent.node.invalidate())
                    }
                    toTreeNode(e) {
                        return (void 0 === this._cachedTreeNode || this._cachedTreeNodeKey !== e) && (this._cachedTreeNodeKey = e, this._cachedTreeNode = this._toTreeNode(e)), this._cachedTreeNode
                    }
                    toImmutable() {
                        return void 0 === this._cachedImmutable && (this._cachedImmutable = this._toImmutable()), this._cachedImmutable
                    }
                },
                eU = ((s = eU || {})[s.OBJECT = 0] = "OBJECT", s[s.LIST = 1] = "LIST", s[s.MAP = 2] = "MAP", s[s.REGISTER = 3] = "REGISTER", s),
                e$ = (e = 21) => crypto.getRandomValues(new Uint8Array(e)).reduce((e, t) => e += (t &= 63) < 36 ? t.toString(36) : t < 62 ? (t - 26).toString(36).toUpperCase() : t < 63 ? "_" : "-", ""),
                eM = class e extends ex {
                    constructor(e) {
                        super(), this._data = e
                    }
                    get data() {
                        return this._data
                    }
                    static _deserialize([t, n], i, r) {
                        let o = new e(n.data);
                        return o._attach(t, r), o
                    }
                    _toOps(e, t, n) {
                        if (void 0 === this._id) throw Error("Cannot serialize register if parentId or parentKey is undefined");
                        return [{
                            type: 8,
                            opId: n ? .generateOpId(),
                            id: this._id,
                            parentId: e,
                            parentKey: t,
                            data: this.data
                        }]
                    }
                    _serialize() {
                        if ("HasParent" !== this.parent.type) throw Error("Cannot serialize LiveRegister if parent is missing");
                        return {
                            type: 3,
                            parentId: m(this.parent.node._id, "Parent node expected to have ID"),
                            parentKey: this.parent.key,
                            data: this.data
                        }
                    }
                    _attachChild(e) {
                        throw Error("Method not implemented.")
                    }
                    _detachChild(e) {
                        throw Error("Method not implemented.")
                    }
                    _apply(e, t) {
                        return super._apply(e, t)
                    }
                    _toTreeNode(e) {
                        return {
                            type: "Json",
                            id: this._id ? ? e$(),
                            key: e,
                            payload: this._data
                        }
                    }
                    _toImmutable() {
                        return this._data
                    }
                    clone() {
                        return U(this.data)
                    }
                };

            function eK(e, t) {
                let n = e._parentPos,
                    i = t._parentPos;
                return n === i ? 0 : n < i ? -1 : 1
            }
            var ej = class e extends ex {
                    constructor(e) {
                        let t;
                        for (let n of (super(), this._items = [], this._implicitlyDeletedItems = new WeakSet, this._unacknowledgedSets = new Map, e)) {
                            let e = eC(t),
                                i = e4(n);
                            i._setParentLink(this, e), this._items.push(i), t = e
                        }
                    }
                    static _deserialize([t], n, i) {
                        let r = new e([]);
                        r._attach(t, i);
                        let o = n.get(t);
                        if (void 0 === o) return r;
                        for (let [e, t] of o) {
                            let o = eQ([e, t], n, i);
                            o._setParentLink(r, t.parentKey), r._insertAndSort(o)
                        }
                        return r
                    }
                    _toOps(e, t, n) {
                        if (void 0 === this._id) throw Error("Cannot serialize item is not attached");
                        let i = [],
                            r = {
                                id: this._id,
                                opId: n ? .generateOpId(),
                                type: 2,
                                parentId: e,
                                parentKey: t
                            };
                        for (let e of (i.push(r), this._items)) {
                            let t = e._getParentKeyOrThrow(),
                                r = eV(e._toOps(this._id, t, n), void 0),
                                o = r[0].opId;
                            void 0 !== o && this._unacknowledgedSets.set(t, o), i.push(...r)
                        }
                        return i
                    }
                    _insertAndSort(e) {
                        this._items.push(e), this._sortItems()
                    }
                    _sortItems() {
                        this._items.sort(eK), this.invalidate()
                    }
                    _indexOfPosition(e) {
                        return this._items.findIndex(t => t._getParentKeyOrThrow() === e)
                    }
                    _attach(e, t) {
                        for (let n of (super._attach(e, t), this._items)) n._attach(t.generateId(), t)
                    }
                    _detach() {
                        for (let e of (super._detach(), this._items)) e._detach()
                    }
                    _applySetRemote(e) {
                        if (void 0 === this._pool) throw Error("Can't attach child if managed pool is not present");
                        let {
                            id: t,
                            parentKey: n
                        } = e, i = eX(e);
                        i._attach(t, this._pool), i._setParentLink(this, n);
                        let r = e.deletedId,
                            o = this._indexOfPosition(n);
                        if (-1 !== o) {
                            let t = this._items[o];
                            if (t._id === r) return t._detach(), this._items[o] = i, {
                                modified: eH(this, [eW(o, i)]),
                                reverse: []
                            }; {
                                this._implicitlyDeletedItems.add(t), this._items[o] = i;
                                let n = [eW(o, i)],
                                    r = this._detachItemAssociatedToSetOperation(e.deletedId);
                                return r && n.push(r), {
                                    modified: eH(this, n),
                                    reverse: []
                                }
                            }
                        } {
                            let t = [],
                                r = this._detachItemAssociatedToSetOperation(e.deletedId);
                            return r && t.push(r), this._insertAndSort(i), t.push(eJ(this._indexOfPosition(n), i)), {
                                reverse: [],
                                modified: eH(this, t)
                            }
                        }
                    }
                    _applySetAck(e) {
                        if (void 0 === this._pool) throw Error("Can't attach child if managed pool is not present");
                        let t = [],
                            n = this._detachItemAssociatedToSetOperation(e.deletedId);
                        n && t.push(n);
                        let i = this._unacknowledgedSets.get(e.parentKey);
                        if (void 0 !== i) {
                            if (i !== e.opId) return 0 === t.length ? {
                                modified: !1
                            } : {
                                modified: eH(this, t),
                                reverse: []
                            };
                            this._unacknowledgedSets.delete(e.parentKey)
                        }
                        let r = this._indexOfPosition(e.parentKey),
                            o = this._items.find(t => t._id === e.id);
                        if (void 0 !== o) {
                            if (o._parentKey === e.parentKey) return {
                                modified: t.length > 0 && eH(this, t),
                                reverse: []
                            }; - 1 !== r && (this._implicitlyDeletedItems.add(this._items[r]), this._items.splice(r, 1), t.push(eF(r)));
                            let n = this._items.indexOf(o);
                            o._setParentLink(this, e.parentKey), this._sortItems();
                            let i = this._items.indexOf(o);
                            return i !== n && t.push(eB(n, i, o)), {
                                modified: t.length > 0 && eH(this, t),
                                reverse: []
                            }
                        } {
                            let n = this._pool.getNode(e.id);
                            if (n && this._implicitlyDeletedItems.has(n)) {
                                n._setParentLink(this, e.parentKey), this._implicitlyDeletedItems.delete(n), this._insertAndSort(n);
                                let i = this._items.indexOf(n);
                                return {
                                    modified: eH(this, [-1 === r ? eJ(i, n) : eW(i, n), ...t]),
                                    reverse: []
                                }
                            } {
                                -1 !== r && this._items.splice(r, 1);
                                let {
                                    newItem: n,
                                    newIndex: i
                                } = this._createAttachItemAndSort(e, e.parentKey);
                                return {
                                    modified: eH(this, [-1 === r ? eJ(i, n) : eW(i, n), ...t]),
                                    reverse: []
                                }
                            }
                        }
                    }
                    _detachItemAssociatedToSetOperation(e) {
                        if (void 0 === e || void 0 === this._pool) return null;
                        let t = this._pool.getNode(e);
                        if (void 0 === t) return null;
                        let n = this._detachChild(t);
                        return !1 === n.modified ? null : n.modified.updates[0]
                    }
                    _applyRemoteInsert(e) {
                        if (void 0 === this._pool) throw Error("Can't attach child if managed pool is not present");
                        let t = eN(e.parentKey),
                            n = this._indexOfPosition(t); - 1 !== n && this._shiftItemPosition(n, t);
                        let {
                            newItem: i,
                            newIndex: r
                        } = this._createAttachItemAndSort(e, t);
                        return {
                            modified: eH(this, [eJ(r, i)]),
                            reverse: []
                        }
                    }
                    _applyInsertAck(e) {
                        let t = this._items.find(t => t._id === e.id),
                            n = eN(e.parentKey),
                            i = this._indexOfPosition(n);
                        if (t) {
                            if (t._parentKey === n) return {
                                modified: !1
                            }; {
                                let e = this._items.indexOf(t); - 1 !== i && this._shiftItemPosition(i, n), t._setParentLink(this, n), this._sortItems();
                                let r = this._indexOfPosition(n);
                                return r === e ? {
                                    modified: !1
                                } : {
                                    modified: eH(this, [eB(e, r, t)]),
                                    reverse: []
                                }
                            }
                        } {
                            let t = m(this._pool).getNode(e.id);
                            if (t && this._implicitlyDeletedItems.has(t)) return t._setParentLink(this, n), this._implicitlyDeletedItems.delete(t), this._insertAndSort(t), {
                                modified: eH(this, [eJ(this._indexOfPosition(n), t)]),
                                reverse: []
                            }; {
                                -1 !== i && this._shiftItemPosition(i, n);
                                let {
                                    newItem: t,
                                    newIndex: r
                                } = this._createAttachItemAndSort(e, n);
                                return {
                                    modified: eH(this, [eJ(r, t)]),
                                    reverse: []
                                }
                            }
                        }
                    }
                    _applyInsertUndoRedo(e) {
                        let {
                            id: t,
                            parentKey: n
                        } = e, i = eX(e);
                        if (this._pool ? .getNode(t) !== void 0) return {
                            modified: !1
                        };
                        i._attach(t, m(this._pool)), i._setParentLink(this, n);
                        let r = this._indexOfPosition(n),
                            o = n;
                        return -1 !== r && (o = eC(this._items[r] ? ._parentPos, this._items[r + 1] ? ._parentPos), i._setParentLink(this, o)), this._insertAndSort(i), {
                            modified: eH(this, [eJ(this._indexOfPosition(o), i)]),
                            reverse: [{
                                type: 5,
                                id: t
                            }]
                        }
                    }
                    _applySetUndoRedo(e) {
                        let {
                            id: t,
                            parentKey: n
                        } = e, i = eX(e);
                        if (this._pool ? .getNode(t) !== void 0) return {
                            modified: !1
                        };
                        this._unacknowledgedSets.set(n, m(e.opId));
                        let r = this._indexOfPosition(n);
                        if (i._attach(t, m(this._pool)), i._setParentLink(this, n), -1 === r) return this._insertAndSort(i), this._detachItemAssociatedToSetOperation(e.deletedId), {
                            reverse: [{
                                type: 5,
                                id: t
                            }],
                            modified: eH(this, [eJ(this._indexOfPosition(n), i)])
                        }; {
                            let t = this._items[r];
                            t._detach(), this._items[r] = i;
                            let o = eV(t._toOps(m(this._id), n, this._pool), e.id),
                                s = [eW(r, i)],
                                a = this._detachItemAssociatedToSetOperation(e.deletedId);
                            return a && s.push(a), {
                                modified: eH(this, s),
                                reverse: o
                            }
                        }
                    }
                    _attachChild(e, t) {
                        let n;
                        if (void 0 === this._pool) throw Error("Can't attach child if managed pool is not present");
                        return !1 !== (n = "set" === e.intent ? 1 === t ? this._applySetRemote(e) : 2 === t ? this._applySetAck(e) : this._applySetUndoRedo(e) : 1 === t ? this._applyRemoteInsert(e) : 2 === t ? this._applyInsertAck(e) : this._applyInsertUndoRedo(e)).modified && this.invalidate(), n
                    }
                    _detachChild(e) {
                        if (e) {
                            let t = m(e._parentKey),
                                n = e._toOps(m(this._id), t, this._pool),
                                i = this._items.indexOf(e);
                            return -1 === i ? {
                                modified: !1
                            } : (this._items.splice(i, 1), this.invalidate(), e._detach(), {
                                modified: eH(this, [eF(i)]),
                                reverse: n
                            })
                        }
                        return {
                            modified: !1
                        }
                    }
                    _applySetChildKeyRemote(e, t) {
                        if (this._implicitlyDeletedItems.has(t)) return this._implicitlyDeletedItems.delete(t), t._setParentLink(this, e), this._insertAndSort(t), {
                            modified: eH(this, [eJ(this._items.indexOf(t), t)]),
                            reverse: []
                        };
                        if (e === t._parentKey) return {
                            modified: !1
                        };
                        let n = this._indexOfPosition(e);
                        if (-1 === n) {
                            let n = this._items.indexOf(t);
                            t._setParentLink(this, e), this._sortItems();
                            let i = this._items.indexOf(t);
                            return i === n ? {
                                modified: !1
                            } : {
                                modified: eH(this, [eB(n, i, t)]),
                                reverse: []
                            }
                        } {
                            this._items[n]._setParentLink(this, eC(e, this._items[n + 1] ? ._parentPos));
                            let i = this._items.indexOf(t);
                            t._setParentLink(this, e), this._sortItems();
                            let r = this._items.indexOf(t);
                            return r === i ? {
                                modified: !1
                            } : {
                                modified: eH(this, [eB(i, r, t)]),
                                reverse: []
                            }
                        }
                    }
                    _applySetChildKeyAck(e, t) {
                        let n = m(t._parentKey);
                        if (this._implicitlyDeletedItems.has(t)) {
                            let n = this._indexOfPosition(e);
                            return this._implicitlyDeletedItems.delete(t), -1 !== n && this._items[n]._setParentLink(this, eC(e, this._items[n + 1] ? ._parentPos)), t._setParentLink(this, e), this._insertAndSort(t), {
                                modified: !1
                            }
                        } {
                            if (e === n) return {
                                modified: !1
                            };
                            let i = this._items.indexOf(t),
                                r = this._indexOfPosition(e); - 1 !== r && this._items[r]._setParentLink(this, eC(e, this._items[r + 1] ? ._parentPos)), t._setParentLink(this, e), this._sortItems();
                            let o = this._items.indexOf(t);
                            return i === o ? {
                                modified: !1
                            } : {
                                modified: eH(this, [eB(i, o, t)]),
                                reverse: []
                            }
                        }
                    }
                    _applySetChildKeyUndoRedo(e, t) {
                        let n = m(t._parentKey),
                            i = this._items.indexOf(t),
                            r = this._indexOfPosition(e); - 1 !== r && this._items[r]._setParentLink(this, eC(e, this._items[r + 1] ? ._parentPos)), t._setParentLink(this, e), this._sortItems();
                        let o = this._items.indexOf(t);
                        return i === o ? {
                            modified: !1
                        } : {
                            modified: eH(this, [eB(i, o, t)]),
                            reverse: [{
                                type: 1,
                                id: m(t._id),
                                parentKey: n
                            }]
                        }
                    }
                    _setChildKey(e, t, n) {
                        return 1 === n ? this._applySetChildKeyRemote(e, t) : 2 === n ? this._applySetChildKeyAck(e, t) : this._applySetChildKeyUndoRedo(e, t)
                    }
                    _apply(e, t) {
                        return super._apply(e, t)
                    }
                    _serialize() {
                        if ("HasParent" !== this.parent.type) throw Error("Cannot serialize LiveList if parent is missing");
                        return {
                            type: 1,
                            parentId: m(this.parent.node._id, "Parent node expected to have ID"),
                            parentKey: this.parent.key
                        }
                    }
                    get length() {
                        return this._items.length
                    }
                    push(e) {
                        return this._pool ? .assertStorageIsWritable(), this.insert(e, this.length)
                    }
                    insert(e, t) {
                        if (this._pool ? .assertStorageIsWritable(), t < 0 || t > this._items.length) throw Error(`Cannot insert list item at index "${t}". index should be between 0 and ${this._items.length}`);
                        let n = eC(this._items[t - 1] ? this._items[t - 1]._parentPos : void 0, this._items[t] ? this._items[t]._parentPos : void 0),
                            i = e4(e);
                        if (i._setParentLink(this, n), this._insertAndSort(i), this._pool && this._id) {
                            let e = this._pool.generateId();
                            i._attach(e, this._pool), this._pool.dispatch(i._toOps(this._id, n, this._pool), [{
                                type: 5,
                                id: e
                            }], new Map([
                                [this._id, eH(this, [eJ(t, i)])]
                            ]))
                        }
                    }
                    move(e, t) {
                        if (this._pool ? .assertStorageIsWritable(), t < 0) throw Error("targetIndex cannot be less than 0");
                        if (t >= this._items.length) throw Error("targetIndex cannot be greater or equal than the list length");
                        if (e < 0) throw Error("index cannot be less than 0");
                        if (e >= this._items.length) throw Error("index cannot be greater or equal than the list length");
                        let n = null,
                            i = null;
                        e < t ? (i = t === this._items.length - 1 ? void 0 : this._items[t + 1]._parentPos, n = this._items[t]._parentPos) : (i = this._items[t]._parentPos, n = 0 === t ? void 0 : this._items[t - 1]._parentPos);
                        let r = eC(n, i),
                            o = this._items[e],
                            s = o._getParentKeyOrThrow();
                        if (o._setParentLink(this, r), this._sortItems(), this._pool && this._id) {
                            let n = new Map([
                                [this._id, eH(this, [eB(e, t, o)])]
                            ]);
                            this._pool.dispatch([{
                                type: 1,
                                id: m(o._id),
                                opId: this._pool.generateOpId(),
                                parentKey: r
                            }], [{
                                type: 1,
                                id: m(o._id),
                                parentKey: s
                            }], n)
                        }
                    }
                    delete(e) {
                        if (this._pool ? .assertStorageIsWritable(), e < 0 || e >= this._items.length) throw Error(`Cannot delete list item at index "${e}". index should be between 0 and ${this._items.length-1}`);
                        let t = this._items[e];
                        if (t._detach(), this._items.splice(e, 1), this.invalidate(), this._pool) {
                            let n = t._id;
                            if (n) {
                                let i = new Map;
                                i.set(m(this._id), eH(this, [eF(e)])), this._pool.dispatch([{
                                    id: n,
                                    opId: this._pool.generateOpId(),
                                    type: 5
                                }], t._toOps(m(this._id), t._getParentKeyOrThrow()), i)
                            }
                        }
                    }
                    clear() {
                        if (this._pool ? .assertStorageIsWritable(), this._pool) {
                            let e = [],
                                t = [],
                                n = [];
                            for (let i of this._items) {
                                i._detach();
                                let r = i._id;
                                r && (e.push({
                                    type: 5,
                                    id: r,
                                    opId: this._pool.generateOpId()
                                }), t.push(...i._toOps(m(this._id), i._getParentKeyOrThrow())), n.push(eF(0)))
                            }
                            this._items = [], this.invalidate();
                            let i = new Map;
                            i.set(m(this._id), eH(this, n)), this._pool.dispatch(e, t, i)
                        } else {
                            for (let e of this._items) e._detach();
                            this._items = [], this.invalidate()
                        }
                    }
                    set(e, t) {
                        if (this._pool ? .assertStorageIsWritable(), e < 0 || e >= this._items.length) throw Error(`Cannot set list item at index "${e}". index should be between 0 and ${this._items.length-1}`);
                        let n = this._items[e],
                            i = n._getParentKeyOrThrow(),
                            r = n._id;
                        n._detach();
                        let o = e4(t);
                        if (o._setParentLink(this, i), this._items[e] = o, this.invalidate(), this._pool && this._id) {
                            let t = this._pool.generateId();
                            o._attach(t, this._pool);
                            let s = new Map;
                            s.set(this._id, eH(this, [eW(e, o)]));
                            let a = eV(o._toOps(this._id, i, this._pool), r);
                            this._unacknowledgedSets.set(i, m(a[0].opId));
                            let d = eV(n._toOps(this._id, i, void 0), t);
                            this._pool.dispatch(a, d, s)
                        }
                    }
                    toArray() {
                        return this._items.map(e => e3(e))
                    }
                    every(e) {
                        return this.toArray().every(e)
                    }
                    filter(e) {
                        return this.toArray().filter(e)
                    }
                    find(e) {
                        return this.toArray().find(e)
                    }
                    findIndex(e) {
                        return this.toArray().findIndex(e)
                    }
                    forEach(e) {
                        return this.toArray().forEach(e)
                    }
                    get(e) {
                        if (!(e < 0) && !(e >= this._items.length)) return e3(this._items[e])
                    }
                    indexOf(e, t) {
                        return this.toArray().indexOf(e, t)
                    }
                    lastIndexOf(e, t) {
                        return this.toArray().lastIndexOf(e, t)
                    }
                    map(e) {
                        return this._items.map((t, n) => e(e3(t), n))
                    }
                    some(e) {
                        return this.toArray().some(e)
                    }[Symbol.iterator]() {
                        return new ez(this._items)
                    }
                    _createAttachItemAndSort(e, t) {
                        let n = eX(e);
                        return n._attach(e.id, m(this._pool)), n._setParentLink(this, t), this._insertAndSort(n), {
                            newItem: n,
                            newIndex: this._indexOfPosition(t)
                        }
                    }
                    _shiftItemPosition(e, t) {
                        let n = eC(t, this._items.length > e + 1 ? this._items[e + 1] ? ._parentPos : void 0);
                        this._items[e]._setParentLink(this, n)
                    }
                    _toTreeNode(e) {
                        return {
                            type: "LiveList",
                            id: this._id ? ? e$(),
                            key: e,
                            payload: this._items.map((e, t) => e.toTreeNode(t.toString()))
                        }
                    }
                    toImmutable() {
                        return super.toImmutable()
                    }
                    _toImmutable() {
                        return this._items.map(e => e.toImmutable())
                    }
                    clone() {
                        return new e(this._items.map(e => e.clone()))
                    }
                },
                ez = class {
                    constructor(e) {
                        this._innerIterator = e[Symbol.iterator]()
                    }[Symbol.iterator]() {
                        return this
                    }
                    next() {
                        let e = this._innerIterator.next();
                        return e.done ? {
                            done: !0,
                            value: void 0
                        } : {
                            value: e3(e.value)
                        }
                    }
                };

            function eH(e, t) {
                return {
                    node: e,
                    type: "LiveList",
                    updates: t
                }
            }

            function eW(e, t) {
                return {
                    index: e,
                    type: "set",
                    item: t instanceof eM ? t.data : t
                }
            }

            function eF(e) {
                return {
                    index: e,
                    type: "delete"
                }
            }

            function eJ(e, t) {
                return {
                    index: e,
                    type: "insert",
                    item: t instanceof eM ? t.data : t
                }
            }

            function eB(e, t, n) {
                return {
                    index: t,
                    type: "move",
                    previousIndex: e,
                    item: n instanceof eM ? n.data : n
                }
            }

            function eV(e, t) {
                return e.map((e, n) => 0 === n ? { ...e,
                    intent: "set",
                    deletedId: t
                } : e)
            }
            var eq = e => e,
                eG = class e extends ex {
                    constructor(e) {
                        if (super(), this.unacknowledgedSet = new Map, e) {
                            let t = [];
                            for (let [n, i] of e) {
                                let e = e4(i);
                                e._setParentLink(this, n), t.push([n, e])
                            }
                            this._map = new Map(t)
                        } else this._map = new Map
                    }
                    _toOps(e, t, n) {
                        if (void 0 === this._id) throw Error("Cannot serialize item is not attached");
                        let i = [],
                            r = {
                                id: this._id,
                                opId: n ? .generateOpId(),
                                type: 7,
                                parentId: e,
                                parentKey: t
                            };
                        for (let [e, t] of (i.push(r), this._map)) i.push(...t._toOps(this._id, e, n));
                        return i
                    }
                    static _deserialize([t, n], i, r) {
                        let o = new e;
                        o._attach(t, r);
                        let s = i.get(t);
                        if (void 0 === s) return o;
                        for (let [e, t] of s) {
                            let n = eQ([e, t], i, r);
                            n._setParentLink(o, t.parentKey), o._map.set(t.parentKey, n), o.invalidate()
                        }
                        return o
                    }
                    _attach(e, t) {
                        for (let [n, i] of (super._attach(e, t), this._map)) e1(i) && i._attach(t.generateId(), t)
                    }
                    _attachChild(e, t) {
                        let n;
                        if (void 0 === this._pool) throw Error("Can't attach child if managed pool is not present");
                        let {
                            id: i,
                            parentKey: r,
                            opId: o
                        } = e, s = eX(e);
                        if (void 0 !== this._pool.getNode(i)) return {
                            modified: !1
                        };
                        if (2 === t) {
                            let e = this.unacknowledgedSet.get(r);
                            if (e === o) return this.unacknowledgedSet.delete(r), {
                                modified: !1
                            };
                            if (void 0 !== e) return {
                                modified: !1
                            }
                        } else 1 === t && this.unacknowledgedSet.delete(r);
                        let a = this._map.get(r);
                        if (a) {
                            let e = m(this._id);
                            n = a._toOps(e, r), a._detach()
                        } else n = [{
                            type: 5,
                            id: i
                        }];
                        return s._setParentLink(this, r), s._attach(i, this._pool), this._map.set(r, s), this.invalidate(), {
                            modified: {
                                node: this,
                                type: "LiveMap",
                                updates: {
                                    [r]: {
                                        type: "update"
                                    }
                                }
                            },
                            reverse: n
                        }
                    }
                    _detach() {
                        for (let e of (super._detach(), this._map.values())) e._detach()
                    }
                    _detachChild(e) {
                        let t = m(this._id),
                            n = m(e._parentKey),
                            i = e._toOps(t, n, this._pool);
                        for (let [t, n] of this._map) n === e && (this._map.delete(t), this.invalidate());
                        return e._detach(), {
                            modified: {
                                node: this,
                                type: "LiveMap",
                                updates: {
                                    [n]: {
                                        type: "delete"
                                    }
                                }
                            },
                            reverse: i
                        }
                    }
                    _serialize() {
                        if ("HasParent" !== this.parent.type) throw Error("Cannot serialize LiveMap if parent is missing");
                        return {
                            type: 2,
                            parentId: m(this.parent.node._id, "Parent node expected to have ID"),
                            parentKey: this.parent.key
                        }
                    }
                    get(e) {
                        let t = this._map.get(e);
                        if (void 0 !== t) return e3(t)
                    }
                    set(e, t) {
                        this._pool ? .assertStorageIsWritable();
                        let n = this._map.get(e);
                        n && n._detach();
                        let i = e4(t);
                        if (i._setParentLink(this, e), this._map.set(e, i), this.invalidate(), this._pool && this._id) {
                            let t = this._pool.generateId();
                            i._attach(t, this._pool);
                            let r = new Map;
                            r.set(this._id, {
                                node: this,
                                type: "LiveMap",
                                updates: {
                                    [e]: {
                                        type: "update"
                                    }
                                }
                            });
                            let o = i._toOps(this._id, e, this._pool);
                            this.unacknowledgedSet.set(e, m(o[0].opId)), this._pool.dispatch(i._toOps(this._id, e, this._pool), n ? n._toOps(this._id, e) : [{
                                type: 5,
                                id: t
                            }], r)
                        }
                    }
                    get size() {
                        return this._map.size
                    }
                    has(e) {
                        return this._map.has(e)
                    }
                    delete(e) {
                        this._pool ? .assertStorageIsWritable();
                        let t = this._map.get(e);
                        if (void 0 === t) return !1;
                        if (t._detach(), this._map.delete(e), this.invalidate(), this._pool && t._id) {
                            let n = m(this._id),
                                i = new Map;
                            i.set(n, {
                                node: this,
                                type: "LiveMap",
                                updates: {
                                    [e]: {
                                        type: "delete"
                                    }
                                }
                            }), this._pool.dispatch([{
                                type: 5,
                                id: t._id,
                                opId: this._pool.generateOpId()
                            }], t._toOps(n, e), i)
                        }
                        return !0
                    }
                    entries() {
                        let e = this._map.entries();
                        return {
                            [Symbol.iterator]() {
                                return this
                            },
                            next() {
                                let t = e.next();
                                return t.done ? {
                                    done: !0,
                                    value: void 0
                                } : {
                                    value: [t.value[0], e3(t.value[1])]
                                }
                            }
                        }
                    }[Symbol.iterator]() {
                        return this.entries()
                    }
                    keys() {
                        return this._map.keys()
                    }
                    values() {
                        let e = this._map.values();
                        return {
                            [Symbol.iterator]() {
                                return this
                            },
                            next() {
                                let t = e.next();
                                return t.done ? {
                                    done: !0,
                                    value: void 0
                                } : {
                                    value: e3(t.value)
                                }
                            }
                        }
                    }
                    forEach(e) {
                        for (let t of this) e(t[1], t[0], this)
                    }
                    _toTreeNode(e) {
                        return {
                            type: "LiveMap",
                            id: this._id ? ? e$(),
                            key: e,
                            payload: Array.from(this._map.entries()).map(([e, t]) => t.toTreeNode(e))
                        }
                    }
                    toImmutable() {
                        return super.toImmutable()
                    }
                    _toImmutable() {
                        let e = new Map;
                        for (let [t, n] of this._map) e.set(t, n.toImmutable());
                        return eq(e)
                    }
                    clone() {
                        return new e(Array.from(this._map).map(([e, t]) => [e, t.clone()]))
                    }
                },
                eY = class e extends ex {
                    static _buildRootAndParentToChildren(e) {
                        let t = new Map,
                            n = null;
                        for (let [i, r] of e)
                            if (0 !== r.type || void 0 !== r.parentId && void 0 !== r.parentKey) {
                                let e = [i, r],
                                    n = t.get(r.parentId);
                                void 0 !== n ? n.push(e) : t.set(r.parentId, [e])
                            } else n = [i, r];
                        if (null === n) throw Error("Root can't be null");
                        return [n, t]
                    }
                    static _fromItems(t, n) {
                        let [i, r] = e._buildRootAndParentToChildren(t);
                        return e._deserialize(i, r, n)
                    }
                    constructor(e = {}) {
                        super(), this._propToLastUpdate = new Map;
                        let t = M(e);
                        for (let e of Object.keys(t)) {
                            let n = t[e];
                            e1(n) && n._setParentLink(this, e)
                        }
                        this._map = new Map(Object.entries(t))
                    }
                    _toOps(e, t, n) {
                        if (void 0 === this._id) throw Error("Cannot serialize item is not attached");
                        let i = n ? .generateOpId(),
                            r = [],
                            o = {
                                type: 4,
                                id: this._id,
                                opId: i,
                                parentId: e,
                                parentKey: t,
                                data: {}
                            };
                        for (let [e, t] of (r.push(o), this._map)) e1(t) ? r.push(...t._toOps(this._id, e, n)) : o.data[e] = t;
                        return r
                    }
                    static _deserialize([t, n], i, r) {
                        let o = new e(n.data);
                        return o._attach(t, r), this._deserializeChildren(o, i, r)
                    }
                    static _deserializeChildren(e, t, n) {
                        let i = t.get(m(e._id));
                        if (void 0 === i) return e;
                        for (let [r, o] of i) {
                            let i = function([e, t], n, i) {
                                switch (t.type) {
                                    case 0:
                                        return eY._deserialize([e, t], n, i);
                                    case 1:
                                        return ej._deserialize([e, t], n, i);
                                    case 2:
                                        return eG._deserialize([e, t], n, i);
                                    case 3:
                                        return t.data;
                                    default:
                                        throw Error("Unexpected CRDT type")
                                }
                            }([r, o], t, n);
                            e0(i) && i._setParentLink(e, o.parentKey), e._map.set(o.parentKey, i), e.invalidate()
                        }
                        return e
                    }
                    _attach(e, t) {
                        for (let [n, i] of (super._attach(e, t), this._map)) e1(i) && i._attach(t.generateId(), t)
                    }
                    _attachChild(e, t) {
                        let n;
                        if (void 0 === this._pool) throw Error("Can't attach child if managed pool is not present");
                        let {
                            id: i,
                            opId: r,
                            parentKey: o
                        } = e, s = eZ(e);
                        if (void 0 !== this._pool.getNode(i)) return this._propToLastUpdate.get(o) === r && this._propToLastUpdate.delete(o), {
                            modified: !1
                        };
                        if (0 === t) this._propToLastUpdate.set(o, m(r));
                        else if (void 0 === this._propToLastUpdate.get(o));
                        else if (this._propToLastUpdate.get(o) === r) return this._propToLastUpdate.delete(o), {
                            modified: !1
                        };
                        else return {
                            modified: !1
                        };
                        let a = m(this._id),
                            d = this._map.get(o);
                        return e1(d) ? (n = d._toOps(a, o), d._detach()) : n = void 0 === d ? [{
                            type: 6,
                            id: a,
                            key: o
                        }] : [{
                            type: 3,
                            id: a,
                            data: {
                                [o]: d
                            }
                        }], this._map.set(o, s), this.invalidate(), e0(s) && (s._setParentLink(this, o), s._attach(i, this._pool)), {
                            reverse: n,
                            modified: {
                                node: this,
                                type: "LiveObject",
                                updates: {
                                    [o]: {
                                        type: "update"
                                    }
                                }
                            }
                        }
                    }
                    _detachChild(e) {
                        if (e) {
                            let t = m(this._id),
                                n = m(e._parentKey),
                                i = e._toOps(t, n, this._pool);
                            for (let [t, n] of this._map) n === e && (this._map.delete(t), this.invalidate());
                            return e._detach(), {
                                modified: {
                                    node: this,
                                    type: "LiveObject",
                                    updates: {
                                        [n]: {
                                            type: "delete"
                                        }
                                    }
                                },
                                reverse: i
                            }
                        }
                        return {
                            modified: !1
                        }
                    }
                    _detach() {
                        for (let e of (super._detach(), this._map.values())) e1(e) && e._detach()
                    }
                    _apply(e, t) {
                        return 3 === e.type ? this._applyUpdate(e, t) : 6 === e.type ? this._applyDeleteObjectKey(e, t) : super._apply(e, t)
                    }
                    _serialize() {
                        let e = {};
                        for (let [t, n] of this._map) e1(n) || (e[t] = n);
                        return "HasParent" === this.parent.type && this.parent.node._id ? {
                            type: 0,
                            parentId: this.parent.node._id,
                            parentKey: this.parent.key,
                            data: e
                        } : {
                            type: 0,
                            data: e
                        }
                    }
                    _applyUpdate(e, t) {
                        let n = !1,
                            i = m(this._id),
                            r = [],
                            o = {
                                type: 3,
                                id: i,
                                data: {}
                            };
                        for (let t in e.data) {
                            let e = this._map.get(t);
                            e1(e) ? (r.push(...e._toOps(i, t)), e._detach()) : void 0 !== e ? o.data[t] = e : void 0 === e && r.push({
                                type: 6,
                                id: i,
                                key: t
                            })
                        }
                        let s = {};
                        for (let i in e.data) {
                            let r = e.data[i];
                            if (void 0 === r) continue;
                            if (t) this._propToLastUpdate.set(i, m(e.opId));
                            else if (void 0 === this._propToLastUpdate.get(i)) n = !0;
                            else {
                                if (this._propToLastUpdate.get(i) !== e.opId) continue;
                                this._propToLastUpdate.delete(i);
                                continue
                            }
                            let o = this._map.get(i);
                            e1(o) && o._detach(), n = !0, s[i] = {
                                type: "update"
                            }, this._map.set(i, r), this.invalidate()
                        }
                        return 0 !== Object.keys(o.data).length && r.unshift(o), n ? {
                            modified: {
                                node: this,
                                type: "LiveObject",
                                updates: s
                            },
                            reverse: r
                        } : {
                            modified: !1
                        }
                    }
                    _applyDeleteObjectKey(e, t) {
                        let n = e.key;
                        if (!1 === this._map.has(n) || !t && void 0 !== this._propToLastUpdate.get(n)) return {
                            modified: !1
                        };
                        let i = this._map.get(n),
                            r = m(this._id),
                            o = [];
                        return e1(i) ? (o = i._toOps(r, e.key), i._detach()) : void 0 !== i && (o = [{
                            type: 3,
                            id: r,
                            data: {
                                [n]: i
                            }
                        }]), this._map.delete(n), this.invalidate(), {
                            modified: {
                                node: this,
                                type: "LiveObject",
                                updates: {
                                    [e.key]: {
                                        type: "delete"
                                    }
                                }
                            },
                            reverse: o
                        }
                    }
                    toObject() {
                        return Object.fromEntries(this._map)
                    }
                    set(e, t) {
                        this._pool ? .assertStorageIsWritable(), this.update({
                            [e]: t
                        })
                    }
                    get(e) {
                        return this._map.get(e)
                    }
                    delete(e) {
                        let t;
                        this._pool ? .assertStorageIsWritable();
                        let n = this._map.get(e);
                        if (void 0 === n) return;
                        if (void 0 === this._pool || void 0 === this._id) {
                            e1(n) && n._detach(), this._map.delete(e), this.invalidate();
                            return
                        }
                        e1(n) ? (n._detach(), t = n._toOps(this._id, e)) : t = [{
                            type: 3,
                            data: {
                                [e]: n
                            },
                            id: this._id
                        }], this._map.delete(e), this.invalidate();
                        let i = new Map;
                        i.set(this._id, {
                            node: this,
                            type: "LiveObject",
                            updates: {
                                [e]: {
                                    type: "delete"
                                }
                            }
                        }), this._pool.dispatch([{
                            type: 6,
                            key: e,
                            id: this._id,
                            opId: this._pool.generateOpId()
                        }], t, i)
                    }
                    update(e) {
                        if (this._pool ? .assertStorageIsWritable(), void 0 === this._pool || void 0 === this._id) {
                            for (let t in e) {
                                let n = e[t];
                                if (void 0 === n) continue;
                                let i = this._map.get(t);
                                e1(i) && i._detach(), e1(n) && n._setParentLink(this, t), this._map.set(t, n), this.invalidate()
                            }
                            return
                        }
                        let t = [],
                            n = [],
                            i = this._pool.generateOpId(),
                            r = {},
                            o = {
                                id: this._id,
                                type: 3,
                                data: {}
                            },
                            s = {};
                        for (let a in e) {
                            let d = e[a];
                            if (void 0 === d) continue;
                            let l = this._map.get(a);
                            if (e1(l) ? (n.push(...l._toOps(this._id, a)), l._detach()) : void 0 === l ? n.push({
                                    type: 6,
                                    id: this._id,
                                    key: a
                                }) : o.data[a] = l, e1(d)) {
                                d._setParentLink(this, a), d._attach(this._pool.generateId(), this._pool);
                                let e = d._toOps(this._id, a, this._pool),
                                    n = e.find(e => e.parentId === this._id);
                                n && this._propToLastUpdate.set(a, m(n.opId)), t.push(...e)
                            } else r[a] = d, this._propToLastUpdate.set(a, i);
                            this._map.set(a, d), this.invalidate(), s[a] = {
                                type: "update"
                            }
                        }
                        0 !== Object.keys(o.data).length && n.unshift(o), 0 !== Object.keys(r).length && t.unshift({
                            opId: i,
                            id: this._id,
                            type: 3,
                            data: r
                        });
                        let a = new Map;
                        a.set(this._id, {
                            node: this,
                            type: "LiveObject",
                            updates: s
                        }), this._pool.dispatch(t, n, a)
                    }
                    toImmutable() {
                        return super.toImmutable()
                    }
                    toTreeNode(e) {
                        return super.toTreeNode(e)
                    }
                    _toTreeNode(e) {
                        let t = this._id ? ? e$();
                        return {
                            type: "LiveObject",
                            id: t,
                            key: e,
                            payload: Array.from(this._map.entries()).map(([e, n]) => e1(n) ? n.toTreeNode(e) : {
                                type: "Json",
                                id: `${t}:${e}`,
                                key: e,
                                payload: n
                            })
                        }
                    }
                    _toImmutable() {
                        let e = {};
                        for (let [t, n] of this._map) e[t] = e0(n) ? n.toImmutable() : n;
                        return e
                    }
                    clone() {
                        return new e(Object.fromEntries(Array.from(this._map).map(([e, t]) => [e, e0(t) ? t.clone() : U(t)])))
                    }
                };

            function eX(e) {
                return e4(eZ(e))
            }

            function eZ(e) {
                switch (e.type) {
                    case 8:
                        return e.data;
                    case 4:
                        return new eY(e.data);
                    case 7:
                        return new eG;
                    case 2:
                        return new ej([]);
                    default:
                        return f(e, "Unknown creation Op")
                }
            }

            function eQ([e, t], n, i) {
                switch (t.type) {
                    case 0:
                        return eY._deserialize([e, t], n, i);
                    case 1:
                        return ej._deserialize([e, t], n, i);
                    case 2:
                        return eG._deserialize([e, t], n, i);
                    case 3:
                        return eM._deserialize([e, t], n, i);
                    default:
                        throw Error("Unexpected CRDT type")
                }
            }

            function e0(e) {
                return e2(e) || e instanceof eG || e instanceof eY
            }

            function e1(e) {
                return e0(e) || e instanceof eM
            }

            function e2(e) {
                return e instanceof ej
            }

            function e3(e) {
                return e instanceof eM ? e.data : e instanceof ej || e instanceof eG || e instanceof eY ? e : f(e, "Unknown AbstractCrdt")
            }

            function e4(e) {
                return e instanceof eY || e instanceof eG || e instanceof ej ? e : new eM(e)
            }

            function e5(e, t) {
                return void 0 === e ? t : "LiveObject" === e.type && "LiveObject" === t.type ? function(e, t) {
                    let n = e.updates;
                    for (let [e, i] of L(t.updates)) n[e] = i;
                    return { ...t,
                        updates: n
                    }
                }(e, t) : "LiveMap" === e.type && "LiveMap" === t.type ? function(e, t) {
                    let n = e.updates;
                    for (let [e, i] of L(t.updates)) n[e] = i;
                    return { ...t,
                        updates: n
                    }
                }(e, t) : "LiveList" === e.type && "LiveList" === t.type ? function(e, t) {
                    let n = e.updates;
                    return { ...t,
                        updates: n.concat(t.updates)
                    }
                }(e, t) : t
            }
            async function e6(e, t, n, i) {
                let r = n.length > 0 ? n[n.length - 1] : 0,
                    o = 0;
                for (;;) {
                    o++;
                    let s = e();
                    try {
                        return await s
                    } catch (e) {
                        if (i ? .(e)) throw e;
                        if (o >= t) throw Error(`Failed after ${t} attempts: ${String(e)}`)
                    }
                    let a = n[o - 1] ? ? r;
                    await
                    function(e) {
                        return new Promise(t => setTimeout(t, e))
                    }(a)
                }
            }

            function e9(e) {
                return `${e}_${e$()}`
            }

            function e8() {
                return e9("th")
            }

            function e7() {
                return e9("cm")
            }

            function te(e) {
                return Array.isArray(e)
            }
            var tt = /^[a-zA-Z_][a-zA-Z0-9_]*$/;

            function tn(e) {
                let t = [],
                    n = Object.entries(e),
                    i = [],
                    r = [],
                    o = [];
                return n.forEach(([e, t]) => {
                    if (!tt.test(e)) throw Error("Key must only contain letters, numbers, _");
                    to(t) ? i.push([e, t]) : ts(t) ? r.push([e, t]) : "object" != typeof t || "startsWith" in t || o.push([e, t])
                }), t = [...ti(i), ...tr(r)], o.forEach(([e, n]) => {
                    let i = Object.entries(n),
                        r = [],
                        o = [];
                    i.forEach(([t, n]) => {
                        if (tc(t)) throw Error("Key cannot be empty");
                        to(n) ? r.push([td(e, t), n]) : ts(n) && o.push([td(e, t), n])
                    }), t = [...t, ...ti(r), ...tr(o)]
                }), t.map(({
                    key: e,
                    operator: t,
                    value: n
                }) => ta(e, t, tl(n))).join(" AND ")
            }
            var ti = e => {
                    let t = [];
                    return e.forEach(([e, n]) => {
                        t.push({
                            key: e,
                            operator: ":",
                            value: n
                        })
                    }), t
                },
                tr = e => {
                    let t = [];
                    return e.forEach(([e, n]) => {
                        "startsWith" in n && "string" == typeof n.startsWith && t.push({
                            key: e,
                            operator: "^",
                            value: n.startsWith
                        })
                    }), t
                },
                to = e => "string" == typeof e || "number" == typeof e || "boolean" == typeof e,
                ts = e => "object" == typeof e && null !== e && "startsWith" in e,
                ta = (e, t, n) => `${e}${t}${n}`,
                td = (e, t) => t ? `${e}[${JSON.stringify(t)}]` : e,
                tl = e => {
                    if ("string" == typeof e) {
                        if (tc(e)) throw Error("Value cannot be empty");
                        return JSON.stringify(e)
                    }
                    return e.toString()
                },
                tc = e => !e || "" === e.toString().trim(),
                tu = ((a = tu || {})[a.UPDATE_PRESENCE = 100] = "UPDATE_PRESENCE", a[a.BROADCAST_EVENT = 103] = "BROADCAST_EVENT", a[a.FETCH_STORAGE = 200] = "FETCH_STORAGE", a[a.UPDATE_STORAGE = 201] = "UPDATE_STORAGE", a[a.FETCH_YDOC = 300] = "FETCH_YDOC", a[a.UPDATE_YDOC = 301] = "UPDATE_YDOC", a);

            function th(e, t) {
                let n = !1,
                    i = { ...e
                    };
                return Object.keys(t).forEach(e => {
                    let r = t[e];
                    i[e] !== r && (void 0 === r ? delete i[e] : i[e] = r, n = !0)
                }), n ? i : e
            }
            var tp = class {
                    constructor() {
                        this._ev = v()
                    }
                    get didInvalidate() {
                        return this._ev.observable
                    }
                    invalidate() {
                        void 0 !== this._cache && (this._cache = void 0, this._ev.notify())
                    }
                    get current() {
                        return this._cache ? ? (this._cache = this._toImmutable())
                    }
                },
                tf = class extends tp {
                    constructor() {
                        super(), this._connections = new Map, this._presences = new Map, this._users = new Map
                    }
                    connectionIds() {
                        return this._connections.keys()
                    }
                    _toImmutable() {
                        return $(Array.from(this._presences.keys()).map(e => this.getUser(Number(e))))
                    }
                    clearOthers() {
                        this._connections = new Map, this._presences = new Map, this._users = new Map, this.invalidate()
                    }
                    _getUser(e) {
                        let t = this._connections.get(e),
                            n = this._presences.get(e);
                        if (void 0 !== t && void 0 !== n) return function(e, t) {
                            let {
                                connectionId: n,
                                id: i,
                                info: r
                            } = e, o = ed(e.scopes);
                            return eq(M({
                                connectionId: n,
                                id: i,
                                info: r,
                                canWrite: o,
                                canComment: el(e.scopes),
                                isReadOnly: !o,
                                presence: t
                            }))
                        }(t, n)
                    }
                    getUser(e) {
                        let t = this._users.get(e);
                        if (t) return t;
                        let n = this._getUser(e);
                        if (n) return this._users.set(e, n), n
                    }
                    _invalidateUser(e) {
                        this._users.has(e) && this._users.delete(e), this.invalidate()
                    }
                    setConnection(e, t, n, i) {
                        this._connections.set(e, eq({
                            connectionId: e,
                            id: t,
                            info: n,
                            scopes: i
                        })), this._presences.has(e) && this._invalidateUser(e)
                    }
                    removeConnection(e) {
                        this._connections.delete(e), this._presences.delete(e), this._invalidateUser(e)
                    }
                    setOther(e, t) {
                        this._presences.set(e, eq(M(t))), this._connections.has(e) && this._invalidateUser(e)
                    }
                    patchOther(e, t) {
                        let n = this._presences.get(e);
                        if (void 0 === n) return;
                        let i = th(n, t);
                        n !== i && (this._presences.set(e, eq(i)), this._invalidateUser(e))
                    }
                },
                t_ = class extends tp {
                    constructor(e) {
                        super(), this._data = eq(M(e))
                    }
                    _toImmutable() {
                        return this._data
                    }
                    patch(e) {
                        let t = this._data,
                            n = th(t, e);
                        t !== n && (this._data = eq(n), this.invalidate())
                    }
                },
                tm = class extends tp {
                    constructor(e) {
                        super(), this._value = eq(e)
                    }
                    _toImmutable() {
                        return this._value
                    }
                    set(e) {
                        this._value = eq(e), this.invalidate()
                    }
                },
                ty = class extends tp {
                    constructor(...e) {
                        super();
                        let t = e.pop();
                        this._refs = e, this._refs.forEach(e => {
                            e.didInvalidate.subscribe(() => this.invalidate())
                        }), this._transform = t
                    }
                    _toImmutable() {
                        return this._transform(...this._refs.map(e => e.current))
                    }
                };

            function tg(e, t) {
                return {
                    type: "User",
                    id: `${t.connectionId}`,
                    key: e,
                    payload: {
                        connectionId: t.connectionId,
                        id: t.id,
                        info: t.info,
                        presence: t.presence,
                        isReadOnly: !t.canWrite
                    }
                }
            }
            var tv = [2e3, 2e3, 2e3, 2e3, 2e3, 2e3, 2e3, 2e3, 2e3, 2e3],
                tb = class extends Error {
                    constructor(e, t, n) {
                        super(e), this.message = e, this.status = t, this.details = n
                    }
                };

            function tE(e) {
                return "public" === e.type ? e.publicApiKey : e.token.raw
            }

            function tw(e) {
                var t;
                let n = tS("throttle", e.throttle ? ? 100, 16, 1e3),
                    i = tS("lostConnectionTimeout", e.lostConnectionTimeout ? ? 5e3, 200, 3e4, 1e3),
                    r = function(e) {
                        if (void 0 !== e) return tS("backgroundKeepAliveTimeout", e, 15e3)
                    }(e.backgroundKeepAliveTimeout),
                    o = "string" == typeof(t = e.baseUrl) && t.startsWith("http") ? t : "https://api.liveblocks.io",
                    s = function(e) {
                        let t = function(e) {
                                let {
                                    publicApiKey: t,
                                    authEndpoint: n
                                } = e;
                                if (void 0 !== n && void 0 !== t) throw Error("You cannot simultaneously use `publicApiKey` and `authEndpoint` options. Please pick one and leave the other option unspecified. For more information: https://liveblocks.io/docs/api-reference/liveblocks-client#createClient");
                                if ("string" == typeof t) {
                                    if (t.startsWith("sk_")) throw Error("Invalid `publicApiKey` option. The value you passed is a secret key, which should not be used from the client. Please only ever pass a public key here. For more information: https://liveblocks.io/docs/api-reference/liveblocks-client#createClientPublicKey");
                                    if (!t.startsWith("pk_")) throw Error("Invalid key. Please use the public key format: pk_<public key>. For more information: https://liveblocks.io/docs/api-reference/liveblocks-client#createClientPublicKey");
                                    return {
                                        type: "public",
                                        publicApiKey: t
                                    }
                                }
                                if ("string" == typeof n) return {
                                    type: "private",
                                    url: n
                                };
                                if ("function" == typeof n) return {
                                    type: "custom",
                                    callback: n
                                };
                                if (void 0 !== n) throw Error("The `authEndpoint` option must be a string or a function. For more information: https://liveblocks.io/docs/api-reference/liveblocks-client#createClientAuthEndpoint");
                                throw Error("Invalid Liveblocks client options. Please provide either a `publicApiKey` or `authEndpoint` option. They cannot both be empty. For more information: https://liveblocks.io/docs/api-reference/liveblocks-client#createClient")
                            }(e),
                            n = new Set,
                            i = [],
                            r = [],
                            o = new Map;

                        function s(e, t) {
                            return "comments:read" === e ? t.includes("comments:read") || t.includes("comments:write") || t.includes("room:read") || t.includes("room:write") : "room:read" === e && (t.includes("room:read") || t.includes("room:write"))
                        }
                        async function a(i) {
                            let r = e.polyfills ? .fetch ? ? ("undefined" == typeof window ? void 0 : window.fetch);
                            if ("private" === t.type) {
                                if (void 0 === r) throw new G("To use Liveblocks client in a non-DOM environment with a url as auth endpoint, you need to provide a fetch polyfill.");
                                let e = ec((await eu(r, t.url, {
                                    room: i.roomId
                                })).token);
                                if (n.has(e.raw)) throw new G("The same Liveblocks auth token was issued from the backend before. Caching Liveblocks tokens is not supported.");
                                return e
                            }
                            if ("custom" === t.type) {
                                let e = await t.callback(i.roomId);
                                if (e && "object" == typeof e) {
                                    if ("string" == typeof e.token) return ec(e.token);
                                    if ("string" == typeof e.error) {
                                        let t = `Authentication failed: ${"reason"in e&&"string"==typeof e.reason?e.reason:"Forbidden"}`;
                                        if ("forbidden" === e.error) throw new G(t);
                                        throw Error(t)
                                    }
                                }
                                throw Error('Your authentication callback function should return a token, but it did not. Hint: the return value should look like: { token: "..." }')
                            }
                            throw Error("Unexpected authentication type. Must be private or custom.")
                        }
                        return {
                            reset: function() {
                                n.clear(), i.length = 0, r.length = 0, o.clear()
                            },
                            getAuthValue: async function(e) {
                                let d;
                                if ("public" === t.type) return {
                                    type: "public",
                                    publicApiKey: t.publicApiKey
                                };
                                let l = function(e) {
                                    let t = Math.ceil(Date.now() / 1e3);
                                    for (let n = i.length - 1; n >= 0; n--) {
                                        let o = i[n];
                                        if (r[n] <= t) {
                                            i.splice(n, 1), r.splice(n, 1);
                                            continue
                                        }
                                        if ("id" === o.parsed.k) return o;
                                        if ("acc" === o.parsed.k) {
                                            if (!e.roomId && 0 === Object.entries(o.parsed.perms).length) return o;
                                            for (let [t, n] of Object.entries(o.parsed.perms))
                                                if (e.roomId) {
                                                    if (t.includes("*") && e.roomId.startsWith(t.replace("*", "")) || e.roomId === t && s(e.requestedScope, n)) return o
                                                } else if (t.includes("*") && s(e.requestedScope, n)) return o
                                        }
                                    }
                                }(e);
                                if (void 0 !== l) return {
                                    type: "secret",
                                    token: l
                                };
                                e.roomId ? void 0 === (d = o.get(e.roomId)) && (d = a(e), o.set(e.roomId, d)) : void 0 === (d = o.get("liveblocks-user-token")) && (d = a(e), o.set("liveblocks-user-token", d));
                                try {
                                    let e = await d,
                                        t = Math.floor(Date.now() / 1e3) + (e.parsed.exp - e.parsed.iat) - 30;
                                    return n.add(e.raw), "sec-legacy" !== e.parsed.k && (i.push(e), r.push(t)), {
                                        type: "secret",
                                        token: e
                                    }
                                } finally {
                                    e.roomId ? o.delete(e.roomId) : o.delete("liveblocks-user-token")
                                }
                            }
                        }
                    }(e),
                    a = new Map;

                function d(e) {
                    let t = () => {
                        if (e.unsubs.delete(t)) {
                            if (0 === e.unsubs.size) {
                                var n;
                                (n = e.room).id, a.delete(n.id), n.destroy()
                            }
                        } else T("This leave function was already called. Calling it more than once has no effect.")
                    };
                    return e.unsubs.add(t), {
                        room: e.room,
                        leave: t
                    }
                }
                let l = ey(null),
                    {
                        getInboxNotifications: u,
                        getInboxNotificationsSince: h,
                        getUnreadInboxNotificationsCount: p,
                        markAllInboxNotificationsAsRead: _,
                        markInboxNotificationAsRead: y,
                        deleteAllInboxNotifications: b,
                        deleteInboxNotification: E,
                        getThreads: w,
                        getThreadsSince: S
                    } = function({
                        baseUrl: e,
                        authManager: t,
                        currentUserIdStore: n,
                        fetcher: i
                    }) {
                        async function r(r, o, s) {
                            let a;
                            r.startsWith("/v2/c/") || N("Expected a /v2/c/* endpoint");
                            let d = await t.getAuthValue({
                                requestedScope: "comments:read"
                            });
                            if ("secret" === d.type && "acc" === d.token.parsed.k) {
                                let e = d.token.parsed.uid;
                                n.set(() => e)
                            }
                            let l = eT(e, r, s),
                                c = await i(l.toString(), { ...o,
                                    headers: { ...o ? .headers,
                                        Authorization : `Bearer ${tE(d)}`
                                    }
                                });
                            if (!c.ok && c.status >= 400 && c.status < 600) {
                                let e;
                                try {
                                    let t = await c.json();
                                    e = new tT(t.message, c.status, t)
                                } catch {
                                    e = new tT(c.statusText, c.status)
                                }
                                throw e
                            }
                            try {
                                a = await c.json()
                            } catch {
                                a = {}
                            }
                            return a
                        }
                        async function o() {
                            let e = await r(eS `/v2/c/inbox-notifications`, void 0, {});
                            return {
                                threads: e.threads.map(ev),
                                inboxNotifications: e.inboxNotifications.map(eb),
                                requestedAt: new Date(e.meta.requestedAt)
                            }
                        }
                        async function s(e) {
                            let t = await r(eS `/v2/c/inbox-notifications`, void 0, {
                                since: e.since.toISOString()
                            });
                            return {
                                threads: {
                                    updated: t.threads.map(ev),
                                    deleted: t.deletedThreads.map(eE)
                                },
                                inboxNotifications: {
                                    updated: t.inboxNotifications.map(eb),
                                    deleted: t.deletedInboxNotifications.map(ew)
                                },
                                requestedAt: new Date(t.meta.requestedAt)
                            }
                        }
                        async function a() {
                            let {
                                count: e
                            } = await r(eS `/v2/c/inbox-notifications/count`);
                            return e
                        }
                        async function d() {
                            await r(eS `/v2/c/inbox-notifications/read`, {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify({
                                    inboxNotificationIds: "all"
                                })
                            })
                        }
                        async function l(e) {
                            await r(eS `/v2/c/inbox-notifications/read`, {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify({
                                    inboxNotificationIds: e
                                })
                            })
                        }
                        let c = new e_(async e => {
                            let t = e.flat();
                            return await l(t), t
                        }, {
                            delay: 50
                        });
                        return {
                            getInboxNotifications: o,
                            getInboxNotificationsSince: s,
                            getUnreadInboxNotificationsCount: a,
                            markAllInboxNotificationsAsRead: d,
                            markInboxNotificationAsRead: async function(e) {
                                await c.get(e)
                            },
                            deleteAllInboxNotifications: async function() {
                                await r(eS `/v2/c/inbox-notifications`, {
                                    method: "DELETE"
                                })
                            },
                            deleteInboxNotification: async function(e) {
                                await r(eS `/v2/c/inbox-notifications/${e}`, {
                                    method: "DELETE"
                                })
                            },
                            getThreads: async function(e) {
                                let t;
                                e ? .query && (t = tn(e.query));
                                let n = await r(eS `/v2/c/threads`, void 0, {
                                    query: t
                                });
                                return {
                                    threads: n.threads.map(ev),
                                    inboxNotifications: n.inboxNotifications.map(eb),
                                    requestedAt: new Date(n.meta.requestedAt)
                                }
                            },
                            getThreadsSince: async function(e) {
                                let t;
                                e ? .query && (t = tn(e.query));
                                let n = await r(eS `/v2/c/threads`, void 0, {
                                    since: e.since.toISOString(),
                                    query: t
                                });
                                return {
                                    threads: {
                                        updated: n.threads.map(ev),
                                        deleted: n.deletedThreads.map(eE)
                                    },
                                    inboxNotifications: {
                                        updated: n.inboxNotifications.map(eb),
                                        deleted: n.deletedInboxNotifications.map(ew)
                                    },
                                    requestedAt: new Date(n.meta.requestedAt)
                                }
                            }
                        }
                    }({
                        baseUrl: o,
                        fetcher: e.polyfills ? .fetch || fetch,
                        authManager: s,
                        currentUserIdStore: l
                    }),
                    O = e.resolveUsers,
                    I = tO(() => !O, "Set the resolveUsers option in createClient to specify user info."),
                    A = em(new e_(async e => {
                        let t = e.flat(),
                            n = await O ? .({
                                userIds: t
                            });
                        return I(), n ? ? t.map(() => void 0)
                    }, {
                        delay: 50
                    })),
                    C = e.resolveRoomsInfo,
                    P = tO(() => !C, "Set the resolveRoomsInfo option in createClient to specify room info."),
                    D = em(new e_(async e => {
                        let t = e.flat(),
                            n = await C ? .({
                                roomIds: t
                            });
                        return P(), n ? ? t.map(() => void 0)
                    }, {
                        delay: 50
                    }));
                return Object.defineProperty({
                    enterRoom: function(t, ...l) {
                        var u;
                        let h = a.get(t);
                        if (void 0 !== h) return d(h);
                        let p = l[0] ? ? {},
                            _ = function(e, t) {
                                let n, i, r;
                                let o = e.initialPresence,
                                    s = e.initialStorage,
                                    [a, d] = function() {
                                        let e = "undefined" != typeof document ? document : void 0,
                                            t = {
                                                current: null
                                            };

                                        function n() {
                                            e ? .visibilityState === "hidden" ? t.current = t.current ? ? Date.now() : t.current = null
                                        }
                                        return e ? .addEventListener("visibilitychange", n), [t, () => {
                                            e ? .removeEventListener("visibilitychange", n)
                                        }]
                                    }(),
                                    l = { ...t.delegates,
                                        canZombie: () => void 0 !== t.backgroundKeepAliveTimeout && null !== a.current && Date.now() > a.current + t.backgroundKeepAliveTimeout && "synchronizing" !== es()
                                    },
                                    c = new ea(l, t.enableDebugLogging),
                                    u = {
                                        buffer: {
                                            flushTimerID: void 0,
                                            lastFlushedAt: 0,
                                            presenceUpdates: {
                                                type: "full",
                                                data: o
                                            },
                                            messages: [],
                                            storageOperations: []
                                        },
                                        staticSessionInfo: new tm(null),
                                        dynamicSessionInfo: new tm(null),
                                        myPresence: new t_(o),
                                        others: new tf,
                                        initialStorage: s,
                                        idFactory: null,
                                        provider: void 0,
                                        onProviderUpdate: v(),
                                        clock: 0,
                                        opClock: 0,
                                        nodes: new Map,
                                        root: void 0,
                                        undoStack: [],
                                        redoStack: [],
                                        pausedHistory: null,
                                        activeBatch: null,
                                        unacknowledgedOps: new Map,
                                        opStackTraces: void 0
                                    },
                                    h = e => e(),
                                    p = t.unstable_batchedUpdates ? ? h,
                                    _ = !1;
                                c.events.onMessage.subscribe(function(e) {
                                    if ("string" != typeof e.data) return;
                                    let t = function(e) {
                                        let t = x(e);
                                        return void 0 === t ? null : te(t) ? $(t.map(e => G(e))) : $([G(t)])
                                    }(e.data);
                                    if (null === t || 0 === t.length) return;
                                    let n = {
                                        storageUpdates: new Map,
                                        others: []
                                    };
                                    p(() => {
                                        for (let e of t) switch (e.type) {
                                            case 101:
                                                {
                                                    let t = function(e) {
                                                        u.others.setConnection(e.actor, e.id, e.info, e.scopes), u.buffer.messages.push({
                                                            type: 100,
                                                            data: u.myPresence.current,
                                                            targetActor: e.actor
                                                        }), Y();
                                                        let t = u.others.getUser(e.actor);
                                                        return t ? {
                                                            type: "enter",
                                                            user: t
                                                        } : void 0
                                                    }(e);t && n.others.push(t);
                                                    break
                                                }
                                            case 100:
                                                {
                                                    let t = function(e) {
                                                        if (void 0 !== e.targetActor) {
                                                            let t = u.others.getUser(e.actor);
                                                            u.others.setOther(e.actor, e.data);
                                                            let n = u.others.getUser(e.actor);
                                                            if (void 0 === t && void 0 !== n) return {
                                                                type: "enter",
                                                                user: n
                                                            }
                                                        } else u.others.patchOther(e.actor, e.data);
                                                        let t = u.others.getUser(e.actor);
                                                        return t ? {
                                                            type: "update",
                                                            updates: e.data,
                                                            user: t
                                                        } : void 0
                                                    }(e);t && n.others.push(t);
                                                    break
                                                }
                                            case 103:
                                                {
                                                    let t = u.others.current;b.customEvent.notify({
                                                        connectionId: e.actor,
                                                        user: e.actor < 0 ? null : t.find(t => t.connectionId === e.actor) ? ? null,
                                                        event: e.event
                                                    });
                                                    break
                                                }
                                            case 102:
                                                {
                                                    let t = function(e) {
                                                        let t = u.others.getUser(e.actor);
                                                        return t ? (u.others.removeConnection(e.actor), {
                                                            type: "leave",
                                                            user: t
                                                        }) : null
                                                    }(e);t && n.others.push(t);
                                                    break
                                                }
                                            case 300:
                                                b.ydoc.notify(e);
                                                break;
                                            case 104:
                                                n.others.push(function(e, t) {
                                                    var n;
                                                    let i;
                                                    for (let r of (u.dynamicSessionInfo.set({
                                                            actor: e.actor,
                                                            nonce: e.nonce,
                                                            scopes: e.scopes
                                                        }), u.idFactory = (n = e.actor, i = 0, () => `${n}:${i++}`), M(t), u.others.connectionIds())) void 0 === e.users[r] && u.others.removeConnection(r);
                                                    for (let t in e.users) {
                                                        let n = e.users[t],
                                                            i = Number(t);
                                                        u.others.setConnection(i, n.id, n.info, n.scopes)
                                                    }
                                                    return {
                                                        type: "reset"
                                                    }
                                                }(e, h));
                                                break;
                                            case 200:
                                                ee(e);
                                                break;
                                            case 201:
                                                for (let [t, i] of J(e.ops, !1).updates.storageUpdates) n.storageUpdates.set(t, e5(n.storageUpdates.get(t), i));
                                                break;
                                            case 299:
                                                k("Storage mutation rejection error", e.reason);
                                                break;
                                            case 400:
                                            case 407:
                                            case 401:
                                            case 408:
                                            case 405:
                                            case 406:
                                            case 402:
                                            case 403:
                                            case 404:
                                                b.comments.notify(e)
                                        }
                                        W(n, h)
                                    })
                                }), c.events.statusDidChange.subscribe(function(e) {
                                    let t = c.authValue;
                                    if (null !== t) {
                                        let e = tE(t);
                                        if (e !== n) {
                                            if (n = e, "secret" === t.type) {
                                                let e = t.token.parsed;
                                                u.staticSessionInfo.set({
                                                    userId: "sec-legacy" === e.k ? e.id : e.uid,
                                                    userInfo: "sec-legacy" === e.k ? e.info : e.ui
                                                })
                                            } else u.staticSessionInfo.set({
                                                userId: void 0,
                                                userInfo: void 0
                                            })
                                        }
                                    }
                                    p(() => {
                                        b.status.notify(e), M(h)
                                    })
                                }), c.events.statusDidChange.subscribe(function(e) {
                                    "reconnecting" === e ? i = setTimeout(() => {
                                        p(() => {
                                            b.lostConnection.notify("lost"), _ = !0, u.others.clearOthers(), W({
                                                others: [{
                                                    type: "reset"
                                                }]
                                            }, h)
                                        })
                                    }, t.lostConnectionTimeout) : (clearTimeout(i), _ && ("disconnected" === e ? p(() => {
                                        b.lostConnection.notify("failed")
                                    }) : p(() => {
                                        b.lostConnection.notify("restored")
                                    }), _ = !1))
                                }), c.events.didConnect.subscribe(function() {
                                    u.buffer.presenceUpdates = {
                                        type: "full",
                                        data: { ...u.myPresence.current
                                        }
                                    }, null !== Z && en({
                                        flush: !1
                                    }), Y()
                                }), c.events.didDisconnect.subscribe(function() {
                                    clearTimeout(u.buffer.flushTimerID)
                                }), c.events.onLiveblocksError.subscribe(e => {
                                    p(() => {
                                        b.error.notify(e)
                                    })
                                });
                                let y = {
                                        roomId: t.roomId,
                                        getNode: e => u.nodes.get(e),
                                        addNode: (e, t) => void u.nodes.set(e, t),
                                        deleteNode: e => void u.nodes.delete(e),
                                        generateId: () => `${F()}:${u.clock++}`,
                                        generateOpId: () => `${F()}:${u.opClock++}`,
                                        dispatch(e, t, n) {
                                            let i = u.activeBatch;
                                            if (i) {
                                                for (let t of e) i.ops.push(t);
                                                for (let [e, t] of n) i.updates.storageUpdates.set(e, e5(i.updates.storageUpdates.get(e), t));
                                                i.reverseOps.unshift(...t)
                                            } else p(() => {
                                                H(t, h), u.redoStack.length = 0, X(e), W({
                                                    storageUpdates: n
                                                }, h)
                                            })
                                        },
                                        assertStorageIsWritable: () => {
                                            let e = u.dynamicSessionInfo.current ? .scopes;
                                            if (void 0 !== e && !ed(e)) throw Error("Cannot write to storage with a read only user, please ensure the user has write permissions")
                                        }
                                    },
                                    b = {
                                        status: v(),
                                        lostConnection: v(),
                                        customEvent: v(),
                                        self: v(),
                                        myPresence: v(),
                                        others: v(),
                                        error: v(),
                                        storageBatch: v(),
                                        history: v(),
                                        storageDidLoad: v(),
                                        storageStatus: v(),
                                        ydoc: v(),
                                        comments: v()
                                    };
                                async function E(e, n, i, r) {
                                    e.startsWith("/v2/c/rooms/") || N("Expected a /v2/c/rooms/* endpoint");
                                    let o = eT(t.baseUrl, e, r),
                                        s = t.polyfills ? .fetch || fetch;
                                    return await s(o, { ...i,
                                        headers: { ...i ? .headers,
                                            Authorization : `Bearer ${tE(n)}`
                                        }
                                    })
                                }
                                async function w(e, t) {
                                    return E(eS `/v2/c/rooms/${t}/storage`, e, {
                                        method: "GET",
                                        headers: {
                                            "Content-Type": "application/json"
                                        }
                                    })
                                }
                                async function S(e, n) {
                                    if (!c.authValue) throw Error("Not authorized");
                                    return E("/send-message" === e ? eS `/v2/c/rooms/${t.roomId}/send-message` : eS `/v2/c/rooms/${t.roomId}/text-metadata`, c.authValue, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify(n)
                                    })
                                }
                                async function O(e, n) {
                                    if (!c.authValue) throw Error("Not authorized");
                                    return E(eS `/v2/c/rooms/${t.roomId}/text-mentions`, c.authValue, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            userId: e,
                                            mentionId: n
                                        })
                                    })
                                }
                                async function I(e) {
                                    if (!c.authValue) throw Error("Not authorized");
                                    return E(eS `/v2/c/rooms/${t.roomId}/text-mentions/${e}`, c.authValue, {
                                        method: "DELETE"
                                    })
                                }
                                async function A(e, n) {
                                    let i = await l.authenticate();
                                    return E(eS `/v2/c/rooms/${t.roomId}/text-metadata`, i, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            type: e,
                                            rootKey: n
                                        })
                                    })
                                }
                                async function C() {
                                    let e = await l.authenticate();
                                    return E(eS `/v2/c/rooms/${t.roomId}/versions`, e, {
                                        method: "GET"
                                    })
                                }
                                async function P(e) {
                                    let n = await l.authenticate();
                                    return E(eS `/v2/c/rooms/${t.roomId}/y-version/${e}`, n, {
                                        method: "GET"
                                    })
                                }
                                async function D() {
                                    let e = await l.authenticate();
                                    return E(eS `/v2/c/rooms/${t.roomId}/version`, e, {
                                        method: "POST"
                                    })
                                }

                                function L(e) {
                                    let n = JSON.stringify(e),
                                        i = u.dynamicSessionInfo.current ? .nonce;
                                    if (t.unstable_fallbackToHTTP && i && new TextEncoder().encode(n).length > 1047552) {
                                        S("/send-message", {
                                            nonce: i,
                                            messages: e
                                        }).then(e => {
                                            e.ok || 403 !== e.status || c.reconnect()
                                        }), T("Message was too large for websockets and sent over HTTP instead");
                                        return
                                    }
                                    c.send(n)
                                }
                                let R = new ty(u.staticSessionInfo, u.dynamicSessionInfo, u.myPresence, (e, t, n) => {
                                    if (null === e || null === t) return null; {
                                        let i = ed(t.scopes);
                                        return {
                                            connectionId: t.actor,
                                            id: e.userId,
                                            info: e.userInfo,
                                            presence: n,
                                            canWrite: i,
                                            canComment: el(t.scopes)
                                        }
                                    }
                                });

                                function M(e) {
                                    let t = R.current;
                                    null !== t && t !== r && (e(() => {
                                        b.self.notify(t)
                                    }), r = t)
                                }
                                let K = new ty(R, e => null !== e ? tg("Me", e) : null);

                                function z(e, t) {
                                    u.undoStack.length >= 50 && u.undoStack.shift(), u.undoStack.push(e), q(t)
                                }

                                function H(e, t) {
                                    null !== u.pausedHistory ? u.pausedHistory.unshift(...e) : z(e, t)
                                }

                                function W(e, t) {
                                    let n = e.storageUpdates,
                                        i = e.others;
                                    t(() => {
                                        if (void 0 !== i && i.length > 0) {
                                            let e = u.others.current;
                                            for (let t of i) b.others.notify({ ...t,
                                                others: e
                                            })
                                        }
                                        if (e.presence && (M(h), b.myPresence.notify(u.myPresence.current)), void 0 !== n && n.size > 0) {
                                            let e = Array.from(n.values());
                                            b.storageBatch.notify(e)
                                        }
                                        eu()
                                    })
                                }

                                function F() {
                                    let e = u.dynamicSessionInfo.current;
                                    if (e) return e.actor;
                                    throw Error("Internal. Tried to get connection id but connection was never open")
                                }

                                function J(e, t) {
                                    let n = {
                                            reverse: [],
                                            storageUpdates: new Map,
                                            presence: !1
                                        },
                                        i = new Set,
                                        r = e.map(e => "presence" === e.type || e.opId ? e : { ...e,
                                            opId: y.generateOpId()
                                        });
                                    for (let e of r)
                                        if ("presence" === e.type) {
                                            let t = {
                                                type: "presence",
                                                data: {}
                                            };
                                            for (let n in e.data) t.data[n] = u.myPresence.current[n];
                                            if (u.myPresence.patch(e.data), null === u.buffer.presenceUpdates) u.buffer.presenceUpdates = {
                                                type: "partial",
                                                data: e.data
                                            };
                                            else
                                                for (let t in e.data) u.buffer.presenceUpdates.data[t] = e.data[t];
                                            n.reverse.unshift(t), n.presence = !0
                                        } else {
                                            let r;
                                            if (t) r = 0;
                                            else {
                                                let t = m(e.opId);
                                                r = u.unacknowledgedOps.delete(t) ? 2 : 1
                                            }
                                            let o = function(e, t) {
                                                if (5 === e.type && "ACK" === e.id) return {
                                                    modified: !1
                                                };
                                                switch (e.type) {
                                                    case 6:
                                                    case 3:
                                                    case 5:
                                                        {
                                                            let n = u.nodes.get(e.id);
                                                            if (void 0 === n) return {
                                                                modified: !1
                                                            };
                                                            return n._apply(e, 0 === t)
                                                        }
                                                    case 1:
                                                        {
                                                            let n = u.nodes.get(e.id);
                                                            if (void 0 === n) return {
                                                                modified: !1
                                                            };
                                                            if ("HasParent" === n.parent.type && e2(n.parent.node)) return n.parent.node._setChildKey(eN(e.parentKey), n, t);
                                                            return {
                                                                modified: !1
                                                            }
                                                        }
                                                    case 4:
                                                    case 2:
                                                    case 7:
                                                    case 8:
                                                        {
                                                            if (void 0 === e.parentId) return {
                                                                modified: !1
                                                            };
                                                            let n = u.nodes.get(e.parentId);
                                                            if (void 0 === n) return {
                                                                modified: !1
                                                            };
                                                            return n._attachChild(e, t)
                                                        }
                                                }
                                            }(e, r);
                                            if (o.modified) {
                                                let t = o.modified.node._id;
                                                t && i.has(t) || (n.storageUpdates.set(m(o.modified.node._id), e5(n.storageUpdates.get(m(o.modified.node._id)), o.modified)), n.reverse.unshift(...o.reverse)), (2 === e.type || 7 === e.type || 4 === e.type) && i.add(m(e.id))
                                            }
                                        }
                                    return {
                                        ops: r,
                                        reverse: n.reverse,
                                        updates: {
                                            storageUpdates: n.storageUpdates,
                                            presence: n.presence
                                        }
                                    }
                                }

                                function B() {
                                    return u.undoStack.length > 0
                                }

                                function V() {
                                    return u.redoStack.length > 0
                                }

                                function q(e) {
                                    e(() => {
                                        b.history.notify({
                                            canUndo: B(),
                                            canRedo: V()
                                        })
                                    })
                                }

                                function G(e) {
                                    return null === e || "string" == typeof e || "number" == typeof e || "boolean" == typeof e || te(e) ? null : e
                                }

                                function Y() {
                                    let e = u.buffer.storageOperations;
                                    if (e.length > 0) {
                                        for (let t of e) u.unacknowledgedOps.set(m(t.opId), t);
                                        eu()
                                    }
                                    if ("connected" !== c.getStatus()) {
                                        u.buffer.storageOperations = [];
                                        return
                                    }
                                    let n = Date.now(),
                                        i = n - u.buffer.lastFlushedAt;
                                    if (i >= t.throttleDelay) {
                                        let e = function() {
                                            let e = [];
                                            for (let t of (u.buffer.presenceUpdates && e.push("full" === u.buffer.presenceUpdates.type ? {
                                                    type: 100,
                                                    targetActor: -1,
                                                    data: u.buffer.presenceUpdates.data
                                                } : {
                                                    type: 100,
                                                    data: u.buffer.presenceUpdates.data
                                                }), u.buffer.messages)) e.push(t);
                                            return u.buffer.storageOperations.length > 0 && e.push({
                                                type: 201,
                                                ops: u.buffer.storageOperations
                                            }), e
                                        }();
                                        if (0 === e.length) return;
                                        L(e), u.buffer = {
                                            flushTimerID: void 0,
                                            lastFlushedAt: n,
                                            messages: [],
                                            storageOperations: [],
                                            presenceUpdates: null
                                        }
                                    } else clearTimeout(u.buffer.flushTimerID), u.buffer.flushTimerID = setTimeout(Y, t.throttleDelay - i)
                                }

                                function X(e) {
                                    let {
                                        storageOperations: t
                                    } = u.buffer;
                                    for (let n of e) t.push(n);
                                    Y()
                                }
                                let Z = null,
                                    Q = null;

                                function ee(e) {
                                    let t = new Map(u.unacknowledgedOps);
                                    ! function(e, t) {
                                        if (0 === e.items.length) throw Error("Internal error: cannot load storage without items");
                                        void 0 !== u.root ? function(e, t) {
                                            if (void 0 === u.root) return;
                                            let n = new Map;
                                            for (let [e, t] of u.nodes) n.set(e, t._serialize());
                                            W(J(function(e, t) {
                                                let n = [];
                                                return e.forEach((e, i) => {
                                                    t.get(i) || n.push({
                                                        type: 5,
                                                        id: i
                                                    })
                                                }), t.forEach((t, i) => {
                                                    let r = e.get(i);
                                                    if (r) 0 === t.type && (0 !== r.type || JSON.stringify(t.data) !== JSON.stringify(r.data)) && n.push({
                                                        type: 3,
                                                        id: i,
                                                        data: t.data
                                                    }), t.parentKey !== r.parentKey && n.push({
                                                        type: 1,
                                                        id: i,
                                                        parentKey: m(t.parentKey, "Parent key must not be missing")
                                                    });
                                                    else switch (t.type) {
                                                        case 3:
                                                            n.push({
                                                                type: 8,
                                                                id: i,
                                                                parentId: t.parentId,
                                                                parentKey: t.parentKey,
                                                                data: t.data
                                                            });
                                                            break;
                                                        case 1:
                                                            n.push({
                                                                type: 2,
                                                                id: i,
                                                                parentId: t.parentId,
                                                                parentKey: t.parentKey
                                                            });
                                                            break;
                                                        case 0:
                                                            if (void 0 === t.parentId || void 0 === t.parentKey) throw Error("Internal error. Cannot serialize storage root into an operation");
                                                            n.push({
                                                                type: 4,
                                                                id: i,
                                                                parentId: t.parentId,
                                                                parentKey: t.parentKey,
                                                                data: t.data
                                                            });
                                                            break;
                                                        case 2:
                                                            n.push({
                                                                type: 7,
                                                                id: i,
                                                                parentId: t.parentId,
                                                                parentKey: t.parentKey
                                                            })
                                                    }
                                                }), n
                                            }(n, new Map(e)), !1).updates, t)
                                        }(e.items, t) : u.root = eY._fromItems(e.items, y);
                                        let n = R.current ? .canWrite ? ? !0,
                                            i = u.undoStack.length;
                                        for (let e in u.initialStorage)
                                            if (void 0 === u.root.get(e)) {
                                                if (n) {
                                                    var r;
                                                    u.root.set(e, void 0 === (r = u.initialStorage[e]) ? void 0 : e0(r) ? r.clone() : U(r))
                                                } else T(`Attempted to populate missing storage key '${e}', but current user has no write access`)
                                            }
                                        u.undoStack.length = i
                                    }(e, h),
                                    function(e, t) {
                                        if (0 === e.size) return;
                                        let n = [],
                                            i = J(Array.from(e.values()), !0);
                                        n.push({
                                            type: 201,
                                            ops: i.ops
                                        }), W(i.updates, t), L(n)
                                    }(t, h), Q ? .(), eu(), b.storageDidLoad.notify()
                                }
                                async function et() {
                                    if (!c.authValue) return;
                                    let e = await w(c.authValue, t.roomId);
                                    ee({
                                        type: 200,
                                        items: await e.json()
                                    })
                                }

                                function en(e) {
                                    let n = u.buffer.messages;
                                    t.unstable_streamData ? et() : n.some(e => 200 === e.type) || n.push({
                                        type: 200
                                    }), e.flush && Y()
                                }

                                function ei() {
                                    return null === Z && (en({
                                        flush: !0
                                    }), Z = new Promise(e => {
                                        Q = e
                                    }), eu()), Z
                                }

                                function er() {
                                    let e = u.root;
                                    return void 0 !== e ? e : (ei(), null)
                                }
                                async function eo() {
                                    return void 0 !== u.root ? Promise.resolve({
                                        root: u.root
                                    }) : (await ei(), {
                                        root: m(u.root)
                                    })
                                }

                                function es() {
                                    return void 0 === u.root ? null === Z ? "not-loaded" : "loading" : 0 === u.unacknowledgedOps.size ? "synchronized" : "synchronizing"
                                }
                                let ec = es();

                                function eu() {
                                    let e = es();
                                    ec !== e && (ec = e, b.storageStatus.notify(e))
                                }

                                function ep() {
                                    return null !== R.current
                                }
                                async function ef() {
                                    for (; !ep();) {
                                        let {
                                            promise: e,
                                            resolve: t
                                        } = g(), n = ek.self.subscribeOnce(t), i = ek.status.subscribeOnce(t);
                                        await e, n(), i()
                                    }
                                }

                                function ey() {
                                    return null !== er()
                                }
                                async function eO() {
                                    for (; !ey();) await eo()
                                }
                                let eI = new ty(u.others, e => e.map((e, t) => tg(`Other ${t}`, e))),
                                    ek = {
                                        status: b.status.observable,
                                        lostConnection: b.lostConnection.observable,
                                        customEvent: b.customEvent.observable,
                                        others: b.others.observable,
                                        self: b.self.observable,
                                        myPresence: b.myPresence.observable,
                                        error: b.error.observable,
                                        storage: b.storageBatch.observable,
                                        storageBatch: b.storageBatch.observable,
                                        history: b.history.observable,
                                        storageDidLoad: b.storageDidLoad.observable,
                                        storageStatus: b.storageStatus.observable,
                                        ydoc: b.ydoc.observable,
                                        comments: b.comments.observable
                                    };
                                async function eA(e, t, n) {
                                    return E(e, await l.authenticate(), n, t)
                                }
                                async function eC(e, t, n) {
                                    let i;
                                    let r = await eA(e, n, t);
                                    if (!r.ok && r.status >= 400 && r.status < 600) {
                                        let e;
                                        try {
                                            let t = await r.json();
                                            e = new tb(t.message, r.status, t)
                                        } catch {
                                            e = new tb(r.statusText, r.status)
                                        }
                                        throw e
                                    }
                                    try {
                                        i = await r.json()
                                    } catch {
                                        i = {}
                                    }
                                    return i
                                }
                                async function eP(e) {
                                    let n = await eA(eS `/v2/c/rooms/${t.roomId}/threads`, {
                                        since: e ? .since ? .toISOString()
                                    }, {
                                        headers: {
                                            "Content-Type": "application/json"
                                        }
                                    });
                                    if (n.ok) {
                                        let e = await n.json();
                                        return {
                                            threads: {
                                                updated: e.data.map(ev),
                                                deleted: e.deletedThreads.map(eE)
                                            },
                                            inboxNotifications: {
                                                updated: e.inboxNotifications.map(eb),
                                                deleted: e.deletedInboxNotifications.map(ew)
                                            },
                                            requestedAt: new Date(e.meta.requestedAt)
                                        }
                                    }
                                    if (404 === n.status) return {
                                        threads: {
                                            updated: [],
                                            deleted: []
                                        },
                                        inboxNotifications: {
                                            updated: [],
                                            deleted: []
                                        },
                                        requestedAt: new Date
                                    };
                                    throw Error("There was an error while getting threads.")
                                }
                                async function eD(e) {
                                    let n;
                                    e ? .query && (n = tn(e.query));
                                    let i = await eA(eS `/v2/c/rooms/${t.roomId}/threads`, {
                                        query: n
                                    }, {
                                        headers: {
                                            "Content-Type": "application/json"
                                        }
                                    });
                                    if (i.ok) {
                                        let e = await i.json();
                                        return {
                                            threads: e.data.map(ev),
                                            inboxNotifications: e.inboxNotifications.map(eb),
                                            requestedAt: new Date(e.meta.requestedAt)
                                        }
                                    }
                                    if (404 === i.status) return {
                                        threads: [],
                                        inboxNotifications: [],
                                        deletedThreads: [],
                                        deletedInboxNotifications: [],
                                        requestedAt: new Date
                                    };
                                    throw Error("There was an error while getting threads.")
                                }
                                async function eL(e) {
                                    let n = await eA(eS `/v2/c/rooms/${t.roomId}/thread-with-notification/${e}`);
                                    if (n.ok) {
                                        let e = await n.json();
                                        return {
                                            thread: ev(e.thread),
                                            inboxNotification: e.inboxNotification ? eb(e.inboxNotification) : void 0
                                        }
                                    }
                                    if (404 === n.status) return {
                                        thread: void 0,
                                        inboxNotification: void 0
                                    };
                                    throw Error(`There was an error while getting thread ${e}.`)
                                }
                                async function eR({
                                    metadata: e,
                                    body: n,
                                    commentId: i = e7(),
                                    threadId: r = e8(),
                                    attachmentIds: o
                                }) {
                                    return ev(await eC(eS `/v2/c/rooms/${t.roomId}/threads`, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            id: r,
                                            comment: {
                                                id: i,
                                                body: n,
                                                attachmentIds: o
                                            },
                                            metadata: e
                                        })
                                    }))
                                }
                                async function ex(e) {
                                    await eC(eS `/v2/c/rooms/${t.roomId}/threads/${e}`, {
                                        method: "DELETE"
                                    })
                                }
                                async function eU({
                                    metadata: e,
                                    threadId: n
                                }) {
                                    return await eC(eS `/v2/c/rooms/${t.roomId}/threads/${n}/metadata`, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify(e)
                                    })
                                }
                                async function e$(e) {
                                    await eC(eS `/v2/c/rooms/${t.roomId}/threads/${e}/mark-as-resolved`, {
                                        method: "POST"
                                    })
                                }
                                async function eM(e) {
                                    await eC(eS `/v2/c/rooms/${t.roomId}/threads/${e}/mark-as-unresolved`, {
                                        method: "POST"
                                    })
                                }
                                async function eK({
                                    threadId: e,
                                    commentId: n = e7(),
                                    body: i,
                                    attachmentIds: r
                                }) {
                                    return eg(await eC(eS `/v2/c/rooms/${t.roomId}/threads/${e}/comments`, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            id: n,
                                            body: i,
                                            attachmentIds: r
                                        })
                                    }))
                                }
                                async function ej({
                                    threadId: e,
                                    commentId: n,
                                    body: i,
                                    attachmentIds: r
                                }) {
                                    return eg(await eC(eS `/v2/c/rooms/${t.roomId}/threads/${e}/comments/${n}`, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            body: i,
                                            attachmentIds: r
                                        })
                                    }))
                                }
                                async function ez({
                                    threadId: e,
                                    commentId: n
                                }) {
                                    await eC(eS `/v2/c/rooms/${t.roomId}/threads/${e}/comments/${n}`, {
                                        method: "DELETE"
                                    })
                                }
                                async function eH({
                                    threadId: e,
                                    commentId: n,
                                    emoji: i
                                }) {
                                    var r;
                                    return { ...r = await eC(eS `/v2/c/rooms/${t.roomId}/threads/${e}/comments/${n}/reactions`, {
                                            method: "POST",
                                            headers: {
                                                "Content-Type": "application/json"
                                            },
                                            body: JSON.stringify({
                                                emoji: i
                                            })
                                        }),
                                        createdAt: new Date(r.createdAt)
                                    }
                                }
                                async function eW({
                                    threadId: e,
                                    commentId: n,
                                    emoji: i
                                }) {
                                    await eC(eS `/v2/c/rooms/${t.roomId}/threads/${e}/comments/${n}/reactions/${i}`, {
                                        method: "DELETE"
                                    })
                                }
                                async function eF(e, n = {}) {
                                    let i = n.signal,
                                        r = i ? new DOMException(`Upload of attachment ${e.id} was aborted.`, "AbortError") : void 0;
                                    if (i ? .aborted) throw r;
                                    let o = e => {
                                        if (i ? .aborted) throw r;
                                        if (e instanceof tb && 413 === e.status) throw e;
                                        return !1
                                    };
                                    if (e.size <= 5242880) return e6(() => eC(eS `/v2/c/rooms/${t.roomId}/attachments/${e.id}/upload/${encodeURIComponent(e.name)}`, {
                                        method: "PUT",
                                        body: e.file,
                                        signal: i
                                    }, {
                                        fileSize: e.size
                                    }), 10, tv, o); {
                                        let n;
                                        let s = [],
                                            a = await e6(() => eC(eS `/v2/c/rooms/${t.roomId}/attachments/${e.id}/multipart/${encodeURIComponent(e.name)}`, {
                                                method: "POST",
                                                signal: i
                                            }, {
                                                fileSize: e.size
                                            }), 10, tv, o);
                                        try {
                                            n = a.uploadId;
                                            let d = function(e) {
                                                let t = [],
                                                    n = 0;
                                                for (; n < e.size;) {
                                                    let i = Math.min(n + 5242880, e.size);
                                                    t.push({
                                                        partNumber: t.length + 1,
                                                        part: e.slice(n, i)
                                                    }), n = i
                                                }
                                                return t
                                            }(e.file);
                                            if (i ? .aborted) throw r;
                                            for (let n of function(e, t) {
                                                    let n = [];
                                                    for (let t = 0, i = e.length; t < i; t += 5) n.push(e.slice(t, t + 5));
                                                    return n
                                                }(d, 0)) {
                                                let r = [];
                                                for (let {
                                                        part: s,
                                                        partNumber: d
                                                    } of n) r.push(e6(() => eC(eS `/v2/c/rooms/${t.roomId}/attachments/${e.id}/multipart/${a.uploadId}/${String(d)}`, {
                                                    method: "PUT",
                                                    body: s,
                                                    signal: i
                                                }), 10, tv, o));
                                                s.push(...await Promise.all(r))
                                            }
                                            if (i ? .aborted) throw r;
                                            let l = s.sort((e, t) => e.partNumber - t.partNumber);
                                            return eC(eS `/v2/c/rooms/${t.roomId}/attachments/${e.id}/multipart/${n}/complete`, {
                                                method: "POST",
                                                headers: {
                                                    "Content-Type": "application/json"
                                                },
                                                body: JSON.stringify({
                                                    parts: l
                                                }),
                                                signal: i
                                            })
                                        } catch (i) {
                                            if (n && i ? .name && ("AbortError" === i.name || "TimeoutError" === i.name)) try {
                                                await eA(eS `/v2/c/rooms/${t.roomId}/attachments/${e.id}/multipart/${n}`, void 0, {
                                                    method: "DELETE"
                                                })
                                            } catch (e) {}
                                            throw i
                                        }
                                    }
                                }
                                async function eJ(e) {
                                    let {
                                        urls: n
                                    } = await eC(eS `/v2/c/rooms/${t.roomId}/attachments/presigned-urls`, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            attachmentIds: e
                                        })
                                    });
                                    return n
                                }
                                let eB = new e_(async e => {
                                        let t = e.flat();
                                        return (await eJ(t)).map(e => e ? ? Error("There was an error while getting this attachment's URL"))
                                    }, {
                                        delay: 50
                                    }),
                                    eV = em(eB);
                                async function eq(e, t) {
                                    let n;
                                    let i = await l.authenticate(),
                                        r = await E(e, i, t);
                                    if (!r.ok && r.status >= 400 && r.status < 600) {
                                        let e;
                                        try {
                                            let t = await r.json();
                                            e = new tT(t.message, r.status, t)
                                        } catch {
                                            e = new tT(r.statusText, r.status)
                                        }
                                        throw e
                                    }
                                    try {
                                        n = await r.json()
                                    } catch {
                                        n = {}
                                    }
                                    return n
                                }
                                async function eG(e) {
                                    await eq(eS `/v2/c/rooms/${t.roomId}/inbox-notifications/read`, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            inboxNotificationIds: e
                                        })
                                    })
                                }
                                let eX = new e_(async e => {
                                    let t = e.flat();
                                    return await eG(t), t
                                }, {
                                    delay: 50
                                });
                                async function eZ(e) {
                                    await eX.get(e)
                                }
                                return Object.defineProperty({
                                    [eh]: {
                                        get presenceBuffer() {
                                            return U(u.buffer.presenceUpdates ? .data ? ? null)
                                        },
                                        get undoStack() {
                                            return U(u.undoStack)
                                        },
                                        get nodeCount() {
                                            return u.nodes.size
                                        },
                                        getProvider: () => u.provider,
                                        setProvider(e) {
                                            u.provider = e, u.onProviderUpdate.notify()
                                        },
                                        onProviderUpdate: u.onProviderUpdate.observable,
                                        reportTextEditor: A,
                                        createTextMention: O,
                                        deleteTextMention: I,
                                        listTextVersions: C,
                                        getTextVersion: P,
                                        createTextVersion: D,
                                        getSelf_forDevTools: () => K.current,
                                        getOthers_forDevTools: () => eI.current,
                                        simulate: {
                                            explicitClose: e => c._privateSendMachineEvent({
                                                type: "EXPLICIT_SOCKET_CLOSE",
                                                event: e
                                            }),
                                            rawSend: e => c.send(e)
                                        },
                                        attachmentUrlsStore: eV
                                    },
                                    id: t.roomId,
                                    subscribe: function(e, t, n) {
                                        if ("string" == typeof e && ("my-presence" === e || "others" === e || "event" === e || "error" === e || "history" === e || "status" === e || "storage-status" === e || "lost-connection" === e || "connection" === e || "comments" === e)) {
                                            if ("function" != typeof t) throw Error("Second argument must be a callback function");
                                            switch (e) {
                                                case "event":
                                                    return ek.customEvent.subscribe(t);
                                                case "my-presence":
                                                    return ek.myPresence.subscribe(t);
                                                case "others":
                                                    return ek.others.subscribe(e => {
                                                        let {
                                                            others: n,
                                                            ...i
                                                        } = e;
                                                        return t(n, i)
                                                    });
                                                case "error":
                                                    return ek.error.subscribe(t);
                                                case "status":
                                                    return ek.status.subscribe(t);
                                                case "lost-connection":
                                                    return ek.lostConnection.subscribe(t);
                                                case "history":
                                                    return ek.history.subscribe(t);
                                                case "storage-status":
                                                    return ek.storageStatus.subscribe(t);
                                                case "comments":
                                                    return ek.comments.subscribe(t);
                                                default:
                                                    return f(e, `"${String(e)}" is not a valid event name`)
                                            }
                                        }
                                        if (void 0 === t || "function" == typeof e) {
                                            if ("function" == typeof e) return ek.storageBatch.subscribe(e);
                                            throw Error("Please specify a listener callback")
                                        }
                                        if (e1(e)) return n ? .isDeep ? ek.storageBatch.subscribe(n => {
                                            let i = n.filter(t => (function e(t, n) {
                                                return t === n || "HasParent" === t.parent.type && e(t.parent.node, n)
                                            })(t.node, e));
                                            i.length > 0 && t(i)
                                        }) : ek.storageBatch.subscribe(n => {
                                            for (let i of n) i.node._id === e._id && t(i.node)
                                        });
                                        throw Error(`${String(e)} is not a value that can be subscribed to.`)
                                    },
                                    connect: () => c.connect(),
                                    reconnect: () => c.reconnect(),
                                    disconnect: () => c.disconnect(),
                                    destroy: () => {
                                        d(), c.destroy()
                                    },
                                    updatePresence: function(e, t) {
                                        let n = {};
                                        for (let t in null === u.buffer.presenceUpdates && (u.buffer.presenceUpdates = {
                                                type: "partial",
                                                data: {}
                                            }), e) {
                                            let i = e[t];
                                            void 0 !== i && (u.buffer.presenceUpdates.data[t] = i, n[t] = u.myPresence.current[t])
                                        }
                                        u.myPresence.patch(e), u.activeBatch ? (t ? .addToHistory && u.activeBatch.reverseOps.unshift({
                                            type: "presence",
                                            data: n
                                        }), u.activeBatch.updates.presence = !0) : (Y(), p(() => {
                                            t ? .addToHistory && H([{
                                                type: "presence",
                                                data: n
                                            }], h), W({
                                                presence: !0
                                            }, h)
                                        }))
                                    },
                                    updateYDoc: function(e, t) {
                                        let n = {
                                            type: 301,
                                            update: e,
                                            guid: t
                                        };
                                        u.buffer.messages.push(n), b.ydoc.notify(n), Y()
                                    },
                                    broadcastEvent: function(e, t = {
                                        shouldQueueEventIfNotReady: !1
                                    }) {
                                        ("connected" === c.getStatus() || t.shouldQueueEventIfNotReady) && (u.buffer.messages.push({
                                            type: 103,
                                            event: e
                                        }), Y())
                                    },
                                    batch: function(e) {
                                        let t;
                                        return u.activeBatch ? e() : (p(() => {
                                            u.activeBatch = {
                                                ops: [],
                                                updates: {
                                                    storageUpdates: new Map,
                                                    presence: !1,
                                                    others: []
                                                },
                                                reverseOps: []
                                            };
                                            try {
                                                t = e()
                                            } finally {
                                                let e = u.activeBatch;
                                                u.activeBatch = null, e.reverseOps.length > 0 && H(e.reverseOps, h), e.ops.length > 0 && (u.redoStack.length = 0), e.ops.length > 0 && X(e.ops), W(e.updates, h), Y()
                                            }
                                        }), t)
                                    },
                                    history: {
                                        undo: function() {
                                            if (u.activeBatch) throw Error("undo is not allowed during a batch");
                                            let e = u.undoStack.pop();
                                            if (void 0 === e) return;
                                            u.pausedHistory = null;
                                            let t = J(e, !0);
                                            for (let e of (p(() => {
                                                    W(t.updates, h), u.redoStack.push(t.reverse), q(h)
                                                }), t.ops)) "presence" !== e.type && u.buffer.storageOperations.push(e);
                                            Y()
                                        },
                                        redo: function() {
                                            if (u.activeBatch) throw Error("redo is not allowed during a batch");
                                            let e = u.redoStack.pop();
                                            if (void 0 === e) return;
                                            u.pausedHistory = null;
                                            let t = J(e, !0);
                                            for (let e of (p(() => {
                                                    W(t.updates, h), u.undoStack.push(t.reverse), q(h)
                                                }), t.ops)) "presence" !== e.type && u.buffer.storageOperations.push(e);
                                            Y()
                                        },
                                        canUndo: B,
                                        canRedo: V,
                                        clear: function() {
                                            u.undoStack.length = 0, u.redoStack.length = 0
                                        },
                                        pause: function() {
                                            null === u.pausedHistory && (u.pausedHistory = [])
                                        },
                                        resume: function() {
                                            let e = u.pausedHistory;
                                            u.pausedHistory = null, null !== e && e.length > 0 && z(e, p)
                                        }
                                    },
                                    fetchYDoc: function(e, t) {
                                        u.buffer.messages.find(n => 300 === n.type && n.vector === e && n.guid === t) || u.buffer.messages.push({
                                            type: 300,
                                            vector: e,
                                            guid: t
                                        }), Y()
                                    },
                                    getStorage: eo,
                                    getStorageSnapshot: er,
                                    getStorageStatus: es,
                                    isPresenceReady: ep,
                                    isStorageReady: ey,
                                    waitUntilPresenceReady: j(ef),
                                    waitUntilStorageReady: j(eO),
                                    events: ek,
                                    getStatus: () => c.getStatus(),
                                    getSelf: () => R.current,
                                    getPresence: () => u.myPresence.current,
                                    getOthers: () => u.others.current,
                                    getThreads: eD,
                                    getThreadsSince: eP,
                                    getThread: eL,
                                    createThread: eR,
                                    deleteThread: ex,
                                    editThreadMetadata: eU,
                                    markThreadAsResolved: e$,
                                    markThreadAsUnresolved: eM,
                                    createComment: eK,
                                    editComment: ej,
                                    deleteComment: ez,
                                    addReaction: eH,
                                    removeReaction: eW,
                                    prepareAttachment: function(e) {
                                        return {
                                            type: "localAttachment",
                                            status: "idle",
                                            id: e9("at"),
                                            name: e.name,
                                            size: e.size,
                                            mimeType: e.type,
                                            file: e
                                        }
                                    },
                                    uploadAttachment: eF,
                                    getAttachmentUrl: function(e) {
                                        return eB.get(e)
                                    },
                                    getNotificationSettings: function() {
                                        return eq(eS `/v2/c/rooms/${t.roomId}/notification-settings`)
                                    },
                                    updateNotificationSettings: function(e) {
                                        return eq(eS `/v2/c/rooms/${t.roomId}/notification-settings`, {
                                            method: "POST",
                                            body: JSON.stringify(e),
                                            headers: {
                                                "Content-Type": "application/json"
                                            }
                                        })
                                    },
                                    markInboxNotificationAsRead: eZ
                                }, eh, {
                                    enumerable: !1
                                })
                            }({
                                initialPresence: ("function" == typeof p.initialPresence ? p.initialPresence(t) : p.initialPresence) ? ? {},
                                initialStorage: ("function" == typeof p.initialStorage ? p.initialStorage(t) : p.initialStorage) ? ? {}
                            }, {
                                roomId: t,
                                throttleDelay: n,
                                lostConnectionTimeout: i,
                                backgroundKeepAliveTimeout: r,
                                polyfills: e.polyfills,
                                delegates: e.mockedDelegates ? ? {
                                    createSocket: (u = e.polyfills ? .WebSocket, e => {
                                        let n = u ? ? ("undefined" == typeof WebSocket ? void 0 : WebSocket);
                                        if (void 0 === n) throw new G("To use Liveblocks client in a non-DOM environment, you need to provide a WebSocket polyfill.");
                                        let i = new URL(o);
                                        if (i.protocol = "http:" === i.protocol ? "ws" : "wss", i.pathname = "/v7", i.searchParams.set("roomId", t), "secret" === e.type) i.searchParams.set("tok", e.token.raw);
                                        else {
                                            if ("public" !== e.type) return f(e, "Unhandled case");
                                            i.searchParams.set("pubkey", e.publicApiKey)
                                        }
                                        return i.searchParams.set("version", c || "dev"), new n(i.toString())
                                    }),
                                    authenticate: async () => s.getAuthValue({
                                        requestedScope: "room:read",
                                        roomId: t
                                    })
                                },
                                enableDebugLogging: e.enableDebugLogging,
                                unstable_batchedUpdates: p ? .unstable_batchedUpdates,
                                baseUrl: o,
                                unstable_fallbackToHTTP: !!e.unstable_fallbackToHTTP,
                                unstable_streamData: !!e.unstable_streamData
                            }),
                            y = {
                                room: _,
                                unsubs: new Set
                            };
                        if (a.set(t, y), p.autoConnect ? ? !0) {
                            if ("undefined" == typeof atob) {
                                if (e.polyfills ? .atob === void 0) throw Error("You need to polyfill atob to use the client in your environment. Please follow the instructions at https://liveblocks.io/docs/errors/liveblocks-client/atob-polyfill");
                                global.atob = e.polyfills.atob
                            }
                            _.connect()
                        }
                        return d(y)
                    },
                    getRoom: function(e) {
                        return a.get(e) ? .room || null
                    },
                    logout: function() {
                        for (let {
                                room: t
                            } of (s.reset(), a.values())) {
                            var e;
                            "initial" === (e = t.getStatus()) || "disconnected" === e || t.reconnect()
                        }
                    },
                    getInboxNotifications: u,
                    getInboxNotificationsSince: h,
                    getUnreadInboxNotificationsCount: p,
                    markAllInboxNotificationsAsRead: _,
                    markInboxNotificationAsRead: y,
                    deleteAllInboxNotifications: b,
                    deleteInboxNotification: E,
                    getThreads: w,
                    [eh]: {
                        currentUserIdStore: l,
                        resolveMentionSuggestions: e.resolveMentionSuggestions,
                        usersStore: A,
                        roomsInfoStore: D,
                        getRoomIds: () => Array.from(a.keys()),
                        getThreads: w,
                        getThreadsSince: S
                    }
                }, eh, {
                    enumerable: !1
                })
            }
            var tT = class extends Error {
                constructor(e, t, n) {
                    super(e), this.message = e, this.status = t, this.details = n
                }
            };

            function tS(e, t, n, i, r) {
                if ("number" != typeof t || t < n || void 0 !== i && t > i) throw Error(void 0 !== i ? `${e} should be between ${r??n} and ${i}.` : `${e} should be at least ${r??n}.`);
                return t
            }

            function tO(e, ...t) {
                return () => {}
            }

            function tI(e) {
                let t = {
                    state: "stopped",
                    timeoutHandle: null,
                    interval: null,
                    lastScheduledAt: null,
                    remainingInterval: null
                };

                function n() {
                    "running" === t.state && i(t.interval), e()
                }

                function i(e) {
                    t = {
                        state: "running",
                        interval: "stopped" !== t.state ? t.interval : e,
                        lastScheduledAt: performance.now(),
                        timeoutHandle: setTimeout(n, e),
                        remainingInterval: null
                    }
                }

                function r(e) {
                    "running" !== t.state && i(e)
                }

                function o() {
                    "stopped" !== t.state && (t.timeoutHandle && clearTimeout(t.timeoutHandle), t = {
                        state: "stopped",
                        interval: null,
                        lastScheduledAt: null,
                        timeoutHandle: null,
                        remainingInterval: null
                    })
                }
                return {
                    start: r,
                    restart: function(e) {
                        o(), r(e)
                    },
                    pause: function() {
                        "running" === t.state && (clearTimeout(t.timeoutHandle), t = {
                            state: "paused",
                            interval: t.interval,
                            lastScheduledAt: t.lastScheduledAt,
                            timeoutHandle: null,
                            remainingInterval: t.interval - (performance.now() - t.lastScheduledAt)
                        })
                    },
                    resume: function() {
                        if ("paused" === t.state) {
                            var e;
                            e = t.remainingInterval, "paused" === t.state && (t = {
                                state: "running",
                                interval: t.interval,
                                lastScheduledAt: t.lastScheduledAt,
                                timeoutHandle: setTimeout(n, e),
                                remainingInterval: null
                            })
                        }
                    },
                    stop: o
                }
            }

            function tk(e, t) {
                if (Object.is(e, t)) return !0;
                let n = Array.isArray(e),
                    i = Array.isArray(t);
                return n || i ? !!n && !!i && function(e, t) {
                    if (e.length !== t.length) return !1;
                    for (let n = 0; n < e.length; n++)
                        if (!Object.is(e[n], t[n])) return !1;
                    return !0
                }(e, t) : function(e, t) {
                    if (!D(e) || !D(t)) return !1;
                    let n = Object.keys(e);
                    return n.length === Object.keys(t).length && n.every(n => Object.prototype.hasOwnProperty.call(t, n) && Object.is(e[n], t[n]))
                }(e, t)
            }
            RegExp(["&", "<", ">", '"', "'"].map(e => `\\${e}`).join("|"), "g"), RegExp(["_", "*", "#", "`", "~", "!", "|", "(", ")", "{", "}", "[", "]"].map(e => `\\${e}`).join("|"), "g"), p(l, c, "esm")
        }
    }
]);