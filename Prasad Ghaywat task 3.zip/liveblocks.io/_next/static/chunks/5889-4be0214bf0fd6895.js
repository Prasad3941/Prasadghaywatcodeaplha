"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5889], {
        26205: function(e, t, r) {
            var a, n = r(67294);

            function c() {
                return (c = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var a in r)({}).hasOwnProperty.call(r, a) && (e[a] = r[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            t.Z = function(e) {
                return n.createElement("svg", c({
                    width: 16,
                    height: 16,
                    viewBox: "0 0 16 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), a || (a = n.createElement("path", {
                    d: "M16 8C16 9.58225 15.5308 11.129 14.6518 12.4446C13.7727 13.7602 12.5233 14.7855 11.0615 15.391C9.59966 15.9965 7.99113 16.155 6.43928 15.8463C4.88743 15.5376 3.46197 14.7757 2.34315 13.6569C1.22433 12.538 0.4624 11.1126 0.153718 9.56072C-0.154964 8.00887 0.00346269 6.40034 0.608964 4.93853C1.21446 3.47672 2.23984 2.22729 3.55544 1.34824C4.87103 0.469192 6.41775 -1.88681e-08 8 0L8 1.52681C6.71972 1.52681 5.4682 1.90645 4.40369 2.61774C3.33917 3.32902 2.50949 4.33999 2.01955 5.52282C1.52961 6.70564 1.40142 8.00718 1.65119 9.26286C1.90096 10.5185 2.51747 11.6719 3.42276 12.5772C4.32805 13.4825 5.48147 14.099 6.73714 14.3488C7.99282 14.5986 9.29436 14.4704 10.4772 13.9805C11.66 13.4905 12.671 12.6608 13.3823 11.5963C14.0935 10.5318 14.4732 9.28028 14.4732 8H16Z"
                })))
            }
        },
        90120: function(e, t, r) {
            r.d(t, {
                X: function() {
                    return p
                },
                Q: function() {
                    return m
                }
            });
            var a = r(85893),
                n = r(67294),
                c = r(4848);
            let o = "data-theme",
                s = "data-domain";

            function d(e, t) {
                document.documentElement.setAttribute(e, t)
            }

            function i() {
                let e = document.createElement("style");
                return e.appendChild(document.createTextNode("*{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}")), document.head.appendChild(e), () => {
                    window.getComputedStyle(document.body), setTimeout(() => {
                        document.head.removeChild(e)
                    }, 1)
                }
            }
            let u = (0, n.memo)(e => {
                    let {
                        attribute: t,
                        value: r
                    } = e, n = '!function(){document.documentElement.setAttribute("'.concat(t, '","').concat(r, '")}()');
                    return (0, a.jsx)("script", {
                        dangerouslySetInnerHTML: {
                            __html: n
                        }
                    })
                }, () => !0),
                l = (0, n.memo)(e => {
                    let {
                        value: t
                    } = e, r = '!function(){let settings=JSON.parse(localStorage.getItem("'.concat(c.Jr, '")||""),theme;theme=settings.theme?"system"===settings.theme?window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light":settings.theme:"').concat(t, '",document.documentElement.setAttribute("').concat(o, '",theme)}();');
                    return (0, a.jsx)("script", {
                        dangerouslySetInnerHTML: {
                            __html: r
                        }
                    })
                }, () => !0);

            function m() {
                let [e] = (0, c.rV)(), {
                    theme: t,
                    isLoading: r
                } = e;
                (0, n.useEffect)(() => {
                    if (r) return;
                    let e = i();
                    "system" === t ? m() : d(o, t), d(s, "product"), e()
                }, [t, r]);
                let m = () => {
                    d(o, window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")
                };
                return (0, n.useEffect)(() => (window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", m), () => {
                    window.matchMedia("(prefers-color-scheme: dark)").removeEventListener("change", m)
                }), []), (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(u, {
                        attribute: s,
                        value: "product"
                    }), (0, a.jsx)(l, {
                        value: t
                    })]
                })
            }

            function p() {
                return (0, n.useEffect)(() => {
                    let e = i();
                    d(o, "dark"), d(s, "marketing"), e()
                }, []), (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(u, {
                        attribute: s,
                        value: "marketing"
                    }), (0, a.jsx)(u, {
                        attribute: o,
                        value: "dark"
                    })]
                })
            }
        },
        33613: function(e, t, r) {
            r.d(t, {
                z: function() {
                    return p
                },
                f: function() {
                    return m
                }
            });
            var a = r(85893),
                n = r(93967),
                c = r.n(n),
                o = r(54735),
                s = r(67294),
                d = r(26205),
                i = r(20402);
            let u = "--pointer-x",
                l = "--pointer-y";

            function m(e) {
                switch (e) {
                    case "ghost":
                        return "hsla(256, 7%, 97%, 0.12)";
                    case "secondary":
                        return "hsla(256, 7%, 97%, 0.08)";
                    case "brand":
                    case "accent-yellow":
                    case "accent-pink":
                    case "accent-green":
                    case "accent-blue":
                        return "hsla(256, 7%, 97%, 0.32)";
                    case "primary":
                        return "hsla(256, 7%, 97%, 1)"
                }
            }
            let p = (0, s.forwardRef)((e, t) => {
                let {
                    children: r,
                    className: n,
                    size: p = "md",
                    disabled: b = !1,
                    appearance: g = "secondary",
                    type: f = "button",
                    loading: h = !1,
                    square: v = !1,
                    round: x = !1,
                    ...k
                } = e, w = (0, s.useRef)(null), y = (0, s.useMemo)(() => m(g), [g]), j = (0, s.useMemo)(() => ({
                    [u]: "".concat(0, "px"),
                    [l]: "".concat(0, "px"),
                    top: "-".concat(100, "px"),
                    left: "-".concat(100, "px"),
                    width: "".concat(200, "px"),
                    height: "".concat(200, "px"),
                    transform: "translateX(var(".concat(u, ")) translateY(var(").concat(l, "))"),
                    backgroundImage: "radial-gradient(".concat(100, "px circle, ").concat(y, ", hsla(256, 7%, 97%, 0))")
                }), [y]), C = (0, s.useCallback)(e => {
                    let t, r;
                    let a = w.current,
                        n = e.currentTarget;
                    a && (o.ZP.read(() => {
                        let a = null == n ? void 0 : n.getBoundingClientRect();
                        a && (t = e.clientX - a.x, r = e.clientY - a.y)
                    }), o.ZP.update(() => {
                        void 0 !== t && void 0 !== r && (a.style.setProperty(u, "".concat(t, "px")), a.style.setProperty(l, "".concat(r, "px")))
                    }))
                }, []);
                return (0, a.jsxs)("button", {
                    ref: t,
                    disabled: b,
                    className: (0, i.cn)("group relative inline-flex select-none appearance-none items-center justify-center overflow-hidden font-medium outline-none transition duration-300 ease-out will-change-transform", {
                        "h-7 text-xs": "sm" === p,
                        "h-9 text-sm": "md" === p,
                        "h-10 sm:h-11 max-sm:text-sm": "lg" === p,
                        "w-7": "sm" === p && v,
                        "w-9": "md" === p && v,
                        "w-10 sm:w-11": "lg" === p && v,
                        rounded: "sm" === p && !x,
                        "rounded-md": "md" === p && !x,
                        "rounded-md sm:rounded-lg": "lg" === p && !x,
                        "px-3": "sm" === p && !v && !x,
                        "px-3.5": "md" === p && !v && !x || "sm" === p && !v && x,
                        "px-3.5 sm:px-4": "lg" === p && !v && !x || "md" === p && !v && x,
                        "px-4.5 sm:px-5": "lg" === p && !v && x,
                        "p-0": v,
                        "rounded-full": x,
                        "bg-marketing-surface-faded active:bg-marketing-surface-faded-bolder focus:bg-marketing-surface-faded-bold": "secondary" === g,
                        "active:bg-marketing-surface-faded-bolder": "ghost" === g,
                        "bg-marketing-surface-base-inverse text-marketing-inverse hover:bg-marketing-surface-base-inverse-subtle active:bg-marketing-surface-base-inverse": "primary" === g,
                        "bg-marketing-surface-brand text-marketing-inverse active:bg-marketing-surface-brand-bolder focus:bg-marketing-surface-brand-bold": "brand" === g,
                        "bg-marketing-surface-accent-yellow text-marketing-inverse active:bg-marketing-surface-accent-yellow-bolder focus:bg-marketing-surface-accent-yellow-bold": "accent-yellow" === g,
                        "bg-marketing-surface-accent-pink text-marketing-inverse hover:bg-marketing-surface-accent-pink-bold active:bg-marketing-surface-accent-pink-bolder focus:bg-marketing-surface-accent-pink-bold": "accent-pink" === g,
                        "bg-marketing-surface-accent-green text-marketing-inverse hover:bg-marketing-surface-accent-green-bold active:bg-marketing-surface-accent-green-bolder focus:bg-marketing-surface-accent-green-bold": "accent-green" === g,
                        "bg-marketing-surface-accent-blue text-marketing-inverse hover:bg-marketing-surface-accent-blue-bold active:bg-marketing-surface-accent-blue-bolder focus:bg-marketing-surface-accent-blue-bold": "accent-blue" === g,
                        "pointer-events-none opacity-50": b
                    }, n),
                    type: f,
                    onPointerMove: C,
                    ...k,
                    children: [(0, a.jsx)("div", {
                        ref: w,
                        className: c()("pointer-events-none absolute inset-0 z-0 opacity-0 transition-opacity duration-150 ease-out group-hover:opacity-100", {
                            rounded: "sm" === p && !x,
                            "rounded-md": "md" === p && !x,
                            "rounded-md sm:rounded-lg": "lg" === p && !x,
                            "rounded-full": x
                        }),
                        style: j
                    }), h && (0, a.jsx)("span", {
                        className: "absolute inset-0 z-10 flex items-center justify-center",
                        children: (0, a.jsx)(d.Z, {
                            className: "animate-spin fill-current"
                        })
                    }), (0, a.jsx)("span", {
                        className: c()("relative z-10 flex items-center", {
                            "opacity-0": h
                        }),
                        children: r
                    })]
                })
            })
        },
        40611: function(e, t, r) {
            r.d(t, {
                z: function() {
                    return u
                }
            });
            var a = r(85893),
                n = r(4222),
                c = r(12003),
                o = r(93967),
                s = r.n(o),
                d = r(67294);
            let i = (0, c.j)("group inline-flex items-center border justify-center whitespace-nowrap font-medium transition-colors focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 data-[square]:px-0", {
                    variants: {
                        appearance: {
                            ghost: ["text-product", "hover:bg-product-surface-base-alpha-subtle focus:bg-product-surface-base-alpha-subtle active:bg-product-surface-base-alpha data-[state=open]:bg-product-surface-base-alpha-subtle", "border-transparent hover:border-product-divider-bold active:border-product-divider-bold focus:border-product-divider-bold", "hover:shadow-product-raised focus:shadow-product-raised active:shadow-none"],
                            primary: ["text-product-inverse", "bg-product-surface-base-inverse-subtle hover:bg-product-surface-base-inverse focus:bg-product-surface-base-inverse active:bg-product-surface-base-inverse-bold data-[state=open]:bg-product-surface-base-inverse-bold", "border-product-divider-inverse-bolder", "shadow-product-raised active:shadow-none"],
                            secondary: ["text-product", "hover:bg-product-surface-base-alpha-subtle focus:bg-product-surface-base-alpha-subtle active:bg-product-surface-base-alpha-subtle data-[state=open]:bg-product-surface-base-alpha-subtle", "border-product-divider-bold", "shadow-product-raised active:shadow-none"],
                            destructive: ["text-product-inverse", "bg-product-surface-danger hover:bg-product-surface-danger-bolder focus:bg-product-surface-danger-bolder active:bg-product-surface-danger-boldest data-[state=open]:bg-product-surface-danger-boldest", "border-product-divider-bold", "shadow-product-raised active:shadow-none", "focus:!ring-product-surface-danger"],
                            "secondary-destructive": ["text-product-danger", "hover:bg-product-surface-base-alpha-subtle focus:bg-product-surface-base-alpha-subtle active:bg-product-surface-base-alpha-subtle data-[state=open]:bg-product-surface-base-alpha-subtle", "border-product-divider-bold", "shadow-product-raised active:shadow-none", "focus:!ring-product-surface-danger"]
                        },
                        size: {
                            sm: "h-7 rounded px-2 text-xs data-[square]:w-7",
                            md: "h-9 rounded-md px-3.5 text-sm data-[square]:w-9",
                            lg: "h-11 rounded-lg px-4 data-[square]:w-11"
                        }
                    },
                    defaultVariants: {
                        appearance: "secondary",
                        size: "md"
                    }
                }),
                u = d.forwardRef((e, t) => {
                    let {
                        className: r,
                        appearance: c,
                        formAction: o,
                        size: d,
                        square: u,
                        loading: l,
                        asChild: m = !1,
                        ...p
                    } = e, b = m ? n.g7 : "button";
                    return (0, a.jsx)(b, {
                        className: s()(i({
                            appearance: c,
                            size: d,
                            className: r
                        }), {
                            "animate-mask-flare-loop": l
                        }),
                        ref: t,
                        "data-square": u ? "" : void 0,
                        ...p
                    })
                })
        },
        79016: function(e, t, r) {
            r.d(t, {
                z: function() {
                    return a.z
                }
            });
            var a = r(40611)
        },
        47874: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return p
                }
            });
            var a = r(85893),
                n = r(93967),
                c = r.n(n),
                o = r(41664),
                s = r.n(o),
                d = r(16003),
                i = r(33613),
                u = r(79016);

            function l(e) {
                let {
                    value: t,
                    onValueChange: r,
                    domain: n
                } = e, o = "marketing" === n ? i.z : u.z;
                return ! function() {
                    var e;
                    if (null === t) return !1;
                    if (void 0 === t.lastUpdated) return !0;
                    let r = (e = new Date(t.lastUpdated), Math.floor((new Date().getTime() - e.getTime()) / 6048e5));
                    if (r > 26) return !0;
                    let a = !0 === t.marketing,
                        n = !0 === t.analytics;
                    if (r > 1 && !a && !n) return !0
                }() ? null : (0, a.jsxs)("div", {
                    className: c()("fixed bottom-3.5 left-3.5 right-3.5 z-high rounded-lg border px-5 pb-5 pt-4 sm:bottom-4 sm:left-4 sm:max-w-md", {
                        "shadow-marketing-elevation-popover border-marketing-divider bg-marketing-surface-raised": "marketing" === n,
                        "border-product-divider bg-product-surface-base-bold shadow-product-popover": "product" === n
                    }),
                    children: [(0, a.jsxs)("p", {
                        className: c()("text-sm", {
                            "text-marketing-subtler": "marketing" === n,
                            "text-product-subtle": "product" === n
                        }),
                        children: ["We use cookies to collect data to improve your experience on our site. Read our", " ", (0, a.jsx)(s(), {
                            href: d.qk.PRIVACY,
                            className: c()("rounded-sm", {
                                "marketing-link-subtle": "marketing" === n,
                                "product-link-subtle": "product" === n
                            }),
                            children: "Privacy Policy"
                        }), " ", "to learn more."]
                    }), (0, a.jsxs)("div", {
                        className: "mt-4 flex items-center justify-end gap-2",
                        children: [(0, a.jsx)(o, {
                            onClick: () => {
                                r({
                                    marketing: !1,
                                    analytics: !1,
                                    lastUpdated: new Date,
                                    essentials: !0
                                })
                            },
                            children: "Decline"
                        }), (0, a.jsx)(o, {
                            appearance: "primary",
                            onClick: () => {
                                r({
                                    marketing: !0,
                                    analytics: !0,
                                    lastUpdated: new Date,
                                    essentials: !0
                                })
                            },
                            children: "Accept"
                        })]
                    })]
                })
            }
            r(94096);
            var m = r(60162);

            function p(e) {
                let {
                    domain: t
                } = e, [r, n] = (0, m.e)();
                return (0, a.jsx)(l, {
                    value: r,
                    onValueChange: n,
                    domain: t
                })
            }
        },
        97691: function(e, t, r) {
            r.d(t, {
                U: function() {
                    return a
                }
            });

            function a(e, t, r) {
                return e || [t, r].filter(e => e).join(" | ")
            }
        }
    }
]);