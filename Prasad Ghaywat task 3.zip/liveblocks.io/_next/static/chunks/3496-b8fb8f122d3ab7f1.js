"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3496], {
        70699: function(e, t, r) {
            r.d(t, {
                fC: function() {
                    return I
                },
                xr: function() {
                    return b
                },
                LW: function() {
                    return F
                },
                bU: function() {
                    return $
                },
                l_: function() {
                    return U
                }
            });
            var n = r(87462),
                o = r(67294);
            r(73935);
            var l = r(4222);
            let i = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                let r = (0, o.forwardRef)((e, r) => {
                    let {
                        asChild: i,
                        ...a
                    } = e, c = i ? l.g7 : t;
                    return (0, o.useEffect)(() => {
                        window[Symbol.for("radix-ui")] = !0
                    }, []), (0, o.createElement)(c, (0, n.Z)({}, a, {
                        ref: r
                    }))
                });
                return r.displayName = `Primitive.${t}`, { ...e,
                    [t]: r
                }
            }, {});
            var a = r(438);

            function c(...e) {
                return (0, o.useCallback)(function(...e) {
                    return t => e.forEach(e => {
                        "function" == typeof e ? e(t) : null != e && (e.current = t)
                    })
                }(...e), e)
            }

            function u(e) {
                let t = (0, o.useRef)(e);
                return (0, o.useEffect)(() => {
                    t.current = e
                }), (0, o.useMemo)(() => (...e) => {
                    var r;
                    return null === (r = t.current) || void 0 === r ? void 0 : r.call(t, ...e)
                }, [])
            }
            let s = (0, o.createContext)(void 0),
                d = (null == globalThis ? void 0 : globalThis.document) ? o.useLayoutEffect : () => {};

            function f(e, t, {
                checkForDefaultPrevented: r = !0
            } = {}) {
                return function(n) {
                    if (null == e || e(n), !1 === r || !n.defaultPrevented) return null == t ? void 0 : t(n)
                }
            }
            let p = "ScrollArea",
                [h, v] = function(e, t = []) {
                    let r = [],
                        n = () => {
                            let t = r.map(e => (0, o.createContext)(e));
                            return function(r) {
                                let n = (null == r ? void 0 : r[e]) || t;
                                return (0, o.useMemo)(() => ({
                                    [`__scope${e}`]: { ...r,
                                        [e]: n
                                    }
                                }), [r, n])
                            }
                        };
                    return n.scopeName = e, [function(t, n) {
                        let l = (0, o.createContext)(n),
                            i = r.length;

                        function a(t) {
                            let {
                                scope: r,
                                children: n,
                                ...a
                            } = t, c = (null == r ? void 0 : r[e][i]) || l, u = (0, o.useMemo)(() => a, Object.values(a));
                            return (0, o.createElement)(c.Provider, {
                                value: u
                            }, n)
                        }
                        return r = [...r, n], a.displayName = t + "Provider", [a, function(r, a) {
                            let c = (null == a ? void 0 : a[e][i]) || l,
                                u = (0, o.useContext)(c);
                            if (u) return u;
                            if (void 0 !== n) return n;
                            throw Error(`\`${r}\` must be used within \`${t}\``)
                        }]
                    }, function(...e) {
                        let t = e[0];
                        if (1 === e.length) return t;
                        let r = () => {
                            let r = e.map(e => ({
                                useScope: e(),
                                scopeName: e.scopeName
                            }));
                            return function(e) {
                                let n = r.reduce((t, {
                                    useScope: r,
                                    scopeName: n
                                }) => {
                                    let o = r(e)[`__scope${n}`];
                                    return { ...t,
                                        ...o
                                    }
                                }, {});
                                return (0, o.useMemo)(() => ({
                                    [`__scope${t.scopeName}`]: n
                                }), [n])
                            }
                        };
                        return r.scopeName = t.scopeName, r
                    }(n, ...t)]
                }(p),
                [m, w] = h(p),
                b = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeScrollArea: r,
                        type: l = "hover",
                        dir: a,
                        scrollHideDelay: u = 600,
                        ...d
                    } = e, [f, p] = (0, o.useState)(null), [h, v] = (0, o.useState)(null), [w, b] = (0, o.useState)(null), [g, E] = (0, o.useState)(null), [S, C] = (0, o.useState)(null), [y, T] = (0, o.useState)(0), [R, _] = (0, o.useState)(0), [P, L] = (0, o.useState)(!1), [x, D] = (0, o.useState)(!1), A = c(t, e => p(e)), z = function(e) {
                        let t = (0, o.useContext)(s);
                        return e || t || "ltr"
                    }(a);
                    return (0, o.createElement)(m, {
                        scope: r,
                        type: l,
                        dir: z,
                        scrollHideDelay: u,
                        scrollArea: f,
                        viewport: h,
                        onViewportChange: v,
                        content: w,
                        onContentChange: b,
                        scrollbarX: g,
                        onScrollbarXChange: E,
                        scrollbarXEnabled: P,
                        onScrollbarXEnabledChange: L,
                        scrollbarY: S,
                        onScrollbarYChange: C,
                        scrollbarYEnabled: x,
                        onScrollbarYEnabledChange: D,
                        onCornerWidthChange: T,
                        onCornerHeightChange: _
                    }, (0, o.createElement)(i.div, (0, n.Z)({
                        dir: z
                    }, d, {
                        ref: A,
                        style: {
                            position: "relative",
                            "--radix-scroll-area-corner-width": y + "px",
                            "--radix-scroll-area-corner-height": R + "px",
                            ...e.style
                        }
                    })))
                }),
                g = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeScrollArea: r,
                        children: l,
                        ...a
                    } = e, u = w("ScrollAreaViewport", r), s = c(t, (0, o.useRef)(null), u.onViewportChange);
                    return (0, o.createElement)(o.Fragment, null, (0, o.createElement)("style", {
                        dangerouslySetInnerHTML: {
                            __html: "[data-radix-scroll-area-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-scroll-area-viewport]::-webkit-scrollbar{display:none}"
                        }
                    }), (0, o.createElement)(i.div, (0, n.Z)({
                        "data-radix-scroll-area-viewport": ""
                    }, a, {
                        ref: s,
                        style: {
                            overflowX: u.scrollbarXEnabled ? "scroll" : "hidden",
                            overflowY: u.scrollbarYEnabled ? "scroll" : "hidden",
                            ...e.style
                        }
                    }), (0, o.createElement)("div", {
                        ref: u.onContentChange,
                        style: {
                            minWidth: "100%",
                            display: "table"
                        }
                    }, l)))
                }),
                E = "ScrollAreaScrollbar",
                S = (0, o.forwardRef)((e, t) => {
                    let {
                        forceMount: r,
                        ...l
                    } = e, i = w(E, e.__scopeScrollArea), {
                        onScrollbarXEnabledChange: a,
                        onScrollbarYEnabledChange: c
                    } = i, u = "horizontal" === e.orientation;
                    return (0, o.useEffect)(() => (u ? a(!0) : c(!0), () => {
                        u ? a(!1) : c(!1)
                    }), [u, a, c]), "hover" === i.type ? (0, o.createElement)(C, (0, n.Z)({}, l, {
                        ref: t,
                        forceMount: r
                    })) : "scroll" === i.type ? (0, o.createElement)(y, (0, n.Z)({}, l, {
                        ref: t,
                        forceMount: r
                    })) : "auto" === i.type ? (0, o.createElement)(T, (0, n.Z)({}, l, {
                        ref: t,
                        forceMount: r
                    })) : "always" === i.type ? (0, o.createElement)(R, (0, n.Z)({}, l, {
                        ref: t
                    })) : null
                }),
                C = (0, o.forwardRef)((e, t) => {
                    let {
                        forceMount: r,
                        ...l
                    } = e, i = w(E, e.__scopeScrollArea), [c, u] = (0, o.useState)(!1);
                    return (0, o.useEffect)(() => {
                        let e = i.scrollArea,
                            t = 0;
                        if (e) {
                            let r = () => {
                                    window.clearTimeout(t), u(!0)
                                },
                                n = () => {
                                    t = window.setTimeout(() => u(!1), i.scrollHideDelay)
                                };
                            return e.addEventListener("pointerenter", r), e.addEventListener("pointerleave", n), () => {
                                window.clearTimeout(t), e.removeEventListener("pointerenter", r), e.removeEventListener("pointerleave", n)
                            }
                        }
                    }, [i.scrollArea, i.scrollHideDelay]), (0, o.createElement)(a.z, {
                        present: r || c
                    }, (0, o.createElement)(T, (0, n.Z)({
                        "data-state": c ? "visible" : "hidden"
                    }, l, {
                        ref: t
                    })))
                }),
                y = (0, o.forwardRef)((e, t) => {
                    var r, l;
                    let {
                        forceMount: i,
                        ...c
                    } = e, u = w(E, e.__scopeScrollArea), s = "horizontal" === e.orientation, d = k(() => h("SCROLL_END"), 100), [p, h] = (r = "hidden", l = {
                        hidden: {
                            SCROLL: "scrolling"
                        },
                        scrolling: {
                            SCROLL_END: "idle",
                            POINTER_ENTER: "interacting"
                        },
                        interacting: {
                            SCROLL: "interacting",
                            POINTER_LEAVE: "idle"
                        },
                        idle: {
                            HIDE: "hidden",
                            SCROLL: "scrolling",
                            POINTER_ENTER: "interacting"
                        }
                    }, (0, o.useReducer)((e, t) => {
                        let r = l[e][t];
                        return null != r ? r : e
                    }, r));
                    return (0, o.useEffect)(() => {
                        if ("idle" === p) {
                            let e = window.setTimeout(() => h("HIDE"), u.scrollHideDelay);
                            return () => window.clearTimeout(e)
                        }
                    }, [p, u.scrollHideDelay, h]), (0, o.useEffect)(() => {
                        let e = u.viewport,
                            t = s ? "scrollLeft" : "scrollTop";
                        if (e) {
                            let r = e[t],
                                n = () => {
                                    let n = e[t];
                                    r !== n && (h("SCROLL"), d()), r = n
                                };
                            return e.addEventListener("scroll", n), () => e.removeEventListener("scroll", n)
                        }
                    }, [u.viewport, s, h, d]), (0, o.createElement)(a.z, {
                        present: i || "hidden" !== p
                    }, (0, o.createElement)(R, (0, n.Z)({
                        "data-state": "hidden" === p ? "hidden" : "visible"
                    }, c, {
                        ref: t,
                        onPointerEnter: f(e.onPointerEnter, () => h("POINTER_ENTER")),
                        onPointerLeave: f(e.onPointerLeave, () => h("POINTER_LEAVE"))
                    })))
                }),
                T = (0, o.forwardRef)((e, t) => {
                    let r = w(E, e.__scopeScrollArea),
                        {
                            forceMount: l,
                            ...i
                        } = e,
                        [c, u] = (0, o.useState)(!1),
                        s = "horizontal" === e.orientation,
                        d = k(() => {
                            if (r.viewport) {
                                let e = r.viewport.offsetWidth < r.viewport.scrollWidth,
                                    t = r.viewport.offsetHeight < r.viewport.scrollHeight;
                                u(s ? e : t)
                            }
                        }, 10);
                    return X(r.viewport, d), X(r.content, d), (0, o.createElement)(a.z, {
                        present: l || c
                    }, (0, o.createElement)(R, (0, n.Z)({
                        "data-state": c ? "visible" : "hidden"
                    }, i, {
                        ref: t
                    })))
                }),
                R = (0, o.forwardRef)((e, t) => {
                    let {
                        orientation: r = "vertical",
                        ...l
                    } = e, i = w(E, e.__scopeScrollArea), a = (0, o.useRef)(null), c = (0, o.useRef)(0), [u, s] = (0, o.useState)({
                        content: 0,
                        viewport: 0,
                        scrollbar: {
                            size: 0,
                            paddingStart: 0,
                            paddingEnd: 0
                        }
                    }), d = Z(u.viewport, u.content), f = { ...l,
                        sizes: u,
                        onSizesChange: s,
                        hasThumb: !!(d > 0 && d < 1),
                        onThumbChange: e => a.current = e,
                        onThumbPointerUp: () => c.current = 0,
                        onThumbPointerDown: e => c.current = e
                    };

                    function p(e, t) {
                        return function(e, t, r, n = "ltr") {
                            let o = W(r),
                                l = t || o / 2,
                                i = r.scrollbar.paddingStart + l,
                                a = r.scrollbar.size - r.scrollbar.paddingEnd - (o - l),
                                c = r.content - r.viewport;
                            return O([i, a], "ltr" === n ? [0, c] : [-1 * c, 0])(e)
                        }(e, c.current, u, t)
                    }
                    return "horizontal" === r ? (0, o.createElement)(_, (0, n.Z)({}, f, {
                        ref: t,
                        onThumbPositionChange: () => {
                            if (i.viewport && a.current) {
                                let e = H(i.viewport.scrollLeft, u, i.dir);
                                a.current.style.transform = `translate3d(${e}px, 0, 0)`
                            }
                        },
                        onWheelScroll: e => {
                            i.viewport && (i.viewport.scrollLeft = e)
                        },
                        onDragScroll: e => {
                            i.viewport && (i.viewport.scrollLeft = p(e, i.dir))
                        }
                    })) : "vertical" === r ? (0, o.createElement)(P, (0, n.Z)({}, f, {
                        ref: t,
                        onThumbPositionChange: () => {
                            if (i.viewport && a.current) {
                                let e = H(i.viewport.scrollTop, u);
                                a.current.style.transform = `translate3d(0, ${e}px, 0)`
                            }
                        },
                        onWheelScroll: e => {
                            i.viewport && (i.viewport.scrollTop = e)
                        },
                        onDragScroll: e => {
                            i.viewport && (i.viewport.scrollTop = p(e))
                        }
                    })) : null
                }),
                _ = (0, o.forwardRef)((e, t) => {
                    let {
                        sizes: r,
                        onSizesChange: l,
                        ...i
                    } = e, a = w(E, e.__scopeScrollArea), [u, s] = (0, o.useState)(), d = (0, o.useRef)(null), f = c(t, d, a.onScrollbarXChange);
                    return (0, o.useEffect)(() => {
                        d.current && s(getComputedStyle(d.current))
                    }, [d]), (0, o.createElement)(D, (0, n.Z)({
                        "data-orientation": "horizontal"
                    }, i, {
                        ref: f,
                        sizes: r,
                        style: {
                            bottom: 0,
                            left: "rtl" === a.dir ? "var(--radix-scroll-area-corner-width)" : 0,
                            right: "ltr" === a.dir ? "var(--radix-scroll-area-corner-width)" : 0,
                            "--radix-scroll-area-thumb-width": W(r) + "px",
                            ...e.style
                        },
                        onThumbPointerDown: t => e.onThumbPointerDown(t.x),
                        onDragScroll: t => e.onDragScroll(t.x),
                        onWheelScroll: (t, r) => {
                            if (a.viewport) {
                                let n = a.viewport.scrollLeft + t.deltaX;
                                e.onWheelScroll(n), n > 0 && n < r && t.preventDefault()
                            }
                        },
                        onResize: () => {
                            d.current && a.viewport && u && l({
                                content: a.viewport.scrollWidth,
                                viewport: a.viewport.offsetWidth,
                                scrollbar: {
                                    size: d.current.clientWidth,
                                    paddingStart: M(u.paddingLeft),
                                    paddingEnd: M(u.paddingRight)
                                }
                            })
                        }
                    }))
                }),
                P = (0, o.forwardRef)((e, t) => {
                    let {
                        sizes: r,
                        onSizesChange: l,
                        ...i
                    } = e, a = w(E, e.__scopeScrollArea), [u, s] = (0, o.useState)(), d = (0, o.useRef)(null), f = c(t, d, a.onScrollbarYChange);
                    return (0, o.useEffect)(() => {
                        d.current && s(getComputedStyle(d.current))
                    }, [d]), (0, o.createElement)(D, (0, n.Z)({
                        "data-orientation": "vertical"
                    }, i, {
                        ref: f,
                        sizes: r,
                        style: {
                            top: 0,
                            right: "ltr" === a.dir ? 0 : void 0,
                            left: "rtl" === a.dir ? 0 : void 0,
                            bottom: "var(--radix-scroll-area-corner-height)",
                            "--radix-scroll-area-thumb-height": W(r) + "px",
                            ...e.style
                        },
                        onThumbPointerDown: t => e.onThumbPointerDown(t.y),
                        onDragScroll: t => e.onDragScroll(t.y),
                        onWheelScroll: (t, r) => {
                            if (a.viewport) {
                                let n = a.viewport.scrollTop + t.deltaY;
                                e.onWheelScroll(n), n > 0 && n < r && t.preventDefault()
                            }
                        },
                        onResize: () => {
                            d.current && a.viewport && u && l({
                                content: a.viewport.scrollHeight,
                                viewport: a.viewport.offsetHeight,
                                scrollbar: {
                                    size: d.current.clientHeight,
                                    paddingStart: M(u.paddingTop),
                                    paddingEnd: M(u.paddingBottom)
                                }
                            })
                        }
                    }))
                }),
                [L, x] = h(E),
                D = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeScrollArea: r,
                        sizes: l,
                        hasThumb: a,
                        onThumbChange: s,
                        onThumbPointerUp: d,
                        onThumbPointerDown: p,
                        onThumbPositionChange: h,
                        onDragScroll: v,
                        onWheelScroll: m,
                        onResize: b,
                        ...g
                    } = e, S = w(E, r), [C, y] = (0, o.useState)(null), T = c(t, e => y(e)), R = (0, o.useRef)(null), _ = (0, o.useRef)(""), P = S.viewport, x = l.content - l.viewport, D = u(m), A = u(h), z = k(b, 10);

                    function N(e) {
                        R.current && v({
                            x: e.clientX - R.current.left,
                            y: e.clientY - R.current.top
                        })
                    }
                    return (0, o.useEffect)(() => {
                        let e = e => {
                            let t = e.target;
                            (null == C ? void 0 : C.contains(t)) && D(e, x)
                        };
                        return document.addEventListener("wheel", e, {
                            passive: !1
                        }), () => document.removeEventListener("wheel", e, {
                            passive: !1
                        })
                    }, [P, C, x, D]), (0, o.useEffect)(A, [l, A]), X(C, z), X(S.content, z), (0, o.createElement)(L, {
                        scope: r,
                        scrollbar: C,
                        hasThumb: a,
                        onThumbChange: u(s),
                        onThumbPointerUp: u(d),
                        onThumbPositionChange: A,
                        onThumbPointerDown: u(p)
                    }, (0, o.createElement)(i.div, (0, n.Z)({}, g, {
                        ref: T,
                        style: {
                            position: "absolute",
                            ...g.style
                        },
                        onPointerDown: f(e.onPointerDown, e => {
                            0 === e.button && (e.target.setPointerCapture(e.pointerId), R.current = C.getBoundingClientRect(), _.current = document.body.style.webkitUserSelect, document.body.style.webkitUserSelect = "none", S.viewport && (S.viewport.style.scrollBehavior = "auto"), N(e))
                        }),
                        onPointerMove: f(e.onPointerMove, N),
                        onPointerUp: f(e.onPointerUp, e => {
                            let t = e.target;
                            t.hasPointerCapture(e.pointerId) && t.releasePointerCapture(e.pointerId), document.body.style.webkitUserSelect = _.current, S.viewport && (S.viewport.style.scrollBehavior = ""), R.current = null
                        })
                    })))
                }),
                A = "ScrollAreaThumb",
                z = (0, o.forwardRef)((e, t) => {
                    let {
                        forceMount: r,
                        ...l
                    } = e, i = x(A, e.__scopeScrollArea);
                    return (0, o.createElement)(a.z, {
                        present: r || i.hasThumb
                    }, (0, o.createElement)(N, (0, n.Z)({
                        ref: t
                    }, l)))
                }),
                N = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeScrollArea: r,
                        style: l,
                        ...a
                    } = e, u = w(A, r), s = x(A, r), {
                        onThumbPositionChange: d
                    } = s, p = c(t, e => s.onThumbChange(e)), h = (0, o.useRef)(), v = k(() => {
                        h.current && (h.current(), h.current = void 0)
                    }, 100);
                    return (0, o.useEffect)(() => {
                        let e = u.viewport;
                        if (e) {
                            let t = () => {
                                if (v(), !h.current) {
                                    let t = Y(e, d);
                                    h.current = t, d()
                                }
                            };
                            return d(), e.addEventListener("scroll", t), () => e.removeEventListener("scroll", t)
                        }
                    }, [u.viewport, v, d]), (0, o.createElement)(i.div, (0, n.Z)({
                        "data-state": s.hasThumb ? "visible" : "hidden"
                    }, a, {
                        ref: p,
                        style: {
                            width: "var(--radix-scroll-area-thumb-width)",
                            height: "var(--radix-scroll-area-thumb-height)",
                            ...l
                        },
                        onPointerDownCapture: f(e.onPointerDownCapture, e => {
                            let t = e.target.getBoundingClientRect(),
                                r = e.clientX - t.left,
                                n = e.clientY - t.top;
                            s.onThumbPointerDown({
                                x: r,
                                y: n
                            })
                        }),
                        onPointerUp: f(e.onPointerUp, s.onThumbPointerUp)
                    }))
                });

            function M(e) {
                return e ? parseInt(e, 10) : 0
            }

            function Z(e, t) {
                let r = e / t;
                return isNaN(r) ? 0 : r
            }

            function W(e) {
                let t = Z(e.viewport, e.content),
                    r = e.scrollbar.paddingStart + e.scrollbar.paddingEnd;
                return Math.max((e.scrollbar.size - r) * t, 18)
            }

            function H(e, t, r = "ltr") {
                let n = W(t),
                    o = t.scrollbar.paddingStart + t.scrollbar.paddingEnd,
                    l = t.scrollbar.size - o,
                    i = t.content - t.viewport,
                    a = function(e, [t, r]) {
                        return Math.min(r, Math.max(t, e))
                    }(e, "ltr" === r ? [0, i] : [-1 * i, 0]);
                return O([0, i], [0, l - n])(a)
            }

            function O(e, t) {
                return r => {
                    if (e[0] === e[1] || t[0] === t[1]) return t[0];
                    let n = (t[1] - t[0]) / (e[1] - e[0]);
                    return t[0] + n * (r - e[0])
                }
            }(e, t) => {
                let {
                    __scopeScrollArea: r,
                    ...l
                } = e, a = w("ScrollAreaCorner", r), [c, u] = (0, o.useState)(0), [s, d] = (0, o.useState)(0), f = !!(c && s);
                return X(a.scrollbarX, () => {
                    var e;
                    let t = (null === (e = a.scrollbarX) || void 0 === e ? void 0 : e.offsetHeight) || 0;
                    a.onCornerHeightChange(t), d(t)
                }), X(a.scrollbarY, () => {
                    var e;
                    let t = (null === (e = a.scrollbarY) || void 0 === e ? void 0 : e.offsetWidth) || 0;
                    a.onCornerWidthChange(t), u(t)
                }), f ? (0, o.createElement)(i.div, (0, n.Z)({}, l, {
                    ref: t,
                    style: {
                        width: c,
                        height: s,
                        position: "absolute",
                        right: "ltr" === a.dir ? 0 : void 0,
                        left: "rtl" === a.dir ? 0 : void 0,
                        bottom: 0,
                        ...e.style
                    }
                })) : null
            };
            let Y = (e, t = () => {}) => {
                let r = {
                        left: e.scrollLeft,
                        top: e.scrollTop
                    },
                    n = 0;
                return ! function o() {
                    let l = {
                            left: e.scrollLeft,
                            top: e.scrollTop
                        },
                        i = r.left !== l.left,
                        a = r.top !== l.top;
                    (i || a) && t(), r = l, n = window.requestAnimationFrame(o)
                }(), () => window.cancelAnimationFrame(n)
            };

            function k(e, t) {
                let r = u(e),
                    n = (0, o.useRef)(0);
                return (0, o.useEffect)(() => () => window.clearTimeout(n.current), []), (0, o.useCallback)(() => {
                    window.clearTimeout(n.current), n.current = window.setTimeout(r, t)
                }, [r, t])
            }

            function X(e, t) {
                let r = u(t);
                d(() => {
                    let t = 0;
                    if (e) {
                        let n = new ResizeObserver(() => {
                            cancelAnimationFrame(t), t = window.requestAnimationFrame(r)
                        });
                        return n.observe(e), () => {
                            window.cancelAnimationFrame(t), n.unobserve(e)
                        }
                    }
                }, [e, r])
            }
            let I = b,
                U = g,
                F = S,
                $ = z
        },
        54735: function(e, t, r) {
            r.d(t, {
                qY: function() {
                    return p
                },
                ZP: function() {
                    return w
                }
            });
            let n = 1 / 60 * 1e3,
                o = "undefined" != typeof performance ? () => performance.now() : () => Date.now(),
                l = "undefined" != typeof window ? e => window.requestAnimationFrame(e) : e => setTimeout(() => e(o()), n),
                i = !0,
                a = !1,
                c = !1,
                u = {
                    delta: 0,
                    timestamp: 0
                },
                s = ["read", "update", "preRender", "render", "postRender"],
                d = s.reduce((e, t) => (e[t] = function(e) {
                    let t = [],
                        r = [],
                        n = 0,
                        o = !1,
                        l = !1,
                        i = new WeakSet,
                        a = {
                            schedule: (e, l = !1, a = !1) => {
                                let c = a && o,
                                    u = c ? t : r;
                                return l && i.add(e), -1 === u.indexOf(e) && (u.push(e), c && o && (n = t.length)), e
                            },
                            cancel: e => {
                                let t = r.indexOf(e); - 1 !== t && r.splice(t, 1), i.delete(e)
                            },
                            process: c => {
                                if (o) {
                                    l = !0;
                                    return
                                }
                                if (o = !0, [t, r] = [r, t], r.length = 0, n = t.length)
                                    for (let r = 0; r < n; r++) {
                                        let n = t[r];
                                        n(c), i.has(n) && (a.schedule(n), e())
                                    }
                                o = !1, l && (l = !1, a.process(c))
                            }
                        };
                    return a
                }(() => a = !0), e), {}),
                f = s.reduce((e, t) => {
                    let r = d[t];
                    return e[t] = (e, t = !1, n = !1) => (a || m(), r.schedule(e, t, n)), e
                }, {}),
                p = s.reduce((e, t) => (e[t] = d[t].cancel, e), {});
            s.reduce((e, t) => (e[t] = () => d[t].process(u), e), {});
            let h = e => d[e].process(u),
                v = e => {
                    a = !1, u.delta = i ? n : Math.max(Math.min(e - u.timestamp, 40), 1), u.timestamp = e, c = !0, s.forEach(h), c = !1, a && (i = !1, l(v))
                },
                m = () => {
                    a = !0, i = !0, c || l(v)
                };
            var w = f
        }
    }
]);