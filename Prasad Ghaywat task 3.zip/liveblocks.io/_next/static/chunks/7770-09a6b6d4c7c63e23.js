(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7770], {
        97770: function(e, t, n) {
            "use strict";
            n.d(t, {
                B: function() {
                    return _
                },
                h: function() {
                    return S
                }
            });
            var r = n(85893),
                o = n(5152),
                i = n.n(o),
                u = n(25675),
                a = n.n(u),
                s = n(67294),
                l = n(59820),
                c = {
                    src: "/_next/static/media/fallback-404.0a3e2e75.png",
                    height: 840,
                    width: 1120,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAD1BMVEUDAwMlJSURERJtbW1MS0stmZO8AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAG0lEQVR4nGNgwAKYGFkYITQzMyMThMUEpqEAAAKeABz7vwwyAAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 6
                },
                f = {
                    src: "/_next/static/media/fallback.0137060d.png",
                    height: 840,
                    width: 1120,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAD1BMVEUFBQUfHx9DQ0ORkZFYV1cYNrT+AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAGklEQVR4nGNgwAIYmVgYwQwmZmYmqBBEAAoAAi0AFaJq3c0AAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 6
                },
                d = n(48529),
                A = n(77470);
            let h = ["ArrowUp", "ArrowUp", "ArrowDown", "ArrowDown", "ArrowLeft", "ArrowRight", "ArrowLeft", "ArrowRight", "b", "a"];

            function v() {
                let e = (0, A.iv)(),
                    t = (0, s.useRef)(0);
                return (0, s.useEffect)(() => {
                    let n = n => {
                        n.key === h[t.current] ? (n.preventDefault(), t.current++, t.current >= h.length / 2 && e.setState({
                            shouldPreloadKonamiCode: !0
                        }), t.current === h.length && (t.current = 0, e.setState(e => ({
                            isKonamiCodeActive: !e.isKonamiCodeActive
                        })))) : t.current = 0
                    };
                    return window.addEventListener("keydown", n), () => {
                        window.removeEventListener("keydown", n)
                    }
                }, []), null
            }
            var w = n(99137),
                g = n(86611),
                p = n(63554),
                y = n(43893),
                m = n.n(y);
            let b = i()(() => Promise.all([n.e(3737), n.e(4782), n.e(2685), n.e(2561), n.e(7701), n.e(4493)]).then(n.bind(n, 64493)), {
                loadableGenerated: {
                    webpack: () => [64493]
                },
                loading: () => null,
                ssr: !1
            });
            async function E(e) {
                let t = await fetch(e);
                return (await t.json()).roomId
            }
            async function C(e) {
                let t = await fetch(e);
                return (await t.json()).count
            }

            function x(e) {
                let {
                    lobbyId: t,
                    children: n
                } = e, o = (0, A.iv)(), i = o(e => e.isActive), [u, a] = (0, s.useState)(0), {
                    data: c
                } = (0, l.ZP)("/api/lobby/".concat(t, "?max=").concat(4), E, {
                    revalidateOnFocus: !1,
                    revalidateIfStale: !1,
                    revalidateOnReconnect: !1
                }), {
                    data: f
                } = (0, l.ZP)(t && c && i ? "/api/lobby/".concat(t, "/count?filter=").concat(c) : null, C, {
                    refreshInterval: u >= 30 ? 6e4 : u >= 15 ? 4e4 : 2e4,
                    keepPreviousData: !0,
                    fallbackData: 0,
                    shouldRetryOnError: !1,
                    revalidateIfStale: !0,
                    revalidateOnFocus: !0,
                    revalidateOnMount: !0,
                    revalidateOnReconnect: !0,
                    refreshWhenHidden: !1,
                    refreshWhenOffline: !1,
                    onSuccess: () => {
                        a(e => e + 1)
                    }
                });
                return (0, s.useEffect)(() => {
                    c && o.setState({
                        roomId: c
                    })
                }, [c]), (0, s.useEffect)(() => {
                    "number" == typeof f && o.setState({
                        usersInOtherLobbies: f
                    })
                }, [f]), (0, r.jsx)(r.Fragment, {
                    children: c ? (0, r.jsx)(w.ke, {
                        id: c,
                        initialPresence: g.of,
                        initialStorage: g.XS,
                        autoConnect: !1,
                        children: n
                    }) : n
                })
            }

            function S(e) {
                let {
                    children: t
                } = e, [n] = (0, s.useState)(A.dJ);
                return (0, r.jsx)(A.WF, {
                    value: n,
                    children: t
                })
            }

            function _(e) {
                let {
                    lobbyId: t = "three-hero",
                    type: n = "liveblocks"
                } = e, o = (0, s.useRef)(null), i = (0, A.iv)(), u = i(e => e.isActive), [l, h] = (0, s.useState)(!1);
                return (0, s.useEffect)(() => {
                    if (!u) return;
                    let e = () => {
                        o.current && i.setState({
                            canvasContainerPosition: {
                                x: o.current.offsetLeft,
                                y: o.current.offsetTop
                            },
                            scrollTop: window.scrollY
                        })
                    };
                    return e(), window.addEventListener("resize", e), window.addEventListener("scroll", e), () => {
                        window.removeEventListener("resize", e), window.removeEventListener("scroll", e)
                    }
                }, [u]), (0, s.useEffect)(() => {
                    let e = (0, p.B)();
                    e || i.setState({
                        supportFlagEmojis: e
                    })
                }, []), (0, d.L)(() => {
                    let e;
                    let t = /^((?!chrome|android|edge).)*safari/i.test(navigator.userAgent),
                        n = /android/i.test(navigator.userAgent);
                    (e = t ? 1 : n ? 0 : 2) >= 1 && h(!0), i.setState({
                        tier: e
                    })
                }, []), (0, r.jsxs)("div", {
                    className: "relative z-0 h-full w-full",
                    ref: o,
                    children: [(0, r.jsxs)("div", {
                        className: "absolute left-0 top-0 z-0 h-full w-full",
                        "aria-hidden": !0,
                        children: [(0, r.jsx)(a(), {
                            src: "404" === n ? c : f,
                            alt: "A 3D scene with a projected image",
                            quality: 90,
                            priority: !0,
                            className: "select-none",
                            sizes: "(max-width: 1280px) 100vw, 1280px",
                            fill: !0
                        }), (0, r.jsx)("div", {
                            className: m().canvasGradientOverlay
                        }), (0, r.jsx)("div", {
                            className: m().canvasGradientSmallerOverlay
                        })]
                    }), (0, r.jsx)(x, {
                        lobbyId: t,
                        children: l ? (0, r.jsx)(b, {
                            type: n
                        }) : null
                    }), u && (0, r.jsx)(v, {})]
                })
            }
        },
        99137: function(e, t, n) {
            "use strict";
            n.d(t, {
                $z: function() {
                    return d
                },
                BU: function() {
                    return a
                },
                NW: function() {
                    return c
                },
                Sk: function() {
                    return f
                },
                YT: function() {
                    return s
                },
                ke: function() {
                    return u
                },
                pw: function() {
                    return h
                },
                v8: function() {
                    return l
                },
                y$: function() {
                    return A
                }
            });
            var r = n(10893),
                o = n(68739);
            let i = (0, r.eI)({
                    authEndpoint: "/api/three-hero/auth",
                    throttle: 16
                }),
                {
                    suspense: {
                        RoomProvider: u,
                        RoomContext: a,
                        useOthersConnectionIds: s,
                        useOther: l,
                        useRoom: c,
                        useSelf: f,
                        useStatus: d,
                        useStorage: A,
                        useUpdateMyPresence: h,
                        useMyPresence: v
                    }
                } = (0, o.m1)(i)
        },
        86611: function(e, t, n) {
            "use strict";
            n.d(t, {
                $6: function() {
                    return x
                },
                $Q: function() {
                    return R
                },
                AN: function() {
                    return f
                },
                BL: function() {
                    return y
                },
                CG: function() {
                    return c
                },
                Cb: function() {
                    return O
                },
                DG: function() {
                    return s
                },
                HS: function() {
                    return j
                },
                Ir: function() {
                    return I
                },
                KU: function() {
                    return d
                },
                Kr: function() {
                    return h
                },
                Ln: function() {
                    return v
                },
                MJ: function() {
                    return a
                },
                Mc: function() {
                    return B
                },
                Pi: function() {
                    return i
                },
                QF: function() {
                    return z
                },
                VU: function() {
                    return E
                },
                VW: function() {
                    return m
                },
                WW: function() {
                    return P
                },
                X3: function() {
                    return w
                },
                XS: function() {
                    return U
                },
                Xh: function() {
                    return C
                },
                f: function() {
                    return l
                },
                ft: function() {
                    return A
                },
                kf: function() {
                    return D
                },
                kr: function() {
                    return g
                },
                l5: function() {
                    return S
                },
                nH: function() {
                    return p
                },
                of: function() {
                    return H
                },
                pq: function() {
                    return _
                },
                qg: function() {
                    return o
                },
                uf: function() {
                    return b
                },
                wB: function() {
                    return T
                },
                yP: function() {
                    return u
                }
            });
            var r = n(63554);
            let o = "#000",
                i = 1,
                u = 1.75,
                a = 6,
                s = 20,
                l = 50,
                c = 3,
                f = 48,
                d = 24,
                A = -2,
                h = -1,
                v = 3.9,
                w = 100,
                g = 1500,
                p = .25,
                y = 1,
                m = Math.PI / 3.25,
                b = 68,
                E = -.5,
                C = .12,
                x = .03,
                S = .12,
                _ = .2,
                z = .15,
                O = 45,
                B = .022222222222222223,
                P = 2e3,
                I = 3e3,
                T = 5e3,
                D = 40,
                R = "Say something…",
                j = [{
                    position: {
                        x: -2.39977837,
                        y: .49899212,
                        z: -1.62679482
                    },
                    rotation: {
                        w: -.07787337,
                        x: -.07786447,
                        y: -.70280397,
                        z: .70280826
                    },
                    wallsOffset: .5,
                    groundOffset: .8,
                    product: "comments",
                    color: "#CB6604",
                    colorIntensityFactor: 2.25
                }, {
                    position: {
                        x: 1.73407972,
                        y: .49898955,
                        z: -.66381592
                    },
                    rotation: {
                        w: .10004429,
                        x: .1000601,
                        y: -.69999111,
                        z: .69999397
                    },
                    wallsOffset: .5,
                    groundOffset: .8,
                    product: "notifications",
                    color: "#00895B",
                    colorIntensityFactor: 3
                }, {
                    position: {
                        x: .93798095,
                        y: .4989948,
                        z: 1.15175843
                    },
                    rotation: {
                        w: .6090644,
                        x: -.35921574,
                        y: -.35922122,
                        z: .60906869
                    },
                    wallsOffset: .5,
                    groundOffset: .8,
                    product: "text-editor",
                    color: "#444FB4",
                    colorIntensityFactor: 3.5
                }, {
                    position: {
                        x: -.79971457,
                        y: 1.49748385,
                        z: 1.21006274
                    },
                    rotation: {
                        w: -.37493455,
                        x: 15119e-8,
                        y: .92705131,
                        z: 227e-7
                    },
                    wallsOffset: .5,
                    groundOffset: .8,
                    product: "custom-editor",
                    color: "#BC0F49",
                    colorIntensityFactor: 3
                }, {
                    position: {
                        x: -1.01094651,
                        y: .4989861,
                        z: 1.27128446
                    },
                    rotation: {
                        w: .58569825,
                        x: -.58570051,
                        y: -.39616579,
                        z: -.39618835
                    },
                    wallsOffset: .5,
                    groundOffset: .8
                }, {
                    position: {
                        x: -.74438918,
                        y: .49898928,
                        z: -3.19619107
                    },
                    rotation: {
                        w: .99304932,
                        x: -.00001917,
                        y: .11769839,
                        z: 4e-7
                    },
                    wallsOffset: .5,
                    groundOffset: .8
                }, {
                    position: {
                        x: 4.03934526,
                        y: .64903879,
                        z: -.11830344
                    },
                    rotation: {
                        w: .90250778,
                        x: .20165384,
                        y: .23959228,
                        z: .29565346
                    },
                    wallsOffset: .65,
                    groundOffset: .9
                }, {
                    position: {
                        x: .43278393,
                        y: .55047446,
                        z: 4.14998484
                    },
                    rotation: {
                        w: .28097793,
                        x: -.64839125,
                        y: .15527119,
                        z: .69031221
                    },
                    wallsOffset: .56,
                    groundOffset: .85
                }, {
                    position: {
                        x: 1.50084472,
                        y: .30073762,
                        z: -3.38085055
                    },
                    rotation: {
                        w: .44551736,
                        x: .63669306,
                        y: -.3608613,
                        z: .51566964
                    },
                    wallsOffset: .76,
                    groundOffset: .6
                }, {
                    position: {
                        x: -3.87502575,
                        y: .24929214,
                        z: 1.52530396
                    },
                    rotation: {
                        w: .97913402,
                        x: 31345e-8,
                        y: .20321475,
                        z: -.00043568
                    },
                    wallsOffset: .5,
                    groundOffset: .5
                }, {
                    position: {
                        x: 1.72860193,
                        y: 1.24755049,
                        z: -.84499854
                    },
                    rotation: {
                        w: .58134758,
                        x: -.00004788,
                        y: .81365532,
                        z: -.00006836
                    },
                    wallsOffset: .5,
                    groundOffset: .5
                }],
                H = {
                    cursor: null,
                    chat: ""
                },
                U = (0, r.I)(j)
        },
        63554: function(e, t, n) {
            "use strict";
            n.d(t, {
                B: function() {
                    return a
                },
                I: function() {
                    return u
                }
            });
            var r = n(10893);
            let o = {
                    x: 0,
                    y: 0,
                    z: 0
                },
                i = {
                    w: 1,
                    x: 0,
                    y: 0,
                    z: 0
                };

            function u(e) {
                return {
                    shapes: new r.oV(e.map((e, t) => {
                        var n;
                        let u = {
                            isDraggedBy: !1,
                            isLockedBy: !1,
                            position: e.position,
                            rotation: null !== (n = e.rotation) && void 0 !== n ? n : i,
                            angularVelocity: o,
                            linearVelocity: o
                        };
                        return [String(t), new r.EU(u)]
                    }))
                }
            }

            function a() {
                let e = document.createElement("canvas").getContext("2d", {
                    willReadFrequently: !0
                });
                return !!e && (e.font = "".concat(Math.floor(12.5), "px ").concat(function() {
                    try {
                        let e = document.createElement("span");
                        e.style.display = "none", e.dataset.emoji = "", document.body.appendChild(e);
                        let t = window.getComputedStyle(e).fontFamily;
                        return document.body.removeChild(e), t
                    } catch (e) {
                        return "'Apple Color Emoji', 'Noto Color Emoji', 'Twemoji Mozilla', 'Android Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', EmojiSymbols, sans-serif"
                    }
                }()), e.textBaseline = "top", e.canvas.width = 40, e.canvas.height = 25, function(e, t) {
                    e.clearRect(0, 0, 40, 25), e.fillStyle = "#f00", e.fillText(t, 0, 22), e.fillStyle = "#00f", e.fillText(t, 20, 22);
                    let n = e.getImageData(0, 0, 20, 25).data,
                        r = n.length,
                        o = 0;
                    for (; o < r && !n[o + 3]; o += 4);
                    if (o >= r) return !1;
                    let i = 20 + o / 4 % 20,
                        u = Math.floor(o / 4 / 20),
                        a = e.getImageData(i, u, 1, 1).data;
                    return n[o] === a[0] && n[o + 2] === a[2] && !(e.measureText(t).width >= 20)
                }(e, "\uD83C\uDDEB\uD83C\uDDF7"))
            }
        },
        77470: function(e, t, n) {
            "use strict";
            n.d(t, {
                WF: function() {
                    return s
                },
                dJ: function() {
                    return i
                },
                iv: function() {
                    return a
                }
            });
            var r = n(67294),
                o = n(73445);

            function i() {
                return (0, o.Ue)((e, t) => ({
                    connectionId: null,
                    others: [],
                    storage: null,
                    isStorageReady: !1,
                    pointer: null,
                    bodyCursor: null,
                    isAuthority: !1,
                    isActive: !1,
                    shouldApplyRemainingExplosionsIfAuthority: 0,
                    last3dPointer: void 0,
                    currentDragging3dPointer: void 0,
                    currentShapePointer: void 0,
                    isProduct0Hover: !1,
                    isProduct1Hover: !1,
                    isProduct2Hover: !1,
                    isProduct3Hover: !1,
                    setProductHover: (t, n) => e(() => ({
                        ["isProduct".concat(t, "Hover")]: n
                    })),
                    isPuzzleButton0Completed: !1,
                    isPuzzleButton1Completed: !1,
                    isPuzzleButton2Completed: !1,
                    isPuzzleButton3Completed: !1,
                    setPuzzleButtonCompleted: (t, n) => e(() => ({
                        ["isPuzzleButton".concat(t, "Completed")]: n
                    })),
                    getShapeLiveObject: e => {
                        let n = t().storage;
                        if (n) return n.get("shapes").get(e)
                    },
                    isLoaded: !1,
                    cameraControls: null,
                    cursorsContainerRef: {
                        current: null
                    },
                    cursorChatInputRef: {
                        current: null
                    },
                    roomId: void 0,
                    usersInOtherLobbies: 0,
                    cursorChat: null,
                    canvasContainerPosition: null,
                    scrollTop: 0,
                    supportFlagEmojis: !0,
                    isCameraMoving: !1,
                    isKonamiCodeActive: !1,
                    shouldPreloadKonamiCode: !1,
                    tier: 0,
                    isDragging: !1
                }))
            }
            let u = (0, r.createContext)(null);

            function a() {
                return (0, r.useContext)(u)
            }
            let s = u.Provider
        },
        43893: function(e) {
            e.exports = {
                canvas: "ThreeHero_canvas__SrcGX",
                canvasContainer: "ThreeHero_canvasContainer__UIBeZ",
                canvasGradientOverlay: "ThreeHero_canvasGradientOverlay__y0Ase",
                canvasGradientSmallerOverlay: "ThreeHero_canvasGradientSmallerOverlay__rRRY8",
                cursorsContainer: "ThreeHero_cursorsContainer__iMRb6",
                cursorBubblePosition: "ThreeHero_cursorBubblePosition__1IImQ",
                cursorBubble: "ThreeHero_cursorBubble__j2_ns",
                cursorBubbleName: "ThreeHero_cursorBubbleName__wr7rJ",
                cursorBubbleChat: "ThreeHero_cursorBubbleChat__CN2h1",
                cursorChatPosition: "ThreeHero_cursorChatPosition__UCSgl",
                cursorChatBubble: "ThreeHero_cursorChatBubble__VAQQE",
                fade: "ThreeHero_fade__dKJc0",
                countPing: "ThreeHero_countPing__rEWTk",
                ping: "ThreeHero_ping__TOY4P"
            }
        },
        50139: function(e, t, n) {
            "use strict";
            var r = n(67294),
                o = n(61688),
                i = "function" == typeof Object.is ? Object.is : function(e, t) {
                    return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
                },
                u = o.useSyncExternalStore,
                a = r.useRef,
                s = r.useEffect,
                l = r.useMemo,
                c = r.useDebugValue;
            t.useSyncExternalStoreWithSelector = function(e, t, n, r, o) {
                var f = a(null);
                if (null === f.current) {
                    var d = {
                        hasValue: !1,
                        value: null
                    };
                    f.current = d
                } else d = f.current;
                var A = u(e, (f = l(function() {
                    function e(e) {
                        if (!s) {
                            if (s = !0, u = e, e = r(e), void 0 !== o && d.hasValue) {
                                var t = d.value;
                                if (o(t, e)) return a = t
                            }
                            return a = e
                        }
                        if (t = a, i(u, e)) return t;
                        var n = r(e);
                        return void 0 !== o && o(t, n) ? t : (u = e, a = n)
                    }
                    var u, a, s = !1,
                        l = void 0 === n ? null : n;
                    return [function() {
                        return e(t())
                    }, null === l ? void 0 : function() {
                        return e(l())
                    }]
                }, [t, n, r, o]))[0], f[1]);
                return s(function() {
                    d.hasValue = !0, d.value = A
                }, [A]), c(A), A
            }
        },
        52798: function(e, t, n) {
            "use strict";
            e.exports = n(50139)
        },
        73445: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ue: function() {
                    return d
                },
                oR: function() {
                    return c
                }
            });
            var r = n(43973),
                o = n(67294),
                i = n(52798);
            let {
                useDebugValue: u
            } = o, {
                useSyncExternalStoreWithSelector: a
            } = i, s = !1, l = e => e;

            function c(e, t = l, n) {
                n && !s && (console.warn("[DEPRECATED] Use `createWithEqualityFn` instead of `create` or use `useStoreWithEqualityFn` instead of `useStore`. They can be imported from 'zustand/traditional'. https://github.com/pmndrs/zustand/discussions/1937"), s = !0);
                let r = a(e.subscribe, e.getState, e.getServerState || e.getInitialState, t, n);
                return u(r), r
            }
            let f = e => {
                    "function" != typeof e && console.warn("[DEPRECATED] Passing a vanilla store will be unsupported in a future version. Instead use `import { useStore } from 'zustand'`.");
                    let t = "function" == typeof e ? (0, r.M)(e) : e,
                        n = (e, n) => c(t, e, n);
                    return Object.assign(n, t), n
                },
                d = e => e ? f(e) : f
        },
        43973: function(e, t, n) {
            "use strict";
            n.d(t, {
                M: function() {
                    return o
                }
            });
            let r = e => {
                    let t;
                    let n = new Set,
                        r = (e, r) => {
                            let o = "function" == typeof e ? e(t) : e;
                            if (!Object.is(o, t)) {
                                let e = t;
                                t = (null != r ? r : "object" != typeof o || null === o) ? o : Object.assign({}, t, o), n.forEach(n => n(t, e))
                            }
                        },
                        o = () => t,
                        i = {
                            setState: r,
                            getState: o,
                            getInitialState: () => u,
                            subscribe: e => (n.add(e), () => n.delete(e)),
                            destroy: () => {
                                console.warn("[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected."), n.clear()
                            }
                        },
                        u = t = e(r, o, i);
                    return i
                },
                o = e => e ? r(e) : r
        }
    }
]);