"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5208], {
        51233: function(e, l, t) {
            var a, r, s, n, i, c, o, d, m, x = t(67294);

            function u() {
                return (u = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var t = arguments[l];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            l.Z = function(e) {
                return x.createElement("svg", u({
                    width: 143,
                    height: 32,
                    viewBox: "0 0 143 32",
                    fill: "white",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), a || (a = x.createElement("path", {
                    d: "M45.2578 27.6959H35.6292V24.4061H38.3172V3.38354H35.4688V0.09375H42.5698V24.4061H45.2578V27.6959ZM63.3644 22.1995C63.2039 23.7776 62.4283 25.155 61.0375 26.3318C59.6467 27.5087 57.7344 28.0971 55.3005 28.0971C52.6794 28.0971 50.5263 27.3348 48.8413 25.8103C47.1563 24.259 46.3138 21.9856 46.3138 18.99C46.3138 16.2351 47.0761 13.9349 48.6006 12.0895C50.1518 10.244 52.3049 9.32121 55.0597 9.32121C57.5471 9.32121 59.513 10.0701 60.9573 11.5679C62.4283 13.0389 63.1772 14.9112 63.2039 17.1846C63.2039 17.9335 63.1237 18.7359 62.9632 19.5918H50.8071C51.0478 22.9618 52.6526 24.6468 55.6214 24.6468C57.0122 24.6468 58.0018 24.3125 58.5902 23.6438C59.2054 22.9752 59.6066 22.2664 59.7938 21.5175L63.3644 22.1995ZM58.7908 16.9439C58.8978 15.874 58.6437 14.8711 58.0286 13.9349C57.4401 12.9721 56.4372 12.4906 55.0196 12.4906C53.7358 12.4906 52.7596 12.9186 52.0909 13.7745C51.4223 14.6303 51.0077 15.6868 50.8472 16.9439H58.7908ZM84.1676 27.6959H75.542V24.4061H77.2671L74.0174 20.7151L70.8079 24.4061H72.3324V27.6959H64.2685V24.4061H66.7559L71.9714 18.7894L66.4349 12.9721H64.3889V9.68229H73.1749V12.9721H71.4899L74.4989 16.5828L77.7084 12.9721H76.1438V9.68229H83.7263V12.9721H81.8407L76.6653 18.3882L82.2419 24.4061H84.1676V27.6959ZM87.7511 5.95118V1.21709H92.124V5.95118H87.7511ZM94.9324 27.6959H85.3038V24.4061H87.9918V13.0122H85.1433V9.68229H92.2444V24.4061H94.9324V27.6959ZM112.745 21.2367C112.558 22.8415 111.849 24.3927 110.619 25.8905C109.388 27.3616 107.409 28.0971 104.681 28.0971C102.113 28.0971 100.014 27.3215 98.3824 25.7702C96.7776 24.2189 95.9752 21.9588 95.9752 18.99C95.9752 16.0746 96.8044 13.7343 98.4626 11.9691C100.148 10.2038 102.341 9.32121 105.042 9.32121C106.112 9.32121 107.182 9.45494 108.252 9.72241C109.322 9.98987 110.378 10.4312 111.421 11.0463L112.143 16.1014L108.693 16.4625L108.091 13.4936C107.117 13.0158 106.047 12.7687 104.962 12.7715C101.966 12.7715 100.469 14.7775 100.469 18.7894C100.469 22.6943 102.006 24.6468 105.082 24.6468C107.329 24.6468 108.68 23.2828 109.134 20.5546L112.745 21.2367ZM115.746 11.0062C117.083 10.3643 118.273 9.923 119.316 9.68229C120.36 9.44157 121.563 9.32121 122.927 9.32121C124.933 9.32121 126.578 9.82939 127.862 10.8458C129.172 11.8621 129.828 13.3866 129.828 15.4194V23.5235C129.828 24.5933 130.269 25.1283 131.152 25.1283C131.392 25.1283 131.7 25.0748 132.074 24.9678L132.114 27.3348C131.232 27.843 130.269 28.0971 129.226 28.0971C126.952 28.0971 125.722 26.9069 125.535 24.5265V24.4462C125 25.3823 124.238 26.2249 123.248 26.9738C122.285 27.7226 121.082 28.0971 119.637 28.0971C118.38 28.0971 117.137 27.7226 115.906 26.9738C114.703 26.1981 114.101 24.8608 114.101 22.9618C114.101 20.7419 114.984 19.2842 116.749 18.5888C118.514 17.8666 120.426 17.5056 122.486 17.5056C122.994 17.5056 123.516 17.5189 124.05 17.5457C124.585 17.5724 125.08 17.6126 125.535 17.666V16.6631C125.535 15.5932 125.348 14.6303 124.973 13.7745C124.599 12.9186 123.663 12.4906 122.165 12.4906C121.603 12.4906 121.068 12.5308 120.56 12.611C120.079 12.6912 119.611 12.8517 119.156 13.0924L118.434 15.8607L114.984 15.4996L115.746 11.0062ZM125.535 20.5546V19.9127C125.067 19.8577 124.599 19.8042 124.131 19.7523C123.638 19.6981 123.142 19.6714 122.646 19.672C121.576 19.672 120.614 19.8592 119.758 20.2337C118.929 20.6081 118.514 21.357 118.514 22.4804C118.514 24.1119 119.383 24.9277 121.122 24.9277C122.138 24.9277 123.101 24.5666 124.01 23.8444C124.92 23.0955 125.428 21.9989 125.535 20.5546ZM142.348 27.6959H132.719V24.4061H135.407V3.38354H132.559V0.09375H139.66V24.4061H142.348V27.6959Z",
                    fill: "currentFill"
                })), r || (r = x.createElement("path", {
                    d: "M87.6423 1.19531H92.1796V5.97143H87.6423V1.19531ZM4.77734 13.6132H10.031V16.0013H4.77734V13.6132Z",
                    fill: "currentFill",
                    fillOpacity: .2
                })), s || (s = x.createElement("path", {
                    d: "M11.2266 13.6094H16.4802V15.9974H11.2266V13.6094Z",
                    fill: "currentFill"
                })), n || (n = x.createElement("path", {
                    d: "M17.6728 13.6094H19.822V15.9974H17.6728V13.6094ZM4.77734 17.4303H13.3743V19.8183H4.77734V17.4303ZM14.5683 17.4303H19.822V19.8183H14.5683V17.4303Z",
                    fill: "currentFill",
                    fillOpacity: .2
                })), i || (i = x.createElement("path", {
                    d: "M4.77734 21.2578H10.031V23.6459H4.77734V21.2578Z",
                    fill: "currentFill"
                })), c || (c = x.createElement("path", {
                    d: "M11.2266 21.2578H16.4802V23.6459H11.2266V21.2578Z",
                    fill: "currentFill",
                    fillOpacity: .2
                })), o || (o = x.createElement("path", {
                    d: "M17.6719 21.2578H19.8211V23.6459H17.6719V21.2578Z",
                    fill: "currentFill"
                })), d || (d = x.createElement("path", {
                    d: "M0 8.83594H19.8207V11.224H2.38804V26.03H19.8207V28.418H0V8.83594ZM28.1789 8.83594H24.5968V11.224H25.7908V26.03H24.5968V28.418H28.1789V8.83594Z",
                    fill: "currentFill"
                })), m || (m = x.createElement("path", {
                    d: "M18.6289 7.64587V5.25781H26.0318V7.64587H23.405V29.616H26.0318V32.0041H18.6289V29.616H21.0169V7.64587H18.6289Z",
                    fill: "currentFill"
                })))
            }
        },
        60716: function(e, l, t) {
            var a, r = t(67294);

            function s() {
                return (s = Object.assign ? Object.assign.bind() : function(e) {
                    for (var l = 1; l < arguments.length; l++) {
                        var t = arguments[l];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            l.Z = function(e) {
                return r.createElement("svg", s({
                    width: 139,
                    height: 32,
                    viewBox: "0 0 139 32",
                    fill: "white",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), a || (a = r.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M16.318 0c3.756 0 7.204 1.313 9.912 3.504H6.406A15.703 15.703 0 0 1 16.318 0Zm50.008 8.647V4.835h3.813v3.812h-3.813Zm0 17.633V10.554h3.813V26.28h-3.813ZM46.953 5.312h16.68v3.575h-6.315V26.28h-4.05V8.887h-6.315V5.312Zm30.406 5.839v-.596h-3.812v21.446h3.812v-6.404c0-.596-.149-1.072-.417-1.609-.149-.297-.268-.595.06-.714.23-.077.351.133.418.25.011.019.02.035.029.047.953 1.728 2.591 2.95 4.974 2.95 4.08 0 6.85-3.575 6.85-8.102 0-4.528-2.77-8.102-6.85-8.102-2.442 0-4.021 1.25-4.974 2.919l-.007.013c-.065.132-.242.488-.53.344-.258-.129-.135-.415-.02-.683.017-.04.035-.081.05-.12.268-.537.417-1.013.417-1.639Zm8.102 7.268c0 2.502-1.251 4.646-3.932 4.646-2.502 0-4.17-2.144-4.17-4.646s1.668-4.647 4.17-4.647c2.681 0 3.932 2.145 3.932 4.647Zm15.804-4.528h-4.29v7.178c0 1.728.03 1.876 1.639 1.876h2.651v3.336H97.81c-3.158 0-4.647-1.042-4.647-4.825v-7.565h-2.86v-3.336h2.86v-4.29h3.813v4.29h4.289v3.336Zm17.699-3.336h-3.813v.596c0 .626.149 1.102.416 1.638.15.298.328.655.03.804-.288.145-.465-.214-.53-.345l-.006-.012c-.863-1.728-2.531-2.919-4.974-2.919-4.08 0-6.85 3.574-6.85 8.102 0 4.527 2.77 8.101 6.85 8.101 2.383 0 3.872-1.31 4.974-2.948l.01-.016.007-.013.011-.019c.067-.117.188-.327.419-.25.328.119.209.417.059.714-.267.537-.416 1.013-.416 1.609v.685h3.813V10.555Zm-3.813 7.864c0 2.502-1.668 4.646-4.17 4.646-2.681 0-3.932-2.144-3.932-4.646s1.251-4.647 3.932-4.647c2.502 0 4.17 2.145 4.17 4.647Zm11.037-7.864v.596c0 .626-.149 1.102-.418 1.638l-.028.068-.023.055c-.114.267-.237.552.022.681.288.144.464-.212.529-.344l.007-.013c.953-1.668 2.531-2.919 4.973-2.919 4.082 0 6.852 3.574 6.852 8.102 0 4.527-2.77 8.101-6.852 8.101-2.382 0-4.02-1.221-4.973-2.948l-.029-.048c-.067-.117-.187-.327-.418-.25-.328.119-.208.417-.06.714.269.537.418 1.013.418 1.609V32h-3.813V10.555h3.813Zm4.17 12.51c2.68 0 3.931-2.144 3.931-4.646s-1.251-4.647-3.931-4.647c-2.503 0-4.17 2.145-4.17 4.647 0 2.502 1.667 4.646 4.17 4.646ZM1.447 10.513A15.713 15.713 0 0 1 3.205 7.01H29.43a15.712 15.712 0 0 1 1.758 3.504H1.447Zm-.898 5.255c0 .592.033 1.176.096 1.752h31.346a15.965 15.965 0 0 0 0-3.504H.645a15.94 15.94 0 0 0-.096 1.752Zm2.656 8.76a15.712 15.712 0 0 1-1.758-3.503h29.742a15.711 15.711 0 0 1-1.758 3.504H3.205Zm13.113 7.01c3.756 0 7.204-1.313 9.912-3.505H6.406a15.702 15.702 0 0 0 9.912 3.505Z",
                    fill: "currentFill"
                })))
            }
        },
        30659: function(e, l, t) {
            t.d(l, {
                H: function() {
                    return s
                }
            });
            var a = t(85893),
                r = t(20402);
            let s = e => {
                let {
                    className: l,
                    type: t = "avatar",
                    size: s = "md",
                    appearance: n
                } = e;
                return (0, a.jsx)("span", {
                    className: (0, r.cn)(l, "block shrink-0 bg-black shadow-[0px_0px_2px_0px_rgba(255,255,255,0.40)_inset,0px_0px_var(--glow-depth-a)_0px_var(--glow-color-a)_inset,0px_0px_var(--glow-depth-b)_0px_var(--glow-color-b)_inset]", {
                        "rounded-full": "avatar" === t,
                        "rounded-[50%] rounded-tl-md": "pin" === t,
                        "size-3 [--glow-depth-a:4px] [--glow-depth-b:8px]": "xs" === s,
                        "size-6 [--glow-depth-a:10px] [--glow-depth-b:16px]": "sm" === s,
                        "size-7 [--glow-depth-a:10px] [--glow-depth-b:20px]": "md" === s,
                        "size-14 [--glow-depth-a:15px] [--glow-depth-b:30px]": "lg" === s,
                        "[--glow-color-a:rgba(255,255,255,0.6)] [--glow-color-b:#595959]": !n,
                        "[--glow-color-a:#FFE500] [--glow-color-b:#FF0000]": "comments" === n,
                        "[--glow-color-a:#00C2FF] [--glow-color-b:#00F051]": "notifications" === n,
                        "[--glow-color-a:#00D1FF] [--glow-color-b:#CC00FF]": "text-editor" === n,
                        "[--glow-color-a:#FF2E00] [--glow-color-b:#FF00B8]": "realtime-apis" === n,
                        "[--glow-color-a:var(--lb-marketing-color-background-surface-accent-green-bold)] [--glow-color-b:var(--lb-marketing-color-background-surface-accent-green)]": "green" === n,
                        "[--glow-color-a:var(--lb-marketing-color-background-surface-accent-yellow-bold)] [--glow-color-b:var(--lb-marketing-color-background-surface-accent-yellow)]": "yellow" === n,
                        "[--glow-color-a:var(--lb-marketing-color-background-surface-accent-blue-bold)] [--glow-color-b:var(--lb-marketing-color-background-surface-accent-blue)]": "blue" === n,
                        "[--glow-color-a:var(--lb-marketing-color-background-surface-accent-pink-bold)] [--glow-color-b:var(--lb-marketing-color-background-surface-accent-pink)]": "pink" === n
                    })
                })
            }
        },
        92605: function(e, l, t) {
            t.d(l, {
                Z: function() {
                    return s
                }
            });
            var a = t(85893),
                r = t(20402);

            function s(e) {
                let {
                    children: l,
                    pointerEventsEnabled: t
                } = e;
                return (0, a.jsx)("div", {
                    className: (0, r.cn)("relative flex size-full min-h-52 flex-1 flex-col items-center justify-center pt-[--inner-gutter]", t ? "pointer-events-auto" : "pointer-events-none select-none"),
                    children: l
                })
            }
        },
        69430: function(e, l, t) {
            var a = t(85893),
                r = t(30659);
            l.Z = e => {
                let {
                    type: l
                } = e;
                return (0, a.jsx)("div", {
                    role: "img",
                    "aria-label": "Illustration of the Liveblocks dashboard.",
                    className: "pointer-events-none absolute inset-0 flex select-none justify-center pt-[calc(2*var(--inner-gutter))]",
                    children: (0, a.jsxs)("div", {
                        className: "relative aspect-video w-full max-w-md rounded-md bg-marketing-surface-faded-subtle",
                        children: [(0, a.jsx)("div", {
                            className: "flex gap-1 p-3",
                            children: [, , , ].fill(null).map((e, l) => (0, a.jsx)("span", {
                                className: "size-1.5 rounded-full bg-marketing-surface-faded"
                            }, l))
                        }), (0, a.jsxs)("div", {
                            className: "absolute left-9 top-9 aspect-square w-full max-w-md rounded-md border border-marketing-divider bg-marketing-surface-base",
                            children: ["text-editor" === l ? (0, a.jsxs)(a.Fragment, {
                                children: [(0, a.jsxs)("div", {
                                    className: "border-b border-marketing-divider text-marketing-subtle",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-2 p-3",
                                        children: [(0, a.jsx)(r.H, {
                                            appearance: "text-editor",
                                            size: "xs"
                                        }), (0, a.jsx)("span", {
                                            className: "text-2xs font-medium",
                                            children: "room-1990-12000"
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex items-center gap-3 px-3",
                                        children: [(0, a.jsx)("div", {
                                            className: "relative pb-2 text-[9px] font-medium text-marketing before:absolute before:bottom-0 before:left-0 before:right-0 before:h-px before:bg-marketing-surface-product-text-editor",
                                            children: "Text Editor"
                                        }), (0, a.jsx)("div", {
                                            className: "pb-2 text-[9px] font-medium text-marketing-subtlest",
                                            children: "Comments"
                                        }), (0, a.jsx)("div", {
                                            className: "pb-2 text-[9px] font-medium text-marketing-subtlest",
                                            children: "Metadata"
                                        }), (0, a.jsx)("div", {
                                            className: "pb-2 text-[9px] font-medium text-marketing-subtlest",
                                            children: "Permissions"
                                        })]
                                    })]
                                }), (0, a.jsx)("div", {
                                    className: "mt-3 flex items-center justify-center p-gutter",
                                    children: (0, a.jsxs)("div", {
                                        className: "mx-auto max-w-2xs",
                                        children: [(0, a.jsx)("div", {
                                            className: "text-lg font-semibold leading-snug text-marketing",
                                            children: "Hello world"
                                        }), (0, a.jsx)("div", {
                                            className: "mt-2 text-2xs leading-snug text-marketing-subtler",
                                            children: "Liveblocks Text Editor enables you to enhance your product with all the table stakes collaborative features people expect in a modern text editor."
                                        })]
                                    })
                                })]
                            }) : null, "project-overview" === l ? (0, a.jsxs)(a.Fragment, {
                                children: [(0, a.jsx)("div", {
                                    className: "flex items-center gap-2 p-3",
                                    children: (0, a.jsx)("span", {
                                        className: "text-2xs font-medium",
                                        children: "Overview"
                                    })
                                }), (0, a.jsxs)("div", {
                                    className: "grid grid-cols-2 gap-2 px-3",
                                    children: [(0, a.jsxs)("div", {
                                        className: "relative h-32 rounded border border-marketing-divider p-2",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex flex-col gap-0.5",
                                            children: [(0, a.jsx)("span", {
                                                className: "text-[9px] text-marketing-subtler",
                                                children: "Active users"
                                            }), (0, a.jsx)("span", {
                                                className: "text-lg font-medium leading-none",
                                                children: "12,000"
                                            })]
                                        }), (0, a.jsx)("div", {
                                            className: "absolute left-2 right-2 top-2 h-[90px]",
                                            children: (0, a.jsxs)("svg", {
                                                width: "157",
                                                height: "90",
                                                viewBox: "0 0 157 90",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                className: "h-auto w-full",
                                                children: [(0, a.jsx)("path", {
                                                    d: "M1 74L14 70L27 65L38 60L50 52L62 50L75 51L89 45L105 44L115 28L132.5 25.5L144 13.5L156 1",
                                                    className: "stroke-marketing-divider-product-text-editor",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }), (0, a.jsx)("path", {
                                                    d: "M1 89L14 81L27 84L38 75L50 66L62 69L75 70L89 64L105 55L115 54L132.5 44.5L145.5 28L156 25",
                                                    className: "stroke-marketing-divider-product-comments",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                }), (0, a.jsx)("path", {
                                                    d: "M27 89L38 75L49 69L62 66L75 64L89 60L105 50L115 46L132.5 48.5L145.5 39L156 32",
                                                    className: "stroke-marketing-divider-product-notifications",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                })]
                                            })
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "relative h-32 rounded border border-marketing-divider p-2",
                                        children: [(0, a.jsxs)("div", {
                                            className: "flex flex-col gap-0.5",
                                            children: [(0, a.jsx)("span", {
                                                className: "text-[9px] text-marketing-subtler",
                                                children: "Active rooms"
                                            }), (0, a.jsx)("span", {
                                                className: "text-lg font-medium leading-none",
                                                children: "1,990"
                                            })]
                                        }), (0, a.jsx)("div", {
                                            className: "absolute left-2 right-2 top-2 h-[90px]",
                                            children: (0, a.jsx)("svg", {
                                                width: "157",
                                                height: "90",
                                                viewBox: "0 0 157 90",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                className: "h-auto w-full",
                                                children: (0, a.jsx)("path", {
                                                    d: "M1 74L14 62L27 57L38 60L50 52L62 50L75 46L89 49L105 44L115 33L132.5 29.5L144 17.5L156 9",
                                                    className: "stroke-marketing-divider-boldest",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round"
                                                })
                                            })
                                        })]
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "grid grid-cols-3 gap-2 px-3 pt-2",
                                    children: [(0, a.jsx)("div", {
                                        className: "aspect-square rounded border border-marketing-divider p-2",
                                        children: (0, a.jsxs)("div", {
                                            className: "flex flex-col gap-0.5",
                                            children: [(0, a.jsx)("span", {
                                                className: "text-[9px] text-marketing-subtler",
                                                children: "Comments"
                                            }), (0, a.jsx)("span", {
                                                className: "text-base font-medium leading-none",
                                                children: "1,804"
                                            })]
                                        })
                                    }), (0, a.jsx)("div", {
                                        className: "aspect-square rounded border border-marketing-divider p-2",
                                        children: (0, a.jsxs)("div", {
                                            className: "flex flex-col gap-0.5",
                                            children: [(0, a.jsx)("span", {
                                                className: "text-[9px] text-marketing-subtler",
                                                children: "Notifications"
                                            }), (0, a.jsx)("span", {
                                                className: "text-base font-medium leading-none",
                                                children: "193"
                                            })]
                                        })
                                    }), (0, a.jsx)("div", {
                                        className: "aspect-square rounded border border-marketing-divider p-2",
                                        children: (0, a.jsxs)("div", {
                                            className: "flex flex-col gap-0.5",
                                            children: [(0, a.jsx)("span", {
                                                className: "text-[9px] text-marketing-subtler",
                                                children: "Data stored"
                                            }), (0, a.jsx)("span", {
                                                className: "text-base font-medium leading-none",
                                                children: "34 Mb"
                                            })]
                                        })
                                    })]
                                })]
                            }) : null]
                        })]
                    })
                })
            }
        },
        12376: function(e, l, t) {
            var a = t(85893);
            t(67294);
            var r = t(51233),
                s = t(60716),
                n = t(81237);
            l.Z = () => (0, a.jsx)("div", {
                role: "img",
                "aria-label": "Logos of Lexical and Tiptap, two open-source text editor frameworks that Liveblocks integrates with.",
                className: "pointer-events-none select-none",
                children: (0, a.jsxs)("div", {
                    className: "flex flex-col items-center gap-8",
                    children: [(0, a.jsx)(r.Z, {
                        className: "h-8 w-auto"
                    }), (0, a.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [(0, a.jsx)(s.Z, {
                            className: "h-8 w-auto"
                        }), (0, a.jsx)(n.C, {
                            className: "translate-y-0.5",
                            size: "sm",
                            children: "Soon"
                        })]
                    })]
                })
            })
        },
        40999: function(e, l, t) {
            var a = t(85893),
                r = t(49329),
                s = t(82925);
            l.Z = e => {
                let {
                    children: l,
                    actions: t
                } = e;
                return (0, a.jsx)(r.Z, {
                    children: (0, a.jsxs)("div", {
                        className: "mx-auto max-w-sm md:max-w-md lg:max-w-lg xl:max-w-xl",
                        children: [(0, a.jsx)(s.x, {
                            className: "f-marketing-body-md flex flex-col gap-gutter max-sm:pr-[2%]",
                            children: l
                        }), t ? (0, a.jsx)("div", {
                            className: "mt-5 inline-flex flex-col items-center gap-2 sm:mt-6 sm:flex-row",
                            children: t
                        }) : null]
                    })
                })
            }
        }
    }
]);