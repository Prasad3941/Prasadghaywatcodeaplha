"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [297], {
        13114: function(e, t, n) {
            n.d(t, {
                M: function() {
                    return v
                }
            });
            var r = n(85893),
                o = n(67294),
                i = n(240),
                l = n(96681),
                s = n(16014);
            class u extends o.Component {
                getSnapshotBeforeUpdate(e) {
                    let t = this.props.childRef.current;
                    if (t && e.isPresent && !this.props.isPresent) {
                        let e = this.props.sizeRef.current;
                        e.height = t.offsetHeight || 0, e.width = t.offsetWidth || 0, e.top = t.offsetTop, e.left = t.offsetLeft
                    }
                    return null
                }
                componentDidUpdate() {}
                render() {
                    return this.props.children
                }
            }

            function f({
                children: e,
                isPresent: t
            }) {
                let n = (0, o.useId)(),
                    i = (0, o.useRef)(null),
                    l = (0, o.useRef)({
                        width: 0,
                        height: 0,
                        top: 0,
                        left: 0
                    }),
                    {
                        nonce: f
                    } = (0, o.useContext)(s._);
                return (0, o.useInsertionEffect)(() => {
                    let {
                        width: e,
                        height: r,
                        top: o,
                        left: s
                    } = l.current;
                    if (t || !i.current || !e || !r) return;
                    i.current.dataset.motionPopId = n;
                    let u = document.createElement("style");
                    return f && (u.nonce = f), document.head.appendChild(u), u.sheet && u.sheet.insertRule(`
          [data-motion-pop-id="${n}"] {
            position: absolute !important;
            width: ${e}px !important;
            height: ${r}px !important;
            top: ${o}px !important;
            left: ${s}px !important;
          }
        `), () => {
                        document.head.removeChild(u)
                    }
                }, [t]), (0, r.jsx)(u, {
                    isPresent: t,
                    childRef: i,
                    sizeRef: l,
                    children: o.cloneElement(e, {
                        ref: i
                    })
                })
            }
            let c = ({
                children: e,
                initial: t,
                isPresent: n,
                onExitComplete: s,
                custom: u,
                presenceAffectsLayout: c,
                mode: d
            }) => {
                let h = (0, l.h)(a),
                    p = (0, o.useId)(),
                    g = (0, o.useMemo)(() => ({
                        id: p,
                        initial: t,
                        isPresent: n,
                        custom: u,
                        onExitComplete: e => {
                            for (let t of (h.set(e, !0), h.values()))
                                if (!t) return;
                            s && s()
                        },
                        register: e => (h.set(e, !1), () => h.delete(e))
                    }), c ? [Math.random()] : [n]);
                return (0, o.useMemo)(() => {
                    h.forEach((e, t) => h.set(t, !1))
                }, [n]), o.useEffect(() => {
                    n || h.size || !s || s()
                }, [n]), "popLayout" === d && (e = (0, r.jsx)(f, {
                    isPresent: n,
                    children: e
                })), (0, r.jsx)(i.O.Provider, {
                    value: g,
                    children: e
                })
            };

            function a() {
                return new Map
            }
            var d = n(25364),
                h = n(45487);
            let p = e => e.key || "";

            function g(e) {
                let t = [];
                return o.Children.forEach(e, e => {
                    (0, o.isValidElement)(e) && t.push(e)
                }), t
            }
            var m = n(58868);
            let v = ({
                children: e,
                exitBeforeEnter: t,
                custom: n,
                initial: i = !0,
                onExitComplete: s,
                presenceAffectsLayout: u = !0,
                mode: f = "sync"
            }) => {
                (0, h.k)(!t, "Replace exitBeforeEnter with mode='wait'");
                let a = (0, o.useMemo)(() => g(e), [e]),
                    v = a.map(p),
                    w = (0, o.useRef)(!0),
                    y = (0, o.useRef)(a),
                    x = (0, l.h)(() => new Map),
                    [E, L] = (0, o.useState)(a),
                    [W, B] = (0, o.useState)(a);
                (0, m.L)(() => {
                    w.current = !1, y.current = a;
                    for (let e = 0; e < W.length; e++) {
                        let t = p(W[e]);
                        v.includes(t) ? x.delete(t) : !0 !== x.get(t) && x.set(t, !1)
                    }
                }, [W, v.length, v.join("-")]);
                let R = [];
                if (a !== E) {
                    let e = [...a];
                    for (let t = 0; t < W.length; t++) {
                        let n = W[t],
                            r = p(n);
                        v.includes(r) || (e.splice(t, 0, n), R.push(n))
                    }
                    "wait" === f && R.length && (e = R), B(g(e)), L(a);
                    return
                }
                let {
                    forceRender: S
                } = (0, o.useContext)(d.p);
                return (0, r.jsx)(r.Fragment, {
                    children: W.map(e => {
                        let t = p(e),
                            o = a === W || v.includes(t);
                        return (0, r.jsx)(c, {
                            isPresent: o,
                            initial: (!w.current || !!i) && void 0,
                            custom: o ? void 0 : n,
                            presenceAffectsLayout: u,
                            mode: f,
                            onExitComplete: o ? void 0 : () => {
                                if (!x.has(t)) return;
                                x.set(t, !0);
                                let e = !0;
                                x.forEach(t => {
                                    t || (e = !1)
                                }), e && (null == S || S(), B(y.current), s && s())
                            },
                            children: e
                        }, t)
                    })
                })
            }
        },
        70832: function(e, t, n) {
            n.d(t, {
                S: function() {
                    return d
                }
            });
            var r = n(85893),
                o = n(67294),
                i = n(25364);
            let l = (0, o.createContext)(null);
            var s = n(58868),
                u = n(26166);
            let f = e => !e.isLayoutDirty && e.willUpdate(!1),
                c = e => !0 === e,
                a = e => c(!0 === e) || "id" === e,
                d = ({
                    children: e,
                    id: t,
                    inherit: n = !0
                }) => {
                    let d = (0, o.useContext)(i.p),
                        h = (0, o.useContext)(l),
                        [p, g] = function() {
                            let e = function() {
                                    let e = (0, o.useRef)(!1);
                                    return (0, s.L)(() => (e.current = !0, () => {
                                        e.current = !1
                                    }), []), e
                                }(),
                                [t, n] = (0, o.useState)(0),
                                r = (0, o.useCallback)(() => {
                                    e.current && n(t + 1)
                                }, [t]);
                            return [(0, o.useCallback)(() => u.Wi.postRender(r), [r]), t]
                        }(),
                        m = (0, o.useRef)(null),
                        v = d.id || h;
                    null === m.current && (a(n) && v && (t = t ? v + "-" + t : v), m.current = {
                        id: t,
                        group: c(n) && d.group || function() {
                            let e = new Set,
                                t = new WeakMap,
                                n = () => e.forEach(f);
                            return {
                                add: r => {
                                    e.add(r), t.set(r, r.addEventListener("willUpdate", n))
                                },
                                remove: r => {
                                    e.delete(r);
                                    let o = t.get(r);
                                    o && (o(), t.delete(r)), n()
                                },
                                dirty: n
                            }
                        }()
                    });
                    let w = (0, o.useMemo)(() => ({ ...m.current,
                        forceRender: p
                    }), [g]);
                    return (0, r.jsx)(i.p.Provider, {
                        value: w,
                        children: e
                    })
                }
        },
        37301: function(e, t, n) {
            n.d(t, {
                I: function() {
                    return o
                }
            });
            var r = n(45487);

            function o(e, t, n) {
                var o;
                if ("string" == typeof e) {
                    let i = document;
                    t && ((0, r.k)(!!t.current, "Scope provided, but no element detected."), i = t.current), n ? (null !== (o = n[e]) && void 0 !== o || (n[e] = i.querySelectorAll(e)), e = n[e]) : e = i.querySelectorAll(e)
                } else e instanceof Element && (e = [e]);
                return Array.from(e || [])
            }
        },
        79645: function(e, t, n) {
            let r, o;
            n.d(t, {
                v: function() {
                    return $
                }
            });
            var i = n(33234),
                l = n(96681),
                s = n(67294),
                u = n(45487),
                f = n(37301);
            let c = new WeakMap;

            function a({
                target: e,
                contentRect: t,
                borderBoxSize: n
            }) {
                var r;
                null === (r = c.get(e)) || void 0 === r || r.forEach(r => {
                    r({
                        target: e,
                        contentSize: t,
                        get size() {
                            return function(e, t) {
                                if (t) {
                                    let {
                                        inlineSize: e,
                                        blockSize: n
                                    } = t[0];
                                    return {
                                        width: e,
                                        height: n
                                    }
                                }
                                return e instanceof SVGElement && "getBBox" in e ? e.getBBox() : {
                                    width: e.offsetWidth,
                                    height: e.offsetHeight
                                }
                            }(e, n)
                        }
                    })
                })
            }

            function d(e) {
                e.forEach(a)
            }
            let h = new Set;
            var p = n(23967),
                g = n(3038);
            let m = () => ({
                    current: 0,
                    offset: [],
                    progress: 0,
                    scrollLength: 0,
                    targetOffset: 0,
                    targetLength: 0,
                    containerLength: 0,
                    velocity: 0
                }),
                v = () => ({
                    time: 0,
                    x: m(),
                    y: m()
                }),
                w = {
                    x: {
                        length: "Width",
                        position: "Left"
                    },
                    y: {
                        length: "Height",
                        position: "Top"
                    }
                };

            function y(e, t, n, r) {
                let o = n[t],
                    {
                        length: i,
                        position: l
                    } = w[t],
                    s = o.current,
                    u = n.time;
                o.current = e[`scroll${l}`], o.scrollLength = e[`scroll${i}`] - e[`client${i}`], o.offset.length = 0, o.offset[0] = 0, o.offset[1] = o.scrollLength, o.progress = (0, p.Y)(0, o.scrollLength, o.current);
                let f = r - u;
                o.velocity = f > 50 ? 0 : (0, g.R)(o.current - s, f)
            }
            let x = [
                    [0, 0],
                    [1, 1]
                ],
                E = {
                    start: 0,
                    center: .5,
                    end: 1
                };

            function L(e, t, n = 0) {
                let r = 0;
                if (e in E && (e = E[e]), "string" == typeof e) {
                    let t = parseFloat(e);
                    e.endsWith("px") ? r = t : e.endsWith("%") ? e = t / 100 : e.endsWith("vw") ? r = t / 100 * document.documentElement.clientWidth : e.endsWith("vh") ? r = t / 100 * document.documentElement.clientHeight : e = t
                }
                return "number" == typeof e && (r = t * e), n + r
            }
            let W = [0, 0];
            var B = n(71884),
                R = n(60599);
            let S = {
                x: 0,
                y: 0
            };
            var b = n(26166);
            let C = new WeakMap,
                k = new WeakMap,
                P = new WeakMap,
                z = e => e === document.documentElement ? window : e;
            var M = n(58868);

            function H(e, t) {
                (0, u.K)(!!(!t || t.current), `You have defined a ${e} options but the provided ref is not yet hydrated, probably because it's defined higher up the tree. Try calling useScroll() in the same component as the ref, or setting its \`layoutEffect: false\` option.`)
            }
            let O = () => ({
                scrollX: (0, i.BX)(0),
                scrollY: (0, i.BX)(0),
                scrollXProgress: (0, i.BX)(0),
                scrollYProgress: (0, i.BX)(0)
            });

            function $({
                container: e,
                target: t,
                layoutEffect: n = !0,
                ...i
            } = {}) {
                let u = (0, l.h)(O);
                return (n ? M.L : s.useEffect)(() => (H("target", t), H("container", e), function(e, {
                    container: t = document.documentElement,
                    ...n
                } = {}) {
                    let i = P.get(t);
                    i || (i = new Set, P.set(t, i));
                    let l = function(e, t, n, r = {}) {
                        return {
                            measure: () => (function(e, t = e, n) {
                                if (n.x.targetOffset = 0, n.y.targetOffset = 0, t !== e) {
                                    let r = t;
                                    for (; r && r !== e;) n.x.targetOffset += r.offsetLeft, n.y.targetOffset += r.offsetTop, r = r.offsetParent
                                }
                                n.x.targetLength = t === e ? t.scrollWidth : t.clientWidth, n.y.targetLength = t === e ? t.scrollHeight : t.clientHeight, n.x.containerLength = e.clientWidth, n.y.containerLength = e.clientHeight
                            })(e, r.target, n),
                            update: t => {
                                y(e, "x", n, t), y(e, "y", n, t), n.time = t, (r.offset || r.target) && function(e, t, n) {
                                    let {
                                        offset: r = x
                                    } = n, {
                                        target: o = e,
                                        axis: i = "y"
                                    } = n, l = "y" === i ? "height" : "width", s = o !== e ? function(e, t) {
                                        let n = {
                                                x: 0,
                                                y: 0
                                            },
                                            r = e;
                                        for (; r && r !== t;)
                                            if (r instanceof HTMLElement) n.x += r.offsetLeft, n.y += r.offsetTop, r = r.offsetParent;
                                            else if ("svg" === r.tagName) {
                                            let e = r.getBoundingClientRect(),
                                                t = (r = r.parentElement).getBoundingClientRect();
                                            n.x += e.left - t.left, n.y += e.top - t.top
                                        } else if (r instanceof SVGGraphicsElement) {
                                            let {
                                                x: e,
                                                y: t
                                            } = r.getBBox();
                                            n.x += e, n.y += t;
                                            let o = null,
                                                i = r.parentNode;
                                            for (; !o;) "svg" === i.tagName && (o = i), i = r.parentNode;
                                            r = o
                                        } else break;
                                        return n
                                    }(o, e) : S, u = o === e ? {
                                        width: e.scrollWidth,
                                        height: e.scrollHeight
                                    } : "getBBox" in o && "svg" !== o.tagName ? o.getBBox() : {
                                        width: o.clientWidth,
                                        height: o.clientHeight
                                    }, f = {
                                        width: e.clientWidth,
                                        height: e.clientHeight
                                    };
                                    t[i].offset.length = 0;
                                    let c = !t[i].interpolate,
                                        a = r.length;
                                    for (let e = 0; e < a; e++) {
                                        let n = function(e, t, n, r) {
                                            let o = Array.isArray(e) ? e : W,
                                                i = 0;
                                            return "number" == typeof e ? o = [e, e] : "string" == typeof e && (o = (e = e.trim()).includes(" ") ? e.split(" ") : [e, E[e] ? e : "0"]), L(o[0], n, r) - L(o[1], t)
                                        }(r[e], f[l], u[l], s[i]);
                                        c || n === t[i].interpolatorOffsets[e] || (c = !0), t[i].offset[e] = n
                                    }
                                    c && (t[i].interpolate = (0, B.s)(t[i].offset, (0, R.Y)(r)), t[i].interpolatorOffsets = [...t[i].offset]), t[i].progress = t[i].interpolate(t[i].current)
                                }(e, n, r)
                            },
                            notify: () => t(n)
                        }
                    }(t, e, v(), n);
                    if (i.add(l), !C.has(t)) {
                        let e = () => {
                                for (let e of i) e.measure()
                            },
                            n = () => {
                                for (let e of i) e.update(b.frameData.timestamp)
                            },
                            l = () => {
                                for (let e of i) e.notify()
                            },
                            s = () => {
                                b.Wi.read(e, !1, !0), b.Wi.read(n, !1, !0), b.Wi.update(l, !1, !0)
                            };
                        C.set(t, s);
                        let u = z(t);
                        window.addEventListener("resize", s, {
                            passive: !0
                        }), t !== document.documentElement && k.set(t, "function" == typeof t ? (h.add(t), o || (o = () => {
                            let e = {
                                    width: window.innerWidth,
                                    height: window.innerHeight
                                },
                                t = {
                                    target: window,
                                    size: e,
                                    contentSize: e
                                };
                            h.forEach(e => e(t))
                        }, window.addEventListener("resize", o)), () => {
                            h.delete(t), !h.size && o && (o = void 0)
                        }) : function(e, t) {
                            r || "undefined" == typeof ResizeObserver || (r = new ResizeObserver(d));
                            let n = (0, f.I)(e);
                            return n.forEach(e => {
                                let n = c.get(e);
                                n || (n = new Set, c.set(e, n)), n.add(t), null == r || r.observe(e)
                            }), () => {
                                n.forEach(e => {
                                    let n = c.get(e);
                                    null == n || n.delete(t), (null == n ? void 0 : n.size) || null == r || r.unobserve(e)
                                })
                            }
                        }(t, s)), u.addEventListener("scroll", s, {
                            passive: !0
                        })
                    }
                    let s = C.get(t);
                    return b.Wi.read(s, !1, !0), () => {
                        var e;
                        (0, b.Pn)(s);
                        let n = P.get(t);
                        if (!n || (n.delete(l), n.size)) return;
                        let r = C.get(t);
                        C.delete(t), r && (z(t).removeEventListener("scroll", r), null === (e = k.get(t)) || void 0 === e || e(), window.removeEventListener("resize", r))
                    }
                }(({
                    x: e,
                    y: t
                }) => {
                    u.scrollX.set(e.current), u.scrollXProgress.set(e.progress), u.scrollY.set(t.current), u.scrollYProgress.set(t.progress)
                }, { ...i,
                    container: (null == e ? void 0 : e.current) || void 0,
                    target: (null == t ? void 0 : t.current) || void 0
                })), [e, t, JSON.stringify(i.offset)]), u
            }
        }
    }
]);