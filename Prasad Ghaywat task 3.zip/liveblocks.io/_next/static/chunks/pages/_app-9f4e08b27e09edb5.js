(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2888, 6514], {
        73606: function(e, t, n) {
            "use strict";
            t.aF = t.dr = void 0;
            let r = n(97582),
                o = r.__importStar(n(95933));
            Object.defineProperty(t, "dr", {
                enumerable: !0,
                get: function() {
                    return o.default
                }
            }), Object.defineProperty(t, "aF", {
                enumerable: !0,
                get: function() {
                    return o.useUser
                }
            }), r.__importDefault(n(34519))
        },
        80489: function(e, t, n) {
            "use strict";
            var r = n(83454);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.useConfig = void 0;
            let o = n(97582).__importStar(n(67294)),
                i = (0, o.createContext)({});
            t.useConfig = () => (0, o.useContext)(i), t.default = ({
                children: e,
                loginUrl: t = r.env.NEXT_PUBLIC_AUTH0_LOGIN || "/api/auth/login"
            }) => o.default.createElement(i.Provider, {
                value: {
                    loginUrl: t
                }
            }, e)
        },
        95933: function(e, t, n) {
            "use strict";
            var r = n(83454);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.useUser = t.UserContext = t.RequestError = void 0;
            let o = n(97582),
                i = o.__importStar(n(67294)),
                u = o.__importDefault(n(80489));
            class c extends Error {
                constructor(e) {
                    super(), this.status = e, Object.setPrototypeOf(this, c.prototype)
                }
            }
            t.RequestError = c;
            let l = "You forgot to wrap your app in <UserProvider>";
            t.UserContext = (0, i.createContext)({
                get user() {
                    throw Error(l)
                },
                get error() {
                    throw Error(l)
                },
                get isLoading() {
                    throw Error(l)
                },
                checkSession: () => {
                    throw Error(l)
                }
            }), t.useUser = () => (0, i.useContext)(t.UserContext);
            let s = async e => {
                let t;
                try {
                    t = await fetch(e)
                } catch (e) {
                    throw new c(0)
                }
                if (204 != t.status) {
                    if (t.ok) return t.json();
                    throw new c(t.status)
                }
            };
            t.default = ({
                children: e,
                user: n,
                profileUrl: o = r.env.NEXT_PUBLIC_AUTH0_PROFILE || "/api/auth/me",
                loginUrl: c,
                fetcher: l = s
            }) => {
                let [a, f] = (0, i.useState)({
                    user: n,
                    isLoading: !n
                }), d = (0, i.useCallback)(async () => {
                    try {
                        let e = await l(o);
                        f(t => Object.assign(Object.assign({}, t), {
                            user: e,
                            error: void 0
                        }))
                    } catch (e) {
                        f(t => Object.assign(Object.assign({}, t), {
                            error: e
                        }))
                    }
                }, [o]);
                (0, i.useEffect)(() => {
                    a.user || (async () => {
                        await d(), f(e => Object.assign(Object.assign({}, e), {
                            isLoading: !1
                        }))
                    })()
                }, [a.user]);
                let {
                    user: p,
                    error: m,
                    isLoading: h
                } = a, E = (0, i.useMemo)(() => ({
                    user: p,
                    error: m,
                    isLoading: h,
                    checkSession: d
                }), [p, m, h, d]);
                return i.default.createElement(u.default, {
                    loginUrl: c
                }, i.default.createElement(t.UserContext.Provider, {
                    value: E
                }, e))
            }
        },
        34519: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            let r = n(97582).__importStar(n(67294)),
                o = n(80489),
                i = n(95933),
                u = () => r.default.createElement(r.default.Fragment, null),
                c = () => r.default.createElement(r.default.Fragment, null);
            t.default = (e, t = {}) => function(n) {
                let {
                    returnTo: l,
                    onRedirecting: s = u,
                    onError: a = c
                } = t, {
                    loginUrl: f
                } = (0, o.useConfig)(), {
                    user: d,
                    error: p,
                    isLoading: m
                } = (0, i.useUser)();
                return ((0, r.useEffect)(() => {
                    let e;
                    if ((!d || p) && !m) {
                        if (l) e = l;
                        else {
                            let t = window.location.toString();
                            e = t.replace(new URL(t).origin, "") || "/"
                        }
                        window.location.assign(`${f}?returnTo=${encodeURIComponent(e)}`)
                    }
                }, [d, p, m]), p) ? a(p) : d ? r.default.createElement(e, Object.assign({
                    user: d
                }, n)) : s()
            }
        },
        89701: function(e, t, n) {
            "use strict";
            var r, o = n(67294);

            function i() {
                return (i = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            t.Z = function(e) {
                return o.createElement("svg", i({
                    "aria-hidden": "true",
                    focusable: "false",
                    width: 16,
                    height: 16,
                    viewBox: "0 0 16 16",
                    fill: "currentColor",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), r || (r = o.createElement("path", {
                    d: "M8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1Zm-1 9.795-2.5-2.5.795-.795L7 9.205 10.705 5.5l.798.793L7 10.795Z"
                })))
            }
        },
        23007: function(e, t, n) {
            "use strict";
            var r, o = n(67294);

            function i() {
                return (i = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            t.Z = function(e) {
                return o.createElement("svg", i({
                    "aria-hidden": "true",
                    focusable: "false",
                    width: 16,
                    height: 16,
                    viewBox: "0 0 16 16",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), r || (r = o.createElement("path", {
                    d: "M13 3.875 12.125 3 8 7.125 3.875 3 3 3.875 7.125 8 3 12.125l.875.875L8 8.875 12.125 13l.875-.875L8.875 8 13 3.875Z"
                })))
            }
        },
        42012: function(e, t, n) {
            "use strict";
            var r, o = n(67294);

            function i() {
                return (i = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            t.Z = function(e) {
                return o.createElement("svg", i({
                    "aria-hidden": "true",
                    focusable: "false",
                    width: 16,
                    height: 16,
                    viewBox: "0 0 16 16",
                    fill: "currentColor",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), r || (r = o.createElement("path", {
                    d: "M8 1C4.15 1 1 4.15 1 8s3.15 7 7 7 7-3.15 7-7-3.15-7-7-7Zm-.55 3h1.1v5.5h-1.1V4ZM8 12.5c-.4 0-.75-.35-.75-.75S7.6 11 8 11s.75.35.75.75-.35.75-.75.75Z"
                })))
            }
        },
        83454: function(e, t, n) {
            "use strict";
            var r, o;
            e.exports = (null == (r = n.g.process) ? void 0 : r.env) && "object" == typeof(null == (o = n.g.process) ? void 0 : o.env) ? n.g.process : n(77663)
        },
        6840: function(e, t, n) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/_app", function() {
                return n(8876)
            }])
        },
        94096: function(e, t, n) {
            "use strict";
            n.d(t, {
                R1: function() {
                    return l
                },
                pr: function() {
                    return c
                }
            });
            var r = n(85893),
                o = n(4298),
                i = n.n(o);
            n(67294);
            let u = "6472508";

            function c() {
                return (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)(i(), {
                        id: "linkedin_insight_tag_first_script",
                        children: '\n        _linkedin_partner_id = "'.concat(u, '";\n        window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];\n        window._linkedin_data_partner_ids.push(_linkedin_partner_id);\n      ')
                    }), (0, r.jsx)(i(), {
                        id: "linkedin_insight_tag_second_script",
                        children: '\n        (function(l) {\n        if (!l){window.lintrk = function(a,b){window.lintrk.q.push([a,b])};\n        window.lintrk.q=[]}\n        var s = document.getElementsByTagName("script")[0];\n        var b = document.createElement("script");\n        b.type = "text/javascript";b.async = true;\n        b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";\n        s.parentNode.insertBefore(b, s);})(window.lintrk);\n      '
                    }), (0, r.jsx)("noscript", {
                        children: (0, r.jsx)("img", {
                            height: "1",
                            width: "1",
                            style: {
                                display: "none"
                            },
                            alt: "",
                            src: "https://px.ads.linkedin.com/collect/?pid=".concat(u, "&fmt=gif")
                        })
                    })]
                })
            }

            function l() {
                return (0, r.jsx)(i(), {
                    id: "koala_marketing_tag_script",
                    children: '!function(t){if(window.ko)return;window.ko=[],["identify","track","removeListeners","open","on","off","qualify","ready"].forEach(function(t){ko[t]=function(){var n=[].slice.call(arguments);return n.unshift(t),ko.push(n),ko}});var n=document.createElement("script");n.async=!0,n.setAttribute("src","https://cdn.getkoala.com/v1/pk_e9b2386c2e455bec07174f69f6841dfe454a/sdk.js"),(document.body || document.head).appendChild(n)}();'
                })
            }
        },
        19606: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                    value: !0
                }),
                function(e, t) {
                    for (var n in t) Object.defineProperty(e, n, {
                        enumerable: !0,
                        get: t[n]
                    })
                }(t, {
                    default: function() {
                        return c
                    },
                    noSSR: function() {
                        return u
                    }
                });
            let r = n(38754);
            n(85893), n(67294);
            let o = r._(n(6119));

            function i(e) {
                return {
                    default: (null == e ? void 0 : e.default) || e
                }
            }

            function u(e, t) {
                return delete t.webpack, delete t.modules, e(t)
            }

            function c(e, t) {
                let n = o.default,
                    r = {
                        loading: e => {
                            let {
                                error: t,
                                isLoading: n,
                                pastDelay: r
                            } = e;
                            return null
                        }
                    };
                e instanceof Promise ? r.loader = () => e : "function" == typeof e ? r.loader = e : "object" == typeof e && (r = { ...r,
                    ...e
                });
                let c = (r = { ...r,
                    ...t
                }).loader;
                return (r.loadableGenerated && (r = { ...r,
                    ...r.loadableGenerated
                }, delete r.loadableGenerated), "boolean" != typeof r.ssr || r.ssr) ? n({ ...r,
                    loader: () => null != c ? c().then(i) : Promise.resolve(i(() => null))
                }) : (delete r.webpack, delete r.modules, u(n, r))
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        16725: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "LoadableContext", {
                enumerable: !0,
                get: function() {
                    return r
                }
            });
            let r = n(38754)._(n(67294)).default.createContext(null)
        },
        6119: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return d
                }
            });
            let r = n(38754)._(n(67294)),
                o = n(16725),
                i = [],
                u = [],
                c = !1;

            function l(e) {
                let t = e(),
                    n = {
                        loading: !0,
                        loaded: null,
                        error: null
                    };
                return n.promise = t.then(e => (n.loading = !1, n.loaded = e, e)).catch(e => {
                    throw n.loading = !1, n.error = e, e
                }), n
            }
            class s {
                promise() {
                    return this._res.promise
                }
                retry() {
                    this._clearTimeouts(), this._res = this._loadFn(this._opts.loader), this._state = {
                        pastDelay: !1,
                        timedOut: !1
                    };
                    let {
                        _res: e,
                        _opts: t
                    } = this;
                    e.loading && ("number" == typeof t.delay && (0 === t.delay ? this._state.pastDelay = !0 : this._delay = setTimeout(() => {
                        this._update({
                            pastDelay: !0
                        })
                    }, t.delay)), "number" == typeof t.timeout && (this._timeout = setTimeout(() => {
                        this._update({
                            timedOut: !0
                        })
                    }, t.timeout))), this._res.promise.then(() => {
                        this._update({}), this._clearTimeouts()
                    }).catch(e => {
                        this._update({}), this._clearTimeouts()
                    }), this._update({})
                }
                _update(e) {
                    this._state = { ...this._state,
                        error: this._res.error,
                        loaded: this._res.loaded,
                        loading: this._res.loading,
                        ...e
                    }, this._callbacks.forEach(e => e())
                }
                _clearTimeouts() {
                    clearTimeout(this._delay), clearTimeout(this._timeout)
                }
                getCurrentValue() {
                    return this._state
                }
                subscribe(e) {
                    return this._callbacks.add(e), () => {
                        this._callbacks.delete(e)
                    }
                }
                constructor(e, t) {
                    this._loadFn = e, this._opts = t, this._callbacks = new Set, this._delay = null, this._timeout = null, this.retry()
                }
            }

            function a(e) {
                return function(e, t) {
                    let n = Object.assign({
                            loader: null,
                            loading: null,
                            delay: 200,
                            timeout: null,
                            webpack: null,
                            modules: null
                        }, t),
                        i = null;

                    function l() {
                        if (!i) {
                            let t = new s(e, n);
                            i = {
                                getCurrentValue: t.getCurrentValue.bind(t),
                                subscribe: t.subscribe.bind(t),
                                retry: t.retry.bind(t),
                                promise: t.promise.bind(t)
                            }
                        }
                        return i.promise()
                    }
                    if (!c) {
                        let e = n.webpack ? n.webpack() : n.modules;
                        e && u.push(t => {
                            for (let n of e)
                                if (t.includes(n)) return l()
                        })
                    }

                    function a(e, t) {
                        ! function() {
                            l();
                            let e = r.default.useContext(o.LoadableContext);
                            e && Array.isArray(n.modules) && n.modules.forEach(t => {
                                e(t)
                            })
                        }();
                        let u = r.default.useSyncExternalStore(i.subscribe, i.getCurrentValue, i.getCurrentValue);
                        return r.default.useImperativeHandle(t, () => ({
                            retry: i.retry
                        }), []), r.default.useMemo(() => {
                            var t;
                            return u.loading || u.error ? r.default.createElement(n.loading, {
                                isLoading: u.loading,
                                pastDelay: u.pastDelay,
                                timedOut: u.timedOut,
                                error: u.error,
                                retry: i.retry
                            }) : u.loaded ? r.default.createElement((t = u.loaded) && t.default ? t.default : t, e) : null
                        }, [e, u])
                    }
                    return a.preload = () => l(), a.displayName = "LoadableComponent", r.default.forwardRef(a)
                }(l, e)
            }

            function f(e, t) {
                let n = [];
                for (; e.length;) {
                    let r = e.pop();
                    n.push(r(t))
                }
                return Promise.all(n).then(() => {
                    if (e.length) return f(e, t)
                })
            }
            a.preloadAll = () => new Promise((e, t) => {
                f(i).then(e, t)
            }), a.preloadReady = e => (void 0 === e && (e = []), new Promise(t => {
                let n = () => (c = !0, t());
                f(u, e).then(n, n)
            })), window.__NEXT_PRELOADREADY = a.preloadReady;
            let d = a
        },
        8876: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return R
                }
            });
            var r = n(85893),
                o = n(73606),
                i = n(16012),
                u = n(93967),
                c = n.n(u),
                l = n(5152),
                s = n.n(l),
                a = n(9008),
                f = n.n(a),
                d = n(4298),
                p = n.n(d);
            n(67294);
            var m = n(4848),
                h = n(16003),
                E = n(18106),
                g = n(5360),
                v = n.n(g),
                b = n(84070),
                y = n.n(b),
                T = n(7854),
                _ = n.n(T),
                w = n(60162),
                x = n(29096),
                O = n(94096);

            function S() {
                let [e] = (0, w.e)();
                return e.marketing ? (0, r.jsx)(O.pr, {}) : null
            }
            var C = n(48529);
            n(17232), n(92808), n(60832), s()(() => Promise.all([n.e(1818), n.e(1692)]).then(n.bind(n, 1692)).then(e => e.TailwindScreenIndicator), {
                loadableGenerated: {
                    webpack: () => [1692]
                },
                ssr: !1
            });
            var R = function(e) {
                let {
                    Component: t,
                    pageProps: n
                } = e;
                return (0, C.L)(() => {
                    document.documentElement.style.setProperty("--font-inter", v().style.fontFamily), document.documentElement.style.setProperty("--font-suisse", y().style.fontFamily), document.documentElement.style.setProperty("--font-fira-mono", _().style.fontFamily)
                }, []), (0, r.jsx)(i.pn, {
                    children: (0, r.jsx)(m.ZP, {
                        children: (0, r.jsx)(w.Z, {
                            children: (0, r.jsxs)(o.dr, {
                                user: n.user,
                                children: [(0, r.jsxs)(f(), {
                                    children: [(0, r.jsx)("title", {
                                        children: h.pB
                                    }), (0, r.jsx)("meta", {
                                        name: "theme-color",
                                        content: "#000000"
                                    }), (0, r.jsx)("link", {
                                        rel: "icon",
                                        href: "/favicon.svg"
                                    }), (0, r.jsx)("link", {
                                        rel: "mask-icon",
                                        href: "/safari-pinned-tab.svg",
                                        color: "#000000"
                                    }), (0, r.jsx)("link", {
                                        rel: "apple-touch-icon",
                                        sizes: "256x256",
                                        href: "/apple-touch-icon.png"
                                    }), (0, r.jsx)("link", {
                                        rel: "manifest",
                                        href: "/manifest.json"
                                    }), (0, r.jsx)("meta", {
                                        name: "viewport",
                                        content: "width=device-width, initial-scale=1, maximum-scale=5, viewport-fit=cover"
                                    }), !1]
                                }), (0, r.jsx)(p(), {
                                    async: !0,
                                    defer: !0,
                                    "data-domain": "liveblocks.io",
                                    src: "https://plausible.io/js/plausible.js"
                                }), (0, r.jsx)(x._, {}), (0, r.jsx)(S, {}), (0, r.jsx)("div", {
                                    id: "fonts",
                                    className: c()("contents font-product", v().variable, y().variable, _().variable),
                                    children: (0, r.jsx)(E.ZP, {
                                        children: (0, r.jsx)(t, { ...n
                                        })
                                    })
                                }), null]
                            })
                        })
                    })
                })
            }
        },
        4848: function(e, t, n) {
            "use strict";
            n.d(t, {
                Jr: function() {
                    return i
                },
                ZP: function() {
                    return s
                },
                rV: function() {
                    return a
                }
            });
            var r = n(85893),
                o = n(67294);
            let i = "settings",
                u = {
                    theme: "system",
                    isLoading: !0,
                    informationTooltips: {}
                },
                c = (0, o.createContext)(u),
                l = (0, o.createContext)(null);

            function s(e) {
                let {
                    children: t
                } = e, [n, s] = (0, o.useState)(u);
                (0, o.useEffect)(() => {
                    try {
                        let e = localStorage.getItem(i);
                        e ? s({ ...JSON.parse(e),
                            isLoading: !1
                        }) : s({ ...u,
                            isLoading: !1
                        })
                    } catch (e) {
                        s({ ...u,
                            isLoading: !1
                        })
                    }
                }, []), (0, o.useEffect)(() => {
                    try {
                        localStorage.setItem(i, JSON.stringify(n))
                    } catch (e) {}
                }, [n]);
                let a = (0, o.useCallback)(e => {
                    s(t => ({ ...t,
                        ...e
                    }))
                }, []);
                return (0, r.jsx)(c.Provider, {
                    value: n,
                    children: (0, r.jsx)(l.Provider, {
                        value: a,
                        children: t
                    })
                })
            }

            function a() {
                let e = (0, o.useContext)(c),
                    t = (0, o.useContext)(l);
                if (null == e || null == t) throw Error("DashboardContextProvider is missing");
                return [e, t]
            }
        },
        16003: function(e, t, n) {
            "use strict";
            var r, o;

            function i(e, t) {
                return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
                    raw: {
                        value: Object.freeze(t)
                    }
                }))
            }

            function u(e, t) {
                return (function(e, t, n) {
                    let r = new URL(t, e);
                    return void 0 !== n && (r.search = (n instanceof URLSearchParams ? n : function(e) {
                        let t = new URLSearchParams;
                        for (let [n, r] of Object.entries(e)) null != r && t.set(n, r.toString());
                        return t
                    }(n)).toString()), r.toString()
                })(r4, e, t).substring(r4.length)
            }

            function c() {
                let e = i(["/dashboard"]);
                return c = function() {
                    return e
                }, e
            }

            function l() {
                let e = i(["/dashboard/", ""]);
                return l = function() {
                    return e
                }, e
            }

            function s() {
                let e = i(["/dashboard/", "/welcome"]);
                return s = function() {
                    return e
                }, e
            }

            function a() {
                let e = i(["/dashboard/apikeys"]);
                return a = function() {
                    return e
                }, e
            }

            function f() {
                let e = i(["/dashboard/", "/members"]);
                return f = function() {
                    return e
                }, e
            }

            function d() {
                let e = i(["/dashboard/", "/members/invitations"]);
                return d = function() {
                    return e
                }, e
            }

            function p() {
                let e = i(["/dashboard/", "/settings"]);
                return p = function() {
                    return e
                }, e
            }

            function m() {
                let e = i(["/dashboard/", "/settings/billing"]);
                return m = function() {
                    return e
                }, e
            }

            function h() {
                let e = i(["/dashboard/billing"]);
                return h = function() {
                    return e
                }, e
            }

            function E() {
                let e = i(["/dashboard/members"]);
                return E = function() {
                    return e
                }, e
            }

            function g() {
                let e = i(["/dashboard/project"]);
                return g = function() {
                    return e
                }, e
            }

            function v() {
                let e = i(["/dashboard/project/quickstart"]);
                return v = function() {
                    return e
                }, e
            }

            function b() {
                let e = i(["/dashboard/settings"]);
                return b = function() {
                    return e
                }, e
            }

            function y() {
                let e = i(["/dashboard/settings/teams"]);
                return y = function() {
                    return e
                }, e
            }

            function T() {
                let e = i(["/dashboard/", "/projects/", "/quickstart"]);
                return T = function() {
                    return e
                }, e
            }

            function _() {
                let e = i(["/dashboard/", "/projects/", ""]);
                return _ = function() {
                    return e
                }, e
            }

            function w() {
                let e = i(["/dashboard/", "/projects/", "/rooms"]);
                return w = function() {
                    return e
                }, e
            }

            function x() {
                let e = i(["/dashboard/", "/projects/", "/events"]);
                return x = function() {
                    return e
                }, e
            }

            function O() {
                let e = i(["/dashboard/", "/projects/", "/rooms/", ""]);
                return O = function() {
                    return e
                }, e
            }

            function S() {
                let e = i(["/dashboard/", "/projects/", "/webhooks"]);
                return S = function() {
                    return e
                }, e
            }

            function C() {
                let e = i(["/dashboard/", "/projects/", "/webhooks/", ""]);
                return C = function() {
                    return e
                }, e
            }

            function R() {
                let e = i(["/dashboard/", "/projects/", "/apikeys"]);
                return R = function() {
                    return e
                }, e
            }

            function A() {
                let e = i(["/dashboard/", "/projects/", "/settings"]);
                return A = function() {
                    return e
                }, e
            }

            function N() {
                let e = i(["/dashboard/", "/projects/", "/schemas"]);
                return N = function() {
                    return e
                }, e
            }

            function P() {
                let e = i(["/dashboard/", "/projects/", "/schemas/", "/", ""]);
                return P = function() {
                    return e
                }, e
            }

            function I() {
                let e = i(["/dashboard/", "/projects/", "/schemas?new=true"]);
                return I = function() {
                    return e
                }, e
            }

            function L() {
                let e = i(["/invite/", ""]);
                return L = function() {
                    return e
                }, e
            }

            function j() {
                let e = i(["/user/", ""]);
                return j = function() {
                    return e
                }, e
            }

            function k() {
                let e = i(["/integrations/", ""]);
                return k = function() {
                    return e
                }, e
            }

            function D() {
                let e = i(["/integrations/", "/", ""]);
                return D = function() {
                    return e
                }, e
            }

            function M() {
                let e = i(["/integrations/", "/", "/welcome"]);
                return M = function() {
                    return e
                }, e
            }

            function U() {
                let e = i(["/integrations/", "/", "/projects/", ""]);
                return U = function() {
                    return e
                }, e
            }

            function G() {
                let e = i(["/api/integrations/", ""]);
                return G = function() {
                    return e
                }, e
            }

            function F() {
                let e = i(["/"]);
                return F = function() {
                    return e
                }, e
            }

            function H() {
                let e = i(["/examples"]);
                return H = function() {
                    return e
                }, e
            }

            function z() {
                let e = i(["/examples"]);
                return z = function() {
                    return e
                }, e
            }

            function B() {
                let e = i(["/examples/browse/", ""]);
                return B = function() {
                    return e
                }, e
            }

            function V() {
                let e = i(["/examples/", "", ""]);
                return V = function() {
                    return e
                }, e
            }

            function J() {
                let e = i(["/examples/", "/", "/preview"]);
                return J = function() {
                    return e
                }, e
            }

            function Y() {
                let e = i(["/about"]);
                return Y = function() {
                    return e
                }, e
            }

            function W() {
                let e = i(["/pricing"]);
                return W = function() {
                    return e
                }, e
            }

            function K() {
                let e = i(["/blog"]);
                return K = function() {
                    return e
                }, e
            }

            function X() {
                let e = i(["/changelog"]);
                return X = function() {
                    return e
                }, e
            }

            function q() {
                let e = i(["/changelog/", ""]);
                return q = function() {
                    return e
                }, e
            }

            function Z() {
                let e = i(["/contact"]);
                return Z = function() {
                    return e
                }, e
            }

            function $() {
                let e = i(["/contact/sales"]);
                return $ = function() {
                    return e
                }, e
            }

            function Q() {
                let e = i(["/contact/support"]);
                return Q = function() {
                    return e
                }, e
            }

            function ee() {
                let e = i(["/startups"]);
                return ee = function() {
                    return e
                }, e
            }

            function et() {
                let e = i(["/privacy"]);
                return et = function() {
                    return e
                }, e
            }

            function en() {
                let e = i(["/security"]);
                return en = function() {
                    return e
                }, e
            }

            function er() {
                let e = i(["/subprocessors"]);
                return er = function() {
                    return e
                }, e
            }

            function eo() {
                let e = i(["/terms"]);
                return eo = function() {
                    return e
                }, e
            }

            function ei() {
                let e = i(["/monitoring-dashboard"]);
                return ei = function() {
                    return e
                }, e
            }

            function eu() {
                let e = i(["/infrastructure"]);
                return eu = function() {
                    return e
                }, e
            }

            function ec() {
                let e = i(["/devtools"]);
                return ec = function() {
                    return e
                }, e
            }

            function el() {
                let e = i(["/comments"]);
                return el = function() {
                    return e
                }, e
            }

            function es() {
                let e = i(["/notifications"]);
                return es = function() {
                    return e
                }, e
            }

            function ea() {
                let e = i(["/text-editor"]);
                return ea = function() {
                    return e
                }, e
            }

            function ef() {
                let e = i(["/realtime-apis"]);
                return ef = function() {
                    return e
                }, e
            }

            function ed() {
                let e = i(["/realtime-apis/storage"]);
                return ed = function() {
                    return e
                }, e
            }

            function ep() {
                let e = i(["/realtime-apis/yjs"]);
                return ep = function() {
                    return e
                }, e
            }

            function em() {
                let e = i(["/nextjs-starter-kit"]);
                return em = function() {
                    return e
                }, e
            }

            function eh() {
                let e = i(["/customers"]);
                return eh = function() {
                    return e
                }, e
            }

            function eE() {
                let e = i(["/unveil"]);
                return eE = function() {
                    return e
                }, e
            }

            function eg() {
                let e = i(["/nextjs-template-week"]);
                return eg = function() {
                    return e
                }, e
            }

            function ev() {
                let e = i(["/use-cases/collaborative-form"]);
                return ev = function() {
                    return e
                }, e
            }

            function eb() {
                let e = i(["/use-cases/collaborative-text-editor"]);
                return eb = function() {
                    return e
                }, e
            }

            function ey() {
                let e = i(["/use-cases/collaborative-code-editor"]);
                return ey = function() {
                    return e
                }, e
            }

            function eT() {
                let e = i(["/use-cases/collaborative-whiteboard"]);
                return eT = function() {
                    return e
                }, e
            }

            function e_() {
                let e = i(["/use-cases/collaborative-creative-tool"]);
                return e_ = function() {
                    return e
                }, e
            }

            function ew() {
                let e = i(["/use-cases/comments"]);
                return ew = function() {
                    return e
                }, e
            }

            function ex() {
                let e = i(["/use-cases/document-browsing"]);
                return ex = function() {
                    return e
                }, e
            }

            function eO() {
                let e = i(["/use-cases/sharing-and-permissions"]);
                return eO = function() {
                    return e
                }, e
            }

            function eS() {
                let e = i(["/solutions/people-platforms"]);
                return eS = function() {
                    return e
                }, e
            }

            function eC() {
                let e = i(["/solutions/sales-tools"]);
                return eC = function() {
                    return e
                }, e
            }

            function eR() {
                let e = i(["/technology/collaborative-nextjs-application"]);
                return eR = function() {
                    return e
                }, e
            }

            function eA() {
                let e = i(["/technology/collaborative-react-application"]);
                return eA = function() {
                    return e
                }, e
            }

            function eN() {
                let e = i(["/technology/collaborative-javascript-application"]);
                return eN = function() {
                    return e
                }, e
            }

            function eP() {
                let e = i(["/technology/shared-collaborative-redux-state"]);
                return eP = function() {
                    return e
                }, e
            }

            function eI() {
                let e = i(["/technology/shared-collaborative-zustand-state"]);
                return eI = function() {
                    return e
                }, e
            }

            function eL() {
                let e = i(["/technology/hosting-platform-for-yjs"]);
                return eL = function() {
                    return e
                }, e
            }

            function ej() {
                let e = i(["/technology/collaborative-tiptap-editor"]);
                return ej = function() {
                    return e
                }, e
            }

            function ek() {
                let e = i(["/technology/collaborative-slate-editor"]);
                return ek = function() {
                    return e
                }, e
            }

            function eD() {
                let e = i(["/technology/collaborative-lexical-editor"]);
                return eD = function() {
                    return e
                }, e
            }

            function eM() {
                let e = i(["/technology/collaborative-quill-editor"]);
                return eM = function() {
                    return e
                }, e
            }

            function eU() {
                let e = i(["/technology/collaborative-monaco-editor"]);
                return eU = function() {
                    return e
                }, e
            }

            function eG() {
                let e = i(["/technology/collaborative-codemirror-editor"]);
                return eG = function() {
                    return e
                }, e
            }

            function eF() {
                let e = i(["/docs"]);
                return eF = function() {
                    return e
                }, e
            }

            function eH() {
                let e = i(["/docs/tutorial/react/getting-started"]);
                return eH = function() {
                    return e
                }, e
            }

            function ez() {
                let e = i(["/docs/guides"]);
                return ez = function() {
                    return e
                }, e
            }

            function eB() {
                let e = i(["/docs/get-started"]);
                return eB = function() {
                    return e
                }, e
            }

            function eV() {
                let e = i(["/docs/get-started/", ""]);
                return eV = function() {
                    return e
                }, e
            }

            function eJ() {
                let e = i(["/docs/get-started/nextjs"]);
                return eJ = function() {
                    return e
                }, e
            }

            function eY() {
                let e = i(["/docs/get-started/react"]);
                return eY = function() {
                    return e
                }, e
            }

            function eW() {
                let e = i(["/docs/get-started/react-comments"]);
                return eW = function() {
                    return e
                }, e
            }

            function eK() {
                let e = i(["/docs/get-started/nextjs-comments"]);
                return eK = function() {
                    return e
                }, e
            }

            function eX() {
                let e = i(["/docs/get-started/react-notifications"]);
                return eX = function() {
                    return e
                }, e
            }

            function eq() {
                let e = i(["/docs/get-started/nextjs-notifications"]);
                return eq = function() {
                    return e
                }, e
            }

            function eZ() {
                let e = i(["/docs/get-started/react-tiptap"]);
                return eZ = function() {
                    return e
                }, e
            }

            function e$() {
                let e = i(["/docs/get-started/nextjs-tiptap"]);
                return e$ = function() {
                    return e
                }, e
            }

            function eQ() {
                let e = i(["/docs/get-started/react-lexical"]);
                return eQ = function() {
                    return e
                }, e
            }

            function e0() {
                let e = i(["/docs/get-started/nextjs-lexical"]);
                return e0 = function() {
                    return e
                }, e
            }

            function e1() {
                let e = i(["/docs/get-started/redux"]);
                return e1 = function() {
                    return e
                }, e
            }

            function e2() {
                let e = i(["/docs/get-started/zustand"]);
                return e2 = function() {
                    return e
                }, e
            }

            function e7() {
                let e = i(["/docs/get-started/svelte"]);
                return e7 = function() {
                    return e
                }, e
            }

            function e8() {
                let e = i(["/docs/get-started/vuejs"]);
                return e8 = function() {
                    return e
                }, e
            }

            function e5() {
                let e = i(["/docs/get-started/solidjs"]);
                return e5 = function() {
                    return e
                }, e
            }

            function e3() {
                let e = i(["/docs/get-started/javascript"]);
                return e3 = function() {
                    return e
                }, e
            }

            function e9() {
                let e = i(["/docs/get-started/yjs-codemirror-react"]);
                return e9 = function() {
                    return e
                }, e
            }

            function e4() {
                let e = i(["/docs/get-started/yjs-codemirror-svelte"]);
                return e4 = function() {
                    return e
                }, e
            }

            function e6() {
                let e = i(["/docs/get-started/yjs-codemirror-vuejs"]);
                return e6 = function() {
                    return e
                }, e
            }

            function te() {
                let e = i(["/docs/get-started/yjs-codemirror-javascript"]);
                return te = function() {
                    return e
                }, e
            }

            function tt() {
                let e = i(["/docs/get-started/yjs-monaco-react"]);
                return tt = function() {
                    return e
                }, e
            }

            function tn() {
                let e = i(["/docs/get-started/yjs-monaco-svelte"]);
                return tn = function() {
                    return e
                }, e
            }

            function tr() {
                let e = i(["/docs/get-started/yjs-monaco-vuejs"]);
                return tr = function() {
                    return e
                }, e
            }

            function to() {
                let e = i(["/docs/get-started/yjs-monaco-javascript"]);
                return to = function() {
                    return e
                }, e
            }

            function ti() {
                let e = i(["/docs/get-started/yjs-quill-react"]);
                return ti = function() {
                    return e
                }, e
            }

            function tu() {
                let e = i(["/docs/get-started/yjs-quill-svelte"]);
                return tu = function() {
                    return e
                }, e
            }

            function tc() {
                let e = i(["/docs/get-started/yjs-quill-vuejs"]);
                return tc = function() {
                    return e
                }, e
            }

            function tl() {
                let e = i(["/docs/get-started/yjs-quill-javascript"]);
                return tl = function() {
                    return e
                }, e
            }

            function ts() {
                let e = i(["/docs/get-started/yjs-slate-react"]);
                return ts = function() {
                    return e
                }, e
            }

            function ta() {
                let e = i(["/docs/get-started/yjs-tiptap-svelte"]);
                return ta = function() {
                    return e
                }, e
            }

            function tf() {
                let e = i(["/docs/get-started/yjs-tiptap-vuejs"]);
                return tf = function() {
                    return e
                }, e
            }

            function td() {
                let e = i(["/docs/get-started/yjs-tiptap-javascript"]);
                return td = function() {
                    return e
                }, e
            }

            function tp() {
                let e = i(["/docs/get-started/yjs-blocknote-react"]);
                return tp = function() {
                    return e
                }, e
            }

            function tm() {
                let e = i(["/docs/concepts/why-liveblocks"]);
                return tm = function() {
                    return e
                }, e
            }

            function th() {
                let e = i(["/docs/concepts/how-liveblocks-works"]);
                return th = function() {
                    return e
                }, e
            }

            function tE() {
                let e = i(["/docs/products/comments"]);
                return tE = function() {
                    return e
                }, e
            }

            function tg() {
                let e = i(["/docs/products/comments/concepts"]);
                return tg = function() {
                    return e
                }, e
            }

            function tv() {
                let e = i(["/docs/products/comments/users-and-mentions"]);
                return tv = function() {
                    return e
                }, e
            }

            function tb() {
                let e = i(["/docs/products/comments/default-components"]);
                return tb = function() {
                    return e
                }, e
            }

            function ty() {
                let e = i(["/docs/products/comments/hooks"]);
                return ty = function() {
                    return e
                }, e
            }

            function tT() {
                let e = i(["/docs/products/comments/metadata"]);
                return tT = function() {
                    return e
                }, e
            }

            function t_() {
                let e = i(["/docs/products/comments/primitives"]);
                return t_ = function() {
                    return e
                }, e
            }

            function tw() {
                let e = i(["/docs/products/comments/styling-and-customization"]);
                return tw = function() {
                    return e
                }, e
            }

            function tx() {
                let e = i(["/docs/products/comments/email-notifications"]);
                return tx = function() {
                    return e
                }, e
            }

            function tO() {
                let e = i(["/docs/products/notifications"]);
                return tO = function() {
                    return e
                }, e
            }

            function tS() {
                let e = i(["/docs/products/notifications/concepts"]);
                return tS = function() {
                    return e
                }, e
            }

            function tC() {
                let e = i(["/docs/products/notifications/default-components"]);
                return tC = function() {
                    return e
                }, e
            }

            function tR() {
                let e = i(["/docs/products/notifications/hooks"]);
                return tR = function() {
                    return e
                }, e
            }

            function tA() {
                let e = i(["/docs/products/notifications/styling-and-customization"]);
                return tA = function() {
                    return e
                }, e
            }

            function tN() {
                let e = i(["/docs/products/notifications/email-notifications"]);
                return tN = function() {
                    return e
                }, e
            }

            function tP() {
                let e = i(["/docs/products/text-editor"]);
                return tP = function() {
                    return e
                }, e
            }

            function tI() {
                let e = i(["/docs/products/text-editor/lexical"]);
                return tI = function() {
                    return e
                }, e
            }

            function tL() {
                let e = i(["/docs/products/realtime-apis"]);
                return tL = function() {
                    return e
                }, e
            }

            function tj() {
                let e = i(["/docs/products/realtime-apis/liveblocks-storage"]);
                return tj = function() {
                    return e
                }, e
            }

            function tk() {
                let e = i(["/docs/products/realtime-apis/liveblocks-yjs"]);
                return tk = function() {
                    return e
                }, e
            }

            function tD() {
                let e = i(["/docs/authentication"]);
                return tD = function() {
                    return e
                }, e
            }

            function tM() {
                let e = i(["/docs/authentication/", ""]);
                return tM = function() {
                    return e
                }, e
            }

            function tU() {
                let e = i(["/docs/authentication/id-token/nextjs"]);
                return tU = function() {
                    return e
                }, e
            }

            function tG() {
                let e = i(["/docs/authentication/id-token/remix"]);
                return tG = function() {
                    return e
                }, e
            }

            function tF() {
                let e = i(["/docs/authentication/id-token/sveltekit"]);
                return tF = function() {
                    return e
                }, e
            }

            function tH() {
                let e = i(["/docs/authentication/id-token/nuxtjs"]);
                return tH = function() {
                    return e
                }, e
            }

            function tz() {
                let e = i(["/docs/authentication/id-token/firebase"]);
                return tz = function() {
                    return e
                }, e
            }

            function tB() {
                let e = i(["/docs/authentication/id-token/express"]);
                return tB = function() {
                    return e
                }, e
            }

            function tV() {
                let e = i(["/docs/authentication/access-token/nextjs"]);
                return tV = function() {
                    return e
                }, e
            }

            function tJ() {
                let e = i(["/docs/authentication/access-token/remix"]);
                return tJ = function() {
                    return e
                }, e
            }

            function tY() {
                let e = i(["/docs/authentication/access-token/sveltekit"]);
                return tY = function() {
                    return e
                }, e
            }

            function tW() {
                let e = i(["/docs/authentication/access-token/nuxtjs"]);
                return tW = function() {
                    return e
                }, e
            }

            function tK() {
                let e = i(["/docs/authentication/access-token/firebase"]);
                return tK = function() {
                    return e
                }, e
            }

            function tX() {
                let e = i(["/docs/authentication/access-token/express"]);
                return tX = function() {
                    return e
                }, e
            }

            function tq() {
                let e = i(["/docs/rooms/metadata"]);
                return tq = function() {
                    return e
                }, e
            }

            function tZ() {
                let e = i(["/docs/rooms/permissions"]);
                return tZ = function() {
                    return e
                }, e
            }

            function t$() {
                let e = i(["/docs/api-reference/liveblocks-client"]);
                return t$ = function() {
                    return e
                }, e
            }

            function tQ() {
                let e = i(["/docs/api-reference/liveblocks-react"]);
                return tQ = function() {
                    return e
                }, e
            }

            function t0() {
                let e = i(["/docs/api-reference/liveblocks-react-ui"]);
                return t0 = function() {
                    return e
                }, e
            }

            function t1() {
                let e = i(["/docs/api-reference/liveblocks-zustand"]);
                return t1 = function() {
                    return e
                }, e
            }

            function t2() {
                let e = i(["/docs/api-reference/liveblocks-redux"]);
                return t2 = function() {
                    return e
                }, e
            }

            function t7() {
                let e = i(["/docs/api-reference/liveblocks-yjs"]);
                return t7 = function() {
                    return e
                }, e
            }

            function t8() {
                let e = i(["/docs/api-reference/liveblocks-node"]);
                return t8 = function() {
                    return e
                }, e
            }

            function t5() {
                let e = i(["/docs/api-reference/rest-api-endpoints"]);
                return t5 = function() {
                    return e
                }, e
            }

            function t3() {
                let e = i(["/docs/api-reference/rest-api-endpoints-v1"]);
                return t3 = function() {
                    return e
                }, e
            }

            function t9() {
                let e = i(["/docs/platform/nextjs-starter-kit"]);
                return t9 = function() {
                    return e
                }, e
            }

            function t4() {
                let e = i(["/docs/platform/devtools"]);
                return t4 = function() {
                    return e
                }, e
            }

            function t6() {
                let e = i(["/docs/platform/websocket-infrastructure"]);
                return t6 = function() {
                    return e
                }, e
            }

            function ne() {
                let e = i(["/docs/platform/webhooks"]);
                return ne = function() {
                    return e
                }, e
            }

            function nt() {
                let e = i(["/docs/platform/projects"]);
                return nt = function() {
                    return e
                }, e
            }

            function nn() {
                let e = i(["/docs/platform/rest-api"]);
                return nn = function() {
                    return e
                }, e
            }

            function nr() {
                let e = i(["/docs/platform/analytics"]);
                return nr = function() {
                    return e
                }, e
            }

            function no() {
                let e = i(["/docs/platform/account-management"]);
                return no = function() {
                    return e
                }, e
            }

            function ni() {
                let e = i(["/docs/platform/account-management/create-an-account"]);
                return ni = function() {
                    return e
                }, e
            }

            function nu() {
                let e = i(["/docs/platform/account-management/manage-members"]);
                return nu = function() {
                    return e
                }, e
            }

            function nc() {
                let e = i(["/docs/platform/schema-validation"]);
                return nc = function() {
                    return e
                }, e
            }

            function nl() {
                let e = i(["/docs/platform/schema-validation/syntax"]);
                return nl = function() {
                    return e
                }, e
            }

            function ns() {
                let e = i(["/docs/platform/plans"]);
                return ns = function() {
                    return e
                }, e
            }

            function na() {
                let e = i(["/docs/platform/limits"]);
                return na = function() {
                    return e
                }, e
            }

            function nf() {
                let e = i(["/docs/platform/limits/fair-use-policy"]);
                return nf = function() {
                    return e
                }, e
            }

            function nd() {
                let e = i(["/docs/platform/upgrading"]);
                return nd = function() {
                    return e
                }, e
            }

            function np() {
                let e = i(["/docs/platform/upgrading/1.0"]);
                return np = function() {
                    return e
                }, e
            }

            function nm() {
                let e = i(["/docs/platform/upgrading/0.19"]);
                return nm = function() {
                    return e
                }, e
            }

            function nh() {
                let e = i(["/docs/platform/upgrading/0.18"]);
                return nh = function() {
                    return e
                }, e
            }

            function nE() {
                let e = i(["/docs/platform/upgrading/0.17"]);
                return nE = function() {
                    return e
                }, e
            }

            function ng() {
                let e = i(["/docs/tutorial/", ""]);
                return ng = function() {
                    return e
                }, e
            }

            function nv() {
                let e = i(["/docs/tutorial/", "/", ""]);
                return nv = function() {
                    return e
                }, e
            }

            function nb() {
                let e = i(["/docs/tutorial/", "/", "/", ""]);
                return nb = function() {
                    return e
                }, e
            }

            function ny() {
                let e = i(["/api/tutorial/get-liveblocks-api-keys"]);
                return ny = function() {
                    return e
                }, e
            }

            function nT() {
                let e = i(["https://github.com/liveblocks/liveblocks/blob/main/tutorial/", "/", "/", ""]);
                return nT = function() {
                    return e
                }, e
            }

            function n_() {
                let e = i(["/docs/guides"]);
                return n_ = function() {
                    return e
                }, e
            }

            function nw() {
                let e = i(["/docs/guides"]);
                return nw = function() {
                    return e
                }, e
            }

            function nx() {
                let e = i(["/docs/guides/", ""]);
                return nx = function() {
                    return e
                }, e
            }

            function nO() {
                let e = i(["https://forms.gle/xgp54aTMsoH8hrjU9"]);
                return nO = function() {
                    return e
                }, e
            }

            function nS() {
                let e = i(["https://forms.gle/8gDUvNSLvFe9dvs28"]);
                return nS = function() {
                    return e
                }, e
            }

            function nC() {
                let e = i(["/design"]);
                return nC = function() {
                    return e
                }, e
            }

            function nR() {
                let e = i(["/design/global"]);
                return nR = function() {
                    return e
                }, e
            }

            function nA() {
                let e = i(["/design/product"]);
                return nA = function() {
                    return e
                }, e
            }

            function nN() {
                let e = i(["/design/marketing"]);
                return nN = function() {
                    return e
                }, e
            }

            function nP() {
                let e = i(["/api/auth/login"]);
                return nP = function() {
                    return e
                }, e
            }

            function nI() {
                let e = i(["/api/auth/logout"]);
                return nI = function() {
                    return e
                }, e
            }

            function nL() {
                let e = i(["/signup"]);
                return nL = function() {
                    return e
                }, e
            }

            function nj() {
                let e = i(["/api/contact-sales"]);
                return nj = function() {
                    return e
                }, e
            }

            function nk() {
                let e = i(["/api/contact-sales-startups"]);
                return nk = function() {
                    return e
                }, e
            }

            function nD() {
                let e = i(["/api/contact-support"]);
                return nD = function() {
                    return e
                }, e
            }

            function nM() {
                let e = i(["/api/location"]);
                return nM = function() {
                    return e
                }, e
            }

            function nU() {
                let e = i(["/api/docs-feedback"]);
                return nU = function() {
                    return e
                }, e
            }

            function nG() {
                let e = i(["/api/accounts/summary"]);
                return nG = function() {
                    return e
                }, e
            }

            function nF() {
                let e = i(["/api/accounts/", "/invite"]);
                return nF = function() {
                    return e
                }, e
            }

            function nH() {
                let e = i(["/api/accounts/", "/leave"]);
                return nH = function() {
                    return e
                }, e
            }

            function nz() {
                let e = i(["/api/accounts/", "/role"]);
                return nz = function() {
                    return e
                }, e
            }

            function nB() {
                let e = i(["/api/accounts/", "/members"]);
                return nB = function() {
                    return e
                }, e
            }

            function nV() {
                let e = i(["/api/accounts/", "/members/", ""]);
                return nV = function() {
                    return e
                }, e
            }

            function nJ() {
                let e = i(["/api/accounts/", "/members/", ""]);
                return nJ = function() {
                    return e
                }, e
            }

            function nY() {
                let e = i(["/api/me/info"]);
                return nY = function() {
                    return e
                }, e
            }

            function nW() {
                let e = i(["/api/me/onboarding"]);
                return nW = function() {
                    return e
                }, e
            }

            function nK() {
                let e = i(["/api/accounts/", "/invitations"]);
                return nK = function() {
                    return e
                }, e
            }

            function nX() {
                let e = i(["/api/accounts/", "/invitations/", ""]);
                return nX = function() {
                    return e
                }, e
            }

            function nq() {
                let e = i(["/api/accounts/", "/projects"]);
                return nq = function() {
                    return e
                }, e
            }

            function nZ() {
                let e = i(["/api/accounts/", "/projects"]);
                return nZ = function() {
                    return e
                }, e
            }

            function n$() {
                let e = i(["/api/accounts/", "/projects/", "/activity-info"]);
                return n$ = function() {
                    return e
                }, e
            }

            function nQ() {
                let e = i(["/api/accounts/", "/rename"]);
                return nQ = function() {
                    return e
                }, e
            }

            function n0() {
                let e = i(["/api/accounts"]);
                return n0 = function() {
                    return e
                }, e
            }

            function n1() {
                let e = i(["/api/accounts/", "/upload-logo"]);
                return n1 = function() {
                    return e
                }, e
            }

            function n2() {
                let e = i(["/api/accounts/", "/delete"]);
                return n2 = function() {
                    return e
                }, e
            }

            function n7() {
                let e = i(["/api/users/", "/delete"]);
                return n7 = function() {
                    return e
                }, e
            }

            function n8() {
                let e = i(["/api/accounts/", "/update-onboarding-status"]);
                return n8 = function() {
                    return e
                }, e
            }

            function n5() {
                let e = i(["/api/accounts/", "/plan-info"]);
                return n5 = function() {
                    return e
                }, e
            }

            function n3() {
                let e = i(["/api/accounts/", "/plan-usage-alert"]);
                return n3 = function() {
                    return e
                }, e
            }

            function n9() {
                let e = i(["/api/accounts/", "/features"]);
                return n9 = function() {
                    return e
                }, e
            }

            function n4() {
                let e = i(["/api/accounts/", "/portal-session"]);
                return n4 = function() {
                    return e
                }, e
            }

            function n6() {
                let e = i(["/api/me/unsubscribe-newsletter"]);
                return n6 = function() {
                    return e
                }, e
            }

            function re() {
                let e = i(["/api/me/subscribe-newsletter"]);
                return re = function() {
                    return e
                }, e
            }

            function rt() {
                let e = i(["/api/projects/", "/public-api-key/activate"]);
                return rt = function() {
                    return e
                }, e
            }

            function rn() {
                let e = i(["/api/projects/", "/public-api-key/deactivate"]);
                return rn = function() {
                    return e
                }, e
            }

            function rr() {
                let e = i(["/api/projects/", "/public/regenerate-key"]);
                return rr = function() {
                    return e
                }, e
            }

            function ro() {
                let e = i(["/api/projects/", "/secret/regenerate-key"]);
                return ro = function() {
                    return e
                }, e
            }

            function ri() {
                let e = i(["/api/projects/", ""]);
                return ri = function() {
                    return e
                }, e
            }

            function ru() {
                let e = i(["/api/accounts/", "/projects/", "/events"]);
                return ru = function() {
                    return e
                }, e
            }

            function rc() {
                let e = i(["/api/projects"]);
                return rc = function() {
                    return e
                }, e
            }

            function rl() {
                let e = i(["/api/accounts/", "/projects/", "/webhook-portal"]);
                return rl = function() {
                    return e
                }, e
            }

            function rs() {
                let e = i(["/api/accounts/", "/projects/", "/webhooks/threadEmailNotification"]);
                return rs = function() {
                    return e
                }, e
            }

            function ra() {
                let e = i(["/api/projects/", "/statistics"]);
                return ra = function() {
                    return e
                }, e
            }

            function rf() {
                let e = i(["/api/accounts/", "/projects/", ""]);
                return rf = function() {
                    return e
                }, e
            }

            function rd() {
                let e = i(["/api/accounts/", "/projects/", "/rooms"]);
                return rd = function() {
                    return e
                }, e
            }

            function rp() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", ""]);
                return rp = function() {
                    return e
                }, e
            }

            function rm() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/info"]);
                return rm = function() {
                    return e
                }, e
            }

            function rh() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", ""]);
                return rh = function() {
                    return e
                }, e
            }

            function rE() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/broadcast-event"]);
                return rE = function() {
                    return e
                }, e
            }

            function rg() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/online-users"]);
                return rg = function() {
                    return e
                }, e
            }

            function rv() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/storage"]);
                return rv = function() {
                    return e
                }, e
            }

            function rb() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/storage?format=json"]);
                return rb = function() {
                    return e
                }, e
            }

            function ry() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/ydoc"]);
                return ry = function() {
                    return e
                }, e
            }

            function rT() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/ydoc-binary"]);
                return rT = function() {
                    return e
                }, e
            }

            function r_() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/ydoc-binary?guid=", ""]);
                return r_ = function() {
                    return e
                }, e
            }

            function rw() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/text-editor"]);
                return rw = function() {
                    return e
                }, e
            }

            function rx() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/storage"]);
                return rx = function() {
                    return e
                }, e
            }

            function rO() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/threads"]);
                return rO = function() {
                    return e
                }, e
            }

            function rS() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/threads"]);
                return rS = function() {
                    return e
                }, e
            }

            function rC() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/threads/", ""]);
                return rC = function() {
                    return e
                }, e
            }

            function rR() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/threads/", "/comments/", ""]);
                return rR = function() {
                    return e
                }, e
            }

            function rA() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/attachments/presigned-urls"]);
                return rA = function() {
                    return e
                }, e
            }

            function rN() {
                let e = i(["/api/accounts/", "/projects/", "/schemas"]);
                return rN = function() {
                    return e
                }, e
            }

            function rP() {
                let e = i(["/api/accounts/", "/projects/", "/schemas/", "/", ""]);
                return rP = function() {
                    return e
                }, e
            }

            function rI() {
                let e = i(["/api/accounts/", "/projects/", "/schemas"]);
                return rI = function() {
                    return e
                }, e
            }

            function rL() {
                let e = i(["/api/accounts/", "/projects/", "/schemas/", "/", ""]);
                return rL = function() {
                    return e
                }, e
            }

            function rj() {
                let e = i(["/api/accounts/", "/projects/", "/schemas/", "/", ""]);
                return rj = function() {
                    return e
                }, e
            }

            function rk() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/schema/check"]);
                return rk = function() {
                    return e
                }, e
            }

            function rD() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/schema/attach"]);
                return rD = function() {
                    return e
                }, e
            }

            function rM() {
                let e = i(["/api/accounts/", "/projects/", "/rooms/", "/schema/detach"]);
                return rM = function() {
                    return e
                }, e
            }

            function rU() {
                let e = i(["/api/dashboard/load-quickstart-guide?filePath=", ""]);
                return rU = function() {
                    return e
                }, e
            }

            function rG() {
                let e = i(["/api/docs-og"]);
                return rG = function() {
                    return e
                }, e
            }

            function rF() {
                let e = i(["/api/changelog-og"]);
                return rF = function() {
                    return e
                }, e
            }

            function rH() {
                let e = i(["https://github.com/", "/", "/blob/main/", ""]);
                return rH = function() {
                    return e
                }, e
            }

            function rz() {
                let e = i(["https://codesandbox.io/s/github/", "/", "/tree/main/", ""]);
                return rz = function() {
                    return e
                }, e
            }

            function rB() {
                let e = i(["https://vercel.com/new/clone?", ""]);
                return rB = function() {
                    return e
                }, e
            }

            function rV() {
                let e = i(["https://join.team/liveblocks"]);
                return rV = function() {
                    return e
                }, e
            }

            function rJ() {
                let e = i(["https://liveblocks.statuspage.io"]);
                return rJ = function() {
                    return e
                }, e
            }

            function rY() {
                let e = i(["https://lp2l6qrhxz2b.statuspage.io/api/v2/status.json"]);
                return rY = function() {
                    return e
                }, e
            }

            function rW() {
                let e = i(["https://liveblocks.notion.site/Liveblocks-Press-Kit-ca633fafac3646979b932b8dd4fcdebb"]);
                return rW = function() {
                    return e
                }, e
            }

            function rK() {
                let e = i(["https://github.com/", "/", "/releases"]);
                return rK = function() {
                    return e
                }, e
            }

            function rX() {
                let e = i(["https://x.com/liveblocks"]);
                return rX = function() {
                    return e
                }, e
            }

            function rq() {
                let e = i(["https://github.com/", ""]);
                return rq = function() {
                    return e
                }, e
            }

            function rZ() {
                let e = i(["https://github.com/", "/", ""]);
                return rZ = function() {
                    return e
                }, e
            }

            function r$() {
                let e = i(["https://www.linkedin.com/company/liveblocks"]);
                return r$ = function() {
                    return e
                }, e
            }

            function rQ() {
                let e = i(["/discord"]);
                return rQ = function() {
                    return e
                }, e
            }

            function r0() {
                let e = i(["https://www.youtube.com/channel/UCDXT5skWxzOorIQrWG5OT2w"]);
                return r0 = function() {
                    return e
                }, e
            }

            function r1() {
                let e = i(["https://x.com/@", ""]);
                return r1 = function() {
                    return e
                }, e
            }

            function r2() {
                let e = i(["https://github.com/", ".png?size=", ""]);
                return r2 = function() {
                    return e
                }, e
            }
            n.d(t, {
                qf: function() {
                    return op
                },
                QY: function() {
                    return oc
                },
                j$: function() {
                    return oS
                },
                CT: function() {
                    return ov
                },
                r3: function() {
                    return oE
                },
                lX: function() {
                    return on
                },
                pB: function() {
                    return r7
                },
                d: function() {
                    return od
                },
                v_: function() {
                    return os
                },
                R4: function() {
                    return r4
                },
                sH: function() {
                    return r9
                },
                AR: function() {
                    return r5
                },
                g2: function() {
                    return r3
                },
                IT: function() {
                    return oA
                },
                A8: function() {
                    return oC
                },
                K4: function() {
                    return oR
                },
                _q: function() {
                    return ot
                },
                ju: function() {
                    return or
                },
                NY: function() {
                    return r6
                },
                xl: function() {
                    return oh
                },
                de: function() {
                    return oe
                },
                fr: function() {
                    return oO
                },
                u1: function() {
                    return of
                },
                BZ: function() {
                    return r
                },
                Dh: function() {
                    return r8
                },
                Bn: function() {
                    return om
                },
                WQ: function() {
                    return oT
                },
                Wf: function() {
                    return oN
                },
                Bc: function() {
                    return o_
                },
                mK: function() {
                    return ow
                },
                PR: function() {
                    return ob
                },
                es: function() {
                    return oy
                },
                zO: function() {
                    return oP
                },
                FC: function() {
                    return oa
                },
                Cx: function() {
                    return ox
                },
                BK: function() {
                    return og
                },
                qk: function() {
                    return ol
                }
            });
            let r7 = "Liveblocks",
                r8 = "Liveblocks Inc.",
                r5 = "sales@liveblocks.io",
                r3 = "support@liveblocks.io",
                r9 = "feedback@liveblocks.io",
                r4 = "https://liveblocks.io",
                r6 = "liveblocks",
                oe = "liveblocks",
                ot = "/api/github/repository",
                on = {
                    street: "251 Little Falls Drive",
                    locality: "Wilmington",
                    region: "Delaware",
                    zipCode: "19808",
                    country: "United States of America"
                },
                or = "https://api.github.com";

            function oo(e) {
                for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                return e.reduce((e, t, r) => {
                    var o;
                    let i = null !== (o = n[r - 1]) && void 0 !== o ? o : "";
                    return e + (i instanceof oi ? i.toString() : encodeURIComponent(i)) + t
                })
            }
            class oi {
                toString() {
                    return this.value
                }
                constructor(e) {
                    this.value = e
                }
            }

            function ou(e, t) {
                return e.includes("@") ? e.split("@") : [e, null != t ? t : 1]
            }
            oo.safe = e => new oi(e);
            let oc = {
                    HOME: oo(c()),
                    ACCOUNT: e => oo(l(), e),
                    ACCOUNT_ONBOARDING: e => oo(s(), e),
                    API_KEYS: oo(a()),
                    MEMBERS: e => oo(f(), e),
                    INVITATIONS: e => oo(d(), e),
                    SETTINGS: e => oo(p(), e),
                    BILLING: e => oo(m(), e),
                    DEFAULT_BILLING: oo(h()),
                    DEFAULT_MEMBERS: oo(E()),
                    DEFAULT_PROJECT: oo(g()),
                    DEFAULT_PROJECT_QUICKSTART: oo(v()),
                    ACCOUNT_SETTINGS: oo(b()),
                    ACCOUNT_SETTINGS_TEAMS: oo(y()),
                    PROJECT_QUICKSTART: (e, t) => oo(T(), e, t),
                    PROJECT: (e, t) => oo(_(), e, t),
                    PROJECT_ROOMS: (e, t) => oo(w(), e, t),
                    PROJECT_EVENTS: (e, t) => oo(x(), e, t),
                    PROJECT_ROOM: (e, t, n) => oo(O(), e, t, n),
                    PROJECT_WEBHOOKS: (e, t) => oo(S(), e, t),
                    PROJECT_WEBHOOKS_ENDPOINT: (e, t, n) => oo(C(), e, t, n),
                    PROJECT_API_KEYS: (e, t) => oo(R(), e, t),
                    PROJECT_SETTINGS: (e, t) => oo(A(), e, t),
                    SCHEMAS: (e, t) => oo(N(), e, t),
                    SCHEMA: (e, t, n, r) => {
                        let [o, i] = ou(n, r);
                        return oo(P(), e, t, o, String(i))
                    },
                    NEW_SCHEMA: (e, t) => oo(I(), e, t),
                    INVITE: e => oo(L(), e),
                    USER_DELETION_TICKET: e => oo(j(), e),
                    INTEGRATION: e => oo(k(), e),
                    INTEGRATION_ACCOUNT: (e, t) => oo(D(), e, t),
                    INTEGRATION_ACCOUNT_ONBOARDING: function(e, t) {
                        let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
                        return oo(M(), e, t) + n
                    },
                    INTEGRATION_ACCOUNT_PROJECT: function(e, t, n) {
                        let r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
                        return oo(U(), e, t, n) + r
                    },
                    INTEGRATION_API: e => oo(G(), e)
                },
                ol = {
                    HOME: oo(F()),
                    EXAMPLES: oo(H()),
                    EXAMPLES_CATEGORY: e => "all" === e ? oo(z()) : oo(B(), oo.safe(e)),
                    EXAMPLE_PAGE: (e, t) => oo(V(), oo.safe(e), oo.safe(t ? "/" + t : "")),
                    EXAMPLE_PREVIEW_PAGE: (e, t) => oo(J(), oo.safe(e), oo.safe(t)),
                    ABOUT: oo(Y()),
                    PRICING: oo(W()),
                    BLOG: oo(K()),
                    CHANGELOG: oo(X()),
                    CHANGELOG_ENTRY: e => oo(q(), e),
                    CONTACT: oo(Z()),
                    CONTACT_SALES: oo($()),
                    CONTACT_SUPPORT: oo(Q()),
                    STARTUPS: oo(ee()),
                    PRIVACY: oo(et()),
                    SECURITY: oo(en()),
                    SUBPROCESSORS: oo(er()),
                    TERMS: oo(eo()),
                    MONITORING_DASHBOARD: oo(ei()),
                    INFRASTRUCTURE: oo(eu()),
                    DEVTOOLS: oo(ec()),
                    COMMENTS: oo(el()),
                    NOTIFICATIONS: oo(es()),
                    TEXT_EDITOR: oo(ea()),
                    REALTIME_APIS: oo(ef()),
                    REALTIME_APIS_STORAGE: oo(ed()),
                    REALTIME_APIS_YJS: oo(ep()),
                    NEXTJS_STARTER_KIT: oo(em()),
                    CUSTOMERS: oo(eh()),
                    UNVEIL: oo(eE()),
                    NEXTJS_TEMPLATE_WEEK: oo(eg()),
                    USE_CASE_FORM: oo(ev()),
                    USE_CASE_TEXT_EDITOR: oo(eb()),
                    USE_CASE_CODE_EDITOR: oo(ey()),
                    USE_CASE_WHITEBOARD: oo(eT()),
                    USE_CASE_CREATIVE_TOOL: oo(e_()),
                    USE_CASE_COMMENTS: oo(ew()),
                    USE_CASE_DOCUMENT_BROWSING: oo(ex()),
                    USE_CASE_SHARING_AND_PERMISSIONS: oo(eO()),
                    SOLUTION_PEOPLE_PLATFORMS: oo(eS()),
                    SOLUTION_SALES_TOOLS: oo(eC()),
                    TECHNOLOGY_NEXTJS: oo(eR()),
                    TECHNOLOGY_REACT: oo(eA()),
                    TECHNOLOGY_JAVASCRIPT: oo(eN()),
                    TECHNOLOGY_REDUX: oo(eP()),
                    TECHNOLOGY_ZUSTAND: oo(eI()),
                    TECHNOLOGY_YJS: oo(eL()),
                    TECHNOLOGY_TIPTAP: oo(ej()),
                    TECHNOLOGY_SLATE: oo(ek()),
                    TECHNOLOGY_LEXICAL: oo(eD()),
                    TECHNOLOGY_QUILL: oo(eM()),
                    TECHNOLOGY_MONACO: oo(eU()),
                    TECHNOLOGY_CODEMIRROR: oo(eG())
                },
                os = {
                    HOME: oo(eF()),
                    TUTORIALS: oo(eH()),
                    GUIDES: oo(ez()),
                    GET_STARTED: oo(eB()),
                    GET_STARTED_USE_CASES: e => oo(eV(), oo.safe(e)),
                    GET_STARTED_NEXTJS: oo(eJ()),
                    GET_STARTED_REACT: oo(eY()),
                    GET_STARTED_REACT_COMMENTS: oo(eW()),
                    GET_STARTED_NEXTJS_COMMENTS: oo(eK()),
                    GET_STARTED_REACT_NOTIFICATIONS: oo(eX()),
                    GET_STARTED_NEXTJS_NOTIFICATIONS: oo(eq()),
                    GET_STARTED_REACT_TIPTAP: oo(eZ()),
                    GET_STARTED_NEXTJS_TIPTAP: oo(e$()),
                    GET_STARTED_REACT_LEXICAL: oo(eQ()),
                    GET_STARTED_NEXTJS_LEXICAL: oo(e0()),
                    GET_STARTED_REDUX: oo(e1()),
                    GET_STARTED_ZUSTAND: oo(e2()),
                    GET_STARTED_SVELTE: oo(e7()),
                    GET_STARTED_VUEJS: oo(e8()),
                    GET_STARTED_SOLIDJS: oo(e5()),
                    GET_STARTED_JAVASCRIPT: oo(e3()),
                    GET_STARTED_YJS_CODEMIRROR_REACT: oo(e9()),
                    GET_STARTED_YJS_CODEMIRROR_SVELTE: oo(e4()),
                    GET_STARTED_YJS_CODEMIRROR_VUEJS: oo(e6()),
                    GET_STARTED_YJS_CODEMIRROR_JAVASCRIPT: oo(te()),
                    GET_STARTED_YJS_MONACO_REACT: oo(tt()),
                    GET_STARTED_YJS_MONACO_SVELTE: oo(tn()),
                    GET_STARTED_YJS_MONACO_VUEJS: oo(tr()),
                    GET_STARTED_YJS_MONACO_JAVASCRIPT: oo(to()),
                    GET_STARTED_YJS_QUILL_REACT: oo(ti()),
                    GET_STARTED_YJS_QUILL_SVELTE: oo(tu()),
                    GET_STARTED_YJS_QUILL_VUEJS: oo(tc()),
                    GET_STARTED_YJS_QUILL_JAVASCRIPT: oo(tl()),
                    GET_STARTED_YJS_SLATE_REACT: oo(ts()),
                    GET_STARTED_YJS_TIPTAP_SVELTE: oo(ta()),
                    GET_STARTED_YJS_TIPTAP_VUEJS: oo(tf()),
                    GET_STARTED_YJS_TIPTAP_JAVASCRIPT: oo(td()),
                    GET_STARTED_YJS_BLOCKNOTE_REACT: oo(tp()),
                    CONCEPTS_WHY_LIVEBLOCKS: oo(tm()),
                    CONCEPTS_HOW_LIVEBLOCKS_WORKS: oo(th()),
                    PRODUCTS_COMMENTS: oo(tE()),
                    PRODUCTS_COMMENTS_CONCEPTS: oo(tg()),
                    PRODUCTS_COMMENTS_USERS_AND_MENTIONS: oo(tv()),
                    PRODUCTS_COMMENTS_DEFAULT_COMPONENTS: oo(tb()),
                    PRODUCTS_COMMENTS_HOOKS: oo(ty()),
                    PRODUCTS_COMMENTS_METADATA: oo(tT()),
                    PRODUCTS_COMMENTS_PRIMITIVES: oo(t_()),
                    PRODUCTS_COMMENTS_STYLING_AND_CUSTOMIZATION: oo(tw()),
                    PRODUCTS_COMMENTS_EMAIL_NOTIFICATIONS: oo(tx()),
                    PRODUCTS_NOTIFICATIONS: oo(tO()),
                    PRODUCTS_NOTIFICATIONS_CONCEPTS: oo(tS()),
                    PRODUCTS_NOTIFICATIONS_DEFAULT_COMPONENTS: oo(tC()),
                    PRODUCTS_NOTIFICATIONS_HOOKS: oo(tR()),
                    PRODUCTS_NOTIFICATIONS_STYLING_AND_CUSTOMIZATION: oo(tA()),
                    PRODUCTS_NOTIFICATIONS_EMAIL_NOTIFICATIONS: oo(tN()),
                    PRODUCTS_TEXT_EDITOR: oo(tP()),
                    PRODUCTS_TEXT_EDITOR_LEXICAL: oo(tI()),
                    PRODUCTS_REALTIME_APIS: oo(tL()),
                    PRODUCTS_REALTIME_APIS_STORAGE: oo(tj()),
                    PRODUCTS_REALTIME_APIS_YJS: oo(tk()),
                    AUTHENTICATION: oo(tD()),
                    AUTHENTICATION_TYPES: e => oo(tM(), oo.safe(e)),
                    AUTHENTICATION_ID_TOKEN_NEXTJS: oo(tU()),
                    AUTHENTICATION_ID_TOKEN_REMIX: oo(tG()),
                    AUTHENTICATION_ID_TOKEN_SVELTEKIT: oo(tF()),
                    AUTHENTICATION_ID_TOKEN_NUXTJS: oo(tH()),
                    AUTHENTICATION_ID_TOKEN_FIREBASE: oo(tz()),
                    AUTHENTICATION_ID_TOKEN_EXPRESS: oo(tB()),
                    AUTHENTICATION_ACCESS_TOKEN_NEXTJS: oo(tV()),
                    AUTHENTICATION_ACCESS_TOKEN_REMIX: oo(tJ()),
                    AUTHENTICATION_ACCESS_TOKEN_SVELTEKIT: oo(tY()),
                    AUTHENTICATION_ACCESS_TOKEN_NUXTJS: oo(tW()),
                    AUTHENTICATION_ACCESS_TOKEN_FIREBASE: oo(tK()),
                    AUTHENTICATION_ACCESS_TOKEN_EXPRESS: oo(tX()),
                    METADATA: oo(tq()),
                    PERMISSIONS: oo(tZ()),
                    API_REFERENCE_CLIENT: oo(t$()),
                    API_REFERENCE_REACT: oo(tQ()),
                    API_REFERENCE_REACT_UI: oo(t0()),
                    API_REFERENCE_ZUSTAND: oo(t1()),
                    API_REFERENCE_REDUX: oo(t2()),
                    API_REFERENCE_YJS: oo(t7()),
                    API_REFERENCE_NODE: oo(t8()),
                    API_REFERENCE_REST: oo(t5()),
                    API_REFERENCE_REST_V1: oo(t3()),
                    TOOLS_NEXTJS_STARTER_KIT: oo(t9()),
                    TOOLS_DEVTOOLS: oo(t4()),
                    PLATFORM_WEBSOCKET_INFRASTRUCTURE: oo(t6()),
                    PLATFORM_WEBHOOKS: oo(ne()),
                    PLATFORM_PROJECTS: oo(nt()),
                    PLATFORM_REST_API: oo(nn()),
                    PLATFORM_ANALYTICS: oo(nr()),
                    PLATFORM_ACCOUNT_MANAGEMENT: oo(no()),
                    PLATFORM_ACCOUNT_MANAGEMENT_CREATE_ACCOUNT: oo(ni()),
                    PLATFORM_ACCOUNT_MANAGEMENT_MANAGE_TEAM_MEMBERS: oo(nu()),
                    PLATFORM_SCHEMA_VALIDATION: oo(nc()),
                    PLATFORM_SCHEMA_VALIDATION_SYNTAX: oo(nl()),
                    PLATFORM_PLANS: oo(ns()),
                    PLATFORM_LIMITS: oo(na()),
                    PLATFORM_LIMITS_FAIR_USE_POLICY: oo(nf()),
                    PLATFORM_UPGRADING: oo(nd()),
                    PLATFORM_UPGRADING_1: oo(np()),
                    PLATFORM_UPGRADING_019: oo(nm()),
                    PLATFORM_UPGRADING_018: oo(nh()),
                    PLATFORM_UPGRADING_017: oo(nE())
                },
                oa = {
                    TUTORIAL_TECHNOLOGY: e => oo(ng(), oo.safe(e)),
                    TUTORIAL_GUIDE: (e, t) => oo(nv(), oo.safe(e), oo.safe(t)),
                    TUTORIAL_PAGE: (e, t, n) => oo(nb(), oo.safe(e), oo.safe(t), oo.safe(n)),
                    GET_LIVEBLOCKS_KEYS_API: oo(ny()),
                    EDIT_ON_GITHUB_PAGE: (e, t, n) => oo(nT(), oo.safe(e), oo.safe(t), oo.safe(n))
                },
                of = {
                    GUIDES_BY_TECHNOLOGY: e => u(oo(n_()), {
                        technologies: e
                    }),
                    GUIDES_BY_TOPIC: e => u(oo(nw()), {
                        topics: e
                    }),
                    GUIDE_PAGE: e => oo(nx(), oo.safe(e))
                };
            oo(nO()), oo(nS());
            let od = {
                    HOME: oo(nC()),
                    GLOBAL: oo(nR()),
                    PRODUCT: oo(nA()),
                    MARKETING: oo(nN())
                },
                op = {
                    LOG_IN: oo(nP()),
                    LOG_OUT: oo(nI()),
                    SIGN_UP: oo(nL()),
                    CONTACT_SALES: oo(nj()),
                    CONTACT_SALES_STARTUPS: oo(nk()),
                    CONTACT_SUPPORT: oo(nD()),
                    EDGE_LOCATION: oo(nM()),
                    DOCS_FEEDBACK: oo(nU()),
                    ACCOUNTS_SUMMARY: oo(nG()),
                    INVITE: (e, t, n) => new Request(oo(nF(), e), {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            email: t,
                            role: n
                        })
                    }),
                    LEAVE: e => new Request(oo(nH(), e), {
                        headers: {
                            "Content-Type": "application/json"
                        },
                        method: "POST"
                    }),
                    ACCOUNT_ROLE: e => oo(nz(), e),
                    GET_MEMBERS: e => oo(nB(), e),
                    DELETE_MEMBER: (e, t) => new Request(oo(nV(), e, t), {
                        method: "DELETE"
                    }),
                    UPDATE_MEMBER: (e, t, n) => new Request(oo(nJ(), e, t), {
                        method: "PATCH",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            role: n
                        })
                    }),
                    ME_INFO: oo(nY()),
                    ME_ONBOARDING: e => new Request(oo(nW()), {
                        headers: {
                            "Content-Type": "application/json"
                        },
                        method: "POST",
                        body: JSON.stringify({
                            isDeveloper: e.isDeveloper,
                            referralSource: e.referralSource,
                            subscribeToNewsletter: e.subscribeToNewsletter
                        })
                    }),
                    GET_INVITATIONS: e => oo(nK(), e),
                    DELETE_INVITE: (e, t) => new Request(oo(nX(), e, t), {
                        method: "DELETE"
                    }),
                    GET_PROJECTS: e => oo(nq(), e),
                    CREATE_PROJECT: (e, t) => new Request(oo(nZ(), e), {
                        headers: {
                            "Content-Type": "application/json"
                        },
                        method: "POST",
                        body: JSON.stringify({
                            displayName: t.displayName,
                            type: t.type
                        })
                    }),
                    GET_PROJECT_ACTIVITY: (e, t) => oo(n$(), e, t),
                    RENAME_ACCOUNT: e => oo(nQ(), e),
                    CREATE_ACCOUNT: e => new Request(oo(n0()), {
                        headers: {
                            "Content-Type": "application/json"
                        },
                        method: "POST",
                        body: JSON.stringify({
                            name: e.name
                        })
                    }),
                    UPLOAD_ACCOUNT_LOGO: e => oo(n1(), e),
                    DELETE_ACCOUNT: e => oo(n2(), e),
                    DELETE_USER: e => oo(n7(), e),
                    UPDATE_ONBOARDING_STATUS: e => oo(n8(), e),
                    PLAN_INFO: e => oo(n5(), e),
                    PLAN_USAGE_ALERT: e => oo(n3(), e),
                    FEATURES: e => oo(n9(), e),
                    CHECKOUT_SESSION: e => "/api/accounts/".concat(e, "/checkout-session"),
                    ADD_PRODUCT_TO_SUBSCRIPTION: e => "/api/accounts/".concat(e, "/add-product-to-subscription"),
                    PORTAL_SESSION: e => oo(n4(), e),
                    UNSUBSCRIBE_NEWSLETTER: oo(n6()),
                    SUBSCRIBE_NEWSLETTER: oo(re()),
                    ACTIVATE_PUBLIC_KEY: e => oo(rt(), e),
                    DEACTIVATE_PUBLIC_KEY: e => oo(rn(), e),
                    REGENERATE_PUBLIC_KEY: e => oo(rr(), e),
                    REGENERATE_SECRET_KEY: e => oo(ro(), e),
                    PROJECT: e => oo(ri(), e),
                    GET_PROJECT_EVENTS: (e, t) => oo(ru(), e, t),
                    PROJECTS: oo(rc()),
                    GET_WEBHOOK_PORTAL: (e, t) => oo(rl(), e, t),
                    POST_WEBHOOK_ENDPOINT_EXAMPLE: (e, t, n) => new Request("/api/accounts/".concat(e, "/projects/").concat(t, "/webhook-example"), {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(n)
                    }),
                    WEBHOOKS_THREAD_EMAIL_NOTIFICATION_SETTINGS: (e, t) => oo(rs(), e, t),
                    PROJECT_STATS: (e, t, n, r) => u(oo(ra(), e), {
                        startTime: t,
                        endTime: n,
                        unit: r
                    }),
                    DELETE_PROJECT: (e, t) => new Request(oo(rf(), e, t), {
                        method: "DELETE"
                    }),
                    GET_ROOMS: (e, t) => oo(rd(), e, t),
                    GET_ROOM: (e, t, n) => oo(rp(), e, t, n),
                    GET_ROOM_INFO: (e, t, n) => oo(rm(), e, t, n),
                    DELETE_ROOM: (e, t, n) => new Request(oo(rh(), e, t, n), {
                        method: "DELETE"
                    }),
                    BROADCAST_ROOM_EVENT: (e, t, n, r) => new Request(oo(rE(), e, t, n), {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            event: r
                        })
                    }),
                    GET_ROOM_ONLINE_USERS: (e, t, n) => oo(rg(), e, t, n),
                    GET_ROOM_STORAGE_AS_PLAIN_LSON: (e, t, n) => oo(rv(), e, t, n),
                    GET_ROOM_STORAGE_AS_JSON: (e, t, n) => oo(rb(), e, t, n),
                    GET_ROOM_YDOC: (e, t, n) => oo(ry(), e, t, n),
                    GET_ROOM_YDOC_BINARY: (e, t, n) => oo(rT(), e, t, n),
                    GET_ROOM_YSUBDOC_BINARY: (e, t, n, r) => oo(r_(), e, t, n, r),
                    GET_ROOM_TEXT_EDITOR: (e, t, n) => oo(rw(), e, t, n),
                    DELETE_ROOM_STORAGE: (e, t, n) => new Request(oo(rx(), e, t, n), {
                        method: "DELETE"
                    }),
                    GET_ROOM_THREADS: (e, t, n) => oo(rO(), e, t, n),
                    DELETE_ROOM_THREADS: (e, t, n) => new Request(oo(rS(), e, t, n), {
                        method: "DELETE"
                    }),
                    DELETE_ROOM_THREAD: (e, t, n, r) => new Request(oo(rC(), e, t, n, r), {
                        method: "DELETE"
                    }),
                    DELETE_COMMENT: (e, t, n, r, o) => new Request(oo(rR(), e, t, n, r, o), {
                        method: "DELETE"
                    }),
                    GET_ROOM_ATTACHMENTS_PRESIGNED_URLS: (e, t, n) => oo(rA(), e, t, n),
                    GET_SCHEMAS: (e, t) => oo(rN(), e, t),
                    GET_SCHEMA: (e, t, n, r) => {
                        let [o, i] = ou(n, r);
                        return oo(rP(), e, t, o, String(i))
                    },
                    CREATE_SCHEMA: (e, t, n) => new Request(oo(rI(), e, t), {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(n)
                    }),
                    UPDATE_SCHEMA: (e, t, n, r, o) => new Request(oo(rL(), e, t, n, String(r)), {
                        method: "PUT",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(o)
                    }),
                    DELETE_SCHEMA: (e, t, n, r) => new Request(oo(rj(), e, t, n, String(r)), {
                        method: "DELETE",
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }),
                    CHECK_ROOM_SCHEMA: (e, t, n, r) => new Request(oo(rk(), e, t, n), {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            body: r
                        })
                    }),
                    ATTACH_ROOM_SCHEMA: (e, t, n, r) => new Request(oo(rD(), e, t, n), {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            schema: r
                        })
                    }),
                    DETACH_ROOM_SCHEMA: (e, t, n) => new Request(oo(rM(), e, t, n), {
                        method: "POST",
                        body: JSON.stringify({})
                    }),
                    LOAD_QUICKSTART_GUIDE: e => new Request(oo(rU(), e))
                },
                om = {
                    DOCS: (e, t) => u(oo(rG()), {
                        title: e,
                        type: t
                    }),
                    CHANGELOG_ENTRY: e => {
                        let {
                            week: t,
                            version: n,
                            socialBranding: r
                        } = e;
                        return u(oo(rF()), {
                            week: t,
                            version: n,
                            socialBranding: r ? "true" : void 0,
                            rand: void 0
                        })
                    }
                };

            function oh(e) {
                return oo(rH(), r6, oe, oo.safe(e))
            }

            function oE(e) {
                return oo(rz(), r6, oe, oo.safe(e))
            }

            function og(e) {
                return oo(rB(), oo.safe(e))
            }
            let ov = oo(rV()),
                ob = oo(rJ()),
                oy = oo(rY()),
                oT = oo(rW()),
                o_ = oo(rK(), r6, oe),
                ow = {
                    TWITTER: oo(rX()),
                    GITHUB: oo(rq(), r6),
                    GITHUB_REPO: oo(rZ(), r6, oe),
                    LINKEDIN: oo(r$()),
                    DISCORD: oo(rQ()),
                    YOUTUBE: oo(r0())
                },
                ox = e => oo(r1(), oo.safe(e)),
                oO = (e, t) => oo(r2(), e, "".concat(t)),
                oS = {
                    SM: 640,
                    MD: 768,
                    LG: 1024,
                    XL: 1280,
                    XXL: 1440,
                    XXXL: 1780
                },
                oC = "exampleId",
                oR = "examplePreview",
                oA = "apiKey",
                oN = 50,
                oP = 50;
            (o = r || (r = {}))[o.NotFound = 0] = "NotFound", o[o.EmailMismatch = 1] = "EmailMismatch", o[o.Expired = 2] = "Expired", o[o.Invalid = 3] = "Invalid"
        },
        62324: function(e, t, n) {
            "use strict";
            n.d(t, {
                $: function() {
                    return l
                }
            });
            var r = n(85893),
                o = n(20402),
                i = n(64795),
                u = n.n(i);
            let c = Array(12).fill(0);

            function l(e) {
                let {
                    className: t,
                    appearance: n = "default",
                    size: i = "md"
                } = e;
                return (0, r.jsx)("div", {
                    className: (0, o.cn)(t, {
                        "size-2": "xs" === i,
                        "size-2.5": "sm" === i,
                        "size-3": "md" === i,
                        "size-4": "lg" === i,
                        "size-5": "xl" === i,
                        "size-7": "2xl" === i
                    }),
                    children: (0, r.jsx)("div", {
                        className: "relative left-1/2 top-1/2 h-full w-full",
                        children: c.map((e, t) => (0, r.jsx)("div", {
                            className: (0, o.cn)(u().bar, "absolute left-[-10%] top-[-3.9%] h-[8%] w-[24%] rounded-md motion-reduce:animate-none motion-reduce:transition-none", {
                                "bg-product-surface-base-inverse": "default" === n,
                                "bg-product-surface-base": "inverse" === n,
                                "bg-product-surface-brand": "brand" === n,
                                "bg-product-surface-success": "success" === n,
                                "bg-product-surface-warning": "warning" === n,
                                "bg-product-surface-danger": "danger" === n,
                                "bg-product-surface-information": "information" === n,
                                "bg-product-surface-accent-yellow": "product-comments" === n,
                                "bg-product-surface-accent-green": "product-notifications" === n,
                                "bg-product-surface-accent-blue": "product-text-editor" === n,
                                "bg-product-surface-accent-pink": "product-realtime-apis" === n
                            })
                        }, t))
                    })
                })
            }
        },
        82889: function(e, t, n) {
            "use strict";
            n.d(t, {
                FN: function() {
                    return Q
                },
                gD: function() {
                    return ee
                },
                sA: function() {
                    return et
                },
                lj: function() {
                    return er
                },
                VW: function() {
                    return Z
                },
                Mi: function() {
                    return en
                },
                _i: function() {
                    return $
                }
            });
            var r = n(85893),
                o = n(87462),
                i = n(67294),
                u = n(73935);

            function c(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (null == e || e(r), !1 === n || !r.defaultPrevented) return null == t ? void 0 : t(r)
                }
            }

            function l(...e) {
                return (0, i.useCallback)(function(...e) {
                    return t => e.forEach(e => {
                        "function" == typeof e ? e(t) : null != e && (e.current = t)
                    })
                }(...e), e)
            }

            function s(e, t = []) {
                let n = [],
                    r = () => {
                        let t = n.map(e => (0, i.createContext)(e));
                        return function(n) {
                            let r = (null == n ? void 0 : n[e]) || t;
                            return (0, i.useMemo)(() => ({
                                [`__scope${e}`]: { ...n,
                                    [e]: r
                                }
                            }), [n, r])
                        }
                    };
                return r.scopeName = e, [function(t, r) {
                    let o = (0, i.createContext)(r),
                        u = n.length;

                    function c(t) {
                        let {
                            scope: n,
                            children: r,
                            ...c
                        } = t, l = (null == n ? void 0 : n[e][u]) || o, s = (0, i.useMemo)(() => c, Object.values(c));
                        return (0, i.createElement)(l.Provider, {
                            value: s
                        }, r)
                    }
                    return n = [...n, r], c.displayName = t + "Provider", [c, function(n, c) {
                        let l = (null == c ? void 0 : c[e][u]) || o,
                            s = (0, i.useContext)(l);
                        if (s) return s;
                        if (void 0 !== r) return r;
                        throw Error(`\`${n}\` must be used within \`${t}\``)
                    }]
                }, function(...e) {
                    let t = e[0];
                    if (1 === e.length) return t;
                    let n = () => {
                        let n = e.map(e => ({
                            useScope: e(),
                            scopeName: e.scopeName
                        }));
                        return function(e) {
                            let r = n.reduce((t, {
                                useScope: n,
                                scopeName: r
                            }) => {
                                let o = n(e)[`__scope${r}`];
                                return { ...t,
                                    ...o
                                }
                            }, {});
                            return (0, i.useMemo)(() => ({
                                [`__scope${t.scopeName}`]: r
                            }), [r])
                        }
                    };
                    return n.scopeName = t.scopeName, n
                }(r, ...t)]
            }
            var a = n(4222),
                f = n(40666),
                d = n(18304),
                p = n(438);
            let m = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                let n = (0, i.forwardRef)((e, n) => {
                    let {
                        asChild: r,
                        ...u
                    } = e, c = r ? a.g7 : t;
                    return (0, i.useEffect)(() => {
                        window[Symbol.for("radix-ui")] = !0
                    }, []), (0, i.createElement)(c, (0, o.Z)({}, u, {
                        ref: n
                    }))
                });
                return n.displayName = `Primitive.${t}`, { ...e,
                    [t]: n
                }
            }, {});

            function h(e) {
                let t = (0, i.useRef)(e);
                return (0, i.useEffect)(() => {
                    t.current = e
                }), (0, i.useMemo)(() => (...e) => {
                    var n;
                    return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                }, [])
            }
            let E = (null == globalThis ? void 0 : globalThis.document) ? i.useLayoutEffect : () => {};
            var g = n(44466);
            let v = "ToastProvider",
                [b, y, T] = function(e) {
                    let t = e + "CollectionProvider",
                        [n, r] = s(t),
                        [o, u] = n(t, {
                            collectionRef: {
                                current: null
                            },
                            itemMap: new Map
                        }),
                        c = e + "CollectionSlot",
                        f = i.forwardRef((e, t) => {
                            let {
                                scope: n,
                                children: r
                            } = e, o = l(t, u(c, n).collectionRef);
                            return i.createElement(a.g7, {
                                ref: o
                            }, r)
                        }),
                        d = e + "CollectionItemSlot",
                        p = "data-radix-collection-item";
                    return [{
                        Provider: e => {
                            let {
                                scope: t,
                                children: n
                            } = e, r = i.useRef(null), u = i.useRef(new Map).current;
                            return i.createElement(o, {
                                scope: t,
                                itemMap: u,
                                collectionRef: r
                            }, n)
                        },
                        Slot: f,
                        ItemSlot: i.forwardRef((e, t) => {
                            let {
                                scope: n,
                                children: r,
                                ...o
                            } = e, c = i.useRef(null), s = l(t, c), f = u(d, n);
                            return i.useEffect(() => (f.itemMap.set(c, {
                                ref: c,
                                ...o
                            }), () => void f.itemMap.delete(c))), i.createElement(a.g7, {
                                [p]: "",
                                ref: s
                            }, r)
                        })
                    }, function(t) {
                        let n = u(e + "CollectionConsumer", t);
                        return i.useCallback(() => {
                            let e = n.collectionRef.current;
                            if (!e) return [];
                            let t = Array.from(e.querySelectorAll(`[${p}]`));
                            return Array.from(n.itemMap.values()).sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current))
                        }, [n.collectionRef, n.itemMap])
                    }, r]
                }("Toast"),
                [_, w] = s("Toast", [T]),
                [x, O] = _(v),
                S = e => {
                    let {
                        __scopeToast: t,
                        label: n = "Notification",
                        duration: r = 5e3,
                        swipeDirection: o = "right",
                        swipeThreshold: u = 50,
                        children: c
                    } = e, [l, s] = (0, i.useState)(null), [a, f] = (0, i.useState)(0), d = (0, i.useRef)(!1), p = (0, i.useRef)(!1);
                    return (0, i.createElement)(b.Provider, {
                        scope: t
                    }, (0, i.createElement)(x, {
                        scope: t,
                        label: n,
                        duration: r,
                        swipeDirection: o,
                        swipeThreshold: u,
                        toastCount: a,
                        viewport: l,
                        onViewportChange: s,
                        onToastAdd: (0, i.useCallback)(() => f(e => e + 1), []),
                        onToastRemove: (0, i.useCallback)(() => f(e => e - 1), []),
                        isFocusedToastEscapeKeyDownRef: d,
                        isClosePausedRef: p
                    }, c))
                };
            S.propTypes = {
                label: e => e.label && "string" == typeof e.label && !e.label.trim() ? Error(`Invalid prop \`label\` supplied to \`${v}\`. Expected non-empty \`string\`.`) : null
            };
            let C = ["F8"],
                R = "toast.viewportPause",
                A = "toast.viewportResume",
                N = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeToast: n,
                        hotkey: r = C,
                        label: u = "Notifications ({hotkey})",
                        ...c
                    } = e, s = O("ToastViewport", n), a = y(n), d = (0, i.useRef)(null), p = (0, i.useRef)(null), h = (0, i.useRef)(null), E = (0, i.useRef)(null), g = l(t, E, s.onViewportChange), v = r.join("+").replace(/Key/g, "").replace(/Digit/g, ""), T = s.toastCount > 0;
                    (0, i.useEffect)(() => {
                        let e = e => {
                            var t;
                            r.every(t => e[t] || e.code === t) && (null === (t = E.current) || void 0 === t || t.focus())
                        };
                        return document.addEventListener("keydown", e), () => document.removeEventListener("keydown", e)
                    }, [r]), (0, i.useEffect)(() => {
                        let e = d.current,
                            t = E.current;
                        if (T && e && t) {
                            let n = () => {
                                    if (!s.isClosePausedRef.current) {
                                        let e = new CustomEvent(R);
                                        t.dispatchEvent(e), s.isClosePausedRef.current = !0
                                    }
                                },
                                r = () => {
                                    if (s.isClosePausedRef.current) {
                                        let e = new CustomEvent(A);
                                        t.dispatchEvent(e), s.isClosePausedRef.current = !1
                                    }
                                },
                                o = t => {
                                    e.contains(t.relatedTarget) || r()
                                },
                                i = () => {
                                    e.contains(document.activeElement) || r()
                                };
                            return e.addEventListener("focusin", n), e.addEventListener("focusout", o), e.addEventListener("pointermove", n), e.addEventListener("pointerleave", i), window.addEventListener("blur", n), window.addEventListener("focus", r), () => {
                                e.removeEventListener("focusin", n), e.removeEventListener("focusout", o), e.removeEventListener("pointermove", n), e.removeEventListener("pointerleave", i), window.removeEventListener("blur", n), window.removeEventListener("focus", r)
                            }
                        }
                    }, [T, s.isClosePausedRef]);
                    let _ = (0, i.useCallback)(({
                        tabbingDirection: e
                    }) => {
                        let t = a().map(t => {
                            let n = t.ref.current,
                                r = [n, ... function(e) {
                                    let t = [],
                                        n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
                                            acceptNode: e => {
                                                let t = "INPUT" === e.tagName && "hidden" === e.type;
                                                return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
                                            }
                                        });
                                    for (; n.nextNode();) t.push(n.currentNode);
                                    return t
                                }(n)];
                            return "forwards" === e ? r : r.reverse()
                        });
                        return ("forwards" === e ? t.reverse() : t).flat()
                    }, [a]);
                    return (0, i.useEffect)(() => {
                        let e = E.current;
                        if (e) {
                            let t = t => {
                                let n = t.altKey || t.ctrlKey || t.metaKey;
                                if ("Tab" === t.key && !n) {
                                    var r, o, i;
                                    let n = document.activeElement,
                                        u = t.shiftKey;
                                    if (t.target === e && u) {
                                        null === (r = p.current) || void 0 === r || r.focus();
                                        return
                                    }
                                    let c = _({
                                            tabbingDirection: u ? "backwards" : "forwards"
                                        }),
                                        l = c.findIndex(e => e === n);
                                    J(c.slice(l + 1)) ? t.preventDefault() : u ? null === (o = p.current) || void 0 === o || o.focus() : null === (i = h.current) || void 0 === i || i.focus()
                                }
                            };
                            return e.addEventListener("keydown", t), () => e.removeEventListener("keydown", t)
                        }
                    }, [a, _]), (0, i.createElement)(f.I0, {
                        ref: d,
                        role: "region",
                        "aria-label": u.replace("{hotkey}", v),
                        tabIndex: -1,
                        style: {
                            pointerEvents: T ? void 0 : "none"
                        }
                    }, T && (0, i.createElement)(P, {
                        ref: p,
                        onFocusFromOutsideViewport: () => {
                            J(_({
                                tabbingDirection: "forwards"
                            }))
                        }
                    }), (0, i.createElement)(b.Slot, {
                        scope: n
                    }, (0, i.createElement)(m.ol, (0, o.Z)({
                        tabIndex: -1
                    }, c, {
                        ref: g
                    }))), T && (0, i.createElement)(P, {
                        ref: h,
                        onFocusFromOutsideViewport: () => {
                            J(_({
                                tabbingDirection: "backwards"
                            }))
                        }
                    }))
                }),
                P = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeToast: n,
                        onFocusFromOutsideViewport: r,
                        ...u
                    } = e, c = O("ToastFocusProxy", n);
                    return (0, i.createElement)(g.T, (0, o.Z)({
                        "aria-hidden": !0,
                        tabIndex: 0
                    }, u, {
                        ref: t,
                        style: {
                            position: "fixed"
                        },
                        onFocus: e => {
                            var t;
                            let n = e.relatedTarget;
                            null !== (t = c.viewport) && void 0 !== t && t.contains(n) || r()
                        }
                    }))
                }),
                I = "Toast",
                L = (0, i.forwardRef)((e, t) => {
                    let {
                        forceMount: n,
                        open: r,
                        defaultOpen: u,
                        onOpenChange: l,
                        ...s
                    } = e, [a = !0, f] = function({
                        prop: e,
                        defaultProp: t,
                        onChange: n = () => {}
                    }) {
                        let [r, o] = function({
                            defaultProp: e,
                            onChange: t
                        }) {
                            let n = (0, i.useState)(e),
                                [r] = n,
                                o = (0, i.useRef)(r),
                                u = h(t);
                            return (0, i.useEffect)(() => {
                                o.current !== r && (u(r), o.current = r)
                            }, [r, o, u]), n
                        }({
                            defaultProp: t,
                            onChange: n
                        }), u = void 0 !== e, c = u ? e : r, l = h(n);
                        return [c, (0, i.useCallback)(t => {
                            if (u) {
                                let n = "function" == typeof t ? t(e) : t;
                                n !== e && l(n)
                            } else o(t)
                        }, [u, e, o, l])]
                    }({
                        prop: r,
                        defaultProp: u,
                        onChange: l
                    });
                    return (0, i.createElement)(p.z, {
                        present: n || a
                    }, (0, i.createElement)(D, (0, o.Z)({
                        open: a
                    }, s, {
                        ref: t,
                        onClose: () => f(!1),
                        onPause: h(e.onPause),
                        onResume: h(e.onResume),
                        onSwipeStart: c(e.onSwipeStart, e => {
                            e.currentTarget.setAttribute("data-swipe", "start")
                        }),
                        onSwipeMove: c(e.onSwipeMove, e => {
                            let {
                                x: t,
                                y: n
                            } = e.detail.delta;
                            e.currentTarget.setAttribute("data-swipe", "move"), e.currentTarget.style.setProperty("--radix-toast-swipe-move-x", `${t}px`), e.currentTarget.style.setProperty("--radix-toast-swipe-move-y", `${n}px`)
                        }),
                        onSwipeCancel: c(e.onSwipeCancel, e => {
                            e.currentTarget.setAttribute("data-swipe", "cancel"), e.currentTarget.style.removeProperty("--radix-toast-swipe-move-x"), e.currentTarget.style.removeProperty("--radix-toast-swipe-move-y"), e.currentTarget.style.removeProperty("--radix-toast-swipe-end-x"), e.currentTarget.style.removeProperty("--radix-toast-swipe-end-y")
                        }),
                        onSwipeEnd: c(e.onSwipeEnd, e => {
                            let {
                                x: t,
                                y: n
                            } = e.detail.delta;
                            e.currentTarget.setAttribute("data-swipe", "end"), e.currentTarget.style.removeProperty("--radix-toast-swipe-move-x"), e.currentTarget.style.removeProperty("--radix-toast-swipe-move-y"), e.currentTarget.style.setProperty("--radix-toast-swipe-end-x", `${t}px`), e.currentTarget.style.setProperty("--radix-toast-swipe-end-y", `${n}px`), f(!1)
                        })
                    })))
                }),
                [j, k] = _(I, {
                    onClose() {}
                }),
                D = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeToast: n,
                        type: r = "foreground",
                        duration: s,
                        open: a,
                        onClose: d,
                        onEscapeKeyDown: p,
                        onPause: E,
                        onResume: g,
                        onSwipeStart: v,
                        onSwipeMove: y,
                        onSwipeCancel: T,
                        onSwipeEnd: _,
                        ...w
                    } = e, x = O(I, n), [S, C] = (0, i.useState)(null), N = l(t, e => C(e)), P = (0, i.useRef)(null), L = (0, i.useRef)(null), k = s || x.duration, D = (0, i.useRef)(0), U = (0, i.useRef)(k), G = (0, i.useRef)(0), {
                        onToastAdd: F,
                        onToastRemove: H
                    } = x, z = h(() => {
                        var e;
                        (null == S ? void 0 : S.contains(document.activeElement)) && (null === (e = x.viewport) || void 0 === e || e.focus()), d()
                    }), J = (0, i.useCallback)(e => {
                        e && e !== 1 / 0 && (window.clearTimeout(G.current), D.current = new Date().getTime(), G.current = window.setTimeout(z, e))
                    }, [z]);
                    (0, i.useEffect)(() => {
                        let e = x.viewport;
                        if (e) {
                            let t = () => {
                                    J(U.current), null == g || g()
                                },
                                n = () => {
                                    let e = new Date().getTime() - D.current;
                                    U.current = U.current - e, window.clearTimeout(G.current), null == E || E()
                                };
                            return e.addEventListener(R, n), e.addEventListener(A, t), () => {
                                e.removeEventListener(R, n), e.removeEventListener(A, t)
                            }
                        }
                    }, [x.viewport, k, E, g, J]), (0, i.useEffect)(() => {
                        a && !x.isClosePausedRef.current && J(k)
                    }, [a, k, x.isClosePausedRef, J]), (0, i.useEffect)(() => (F(), () => H()), [F, H]);
                    let Y = (0, i.useMemo)(() => S ? function e(t) {
                        let n = [];
                        return Array.from(t.childNodes).forEach(t => {
                            if (t.nodeType === t.TEXT_NODE && t.textContent && n.push(t.textContent), t.nodeType === t.ELEMENT_NODE) {
                                let r = t.ariaHidden || t.hidden || "none" === t.style.display,
                                    o = "" === t.dataset.radixToastAnnounceExclude;
                                if (!r) {
                                    if (o) {
                                        let e = t.dataset.radixToastAnnounceAlt;
                                        e && n.push(e)
                                    } else n.push(...e(t))
                                }
                            }
                        }), n
                    }(S) : null, [S]);
                    return x.viewport ? (0, i.createElement)(i.Fragment, null, Y && (0, i.createElement)(M, {
                        __scopeToast: n,
                        role: "status",
                        "aria-live": "foreground" === r ? "assertive" : "polite",
                        "aria-atomic": !0
                    }, Y), (0, i.createElement)(j, {
                        scope: n,
                        onClose: z
                    }, (0, u.createPortal)((0, i.createElement)(b.ItemSlot, {
                        scope: n
                    }, (0, i.createElement)(f.fC, {
                        asChild: !0,
                        onEscapeKeyDown: c(p, () => {
                            x.isFocusedToastEscapeKeyDownRef.current || z(), x.isFocusedToastEscapeKeyDownRef.current = !1
                        })
                    }, (0, i.createElement)(m.li, (0, o.Z)({
                        role: "status",
                        "aria-live": "off",
                        "aria-atomic": !0,
                        tabIndex: 0,
                        "data-state": a ? "open" : "closed",
                        "data-swipe-direction": x.swipeDirection
                    }, w, {
                        ref: N,
                        style: {
                            userSelect: "none",
                            touchAction: "none",
                            ...e.style
                        },
                        onKeyDown: c(e.onKeyDown, e => {
                            "Escape" !== e.key || (null == p || p(e.nativeEvent), e.nativeEvent.defaultPrevented || (x.isFocusedToastEscapeKeyDownRef.current = !0, z()))
                        }),
                        onPointerDown: c(e.onPointerDown, e => {
                            0 === e.button && (P.current = {
                                x: e.clientX,
                                y: e.clientY
                            })
                        }),
                        onPointerMove: c(e.onPointerMove, e => {
                            if (!P.current) return;
                            let t = e.clientX - P.current.x,
                                n = e.clientY - P.current.y,
                                r = !!L.current,
                                o = ["left", "right"].includes(x.swipeDirection),
                                i = ["left", "up"].includes(x.swipeDirection) ? Math.min : Math.max,
                                u = o ? i(0, t) : 0,
                                c = o ? 0 : i(0, n),
                                l = "touch" === e.pointerType ? 10 : 2,
                                s = {
                                    x: u,
                                    y: c
                                },
                                a = {
                                    originalEvent: e,
                                    delta: s
                                };
                            r ? (L.current = s, B("toast.swipeMove", y, a, {
                                discrete: !1
                            })) : V(s, x.swipeDirection, l) ? (L.current = s, B("toast.swipeStart", v, a, {
                                discrete: !1
                            }), e.target.setPointerCapture(e.pointerId)) : (Math.abs(t) > l || Math.abs(n) > l) && (P.current = null)
                        }),
                        onPointerUp: c(e.onPointerUp, e => {
                            let t = L.current,
                                n = e.target;
                            if (n.hasPointerCapture(e.pointerId) && n.releasePointerCapture(e.pointerId), L.current = null, P.current = null, t) {
                                let n = e.currentTarget,
                                    r = {
                                        originalEvent: e,
                                        delta: t
                                    };
                                V(t, x.swipeDirection, x.swipeThreshold) ? B("toast.swipeEnd", _, r, {
                                    discrete: !0
                                }) : B("toast.swipeCancel", T, r, {
                                    discrete: !0
                                }), n.addEventListener("click", e => e.preventDefault(), {
                                    once: !0
                                })
                            }
                        })
                    })))), x.viewport))) : null
                });
            D.propTypes = {
                type: e => e.type && !["foreground", "background"].includes(e.type) ? Error(`Invalid prop \`type\` supplied to \`${I}\`. Expected \`foreground | background\`.`) : null
            };
            let M = e => {
                    let {
                        __scopeToast: t,
                        children: n,
                        ...r
                    } = e, o = O(I, t), [u, c] = (0, i.useState)(!1), [l, s] = (0, i.useState)(!1);
                    return function(e = () => {}) {
                        let t = h(e);
                        E(() => {
                            let e = 0,
                                n = 0;
                            return e = window.requestAnimationFrame(() => n = window.requestAnimationFrame(t)), () => {
                                window.cancelAnimationFrame(e), window.cancelAnimationFrame(n)
                            }
                        }, [t])
                    }(() => c(!0)), (0, i.useEffect)(() => {
                        let e = window.setTimeout(() => s(!0), 1e3);
                        return () => window.clearTimeout(e)
                    }, []), l ? null : (0, i.createElement)(d.h, {
                        asChild: !0
                    }, (0, i.createElement)(g.T, r, u && (0, i.createElement)(i.Fragment, null, o.label, " ", n)))
                },
                U = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeToast: n,
                        ...r
                    } = e;
                    return (0, i.createElement)(m.div, (0, o.Z)({}, r, {
                        ref: t
                    }))
                }),
                G = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeToast: n,
                        ...r
                    } = e;
                    return (0, i.createElement)(m.div, (0, o.Z)({}, r, {
                        ref: t
                    }))
                }),
                F = (0, i.forwardRef)((e, t) => {
                    let {
                        altText: n,
                        ...r
                    } = e;
                    return n ? (0, i.createElement)(z, {
                        altText: n,
                        asChild: !0
                    }, (0, i.createElement)(H, (0, o.Z)({}, r, {
                        ref: t
                    }))) : null
                });
            F.propTypes = {
                altText: e => e.altText ? null : Error("Missing prop `altText` expected on `ToastAction`")
            };
            let H = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeToast: n,
                        ...r
                    } = e, u = k("ToastClose", n);
                    return (0, i.createElement)(z, {
                        asChild: !0
                    }, (0, i.createElement)(m.button, (0, o.Z)({
                        type: "button"
                    }, r, {
                        ref: t,
                        onClick: c(e.onClick, u.onClose)
                    })))
                }),
                z = (0, i.forwardRef)((e, t) => {
                    let {
                        __scopeToast: n,
                        altText: r,
                        ...u
                    } = e;
                    return (0, i.createElement)(m.div, (0, o.Z)({
                        "data-radix-toast-announce-exclude": "",
                        "data-radix-toast-announce-alt": r || void 0
                    }, u, {
                        ref: t
                    }))
                });

            function B(e, t, n, {
                discrete: r
            }) {
                let o = n.originalEvent.currentTarget,
                    i = new CustomEvent(e, {
                        bubbles: !0,
                        cancelable: !0,
                        detail: n
                    });
                (t && o.addEventListener(e, t, {
                    once: !0
                }), r) ? o && (0, u.flushSync)(() => o.dispatchEvent(i)): o.dispatchEvent(i)
            }
            let V = (e, t, n = 0) => {
                let r = Math.abs(e.x),
                    o = Math.abs(e.y),
                    i = r > o;
                return "left" === t || "right" === t ? i && r > n : !i && o > n
            };

            function J(e) {
                let t = document.activeElement;
                return e.some(e => e === t || (e.focus(), document.activeElement !== t))
            }
            var Y = n(93967),
                W = n.n(Y),
                K = n(23007),
                X = n(40421),
                q = n.n(X);
            let Z = S,
                $ = i.forwardRef((e, t) => {
                    let {
                        className: n,
                        ...o
                    } = e;
                    return (0, r.jsx)(N, {
                        ref: t,
                        className: W()("fixed bottom-0 z-highest flex max-h-screen w-full flex-col-reverse gap-4 p-[var(--outer-gutter)] sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]", n),
                        ...o
                    })
                }),
                Q = i.forwardRef((e, t) => {
                    let {
                        className: n,
                        ...o
                    } = e;
                    return (0, r.jsx)(L, {
                        ref: t,
                        className: W()("group pointer-events-auto relative flex w-full items-center justify-between gap-4 rounded-md border border-product-divider p-4 text-sm shadow-product-popover", n, q().toast),
                        ...o
                    })
                }),
                ee = i.forwardRef((e, t) => {
                    let {
                        className: n,
                        ...o
                    } = e;
                    return (0, r.jsx)(F, {
                        ref: t,
                        className: W()("inline-flex h-8 shrink-0 items-center justify-center rounded-md border border-product-divider bg-product-surface-base-inverse px-3 text-sm font-medium text-product-inverse shadow-product-raised transition-colors disabled:pointer-events-none disabled:opacity-50", n),
                        ...o
                    })
                }),
                et = i.forwardRef((e, t) => {
                    let {
                        className: n,
                        ...o
                    } = e;
                    return (0, r.jsx)(H, {
                        ref: t,
                        className: W()("transition-all group absolute right-0 top-0 inline-flex h-5 w-5 -translate-y-1/3 translate-x-1/3 items-center justify-center rounded-full border border-product-divider bg-product-surface-base opacity-0 shadow-product-raised duration-150 ease-out hover:border-product-divider-bold hover:bg-product-surface-raised group-hover:opacity-100 focus:border-product-divider-bold focus:bg-product-surface-raised", n),
                        "toast-close": "",
                        ...o,
                        children: (0, r.jsx)(K.Z, {
                            className: "h-3 w-3 fill-product-icon transition-colors duration-150 ease-out group-hover:fill-product-icon-bolder group-focus:fill-product-icon-bolder"
                        })
                    })
                }),
                en = i.forwardRef((e, t) => {
                    let {
                        className: n,
                        ...o
                    } = e;
                    return (0, r.jsx)(U, {
                        ref: t,
                        className: W()("font-medium", n),
                        ...o
                    })
                }),
                er = i.forwardRef((e, t) => {
                    let {
                        className: n,
                        ...o
                    } = e;
                    return (0, r.jsx)(G, {
                        ref: t,
                        className: n,
                        ...o
                    })
                })
        },
        18106: function(e, t, n) {
            "use strict";
            n.d(t, {
                ZP: function() {
                    return d
                },
                x_: function() {
                    return p
                }
            });
            var r = n(85893),
                o = n(93967),
                i = n.n(o),
                u = n(67294),
                c = n(89701),
                l = n(42012),
                s = n(62324),
                a = n(82889);
            let f = (0, u.createContext)(null);

            function d(e) {
                let {
                    children: t
                } = e, [n, o] = (0, u.useState)([]), d = (0, u.useRef)(0), p = (0, u.useRef)(new Map);
                (0, u.useEffect)(() => {
                    let e = p.current;
                    return () => {
                        e.forEach(e => {
                            window.clearTimeout(e)
                        })
                    }
                }, []);
                let m = (0, u.useCallback)(e => {
                        let {
                            title: t,
                            description: n,
                            action: r,
                            type: i = "default"
                        } = e, u = d.current++;
                        return o(e => [...e, {
                            id: u,
                            title: t,
                            description: n,
                            action: r,
                            type: i
                        }]), u
                    }, []),
                    h = (0, u.useCallback)((e, t) => {
                        let {
                            title: n,
                            description: r,
                            action: i,
                            type: u
                        } = t;
                        o(t => t.map(t => t.id !== e ? t : { ...t,
                            title: n,
                            description: r,
                            action: i,
                            ...u ? {
                                type: u
                            } : {}
                        }))
                    }, []),
                    E = (0, u.useCallback)(e => {
                        let t = window.setTimeout(() => {
                            p.current.delete(e), o(t => t.filter(t => t.id !== e))
                        }, 100);
                        p.current.set(e, t)
                    }, []),
                    g = (0, u.useMemo)(() => ({
                        create: m,
                        update: h,
                        remove: E
                    }), [m, h, E]);
                return (0, r.jsx)(f.Provider, {
                    value: g,
                    children: (0, r.jsxs)(a.VW, {
                        children: [t, (0, r.jsx)("div", {
                            children: n.map(e => {
                                let {
                                    id: t,
                                    title: n,
                                    description: o,
                                    action: u,
                                    type: f
                                } = e;
                                return (0, r.jsxs)(a.FN, {
                                    className: "bg-product-surface-raised",
                                    defaultOpen: !0,
                                    onOpenChange: e => {
                                        if (!e) return E(t)
                                    },
                                    children: [(0, r.jsxs)("div", {
                                        className: "flex gap-3",
                                        children: ["success" === f && (0, r.jsx)(c.Z, {
                                            className: "mt-[2px] h-4 w-4 shrink-0 fill-product-icon-success"
                                        }), ("error" === f || "warning" === f) && (0, r.jsx)(l.Z, {
                                            className: i()("mt-[2px] h-4 w-4 shrink-0", {
                                                "fill-product-icon-danger": "error" === f,
                                                "fill-product-icon-warning": "warning" === f
                                            })
                                        }), "loading" === f && (0, r.jsx)(s.$, {
                                            className: "mt-[2px] shrink-0"
                                        }), (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-0.5",
                                            children: [n && (0, r.jsx)(a.Mi, {
                                                children: n
                                            }), o && (0, r.jsx)(a.lj, {
                                                className: i()({
                                                    "text-product-subtle": ("default" === f || "loading" === f) && n
                                                }),
                                                children: o
                                            })]
                                        })]
                                    }), u, (0, r.jsx)(a.sA, {})]
                                }, t)
                            })
                        }), (0, r.jsx)(a._i, {})]
                    })
                })
            }

            function p() {
                let e = (0, u.useContext)(f);
                if (!e) throw Error("useToastActions must be used within a ToastsProvider");
                return e
            }
        },
        60162: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return s
                },
                e: function() {
                    return a
                }
            });
            var r = n(85893),
                o = n(67294);
            let i = "cookieSettings",
                u = {
                    essentials: !0,
                    marketing: !1,
                    analytics: !1,
                    isLoading: !0
                },
                c = (0, o.createContext)(u),
                l = (0, o.createContext)(null);

            function s(e) {
                let {
                    children: t
                } = e, [n, s] = (0, o.useState)(u);
                (0, o.useEffect)(() => {
                    let e = localStorage.getItem(i);
                    e ? s({ ...JSON.parse(e)
                    }) : s({ ...u,
                        isLoading: !1
                    })
                }, []), (0, o.useEffect)(() => {
                    localStorage.setItem(i, JSON.stringify(n))
                }, [n]);
                let a = (0, o.useCallback)(e => {
                    s(t => ({ ...t,
                        ...e
                    }))
                }, []);
                return (0, r.jsx)(c.Provider, {
                    value: n,
                    children: (0, r.jsx)(l.Provider, {
                        value: a,
                        children: t
                    })
                })
            }

            function a() {
                let e = (0, o.useContext)(c),
                    t = (0, o.useContext)(l);
                if (null == e || null == t) throw Error("CookieSettingsProvider is missing");
                return [e, t]
            }
        },
        29096: function(e, t, n) {
            "use strict";
            n.d(t, {
                _: function() {
                    return c
                },
                c: function() {
                    return l
                }
            });
            var r = n(85893),
                o = n(67294),
                i = n(94096),
                u = n(60162);

            function c() {
                let [e] = (0, u.e)();
                return e.marketing ? (0, r.jsx)(i.R1, {}) : null
            }

            function l() {
                let [e] = (0, u.e)(), t = (0, o.useRef)(), n = (0, o.useCallback)(() => new Promise((e, n) => {
                    let r = 0;
                    window.koala_marketing_tag_script || n(), window.ko && (clearInterval(t.current), e(window.ko)), t.current = setInterval(() => {
                        window.ko && (clearInterval(t.current), e(window.ko)), 60 === (r += 1) && (clearInterval(t.current), n())
                    }, 100)
                }), []);
                return (0, o.useEffect)(() => () => {
                    t.current && clearInterval(t.current)
                }, []), (0, o.useCallback)((t, r) => {
                    e.marketing && n().then(e => {
                        e.identify(t, { ...r
                        })
                    }).catch(() => {})
                }, [e.isLoading, e.marketing, n])
            }
        },
        20402: function(e, t, n) {
            "use strict";
            n.d(t, {
                cn: function() {
                    return U
                }
            });
            var r = n(90512);
            let o = /^\[(.+)\]$/;

            function i(e, t) {
                let n = e;
                return t.split("-").forEach(e => {
                    n.nextPart.has(e) || n.nextPart.set(e, {
                        nextPart: new Map,
                        validators: []
                    }), n = n.nextPart.get(e)
                }), n
            }
            let u = /\s+/;

            function c() {
                let e, t, n = 0,
                    r = "";
                for (; n < arguments.length;)(e = arguments[n++]) && (t = function e(t) {
                    let n;
                    if ("string" == typeof t) return t;
                    let r = "";
                    for (let o = 0; o < t.length; o++) t[o] && (n = e(t[o])) && (r && (r += " "), r += n);
                    return r
                }(e)) && (r && (r += " "), r += t);
                return r
            }

            function l(e) {
                let t = t => t[e] || [];
                return t.isThemeGetter = !0, t
            }
            let s = /^\[(?:([a-z-]+):)?(.+)\]$/i,
                a = /^\d+\/\d+$/,
                f = new Set(["px", "full", "screen"]),
                d = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
                p = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
                m = /^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/,
                h = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
                E = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;

            function g(e) {
                return b(e) || f.has(e) || a.test(e)
            }

            function v(e) {
                return I(e, "length", L)
            }

            function b(e) {
                return !!e && !Number.isNaN(Number(e))
            }

            function y(e) {
                return I(e, "number", b)
            }

            function T(e) {
                return !!e && Number.isInteger(Number(e))
            }

            function _(e) {
                return e.endsWith("%") && b(e.slice(0, -1))
            }

            function w(e) {
                return s.test(e)
            }

            function x(e) {
                return d.test(e)
            }
            let O = new Set(["length", "size", "percentage"]);

            function S(e) {
                return I(e, O, j)
            }

            function C(e) {
                return I(e, "position", j)
            }
            let R = new Set(["image", "url"]);

            function A(e) {
                return I(e, R, D)
            }

            function N(e) {
                return I(e, "", k)
            }

            function P() {
                return !0
            }

            function I(e, t, n) {
                let r = s.exec(e);
                return !!r && (r[1] ? "string" == typeof t ? r[1] === t : t.has(r[1]) : n(r[2]))
            }

            function L(e) {
                return p.test(e) && !m.test(e)
            }

            function j() {
                return !1
            }

            function k(e) {
                return h.test(e)
            }

            function D(e) {
                return E.test(e)
            }
            let M = function(e, ...t) {
                let n, r, l;
                let s = function(u) {
                    var c;
                    return r = (n = {
                        cache: function(e) {
                            if (e < 1) return {
                                get: () => void 0,
                                set: () => {}
                            };
                            let t = 0,
                                n = new Map,
                                r = new Map;

                            function o(o, i) {
                                n.set(o, i), ++t > e && (t = 0, r = n, n = new Map)
                            }
                            return {
                                get(e) {
                                    let t = n.get(e);
                                    return void 0 !== t ? t : void 0 !== (t = r.get(e)) ? (o(e, t), t) : void 0
                                },
                                set(e, t) {
                                    n.has(e) ? n.set(e, t) : o(e, t)
                                }
                            }
                        }((c = t.reduce((e, t) => t(e), e())).cacheSize),
                        parseClassName: function(e) {
                            let {
                                separator: t,
                                experimentalParseClassName: n
                            } = e, r = 1 === t.length, o = t[0], i = t.length;

                            function u(e) {
                                let n;
                                let u = [],
                                    c = 0,
                                    l = 0;
                                for (let s = 0; s < e.length; s++) {
                                    let a = e[s];
                                    if (0 === c) {
                                        if (a === o && (r || e.slice(s, s + i) === t)) {
                                            u.push(e.slice(l, s)), l = s + i;
                                            continue
                                        }
                                        if ("/" === a) {
                                            n = s;
                                            continue
                                        }
                                    }
                                    "[" === a ? c++ : "]" === a && c--
                                }
                                let s = 0 === u.length ? e : e.substring(l),
                                    a = s.startsWith("!"),
                                    f = a ? s.substring(1) : s;
                                return {
                                    modifiers: u,
                                    hasImportantModifier: a,
                                    baseClassName: f,
                                    maybePostfixModifierPosition: n && n > l ? n - l : void 0
                                }
                            }
                            return n ? function(e) {
                                return n({
                                    className: e,
                                    parseClassName: u
                                })
                            } : u
                        }(c),
                        ... function(e) {
                            let t = function(e) {
                                    var t;
                                    let {
                                        theme: n,
                                        prefix: r
                                    } = e, o = {
                                        nextPart: new Map,
                                        validators: []
                                    };
                                    return (t = Object.entries(e.classGroups), r ? t.map(([e, t]) => [e, t.map(e => "string" == typeof e ? r + e : "object" == typeof e ? Object.fromEntries(Object.entries(e).map(([e, t]) => [r + e, t])) : e)]) : t).forEach(([e, t]) => {
                                        (function e(t, n, r, o) {
                                            t.forEach(t => {
                                                if ("string" == typeof t) {
                                                    ("" === t ? n : i(n, t)).classGroupId = r;
                                                    return
                                                }
                                                if ("function" == typeof t) {
                                                    if (t.isThemeGetter) {
                                                        e(t(o), n, r, o);
                                                        return
                                                    }
                                                    n.validators.push({
                                                        validator: t,
                                                        classGroupId: r
                                                    });
                                                    return
                                                }
                                                Object.entries(t).forEach(([t, u]) => {
                                                    e(u, i(n, t), r, o)
                                                })
                                            })
                                        })(t, o, e, n)
                                    }), o
                                }(e),
                                {
                                    conflictingClassGroups: n,
                                    conflictingClassGroupModifiers: r
                                } = e;
                            return {
                                getClassGroupId: function(e) {
                                    let n = e.split("-");
                                    return "" === n[0] && 1 !== n.length && n.shift(),
                                        function e(t, n) {
                                            if (0 === t.length) return n.classGroupId;
                                            let r = t[0],
                                                o = n.nextPart.get(r),
                                                i = o ? e(t.slice(1), o) : void 0;
                                            if (i) return i;
                                            if (0 === n.validators.length) return;
                                            let u = t.join("-");
                                            return n.validators.find(({
                                                validator: e
                                            }) => e(u)) ? .classGroupId
                                        }(n, t) || function(e) {
                                            if (o.test(e)) {
                                                let t = o.exec(e)[1],
                                                    n = t ? .substring(0, t.indexOf(":"));
                                                if (n) return "arbitrary.." + n
                                            }
                                        }(e)
                                },
                                getConflictingClassGroupIds: function(e, t) {
                                    let o = n[e] || [];
                                    return t && r[e] ? [...o, ...r[e]] : o
                                }
                            }
                        }(c)
                    }).cache.get, l = n.cache.set, s = a, a(u)
                };

                function a(e) {
                    let t = r(e);
                    if (t) return t;
                    let o = function(e, t) {
                        let {
                            parseClassName: n,
                            getClassGroupId: r,
                            getConflictingClassGroupIds: o
                        } = t, i = new Set;
                        return e.trim().split(u).map(e => {
                            let {
                                modifiers: t,
                                hasImportantModifier: o,
                                baseClassName: i,
                                maybePostfixModifierPosition: u
                            } = n(e), c = !!u, l = r(c ? i.substring(0, u) : i);
                            if (!l) {
                                if (!c || !(l = r(i))) return {
                                    isTailwindClass: !1,
                                    originalClassName: e
                                };
                                c = !1
                            }
                            let s = (function(e) {
                                if (e.length <= 1) return e;
                                let t = [],
                                    n = [];
                                return e.forEach(e => {
                                    "[" === e[0] ? (t.push(...n.sort(), e), n = []) : n.push(e)
                                }), t.push(...n.sort()), t
                            })(t).join(":");
                            return {
                                isTailwindClass: !0,
                                modifierId: o ? s + "!" : s,
                                classGroupId: l,
                                originalClassName: e,
                                hasPostfixModifier: c
                            }
                        }).reverse().filter(e => {
                            if (!e.isTailwindClass) return !0;
                            let {
                                modifierId: t,
                                classGroupId: n,
                                hasPostfixModifier: r
                            } = e, u = t + n;
                            return !i.has(u) && (i.add(u), o(n, r).forEach(e => i.add(t + e)), !0)
                        }).reverse().map(e => e.originalClassName).join(" ")
                    }(e, n);
                    return l(e, o), o
                }
                return function() {
                    return s(c.apply(null, arguments))
                }
            }(function() {
                let e = l("colors"),
                    t = l("spacing"),
                    n = l("blur"),
                    r = l("brightness"),
                    o = l("borderColor"),
                    i = l("borderRadius"),
                    u = l("borderSpacing"),
                    c = l("borderWidth"),
                    s = l("contrast"),
                    a = l("grayscale"),
                    f = l("hueRotate"),
                    d = l("invert"),
                    p = l("gap"),
                    m = l("gradientColorStops"),
                    h = l("gradientColorStopPositions"),
                    E = l("inset"),
                    O = l("margin"),
                    R = l("opacity"),
                    I = l("padding"),
                    L = l("saturate"),
                    j = l("scale"),
                    k = l("sepia"),
                    D = l("skew"),
                    M = l("space"),
                    U = l("translate"),
                    G = () => ["auto", "contain", "none"],
                    F = () => ["auto", "hidden", "clip", "visible", "scroll"],
                    H = () => ["auto", w, t],
                    z = () => [w, t],
                    B = () => ["", g, v],
                    V = () => ["auto", b, w],
                    J = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"],
                    Y = () => ["solid", "dashed", "dotted", "double", "none"],
                    W = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"],
                    K = () => ["start", "end", "center", "between", "around", "evenly", "stretch"],
                    X = () => ["", "0", w],
                    q = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"],
                    Z = () => [b, y],
                    $ = () => [b, w];
                return {
                    cacheSize: 500,
                    separator: ":",
                    theme: {
                        colors: [P],
                        spacing: [g, v],
                        blur: ["none", "", x, w],
                        brightness: Z(),
                        borderColor: [e],
                        borderRadius: ["none", "", "full", x, w],
                        borderSpacing: z(),
                        borderWidth: B(),
                        contrast: Z(),
                        grayscale: X(),
                        hueRotate: $(),
                        invert: X(),
                        gap: z(),
                        gradientColorStops: [e],
                        gradientColorStopPositions: [_, v],
                        inset: H(),
                        margin: H(),
                        opacity: Z(),
                        padding: z(),
                        saturate: Z(),
                        scale: Z(),
                        sepia: X(),
                        skew: $(),
                        space: z(),
                        translate: z()
                    },
                    classGroups: {
                        aspect: [{
                            aspect: ["auto", "square", "video", w]
                        }],
                        container: ["container"],
                        columns: [{
                            columns: [x]
                        }],
                        "break-after": [{
                            "break-after": q()
                        }],
                        "break-before": [{
                            "break-before": q()
                        }],
                        "break-inside": [{
                            "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
                        }],
                        "box-decoration": [{
                            "box-decoration": ["slice", "clone"]
                        }],
                        box: [{
                            box: ["border", "content"]
                        }],
                        display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
                        float: [{
                            float: ["right", "left", "none", "start", "end"]
                        }],
                        clear: [{
                            clear: ["left", "right", "both", "none", "start", "end"]
                        }],
                        isolation: ["isolate", "isolation-auto"],
                        "object-fit": [{
                            object: ["contain", "cover", "fill", "none", "scale-down"]
                        }],
                        "object-position": [{
                            object: [...J(), w]
                        }],
                        overflow: [{
                            overflow: F()
                        }],
                        "overflow-x": [{
                            "overflow-x": F()
                        }],
                        "overflow-y": [{
                            "overflow-y": F()
                        }],
                        overscroll: [{
                            overscroll: G()
                        }],
                        "overscroll-x": [{
                            "overscroll-x": G()
                        }],
                        "overscroll-y": [{
                            "overscroll-y": G()
                        }],
                        position: ["static", "fixed", "absolute", "relative", "sticky"],
                        inset: [{
                            inset: [E]
                        }],
                        "inset-x": [{
                            "inset-x": [E]
                        }],
                        "inset-y": [{
                            "inset-y": [E]
                        }],
                        start: [{
                            start: [E]
                        }],
                        end: [{
                            end: [E]
                        }],
                        top: [{
                            top: [E]
                        }],
                        right: [{
                            right: [E]
                        }],
                        bottom: [{
                            bottom: [E]
                        }],
                        left: [{
                            left: [E]
                        }],
                        visibility: ["visible", "invisible", "collapse"],
                        z: [{
                            z: ["auto", T, w]
                        }],
                        basis: [{
                            basis: H()
                        }],
                        "flex-direction": [{
                            flex: ["row", "row-reverse", "col", "col-reverse"]
                        }],
                        "flex-wrap": [{
                            flex: ["wrap", "wrap-reverse", "nowrap"]
                        }],
                        flex: [{
                            flex: ["1", "auto", "initial", "none", w]
                        }],
                        grow: [{
                            grow: X()
                        }],
                        shrink: [{
                            shrink: X()
                        }],
                        order: [{
                            order: ["first", "last", "none", T, w]
                        }],
                        "grid-cols": [{
                            "grid-cols": [P]
                        }],
                        "col-start-end": [{
                            col: ["auto", {
                                span: ["full", T, w]
                            }, w]
                        }],
                        "col-start": [{
                            "col-start": V()
                        }],
                        "col-end": [{
                            "col-end": V()
                        }],
                        "grid-rows": [{
                            "grid-rows": [P]
                        }],
                        "row-start-end": [{
                            row: ["auto", {
                                span: [T, w]
                            }, w]
                        }],
                        "row-start": [{
                            "row-start": V()
                        }],
                        "row-end": [{
                            "row-end": V()
                        }],
                        "grid-flow": [{
                            "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
                        }],
                        "auto-cols": [{
                            "auto-cols": ["auto", "min", "max", "fr", w]
                        }],
                        "auto-rows": [{
                            "auto-rows": ["auto", "min", "max", "fr", w]
                        }],
                        gap: [{
                            gap: [p]
                        }],
                        "gap-x": [{
                            "gap-x": [p]
                        }],
                        "gap-y": [{
                            "gap-y": [p]
                        }],
                        "justify-content": [{
                            justify: ["normal", ...K()]
                        }],
                        "justify-items": [{
                            "justify-items": ["start", "end", "center", "stretch"]
                        }],
                        "justify-self": [{
                            "justify-self": ["auto", "start", "end", "center", "stretch"]
                        }],
                        "align-content": [{
                            content: ["normal", ...K(), "baseline"]
                        }],
                        "align-items": [{
                            items: ["start", "end", "center", "baseline", "stretch"]
                        }],
                        "align-self": [{
                            self: ["auto", "start", "end", "center", "stretch", "baseline"]
                        }],
                        "place-content": [{
                            "place-content": [...K(), "baseline"]
                        }],
                        "place-items": [{
                            "place-items": ["start", "end", "center", "baseline", "stretch"]
                        }],
                        "place-self": [{
                            "place-self": ["auto", "start", "end", "center", "stretch"]
                        }],
                        p: [{
                            p: [I]
                        }],
                        px: [{
                            px: [I]
                        }],
                        py: [{
                            py: [I]
                        }],
                        ps: [{
                            ps: [I]
                        }],
                        pe: [{
                            pe: [I]
                        }],
                        pt: [{
                            pt: [I]
                        }],
                        pr: [{
                            pr: [I]
                        }],
                        pb: [{
                            pb: [I]
                        }],
                        pl: [{
                            pl: [I]
                        }],
                        m: [{
                            m: [O]
                        }],
                        mx: [{
                            mx: [O]
                        }],
                        my: [{
                            my: [O]
                        }],
                        ms: [{
                            ms: [O]
                        }],
                        me: [{
                            me: [O]
                        }],
                        mt: [{
                            mt: [O]
                        }],
                        mr: [{
                            mr: [O]
                        }],
                        mb: [{
                            mb: [O]
                        }],
                        ml: [{
                            ml: [O]
                        }],
                        "space-x": [{
                            "space-x": [M]
                        }],
                        "space-x-reverse": ["space-x-reverse"],
                        "space-y": [{
                            "space-y": [M]
                        }],
                        "space-y-reverse": ["space-y-reverse"],
                        w: [{
                            w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", w, t]
                        }],
                        "min-w": [{
                            "min-w": [w, t, "min", "max", "fit"]
                        }],
                        "max-w": [{
                            "max-w": [w, t, "none", "full", "min", "max", "fit", "prose", {
                                screen: [x]
                            }, x]
                        }],
                        h: [{
                            h: [w, t, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
                        }],
                        "min-h": [{
                            "min-h": [w, t, "min", "max", "fit", "svh", "lvh", "dvh"]
                        }],
                        "max-h": [{
                            "max-h": [w, t, "min", "max", "fit", "svh", "lvh", "dvh"]
                        }],
                        size: [{
                            size: [w, t, "auto", "min", "max", "fit"]
                        }],
                        "font-size": [{
                            text: ["base", x, v]
                        }],
                        "font-smoothing": ["antialiased", "subpixel-antialiased"],
                        "font-style": ["italic", "not-italic"],
                        "font-weight": [{
                            font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", y]
                        }],
                        "font-family": [{
                            font: [P]
                        }],
                        "fvn-normal": ["normal-nums"],
                        "fvn-ordinal": ["ordinal"],
                        "fvn-slashed-zero": ["slashed-zero"],
                        "fvn-figure": ["lining-nums", "oldstyle-nums"],
                        "fvn-spacing": ["proportional-nums", "tabular-nums"],
                        "fvn-fraction": ["diagonal-fractions", "stacked-fractons"],
                        tracking: [{
                            tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", w]
                        }],
                        "line-clamp": [{
                            "line-clamp": ["none", b, y]
                        }],
                        leading: [{
                            leading: ["none", "tight", "snug", "normal", "relaxed", "loose", g, w]
                        }],
                        "list-image": [{
                            "list-image": ["none", w]
                        }],
                        "list-style-type": [{
                            list: ["none", "disc", "decimal", w]
                        }],
                        "list-style-position": [{
                            list: ["inside", "outside"]
                        }],
                        "placeholder-color": [{
                            placeholder: [e]
                        }],
                        "placeholder-opacity": [{
                            "placeholder-opacity": [R]
                        }],
                        "text-alignment": [{
                            text: ["left", "center", "right", "justify", "start", "end"]
                        }],
                        "text-color": [{
                            text: [e]
                        }],
                        "text-opacity": [{
                            "text-opacity": [R]
                        }],
                        "text-decoration": ["underline", "overline", "line-through", "no-underline"],
                        "text-decoration-style": [{
                            decoration: [...Y(), "wavy"]
                        }],
                        "text-decoration-thickness": [{
                            decoration: ["auto", "from-font", g, v]
                        }],
                        "underline-offset": [{
                            "underline-offset": ["auto", g, w]
                        }],
                        "text-decoration-color": [{
                            decoration: [e]
                        }],
                        "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
                        "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
                        "text-wrap": [{
                            text: ["wrap", "nowrap", "balance", "pretty"]
                        }],
                        indent: [{
                            indent: z()
                        }],
                        "vertical-align": [{
                            align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", w]
                        }],
                        whitespace: [{
                            whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
                        }],
                        break: [{
                            break: ["normal", "words", "all", "keep"]
                        }],
                        hyphens: [{
                            hyphens: ["none", "manual", "auto"]
                        }],
                        content: [{
                            content: ["none", w]
                        }],
                        "bg-attachment": [{
                            bg: ["fixed", "local", "scroll"]
                        }],
                        "bg-clip": [{
                            "bg-clip": ["border", "padding", "content", "text"]
                        }],
                        "bg-opacity": [{
                            "bg-opacity": [R]
                        }],
                        "bg-origin": [{
                            "bg-origin": ["border", "padding", "content"]
                        }],
                        "bg-position": [{
                            bg: [...J(), C]
                        }],
                        "bg-repeat": [{
                            bg: ["no-repeat", {
                                repeat: ["", "x", "y", "round", "space"]
                            }]
                        }],
                        "bg-size": [{
                            bg: ["auto", "cover", "contain", S]
                        }],
                        "bg-image": [{
                            bg: ["none", {
                                "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
                            }, A]
                        }],
                        "bg-color": [{
                            bg: [e]
                        }],
                        "gradient-from-pos": [{
                            from: [h]
                        }],
                        "gradient-via-pos": [{
                            via: [h]
                        }],
                        "gradient-to-pos": [{
                            to: [h]
                        }],
                        "gradient-from": [{
                            from: [m]
                        }],
                        "gradient-via": [{
                            via: [m]
                        }],
                        "gradient-to": [{
                            to: [m]
                        }],
                        rounded: [{
                            rounded: [i]
                        }],
                        "rounded-s": [{
                            "rounded-s": [i]
                        }],
                        "rounded-e": [{
                            "rounded-e": [i]
                        }],
                        "rounded-t": [{
                            "rounded-t": [i]
                        }],
                        "rounded-r": [{
                            "rounded-r": [i]
                        }],
                        "rounded-b": [{
                            "rounded-b": [i]
                        }],
                        "rounded-l": [{
                            "rounded-l": [i]
                        }],
                        "rounded-ss": [{
                            "rounded-ss": [i]
                        }],
                        "rounded-se": [{
                            "rounded-se": [i]
                        }],
                        "rounded-ee": [{
                            "rounded-ee": [i]
                        }],
                        "rounded-es": [{
                            "rounded-es": [i]
                        }],
                        "rounded-tl": [{
                            "rounded-tl": [i]
                        }],
                        "rounded-tr": [{
                            "rounded-tr": [i]
                        }],
                        "rounded-br": [{
                            "rounded-br": [i]
                        }],
                        "rounded-bl": [{
                            "rounded-bl": [i]
                        }],
                        "border-w": [{
                            border: [c]
                        }],
                        "border-w-x": [{
                            "border-x": [c]
                        }],
                        "border-w-y": [{
                            "border-y": [c]
                        }],
                        "border-w-s": [{
                            "border-s": [c]
                        }],
                        "border-w-e": [{
                            "border-e": [c]
                        }],
                        "border-w-t": [{
                            "border-t": [c]
                        }],
                        "border-w-r": [{
                            "border-r": [c]
                        }],
                        "border-w-b": [{
                            "border-b": [c]
                        }],
                        "border-w-l": [{
                            "border-l": [c]
                        }],
                        "border-opacity": [{
                            "border-opacity": [R]
                        }],
                        "border-style": [{
                            border: [...Y(), "hidden"]
                        }],
                        "divide-x": [{
                            "divide-x": [c]
                        }],
                        "divide-x-reverse": ["divide-x-reverse"],
                        "divide-y": [{
                            "divide-y": [c]
                        }],
                        "divide-y-reverse": ["divide-y-reverse"],
                        "divide-opacity": [{
                            "divide-opacity": [R]
                        }],
                        "divide-style": [{
                            divide: Y()
                        }],
                        "border-color": [{
                            border: [o]
                        }],
                        "border-color-x": [{
                            "border-x": [o]
                        }],
                        "border-color-y": [{
                            "border-y": [o]
                        }],
                        "border-color-t": [{
                            "border-t": [o]
                        }],
                        "border-color-r": [{
                            "border-r": [o]
                        }],
                        "border-color-b": [{
                            "border-b": [o]
                        }],
                        "border-color-l": [{
                            "border-l": [o]
                        }],
                        "divide-color": [{
                            divide: [o]
                        }],
                        "outline-style": [{
                            outline: ["", ...Y()]
                        }],
                        "outline-offset": [{
                            "outline-offset": [g, w]
                        }],
                        "outline-w": [{
                            outline: [g, v]
                        }],
                        "outline-color": [{
                            outline: [e]
                        }],
                        "ring-w": [{
                            ring: B()
                        }],
                        "ring-w-inset": ["ring-inset"],
                        "ring-color": [{
                            ring: [e]
                        }],
                        "ring-opacity": [{
                            "ring-opacity": [R]
                        }],
                        "ring-offset-w": [{
                            "ring-offset": [g, v]
                        }],
                        "ring-offset-color": [{
                            "ring-offset": [e]
                        }],
                        shadow: [{
                            shadow: ["", "inner", "none", x, N]
                        }],
                        "shadow-color": [{
                            shadow: [P]
                        }],
                        opacity: [{
                            opacity: [R]
                        }],
                        "mix-blend": [{
                            "mix-blend": [...W(), "plus-lighter", "plus-darker"]
                        }],
                        "bg-blend": [{
                            "bg-blend": W()
                        }],
                        filter: [{
                            filter: ["", "none"]
                        }],
                        blur: [{
                            blur: [n]
                        }],
                        brightness: [{
                            brightness: [r]
                        }],
                        contrast: [{
                            contrast: [s]
                        }],
                        "drop-shadow": [{
                            "drop-shadow": ["", "none", x, w]
                        }],
                        grayscale: [{
                            grayscale: [a]
                        }],
                        "hue-rotate": [{
                            "hue-rotate": [f]
                        }],
                        invert: [{
                            invert: [d]
                        }],
                        saturate: [{
                            saturate: [L]
                        }],
                        sepia: [{
                            sepia: [k]
                        }],
                        "backdrop-filter": [{
                            "backdrop-filter": ["", "none"]
                        }],
                        "backdrop-blur": [{
                            "backdrop-blur": [n]
                        }],
                        "backdrop-brightness": [{
                            "backdrop-brightness": [r]
                        }],
                        "backdrop-contrast": [{
                            "backdrop-contrast": [s]
                        }],
                        "backdrop-grayscale": [{
                            "backdrop-grayscale": [a]
                        }],
                        "backdrop-hue-rotate": [{
                            "backdrop-hue-rotate": [f]
                        }],
                        "backdrop-invert": [{
                            "backdrop-invert": [d]
                        }],
                        "backdrop-opacity": [{
                            "backdrop-opacity": [R]
                        }],
                        "backdrop-saturate": [{
                            "backdrop-saturate": [L]
                        }],
                        "backdrop-sepia": [{
                            "backdrop-sepia": [k]
                        }],
                        "border-collapse": [{
                            border: ["collapse", "separate"]
                        }],
                        "border-spacing": [{
                            "border-spacing": [u]
                        }],
                        "border-spacing-x": [{
                            "border-spacing-x": [u]
                        }],
                        "border-spacing-y": [{
                            "border-spacing-y": [u]
                        }],
                        "table-layout": [{
                            table: ["auto", "fixed"]
                        }],
                        caption: [{
                            caption: ["top", "bottom"]
                        }],
                        transition: [{
                            transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", w]
                        }],
                        duration: [{
                            duration: $()
                        }],
                        ease: [{
                            ease: ["linear", "in", "out", "in-out", w]
                        }],
                        delay: [{
                            delay: $()
                        }],
                        animate: [{
                            animate: ["none", "spin", "ping", "pulse", "bounce", w]
                        }],
                        transform: [{
                            transform: ["", "gpu", "none"]
                        }],
                        scale: [{
                            scale: [j]
                        }],
                        "scale-x": [{
                            "scale-x": [j]
                        }],
                        "scale-y": [{
                            "scale-y": [j]
                        }],
                        rotate: [{
                            rotate: [T, w]
                        }],
                        "translate-x": [{
                            "translate-x": [U]
                        }],
                        "translate-y": [{
                            "translate-y": [U]
                        }],
                        "skew-x": [{
                            "skew-x": [D]
                        }],
                        "skew-y": [{
                            "skew-y": [D]
                        }],
                        "transform-origin": [{
                            origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", w]
                        }],
                        accent: [{
                            accent: ["auto", e]
                        }],
                        appearance: [{
                            appearance: ["none", "auto"]
                        }],
                        cursor: [{
                            cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", w]
                        }],
                        "caret-color": [{
                            caret: [e]
                        }],
                        "pointer-events": [{
                            "pointer-events": ["none", "auto"]
                        }],
                        resize: [{
                            resize: ["none", "y", "x", ""]
                        }],
                        "scroll-behavior": [{
                            scroll: ["auto", "smooth"]
                        }],
                        "scroll-m": [{
                            "scroll-m": z()
                        }],
                        "scroll-mx": [{
                            "scroll-mx": z()
                        }],
                        "scroll-my": [{
                            "scroll-my": z()
                        }],
                        "scroll-ms": [{
                            "scroll-ms": z()
                        }],
                        "scroll-me": [{
                            "scroll-me": z()
                        }],
                        "scroll-mt": [{
                            "scroll-mt": z()
                        }],
                        "scroll-mr": [{
                            "scroll-mr": z()
                        }],
                        "scroll-mb": [{
                            "scroll-mb": z()
                        }],
                        "scroll-ml": [{
                            "scroll-ml": z()
                        }],
                        "scroll-p": [{
                            "scroll-p": z()
                        }],
                        "scroll-px": [{
                            "scroll-px": z()
                        }],
                        "scroll-py": [{
                            "scroll-py": z()
                        }],
                        "scroll-ps": [{
                            "scroll-ps": z()
                        }],
                        "scroll-pe": [{
                            "scroll-pe": z()
                        }],
                        "scroll-pt": [{
                            "scroll-pt": z()
                        }],
                        "scroll-pr": [{
                            "scroll-pr": z()
                        }],
                        "scroll-pb": [{
                            "scroll-pb": z()
                        }],
                        "scroll-pl": [{
                            "scroll-pl": z()
                        }],
                        "snap-align": [{
                            snap: ["start", "end", "center", "align-none"]
                        }],
                        "snap-stop": [{
                            snap: ["normal", "always"]
                        }],
                        "snap-type": [{
                            snap: ["none", "x", "y", "both"]
                        }],
                        "snap-strictness": [{
                            snap: ["mandatory", "proximity"]
                        }],
                        touch: [{
                            touch: ["auto", "none", "manipulation"]
                        }],
                        "touch-x": [{
                            "touch-pan": ["x", "left", "right"]
                        }],
                        "touch-y": [{
                            "touch-pan": ["y", "up", "down"]
                        }],
                        "touch-pz": ["touch-pinch-zoom"],
                        select: [{
                            select: ["none", "text", "all", "auto"]
                        }],
                        "will-change": [{
                            "will-change": ["auto", "scroll", "contents", "transform", w]
                        }],
                        fill: [{
                            fill: [e, "none"]
                        }],
                        "stroke-w": [{
                            stroke: [g, v, y]
                        }],
                        stroke: [{
                            stroke: [e, "none"]
                        }],
                        sr: ["sr-only", "not-sr-only"],
                        "forced-color-adjust": [{
                            "forced-color-adjust": ["auto", "none"]
                        }]
                    },
                    conflictingClassGroups: {
                        overflow: ["overflow-x", "overflow-y"],
                        overscroll: ["overscroll-x", "overscroll-y"],
                        inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
                        "inset-x": ["right", "left"],
                        "inset-y": ["top", "bottom"],
                        flex: ["basis", "grow", "shrink"],
                        gap: ["gap-x", "gap-y"],
                        p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
                        px: ["pr", "pl"],
                        py: ["pt", "pb"],
                        m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
                        mx: ["mr", "ml"],
                        my: ["mt", "mb"],
                        size: ["w", "h"],
                        "font-size": ["leading"],
                        "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
                        "fvn-ordinal": ["fvn-normal"],
                        "fvn-slashed-zero": ["fvn-normal"],
                        "fvn-figure": ["fvn-normal"],
                        "fvn-spacing": ["fvn-normal"],
                        "fvn-fraction": ["fvn-normal"],
                        "line-clamp": ["display", "overflow"],
                        rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
                        "rounded-s": ["rounded-ss", "rounded-es"],
                        "rounded-e": ["rounded-se", "rounded-ee"],
                        "rounded-t": ["rounded-tl", "rounded-tr"],
                        "rounded-r": ["rounded-tr", "rounded-br"],
                        "rounded-b": ["rounded-br", "rounded-bl"],
                        "rounded-l": ["rounded-tl", "rounded-bl"],
                        "border-spacing": ["border-spacing-x", "border-spacing-y"],
                        "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
                        "border-w-x": ["border-w-r", "border-w-l"],
                        "border-w-y": ["border-w-t", "border-w-b"],
                        "border-color": ["border-color-t", "border-color-r", "border-color-b", "border-color-l"],
                        "border-color-x": ["border-color-r", "border-color-l"],
                        "border-color-y": ["border-color-t", "border-color-b"],
                        "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
                        "scroll-mx": ["scroll-mr", "scroll-ml"],
                        "scroll-my": ["scroll-mt", "scroll-mb"],
                        "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
                        "scroll-px": ["scroll-pr", "scroll-pl"],
                        "scroll-py": ["scroll-pt", "scroll-pb"],
                        touch: ["touch-x", "touch-y", "touch-pz"],
                        "touch-x": ["touch"],
                        "touch-y": ["touch"],
                        "touch-pz": ["touch"]
                    },
                    conflictingClassGroupModifiers: {
                        "font-size": ["leading"]
                    }
                }
            });

            function U() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return M((0, r.W)(t))
            }
        },
        92569: function(e, t, n) {
            "use strict";

            function r() {
                return !0
            }
            n.d(t, {
                G6: function() {
                    return c
                },
                jU: function() {
                    return r
                },
                un: function() {
                    return l
                },
                vU: function() {
                    return s
                }
            });
            let o = /^((?!chrome|android).)*safari/i,
                i = /edge?/i,
                u = /firefox/i;

            function c() {
                return o.test(navigator.userAgent)
            }

            function l() {
                return i.test(navigator.userAgent)
            }

            function s() {
                return u.test(navigator.userAgent)
            }
        },
        48529: function(e, t, n) {
            "use strict";
            n.d(t, {
                L: function() {
                    return o
                }
            });
            var r = n(67294);
            let o = (0, n(92569).jU)() ? r.useLayoutEffect : r.useEffect
        },
        60832: function() {},
        92808: function() {},
        17232: function() {},
        7854: function(e) {
            e.exports = {
                style: {
                    fontFamily: "'__Fira_Mono_8f0e11', '__Fira_Mono_Fallback_8f0e11'",
                    fontStyle: "normal"
                },
                className: "__className_8f0e11",
                variable: "__variable_8f0e11"
            }
        },
        84070: function(e) {
            e.exports = {
                style: {
                    fontFamily: "'__suisse_a96a80', '__suisse_Fallback_a96a80'"
                },
                className: "__className_a96a80",
                variable: "__variable_a96a80"
            }
        },
        5360: function(e) {
            e.exports = {
                style: {
                    fontFamily: "'__inter_11d45e', '__inter_Fallback_11d45e'"
                },
                className: "__className_11d45e",
                variable: "__variable_11d45e"
            }
        },
        64795: function(e) {
            e.exports = {
                bar: "Spinner_bar__30T0c",
                spin: "Spinner_spin__CmdAF"
            }
        },
        40421: function(e) {
            e.exports = {
                toast: "Toast_toast__0g7mz",
                slideIn: "Toast_slideIn__JD4gB",
                hide: "Toast_hide__PDveB",
                swipeOut: "Toast_swipeOut__62nHY"
            }
        },
        77663: function(e) {
            ! function() {
                var t = {
                        229: function(e) {
                            var t, n, r, o = e.exports = {};

                            function i() {
                                throw Error("setTimeout has not been defined")
                            }

                            function u() {
                                throw Error("clearTimeout has not been defined")
                            }

                            function c(e) {
                                if (t === setTimeout) return setTimeout(e, 0);
                                if ((t === i || !t) && setTimeout) return t = setTimeout, setTimeout(e, 0);
                                try {
                                    return t(e, 0)
                                } catch (n) {
                                    try {
                                        return t.call(null, e, 0)
                                    } catch (n) {
                                        return t.call(this, e, 0)
                                    }
                                }
                            }! function() {
                                try {
                                    t = "function" == typeof setTimeout ? setTimeout : i
                                } catch (e) {
                                    t = i
                                }
                                try {
                                    n = "function" == typeof clearTimeout ? clearTimeout : u
                                } catch (e) {
                                    n = u
                                }
                            }();
                            var l = [],
                                s = !1,
                                a = -1;

                            function f() {
                                s && r && (s = !1, r.length ? l = r.concat(l) : a = -1, l.length && d())
                            }

                            function d() {
                                if (!s) {
                                    var e = c(f);
                                    s = !0;
                                    for (var t = l.length; t;) {
                                        for (r = l, l = []; ++a < t;) r && r[a].run();
                                        a = -1, t = l.length
                                    }
                                    r = null, s = !1,
                                        function(e) {
                                            if (n === clearTimeout) return clearTimeout(e);
                                            if ((n === u || !n) && clearTimeout) return n = clearTimeout, clearTimeout(e);
                                            try {
                                                n(e)
                                            } catch (t) {
                                                try {
                                                    return n.call(null, e)
                                                } catch (t) {
                                                    return n.call(this, e)
                                                }
                                            }
                                        }(e)
                                }
                            }

                            function p(e, t) {
                                this.fun = e, this.array = t
                            }

                            function m() {}
                            o.nextTick = function(e) {
                                var t = Array(arguments.length - 1);
                                if (arguments.length > 1)
                                    for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                                l.push(new p(e, t)), 1 !== l.length || s || c(d)
                            }, p.prototype.run = function() {
                                this.fun.apply(null, this.array)
                            }, o.title = "browser", o.browser = !0, o.env = {}, o.argv = [], o.version = "", o.versions = {}, o.on = m, o.addListener = m, o.once = m, o.off = m, o.removeListener = m, o.removeAllListeners = m, o.emit = m, o.prependListener = m, o.prependOnceListener = m, o.listeners = function(e) {
                                return []
                            }, o.binding = function(e) {
                                throw Error("process.binding is not supported")
                            }, o.cwd = function() {
                                return "/"
                            }, o.chdir = function(e) {
                                throw Error("process.chdir is not supported")
                            }, o.umask = function() {
                                return 0
                            }
                        }
                    },
                    n = {};

                function r(e) {
                    var o = n[e];
                    if (void 0 !== o) return o.exports;
                    var i = n[e] = {
                            exports: {}
                        },
                        u = !0;
                    try {
                        t[e](i, i.exports, r), u = !1
                    } finally {
                        u && delete n[e]
                    }
                    return i.exports
                }
                r.ab = "//";
                var o = r(229);
                e.exports = o
            }()
        },
        5152: function(e, t, n) {
            e.exports = n(19606)
        },
        9008: function(e, t, n) {
            e.exports = n(37219)
        },
        4298: function(e, t, n) {
            e.exports = n(90069)
        },
        93967: function(e, t) {
            var n;
            ! function() {
                "use strict";
                var r = {}.hasOwnProperty;

                function o() {
                    for (var e = "", t = 0; t < arguments.length; t++) {
                        var n = arguments[t];
                        n && (e = i(e, function(e) {
                            if ("string" == typeof e || "number" == typeof e) return e;
                            if ("object" != typeof e) return "";
                            if (Array.isArray(e)) return o.apply(null, e);
                            if (e.toString !== Object.prototype.toString && !e.toString.toString().includes("[native code]")) return e.toString();
                            var t = "";
                            for (var n in e) r.call(e, n) && e[n] && (t = i(t, n));
                            return t
                        }(n)))
                    }
                    return e
                }

                function i(e, t) {
                    return t ? e ? e + " " + t : e + t : e
                }
                e.exports ? (o.default = o, e.exports = o) : void 0 !== (n = (function() {
                    return o
                }).apply(t, [])) && (e.exports = n)
            }()
        },
        87462: function(e, t, n) {
            "use strict";

            function r() {
                return (r = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            n.d(t, {
                Z: function() {
                    return r
                }
            })
        },
        85983: function(e, t, n) {
            "use strict";
            n.d(t, {
                Cp: function() {
                    return f
                },
                RR: function() {
                    return l
                },
                cv: function() {
                    return p
                },
                dp: function() {
                    return E
                },
                dr: function() {
                    return h
                },
                oo: function() {
                    return i
                },
                uY: function() {
                    return m
                },
                x7: function() {
                    return c
                }
            });
            var r = n(71347);

            function o(e, t, n) {
                let o, {
                        reference: i,
                        floating: u
                    } = e,
                    c = (0, r.Qq)(t),
                    l = (0, r.Wh)(t),
                    s = (0, r.I4)(l),
                    a = (0, r.k3)(t),
                    f = "y" === c,
                    d = i.x + i.width / 2 - u.width / 2,
                    p = i.y + i.height / 2 - u.height / 2,
                    m = i[s] / 2 - u[s] / 2;
                switch (a) {
                    case "top":
                        o = {
                            x: d,
                            y: i.y - u.height
                        };
                        break;
                    case "bottom":
                        o = {
                            x: d,
                            y: i.y + i.height
                        };
                        break;
                    case "right":
                        o = {
                            x: i.x + i.width,
                            y: p
                        };
                        break;
                    case "left":
                        o = {
                            x: i.x - u.width,
                            y: p
                        };
                        break;
                    default:
                        o = {
                            x: i.x,
                            y: i.y
                        }
                }
                switch ((0, r.hp)(t)) {
                    case "start":
                        o[l] -= m * (n && f ? -1 : 1);
                        break;
                    case "end":
                        o[l] += m * (n && f ? -1 : 1)
                }
                return o
            }
            let i = async (e, t, n) => {
                let {
                    placement: r = "bottom",
                    strategy: i = "absolute",
                    middleware: u = [],
                    platform: c
                } = n, l = u.filter(Boolean), s = await (null == c.isRTL ? void 0 : c.isRTL(t)), a = await c.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: i
                }), {
                    x: f,
                    y: d
                } = o(a, r, s), p = r, m = {}, h = 0;
                for (let n = 0; n < l.length; n++) {
                    let {
                        name: u,
                        fn: E
                    } = l[n], {
                        x: g,
                        y: v,
                        data: b,
                        reset: y
                    } = await E({
                        x: f,
                        y: d,
                        initialPlacement: r,
                        placement: p,
                        strategy: i,
                        middlewareData: m,
                        rects: a,
                        platform: c,
                        elements: {
                            reference: e,
                            floating: t
                        }
                    });
                    if (f = null != g ? g : f, d = null != v ? v : d, m = { ...m,
                            [u]: { ...m[u],
                                ...b
                            }
                        }, y && h <= 50) {
                        h++, "object" == typeof y && (y.placement && (p = y.placement), y.rects && (a = !0 === y.rects ? await c.getElementRects({
                            reference: e,
                            floating: t,
                            strategy: i
                        }) : y.rects), {
                            x: f,
                            y: d
                        } = o(a, p, s)), n = -1;
                        continue
                    }
                }
                return {
                    x: f,
                    y: d,
                    placement: p,
                    strategy: i,
                    middlewareData: m
                }
            };
            async function u(e, t) {
                var n;
                void 0 === t && (t = {});
                let {
                    x: o,
                    y: i,
                    platform: u,
                    rects: c,
                    elements: l,
                    strategy: s
                } = e, {
                    boundary: a = "clippingAncestors",
                    rootBoundary: f = "viewport",
                    elementContext: d = "floating",
                    altBoundary: p = !1,
                    padding: m = 0
                } = (0, r.ku)(t, e), h = (0, r.yd)(m), E = l[p ? "floating" === d ? "reference" : "floating" : d], g = (0, r.JB)(await u.getClippingRect({
                    element: null == (n = await (null == u.isElement ? void 0 : u.isElement(E))) || n ? E : E.contextElement || await (null == u.getDocumentElement ? void 0 : u.getDocumentElement(l.floating)),
                    boundary: a,
                    rootBoundary: f,
                    strategy: s
                })), v = "floating" === d ? { ...c.floating,
                    x: o,
                    y: i
                } : c.reference, b = await (null == u.getOffsetParent ? void 0 : u.getOffsetParent(l.floating)), y = await (null == u.isElement ? void 0 : u.isElement(b)) && await (null == u.getScale ? void 0 : u.getScale(b)) || {
                    x: 1,
                    y: 1
                }, T = (0, r.JB)(u.convertOffsetParentRelativeRectToViewportRelativeRect ? await u.convertOffsetParentRelativeRectToViewportRelativeRect({
                    rect: v,
                    offsetParent: b,
                    strategy: s
                }) : v);
                return {
                    top: (g.top - T.top + h.top) / y.y,
                    bottom: (T.bottom - g.bottom + h.bottom) / y.y,
                    left: (g.left - T.left + h.left) / y.x,
                    right: (T.right - g.right + h.right) / y.x
                }
            }
            let c = e => ({
                    name: "arrow",
                    options: e,
                    async fn(t) {
                        let {
                            x: n,
                            y: o,
                            placement: i,
                            rects: u,
                            platform: c,
                            elements: l,
                            middlewareData: s
                        } = t, {
                            element: a,
                            padding: f = 0
                        } = (0, r.ku)(e, t) || {};
                        if (null == a) return {};
                        let d = (0, r.yd)(f),
                            p = {
                                x: n,
                                y: o
                            },
                            m = (0, r.Wh)(i),
                            h = (0, r.I4)(m),
                            E = await c.getDimensions(a),
                            g = "y" === m,
                            v = g ? "clientHeight" : "clientWidth",
                            b = u.reference[h] + u.reference[m] - p[m] - u.floating[h],
                            y = p[m] - u.reference[m],
                            T = await (null == c.getOffsetParent ? void 0 : c.getOffsetParent(a)),
                            _ = T ? T[v] : 0;
                        _ && await (null == c.isElement ? void 0 : c.isElement(T)) || (_ = l.floating[v] || u.floating[h]);
                        let w = _ / 2 - E[h] / 2 - 1,
                            x = (0, r.VV)(d[g ? "top" : "left"], w),
                            O = (0, r.VV)(d[g ? "bottom" : "right"], w),
                            S = _ - E[h] - O,
                            C = _ / 2 - E[h] / 2 + (b / 2 - y / 2),
                            R = (0, r.uZ)(x, C, S),
                            A = !s.arrow && null != (0, r.hp)(i) && C != R && u.reference[h] / 2 - (C < x ? x : O) - E[h] / 2 < 0,
                            N = A ? C < x ? C - x : C - S : 0;
                        return {
                            [m]: p[m] + N,
                            data: {
                                [m]: R,
                                centerOffset: C - R - N,
                                ...A && {
                                    alignmentOffset: N
                                }
                            },
                            reset: A
                        }
                    }
                }),
                l = function(e) {
                    return void 0 === e && (e = {}), {
                        name: "flip",
                        options: e,
                        async fn(t) {
                            var n, o, i, c, l;
                            let {
                                placement: s,
                                middlewareData: a,
                                rects: f,
                                initialPlacement: d,
                                platform: p,
                                elements: m
                            } = t, {
                                mainAxis: h = !0,
                                crossAxis: E = !0,
                                fallbackPlacements: g,
                                fallbackStrategy: v = "bestFit",
                                fallbackAxisSideDirection: b = "none",
                                flipAlignment: y = !0,
                                ...T
                            } = (0, r.ku)(e, t);
                            if (null != (n = a.arrow) && n.alignmentOffset) return {};
                            let _ = (0, r.k3)(s),
                                w = (0, r.k3)(d) === d,
                                x = await (null == p.isRTL ? void 0 : p.isRTL(m.floating)),
                                O = g || (w || !y ? [(0, r.pw)(d)] : (0, r.gy)(d));
                            g || "none" === b || O.push(...(0, r.KX)(d, y, b, x));
                            let S = [d, ...O],
                                C = await u(t, T),
                                R = [],
                                A = (null == (o = a.flip) ? void 0 : o.overflows) || [];
                            if (h && R.push(C[_]), E) {
                                let e = (0, r.i8)(s, f, x);
                                R.push(C[e[0]], C[e[1]])
                            }
                            if (A = [...A, {
                                    placement: s,
                                    overflows: R
                                }], !R.every(e => e <= 0)) {
                                let e = ((null == (i = a.flip) ? void 0 : i.index) || 0) + 1,
                                    t = S[e];
                                if (t) return {
                                    data: {
                                        index: e,
                                        overflows: A
                                    },
                                    reset: {
                                        placement: t
                                    }
                                };
                                let n = null == (c = A.filter(e => e.overflows[0] <= 0).sort((e, t) => e.overflows[1] - t.overflows[1])[0]) ? void 0 : c.placement;
                                if (!n) switch (v) {
                                    case "bestFit":
                                        {
                                            let e = null == (l = A.map(e => [e.placement, e.overflows.filter(e => e > 0).reduce((e, t) => e + t, 0)]).sort((e, t) => e[1] - t[1])[0]) ? void 0 : l[0];e && (n = e);
                                            break
                                        }
                                    case "initialPlacement":
                                        n = d
                                }
                                if (s !== n) return {
                                    reset: {
                                        placement: n
                                    }
                                }
                            }
                            return {}
                        }
                    }
                };

            function s(e, t) {
                return {
                    top: e.top - t.height,
                    right: e.right - t.width,
                    bottom: e.bottom - t.height,
                    left: e.left - t.width
                }
            }

            function a(e) {
                return r.mA.some(t => e[t] >= 0)
            }
            let f = function(e) {
                return void 0 === e && (e = {}), {
                    name: "hide",
                    options: e,
                    async fn(t) {
                        let {
                            rects: n
                        } = t, {
                            strategy: o = "referenceHidden",
                            ...i
                        } = (0, r.ku)(e, t);
                        switch (o) {
                            case "referenceHidden":
                                {
                                    let e = s(await u(t, { ...i,
                                        elementContext: "reference"
                                    }), n.reference);
                                    return {
                                        data: {
                                            referenceHiddenOffsets: e,
                                            referenceHidden: a(e)
                                        }
                                    }
                                }
                            case "escaped":
                                {
                                    let e = s(await u(t, { ...i,
                                        altBoundary: !0
                                    }), n.floating);
                                    return {
                                        data: {
                                            escapedOffsets: e,
                                            escaped: a(e)
                                        }
                                    }
                                }
                            default:
                                return {}
                        }
                    }
                }
            };
            async function d(e, t) {
                let {
                    placement: n,
                    platform: o,
                    elements: i
                } = e, u = await (null == o.isRTL ? void 0 : o.isRTL(i.floating)), c = (0, r.k3)(n), l = (0, r.hp)(n), s = "y" === (0, r.Qq)(n), a = ["left", "top"].includes(c) ? -1 : 1, f = u && s ? -1 : 1, d = (0, r.ku)(t, e), {
                    mainAxis: p,
                    crossAxis: m,
                    alignmentAxis: h
                } = "number" == typeof d ? {
                    mainAxis: d,
                    crossAxis: 0,
                    alignmentAxis: null
                } : {
                    mainAxis: 0,
                    crossAxis: 0,
                    alignmentAxis: null,
                    ...d
                };
                return l && "number" == typeof h && (m = "end" === l ? -1 * h : h), s ? {
                    x: m * f,
                    y: p * a
                } : {
                    x: p * a,
                    y: m * f
                }
            }
            let p = function(e) {
                    return void 0 === e && (e = 0), {
                        name: "offset",
                        options: e,
                        async fn(t) {
                            var n, r;
                            let {
                                x: o,
                                y: i,
                                placement: u,
                                middlewareData: c
                            } = t, l = await d(t, e);
                            return u === (null == (n = c.offset) ? void 0 : n.placement) && null != (r = c.arrow) && r.alignmentOffset ? {} : {
                                x: o + l.x,
                                y: i + l.y,
                                data: { ...l,
                                    placement: u
                                }
                            }
                        }
                    }
                },
                m = function(e) {
                    return void 0 === e && (e = {}), {
                        name: "shift",
                        options: e,
                        async fn(t) {
                            let {
                                x: n,
                                y: o,
                                placement: i
                            } = t, {
                                mainAxis: c = !0,
                                crossAxis: l = !1,
                                limiter: s = {
                                    fn: e => {
                                        let {
                                            x: t,
                                            y: n
                                        } = e;
                                        return {
                                            x: t,
                                            y: n
                                        }
                                    }
                                },
                                ...a
                            } = (0, r.ku)(e, t), f = {
                                x: n,
                                y: o
                            }, d = await u(t, a), p = (0, r.Qq)((0, r.k3)(i)), m = (0, r.Rn)(p), h = f[m], E = f[p];
                            if (c) {
                                let e = "y" === m ? "top" : "left",
                                    t = "y" === m ? "bottom" : "right",
                                    n = h + d[e],
                                    o = h - d[t];
                                h = (0, r.uZ)(n, h, o)
                            }
                            if (l) {
                                let e = "y" === p ? "top" : "left",
                                    t = "y" === p ? "bottom" : "right",
                                    n = E + d[e],
                                    o = E - d[t];
                                E = (0, r.uZ)(n, E, o)
                            }
                            let g = s.fn({ ...t,
                                [m]: h,
                                [p]: E
                            });
                            return { ...g,
                                data: {
                                    x: g.x - n,
                                    y: g.y - o
                                }
                            }
                        }
                    }
                },
                h = function(e) {
                    return void 0 === e && (e = {}), {
                        options: e,
                        fn(t) {
                            let {
                                x: n,
                                y: o,
                                placement: i,
                                rects: u,
                                middlewareData: c
                            } = t, {
                                offset: l = 0,
                                mainAxis: s = !0,
                                crossAxis: a = !0
                            } = (0, r.ku)(e, t), f = {
                                x: n,
                                y: o
                            }, d = (0, r.Qq)(i), p = (0, r.Rn)(d), m = f[p], h = f[d], E = (0, r.ku)(l, t), g = "number" == typeof E ? {
                                mainAxis: E,
                                crossAxis: 0
                            } : {
                                mainAxis: 0,
                                crossAxis: 0,
                                ...E
                            };
                            if (s) {
                                let e = "y" === p ? "height" : "width",
                                    t = u.reference[p] - u.floating[e] + g.mainAxis,
                                    n = u.reference[p] + u.reference[e] - g.mainAxis;
                                m < t ? m = t : m > n && (m = n)
                            }
                            if (a) {
                                var v, b;
                                let e = "y" === p ? "width" : "height",
                                    t = ["top", "left"].includes((0, r.k3)(i)),
                                    n = u.reference[d] - u.floating[e] + (t && (null == (v = c.offset) ? void 0 : v[d]) || 0) + (t ? 0 : g.crossAxis),
                                    o = u.reference[d] + u.reference[e] + (t ? 0 : (null == (b = c.offset) ? void 0 : b[d]) || 0) - (t ? g.crossAxis : 0);
                                h < n ? h = n : h > o && (h = o)
                            }
                            return {
                                [p]: m,
                                [d]: h
                            }
                        }
                    }
                },
                E = function(e) {
                    return void 0 === e && (e = {}), {
                        name: "size",
                        options: e,
                        async fn(t) {
                            let n, o;
                            let {
                                placement: i,
                                rects: c,
                                platform: l,
                                elements: s
                            } = t, {
                                apply: a = () => {},
                                ...f
                            } = (0, r.ku)(e, t), d = await u(t, f), p = (0, r.k3)(i), m = (0, r.hp)(i), h = "y" === (0, r.Qq)(i), {
                                width: E,
                                height: g
                            } = c.floating;
                            "top" === p || "bottom" === p ? (n = p, o = m === (await (null == l.isRTL ? void 0 : l.isRTL(s.floating)) ? "start" : "end") ? "left" : "right") : (o = p, n = "end" === m ? "top" : "bottom");
                            let v = g - d[n],
                                b = E - d[o],
                                y = !t.middlewareData.shift,
                                T = v,
                                _ = b;
                            if (h) {
                                let e = E - d.left - d.right;
                                _ = m || y ? (0, r.VV)(b, e) : e
                            } else {
                                let e = g - d.top - d.bottom;
                                T = m || y ? (0, r.VV)(v, e) : e
                            }
                            if (y && !m) {
                                let e = (0, r.Fp)(d.left, 0),
                                    t = (0, r.Fp)(d.right, 0),
                                    n = (0, r.Fp)(d.top, 0),
                                    o = (0, r.Fp)(d.bottom, 0);
                                h ? _ = E - 2 * (0 !== e || 0 !== t ? e + t : (0, r.Fp)(d.left, d.right)) : T = g - 2 * (0 !== n || 0 !== o ? n + o : (0, r.Fp)(d.top, d.bottom))
                            }
                            await a({ ...t,
                                availableWidth: _,
                                availableHeight: T
                            });
                            let w = await l.getDimensions(s.floating);
                            return E !== w.width || g !== w.height ? {
                                reset: {
                                    rects: !0
                                }
                            } : {}
                        }
                    }
                }
        },
        63853: function(e, t, n) {
            "use strict";
            n.d(t, {
                Me: function() {
                    return I
                },
                oo: function() {
                    return L
                }
            });
            var r = n(71347),
                o = n(85983);

            function i(e) {
                return l(e) ? (e.nodeName || "").toLowerCase() : "#document"
            }

            function u(e) {
                var t;
                return (null == e ? void 0 : null == (t = e.ownerDocument) ? void 0 : t.defaultView) || window
            }

            function c(e) {
                var t;
                return null == (t = (l(e) ? e.ownerDocument : e.document) || window.document) ? void 0 : t.documentElement
            }

            function l(e) {
                return e instanceof Node || e instanceof u(e).Node
            }

            function s(e) {
                return e instanceof Element || e instanceof u(e).Element
            }

            function a(e) {
                return e instanceof HTMLElement || e instanceof u(e).HTMLElement
            }

            function f(e) {
                return "undefined" != typeof ShadowRoot && (e instanceof ShadowRoot || e instanceof u(e).ShadowRoot)
            }

            function d(e) {
                let {
                    overflow: t,
                    overflowX: n,
                    overflowY: r,
                    display: o
                } = E(e);
                return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && !["inline", "contents"].includes(o)
            }

            function p(e) {
                let t = m(),
                    n = E(e);
                return "none" !== n.transform || "none" !== n.perspective || !!n.containerType && "normal" !== n.containerType || !t && !!n.backdropFilter && "none" !== n.backdropFilter || !t && !!n.filter && "none" !== n.filter || ["transform", "perspective", "filter"].some(e => (n.willChange || "").includes(e)) || ["paint", "layout", "strict", "content"].some(e => (n.contain || "").includes(e))
            }

            function m() {
                return "undefined" != typeof CSS && !!CSS.supports && CSS.supports("-webkit-backdrop-filter", "none")
            }

            function h(e) {
                return ["html", "body", "#document"].includes(i(e))
            }

            function E(e) {
                return u(e).getComputedStyle(e)
            }

            function g(e) {
                return s(e) ? {
                    scrollLeft: e.scrollLeft,
                    scrollTop: e.scrollTop
                } : {
                    scrollLeft: e.pageXOffset,
                    scrollTop: e.pageYOffset
                }
            }

            function v(e) {
                if ("html" === i(e)) return e;
                let t = e.assignedSlot || e.parentNode || f(e) && e.host || c(e);
                return f(t) ? t.host : t
            }

            function b(e, t, n) {
                var r;
                void 0 === t && (t = []), void 0 === n && (n = !0);
                let o = function e(t) {
                        let n = v(t);
                        return h(n) ? t.ownerDocument ? t.ownerDocument.body : t.body : a(n) && d(n) ? n : e(n)
                    }(e),
                    i = o === (null == (r = e.ownerDocument) ? void 0 : r.body),
                    c = u(o);
                return i ? t.concat(c, c.visualViewport || [], d(o) ? o : [], c.frameElement && n ? b(c.frameElement) : []) : t.concat(o, b(o, [], n))
            }

            function y(e) {
                let t = E(e),
                    n = parseFloat(t.width) || 0,
                    o = parseFloat(t.height) || 0,
                    i = a(e),
                    u = i ? e.offsetWidth : n,
                    c = i ? e.offsetHeight : o,
                    l = (0, r.NM)(n) !== u || (0, r.NM)(o) !== c;
                return l && (n = u, o = c), {
                    width: n,
                    height: o,
                    $: l
                }
            }

            function T(e) {
                return s(e) ? e : e.contextElement
            }

            function _(e) {
                let t = T(e);
                if (!a(t)) return (0, r.ze)(1);
                let n = t.getBoundingClientRect(),
                    {
                        width: o,
                        height: i,
                        $: u
                    } = y(t),
                    c = (u ? (0, r.NM)(n.width) : n.width) / o,
                    l = (u ? (0, r.NM)(n.height) : n.height) / i;
                return c && Number.isFinite(c) || (c = 1), l && Number.isFinite(l) || (l = 1), {
                    x: c,
                    y: l
                }
            }
            let w = (0, r.ze)(0);

            function x(e) {
                let t = u(e);
                return m() && t.visualViewport ? {
                    x: t.visualViewport.offsetLeft,
                    y: t.visualViewport.offsetTop
                } : w
            }

            function O(e, t, n, o) {
                var i;
                void 0 === t && (t = !1), void 0 === n && (n = !1);
                let c = e.getBoundingClientRect(),
                    l = T(e),
                    a = (0, r.ze)(1);
                t && (o ? s(o) && (a = _(o)) : a = _(e));
                let f = (void 0 === (i = n) && (i = !1), o && (!i || o === u(l)) && i) ? x(l) : (0, r.ze)(0),
                    d = (c.left + f.x) / a.x,
                    p = (c.top + f.y) / a.y,
                    m = c.width / a.x,
                    h = c.height / a.y;
                if (l) {
                    let e = u(l),
                        t = o && s(o) ? u(o) : o,
                        n = e.frameElement;
                    for (; n && o && t !== e;) {
                        let e = _(n),
                            t = n.getBoundingClientRect(),
                            r = E(n),
                            o = t.left + (n.clientLeft + parseFloat(r.paddingLeft)) * e.x,
                            i = t.top + (n.clientTop + parseFloat(r.paddingTop)) * e.y;
                        d *= e.x, p *= e.y, m *= e.x, h *= e.y, d += o, p += i, n = u(n).frameElement
                    }
                }
                return (0, r.JB)({
                    width: m,
                    height: h,
                    x: d,
                    y: p
                })
            }

            function S(e) {
                return O(c(e)).left + g(e).scrollLeft
            }

            function C(e, t, n) {
                let o;
                if ("viewport" === t) o = function(e, t) {
                    let n = u(e),
                        r = c(e),
                        o = n.visualViewport,
                        i = r.clientWidth,
                        l = r.clientHeight,
                        s = 0,
                        a = 0;
                    if (o) {
                        i = o.width, l = o.height;
                        let e = m();
                        (!e || e && "fixed" === t) && (s = o.offsetLeft, a = o.offsetTop)
                    }
                    return {
                        width: i,
                        height: l,
                        x: s,
                        y: a
                    }
                }(e, n);
                else if ("document" === t) o = function(e) {
                    let t = c(e),
                        n = g(e),
                        o = e.ownerDocument.body,
                        i = (0, r.Fp)(t.scrollWidth, t.clientWidth, o.scrollWidth, o.clientWidth),
                        u = (0, r.Fp)(t.scrollHeight, t.clientHeight, o.scrollHeight, o.clientHeight),
                        l = -n.scrollLeft + S(e),
                        s = -n.scrollTop;
                    return "rtl" === E(o).direction && (l += (0, r.Fp)(t.clientWidth, o.clientWidth) - i), {
                        width: i,
                        height: u,
                        x: l,
                        y: s
                    }
                }(c(e));
                else if (s(t)) o = function(e, t) {
                    let n = O(e, !0, "fixed" === t),
                        o = n.top + e.clientTop,
                        i = n.left + e.clientLeft,
                        u = a(e) ? _(e) : (0, r.ze)(1),
                        c = e.clientWidth * u.x;
                    return {
                        width: c,
                        height: e.clientHeight * u.y,
                        x: i * u.x,
                        y: o * u.y
                    }
                }(t, n);
                else {
                    let n = x(e);
                    o = { ...t,
                        x: t.x - n.x,
                        y: t.y - n.y
                    }
                }
                return (0, r.JB)(o)
            }

            function R(e, t) {
                return a(e) && "fixed" !== E(e).position ? t ? t(e) : e.offsetParent : null
            }

            function A(e, t) {
                let n = u(e);
                if (!a(e)) return n;
                let r = R(e, t);
                for (; r && ["table", "td", "th"].includes(i(r)) && "static" === E(r).position;) r = R(r, t);
                return r && ("html" === i(r) || "body" === i(r) && "static" === E(r).position && !p(r)) ? n : r || function(e) {
                    let t = v(e);
                    for (; a(t) && !h(t);) {
                        if (p(t)) return t;
                        t = v(t)
                    }
                    return null
                }(e) || n
            }
            let N = async function(e) {
                    let {
                        reference: t,
                        floating: n,
                        strategy: o
                    } = e, u = this.getOffsetParent || A, l = this.getDimensions;
                    return {
                        reference: function(e, t, n) {
                            let o = a(t),
                                u = c(t),
                                l = "fixed" === n,
                                s = O(e, !0, l, t),
                                f = {
                                    scrollLeft: 0,
                                    scrollTop: 0
                                },
                                p = (0, r.ze)(0);
                            if (o || !o && !l) {
                                if (("body" !== i(t) || d(u)) && (f = g(t)), o) {
                                    let e = O(t, !0, l, t);
                                    p.x = e.x + t.clientLeft, p.y = e.y + t.clientTop
                                } else u && (p.x = S(u))
                            }
                            return {
                                x: s.left + f.scrollLeft - p.x,
                                y: s.top + f.scrollTop - p.y,
                                width: s.width,
                                height: s.height
                            }
                        }(t, await u(n), o),
                        floating: {
                            x: 0,
                            y: 0,
                            ...await l(n)
                        }
                    }
                },
                P = {
                    convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
                        let {
                            rect: t,
                            offsetParent: n,
                            strategy: o
                        } = e, u = a(n), l = c(n);
                        if (n === l) return t;
                        let s = {
                                scrollLeft: 0,
                                scrollTop: 0
                            },
                            f = (0, r.ze)(1),
                            p = (0, r.ze)(0);
                        if ((u || !u && "fixed" !== o) && (("body" !== i(n) || d(l)) && (s = g(n)), a(n))) {
                            let e = O(n);
                            f = _(n), p.x = e.x + n.clientLeft, p.y = e.y + n.clientTop
                        }
                        return {
                            width: t.width * f.x,
                            height: t.height * f.y,
                            x: t.x * f.x - s.scrollLeft * f.x + p.x,
                            y: t.y * f.y - s.scrollTop * f.y + p.y
                        }
                    },
                    getDocumentElement: c,
                    getClippingRect: function(e) {
                        let {
                            element: t,
                            boundary: n,
                            rootBoundary: o,
                            strategy: u
                        } = e, c = [..."clippingAncestors" === n ? function(e, t) {
                            let n = t.get(e);
                            if (n) return n;
                            let r = b(e, [], !1).filter(e => s(e) && "body" !== i(e)),
                                o = null,
                                u = "fixed" === E(e).position,
                                c = u ? v(e) : e;
                            for (; s(c) && !h(c);) {
                                let t = E(c),
                                    n = p(c);
                                n || "fixed" !== t.position || (o = null), (u ? !n && !o : !n && "static" === t.position && !!o && ["absolute", "fixed"].includes(o.position) || d(c) && !n && function e(t, n) {
                                    let r = v(t);
                                    return !(r === n || !s(r) || h(r)) && ("fixed" === E(r).position || e(r, n))
                                }(e, c)) ? r = r.filter(e => e !== c) : o = t, c = v(c)
                            }
                            return t.set(e, r), r
                        }(t, this._c) : [].concat(n), o], l = c[0], a = c.reduce((e, n) => {
                            let o = C(t, n, u);
                            return e.top = (0, r.Fp)(o.top, e.top), e.right = (0, r.VV)(o.right, e.right), e.bottom = (0, r.VV)(o.bottom, e.bottom), e.left = (0, r.Fp)(o.left, e.left), e
                        }, C(t, l, u));
                        return {
                            width: a.right - a.left,
                            height: a.bottom - a.top,
                            x: a.left,
                            y: a.top
                        }
                    },
                    getOffsetParent: A,
                    getElementRects: N,
                    getClientRects: function(e) {
                        return Array.from(e.getClientRects())
                    },
                    getDimensions: function(e) {
                        return y(e)
                    },
                    getScale: _,
                    isElement: s,
                    isRTL: function(e) {
                        return "rtl" === E(e).direction
                    }
                };

            function I(e, t, n, o) {
                let i;
                void 0 === o && (o = {});
                let {
                    ancestorScroll: u = !0,
                    ancestorResize: l = !0,
                    elementResize: s = "function" == typeof ResizeObserver,
                    layoutShift: a = "function" == typeof IntersectionObserver,
                    animationFrame: f = !1
                } = o, d = T(e), p = u || l ? [...d ? b(d) : [], ...b(t)] : [];
                p.forEach(e => {
                    u && e.addEventListener("scroll", n, {
                        passive: !0
                    }), l && e.addEventListener("resize", n)
                });
                let m = d && a ? function(e, t) {
                        let n, o = null,
                            i = c(e);

                        function u() {
                            clearTimeout(n), o && o.disconnect(), o = null
                        }
                        return ! function c(l, s) {
                            void 0 === l && (l = !1), void 0 === s && (s = 1), u();
                            let {
                                left: a,
                                top: f,
                                width: d,
                                height: p
                            } = e.getBoundingClientRect();
                            if (l || t(), !d || !p) return;
                            let m = (0, r.GW)(f),
                                h = (0, r.GW)(i.clientWidth - (a + d)),
                                E = {
                                    rootMargin: -m + "px " + -h + "px " + -(0, r.GW)(i.clientHeight - (f + p)) + "px " + -(0, r.GW)(a) + "px",
                                    threshold: (0, r.Fp)(0, (0, r.VV)(1, s)) || 1
                                },
                                g = !0;

                            function v(e) {
                                let t = e[0].intersectionRatio;
                                if (t !== s) {
                                    if (!g) return c();
                                    t ? c(!1, t) : n = setTimeout(() => {
                                        c(!1, 1e-7)
                                    }, 100)
                                }
                                g = !1
                            }
                            try {
                                o = new IntersectionObserver(v, { ...E,
                                    root: i.ownerDocument
                                })
                            } catch (e) {
                                o = new IntersectionObserver(v, E)
                            }
                            o.observe(e)
                        }(!0), u
                    }(d, n) : null,
                    h = -1,
                    E = null;
                s && (E = new ResizeObserver(e => {
                    let [r] = e;
                    r && r.target === d && E && (E.unobserve(t), cancelAnimationFrame(h), h = requestAnimationFrame(() => {
                        E && E.observe(t)
                    })), n()
                }), d && !f && E.observe(d), E.observe(t));
                let g = f ? O(e) : null;
                return f && function t() {
                    let r = O(e);
                    g && (r.x !== g.x || r.y !== g.y || r.width !== g.width || r.height !== g.height) && n(), g = r, i = requestAnimationFrame(t)
                }(), n(), () => {
                    p.forEach(e => {
                        u && e.removeEventListener("scroll", n), l && e.removeEventListener("resize", n)
                    }), m && m(), E && E.disconnect(), E = null, f && cancelAnimationFrame(i)
                }
            }
            let L = (e, t, n) => {
                let r = new Map,
                    i = {
                        platform: P,
                        ...n
                    },
                    u = { ...i.platform,
                        _c: r
                    };
                return (0, o.oo)(e, t, { ...i,
                    platform: u
                })
            }
        },
        1371: function(e, t, n) {
            "use strict";
            n.d(t, {
                Cp: function() {
                    return b
                },
                RR: function() {
                    return g
                },
                YF: function() {
                    return d
                },
                cv: function() {
                    return m
                },
                dp: function() {
                    return v
                },
                dr: function() {
                    return E
                },
                uY: function() {
                    return h
                },
                x7: function() {
                    return y
                }
            });
            var r = n(63853),
                o = n(85983),
                i = n(67294),
                u = n(73935),
                c = "undefined" != typeof document ? i.useLayoutEffect : i.useEffect;

            function l(e, t) {
                let n, r, o;
                if (e === t) return !0;
                if (typeof e != typeof t) return !1;
                if ("function" == typeof e && e.toString() === t.toString()) return !0;
                if (e && t && "object" == typeof e) {
                    if (Array.isArray(e)) {
                        if ((n = e.length) !== t.length) return !1;
                        for (r = n; 0 != r--;)
                            if (!l(e[r], t[r])) return !1;
                        return !0
                    }
                    if ((n = (o = Object.keys(e)).length) !== Object.keys(t).length) return !1;
                    for (r = n; 0 != r--;)
                        if (!({}).hasOwnProperty.call(t, o[r])) return !1;
                    for (r = n; 0 != r--;) {
                        let n = o[r];
                        if (("_owner" !== n || !e.$$typeof) && !l(e[n], t[n])) return !1
                    }
                    return !0
                }
                return e != e && t != t
            }

            function s(e) {
                return "undefined" == typeof window ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1
            }

            function a(e, t) {
                let n = s(e);
                return Math.round(t * n) / n
            }

            function f(e) {
                let t = i.useRef(e);
                return c(() => {
                    t.current = e
                }), t
            }

            function d(e) {
                void 0 === e && (e = {});
                let {
                    placement: t = "bottom",
                    strategy: n = "absolute",
                    middleware: o = [],
                    platform: d,
                    elements: {
                        reference: p,
                        floating: m
                    } = {},
                    transform: h = !0,
                    whileElementsMounted: E,
                    open: g
                } = e, [v, b] = i.useState({
                    x: 0,
                    y: 0,
                    strategy: n,
                    placement: t,
                    middlewareData: {},
                    isPositioned: !1
                }), [y, T] = i.useState(o);
                l(y, o) || T(o);
                let [_, w] = i.useState(null), [x, O] = i.useState(null), S = i.useCallback(e => {
                    e !== N.current && (N.current = e, w(e))
                }, []), C = i.useCallback(e => {
                    e !== P.current && (P.current = e, O(e))
                }, []), R = p || _, A = m || x, N = i.useRef(null), P = i.useRef(null), I = i.useRef(v), L = null != E, j = f(E), k = f(d), D = i.useCallback(() => {
                    if (!N.current || !P.current) return;
                    let e = {
                        placement: t,
                        strategy: n,
                        middleware: y
                    };
                    k.current && (e.platform = k.current), (0, r.oo)(N.current, P.current, e).then(e => {
                        let t = { ...e,
                            isPositioned: !0
                        };
                        M.current && !l(I.current, t) && (I.current = t, u.flushSync(() => {
                            b(t)
                        }))
                    })
                }, [y, t, n, k]);
                c(() => {
                    !1 === g && I.current.isPositioned && (I.current.isPositioned = !1, b(e => ({ ...e,
                        isPositioned: !1
                    })))
                }, [g]);
                let M = i.useRef(!1);
                c(() => (M.current = !0, () => {
                    M.current = !1
                }), []), c(() => {
                    if (R && (N.current = R), A && (P.current = A), R && A) {
                        if (j.current) return j.current(R, A, D);
                        D()
                    }
                }, [R, A, D, j, L]);
                let U = i.useMemo(() => ({
                        reference: N,
                        floating: P,
                        setReference: S,
                        setFloating: C
                    }), [S, C]),
                    G = i.useMemo(() => ({
                        reference: R,
                        floating: A
                    }), [R, A]),
                    F = i.useMemo(() => {
                        let e = {
                            position: n,
                            left: 0,
                            top: 0
                        };
                        if (!G.floating) return e;
                        let t = a(G.floating, v.x),
                            r = a(G.floating, v.y);
                        return h ? { ...e,
                            transform: "translate(" + t + "px, " + r + "px)",
                            ...s(G.floating) >= 1.5 && {
                                willChange: "transform"
                            }
                        } : {
                            position: n,
                            left: t,
                            top: r
                        }
                    }, [n, h, G.floating, v.x, v.y]);
                return i.useMemo(() => ({ ...v,
                    update: D,
                    refs: U,
                    elements: G,
                    floatingStyles: F
                }), [v, D, U, G, F])
            }
            let p = e => ({
                    name: "arrow",
                    options: e,
                    fn(t) {
                        let {
                            element: n,
                            padding: r
                        } = "function" == typeof e ? e(t) : e;
                        return n && ({}).hasOwnProperty.call(n, "current") ? null != n.current ? (0, o.x7)({
                            element: n.current,
                            padding: r
                        }).fn(t) : {} : n ? (0, o.x7)({
                            element: n,
                            padding: r
                        }).fn(t) : {}
                    }
                }),
                m = (e, t) => ({ ...(0, o.cv)(e),
                    options: [e, t]
                }),
                h = (e, t) => ({ ...(0, o.uY)(e),
                    options: [e, t]
                }),
                E = (e, t) => ({ ...(0, o.dr)(e),
                    options: [e, t]
                }),
                g = (e, t) => ({ ...(0, o.RR)(e),
                    options: [e, t]
                }),
                v = (e, t) => ({ ...(0, o.dp)(e),
                    options: [e, t]
                }),
                b = (e, t) => ({ ...(0, o.Cp)(e),
                    options: [e, t]
                }),
                y = (e, t) => ({ ...p(e),
                    options: [e, t]
                })
        },
        71347: function(e, t, n) {
            "use strict";
            n.d(t, {
                Fp: function() {
                    return i
                },
                GW: function() {
                    return c
                },
                I4: function() {
                    return E
                },
                JB: function() {
                    return O
                },
                KX: function() {
                    return _
                },
                NM: function() {
                    return u
                },
                Qq: function() {
                    return g
                },
                Rn: function() {
                    return h
                },
                VV: function() {
                    return o
                },
                Wh: function() {
                    return v
                },
                gy: function() {
                    return y
                },
                hp: function() {
                    return m
                },
                i8: function() {
                    return b
                },
                k3: function() {
                    return p
                },
                ku: function() {
                    return d
                },
                mA: function() {
                    return r
                },
                pw: function() {
                    return w
                },
                uZ: function() {
                    return f
                },
                yd: function() {
                    return x
                },
                ze: function() {
                    return l
                }
            });
            let r = ["top", "right", "bottom", "left"],
                o = Math.min,
                i = Math.max,
                u = Math.round,
                c = Math.floor,
                l = e => ({
                    x: e,
                    y: e
                }),
                s = {
                    left: "right",
                    right: "left",
                    bottom: "top",
                    top: "bottom"
                },
                a = {
                    start: "end",
                    end: "start"
                };

            function f(e, t, n) {
                return i(e, o(t, n))
            }

            function d(e, t) {
                return "function" == typeof e ? e(t) : e
            }

            function p(e) {
                return e.split("-")[0]
            }

            function m(e) {
                return e.split("-")[1]
            }

            function h(e) {
                return "x" === e ? "y" : "x"
            }

            function E(e) {
                return "y" === e ? "height" : "width"
            }

            function g(e) {
                return ["top", "bottom"].includes(p(e)) ? "y" : "x"
            }

            function v(e) {
                return h(g(e))
            }

            function b(e, t, n) {
                void 0 === n && (n = !1);
                let r = m(e),
                    o = v(e),
                    i = E(o),
                    u = "x" === o ? r === (n ? "end" : "start") ? "right" : "left" : "start" === r ? "bottom" : "top";
                return t.reference[i] > t.floating[i] && (u = w(u)), [u, w(u)]
            }

            function y(e) {
                let t = w(e);
                return [T(e), t, T(t)]
            }

            function T(e) {
                return e.replace(/start|end/g, e => a[e])
            }

            function _(e, t, n, r) {
                let o = m(e),
                    i = function(e, t, n) {
                        let r = ["left", "right"],
                            o = ["right", "left"];
                        switch (e) {
                            case "top":
                            case "bottom":
                                if (n) return t ? o : r;
                                return t ? r : o;
                            case "left":
                            case "right":
                                return t ? ["top", "bottom"] : ["bottom", "top"];
                            default:
                                return []
                        }
                    }(p(e), "start" === n, r);
                return o && (i = i.map(e => e + "-" + o), t && (i = i.concat(i.map(T)))), i
            }

            function w(e) {
                return e.replace(/left|right|bottom|top/g, e => s[e])
            }

            function x(e) {
                return "number" != typeof e ? {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0,
                    ...e
                } : {
                    top: e,
                    right: e,
                    bottom: e,
                    left: e
                }
            }

            function O(e) {
                return { ...e,
                    top: e.y,
                    left: e.x,
                    right: e.x + e.width,
                    bottom: e.y + e.height
                }
            }
        },
        40666: function(e, t, n) {
            "use strict";
            let r;
            n.d(t, {
                I0: function() {
                    return b
                },
                XB: function() {
                    return m
                },
                fC: function() {
                    return v
                }
            });
            var o = n(87462),
                i = n(67294);

            function u(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (null == e || e(r), !1 === n || !r.defaultPrevented) return null == t ? void 0 : t(r)
                }
            }
            var c = n(73935),
                l = n(4222);
            let s = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                let n = (0, i.forwardRef)((e, n) => {
                    let {
                        asChild: r,
                        ...u
                    } = e, c = r ? l.g7 : t;
                    return (0, i.useEffect)(() => {
                        window[Symbol.for("radix-ui")] = !0
                    }, []), (0, i.createElement)(c, (0, o.Z)({}, u, {
                        ref: n
                    }))
                });
                return n.displayName = `Primitive.${t}`, { ...e,
                    [t]: n
                }
            }, {});

            function a(...e) {
                return (0, i.useCallback)(function(...e) {
                    return t => e.forEach(e => {
                        "function" == typeof e ? e(t) : null != e && (e.current = t)
                    })
                }(...e), e)
            }

            function f(e) {
                let t = (0, i.useRef)(e);
                return (0, i.useEffect)(() => {
                    t.current = e
                }), (0, i.useMemo)(() => (...e) => {
                    var n;
                    return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                }, [])
            }
            let d = "dismissableLayer.update",
                p = (0, i.createContext)({
                    layers: new Set,
                    layersWithOutsidePointerEventsDisabled: new Set,
                    branches: new Set
                }),
                m = (0, i.forwardRef)((e, t) => {
                    var n;
                    let {
                        disableOutsidePointerEvents: c = !1,
                        onEscapeKeyDown: l,
                        onPointerDownOutside: m,
                        onFocusOutside: h,
                        onInteractOutside: v,
                        onDismiss: b,
                        ...y
                    } = e, T = (0, i.useContext)(p), [_, w] = (0, i.useState)(null), x = null !== (n = null == _ ? void 0 : _.ownerDocument) && void 0 !== n ? n : null == globalThis ? void 0 : globalThis.document, [, O] = (0, i.useState)({}), S = a(t, e => w(e)), C = Array.from(T.layers), [R] = [...T.layersWithOutsidePointerEventsDisabled].slice(-1), A = C.indexOf(R), N = _ ? C.indexOf(_) : -1, P = T.layersWithOutsidePointerEventsDisabled.size > 0, I = N >= A, L = function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = f(e),
                            r = (0, i.useRef)(!1),
                            o = (0, i.useRef)(() => {});
                        return (0, i.useEffect)(() => {
                            let e = e => {
                                    if (e.target && !r.current) {
                                        let r = {
                                            originalEvent: e
                                        };

                                        function i() {
                                            g("dismissableLayer.pointerDownOutside", n, r, {
                                                discrete: !0
                                            })
                                        }
                                        "touch" === e.pointerType ? (t.removeEventListener("click", o.current), o.current = i, t.addEventListener("click", o.current, {
                                            once: !0
                                        })) : i()
                                    } else t.removeEventListener("click", o.current);
                                    r.current = !1
                                },
                                i = window.setTimeout(() => {
                                    t.addEventListener("pointerdown", e)
                                }, 0);
                            return () => {
                                window.clearTimeout(i), t.removeEventListener("pointerdown", e), t.removeEventListener("click", o.current)
                            }
                        }, [t, n]), {
                            onPointerDownCapture: () => r.current = !0
                        }
                    }(e => {
                        let t = e.target,
                            n = [...T.branches].some(e => e.contains(t));
                        !I || n || (null == m || m(e), null == v || v(e), e.defaultPrevented || null == b || b())
                    }, x), j = function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = f(e),
                            r = (0, i.useRef)(!1);
                        return (0, i.useEffect)(() => {
                            let e = e => {
                                e.target && !r.current && g("dismissableLayer.focusOutside", n, {
                                    originalEvent: e
                                }, {
                                    discrete: !1
                                })
                            };
                            return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e)
                        }, [t, n]), {
                            onFocusCapture: () => r.current = !0,
                            onBlurCapture: () => r.current = !1
                        }
                    }(e => {
                        let t = e.target;
                        [...T.branches].some(e => e.contains(t)) || (null == h || h(e), null == v || v(e), e.defaultPrevented || null == b || b())
                    }, x);
                    return ! function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = function(e) {
                            let t = (0, i.useRef)(e);
                            return (0, i.useEffect)(() => {
                                t.current = e
                            }), (0, i.useMemo)(() => (...e) => {
                                var n;
                                return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                            }, [])
                        }(e);
                        (0, i.useEffect)(() => {
                            let e = e => {
                                "Escape" === e.key && n(e)
                            };
                            return t.addEventListener("keydown", e), () => t.removeEventListener("keydown", e)
                        }, [n, t])
                    }(e => {
                        N !== T.layers.size - 1 || (null == l || l(e), !e.defaultPrevented && b && (e.preventDefault(), b()))
                    }, x), (0, i.useEffect)(() => {
                        if (_) return c && (0 === T.layersWithOutsidePointerEventsDisabled.size && (r = x.body.style.pointerEvents, x.body.style.pointerEvents = "none"), T.layersWithOutsidePointerEventsDisabled.add(_)), T.layers.add(_), E(), () => {
                            c && 1 === T.layersWithOutsidePointerEventsDisabled.size && (x.body.style.pointerEvents = r)
                        }
                    }, [_, x, c, T]), (0, i.useEffect)(() => () => {
                        _ && (T.layers.delete(_), T.layersWithOutsidePointerEventsDisabled.delete(_), E())
                    }, [_, T]), (0, i.useEffect)(() => {
                        let e = () => O({});
                        return document.addEventListener(d, e), () => document.removeEventListener(d, e)
                    }, []), (0, i.createElement)(s.div, (0, o.Z)({}, y, {
                        ref: S,
                        style: {
                            pointerEvents: P ? I ? "auto" : "none" : void 0,
                            ...e.style
                        },
                        onFocusCapture: u(e.onFocusCapture, j.onFocusCapture),
                        onBlurCapture: u(e.onBlurCapture, j.onBlurCapture),
                        onPointerDownCapture: u(e.onPointerDownCapture, L.onPointerDownCapture)
                    }))
                }),
                h = (0, i.forwardRef)((e, t) => {
                    let n = (0, i.useContext)(p),
                        r = (0, i.useRef)(null),
                        u = a(t, r);
                    return (0, i.useEffect)(() => {
                        let e = r.current;
                        if (e) return n.branches.add(e), () => {
                            n.branches.delete(e)
                        }
                    }, [n.branches]), (0, i.createElement)(s.div, (0, o.Z)({}, e, {
                        ref: u
                    }))
                });

            function E() {
                let e = new CustomEvent(d);
                document.dispatchEvent(e)
            }

            function g(e, t, n, {
                discrete: r
            }) {
                let o = n.originalEvent.target,
                    i = new CustomEvent(e, {
                        bubbles: !1,
                        cancelable: !0,
                        detail: n
                    });
                (t && o.addEventListener(e, t, {
                    once: !0
                }), r) ? o && (0, c.flushSync)(() => o.dispatchEvent(i)): o.dispatchEvent(i)
            }
            let v = m,
                b = h
        },
        18304: function(e, t, n) {
            "use strict";
            n.d(t, {
                h: function() {
                    return l
                }
            });
            var r = n(87462),
                o = n(67294),
                i = n(73935),
                u = n(4222);
            let c = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = (0, o.forwardRef)((e, n) => {
                        let {
                            asChild: i,
                            ...c
                        } = e, l = i ? u.g7 : t;
                        return (0, o.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, o.createElement)(l, (0, r.Z)({}, c, {
                            ref: n
                        }))
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {}),
                l = (0, o.forwardRef)((e, t) => {
                    var n;
                    let {
                        container: u = null == globalThis ? void 0 : null === (n = globalThis.document) || void 0 === n ? void 0 : n.body,
                        ...l
                    } = e;
                    return u ? i.createPortal((0, o.createElement)(c.div, (0, r.Z)({}, l, {
                        ref: t
                    })), u) : null
                })
        },
        438: function(e, t, n) {
            "use strict";
            n.d(t, {
                z: function() {
                    return u
                }
            });
            var r = n(67294),
                o = n(73935);
            let i = (null == globalThis ? void 0 : globalThis.document) ? r.useLayoutEffect : () => {},
                u = e => {
                    let {
                        present: t,
                        children: n
                    } = e, u = function(e) {
                        var t, n;
                        let [u, l] = (0, r.useState)(), s = (0, r.useRef)({}), a = (0, r.useRef)(e), f = (0, r.useRef)("none"), [d, p] = (t = e ? "mounted" : "unmounted", n = {
                            mounted: {
                                UNMOUNT: "unmounted",
                                ANIMATION_OUT: "unmountSuspended"
                            },
                            unmountSuspended: {
                                MOUNT: "mounted",
                                ANIMATION_END: "unmounted"
                            },
                            unmounted: {
                                MOUNT: "mounted"
                            }
                        }, (0, r.useReducer)((e, t) => {
                            let r = n[e][t];
                            return null != r ? r : e
                        }, t));
                        return (0, r.useEffect)(() => {
                            let e = c(s.current);
                            f.current = "mounted" === d ? e : "none"
                        }, [d]), i(() => {
                            let t = s.current,
                                n = a.current;
                            if (n !== e) {
                                let r = f.current,
                                    o = c(t);
                                e ? p("MOUNT") : "none" === o || (null == t ? void 0 : t.display) === "none" ? p("UNMOUNT") : n && r !== o ? p("ANIMATION_OUT") : p("UNMOUNT"), a.current = e
                            }
                        }, [e, p]), i(() => {
                            if (u) {
                                let e = e => {
                                        let t = c(s.current).includes(e.animationName);
                                        e.target === u && t && (0, o.flushSync)(() => p("ANIMATION_END"))
                                    },
                                    t = e => {
                                        e.target === u && (f.current = c(s.current))
                                    };
                                return u.addEventListener("animationstart", t), u.addEventListener("animationcancel", e), u.addEventListener("animationend", e), () => {
                                    u.removeEventListener("animationstart", t), u.removeEventListener("animationcancel", e), u.removeEventListener("animationend", e)
                                }
                            }
                            p("ANIMATION_END")
                        }, [u, p]), {
                            isPresent: ["mounted", "unmountSuspended"].includes(d),
                            ref: (0, r.useCallback)(e => {
                                e && (s.current = getComputedStyle(e)), l(e)
                            }, [])
                        }
                    }(t), l = "function" == typeof n ? n({
                        present: u.isPresent
                    }) : r.Children.only(n), s = function(...e) {
                        return (0, r.useCallback)(function(...e) {
                            return t => e.forEach(e => {
                                "function" == typeof e ? e(t) : null != e && (e.current = t)
                            })
                        }(...e), e)
                    }(u.ref, l.ref);
                    return "function" == typeof n || u.isPresent ? (0, r.cloneElement)(l, {
                        ref: s
                    }) : null
                };

            function c(e) {
                return (null == e ? void 0 : e.animationName) || "none"
            }
            u.displayName = "Presence"
        },
        4222: function(e, t, n) {
            "use strict";
            n.d(t, {
                g7: function() {
                    return i
                },
                A4: function() {
                    return c
                }
            });
            var r = n(87462),
                o = n(67294);
            let i = (0, o.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...i
                } = e, c = o.Children.toArray(n), s = c.find(l);
                if (s) {
                    let e = s.props.children,
                        n = c.map(t => t !== s ? t : o.Children.count(e) > 1 ? o.Children.only(null) : (0, o.isValidElement)(e) ? e.props.children : null);
                    return (0, o.createElement)(u, (0, r.Z)({}, i, {
                        ref: t
                    }), (0, o.isValidElement)(e) ? (0, o.cloneElement)(e, void 0, n) : null)
                }
                return (0, o.createElement)(u, (0, r.Z)({}, i, {
                    ref: t
                }), n)
            });
            i.displayName = "Slot";
            let u = (0, o.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...r
                } = e;
                return (0, o.isValidElement)(n) ? (0, o.cloneElement)(n, { ... function(e, t) {
                        let n = { ...t
                        };
                        for (let r in t) {
                            let o = e[r],
                                i = t[r];
                            /^on[A-Z]/.test(r) ? o && i ? n[r] = (...e) => {
                                i(...e), o(...e)
                            } : o && (n[r] = o) : "style" === r ? n[r] = { ...o,
                                ...i
                            } : "className" === r && (n[r] = [o, i].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...n
                        }
                    }(r, n.props),
                    ref: t ? function(...e) {
                        return t => e.forEach(e => {
                            "function" == typeof e ? e(t) : null != e && (e.current = t)
                        })
                    }(t, n.ref) : n.ref
                }) : o.Children.count(n) > 1 ? o.Children.only(null) : null
            });
            u.displayName = "SlotClone";
            let c = ({
                children: e
            }) => (0, o.createElement)(o.Fragment, null, e);

            function l(e) {
                return (0, o.isValidElement)(e) && e.type === c
            }
        },
        16012: function(e, t, n) {
            "use strict";
            n.d(t, {
                Eh: function() {
                    return eC
                },
                VY: function() {
                    return eS
                },
                h_: function() {
                    return eO
                },
                fC: function() {
                    return ew
                },
                NM: function() {
                    return em
                },
                pn: function() {
                    return eo
                },
                xz: function() {
                    return ex
                }
            });
            var r, o = n(67294),
                i = n.t(o, 2);

            function u(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (e ? .(r), !1 === n || !r.defaultPrevented) return t ? .(r)
                }
            }

            function c(...e) {
                return t => e.forEach(e => {
                    "function" == typeof e ? e(t) : null != e && (e.current = t)
                })
            }

            function l(...e) {
                return o.useCallback(c(...e), e)
            }
            var s = n(85893);

            function a(e, t = []) {
                let n = [],
                    r = () => {
                        let t = n.map(e => o.createContext(e));
                        return function(n) {
                            let r = n ? .[e] || t;
                            return o.useMemo(() => ({
                                [`__scope${e}`]: { ...n,
                                    [e]: r
                                }
                            }), [n, r])
                        }
                    };
                return r.scopeName = e, [function(t, r) {
                    let i = o.createContext(r),
                        u = n.length;

                    function c(t) {
                        let {
                            scope: n,
                            children: r,
                            ...c
                        } = t, l = n ? .[e][u] || i, a = o.useMemo(() => c, Object.values(c));
                        return (0, s.jsx)(l.Provider, {
                            value: a,
                            children: r
                        })
                    }
                    return n = [...n, r], c.displayName = t + "Provider", [c, function(n, c) {
                        let l = c ? .[e][u] || i,
                            s = o.useContext(l);
                        if (s) return s;
                        if (void 0 !== r) return r;
                        throw Error(`\`${n}\` must be used within \`${t}\``)
                    }]
                }, function(...e) {
                    let t = e[0];
                    if (1 === e.length) return t;
                    let n = () => {
                        let n = e.map(e => ({
                            useScope: e(),
                            scopeName: e.scopeName
                        }));
                        return function(e) {
                            let r = n.reduce((t, {
                                useScope: n,
                                scopeName: r
                            }) => {
                                let o = n(e)[`__scope${r}`];
                                return { ...t,
                                    ...o
                                }
                            }, {});
                            return o.useMemo(() => ({
                                [`__scope${t.scopeName}`]: r
                            }), [r])
                        }
                    };
                    return n.scopeName = t.scopeName, n
                }(r, ...t)]
            }
            var f = n(73935),
                d = o.forwardRef((e, t) => {
                    let {
                        children: n,
                        ...r
                    } = e, i = o.Children.toArray(n), u = i.find(h);
                    if (u) {
                        let e = u.props.children,
                            n = i.map(t => t !== u ? t : o.Children.count(e) > 1 ? o.Children.only(null) : o.isValidElement(e) ? e.props.children : null);
                        return (0, s.jsx)(p, { ...r,
                            ref: t,
                            children: o.isValidElement(e) ? o.cloneElement(e, void 0, n) : null
                        })
                    }
                    return (0, s.jsx)(p, { ...r,
                        ref: t,
                        children: n
                    })
                });
            d.displayName = "Slot";
            var p = o.forwardRef((e, t) => {
                let {
                    children: n,
                    ...r
                } = e;
                if (o.isValidElement(n)) {
                    let e, i;
                    let u = (e = Object.getOwnPropertyDescriptor(n.props, "ref") ? .get) && "isReactWarning" in e && e.isReactWarning ? n.ref : (e = Object.getOwnPropertyDescriptor(n, "ref") ? .get) && "isReactWarning" in e && e.isReactWarning ? n.props.ref : n.props.ref || n.ref;
                    return o.cloneElement(n, { ... function(e, t) {
                            let n = { ...t
                            };
                            for (let r in t) {
                                let o = e[r],
                                    i = t[r];
                                /^on[A-Z]/.test(r) ? o && i ? n[r] = (...e) => {
                                    i(...e), o(...e)
                                } : o && (n[r] = o) : "style" === r ? n[r] = { ...o,
                                    ...i
                                } : "className" === r && (n[r] = [o, i].filter(Boolean).join(" "))
                            }
                            return { ...e,
                                ...n
                            }
                        }(r, n.props),
                        ref: t ? c(t, u) : u
                    })
                }
                return o.Children.count(n) > 1 ? o.Children.only(null) : null
            });
            p.displayName = "SlotClone";
            var m = ({
                children: e
            }) => (0, s.jsx)(s.Fragment, {
                children: e
            });

            function h(e) {
                return o.isValidElement(e) && e.type === m
            }
            var E = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                let n = o.forwardRef((e, n) => {
                    let {
                        asChild: r,
                        ...o
                    } = e, i = r ? d : t;
                    return "undefined" != typeof window && (window[Symbol.for("radix-ui")] = !0), (0, s.jsx)(i, { ...o,
                        ref: n
                    })
                });
                return n.displayName = `Primitive.${t}`, { ...e,
                    [t]: n
                }
            }, {});

            function g(e) {
                let t = o.useRef(e);
                return o.useEffect(() => {
                    t.current = e
                }), o.useMemo(() => (...e) => t.current ? .(...e), [])
            }
            var v = "dismissableLayer.update",
                b = o.createContext({
                    layers: new Set,
                    layersWithOutsidePointerEventsDisabled: new Set,
                    branches: new Set
                }),
                y = o.forwardRef((e, t) => {
                    let {
                        disableOutsidePointerEvents: n = !1,
                        onEscapeKeyDown: i,
                        onPointerDownOutside: c,
                        onFocusOutside: a,
                        onInteractOutside: f,
                        onDismiss: d,
                        ...p
                    } = e, m = o.useContext(b), [h, y] = o.useState(null), w = h ? .ownerDocument ? ? globalThis ? .document, [, x] = o.useState({}), O = l(t, e => y(e)), S = Array.from(m.layers), [C] = [...m.layersWithOutsidePointerEventsDisabled].slice(-1), R = S.indexOf(C), A = h ? S.indexOf(h) : -1, N = m.layersWithOutsidePointerEventsDisabled.size > 0, P = A >= R, I = function(e, t = globalThis ? .document) {
                        let n = g(e),
                            r = o.useRef(!1),
                            i = o.useRef(() => {});
                        return o.useEffect(() => {
                            let e = e => {
                                    if (e.target && !r.current) {
                                        let r = function() {
                                                _("dismissableLayer.pointerDownOutside", n, o, {
                                                    discrete: !0
                                                })
                                            },
                                            o = {
                                                originalEvent: e
                                            };
                                        "touch" === e.pointerType ? (t.removeEventListener("click", i.current), i.current = r, t.addEventListener("click", i.current, {
                                            once: !0
                                        })) : r()
                                    } else t.removeEventListener("click", i.current);
                                    r.current = !1
                                },
                                o = window.setTimeout(() => {
                                    t.addEventListener("pointerdown", e)
                                }, 0);
                            return () => {
                                window.clearTimeout(o), t.removeEventListener("pointerdown", e), t.removeEventListener("click", i.current)
                            }
                        }, [t, n]), {
                            onPointerDownCapture: () => r.current = !0
                        }
                    }(e => {
                        let t = e.target,
                            n = [...m.branches].some(e => e.contains(t));
                        !P || n || (c ? .(e), f ? .(e), e.defaultPrevented || d ? .())
                    }, w), L = function(e, t = globalThis ? .document) {
                        let n = g(e),
                            r = o.useRef(!1);
                        return o.useEffect(() => {
                            let e = e => {
                                e.target && !r.current && _("dismissableLayer.focusOutside", n, {
                                    originalEvent: e
                                }, {
                                    discrete: !1
                                })
                            };
                            return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e)
                        }, [t, n]), {
                            onFocusCapture: () => r.current = !0,
                            onBlurCapture: () => r.current = !1
                        }
                    }(e => {
                        let t = e.target;
                        [...m.branches].some(e => e.contains(t)) || (a ? .(e), f ? .(e), e.defaultPrevented || d ? .())
                    }, w);
                    return ! function(e, t = globalThis ? .document) {
                        let n = g(e);
                        o.useEffect(() => {
                            let e = e => {
                                "Escape" === e.key && n(e)
                            };
                            return t.addEventListener("keydown", e, {
                                capture: !0
                            }), () => t.removeEventListener("keydown", e, {
                                capture: !0
                            })
                        }, [n, t])
                    }(e => {
                        A !== m.layers.size - 1 || (i ? .(e), !e.defaultPrevented && d && (e.preventDefault(), d()))
                    }, w), o.useEffect(() => {
                        if (h) return n && (0 === m.layersWithOutsidePointerEventsDisabled.size && (r = w.body.style.pointerEvents, w.body.style.pointerEvents = "none"), m.layersWithOutsidePointerEventsDisabled.add(h)), m.layers.add(h), T(), () => {
                            n && 1 === m.layersWithOutsidePointerEventsDisabled.size && (w.body.style.pointerEvents = r)
                        }
                    }, [h, w, n, m]), o.useEffect(() => () => {
                        h && (m.layers.delete(h), m.layersWithOutsidePointerEventsDisabled.delete(h), T())
                    }, [h, m]), o.useEffect(() => {
                        let e = () => x({});
                        return document.addEventListener(v, e), () => document.removeEventListener(v, e)
                    }, []), (0, s.jsx)(E.div, { ...p,
                        ref: O,
                        style: {
                            pointerEvents: N ? P ? "auto" : "none" : void 0,
                            ...e.style
                        },
                        onFocusCapture: u(e.onFocusCapture, L.onFocusCapture),
                        onBlurCapture: u(e.onBlurCapture, L.onBlurCapture),
                        onPointerDownCapture: u(e.onPointerDownCapture, I.onPointerDownCapture)
                    })
                });

            function T() {
                let e = new CustomEvent(v);
                document.dispatchEvent(e)
            }

            function _(e, t, n, {
                discrete: r
            }) {
                let o = n.originalEvent.target,
                    i = new CustomEvent(e, {
                        bubbles: !1,
                        cancelable: !0,
                        detail: n
                    });
                (t && o.addEventListener(e, t, {
                    once: !0
                }), r) ? o && f.flushSync(() => o.dispatchEvent(i)): o.dispatchEvent(i)
            }
            y.displayName = "DismissableLayer", o.forwardRef((e, t) => {
                let n = o.useContext(b),
                    r = o.useRef(null),
                    i = l(t, r);
                return o.useEffect(() => {
                    let e = r.current;
                    if (e) return n.branches.add(e), () => {
                        n.branches.delete(e)
                    }
                }, [n.branches]), (0, s.jsx)(E.div, { ...e,
                    ref: i
                })
            }).displayName = "DismissableLayerBranch";
            var w = globalThis ? .document ? o.useLayoutEffect : () => {},
                x = i["useId".toString()] || (() => void 0),
                O = 0,
                S = n(1371),
                C = n(63853),
                R = o.forwardRef((e, t) => {
                    let {
                        children: n,
                        width: r = 10,
                        height: o = 5,
                        ...i
                    } = e;
                    return (0, s.jsx)(E.svg, { ...i,
                        ref: t,
                        width: r,
                        height: o,
                        viewBox: "0 0 30 10",
                        preserveAspectRatio: "none",
                        children: e.asChild ? n : (0, s.jsx)("polygon", {
                            points: "0,0 30,0 15,10"
                        })
                    })
                });
            R.displayName = "Arrow";
            var A = "Popper",
                [N, P] = a(A),
                [I, L] = N(A),
                j = e => {
                    let {
                        __scopePopper: t,
                        children: n
                    } = e, [r, i] = o.useState(null);
                    return (0, s.jsx)(I, {
                        scope: t,
                        anchor: r,
                        onAnchorChange: i,
                        children: n
                    })
                };
            j.displayName = A;
            var k = "PopperAnchor",
                D = o.forwardRef((e, t) => {
                    let {
                        __scopePopper: n,
                        virtualRef: r,
                        ...i
                    } = e, u = L(k, n), c = o.useRef(null), a = l(t, c);
                    return o.useEffect(() => {
                        u.onAnchorChange(r ? .current || c.current)
                    }), r ? null : (0, s.jsx)(E.div, { ...i,
                        ref: a
                    })
                });
            D.displayName = k;
            var M = "PopperContent",
                [U, G] = N(M),
                F = o.forwardRef((e, t) => {
                    let {
                        __scopePopper: n,
                        side: r = "bottom",
                        sideOffset: i = 0,
                        align: u = "center",
                        alignOffset: c = 0,
                        arrowPadding: a = 0,
                        avoidCollisions: f = !0,
                        collisionBoundary: d = [],
                        collisionPadding: p = 0,
                        sticky: m = "partial",
                        hideWhenDetached: h = !1,
                        updatePositionStrategy: v = "optimized",
                        onPlaced: b,
                        ...y
                    } = e, T = L(M, n), [_, x] = o.useState(null), O = l(t, e => x(e)), [R, A] = o.useState(null), N = function(e) {
                        let [t, n] = o.useState(void 0);
                        return w(() => {
                            if (e) {
                                n({
                                    width: e.offsetWidth,
                                    height: e.offsetHeight
                                });
                                let t = new ResizeObserver(t => {
                                    let r, o;
                                    if (!Array.isArray(t) || !t.length) return;
                                    let i = t[0];
                                    if ("borderBoxSize" in i) {
                                        let e = i.borderBoxSize,
                                            t = Array.isArray(e) ? e[0] : e;
                                        r = t.inlineSize, o = t.blockSize
                                    } else r = e.offsetWidth, o = e.offsetHeight;
                                    n({
                                        width: r,
                                        height: o
                                    })
                                });
                                return t.observe(e, {
                                    box: "border-box"
                                }), () => t.unobserve(e)
                            }
                            n(void 0)
                        }, [e]), t
                    }(R), P = N ? .width ? ? 0, I = N ? .height ? ? 0, j = "number" == typeof p ? p : {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0,
                        ...p
                    }, k = Array.isArray(d) ? d : [d], D = k.length > 0, G = {
                        padding: j,
                        boundary: k.filter(V),
                        altBoundary: D
                    }, {
                        refs: F,
                        floatingStyles: H,
                        placement: z,
                        isPositioned: B,
                        middlewareData: W
                    } = (0, S.YF)({
                        strategy: "fixed",
                        placement: r + ("center" !== u ? "-" + u : ""),
                        whileElementsMounted: (...e) => (0, C.Me)(...e, {
                            animationFrame: "always" === v
                        }),
                        elements: {
                            reference: T.anchor
                        },
                        middleware: [(0, S.cv)({
                            mainAxis: i + I,
                            alignmentAxis: c
                        }), f && (0, S.uY)({
                            mainAxis: !0,
                            crossAxis: !1,
                            limiter: "partial" === m ? (0, S.dr)() : void 0,
                            ...G
                        }), f && (0, S.RR)({ ...G
                        }), (0, S.dp)({ ...G,
                            apply: ({
                                elements: e,
                                rects: t,
                                availableWidth: n,
                                availableHeight: r
                            }) => {
                                let {
                                    width: o,
                                    height: i
                                } = t.reference, u = e.floating.style;
                                u.setProperty("--radix-popper-available-width", `${n}px`), u.setProperty("--radix-popper-available-height", `${r}px`), u.setProperty("--radix-popper-anchor-width", `${o}px`), u.setProperty("--radix-popper-anchor-height", `${i}px`)
                            }
                        }), R && (0, S.x7)({
                            element: R,
                            padding: a
                        }), J({
                            arrowWidth: P,
                            arrowHeight: I
                        }), h && (0, S.Cp)({
                            strategy: "referenceHidden",
                            ...G
                        })]
                    }), [K, X] = Y(z), q = g(b);
                    w(() => {
                        B && q ? .()
                    }, [B, q]);
                    let Z = W.arrow ? .x,
                        $ = W.arrow ? .y,
                        Q = W.arrow ? .centerOffset !== 0,
                        [ee, et] = o.useState();
                    return w(() => {
                        _ && et(window.getComputedStyle(_).zIndex)
                    }, [_]), (0, s.jsx)("div", {
                        ref: F.setFloating,
                        "data-radix-popper-content-wrapper": "",
                        style: { ...H,
                            transform: B ? H.transform : "translate(0, -200%)",
                            minWidth: "max-content",
                            zIndex: ee,
                            "--radix-popper-transform-origin": [W.transformOrigin ? .x, W.transformOrigin ? .y].join(" "),
                            ...W.hide ? .referenceHidden && {
                                visibility: "hidden",
                                pointerEvents: "none"
                            }
                        },
                        dir: e.dir,
                        children: (0, s.jsx)(U, {
                            scope: n,
                            placedSide: K,
                            onArrowChange: A,
                            arrowX: Z,
                            arrowY: $,
                            shouldHideArrow: Q,
                            children: (0, s.jsx)(E.div, {
                                "data-side": K,
                                "data-align": X,
                                ...y,
                                ref: O,
                                style: { ...y.style,
                                    animation: B ? void 0 : "none"
                                }
                            })
                        })
                    })
                });
            F.displayName = M;
            var H = "PopperArrow",
                z = {
                    top: "bottom",
                    right: "left",
                    bottom: "top",
                    left: "right"
                },
                B = o.forwardRef(function(e, t) {
                    let {
                        __scopePopper: n,
                        ...r
                    } = e, o = G(H, n), i = z[o.placedSide];
                    return (0, s.jsx)("span", {
                        ref: o.onArrowChange,
                        style: {
                            position: "absolute",
                            left: o.arrowX,
                            top: o.arrowY,
                            [i]: 0,
                            transformOrigin: {
                                top: "",
                                right: "0 0",
                                bottom: "center 0",
                                left: "100% 0"
                            }[o.placedSide],
                            transform: {
                                top: "translateY(100%)",
                                right: "translateY(50%) rotate(90deg) translateX(-50%)",
                                bottom: "rotate(180deg)",
                                left: "translateY(50%) rotate(-90deg) translateX(50%)"
                            }[o.placedSide],
                            visibility: o.shouldHideArrow ? "hidden" : void 0
                        },
                        children: (0, s.jsx)(R, { ...r,
                            ref: t,
                            style: { ...r.style,
                                display: "block"
                            }
                        })
                    })
                });

            function V(e) {
                return null !== e
            }
            B.displayName = H;
            var J = e => ({
                name: "transformOrigin",
                options: e,
                fn(t) {
                    let {
                        placement: n,
                        rects: r,
                        middlewareData: o
                    } = t, i = o.arrow ? .centerOffset !== 0, u = i ? 0 : e.arrowWidth, c = i ? 0 : e.arrowHeight, [l, s] = Y(n), a = {
                        start: "0%",
                        center: "50%",
                        end: "100%"
                    }[s], f = (o.arrow ? .x ? ? 0) + u / 2, d = (o.arrow ? .y ? ? 0) + c / 2, p = "", m = "";
                    return "bottom" === l ? (p = i ? a : `${f}px`, m = `${-c}px`) : "top" === l ? (p = i ? a : `${f}px`, m = `${r.floating.height+c}px`) : "right" === l ? (p = `${-c}px`, m = i ? a : `${d}px`) : "left" === l && (p = `${r.floating.width+c}px`, m = i ? a : `${d}px`), {
                        data: {
                            x: p,
                            y: m
                        }
                    }
                }
            });

            function Y(e) {
                let [t, n = "center"] = e.split("-");
                return [t, n]
            }
            var W = o.forwardRef((e, t) => {
                let {
                    container: n,
                    ...r
                } = e, [i, u] = o.useState(!1);
                w(() => u(!0), []);
                let c = n || i && globalThis ? .document ? .body;
                return c ? f.createPortal((0, s.jsx)(E.div, { ...r,
                    ref: t
                }), c) : null
            });
            W.displayName = "Portal";
            var K = e => {
                let t, n;
                let {
                    present: r,
                    children: i
                } = e, u = function(e) {
                    var t, n;
                    let [r, i] = o.useState(), u = o.useRef({}), c = o.useRef(e), l = o.useRef("none"), [s, a] = (t = e ? "mounted" : "unmounted", n = {
                        mounted: {
                            UNMOUNT: "unmounted",
                            ANIMATION_OUT: "unmountSuspended"
                        },
                        unmountSuspended: {
                            MOUNT: "mounted",
                            ANIMATION_END: "unmounted"
                        },
                        unmounted: {
                            MOUNT: "mounted"
                        }
                    }, o.useReducer((e, t) => n[e][t] ? ? e, t));
                    return o.useEffect(() => {
                        let e = X(u.current);
                        l.current = "mounted" === s ? e : "none"
                    }, [s]), w(() => {
                        let t = u.current,
                            n = c.current;
                        if (n !== e) {
                            let r = l.current,
                                o = X(t);
                            e ? a("MOUNT") : "none" === o || t ? .display === "none" ? a("UNMOUNT") : n && r !== o ? a("ANIMATION_OUT") : a("UNMOUNT"), c.current = e
                        }
                    }, [e, a]), w(() => {
                        if (r) {
                            let e = e => {
                                    let t = X(u.current).includes(e.animationName);
                                    e.target === r && t && f.flushSync(() => a("ANIMATION_END"))
                                },
                                t = e => {
                                    e.target === r && (l.current = X(u.current))
                                };
                            return r.addEventListener("animationstart", t), r.addEventListener("animationcancel", e), r.addEventListener("animationend", e), () => {
                                r.removeEventListener("animationstart", t), r.removeEventListener("animationcancel", e), r.removeEventListener("animationend", e)
                            }
                        }
                        a("ANIMATION_END")
                    }, [r, a]), {
                        isPresent: ["mounted", "unmountSuspended"].includes(s),
                        ref: o.useCallback(e => {
                            e && (u.current = getComputedStyle(e)), i(e)
                        }, [])
                    }
                }(r), c = "function" == typeof i ? i({
                    present: u.isPresent
                }) : o.Children.only(i), s = l(u.ref, (t = Object.getOwnPropertyDescriptor(c.props, "ref") ? .get) && "isReactWarning" in t && t.isReactWarning ? c.ref : (t = Object.getOwnPropertyDescriptor(c, "ref") ? .get) && "isReactWarning" in t && t.isReactWarning ? c.props.ref : c.props.ref || c.ref);
                return "function" == typeof i || u.isPresent ? o.cloneElement(c, {
                    ref: s
                }) : null
            };

            function X(e) {
                return e ? .animationName || "none"
            }
            K.displayName = "Presence";
            var q = o.forwardRef((e, t) => (0, s.jsx)(E.span, { ...e,
                ref: t,
                style: {
                    position: "absolute",
                    border: 0,
                    width: 1,
                    height: 1,
                    padding: 0,
                    margin: -1,
                    overflow: "hidden",
                    clip: "rect(0, 0, 0, 0)",
                    whiteSpace: "nowrap",
                    wordWrap: "normal",
                    ...e.style
                }
            }));
            q.displayName = "VisuallyHidden";
            var [Z, $] = a("Tooltip", [P]), Q = P(), ee = "TooltipProvider", et = "tooltip.open", [en, er] = Z(ee), eo = e => {
                let {
                    __scopeTooltip: t,
                    delayDuration: n = 700,
                    skipDelayDuration: r = 300,
                    disableHoverableContent: i = !1,
                    children: u
                } = e, [c, l] = o.useState(!0), a = o.useRef(!1), f = o.useRef(0);
                return o.useEffect(() => {
                    let e = f.current;
                    return () => window.clearTimeout(e)
                }, []), (0, s.jsx)(en, {
                    scope: t,
                    isOpenDelayed: c,
                    delayDuration: n,
                    onOpen: o.useCallback(() => {
                        window.clearTimeout(f.current), l(!1)
                    }, []),
                    onClose: o.useCallback(() => {
                        window.clearTimeout(f.current), f.current = window.setTimeout(() => l(!0), r)
                    }, [r]),
                    isPointerInTransitRef: a,
                    onPointerInTransitChange: o.useCallback(e => {
                        a.current = e
                    }, []),
                    disableHoverableContent: i,
                    children: u
                })
            };
            eo.displayName = ee;
            var ei = "Tooltip",
                [eu, ec] = Z(ei),
                el = e => {
                    let {
                        __scopeTooltip: t,
                        children: n,
                        open: r,
                        defaultOpen: i = !1,
                        onOpenChange: u,
                        disableHoverableContent: c,
                        delayDuration: l
                    } = e, a = er(ei, e.__scopeTooltip), f = Q(t), [d, p] = o.useState(null), m = function(e) {
                        let [t, n] = o.useState(x());
                        return w(() => {
                            n(e => e ? ? String(O++))
                        }, [void 0]), t ? `radix-${t}` : ""
                    }(), h = o.useRef(0), E = c ? ? a.disableHoverableContent, v = l ? ? a.delayDuration, b = o.useRef(!1), [y = !1, T] = function({
                        prop: e,
                        defaultProp: t,
                        onChange: n = () => {}
                    }) {
                        let [r, i] = function({
                            defaultProp: e,
                            onChange: t
                        }) {
                            let n = o.useState(e),
                                [r] = n,
                                i = o.useRef(r),
                                u = g(t);
                            return o.useEffect(() => {
                                i.current !== r && (u(r), i.current = r)
                            }, [r, i, u]), n
                        }({
                            defaultProp: t,
                            onChange: n
                        }), u = void 0 !== e, c = u ? e : r, l = g(n);
                        return [c, o.useCallback(t => {
                            if (u) {
                                let n = "function" == typeof t ? t(e) : t;
                                n !== e && l(n)
                            } else i(t)
                        }, [u, e, i, l])]
                    }({
                        prop: r,
                        defaultProp: i,
                        onChange: e => {
                            e ? (a.onOpen(), document.dispatchEvent(new CustomEvent(et))) : a.onClose(), u ? .(e)
                        }
                    }), _ = o.useMemo(() => y ? b.current ? "delayed-open" : "instant-open" : "closed", [y]), S = o.useCallback(() => {
                        window.clearTimeout(h.current), b.current = !1, T(!0)
                    }, [T]), C = o.useCallback(() => {
                        window.clearTimeout(h.current), T(!1)
                    }, [T]), R = o.useCallback(() => {
                        window.clearTimeout(h.current), h.current = window.setTimeout(() => {
                            b.current = !0, T(!0)
                        }, v)
                    }, [v, T]);
                    return o.useEffect(() => () => window.clearTimeout(h.current), []), (0, s.jsx)(j, { ...f,
                        children: (0, s.jsx)(eu, {
                            scope: t,
                            contentId: m,
                            open: y,
                            stateAttribute: _,
                            trigger: d,
                            onTriggerChange: p,
                            onTriggerEnter: o.useCallback(() => {
                                a.isOpenDelayed ? R() : S()
                            }, [a.isOpenDelayed, R, S]),
                            onTriggerLeave: o.useCallback(() => {
                                E ? C() : window.clearTimeout(h.current)
                            }, [C, E]),
                            onOpen: S,
                            onClose: C,
                            disableHoverableContent: E,
                            children: n
                        })
                    })
                };
            el.displayName = ei;
            var es = "TooltipTrigger",
                ea = o.forwardRef((e, t) => {
                    let {
                        __scopeTooltip: n,
                        ...r
                    } = e, i = ec(es, n), c = er(es, n), a = Q(n), f = l(t, o.useRef(null), i.onTriggerChange), d = o.useRef(!1), p = o.useRef(!1), m = o.useCallback(() => d.current = !1, []);
                    return o.useEffect(() => () => document.removeEventListener("pointerup", m), [m]), (0, s.jsx)(D, {
                        asChild: !0,
                        ...a,
                        children: (0, s.jsx)(E.button, {
                            "aria-describedby": i.open ? i.contentId : void 0,
                            "data-state": i.stateAttribute,
                            ...r,
                            ref: f,
                            onPointerMove: u(e.onPointerMove, e => {
                                "touch" === e.pointerType || p.current || c.isPointerInTransitRef.current || (i.onTriggerEnter(), p.current = !0)
                            }),
                            onPointerLeave: u(e.onPointerLeave, () => {
                                i.onTriggerLeave(), p.current = !1
                            }),
                            onPointerDown: u(e.onPointerDown, () => {
                                d.current = !0, document.addEventListener("pointerup", m, {
                                    once: !0
                                })
                            }),
                            onFocus: u(e.onFocus, () => {
                                d.current || i.onOpen()
                            }),
                            onBlur: u(e.onBlur, i.onClose),
                            onClick: u(e.onClick, i.onClose)
                        })
                    })
                });
            ea.displayName = es;
            var ef = "TooltipPortal",
                [ed, ep] = Z(ef, {
                    forceMount: void 0
                }),
                em = e => {
                    let {
                        __scopeTooltip: t,
                        forceMount: n,
                        children: r,
                        container: o
                    } = e, i = ec(ef, t);
                    return (0, s.jsx)(ed, {
                        scope: t,
                        forceMount: n,
                        children: (0, s.jsx)(K, {
                            present: n || i.open,
                            children: (0, s.jsx)(W, {
                                asChild: !0,
                                container: o,
                                children: r
                            })
                        })
                    })
                };
            em.displayName = ef;
            var eh = "TooltipContent",
                eE = o.forwardRef((e, t) => {
                    let n = ep(eh, e.__scopeTooltip),
                        {
                            forceMount: r = n.forceMount,
                            side: o = "top",
                            ...i
                        } = e,
                        u = ec(eh, e.__scopeTooltip);
                    return (0, s.jsx)(K, {
                        present: r || u.open,
                        children: u.disableHoverableContent ? (0, s.jsx)(ey, {
                            side: o,
                            ...i,
                            ref: t
                        }) : (0, s.jsx)(eg, {
                            side: o,
                            ...i,
                            ref: t
                        })
                    })
                }),
                eg = o.forwardRef((e, t) => {
                    let n = ec(eh, e.__scopeTooltip),
                        r = er(eh, e.__scopeTooltip),
                        i = o.useRef(null),
                        u = l(t, i),
                        [c, a] = o.useState(null),
                        {
                            trigger: f,
                            onClose: d
                        } = n,
                        p = i.current,
                        {
                            onPointerInTransitChange: m
                        } = r,
                        h = o.useCallback(() => {
                            a(null), m(!1)
                        }, [m]),
                        E = o.useCallback((e, t) => {
                            let n = e.currentTarget,
                                r = {
                                    x: e.clientX,
                                    y: e.clientY
                                },
                                o = function(e, t) {
                                    let n = Math.abs(t.top - e.y),
                                        r = Math.abs(t.bottom - e.y),
                                        o = Math.abs(t.right - e.x),
                                        i = Math.abs(t.left - e.x);
                                    switch (Math.min(n, r, o, i)) {
                                        case i:
                                            return "left";
                                        case o:
                                            return "right";
                                        case n:
                                            return "top";
                                        case r:
                                            return "bottom";
                                        default:
                                            throw Error("unreachable")
                                    }
                                }(r, n.getBoundingClientRect());
                            a(function(e) {
                                let t = e.slice();
                                return t.sort((e, t) => e.x < t.x ? -1 : e.x > t.x ? 1 : e.y < t.y ? -1 : e.y > t.y ? 1 : 0),
                                    function(e) {
                                        if (e.length <= 1) return e.slice();
                                        let t = [];
                                        for (let n = 0; n < e.length; n++) {
                                            let r = e[n];
                                            for (; t.length >= 2;) {
                                                let e = t[t.length - 1],
                                                    n = t[t.length - 2];
                                                if ((e.x - n.x) * (r.y - n.y) >= (e.y - n.y) * (r.x - n.x)) t.pop();
                                                else break
                                            }
                                            t.push(r)
                                        }
                                        t.pop();
                                        let n = [];
                                        for (let t = e.length - 1; t >= 0; t--) {
                                            let r = e[t];
                                            for (; n.length >= 2;) {
                                                let e = n[n.length - 1],
                                                    t = n[n.length - 2];
                                                if ((e.x - t.x) * (r.y - t.y) >= (e.y - t.y) * (r.x - t.x)) n.pop();
                                                else break
                                            }
                                            n.push(r)
                                        }
                                        return (n.pop(), 1 === t.length && 1 === n.length && t[0].x === n[0].x && t[0].y === n[0].y) ? t : t.concat(n)
                                    }(t)
                            }([... function(e, t, n = 5) {
                                let r = [];
                                switch (t) {
                                    case "top":
                                        r.push({
                                            x: e.x - n,
                                            y: e.y + n
                                        }, {
                                            x: e.x + n,
                                            y: e.y + n
                                        });
                                        break;
                                    case "bottom":
                                        r.push({
                                            x: e.x - n,
                                            y: e.y - n
                                        }, {
                                            x: e.x + n,
                                            y: e.y - n
                                        });
                                        break;
                                    case "left":
                                        r.push({
                                            x: e.x + n,
                                            y: e.y - n
                                        }, {
                                            x: e.x + n,
                                            y: e.y + n
                                        });
                                        break;
                                    case "right":
                                        r.push({
                                            x: e.x - n,
                                            y: e.y - n
                                        }, {
                                            x: e.x - n,
                                            y: e.y + n
                                        })
                                }
                                return r
                            }(r, o), ... function(e) {
                                let {
                                    top: t,
                                    right: n,
                                    bottom: r,
                                    left: o
                                } = e;
                                return [{
                                    x: o,
                                    y: t
                                }, {
                                    x: n,
                                    y: t
                                }, {
                                    x: n,
                                    y: r
                                }, {
                                    x: o,
                                    y: r
                                }]
                            }(t.getBoundingClientRect())])), m(!0)
                        }, [m]);
                    return o.useEffect(() => () => h(), [h]), o.useEffect(() => {
                        if (f && p) {
                            let e = e => E(e, p),
                                t = e => E(e, f);
                            return f.addEventListener("pointerleave", e), p.addEventListener("pointerleave", t), () => {
                                f.removeEventListener("pointerleave", e), p.removeEventListener("pointerleave", t)
                            }
                        }
                    }, [f, p, E, h]), o.useEffect(() => {
                        if (c) {
                            let e = e => {
                                let t = e.target,
                                    n = {
                                        x: e.clientX,
                                        y: e.clientY
                                    },
                                    r = f ? .contains(t) || p ? .contains(t),
                                    o = ! function(e, t) {
                                        let {
                                            x: n,
                                            y: r
                                        } = e, o = !1;
                                        for (let e = 0, i = t.length - 1; e < t.length; i = e++) {
                                            let u = t[e].x,
                                                c = t[e].y,
                                                l = t[i].x,
                                                s = t[i].y;
                                            c > r != s > r && n < (l - u) * (r - c) / (s - c) + u && (o = !o)
                                        }
                                        return o
                                    }(n, c);
                                r ? h() : o && (h(), d())
                            };
                            return document.addEventListener("pointermove", e), () => document.removeEventListener("pointermove", e)
                        }
                    }, [f, p, c, d, h]), (0, s.jsx)(ey, { ...e,
                        ref: u
                    })
                }),
                [ev, eb] = Z(ei, {
                    isInside: !1
                }),
                ey = o.forwardRef((e, t) => {
                    let {
                        __scopeTooltip: n,
                        children: r,
                        "aria-label": i,
                        onEscapeKeyDown: u,
                        onPointerDownOutside: c,
                        ...l
                    } = e, a = ec(eh, n), f = Q(n), {
                        onClose: d
                    } = a;
                    return o.useEffect(() => (document.addEventListener(et, d), () => document.removeEventListener(et, d)), [d]), o.useEffect(() => {
                        if (a.trigger) {
                            let e = e => {
                                let t = e.target;
                                t ? .contains(a.trigger) && d()
                            };
                            return window.addEventListener("scroll", e, {
                                capture: !0
                            }), () => window.removeEventListener("scroll", e, {
                                capture: !0
                            })
                        }
                    }, [a.trigger, d]), (0, s.jsx)(y, {
                        asChild: !0,
                        disableOutsidePointerEvents: !1,
                        onEscapeKeyDown: u,
                        onPointerDownOutside: c,
                        onFocusOutside: e => e.preventDefault(),
                        onDismiss: d,
                        children: (0, s.jsxs)(F, {
                            "data-state": a.stateAttribute,
                            ...f,
                            ...l,
                            ref: t,
                            style: { ...l.style,
                                "--radix-tooltip-content-transform-origin": "var(--radix-popper-transform-origin)",
                                "--radix-tooltip-content-available-width": "var(--radix-popper-available-width)",
                                "--radix-tooltip-content-available-height": "var(--radix-popper-available-height)",
                                "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
                                "--radix-tooltip-trigger-height": "var(--radix-popper-anchor-height)"
                            },
                            children: [(0, s.jsx)(m, {
                                children: r
                            }), (0, s.jsx)(ev, {
                                scope: n,
                                isInside: !0,
                                children: (0, s.jsx)(q, {
                                    id: a.contentId,
                                    role: "tooltip",
                                    children: i || r
                                })
                            })]
                        })
                    })
                });
            eE.displayName = eh;
            var eT = "TooltipArrow",
                e_ = o.forwardRef((e, t) => {
                    let {
                        __scopeTooltip: n,
                        ...r
                    } = e, o = Q(n);
                    return eb(eT, n).isInside ? null : (0, s.jsx)(B, { ...o,
                        ...r,
                        ref: t
                    })
                });
            e_.displayName = eT;
            var ew = el,
                ex = ea,
                eO = em,
                eS = eE,
                eC = e_
        },
        44466: function(e, t, n) {
            "use strict";
            n.d(t, {
                T: function() {
                    return c
                }
            });
            var r = n(87462),
                o = n(67294);
            n(73935);
            var i = n(4222);
            let u = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = (0, o.forwardRef)((e, n) => {
                        let {
                            asChild: u,
                            ...c
                        } = e, l = u ? i.g7 : t;
                        return (0, o.useEffect)(() => {
                            window[Symbol.for("radix-ui")] = !0
                        }, []), (0, o.createElement)(l, (0, r.Z)({}, c, {
                            ref: n
                        }))
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {}),
                c = (0, o.forwardRef)((e, t) => (0, o.createElement)(u.span, (0, r.Z)({}, e, {
                    ref: t,
                    style: {
                        position: "absolute",
                        border: 0,
                        width: 1,
                        height: 1,
                        padding: 0,
                        margin: -1,
                        overflow: "hidden",
                        clip: "rect(0, 0, 0, 0)",
                        whiteSpace: "nowrap",
                        wordWrap: "normal",
                        ...e.style
                    }
                })))
        },
        90512: function(e, t, n) {
            "use strict";

            function r() {
                for (var e, t, n = 0, r = ""; n < arguments.length;)(e = arguments[n++]) && (t = function e(t) {
                    var n, r, o = "";
                    if ("string" == typeof t || "number" == typeof t) o += t;
                    else if ("object" == typeof t) {
                        if (Array.isArray(t))
                            for (n = 0; n < t.length; n++) t[n] && (r = e(t[n])) && (o && (o += " "), o += r);
                        else
                            for (n in t) t[n] && (o && (o += " "), o += n)
                    }
                    return o
                }(e)) && (r && (r += " "), r += t);
                return r
            }
            n.d(t, {
                W: function() {
                    return r
                }
            }), t.Z = r
        },
        97582: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                __addDisposableResource: function() {
                    return j
                },
                __assign: function() {
                    return i
                },
                __asyncDelegator: function() {
                    return O
                },
                __asyncGenerator: function() {
                    return x
                },
                __asyncValues: function() {
                    return S
                },
                __await: function() {
                    return w
                },
                __awaiter: function() {
                    return m
                },
                __classPrivateFieldGet: function() {
                    return P
                },
                __classPrivateFieldIn: function() {
                    return L
                },
                __classPrivateFieldSet: function() {
                    return I
                },
                __createBinding: function() {
                    return E
                },
                __decorate: function() {
                    return c
                },
                __disposeResources: function() {
                    return D
                },
                __esDecorate: function() {
                    return s
                },
                __exportStar: function() {
                    return g
                },
                __extends: function() {
                    return o
                },
                __generator: function() {
                    return h
                },
                __importDefault: function() {
                    return N
                },
                __importStar: function() {
                    return A
                },
                __makeTemplateObject: function() {
                    return C
                },
                __metadata: function() {
                    return p
                },
                __param: function() {
                    return l
                },
                __propKey: function() {
                    return f
                },
                __read: function() {
                    return b
                },
                __rest: function() {
                    return u
                },
                __runInitializers: function() {
                    return a
                },
                __setFunctionName: function() {
                    return d
                },
                __spread: function() {
                    return y
                },
                __spreadArray: function() {
                    return _
                },
                __spreadArrays: function() {
                    return T
                },
                __values: function() {
                    return v
                }
            });
            var r = function(e, t) {
                return (r = Object.setPrototypeOf || ({
                    __proto__: []
                }) instanceof Array && function(e, t) {
                    e.__proto__ = t
                } || function(e, t) {
                    for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                })(e, t)
            };

            function o(e, t) {
                if ("function" != typeof t && null !== t) throw TypeError("Class extends value " + String(t) + " is not a constructor or null");

                function n() {
                    this.constructor = e
                }
                r(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            }
            var i = function() {
                return (i = Object.assign || function(e) {
                    for (var t, n = 1, r = arguments.length; n < r; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            };

            function u(e, t) {
                var n = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && 0 > t.indexOf(r) && (n[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) 0 > t.indexOf(r[o]) && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]]);
                return n
            }

            function c(e, t, n, r) {
                var o, i = arguments.length,
                    u = i < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, n, r);
                else
                    for (var c = e.length - 1; c >= 0; c--)(o = e[c]) && (u = (i < 3 ? o(u) : i > 3 ? o(t, n, u) : o(t, n)) || u);
                return i > 3 && u && Object.defineProperty(t, n, u), u
            }

            function l(e, t) {
                return function(n, r) {
                    t(n, r, e)
                }
            }

            function s(e, t, n, r, o, i) {
                function u(e) {
                    if (void 0 !== e && "function" != typeof e) throw TypeError("Function expected");
                    return e
                }
                for (var c, l = r.kind, s = "getter" === l ? "get" : "setter" === l ? "set" : "value", a = !t && e ? r.static ? e : e.prototype : null, f = t || (a ? Object.getOwnPropertyDescriptor(a, r.name) : {}), d = !1, p = n.length - 1; p >= 0; p--) {
                    var m = {};
                    for (var h in r) m[h] = "access" === h ? {} : r[h];
                    for (var h in r.access) m.access[h] = r.access[h];
                    m.addInitializer = function(e) {
                        if (d) throw TypeError("Cannot add initializers after decoration has completed");
                        i.push(u(e || null))
                    };
                    var E = (0, n[p])("accessor" === l ? {
                        get: f.get,
                        set: f.set
                    } : f[s], m);
                    if ("accessor" === l) {
                        if (void 0 === E) continue;
                        if (null === E || "object" != typeof E) throw TypeError("Object expected");
                        (c = u(E.get)) && (f.get = c), (c = u(E.set)) && (f.set = c), (c = u(E.init)) && o.unshift(c)
                    } else(c = u(E)) && ("field" === l ? o.unshift(c) : f[s] = c)
                }
                a && Object.defineProperty(a, r.name, f), d = !0
            }

            function a(e, t, n) {
                for (var r = arguments.length > 2, o = 0; o < t.length; o++) n = r ? t[o].call(e, n) : t[o].call(e);
                return r ? n : void 0
            }

            function f(e) {
                return "symbol" == typeof e ? e : "".concat(e)
            }

            function d(e, t, n) {
                return "symbol" == typeof t && (t = t.description ? "[".concat(t.description, "]") : ""), Object.defineProperty(e, "name", {
                    configurable: !0,
                    value: n ? "".concat(n, " ", t) : t
                })
            }

            function p(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t)
            }

            function m(e, t, n, r) {
                return new(n || (n = Promise))(function(o, i) {
                    function u(e) {
                        try {
                            l(r.next(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function c(e) {
                        try {
                            l(r.throw(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function l(e) {
                        var t;
                        e.done ? o(e.value) : ((t = e.value) instanceof n ? t : new n(function(e) {
                            e(t)
                        })).then(u, c)
                    }
                    l((r = r.apply(e, t || [])).next())
                })
            }

            function h(e, t) {
                var n, r, o, i, u = {
                    label: 0,
                    sent: function() {
                        if (1 & o[0]) throw o[1];
                        return o[1]
                    },
                    trys: [],
                    ops: []
                };
                return i = {
                    next: c(0),
                    throw: c(1),
                    return: c(2)
                }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                    return this
                }), i;

                function c(c) {
                    return function(l) {
                        return function(c) {
                            if (n) throw TypeError("Generator is already executing.");
                            for (; i && (i = 0, c[0] && (u = 0)), u;) try {
                                if (n = 1, r && (o = 2 & c[0] ? r.return : c[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, c[1])).done) return o;
                                switch (r = 0, o && (c = [2 & c[0], o.value]), c[0]) {
                                    case 0:
                                    case 1:
                                        o = c;
                                        break;
                                    case 4:
                                        return u.label++, {
                                            value: c[1],
                                            done: !1
                                        };
                                    case 5:
                                        u.label++, r = c[1], c = [0];
                                        continue;
                                    case 7:
                                        c = u.ops.pop(), u.trys.pop();
                                        continue;
                                    default:
                                        if (!(o = (o = u.trys).length > 0 && o[o.length - 1]) && (6 === c[0] || 2 === c[0])) {
                                            u = 0;
                                            continue
                                        }
                                        if (3 === c[0] && (!o || c[1] > o[0] && c[1] < o[3])) {
                                            u.label = c[1];
                                            break
                                        }
                                        if (6 === c[0] && u.label < o[1]) {
                                            u.label = o[1], o = c;
                                            break
                                        }
                                        if (o && u.label < o[2]) {
                                            u.label = o[2], u.ops.push(c);
                                            break
                                        }
                                        o[2] && u.ops.pop(), u.trys.pop();
                                        continue
                                }
                                c = t.call(e, u)
                            } catch (e) {
                                c = [6, e], r = 0
                            } finally {
                                n = o = 0
                            }
                            if (5 & c[0]) throw c[1];
                            return {
                                value: c[0] ? c[1] : void 0,
                                done: !0
                            }
                        }([c, l])
                    }
                }
            }
            var E = Object.create ? function(e, t, n, r) {
                void 0 === r && (r = n);
                var o = Object.getOwnPropertyDescriptor(t, n);
                (!o || ("get" in o ? !t.__esModule : o.writable || o.configurable)) && (o = {
                    enumerable: !0,
                    get: function() {
                        return t[n]
                    }
                }), Object.defineProperty(e, r, o)
            } : function(e, t, n, r) {
                void 0 === r && (r = n), e[r] = t[n]
            };

            function g(e, t) {
                for (var n in e) "default" === n || Object.prototype.hasOwnProperty.call(t, n) || E(t, e, n)
            }

            function v(e) {
                var t = "function" == typeof Symbol && Symbol.iterator,
                    n = t && e[t],
                    r = 0;
                if (n) return n.call(e);
                if (e && "number" == typeof e.length) return {
                    next: function() {
                        return e && r >= e.length && (e = void 0), {
                            value: e && e[r++],
                            done: !e
                        }
                    }
                };
                throw TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
            }

            function b(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var r, o, i = n.call(e),
                    u = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(r = i.next()).done;) u.push(r.value)
                } catch (e) {
                    o = {
                        error: e
                    }
                } finally {
                    try {
                        r && !r.done && (n = i.return) && n.call(i)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return u
            }

            function y() {
                for (var e = [], t = 0; t < arguments.length; t++) e = e.concat(b(arguments[t]));
                return e
            }

            function T() {
                for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
                for (var r = Array(e), o = 0, t = 0; t < n; t++)
                    for (var i = arguments[t], u = 0, c = i.length; u < c; u++, o++) r[o] = i[u];
                return r
            }

            function _(e, t, n) {
                if (n || 2 == arguments.length)
                    for (var r, o = 0, i = t.length; o < i; o++) !r && o in t || (r || (r = Array.prototype.slice.call(t, 0, o)), r[o] = t[o]);
                return e.concat(r || Array.prototype.slice.call(t))
            }

            function w(e) {
                return this instanceof w ? (this.v = e, this) : new w(e)
            }

            function x(e, t, n) {
                if (!Symbol.asyncIterator) throw TypeError("Symbol.asyncIterator is not defined.");
                var r, o = n.apply(e, t || []),
                    i = [];
                return r = {}, u("next"), u("throw"), u("return", function(e) {
                    return function(t) {
                        return Promise.resolve(t).then(e, s)
                    }
                }), r[Symbol.asyncIterator] = function() {
                    return this
                }, r;

                function u(e, t) {
                    o[e] && (r[e] = function(t) {
                        return new Promise(function(n, r) {
                            i.push([e, t, n, r]) > 1 || c(e, t)
                        })
                    }, t && (r[e] = t(r[e])))
                }

                function c(e, t) {
                    try {
                        var n;
                        (n = o[e](t)).value instanceof w ? Promise.resolve(n.value.v).then(l, s) : a(i[0][2], n)
                    } catch (e) {
                        a(i[0][3], e)
                    }
                }

                function l(e) {
                    c("next", e)
                }

                function s(e) {
                    c("throw", e)
                }

                function a(e, t) {
                    e(t), i.shift(), i.length && c(i[0][0], i[0][1])
                }
            }

            function O(e) {
                var t, n;
                return t = {}, r("next"), r("throw", function(e) {
                    throw e
                }), r("return"), t[Symbol.iterator] = function() {
                    return this
                }, t;

                function r(r, o) {
                    t[r] = e[r] ? function(t) {
                        return (n = !n) ? {
                            value: w(e[r](t)),
                            done: !1
                        } : o ? o(t) : t
                    } : o
                }
            }

            function S(e) {
                if (!Symbol.asyncIterator) throw TypeError("Symbol.asyncIterator is not defined.");
                var t, n = e[Symbol.asyncIterator];
                return n ? n.call(e) : (e = v(e), t = {}, r("next"), r("throw"), r("return"), t[Symbol.asyncIterator] = function() {
                    return this
                }, t);

                function r(n) {
                    t[n] = e[n] && function(t) {
                        return new Promise(function(r, o) {
                            ! function(e, t, n, r) {
                                Promise.resolve(r).then(function(t) {
                                    e({
                                        value: t,
                                        done: n
                                    })
                                }, t)
                            }(r, o, (t = e[n](t)).done, t.value)
                        })
                    }
                }
            }

            function C(e, t) {
                return Object.defineProperty ? Object.defineProperty(e, "raw", {
                    value: t
                }) : e.raw = t, e
            }
            var R = Object.create ? function(e, t) {
                Object.defineProperty(e, "default", {
                    enumerable: !0,
                    value: t
                })
            } : function(e, t) {
                e.default = t
            };

            function A(e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e)
                    for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && E(t, e, n);
                return R(t, e), t
            }

            function N(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }

            function P(e, t, n, r) {
                if ("a" === n && !r) throw TypeError("Private accessor was defined without a getter");
                if ("function" == typeof t ? e !== t || !r : !t.has(e)) throw TypeError("Cannot read private member from an object whose class did not declare it");
                return "m" === n ? r : "a" === n ? r.call(e) : r ? r.value : t.get(e)
            }

            function I(e, t, n, r, o) {
                if ("m" === r) throw TypeError("Private method is not writable");
                if ("a" === r && !o) throw TypeError("Private accessor was defined without a setter");
                if ("function" == typeof t ? e !== t || !o : !t.has(e)) throw TypeError("Cannot write private member to an object whose class did not declare it");
                return "a" === r ? o.call(e, n) : o ? o.value = n : t.set(e, n), n
            }

            function L(e, t) {
                if (null === t || "object" != typeof t && "function" != typeof t) throw TypeError("Cannot use 'in' operator on non-object");
                return "function" == typeof e ? t === e : e.has(t)
            }

            function j(e, t, n) {
                if (null != t) {
                    var r, o;
                    if ("object" != typeof t && "function" != typeof t) throw TypeError("Object expected.");
                    if (n) {
                        if (!Symbol.asyncDispose) throw TypeError("Symbol.asyncDispose is not defined.");
                        r = t[Symbol.asyncDispose]
                    }
                    if (void 0 === r) {
                        if (!Symbol.dispose) throw TypeError("Symbol.dispose is not defined.");
                        r = t[Symbol.dispose], n && (o = r)
                    }
                    if ("function" != typeof r) throw TypeError("Object not disposable.");
                    o && (r = function() {
                        try {
                            o.call(this)
                        } catch (e) {
                            return Promise.reject(e)
                        }
                    }), e.stack.push({
                        value: t,
                        dispose: r,
                        async: n
                    })
                } else n && e.stack.push({
                    async: !0
                });
                return t
            }
            var k = "function" == typeof SuppressedError ? SuppressedError : function(e, t, n) {
                var r = Error(n);
                return r.name = "SuppressedError", r.error = e, r.suppressed = t, r
            };

            function D(e) {
                function t(t) {
                    e.error = e.hasError ? new k(t, e.error, "An error was suppressed during disposal.") : t, e.hasError = !0
                }
                return function n() {
                    for (; e.stack.length;) {
                        var r = e.stack.pop();
                        try {
                            var o = r.dispose && r.dispose.call(r.value);
                            if (r.async) return Promise.resolve(o).then(n, function(e) {
                                return t(e), n()
                            })
                        } catch (e) {
                            t(e)
                        }
                    }
                    if (e.hasError) throw e.error
                }()
            }
            t.default = {
                __extends: o,
                __assign: i,
                __rest: u,
                __decorate: c,
                __param: l,
                __metadata: p,
                __awaiter: m,
                __generator: h,
                __createBinding: E,
                __exportStar: g,
                __values: v,
                __read: b,
                __spread: y,
                __spreadArrays: T,
                __spreadArray: _,
                __await: w,
                __asyncGenerator: x,
                __asyncDelegator: O,
                __asyncValues: S,
                __makeTemplateObject: C,
                __importStar: A,
                __importDefault: N,
                __classPrivateFieldGet: P,
                __classPrivateFieldSet: I,
                __classPrivateFieldIn: L,
                __addDisposableResource: j,
                __disposeResources: D
            }
        }
    },
    function(e) {
        var t = function(t) {
            return e(e.s = t)
        };
        e.O(0, [9774, 179], function() {
            return t(6840), t(26036)
        }), _N_E = e.O()
    }
]);