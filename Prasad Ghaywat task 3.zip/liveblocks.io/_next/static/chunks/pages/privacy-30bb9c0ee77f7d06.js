(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4970], {
        54248: function(e, n, r) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/privacy", function() {
                return r(53068)
            }])
        },
        12191: function(e, n, r) {
            "use strict";
            r.d(n, {
                xr: function() {
                    return d
                }
            });
            var o = r(85893),
                t = r(70699),
                i = r(93967),
                s = r.n(i),
                a = r(67294),
                c = r(34337),
                l = r.n(c);
            let d = (0, a.forwardRef)((e, n) => {
                    let {
                        children: r,
                        orientation: t = "both",
                        viewportRef: i,
                        ...s
                    } = e;
                    return (0, o.jsxs)(u, { ...s,
                        ref: n,
                        children: [(0, o.jsx)(h, {
                            ref: i,
                            children: r
                        }), ("vertical" === t || "both" === t) && (0, o.jsx)(p, {
                            orientation: "vertical",
                            children: (0, o.jsx)(f, {})
                        }), ("horizontal" === t || "both" === t) && (0, o.jsx)(p, {
                            orientation: "horizontal",
                            children: (0, o.jsx)(f, {})
                        })]
                    })
                }),
                u = (0, a.forwardRef)((e, n) => {
                    let {
                        children: r,
                        style: i,
                        ...s
                    } = e;
                    return (0, o.jsx)(t.fC, { ...s,
                        ref: n,
                        style: { ...i,
                            overflow: "hidden"
                        },
                        children: r
                    })
                }),
                h = (0, a.forwardRef)((e, n) => {
                    let {
                        children: r,
                        className: i,
                        ...a
                    } = e;
                    return (0, o.jsx)(t.l_, { ...a,
                        ref: n,
                        className: s()(i, l().viewport),
                        children: r
                    })
                }),
                p = (0, a.forwardRef)((e, n) => {
                    let {
                        children: r,
                        className: i,
                        ...a
                    } = e;
                    return (0, o.jsx)(t.LW, { ...a,
                        ref: n,
                        className: s()(i, l().scrollbar, "z-20"),
                        children: r
                    })
                }),
                f = (0, a.forwardRef)((e, n) => {
                    let {
                        className: r,
                        ...i
                    } = e;
                    return (0, o.jsx)(t.bU, { ...i,
                        ref: n,
                        className: s()(r, l().thumb)
                    })
                })
        },
        61205: function(e, n, r) {
            "use strict";
            r.d(n, {
                xr: function() {
                    return o.xr
                }
            });
            var o = r(12191)
        },
        12009: function(e, n, r) {
            "use strict";
            r.d(n, {
                IH: function() {
                    return t
                },
                _d: function() {
                    return s
                },
                bk: function() {
                    return i
                }
            });
            var o = r(29724);

            function t(e) {
                return "var(--".concat(o.VARIABLE_PREFIX, "-").concat(e.replaceAll(".", "-"), ")")
            }

            function i(e) {
                return "var(--".concat(o.VARIABLE_PREFIX, "-marketing-").concat(e.replaceAll(".", "-"), ")")
            }

            function s(e) {
                return "var(--".concat(o.VARIABLE_PREFIX, "-product-").concat(e.replaceAll(".", "-"), ")")
            }
        },
        29724: function(e) {
            "use strict";
            let n = "DEFAULT";

            function r() {
                for (var e = arguments.length, n = Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                return n.filter(e => e).join("-")
            }

            function o(e, n, r, o) {
                var t, i;
                for (let [s, a] of Object.entries(null !== (i = null == e ? void 0 : null === (t = e[n]) || void 0 === t ? void 0 : t[r]) && void 0 !== i ? i : {})) ! function e(n, r) {
                    let t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
                    if (function(e) {
                            let n = Object.keys(null != e ? e : {}),
                                r = 1 === n.length && (e.light || e.dark),
                                o = 2 === n.length && e.light && e.dark;
                            return r || o
                        }(r)) o([...t, n], r.light, r.dark);
                    else
                        for (let [o, i] of Object.entries(null != r ? r : {})) e(o, i, [...t, n])
                }(s, a)
            }

            function t(e) {
                return Array.isArray(e) ? r(...e.filter((r, o) => o !== e.length - 1 || r !== n)) : e
            }

            function i(e, n, o, i) {
                let s = "--".concat(r("lb", e, n, o));
                return r(s, t(i))
            }
            e.exports = {
                VARIABLE_PREFIX: "lb",
                DEFAULT_TOKEN: n,
                generateCSSVariables: function(e, n, r) {
                    let t = {},
                        s = {};
                    return o(e, n, r, (o, a, c) => {
                        let l = i(e.domain, n, r, o);
                        a && (t[l] = a), c && (s[l] = c)
                    }), {
                        light: t,
                        dark: s
                    }
                },
                generateTailwindValues: function(e, n, s) {
                    let a = {};
                    return o(e, n, s, o => {
                        let c = r(e.domain, t(o)),
                            l = i(e.domain, n, s, o);
                        a[c] = "var(".concat(l, ")")
                    }), a
                }
            }
        },
        92690: function(e, n, r) {
            "use strict";
            async function o(e) {
                if (!navigator.clipboard) return function(e) {
                    let n = document.createElement("textarea");
                    n.value = e, n.style.top = "0", n.style.left = "0", n.style.position = "fixed", document.body.appendChild(n), n.focus(), n.select();
                    try {
                        return document.execCommand("copy"), document.body.removeChild(n), !0
                    } catch (e) {
                        return document.body.removeChild(n), !1
                    }
                }(e);
                try {
                    return await navigator.clipboard.writeText(e), !0
                } catch (e) {
                    return !1
                }
            }
            r.d(n, {
                Z: function() {
                    return o
                }
            })
        },
        78769: function(e, n, r) {
            "use strict";
            r.d(n, {
                Z: function() {
                    return s
                }
            });
            var o = r(85893);
            r(67294);
            var t = r(83492),
                i = r(49329);

            function s(e) {
                let {
                    meta: n,
                    children: r
                } = e, s = n.parentTitle ? "".concat(n.parentTitle, " - ").concat(n.title) : n.title;
                return (0, o.jsx)(t.Z, {
                    prefixTitle: s,
                    description: n.description,
                    canonicalPath: n.canonicalPath,
                    children: (0, o.jsx)("section", {
                        className: "py-marketing-spacing-xl",
                        children: (0, o.jsx)(i.Z, {
                            hasGrid: !0,
                            children: (0, o.jsxs)("div", {
                                className: "col-span-12 sm:col-span-10 sm:col-start-2 lg:col-span-8 lg:col-start-3",
                                children: [(0, o.jsxs)("div", {
                                    children: [(0, o.jsxs)("h1", {
                                        className: "f-marketing-display-xl flex flex-col text-center",
                                        children: [n.parentTitle && (0, o.jsxs)("span", {
                                            className: "mb-3 rounded-full py-1 text-base text-marketing-brand",
                                            children: [n.parentTitle, (0, o.jsx)("span", {
                                                className: "pointer-events-none opacity-0",
                                                children: " - "
                                            })]
                                        }), (0, o.jsx)("span", {
                                            children: n.title
                                        })]
                                    }), (0, o.jsx)("div", {
                                        className: "bg-marketing-gradient-brand my-marketing-spacing-sm mx-auto h-px w-12"
                                    })]
                                }), (0, o.jsx)("div", {
                                    className: "markdown",
                                    children: r
                                })]
                            })
                        })
                    })
                })
            }
        },
        53068: function(e, n, r) {
            "use strict";
            r.r(n);
            var o = r(85893),
                t = r(11151),
                i = r(16003),
                s = r(78769);
            let a = e => {
                let {
                    children: n
                } = e;
                return (0, o.jsx)(s.Z, {
                    meta: {
                        title: "Privacy Policy",
                        description: "Build amazing realtime collaborative products with ".concat(i.pB),
                        canonicalPath: i.qk.PRIVACY
                    },
                    children: n
                })
            };

            function c(e) {
                let n = Object.assign({
                    p: "p",
                    em: "em",
                    h3: "h3",
                    strong: "strong",
                    ul: "ul",
                    li: "li",
                    a: "a",
                    table: "table",
                    thead: "thead",
                    tr: "tr",
                    th: "th",
                    tbody: "tbody",
                    td: "td"
                }, (0, t.ah)(), e.components);
                return (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsx)(n.p, {
                        children: (0, o.jsx)(n.em, {
                            children: "Last updated: September 15th, 2021"
                        })
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "Liveblocks, Inc. (“Liveblocks”, “we”, “us”, “our”) takes your privacy seriously.\nThis Privacy Policy describes how we collect, use and share personal information\nin connection with your use of the website (the “Service” or “Services”)."
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "We provide additional information for European residents below."
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "Personal-Information-We-Collect",
                        children: "Personal Information We Collect"
                    }), "\n", (0, o.jsx)(n.p, {
                        children: (0, o.jsx)(n.strong, {
                            children: "Information you provide to us."
                        })
                    }), "\n", (0, o.jsxs)(n.ul, {
                        children: ["\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Account information"
                            }), ", such as your first and last name, email and mailing\naddresses, phone number and date of birth."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Communications"
                            }), " that we exchange with you, including when you contact us\nwith questions, feedback, comments or otherwise."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Payment data"
                            }), " needed to complete your orders on or through the Services."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Marketing data"
                            }), ", such as your preferences for receiving our marketing\ncommunications, and details about your engagement with them."]
                        }), "\n"]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Automatic data collection."
                        }), " We and our service providers may automatically\nlog information about you, your computer or mobile device, and your interaction\nover time with the Services, our communications and other online services, such\nas:"]
                    }), "\n", (0, o.jsxs)(n.ul, {
                        children: ["\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Device data"
                            }), ", such as your computer’s or mobile device’s operating system\ntype and version, manufacturer and model, browser type, screen resolution, RAM\nand disk size, CPU usage, device type (e.g., phone, tablet), IP address,\nunique identifiers (including identifiers used for advertising purposes),\nlanguage settings, mobile device carrier, radio/network information (e.g.,\nWiFi, LTE, 3G), and general location information such as city, state or\ngeographic area."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Online activity data"
                            }), ", such as pages or screens you viewed, how long you\nspent on a page or screen, the website you visited before browsing to the\nwebsite, navigation paths between pages or screens, information about your\nactivity on a page or screen, access times, and duration of access, and\nwhether you have opened our marketing emails or clicked links within them."]
                        }), "\n"]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Cookies and similar technologies."
                        }), " Our website may use the following\ntechnologies:"]
                    }), "\n", (0, o.jsxs)(n.ul, {
                        children: ["\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Cookies"
                            }), ", which are text files that websites store on a visitor‘s device to\nuniquely identify the visitor’s browser or to store information or settings in\nthe browser for the purpose of helping you navigate between pages efficiently,\nremembering your preferences, enabling functionality, helping us understand\nuser activity and patterns, and facilitating online advertising."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Local storage technologies"
                            }), ", like HTML5, that provide cookie-equivalent\nfunctionality but can store larger amounts of data, including on your device\noutside of your browser in connection with specific applications."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Web beacons"
                            }), ", also known as pixel tags or clear GIFs, which are used to\ndemonstrate that a webpage or email was accessed or opened, or that certain\ncontent was viewed or clicked."]
                        }), "\n"]
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "How-We-Use-Personal-Information",
                        children: "How We Use Personal Information"
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "We use personal information for the following purposes:"
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Services delivery"
                        }), ", to:"]
                    }), "\n", (0, o.jsxs)(n.ul, {
                        children: ["\n", (0, o.jsx)(n.li, {
                            children: "Provide, operate and improve the Services;"
                        }), "\n", (0, o.jsx)(n.li, {
                            children: "Process your payments and complete our transactions with you;"
                        }), "\n", (0, o.jsx)(n.li, {
                            children: "Communicate with you about the Services, including by sending announcements,\nupdates, security alerts, and support and administrative messages;"
                        }), "\n", (0, o.jsx)(n.li, {
                            children: "Understand your needs and interests, and personalize your experience with the\nServices and our communications; and"
                        }), "\n", (0, o.jsx)(n.li, {
                            children: "Provide support for the Services, and respond to your requests, questions and\nfeedback."
                        }), "\n"]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Research and development."
                        }), " We may create aggregated, de-identified or other\nanonymous data from personal information we collect. We may use this anonymous\ndata and share it with third parties for our lawful business purposes."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Marketing."
                        }), " We may use personal information for our marketing and purposes,\nincluding:"]
                    }), "\n", (0, o.jsxs)(n.ul, {
                        children: ["\n", (0, o.jsx)(n.li, {
                            children: "Direct marketing. We may send you direct marketing communications as permitted\nby law. You may opt out of our marketing communications as described in the\n“Opt out of marketing communications” section below."
                        }), "\n"]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Compliance and protection."
                        }), " We may use your personal information to:"]
                    }), "\n", (0, o.jsxs)(n.ul, {
                        children: ["\n", (0, o.jsx)(n.li, {
                            children: "Comply with applicable laws, lawful requests, and legal process, such as to\nrespond to subpoenas or requests from government authorities;"
                        }), "\n", (0, o.jsx)(n.li, {
                            children: "Protect our, your or others’ rights, privacy, safety or property (including by\nmaking and defending legal claims);"
                        }), "\n", (0, o.jsx)(n.li, {
                            children: "Audit our internal processes for compliance with legal and contractual\nrequirements and internal policies;"
                        }), "\n", (0, o.jsx)(n.li, {
                            children: "Enforce the terms and conditions that govern the Services; and"
                        }), "\n", (0, o.jsx)(n.li, {
                            children: "Prevent, identify, investigate and deter fraudulent, harmful, unauthorized,\nunethical or illegal activity, including cyberattacks and identity theft."
                        }), "\n"]
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "How-We-Share-Personal-Information",
                        children: "How We Share Personal Information"
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "We may share your personal information with:"
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Service providers."
                        }), " Companies and individuals that provide services on our\nbehalf or help us operate the Services (such as hosting, information technology,\ncustomer support, payment processors, email delivery, and website analytics\nservices)."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Professional advisors."
                        }), " Professional advisors, such as lawyers, auditors,\nbankers and insurers, where necessary in the course of the professional services\nthat they render to us."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Authorities and others."
                        }), " Law enforcement, government authorities, and private\nparties, as we believe in good faith to be necessary for the compliance and\nprotection purposes described above."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Business transferees."
                        }), " Acquirers and other relevant participants in business\ntransactions (or negotiations for such transactions) involving a corporate\ndivestiture, merger, consolidation, acquisition, reorganization, sale or other\ndisposition of all or any portion of the business or assets of, or equity\ninterests in, our business (including, in connection with a bankruptcy or\nsimilar proceedings)."]
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "Please keep in mind that whenever you voluntarily make your personal information\navailable for viewing by third parties or the public on or through our Services,\nthat information can be seen, collected and used by others. We are not\nresponsible for any use of such information by others."
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "Your-Choices",
                        children: "Your Choices"
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Access to information."
                        }), " You may update or correct your information by\naccessing the account you have established with us on the Services."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Opt out of marketing communications."
                        }), " You may opt out of marketing-related\ncommunications by following the opt out or unsubscribe instructions contained in\nthe marketing communication we send you."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Blocking cookies in your browser."
                        }), " Most browsers let you remove or reject\ncookies. To do this, follow the instructions in your browser settings. Many\nbrowsers accept cookies by default until you change your settings. For more\ninformation about cookies, including how to see what cookies have been set on\nyour device and how to manage and delete them, visit\n", (0, o.jsx)(n.a, {
                            href: "https://www.allaboutcookies.org/",
                            rel: "nofollow",
                            children: "https://www.allaboutcookies.org/"
                        }), "."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Do Not Track."
                        }), ' Some Internet browsers may be configured to send “Do Not\nTrack” signals to the online services that you visit. We currently do not\nrespond to "Do Not Track" or similar signals. To find out more about "Do Not\nTrack," please visit ', (0, o.jsx)(n.a, {
                            href: "http://www.allaboutdnt.com",
                            rel: "nofollow",
                            children: "http://www.allaboutdnt.com"
                        }), "."]
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "Other-Sites-and-Services",
                        children: "Other Sites and Services"
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "The Services may contain links to websites and other online services operated by\nthird parties. In addition, our content may be integrated into web pages or\nother online services that are not associated with us. These links and\nintegrations are not an endorsement of, or representation that we are affiliated\nwith, any third party. We do not control websites or online services operated by\nthird parties, and we are not responsible for their actions."
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "Processing-of-Personal-Information-in-the-U.S.",
                        children: "Processing of Personal Information in the U.S."
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "We are headquartered in the United States with affiliates and services providers\nthat operate in other countries. Your personal information may therefore be\nprocessed in the United States or transferred to other locations."
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "Security",
                        children: "Security"
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "We employ a number of technical, organizational and physical safeguards designed\nto protect the personal information we collect. However, no security measures\nare failsafe and we cannot guarantee the security of your personal information."
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "Children",
                        children: "Children"
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "The Services is not intended for use by children under 13 years of age. If we\nlearn that we have collected personal information through the Services from a\nchild under 13 without the consent of the child’s parent or guardian as required\nby law, we will delete it."
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "Notice-to-European-Residents",
                        children: "Notice to European Residents"
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Controller."
                        }), " Liveblocks is the controller of your personal information\ncovered by this Privacy Policy for purposes of European data protection\nlegislation."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Legal basis for processing."
                        }), " We use your personal information only as\npermitted by law. Our legal bases for processing the personal information\ndescribed in this Privacy Policy are described in the table below."]
                    }), "\n", (0, o.jsxs)(n.table, {
                        children: [(0, o.jsx)(n.thead, {
                            children: (0, o.jsxs)(n.tr, {
                                children: [(0, o.jsx)(n.th, {
                                    children: "Processing Purpose"
                                }), (0, o.jsx)(n.th, {
                                    children: "GDPR Legal Basis"
                                })]
                            })
                        }), (0, o.jsxs)(n.tbody, {
                            children: [(0, o.jsxs)(n.tr, {
                                children: [(0, o.jsx)(n.td, {
                                    children: "Service delivery"
                                }), (0, o.jsx)(n.td, {
                                    children: "Processing is necessary to perform the contract governing our provision of our services or to take steps that you request prior to signing up for the Service. If we have not entered into a contract with you, we process your personal information based on our legitimate interest in providing the services you access and request."
                                })]
                            }), (0, o.jsxs)(n.tr, {
                                children: [(0, o.jsx)(n.td, {
                                    children: "Research and development, Marketing, Compliance and protection"
                                }), (0, o.jsx)(n.td, {
                                    children: "These activities constitute our legitimate interests. We do not use your personal information for these activities where our interests are overridden by the impact on you (unless we have your consent or are otherwise required or permitted to by law)."
                                })]
                            }), (0, o.jsxs)(n.tr, {
                                children: [(0, o.jsx)(n.td, {
                                    children: "Comply with law"
                                }), (0, o.jsx)(n.td, {
                                    children: "Processing is necessary to comply with our legal obligations"
                                })]
                            })]
                        })]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Use for new purposes."
                        }), " We may use your personal information for reasons not\ndescribed in this Privacy Policy where permitted by law and where the reason is\ncompatible with the purpose for which we collected it. If we need to use your\npersonal information for an unrelated purpose, we will notify you and explain\nthe applicable legal basis."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Sensitive personal information."
                        }), " We ask you not to provide any sensitive\npersonal information to us because we do not have the ability to identify or\noffer enhanced protections for sensitive personal information. If you choose to\nprovide us with any sensitive personal information, we will process it as\n“personal information” in accordance with this Privacy Policy."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Your rights."
                        }), " Data protection laws give you certain rights regarding your\npersonal information. If you are located in Europe, you may ask us to take the\nfollowing actions in relation to your personal information that we hold:"]
                    }), "\n", (0, o.jsxs)(n.ul, {
                        children: ["\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Access."
                            }), " Provide you with information about our processing of your personal\ninformation and give you access to your personal information."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Correct."
                            }), " Update or correct inaccuracies in your personal information."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Delete."
                            }), " Delete your personal information."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Transfer."
                            }), " Transfer a machine-readable copy of your personal information to\nyou or a third party of your choice."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Restrict."
                            }), " Restrict the processing of your personal information."]
                        }), "\n", (0, o.jsxs)(n.li, {
                            children: [(0, o.jsx)(n.strong, {
                                children: "Object."
                            }), " Object to our reliance on our legitimate interests as the basis of\nour processing of your personal information that impacts your rights."]
                        }), "\n"]
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "You may submit these requests by email or our postal address provided below."
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "We may request specific information from you to help us confirm your identity\nand process your request. Applicable law may require or permit us to decline\nyour request. If we decline your request, we will tell you why, subject to legal\nrestrictions. If you would like to submit a complaint about our use of your\npersonal information or our response to your requests regarding your personal\ninformation, you may contact us or submit a complaint to the data protection\nregulator in your jurisdiction. You can find your data protection regulator\nhere."
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Processing of personal information in the United States."
                        }), " To provide our\nservices we will process your personal information in the United States for the\npurposes we have set out in this Privacy Policy. If such processing involves the\ntransfer of personal information to the United States in a manner governed by\nEuropean data protection law, the transfer will be performed pursuant to the\napplicable requirements of the law, such as standard contractual clauses, the\nindividual’s consent, or in other circumstances permitted by European data\nprotection law."]
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: [(0, o.jsx)(n.strong, {
                            children: "Data retention."
                        }), " We retain personal information for as long as necessary to\nfulfill the purposes for which we collected it, including for the purposes of\nsatisfying any legal, accounting, or reporting requirements, to establish or\ndefend legal claims, or for fraud prevention purposes. When we have no ongoing\nlegitimate business need to process your personal information, we will either\ndelete or anonymize it or, if this is not possible (for example, because your\npersonal information has been stored in backup archives), then we will securely\nstore your personal information and isolate it from any further processing until\ndeletion is possible."]
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "Changes-to-This-Privacy-Policy",
                        children: "Changes to This Privacy Policy"
                    }), "\n", (0, o.jsx)(n.p, {
                        children: "We reserve the right to modify this Privacy Policy at any time. If we make\nmaterial changes to this Privacy Policy, we will notify you by updating the date\nof this Privacy Policy and posting it on the website."
                    }), "\n", (0, o.jsx)(n.h3, {
                        id: "How-to-Contact-Us",
                        children: "How to Contact Us"
                    }), "\n", (0, o.jsxs)(n.p, {
                        children: ["You can reach us by email at ", (0, o.jsx)(n.a, {
                            href: "mailto:hello@liveblocks.io",
                            children: "hello@liveblocks.io"
                        }), " or at the following mailing\naddress: 251 Little Falls Drive, Wilmington DE 19808"]
                    })]
                })
            }
            n.default = function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return (0, o.jsx)(a, Object.assign({}, e, {
                    children: (0, o.jsx)(c, e)
                }))
            }
        },
        34337: function(e) {
            e.exports = {
                viewport: "ScrollArea_viewport__RrP1h",
                scrollbar: "ScrollArea_scrollbar__LNuRt",
                thumb: "ScrollArea_thumb__RMi_2"
            }
        },
        11151: function(e, n, r) {
            "use strict";
            r.d(n, {
                NF: function() {
                    return i
                },
                Zo: function() {
                    return c
                },
                ah: function() {
                    return s
                },
                pC: function() {
                    return t
                }
            });
            var o = r(67294);
            let t = o.createContext({});

            function i(e) {
                return function(n) {
                    let r = s(n.components);
                    return o.createElement(e, { ...n,
                        allComponents: r
                    })
                }
            }

            function s(e) {
                let n = o.useContext(t);
                return o.useMemo(() => "function" == typeof e ? e(n) : { ...n,
                    ...e
                }, [n, e])
            }
            let a = {};

            function c({
                components: e,
                children: n,
                disableParentContext: r
            }) {
                let i;
                return i = r ? "function" == typeof e ? e({}) : e || a : s(e), o.createElement(t.Provider, {
                    value: i
                }, n)
            }
        }
    },
    function(e) {
        e.O(0, [3662, 4919, 3230, 1664, 7821, 1818, 2785, 3496, 5675, 6417, 7680, 297, 5889, 3492, 2888, 9774, 179], function() {
            return e(e.s = 54248)
        }), _N_E = e.O()
    }
]);