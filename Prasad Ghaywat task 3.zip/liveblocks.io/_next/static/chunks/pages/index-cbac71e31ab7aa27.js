(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5405], {
        16367: function(e, s, t) {
            "use strict";
            var a, i = t(67294);

            function n() {
                return (n = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            s.Z = function(e) {
                return i.createElement("svg", n({
                    "aria-hidden": "true",
                    focusable: "false",
                    width: 16,
                    height: 16,
                    viewBox: "0 0 16 16",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), a || (a = i.createElement("path", {
                    d: "M11.0007 8L6.00078 13L5.30078 12.3L9.60078 8L5.30078 3.7L6.00078 3L11.0007 8Z"
                })))
            }
        },
        56831: function(e, s, t) {
            "use strict";
            var a, i, n = t(67294);

            function l() {
                return (l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            s.Z = function(e) {
                return n.createElement("svg", l({
                    "aria-hidden": "true",
                    focusable: "false",
                    width: 16,
                    height: 16,
                    viewBox: "0 0 16 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), a || (a = n.createElement("path", {
                    d: "M15.47 7.83A8.345 8.345 0 0 0 8 2.5 8.345 8.345 0 0 0 .53 7.83a.5.5 0 0 0 0 .34A8.345 8.345 0 0 0 8 13.5a8.346 8.346 0 0 0 7.47-5.33.5.5 0 0 0 0-.34ZM8 12.5c-2.65 0-5.45-1.965-6.465-4.5C2.55 5.465 5.35 3.5 8 3.5s5.45 1.965 6.465 4.5C13.45 10.535 10.65 12.5 8 12.5Z"
                })), i || (i = n.createElement("path", {
                    d: "M8 5a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm0 5a2 2 0 1 1 0-4 2 2 0 0 1 0 4Z"
                })))
            }
        },
        18641: function(e, s, t) {
            "use strict";
            var a, i, n = t(67294);

            function l() {
                return (l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            s.Z = function(e) {
                return n.createElement("svg", l({
                    "aria-hidden": "true",
                    focusable: "false",
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), a || (a = n.createElement("path", {
                    d: "M16.63 29.93a1 1 0 0 0 .99-.15l5-4A1 1 0 0 0 23 25v-7.59l3.78-3.77A10.92 10.92 0 0 0 30 5.86V4a2 2 0 0 0-2-2h-1.86a10.92 10.92 0 0 0-7.78 3.22L14.59 9H7a1 1 0 0 0-.78.39l-4 5a1 1 0 0 0 .64 1.62l7 1 .28-2-5.27-.75L7.48 11H15a1 1 0 0 0 .71-.29l4.07-4.07A8.94 8.94 0 0 1 26.14 4H28v1.86a8.938 8.938 0 0 1-2.64 6.36l-4.07 4.07A1 1 0 0 0 21 17v7.52l-3.24 2.61-.75-5.27-2 .28 1 7a1 1 0 0 0 .62.79Z",
                    fill: "currentFill"
                })), i || (i = n.createElement("path", {
                    d: "m7.288 23.292 7.998-7.997 1.414 1.414-7.998 7.997-1.414-1.414Z",
                    fill: "currentFill"
                })))
            }
        },
        34199: function(e, s, t) {
            "use strict";
            var a, i = t(67294);

            function n() {
                return (n = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            s.Z = function(e) {
                return i.createElement("svg", n({
                    "aria-hidden": "true",
                    focusable: "false",
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), a || (a = i.createElement("path", {
                    d: "m19 20.4 1.4-1.4 7.6 7.6V20h2v10H20v-2h6.6L19 20.4ZM13 20.4 11.6 19 4 26.6V20H2v10h10v-2H5.4l7.6-7.6ZM17 16h-2V5.8l-4.6 4.6L9 9l7-7 7 7-1.4 1.4L17 5.8V16Z",
                    fill: "currentFill"
                })))
            }
        },
        30337: function(e, s, t) {
            "use strict";
            var a, i, n = t(67294);

            function l() {
                return (l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            s.Z = function(e) {
                return n.createElement("svg", l({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), a || (a = n.createElement("path", {
                    d: "M14 16.59L11.41 14L10 15.41L14 19.41L22 11.41L20.59 10L14 16.59Z",
                    fill: "currentFill"
                })), i || (i = n.createElement("path", {
                    d: "M16 30L9.82401 26.707C8.0632 25.7705 6.59071 24.3721 5.56464 22.6619C4.53857 20.9517 3.99767 18.9944 4.00001 17V4C4.00001 3.46957 4.21072 2.96086 4.58579 2.58579C4.96087 2.21071 5.46957 2 6.00001 2H26C26.5304 2 27.0391 2.21071 27.4142 2.58579C27.7893 2.96086 28 3.46957 28 4V17C28.0023 18.9944 27.4614 20.9517 26.4354 22.6619C25.4093 24.3721 23.9368 25.7705 22.176 26.707L16 30ZM6.00001 4V17C5.99889 18.6317 6.44188 20.2329 7.28149 21.632C8.12109 23.0311 9.32564 24.1753 10.766 24.942L16 27.733L21.234 24.943C22.6745 24.1763 23.8792 23.0319 24.7188 21.6326C25.5584 20.2333 26.0013 18.6319 26 17V4H6.00001Z",
                    fill: "currentFill"
                })))
            }
        },
        40830: function(e, s, t) {
            "use strict";
            var a, i = t(67294);

            function n() {
                return (n = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            s.Z = function(e) {
                return i.createElement("svg", n({
                    width: 32,
                    height: 32,
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), a || (a = i.createElement("path", {
                    d: "M23.1 16L29.4 9.7C30.2 8.9 30.2 7.7 29.4 6.9L25.2 2.7C24.4 1.9 23.2 1.9 22.4 2.7L16 8.9L9.7 2.6C8.9 1.8 7.7 1.8 6.9 2.6L2.6 6.8C1.8 7.6 1.8 8.8 2.6 9.6L8.9 16L2.14645 22.7536C2.05268 22.8473 2 22.9745 2 23.1071V29.5C2 29.7761 2.22386 30 2.5 30H8.89289C9.0255 30 9.15268 29.9473 9.24645 29.8536L16 23.1L22.3 29.4C23.1 30.2 24.3 30.2 25.1 29.4L29.3 25.2C30.1 24.4 30.1 23.2 29.3 22.4L23.1 16ZM23.8 4L28 8.2L21.7 14.5L17.5 10.3L23.8 4ZM8.2 28H4V23.8L10.3 17.5L14.5 21.7L8.2 28ZM23.8 28L4 8.2L8.2 4L11.7 7.5L9.95355 9.24645C9.75829 9.44171 9.75829 9.75829 9.95355 9.95355L10.6464 10.6464C10.8417 10.8417 11.1583 10.8417 11.3536 10.6464L13.1 8.9L17.3 13.1L15.5536 14.8464C15.3583 15.0417 15.3583 15.3583 15.5536 15.5536L16.2464 16.2464C16.4417 16.4417 16.7583 16.4417 16.9536 16.2464L18.7 14.5L22.9 18.7L21.3038 20.5483C21.1325 20.7465 21.1434 21.0434 21.3286 21.2286L22.0464 21.9464C22.2417 22.1417 22.5583 22.1417 22.7536 21.9464L24.5 20.2L28 23.7L23.8 28Z",
                    fill: "currentFill"
                })))
            }
        },
        48312: function(e, s, t) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/", function() {
                return t(94975)
            }])
        },
        94975: function(e, s, t) {
            "use strict";
            t.r(s), t.d(s, {
                default: function() {
                    return si
                }
            });
            var a, i, n, l, r, c, o, d = t(85893),
                m = t(67294),
                x = t(83492),
                h = t(6875),
                u = t(16061),
                g = t(16003);
            let p = {
                "@context": "https://schema.org",
                "@type": "WebSite",
                name: g.pB,
                url: g.R4
            };
            var f = t(40211),
                j = t(25615),
                v = t(88312),
                b = t(38122),
                w = t(49329),
                N = t(92605),
                k = t(30659);
            let y = e => {
                    let {
                        prefix: s,
                        type: t,
                        label: a
                    } = e;
                    return (0, d.jsxs)("div", {
                        className: "mt-3 flex items-baseline gap-1.5 text-xs text-marketing-subtler",
                        children: [(0, d.jsx)("span", {
                            className: "rounded bg-marketing-surface-faded px-1 py-0.5 font-mono",
                            children: s
                        }), (0, d.jsx)("span", {
                            className: "text-marketing-subtle",
                            children: a
                        }), (0, d.jsx)("span", {
                            className: "rounded-full bg-marketing-surface-faded px-1.5 py-0.5",
                            children: t
                        })]
                    })
                },
                L = e => {
                    let {
                        label: s,
                        content: t
                    } = e;
                    return (0, d.jsxs)("div", {
                        className: "ml-8 mt-2 flex items-baseline gap-1.5 text-xs text-marketing-subtler",
                        children: [(0, d.jsx)("span", {
                            className: "text-marketing-subtle",
                            children: s
                        }), (0, d.jsx)("span", {
                            children: t
                        })]
                    })
                };
            var C = () => (0, d.jsx)("div", {
                    role: "img",
                    "aria-label": "Illustration of Liveblocks DevTools displayed on top of a webpage.",
                    className: "pointer-events-none absolute inset-0 flex select-none justify-center pt-gutter",
                    children: (0, d.jsxs)("div", {
                        className: "relative aspect-video w-full max-w-sm rounded-md bg-marketing-surface-faded-subtle",
                        children: [(0, d.jsx)("div", {
                            className: "flex gap-1 p-3",
                            children: [, , , ].fill(null).map((e, s) => (0, d.jsx)("span", {
                                className: "size-1.5 rounded-full bg-marketing-surface-faded"
                            }, s))
                        }), (0, d.jsxs)("div", {
                            className: "absolute left-9 top-9 aspect-square w-full max-w-sm rounded-md border border-marketing-divider bg-marketing-surface-base font-mono",
                            children: [(0, d.jsxs)("div", {
                                className: "flex items-center gap-2 border-b border-marketing-divider p-3 text-marketing-subtle",
                                children: [(0, d.jsx)(k.H, {
                                    appearance: "notifications",
                                    size: "xs"
                                }), (0, d.jsx)("span", {
                                    className: "text-xs font-medium",
                                    children: "nextjs-whiteboard"
                                })]
                            }), (0, d.jsxs)("div", {
                                className: "px-3 pb-3",
                                children: [(0, d.jsx)(y, {
                                    prefix: "[]",
                                    type: "LiveList",
                                    label: "layerIds"
                                }), ["jC_mbZ553Tf496628954aCf", "dmgVWjQ8UPicQ5lzF2s6d"].map((e, s) => (0, d.jsx)(L, {
                                    label: s.toString(),
                                    content: '"'.concat(e, '"')
                                }, s)), (0, d.jsx)(y, {
                                    prefix: "()",
                                    type: "LiveMap",
                                    label: "layers"
                                }), [{
                                    label: "x",
                                    content: "537"
                                }, {
                                    label: "y",
                                    content: "504"
                                }, {
                                    label: "width",
                                    content: "100"
                                }, {
                                    label: "height",
                                    content: "100"
                                }, {
                                    label: "fill",
                                    content: "{ r: 155, g: 105, b: 245 }"
                                }].map((e, s) => {
                                    let {
                                        label: t,
                                        content: a
                                    } = e;
                                    return (0, d.jsx)(L, {
                                        label: t,
                                        content: a
                                    }, s)
                                })]
                            })]
                        })]
                    })
                }),
                z = t(25675),
                S = t.n(z),
                Z = () => (0, d.jsx)("div", {
                    className: "absolute inset-0 flex flex-col justify-end",
                    children: (0, d.jsx)(S(), {
                        src: "/images/open-source-gallery.png",
                        width: "1394",
                        height: "446",
                        alt: "Open-source examples gallery",
                        quality: 90
                    })
                }),
                A = t(75107),
                E = t(14498);
            let M = [{
                    author: "Alicia",
                    date: "Apr 11",
                    content: (0, d.jsxs)(d.Fragment, {
                        children: [(0, d.jsx)("em", {
                            children: "@Marc"
                        }), " Do you like this direction?"]
                    }),
                    emojis: [{
                        symbol: "\uD83D\uDC4C",
                        count: 1
                    }],
                    isActive: !1
                }, {
                    author: "Adrien",
                    date: "Apr 12",
                    content: "Absolutely! The copywriting is spot on. Well done!",
                    isActive: !0
                }],
                _ = [{
                    date: "4m ago",
                    title: (0, d.jsxs)(d.Fragment, {
                        children: [(0, d.jsx)("em", {
                            children: "Nimesh"
                        }), " commented in ", (0, d.jsx)("em", {
                            children: "LB-572"
                        })]
                    }),
                    content: (0, d.jsxs)(d.Fragment, {
                        children: [(0, d.jsx)("em", {
                            children: "@Jonathan"
                        }), " is this done?"]
                    }),
                    emojis: [{
                        symbol: "\uD83D\uDC4D",
                        count: 3
                    }, {
                        symbol: "\uD83D\uDD25",
                        count: 2
                    }],
                    seen: !1
                }, {
                    date: "2h ago",
                    title: (0, d.jsxs)(d.Fragment, {
                        children: [(0, d.jsx)("em", {
                            children: "Florent"
                        }), " commented in ", (0, d.jsx)("em", {
                            children: "Design explorations"
                        })]
                    }),
                    content: "Great work! This section looks good!",
                    seen: !0
                }, {
                    date: "4h ago",
                    title: (0, d.jsxs)(d.Fragment, {
                        children: [(0, d.jsx)("em", {
                            children: "Stacy"
                        }), " invited you to ", (0, d.jsx)("em", {
                            children: "Sales Pipeline"
                        })]
                    }),
                    hideAvatar: !1,
                    seen: !0
                }];
            var H = () => (0, d.jsxs)("div", {
                className: "pointer-events-none absolute inset-0 flex select-none items-start justify-center gap-4 pt-gutter",
                children: [(0, d.jsx)(A.J, {
                    className: "relative w-full max-w-md rounded-lg sm:mt-[52px]",
                    items: M
                }), (0, d.jsx)(E.Z, {
                    items: _,
                    className: "relative hidden w-full max-w-md sm:flex",
                    showTrigger: !0
                }), (0, d.jsx)("div", {
                    className: "point-events-none absolute -bottom-gutter left-0 right-0 z-10 h-24 bg-gradient-to-t from-marketing-surface-base to-transparent"
                })]
            });

            function T() {
                return (T = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            var I = function(e) {
                    return m.createElement("svg", T({
                        "aria-hidden": "true",
                        focusable: "false",
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 394,
                        height: 80,
                        fill: "currentcolor",
                        viewBox: "0 0 394 80"
                    }, e), a || (a = m.createElement("path", {
                        d: "M261.919.033h68.628V12.7h-27.224v66.639H289.71V12.7h-27.791V.033ZM149.052.033V12.7h-55.01v20.377h44.239v12.667H94.042v20.928h55.01V79.34H80.43V12.7h-.006V.033h68.628ZM183.32.066h-17.814l63.806 79.306h17.866l-31.907-39.626L247.127.126l-17.815.028-22.96 28.516L183.32.066ZM201.6 56.715l-8.921-11.092-27.224 33.81h17.865l18.28-22.718Z"
                    })), i || (i = m.createElement("path", {
                        fillRule: "evenodd",
                        d: "M80.907 79.339 17.015 0H0v79.306h13.612V16.952l50.195 62.387h17.1Z",
                        clipRule: "evenodd"
                    })), n || (n = m.createElement("path", {
                        d: "M333.607 78.855a3.528 3.528 0 0 1-2.555-1.036c-.71-.691-1.061-1.527-1.052-2.518-.009-.963.342-1.79 1.052-2.481a3.528 3.528 0 0 1 2.555-1.036c.959 0 1.798.345 2.508 1.036.72.69 1.079 1.518 1.089 2.481a3.44 3.44 0 0 1-.508 1.79 3.675 3.675 0 0 1-1.319 1.282 3.403 3.403 0 0 1-1.77.482ZM356.84 45.445h6.032v23.24c-.009 2.135-.471 3.962-1.374 5.498-.913 1.536-2.177 2.708-3.8 3.535-1.614.818-3.505 1.237-5.654 1.237-1.965 0-3.726-.355-5.294-1.046-1.568-.69-2.813-1.726-3.726-3.09-.923-1.363-1.375-3.063-1.375-5.098h6.042c.009.89.212 1.663.599 2.308a3.855 3.855 0 0 0 1.605 1.481c.691.346 1.485.519 2.379.519.969 0 1.799-.2 2.472-.61.673-.4 1.19-1 1.55-1.799.35-.79.535-1.772.544-2.935v-23.24ZM387.691 54.534c-.147-1.409-.793-2.509-1.918-3.29-1.135-.79-2.601-1.182-4.4-1.182-1.263 0-2.351.191-3.255.564-.904.382-1.605.89-2.085 1.536-.479.645-.719 1.381-.738 2.208 0 .691.166 1.29.489 1.79.323.51.756.937 1.319 1.282a8.806 8.806 0 0 0 1.845.882c.682.236 1.365.436 2.047.6l3.145.772a21.74 21.74 0 0 1 3.662 1.182 12.966 12.966 0 0 1 3.163 1.872 8.384 8.384 0 0 1 2.214 2.726c.544 1.064.821 2.309.821 3.745 0 1.936-.498 3.635-1.504 5.108-1.005 1.463-2.453 2.608-4.353 3.435-1.891.818-4.178 1.236-6.871 1.236-2.601 0-4.87-.4-6.779-1.2-1.918-.79-3.413-1.954-4.492-3.48-1.079-1.527-1.66-3.39-1.743-5.58h5.977c.083 1.144.452 2.099 1.079 2.871.636.763 1.466 1.327 2.481 1.709 1.024.372 2.167.563 3.431.563 1.319 0 2.481-.2 3.486-.59.996-.391 1.78-.937 2.343-1.646.572-.7.858-1.526.867-2.472-.009-.863-.268-1.581-.766-2.145-.507-.563-1.208-1.036-2.103-1.417a21.606 21.606 0 0 0-3.154-1.027l-3.818-.964c-2.758-.7-4.944-1.763-6.54-3.19-1.604-1.427-2.398-3.317-2.398-5.69 0-1.944.535-3.653 1.615-5.116 1.069-1.463 2.536-2.6 4.39-3.408 1.863-.818 3.966-1.218 6.308-1.218 2.38 0 4.464.4 6.263 1.218 1.798.809 3.21 1.936 4.233 3.372 1.024 1.436 1.559 3.08 1.587 4.944h-5.848Z"
                    })))
                },
                P = t(27893);
            let O = e => {
                let {
                    className: s
                } = e;
                return (0, d.jsx)("svg", {
                    className: s,
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "40",
                    height: "22",
                    fill: "currentColor",
                    viewBox: "0 0 40 22",
                    children: (0, d.jsx)("path", {
                        fillRule: "evenodd",
                        d: "M27 0H0l8 8v11L27 0ZM13 22h27l-8-8V3L13 22Z",
                        clipRule: "evenodd"
                    })
                })
            };
            var R = () => (0, d.jsx)("div", {
                    role: "img",
                    "aria-label": "Liveblocks and NextJS logos paired with live cursors, indicating a collaborative experience.",
                    className: "pointer-events-none flex flex-1 select-none flex-col items-center justify-center",
                    children: (0, d.jsxs)("div", {
                        className: "relative flex items-center",
                        children: [(0, d.jsx)(O, {
                            className: "h-6 w-auto"
                        }), (0, d.jsx)("span", {
                            "aria-hidden": "true",
                            className: "mx-4 h-6 w-px border-l border-marketing-divider-bolder"
                        }), (0, d.jsx)(I, {
                            className: "h-6 w-auto"
                        }), (0, d.jsx)(P.Z, {
                            name: "Chris",
                            color: "var(--lb-marketing-color-background-surface-product-comments)",
                            className: "-top-16 left-0"
                        }), (0, d.jsx)(P.Z, {
                            name: "Jonathan",
                            color: "var(--lb-marketing-color-background-surface-base-inverse-subtler)",
                            className: "right-16 top-12"
                        })]
                    })
                }),
                q = t(40999),
                B = t(22132),
                V = () => (0, d.jsxs)("section", {
                    className: "my-marketing-spacing-2xl",
                    children: [(0, d.jsxs)(q.Z, {
                        actions: (0, d.jsx)(v.Z, {
                            href: g.v_.HOME,
                            appearance: "primary",
                            size: "lg",
                            children: "Read the docs"
                        }),
                        children: [(0, d.jsx)("h2", {
                            children: "Designed for developers."
                        }), (0, d.jsxs)("p", {
                            children: ["Every API is carefully crafted to provide", " ", (0, d.jsx)("em", {
                                children: "the best developer experience"
                            }), ". Save heartache and ship faster. Let us handle the maintenance."]
                        })]
                    }), (0, d.jsx)(w.Z, {
                        hasGrid: !0,
                        children: (0, d.jsx)(b.S.System, {
                            className: "mt-marketing-spacing-md col-span-full md:col-span-10 md:col-start-2 lg:col-span-8 lg:col-start-3",
                            children: (0, d.jsxs)(b.S, {
                                columns: {
                                    sm: 2,
                                    md: 2,
                                    lg: 2
                                },
                                children: [(0, d.jsxs)(b.S.Cell, {
                                    column: {
                                        sm: 2,
                                        md: 2
                                    },
                                    className: "flex flex-col lg:aspect-video",
                                    children: [(0, d.jsx)(B.Z, {
                                        className: "max-w-xs sm:max-w-lg",
                                        isLeftAligned: !0,
                                        size: "md",
                                        matchingSize: !0,
                                        headingAs: "h3",
                                        heading: (0, d.jsx)(b.S.CellLink, {
                                            href: g.v_.API_REFERENCE_REACT_UI,
                                            children: "Pre-built components"
                                        }),
                                        description: (0, d.jsxs)(d.Fragment, {
                                            children: ["Leverage React components like", " ", (0, d.jsx)("code", {
                                                className: "whitespace-nowrap",
                                                children: "<Thread />"
                                            }), ",", " ", (0, d.jsx)("code", {
                                                className: "whitespace-nowrap",
                                                children: "<InboxNotification />"
                                            }), ", and more."]
                                        })
                                    }), (0, d.jsx)(N.Z, {
                                        children: (0, d.jsx)(H, {})
                                    })]
                                }), (0, d.jsxs)(b.S.Cell, {
                                    column: {
                                        sm: 2,
                                        md: 1
                                    },
                                    className: "flex flex-col lg:aspect-square",
                                    children: [(0, d.jsx)(B.Z, {
                                        className: "max-w-72",
                                        isLeftAligned: !0,
                                        size: "md",
                                        matchingSize: !0,
                                        headingAs: "h3",
                                        heading: (0, d.jsx)(b.S.CellLink, {
                                            href: g.qk.DEVTOOLS,
                                            children: "DevTools"
                                        }),
                                        description: "Browser extension to inspect Liveblocks apps."
                                    }), (0, d.jsx)(N.Z, {
                                        children: (0, d.jsx)(C, {})
                                    })]
                                }), (0, d.jsxs)(b.S.Cell, {
                                    column: {
                                        sm: 2,
                                        md: 1
                                    },
                                    className: "flex flex-col lg:aspect-square",
                                    children: [(0, d.jsx)(B.Z, {
                                        className: "max-w-xs",
                                        isLeftAligned: !0,
                                        size: "md",
                                        matchingSize: !0,
                                        headingAs: "h3",
                                        heading: (0, d.jsx)(b.S.CellLink, {
                                            href: g.qk.NEXTJS_STARTER_KIT,
                                            children: "Starter Kit"
                                        }),
                                        description: "Kickstart your Next.js collaborative application."
                                    }), (0, d.jsx)(N.Z, {
                                        children: (0, d.jsx)(R, {})
                                    })]
                                }), (0, d.jsxs)(b.S.Cell, {
                                    column: {
                                        sm: 2
                                    },
                                    className: "flex flex-col lg:aspect-video",
                                    children: [(0, d.jsx)(B.Z, {
                                        className: "max-w-xs",
                                        isLeftAligned: !0,
                                        size: "md",
                                        matchingSize: !0,
                                        headingAs: "h3",
                                        heading: (0, d.jsx)(b.S.CellLink, {
                                            href: g.qk.EXAMPLES,
                                            children: "Open-source examples"
                                        }),
                                        description: "Browse our gallery of collaborative experiences."
                                    }), (0, d.jsx)(N.Z, {
                                        children: (0, d.jsx)(Z, {})
                                    })]
                                })]
                            })
                        })
                    })]
                }),
                F = t(41664),
                D = t.n(F),
                W = t(87527),
                X = t(20402),
                G = t(97770),
                U = t(77470),
                K = t(51393);

            function J() {
                return (0, d.jsxs)(D(), {
                    className: "group relative mb-6 flex items-center justify-center gap-4 overflow-hidden rounded-full border border-marketing-divider-subtle bg-[#0057FF] py-1 font-medium transition duration-300 ease-out hover:border-marketing-divider-bold focus:border-marketing-divider-bold",
                    href: g.qk.NEXTJS_TEMPLATE_WEEK,
                    prefetch: !1,
                    children: [(0, d.jsx)(K.ZP, {
                        className: "absolute h-[calc(var(--inner-gutter)*2)] w-full",
                        lightRadius: 224,
                        lightIntensity: .3
                    }), (0, d.jsxs)("div", {
                        className: "pointer-events-none flex animate-mask-flare-loop items-center gap-2",
                        children: [(0, d.jsx)("div", {
                            className: "font-sans ml-3 inline-flex h-4 items-center rounded-full bg-marketing-surface-faded-bolder px-1.5 text-[9px] font-semibold uppercase leading-tight tracking-widest text-marketing",
                            children: "Sep 17-19"
                        }), (0, d.jsx)("p", {
                            className: "text-xs md:text-sm",
                            children: "Next.js Template Week"
                        })]
                    }), (0, d.jsx)("div", {
                        className: "pointer-events-none mr-1 rounded-full bg-marketing-surface-base-inverse p-1.5 text-[#0057FF]",
                        children: (0, d.jsx)(W.Z, {
                            className: "fill-current"
                        })
                    })]
                })
            }
            var Y = t(31422),
                Q = t.n(Y);
            let $ = e => {
                let {
                    className: s
                } = e, t = (0, U.iv)()(e => e.setProductHover), a = (0, m.useCallback)(() => {
                    t(0, !0)
                }, [t]), i = (0, m.useCallback)(() => {
                    t(0, !1)
                }, [t]), n = (0, m.useCallback)(() => {
                    t(1, !0)
                }, [t]), l = (0, m.useCallback)(() => {
                    t(1, !1)
                }, [t]), r = (0, m.useCallback)(() => {
                    t(2, !0)
                }, [t]), c = (0, m.useCallback)(() => {
                    t(2, !1)
                }, [t]), o = (0, m.useCallback)(() => {
                    t(3, !0)
                }, [t]), x = (0, m.useCallback)(() => {
                    t(3, !1)
                }, [t]);
                return (0, d.jsxs)("p", {
                    className: (0, X.cn)(s, "f-marketing-body-md max-w-md text-marketing-subtler sm:max-w-xl lg:max-w-2xl xl:max-w-3xl max-sm:px-[4%]"),
                    children: ["Ship features like", " ", (0, d.jsxs)(D(), {
                        href: g.qk.COMMENTS,
                        className: "whitespace-nowrap font-medium text-marketing",
                        onPointerEnter: a,
                        onPointerLeave: i,
                        prefetch: !1,
                        children: [(0, d.jsx)(S(), {
                            src: "/images/products/comments.png",
                            quality: 5,
                            alt: "Comments",
                            width: 24,
                            height: 24,
                            className: "relative -top-px ml-1 mr-1.5 inline-block size-4 select-none md:-top-0.5 md:mr-2 md:size-5 lg:size-6",
                            priority: !0,
                            "aria-hidden": !0
                        }), "Comments"]
                    }), ",", " ", (0, d.jsxs)(D(), {
                        href: g.qk.NOTIFICATIONS,
                        className: "whitespace-nowrap font-medium text-marketing",
                        onPointerEnter: n,
                        onPointerLeave: l,
                        prefetch: !1,
                        children: [(0, d.jsx)(S(), {
                            src: "/images/products/notifications.png",
                            quality: 5,
                            alt: "Notifications",
                            width: 24,
                            height: 24,
                            className: "relative -top-px ml-1 mr-1.5 inline-block size-4 select-none md:-top-0.5 md:mr-2 md:size-5 lg:size-6",
                            priority: !0,
                            "aria-hidden": !0
                        }), "Notifications"]
                    }), ", a", " ", (0, d.jsxs)(D(), {
                        href: g.qk.TEXT_EDITOR,
                        className: "whitespace-nowrap font-medium text-marketing",
                        onPointerEnter: r,
                        onPointerLeave: c,
                        prefetch: !1,
                        children: [(0, d.jsx)(S(), {
                            src: "/images/products/text-editor.png",
                            quality: 5,
                            alt: "Text editor",
                            width: 24,
                            height: 24,
                            className: "relative -top-px ml-1 mr-1.5 inline-block size-4 select-none md:-top-0.5 md:mr-2 md:size-5 lg:size-6",
                            priority: !0,
                            "aria-hidden": !0
                        }), "Text\xa0Editor"]
                    }), ", or build any collaborative experience with", " ", (0, d.jsxs)(D(), {
                        href: g.qk.REALTIME_APIS,
                        className: "whitespace-nowrap font-medium text-marketing",
                        onPointerEnter: o,
                        onPointerLeave: x,
                        prefetch: !1,
                        children: [(0, d.jsx)(S(), {
                            src: "/images/products/realtime-apis.png",
                            quality: 5,
                            alt: "Realtime APIs",
                            width: 24,
                            height: 24,
                            className: "relative -top-px ml-1 mr-1.5 inline-block size-4 select-none md:-top-0.5 md:mr-2 md:size-5 lg:size-6",
                            priority: !0,
                            "aria-hidden": !0
                        }), "Realtime\xa0APIs"]
                    }), " ", "in days, not months. Engage users, fuel creativity, and drive growth. Finally."]
                })
            };
            var ee = () => (0, d.jsx)(G.h, {
                    children: (0, d.jsxs)("div", {
                        className: "relative overflow-hidden",
                        children: [(0, d.jsx)("div", {
                            "aria-hidden": "true",
                            className: Q().heroGradientTop
                        }), (0, d.jsxs)("div", {
                            "aria-hidden": "true",
                            className: Q().heroLight,
                            children: [(0, d.jsx)("div", {
                                className: Q().heroLightStreaks1
                            }), (0, d.jsx)("div", {
                                className: Q().heroLightStreaks2
                            }), (0, d.jsx)("div", {
                                className: Q().heroLightStreaks3
                            })]
                        }), (0, d.jsx)("section", {
                            className: "pb-marketing-spacing-xl pt-marketing-spacing-sm pointer-events-none relative z-10 mt-[--marketing-header-height]",
                            children: (0, d.jsx)(w.Z, {
                                children: (0, d.jsxs)("div", {
                                    className: "pointer-events-auto flex flex-col items-center text-center",
                                    children: [(0, d.jsx)(J, {}), (0, d.jsx)("h1", {
                                        className: "f-marketing-display-xl mb-5 sm:mb-6 lg:max-w-2xl xl:mb-7 xl:max-w-3xl",
                                        children: "Build collaborative experiences faster"
                                    }), (0, d.jsx)($, {
                                        className: "mb-6 xl:mb-8"
                                    }), (0, d.jsxs)("div", {
                                        className: "flex flex-col items-center justify-center gap-2 sm:flex-row sm:gap-3",
                                        children: [(0, d.jsx)(v.Z, {
                                            size: "lg",
                                            href: g.qf.SIGN_UP,
                                            appearance: "primary",
                                            children: "Start building for free"
                                        }), (0, d.jsxs)(v.Z, {
                                            size: "lg",
                                            href: g.qk.EXAMPLES,
                                            appearance: "ghost",
                                            children: ["Browse examples", (0, d.jsx)(W.Z, {
                                                className: "-mr-0.5 ml-1.5 fill-current"
                                            })]
                                        })]
                                    })]
                                })
                            })
                        }), (0, d.jsx)("div", {
                            className: "container z-0 ml-[-7.5vw] aspect-[16/12] w-[115vw] max-w-screen-xl md:mx-auto md:w-full",
                            children: (0, d.jsx)("div", {
                                className: Q().heroContainer,
                                children: (0, d.jsx)(G.B, {})
                            })
                        })]
                    })
                }),
                es = t(51818),
                et = t(82925);
            let ea = () => (0, d.jsxs)(es.E.svg, {
                    className: "size-6",
                    animate: {
                        rotate: [0, 360]
                    },
                    transition: {
                        duration: 1,
                        repeat: 1 / 0,
                        repeatDelay: 1.2
                    },
                    width: "32",
                    height: "32",
                    viewBox: "0 0 32 32",
                    fill: "currentColor",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, d.jsx)("path", {
                        d: "M16,2A14,14,0,1,0,30,16,14,14,0,0,0,16,2Zm0,26A12,12,0,1,1,28,16,12,12,0,0,1,16,28Z"
                    }), (0, d.jsx)(es.E.path, {
                        animate: {
                            scaleY: [1, 0, 1]
                        },
                        transition: {
                            duration: .2,
                            repeat: 1 / 0,
                            delay: 1,
                            repeatDelay: 1
                        },
                        d: "M11.5,11A2.5,2.5,0,1,0,14,13.5,2.48,2.48,0,0,0,11.5,11Z"
                    }), (0, d.jsx)("path", {
                        d: "M20.5,11A2.5,2.5,0,1,0,23,13.5,2.48,2.48,0,0,0,20.5,11Z"
                    }), (0, d.jsx)("path", {
                        d: "M16,24a8,8,0,0,0,6.85-3.89l-1.71-1a6,6,0,0,1-10.28,0l-1.71,1A8,8,0,0,0,16,24Z"
                    })]
                }),
                ei = () => (0, d.jsx)(es.E.svg, {
                    className: "size-6",
                    width: "24",
                    height: "24",
                    viewBox: "0 0 24 24",
                    fill: "white",
                    xmlns: "http://www.w3.org/2000/svg",
                    animate: {
                        scale: [1, 1, 1, .9, 1, .9, 1]
                    },
                    transition: {
                        duration: .8,
                        repeat: 1 / 0,
                        repeatDelay: 2
                    },
                    children: (0, d.jsx)("path", {
                        fill: "currentColor",
                        d: "M17.25 21a.748.748 0 0 1-.533-.218l-4.598-4.605-2.497 3.75a.75.75 0 0 1-.75.33.75.75 0 0 1-.608-.524l-4.5-15a.75.75 0 0 1 .953-.983l15 4.5a.75.75 0 0 1 .525.608.75.75 0 0 1-.33.75l-3.75 2.497 4.605 4.598a.75.75 0 0 1 0 1.064l-3 3a.75.75 0 0 1-.518.233Zm0-1.808 1.942-1.942-5.37-5.363 3.937-2.624L5.617 5.618 9.262 17.76l2.625-3.938 5.362 5.37Z"
                    })
                });
            var en = () => (0, d.jsx)("section", {
                    className: "py-marketing-spacing-xl max-sm:pr-[2%]",
                    children: (0, d.jsxs)(q.Z, {
                        children: [(0, d.jsxs)("p", {
                            children: ["Many SaaS companies struggle to grow their user base, and maintain engagement. This is because", " ", (0, d.jsx)("em", {
                                children: "their products aren’t designed for how people work today"
                            }), ". Teams seek collaboration in their daily work, but instead find themselves emailing files, sharing links in", "\xa0", "Slack, and juggling multiple tools… Work is fragmented, disconnected, and hinders productivity."]
                        }), (0, d.jsxs)("p", {
                            children: ["There’s a reason why fast-growing companies like Figma, Linear, and Notion are thriving. Their secret? They’ve perfected collaboration with", " ", (0, d.jsxs)("em", {
                                children: [(0, d.jsx)(et.x.WordWithIcon, {
                                    size: "lg",
                                    icon: (0, d.jsx)("span", {
                                        className: "flex size-6 items-center justify-center rounded border-2 border-marketing-divider",
                                        children: (0, d.jsx)("span", {
                                            className: "inline size-2 animate-[blink_2s_step-start_0s_infinite] rounded-full bg-white"
                                        })
                                    }),
                                    children: "realtime"
                                }), "\xa0", "comments"]
                            }), ",", " ", (0, d.jsxs)("em", {
                                children: [(0, d.jsx)(et.x.WordWithIcon, {
                                    size: "lg",
                                    icon: (0, d.jsx)(ea, {}),
                                    children: "intelligent"
                                }), " ", "notifications"]
                            }), ", and", " ", (0, d.jsxs)("em", {
                                children: [(0, d.jsx)(et.x.WordWithIcon, {
                                    size: "lg",
                                    icon: (0, d.jsx)(ei, {}),
                                    children: "multiplayer"
                                }), " ", "editing"]
                            }), ". And if it’s good for people, it’s good for business."]
                        }), (0, d.jsxs)("p", {
                            children: ["However, building such experiences is no small feat. Even seemingly simple features like commenting can extend into months‑long battles for quality. Throw notifications into the mix, along with scaling & maintaining your infrastructure, and", " ", (0, d.jsxs)("em", {
                                children: ["you’re looking at months of", "\xa0", "serious effort"]
                            }), ". Not to mention realtime functionality, which can be mind-bendingly complex. It starts to feel like an impossible task."]
                        }), (0, d.jsx)("p", {
                            children: (0, d.jsx)("em", {
                                children: "Liveblocks makes it possible."
                            })
                        })]
                    })
                }),
                el = t(5152),
                er = t.n(el),
                ec = t(18641),
                eo = t(34199),
                ed = t(30337),
                em = t(40830),
                ex = t(5198),
                eh = t(4635),
                eu = t(70957),
                eg = t(18141),
                ep = t(2131),
                ef = t(69430),
                ej = t(24973);
            let ev = er()(() => Promise.all([t.e(6138), t.e(2748), t.e(6885)]).then(t.bind(t, 13492)), {
                    loadableGenerated: {
                        webpack: () => [13492]
                    },
                    loading: () => null,
                    ssr: !1
                }),
                eb = [{
                    author: ep.Q.LUKE_THOMAS.author,
                    quote: ep.Q.LUKE_THOMAS.quote,
                    companyInfo: {
                        logo: (0, d.jsx)(eg.Z, {
                            className: "h-full w-auto"
                        }),
                        teamSize: 800,
                        yearFounded: 2011,
                        industry: "Automation"
                    }
                }, {
                    author: ep.Q.JOEL_VARTY.author,
                    quote: ep.Q.JOEL_VARTY.quote,
                    companyInfo: {
                        logo: (0, d.jsx)(ex.Z, {
                            className: "h-full w-auto"
                        }),
                        teamSize: 20,
                        yearFounded: 2002,
                        industry: "CMS"
                    }
                }, {
                    author: ep.Q.ALEXIS_SMIRNOV.author,
                    quote: ep.Q.ALEXIS_SMIRNOV.quote,
                    companyInfo: {
                        logo: (0, d.jsx)(eh.Z, {
                            className: "h-full w-auto"
                        }),
                        teamSize: 654,
                        yearFounded: 2016,
                        industry: "Telemedecine"
                    }
                }, {
                    author: ep.Q.DEV_SHEKHAWAT.author,
                    quote: ep.Q.DEV_SHEKHAWAT.quote,
                    companyInfo: {
                        logo: (0, d.jsx)(eu.Z, {
                            className: "h-full w-auto"
                        }),
                        teamSize: 20,
                        yearFounded: 2015,
                        industry: "Publishing"
                    }
                }];
            var ew = () => (0, d.jsxs)("section", {
                className: "mt-marketing-spacing-2xl mb-marketing-spacing-xl",
                children: [(0, d.jsxs)(q.Z, {
                    children: [(0, d.jsx)("h2", {
                        children: "The all‑in‑one collaboration platform."
                    }), (0, d.jsxs)("p", {
                        children: ["Liveblocks is the world’s ", (0, d.jsx)("strong", {
                            children: "most advanced platform"
                        }), " for", "\xa0", (0, d.jsx)("strong", {
                            children: "building"
                        }), ", ", (0, d.jsx)("strong", {
                            children: "hosting"
                        }), ", and", " ", (0, d.jsx)("strong", {
                            children: "scaling"
                        }), " collaborative products that work the way they should."]
                    })]
                }), (0, d.jsx)(w.Z, {
                    hasGrid: !0,
                    children: (0, d.jsx)(b.S.System, {
                        className: "mt-marketing-spacing-md col-span-full md:col-span-10 md:col-start-2 lg:col-span-8 lg:col-start-3",
                        children: (0, d.jsxs)(b.S, {
                            columns: {
                                sm: 2,
                                md: 2,
                                lg: 2
                            },
                            children: [(0, d.jsxs)(b.S.Cell, {
                                column: {
                                    sm: 2,
                                    md: 2,
                                    lg: 2
                                },
                                className: "flex flex-col sm:aspect-video",
                                children: [(0, d.jsx)(B.Z, {
                                    className: "max-w-60 sm:max-w-xs lg:max-w-sm",
                                    isLeftAligned: !0,
                                    size: "md",
                                    matchingSize: !0,
                                    headingAs: "h3",
                                    heading: (0, d.jsx)(b.S.CellLink, {
                                        href: g.qk.INFRASTRUCTURE,
                                        children: "Collaboration infrastructure"
                                    }),
                                    description: "WebSocket edge infrastructure and\xa0reliable connection engine."
                                }), (0, d.jsx)(ev, {}), (0, d.jsx)(N.Z, {})]
                            }), (0, d.jsxs)(b.S.Cell, {
                                children: [(0, d.jsx)(ec.Z, {
                                    className: "mb-4 size-6 fill-marketing-subtle md:size-8"
                                }), (0, d.jsx)(B.Z, {
                                    className: "max-w-60",
                                    isLeftAligned: !0,
                                    size: "sm",
                                    matchingSize: !0,
                                    headingAs: "h3",
                                    heading: "Zero configuration",
                                    description: "Scale to millions. No complex configuration required."
                                })]
                            }), (0, d.jsxs)(b.S.Cell, {
                                children: [(0, d.jsx)(eo.Z, {
                                    className: "mb-4 size-6 fill-marketing-subtle md:size-8"
                                }), (0, d.jsx)(B.Z, {
                                    className: "max-w-60",
                                    isLeftAligned: !0,
                                    size: "sm",
                                    matchingSize: !0,
                                    headingAs: "h3",
                                    heading: "Effortless scaling",
                                    description: "Built to handle any traffic on your collaborative experiences."
                                })]
                            }), (0, d.jsxs)(b.S.Cell, {
                                children: [(0, d.jsx)(em.Z, {
                                    className: "mb-4 h-6 w-6 fill-marketing-subtle md:h-8 md:w-8"
                                }), (0, d.jsx)(B.Z, {
                                    className: "max-w-60",
                                    isLeftAligned: !0,
                                    size: "sm",
                                    matchingSize: !0,
                                    headingAs: "h3",
                                    heading: "No maintenance required",
                                    description: "Spend time building, not maintaining infrastructure."
                                })]
                            }), (0, d.jsxs)(b.S.Cell, {
                                children: [(0, d.jsx)(ed.Z, {
                                    className: "mb-4 h-6 w-6 fill-marketing-subtle md:h-8 md:w-8"
                                }), (0, d.jsx)(B.Z, {
                                    className: "max-w-60",
                                    isLeftAligned: !0,
                                    size: "sm",
                                    matchingSize: !0,
                                    headingAs: "h3",
                                    heading: "Rock‑solid security",
                                    description: "Access management, 99.9% Uptime SLA, SOC 2, and more."
                                })]
                            }), (0, d.jsxs)(b.S.Cell, {
                                column: {
                                    sm: 2,
                                    md: 2,
                                    lg: 2
                                },
                                className: "flex flex-col lg:aspect-video",
                                children: [(0, d.jsx)(B.Z, {
                                    className: "max-w-xs md:max-w-sm lg:max-w-md",
                                    isLeftAligned: !0,
                                    size: "md",
                                    matchingSize: !0,
                                    headingAs: "h3",
                                    heading: (0, d.jsx)(b.S.CellLink, {
                                        href: g.qk.MONITORING_DASHBOARD,
                                        children: "Monitoring dashboard"
                                    }),
                                    description: "Monitor, analyze, and manage the collaborative experiences in\xa0your product."
                                }), (0, d.jsx)(N.Z, {
                                    children: (0, d.jsx)(ef.Z, {
                                        type: "project-overview"
                                    })
                                })]
                            }), (0, d.jsx)(b.S.Cell, {
                                column: {
                                    sm: 2,
                                    md: 2,
                                    lg: 2
                                },
                                className: "flex flex-col justify-between gap-12 lg:aspect-video",
                                children: (0, d.jsx)(ej.Z, {
                                    testimonials: eb
                                })
                            })]
                        })
                    })
                })]
            });
            let eN = [{
                author: "Alicia",
                date: "Apr 11",
                content: (0, d.jsxs)(d.Fragment, {
                    children: [(0, d.jsx)("em", {
                        children: "@AI bot"
                    }), " what could I do to sound more enthusiastic here?"]
                }),
                emojis: [{
                    symbol: "\uD83D\uDC4D",
                    count: 1
                }],
                isActive: !1
            }, {
                author: "AI bot",
                date: "Apr 12",
                content: (0, d.jsxs)(d.Fragment, {
                    children: ["You could try one of this alternative perhaps?", (0, d.jsx)("br", {}), '- "This is freaking awesome!"', (0, d.jsx)("br", {}), '- "This is amazing!" ', (0, d.jsx)("br", {}), '- "Wow! Incredible!"']
                }),
                isActive: !0
            }];
            var ek = () => (0, d.jsxs)("div", {
                    className: "pointer-events-none absolute inset-0 flex select-none items-start justify-center pt-gutter",
                    children: [(0, d.jsx)(A.J, {
                        className: "relative w-full rounded-lg",
                        items: eN
                    }), (0, d.jsx)("div", {
                        className: "point-events-none absolute -bottom-gutter left-0 right-0 z-10 h-24 bg-gradient-to-t from-marketing-surface-base to-transparent"
                    })]
                }),
                ey = t(65202),
                eL = () => (0, d.jsx)("div", {
                    role: "img",
                    "aria-label": "Illustration of a collaborative text editor, with a comment attached to a highlighted word indicating a spelling mistake.",
                    className: "pointer-events-none absolute inset-0 mt-gutter flex select-none items-start justify-center pt-gutter lg:mt-0 lg:items-center",
                    children: (0, d.jsxs)("div", {
                        className: "relative -left-[calc(var(--inner-gutter)*4)] flex w-96 flex-col lg:-left-6",
                        children: [(0, d.jsx)(eC, {
                            isTitle: !0,
                            className: "mb-6 w-1/2"
                        }), (0, d.jsxs)("div", {
                            className: "relative mb-2 flex w-full gap-2",
                            children: [(0, d.jsx)(k.H, {
                                className: "absolute top-1/2 -ml-4 -translate-x-full -translate-y-1/2",
                                size: "sm",
                                appearance: "text-editor"
                            }), (0, d.jsx)(eC, {
                                className: "w-1/2"
                            }), (0, d.jsx)(eC, {
                                className: "w-20",
                                isHighlighted: !0,
                                isActive: !0
                            }), (0, d.jsx)(ez, {
                                isHighlighted: !0
                            }), (0, d.jsx)(eC, {
                                className: "w-full"
                            })]
                        }), (0, d.jsx)(eC, {
                            className: "mb-2 w-10/12"
                        }), (0, d.jsx)(eC, {
                            className: "w-11/12"
                        }), (0, d.jsxs)("div", {
                            className: "relative mb-2 mt-6 hidden w-full gap-2 lg:flex",
                            children: [(0, d.jsx)(k.H, {
                                className: "absolute top-1/2 -ml-4 -translate-x-full -translate-y-1/2",
                                size: "sm"
                            }), (0, d.jsx)(eC, {
                                className: "w-1/5"
                            }), (0, d.jsx)(eC, {
                                className: "w-20",
                                isHighlighted: !0
                            }), (0, d.jsx)(eC, {
                                className: "w-full"
                            }), " ", (0, d.jsx)(ez, {})]
                        }), (0, d.jsxs)("div", {
                            className: "mb-2 hidden gap-2 lg:flex",
                            children: [(0, d.jsx)(eC, {
                                className: "w-11/12"
                            }), (0, d.jsx)(eC, {
                                className: "w-20",
                                isHighlighted: !0
                            }), (0, d.jsx)(eC, {
                                className: "w-11/12"
                            })]
                        }), (0, d.jsx)("div", {
                            className: "hidden gap-2 lg:flex",
                            children: (0, d.jsx)(eC, {
                                className: "w-2/3"
                            })
                        }), (0, d.jsx)(A.J, {
                            className: "absolute -right-[calc(var(--inner-gutter)*4)] -top-2 w-full max-w-72 origin-top-right scale-75 rounded-lg shadow-2xl ring-1 ring-marketing-divider-surface lg:-right-20 lg:scale-90",
                            appearance: "text-editor",
                            items: [{
                                author: "Guillaume",
                                date: "1m ago",
                                content: (0, d.jsxs)(d.Fragment, {
                                    children: [(0, d.jsx)("em", {
                                        children: "@Olivier"
                                    }), " There is a typo!"]
                                }),
                                emojis: [{
                                    symbol: "\uD83D\uDC40",
                                    count: 1
                                }],
                                isActive: !0
                            }],
                            highlightedWord: "warld"
                        })]
                    })
                });
            let eC = e => {
                    let {
                        className: s,
                        isTitle: t,
                        isHighlighted: a,
                        isActive: i
                    } = e;
                    return (0, d.jsx)("div", {
                        className: (0, X.cn)(s, "rounded", a ? i ? "bg-marketing-surface-product-text-editor" : "bg-marketing-surface-base-inverse-subtlest" : "bg-marketing-surface-faded-subtle opacity-60", t ? "h-6" : "h-4")
                    })
                },
                ez = e => {
                    let {
                        className: s,
                        isHighlighted: t
                    } = e;
                    return (0, d.jsx)("div", {
                        className: (0, X.cn)(s, "h-4 w-2 shrink-0 rounded", t ? "bg-marketing-surface-product-text-editor" : "bg-marketing-surface-base-inverse-subtlest")
                    })
                };
            var eS = t(16367),
                eZ = () => (0, d.jsx)("div", {
                    role: "img",
                    "aria-label": "Illustration of AI integration into a collaborative text editor, used to correct spelling and grammar or translate words or sentences.",
                    className: "pointer-events-none select-none",
                    children: (0, d.jsxs)("div", {
                        className: "flex flex-col gap-1 truncate",
                        children: [(0, d.jsxs)("span", {
                            className: "relative block truncate pl-0.5 text-lg text-marketing-subtlest after:absolute after:inset-y-0 after:right-0 after:w-10 after:bg-gradient-to-l after:from-black",
                            children: [(0, d.jsx)("span", {
                                className: "relative text-marketing after:absolute after:-inset-0.5 after:rounded after:bg-white/20",
                                children: "Thus"
                            }), " ", "is so magical, thanks for find"]
                        }), (0, d.jsxs)("ul", {
                            className: "flex flex-col gap-px divide-y divide-black rounded bg-white/10",
                            children: [(0, d.jsxs)("li", {
                                className: "flex h-9 items-center gap-3 px-3 text-sm",
                                children: [(0, d.jsx)("svg", {
                                    className: "opacity-60",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    width: "16",
                                    height: "16",
                                    fill: "none",
                                    viewBox: "0 0 16 16",
                                    children: (0, d.jsxs)("g", {
                                        fill: "currentColor",
                                        children: [(0, d.jsx)("path", {
                                            d: "M8.87 15 8 14.5l2-3.5h3a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h4.5v1H3a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-2.42l-1.71 3Z"
                                        }), (0, d.jsx)("path", {
                                            d: "M12 5H4v1h8V5ZM9 8H4v1h5V8Z"
                                        })]
                                    })
                                }), "Add comment"]
                            }), (0, d.jsxs)("li", {
                                className: "flex h-9 items-center gap-3 px-3 text-sm",
                                children: [(0, d.jsx)("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    width: "16",
                                    height: "16",
                                    fill: "none",
                                    viewBox: "0 0 16 16",
                                    children: (0, d.jsx)("path", {
                                        fill: "var(--lb-marketing-color-text-product-text-editor)",
                                        fillRule: "evenodd",
                                        d: "M7.272 4.824c.303-.106.303-.292 0-.41l-1.647-.63c-.292-.105-.63-.444-.747-.747l-.63-1.647c-.106-.304-.293-.304-.41 0l-.63 1.647c-.105.292-.444.63-.748.747l-1.646.63c-.304.106-.304.293 0 .41l1.646.63c.292.105.63.444.748.748l.63 1.646c.105.304.292.304.41 0l.63-1.646c.105-.292.444-.631.747-.748l1.647-.63Zm8.023 5.769c.935-.234.935-.62 0-.853l-2.067-.514c-.934-.233-1.892-1.19-2.125-2.125l-.514-2.067c-.234-.934-.62-.934-.853 0L9.222 7.1c-.233.934-1.19 1.892-2.125 2.125L5.03 9.74c-.934.234-.934.62 0 .853l2.067.514c.934.233 1.892 1.19 2.125 2.125l.514 2.067c.234.935.62.935.853 0l.514-2.067c.233-.934 1.19-1.892 2.125-2.125l2.067-.514Z",
                                        clipRule: "evenodd"
                                    })
                                }), "Fix spelling & grammar"]
                            }), (0, d.jsxs)("li", {
                                className: "flex h-9 items-center justify-between gap-3 px-3 text-sm",
                                children: [(0, d.jsxs)("div", {
                                    className: "flex items-center gap-3",
                                    children: [(0, d.jsx)("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        width: "16",
                                        height: "16",
                                        fill: "none",
                                        viewBox: "0 0 16 16",
                                        children: (0, d.jsx)("path", {
                                            fill: "var(--lb-marketing-color-text-product-text-editor)",
                                            fillRule: "evenodd",
                                            d: "M7.272 4.824c.303-.106.303-.292 0-.41l-1.647-.63c-.292-.105-.63-.444-.747-.747l-.63-1.647c-.106-.304-.293-.304-.41 0l-.63 1.647c-.105.292-.444.63-.748.747l-1.646.63c-.304.106-.304.293 0 .41l1.646.63c.292.105.63.444.748.748l.63 1.646c.105.304.292.304.41 0l.63-1.646c.105-.292.444-.631.747-.748l1.647-.63Zm8.023 5.769c.935-.234.935-.62 0-.853l-2.067-.514c-.934-.233-1.892-1.19-2.125-2.125l-.514-2.067c-.234-.934-.62-.934-.853 0L9.222 7.1c-.233.934-1.19 1.892-2.125 2.125L5.03 9.74c-.934.234-.934.62 0 .853l2.067.514c.934.233 1.892 1.19 2.125 2.125l.514 2.067c.234.935.62.935.853 0l.514-2.067c.233-.934 1.19-1.892 2.125-2.125l2.067-.514Z",
                                            clipRule: "evenodd"
                                        })
                                    }), "Translate"]
                                }), (0, d.jsx)(eS.Z, {
                                    className: "fill-current opacity-40"
                                })]
                            })]
                        })]
                    })
                }),
                eA = t(12376),
                eE = t(45417),
                eM = t(93967),
                e_ = t.n(eM),
                eH = t(13114);

            function eT(e) {
                var s;
                let {
                    className: t,
                    items: a
                } = e, [i, n] = (0, m.useState)(0);
                return (0, d.jsxs)("div", {
                    className: (0, X.cn)(t, "flex flex-col sm:items-center"),
                    children: [(0, d.jsx)(eH.M, {
                        mode: "wait",
                        children: (0, d.jsx)(es.E.div, {
                            className: "relative flex w-full grow items-center justify-center",
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            children: null === (s = a[i]) || void 0 === s ? void 0 : s.visual
                        }, i)
                    }), (0, d.jsx)("div", {
                        role: "tablist",
                        className: "-mx-[--inner-gutter] inline-flex w-auto shrink-0 items-center justify-start overflow-x-auto px-[--inner-gutter] pb-gutter",
                        children: a.map((e, s) => (0, d.jsx)(eI, {
                            name: e.name,
                            icon: e.icon,
                            index: s,
                            selected: i === s,
                            setSelectedIndex: n
                        }, s))
                    })]
                })
            }

            function eI(e) {
                let {
                    name: s,
                    icon: t,
                    index: a,
                    setSelectedIndex: i,
                    selected: n
                } = e;
                return (0, d.jsxs)("button", {
                    role: "tab",
                    "aria-selected": null != n ? n : "false",
                    className: e_()("group relative flex h-10 items-center gap-2 whitespace-nowrap rounded-full px-3.5 text-sm transition-colors duration-200 ease-out", {
                        "text-marketing-subtler hover:text-marketing-subtle focus:text-marketing-subtle": !n
                    }),
                    onClick: () => {
                        i(a)
                    },
                    children: [t, s, n && (0, d.jsx)(es.E.span, {
                        layoutId: "position",
                        transition: {
                            type: "spring",
                            stiffness: 500,
                            damping: 50
                        },
                        className: "absolute inset-0 rounded-full bg-marketing-surface-faded"
                    })]
                })
            }
            let eP = [{
                visual: (0, d.jsx)(function() {
                    return (0, d.jsx)("div", {
                        "aria-label": "Illustration of a media player with comments using Liveblocks.",
                        className: "pointer-events-none absolute inset-0 flex scale-75 select-none items-center justify-center lg:scale-90 xl:scale-100",
                        role: "img",
                        children: (0, d.jsx)("div", {
                            className: "mt-gutter flex justify-center",
                            children: (0, d.jsxs)("div", {
                                className: "flex flex-col gap-3",
                                children: [(0, d.jsxs)("div", {
                                    className: "flex items-end gap-1.5 [&>span]:inline-block [&>span]:w-0.5 [&>span]:rounded-sm",
                                    children: [(0, d.jsx)("span", {
                                        className: "h-1 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-2 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-3.5 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-4 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-3 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-8 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-3 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-5 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-4 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-3.5 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-4 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-2 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-3 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-4 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-4 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-3 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-2 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-3 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-5 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-20 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-16 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-8 bg-marketing-surface-base-inverse-subtlest"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-16 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-14 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-10 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-9 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-6 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-5 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-16 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-8 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-6 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-12 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-5 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-11 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-10 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-6 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-14 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-5 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-10 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-5 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-12 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-2.5 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-6 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-8 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-6 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-6 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-7 bg-marketing-surface-faded"
                                    }), (0, d.jsx)("span", {
                                        className: "h-4 bg-marketing-surface-faded"
                                    })]
                                }), (0, d.jsxs)("div", {
                                    className: "mx-4 flex items-start justify-between px-[6%]",
                                    children: [(0, d.jsx)(k.H, {
                                        size: "sm",
                                        type: "pin"
                                    }), (0, d.jsxs)("div", {
                                        className: "flex flex-col gap-1.5",
                                        children: [(0, d.jsx)(k.H, {
                                            size: "sm",
                                            appearance: "comments",
                                            type: "pin"
                                        }), (0, d.jsxs)("span", {
                                            className: "text-sm",
                                            children: [(0, d.jsx)("span", {
                                                className: "font-medium",
                                                children: "@Guillaume"
                                            }), " ", (0, d.jsx)("span", {
                                                className: "text-marketing-subtle",
                                                children: "Love the drop!"
                                            })]
                                        })]
                                    }), (0, d.jsx)(k.H, {
                                        size: "sm",
                                        type: "pin"
                                    })]
                                })]
                            })
                        })
                    })
                }, {}),
                name: "Media player",
                icon: (0, d.jsx)("svg", {
                    width: "16",
                    height: "16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, d.jsx)("path", {
                        d: "M7 3.5 4 6H2a.5.5 0 0 0-.5.5v3c0 .28.22.5.5.5h2l3 2.5v-9Zm3 2c.62.63 1 1.62 1 2.5a3.7 3.7 0 0 1-1 2.5M12.5 3a7.4 7.4 0 0 1 2 5 7.4 7.4 0 0 1-2 5",
                        stroke: "currentColor",
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })
                })
            }, {
                visual: (0, d.jsx)(function() {
                    return (0, d.jsxs)("div", {
                        "aria-label": "Illustration of a collaborative whiteboard with comments using Liveblocks.",
                        className: "pointer-events-none absolute inset-0 flex scale-50 select-none flex-col items-center justify-center lg:scale-90 xl:scale-100",
                        role: "img",
                        children: [(0, d.jsxs)("svg", {
                            width: "436",
                            height: "290",
                            viewBox: "0 0 436 290",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            className: "absolute",
                            children: [(0, d.jsx)("rect", {
                                x: "57",
                                y: "48",
                                width: "98",
                                height: "98",
                                rx: "4",
                                className: "fill-marketing-surface-faded"
                            }), (0, d.jsx)("circle", {
                                cx: "253",
                                cy: "165",
                                r: "54",
                                className: "fill-marketing-surface-faded"
                            }), (0, d.jsx)("path", {
                                d: "M87.4922 134.828C98.8351 134.828 110.178 134.828 121.521 134.828C129.92 134.828 114.794 138.758 112.91 139.168C108.726 140.078 100.442 142.268 100.442 142.268C100.442 142.268 108.348 142.036 112.29 142.268C115.691 142.468 105.064 145.912 104.3 146.676C101.513 149.463 109.491 147.37 105.402 149.707C102.045 151.625 98.6287 153.393 101.131 157.147",
                                className: "stroke-marketing-divider-boldest",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }), (0, d.jsx)("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M132.806 66.7326C133.547 66.3621 133.847 65.4611 133.477 64.7201C133.106 63.9792 132.205 63.6788 131.464 64.0493C129.58 64.9915 128.092 66.3551 126.932 67.9507C125.98 67.1776 124.876 66.5415 123.639 66.3869C122.817 66.2842 122.068 66.8672 121.965 67.6893C121.862 68.5113 122.445 69.261 123.267 69.3637C123.812 69.4319 124.512 69.7903 125.39 70.5775C125.218 70.9418 125.059 71.3116 124.911 71.6854C123.666 74.8293 123.195 78.3537 123.195 81.5098C123.195 82.3382 123.867 83.0098 124.695 83.0098C125.524 83.0098 126.195 82.3382 126.195 81.5098C126.195 78.7001 126.607 75.6671 127.611 73.0203C127.763 73.2115 127.917 73.4071 128.071 73.6067C128.444 74.087 128.843 74.6182 129.246 75.1557L129.247 75.1558C129.782 75.8679 130.325 76.5907 130.824 77.2199C131.727 78.3582 132.699 79.4745 133.712 80.2345C134.375 80.7316 135.315 80.5973 135.812 79.9345C136.31 79.2718 136.175 78.3316 135.512 77.8345C134.83 77.3225 134.058 76.4702 133.174 75.3556C132.67 74.7196 132.194 74.0848 131.699 73.4255C131.301 72.8939 130.89 72.3463 130.443 71.7692C130.007 71.2066 129.555 70.6416 129.089 70.1014C130.054 68.6578 131.28 67.4956 132.806 66.7326Z",
                                fill: "fill-marketing-surface-base"
                            }), (0, d.jsx)("path", {
                                d: "M240 148C279.048 148 317.961 146 357 146",
                                className: "stroke-marketing-divider-boldest",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }), (0, d.jsx)("path", {
                                d: "M240 149C240.727 158.446 242 167.674 242 177.222C242 190.74 240.18 204.178 240 217.667C239.856 228.439 239 239.154 239 250",
                                className: "stroke-marketing-divider-boldest",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }), (0, d.jsx)("path", {
                                d: "M238 250.998C253.798 250.489 269.557 249.109 285.389 249.109C307.617 249.109 329.777 250.998 352 250.998",
                                className: "stroke-marketing-divider-boldest",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }), (0, d.jsx)("path", {
                                d: "M348 142C348 171.322 350 200.585 350 229.889C350 235.602 351 252.713 351 247",
                                className: "stroke-marketing-divider-boldest",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }), (0, d.jsx)("path", {
                                d: "M253 166.998C256.323 165.521 259.993 165.998 263.556 165.998C271.371 165.998 279.304 165.459 287 166.998",
                                className: "stroke-marketing-divider-boldest",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }), (0, d.jsx)("path", {
                                d: "M253 181C258.424 181.417 263.538 182 269 182",
                                className: "stroke-marketing-divider-boldest",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }), (0, d.jsx)("path", {
                                d: "M253 196C266.715 196 280.34 195 294 195",
                                className: "stroke-marketing-divider-boldest",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }), (0, d.jsx)("path", {
                                d: "M56 226C56 211.357 69.6992 187.805 86.6667 197.167C97.0094 202.873 105.86 205.788 118.222 204.333C123.764 203.681 127.292 201.97 131.111 198.111C137.44 191.715 144.269 185.962 151 180",
                                className: "stroke-marketing-divider-boldest",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }), (0, d.jsx)("path", {
                                d: "M285 62C290.965 67.3027 298.535 69.6821 304.778 74.2222C305.807 74.9706 310.822 67.9844 311.444 67.3333C321.672 56.6365 334.043 49.8196 347 43",
                                className: "stroke-marketing-divider-boldest",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            })]
                        }), (0, d.jsx)(k.H, {
                            className: "absolute translate-x-16 translate-y-6",
                            type: "pin",
                            appearance: "comments",
                            size: "md"
                        }), (0, d.jsx)(k.H, {
                            className: "absolute -translate-x-24 -translate-y-10",
                            type: "pin",
                            size: "md"
                        })]
                    })
                }, {}),
                name: "Whiteboard",
                icon: (0, d.jsx)("svg", {
                    width: "16",
                    height: "16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, d.jsx)("path", {
                        d: "M2.75 14h3c.41 0 .75-.34.75-.75v-3a.75.75 0 0 0-.75-.75h-3a.75.75 0 0 0-.75.75v3c0 .41.34.75.75.75Zm9 0a2.25 2.25 0 1 0 0-4.5 2.25 2.25 0 0 0 0 4.5Zm-6.7-8.29L7.6 2.1a.5.5 0 0 1 .82 0l2.54 3.62a.5.5 0 0 1-.41.79H5.46a.5.5 0 0 1-.4-.79Z",
                        stroke: "currentColor",
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })
                })
            }, {
                visual: (0, d.jsx)(function() {
                    return (0, d.jsxs)("div", {
                        "aria-label": "Illustration of a collaborative text editor with comments using Liveblocks.",
                        className: "pointer-events-none absolute inset-0 flex scale-50 select-none flex-col items-center justify-center lg:scale-90 xl:scale-100",
                        role: "img",
                        children: [(0, d.jsxs)("svg", {
                            width: "436",
                            height: "290",
                            viewBox: "0 0 436 290",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            className: "absolute",
                            children: [(0, d.jsx)("rect", {
                                x: "64",
                                y: "57",
                                width: "194",
                                height: "20",
                                rx: "4",
                                className: "fill-marketing-subtlest"
                            }), (0, d.jsx)("rect", {
                                x: "64",
                                y: "105",
                                width: "298",
                                height: "10",
                                rx: "4",
                                className: "fill-marketing-surface-faded"
                            }), (0, d.jsx)("rect", {
                                x: "64",
                                y: "183",
                                width: "268",
                                height: "10",
                                rx: "4",
                                className: "fill-marketing-surface-faded"
                            }), (0, d.jsx)("rect", {
                                x: "64",
                                y: "125",
                                width: "308",
                                height: "10",
                                rx: "4",
                                className: "fill-marketing-surface-faded"
                            }), (0, d.jsx)("rect", {
                                x: "64",
                                y: "203",
                                width: "308",
                                height: "10",
                                rx: "4",
                                className: "fill-marketing-surface-faded"
                            }), (0, d.jsx)("rect", {
                                x: "64",
                                y: "145",
                                width: "138",
                                height: "10",
                                rx: "4",
                                className: "fill-marketing-surface-faded"
                            }), (0, d.jsx)("rect", {
                                x: "64",
                                y: "223",
                                width: "98",
                                height: "10",
                                rx: "4",
                                className: "fill-marketing-surface-faded"
                            })]
                        }), (0, d.jsx)(k.H, {
                            className: "absolute translate-x-36 translate-y-14",
                            type: "pin",
                            appearance: "comments",
                            size: "md"
                        }), (0, d.jsx)(k.H, {
                            className: "absolute translate-x-3 translate-y-4",
                            type: "pin",
                            size: "md"
                        })]
                    })
                }, {}),
                name: "Text editor",
                icon: (0, d.jsx)("svg", {
                    width: "16",
                    height: "16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, d.jsx)("path", {
                        d: "M11 2.5c.5-.5 1.79-.71 2.5 0s.5 2 0 2.5l-7.27 7.27a4 4 0 0 1-1.73 1.01L2 14l.72-2.5a4 4 0 0 1 1.01-1.73L11 2.5Z",
                        stroke: "currentColor",
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })
                })
            }];
            var eO = () => (0, d.jsx)(eT, {
                    className: "absolute inset-0 -mb-gutter flex flex-col justify-between",
                    items: eP
                }),
                eR = e => {
                    let {
                        mentionName: s = "Alicia",
                        commentText: t = "Can you update the logo?"
                    } = e;
                    return (0, d.jsx)("div", {
                        role: "img",
                        "aria-label": "Illustration of a comment attached to a website.",
                        className: "pointer-events-none absolute inset-0 flex select-none items-center justify-start pt-gutter",
                        children: (0, d.jsxs)("div", {
                            className: "ml-gutter flex items-start gap-3 pl-gutter",
                            children: [(0, d.jsx)(k.H, {
                                type: "pin",
                                appearance: "comments",
                                size: "lg"
                            }), (0, d.jsxs)("div", {
                                className: "flex w-96 flex-col justify-between gap-6 rounded-lg bg-marketing-surface-faded-subtle p-6 text-xl",
                                children: [(0, d.jsxs)("div", {
                                    className: "truncate text-marketing-subtle",
                                    children: [(0, d.jsxs)("span", {
                                        className: "font-medium text-marketing",
                                        children: ["@", s]
                                    }), " ", (0, d.jsx)("span", {
                                        children: t
                                    })]
                                }), (0, d.jsxs)("div", {
                                    className: "flex items-center gap-3 opacity-30",
                                    children: [(0, d.jsx)("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        width: "24",
                                        height: "24",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        children: (0, d.jsxs)("g", {
                                            stroke: "currentColor",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: "1.8",
                                            children: [(0, d.jsx)("path", {
                                                d: "M11.998 15.6a3.6 3.6 0 1 0 0-7.2 3.6 3.6 0 0 0 0 7.2Z"
                                            }), (0, d.jsx)("path", {
                                                d: "M15.602 8.4v4.44c0 1.326 1.026 2.52 2.28 2.52a2.544 2.544 0 0 0 2.52-2.52V12a8.4 8.4 0 1 0-3.36 6.72"
                                            })]
                                        })
                                    }), (0, d.jsx)("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        width: "24",
                                        height: "24",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        children: (0, d.jsxs)("g", {
                                            stroke: "currentColor",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: "1.8",
                                            children: [(0, d.jsx)("path", {
                                                d: "M12.002 20.4a8.4 8.4 0 1 0 0-16.8 8.4 8.4 0 0 0 0 16.8Z"
                                            }), (0, d.jsx)("path", {
                                                d: "M9 13.8s.9 1.8 3 1.8 3-1.8 3-1.8M9.6 9.6h.008M14.398 9.6h.009M9.597 9.9a.3.3 0 1 0 0-.6.3.3 0 0 0 0 .6ZM14.402 9.9a.3.3 0 1 0 0-.6.3.3 0 0 0 0 .6Z"
                                            })]
                                        })
                                    }), (0, d.jsx)("svg", {
                                        width: "24",
                                        height: "24",
                                        viewBox: "0 0 24 24",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, d.jsx)("path", {
                                            d: "M16.8926 14.0829L12.425 18.4269C10.565 20.2353 7.47136 20.2353 5.61136 18.4269C3.75976 16.6269 3.75976 13.6029 5.61136 11.8029L12.4886 5.11529C13.7294 3.90809 15.7934 3.90689 17.0354 5.11169C18.2714 6.31169 18.2738 8.33009 17.039 9.53249L10.1462 16.2189C9.83929 16.5093 9.43285 16.6711 9.01036 16.6711C8.58786 16.6711 8.18142 16.5093 7.87456 16.2189C7.72623 16.0757 7.60817 15.9042 7.52737 15.7146C7.44656 15.525 7.40466 15.321 7.40416 15.1149C7.40416 14.7009 7.57216 14.3037 7.87456 14.0109L12.4178 9.59849",
                                            stroke: "currentColor",
                                            strokeWidth: "1.8"
                                        })
                                    })]
                                })]
                            })]
                        })
                    })
                },
                eq = e => {
                    let {
                        className: s
                    } = e;
                    return (0, d.jsx)("div", {
                        role: "img",
                        "aria-label": "Illustration of a live avatar stack, which shows who is currently connected.",
                        className: (0, X.cn)("pointer-events-none select-none", s),
                        children: (0, d.jsxs)("ul", {
                            className: "flex",
                            children: [(0, d.jsxs)("li", {
                                className: "relative",
                                children: [(0, d.jsx)(k.H, {
                                    className: "relative after:absolute after:-inset-px after:rounded-full after:border-2 after:border-black",
                                    size: "lg"
                                }), (0, d.jsx)("span", {
                                    className: "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-sm font-medium",
                                    children: "+2"
                                })]
                            }), (0, d.jsxs)("li", {
                                className: "relative -ml-2",
                                children: [(0, d.jsx)(k.H, {
                                    className: "relative after:absolute after:-inset-px after:rounded-full after:border-2 after:border-black",
                                    size: "lg"
                                }), (0, d.jsx)("span", {
                                    className: "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-sm font-medium",
                                    children: "A"
                                })]
                            }), (0, d.jsxs)("li", {
                                className: "relative -ml-2",
                                children: [(0, d.jsx)(k.H, {
                                    className: "relative after:absolute after:-inset-px after:rounded-full after:border-2 after:border-black",
                                    size: "lg"
                                }), (0, d.jsx)("span", {
                                    className: "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-sm font-medium",
                                    children: "G"
                                })]
                            }), (0, d.jsxs)("li", {
                                className: "relative ml-4",
                                children: [(0, d.jsx)(k.H, {
                                    size: "lg",
                                    appearance: "realtime-apis"
                                }), (0, d.jsx)("span", {
                                    className: "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-sm font-medium",
                                    children: "M"
                                })]
                            })]
                        })
                    })
                };
            let eB = e => {
                let {
                    className: s,
                    author: t,
                    content: a,
                    isActive: i
                } = e;
                return (0, d.jsxs)("div", {
                    className: (0, X.cn)(s, t && "flex flex-col items-start"),
                    children: [t ? (0, d.jsx)("div", {
                        className: (0, X.cn)("flex h-5 items-center rounded-t px-1.5 text-xs font-medium", i ? "bg-marketing-surface-product-realtime-apis" : "bg-white/30"),
                        children: (0, d.jsx)("span", {
                            className: "translate-y-px",
                            children: t
                        })
                    }) : null, (0, d.jsx)("div", {
                        className: (0, X.cn)("flex h-8 w-full items-center px-2 font-mono text-sm", t ? "rounded-b rounded-r border-2" : "rounded border", i ? "border-marketing-divider-product-realtime-apis" : t ? "border-white/30" : "border-white/20"),
                        children: a
                    })]
                })
            };
            var eV = () => (0, d.jsx)("div", {
                    role: "img",
                    "aria-label": "Illustration of a collaborative spreadsheet.",
                    className: "pointer-events-none w-full max-w-72 select-none",
                    children: (0, d.jsxs)("div", {
                        className: "grid grid-cols-2 gap-1",
                        children: [(0, d.jsx)(eB, {
                            author: "Adrien",
                            content: "3"
                        }), (0, d.jsx)("div", {}), (0, d.jsx)("div", {}), (0, d.jsx)(eB, {
                            className: "-mt-5",
                            author: "Marc",
                            content: (0, d.jsx)(d.Fragment, {
                                children: (0, d.jsxs)("span", {
                                    className: "text-marketing-subtler [&>span]:text-marketing",
                                    children: ["=(", (0, d.jsx)("span", {
                                        children: "A1"
                                    }), "*", (0, d.jsx)("span", {
                                        children: "13"
                                    }), ")/2"]
                                })
                            }),
                            isActive: !0
                        }), (0, d.jsx)(eB, {
                            content: "2.25"
                        })]
                    })
                }),
                eF = t(17245);

            function eD() {
                return (eD = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            var eW = function(e) {
                return m.createElement("svg", eD({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 32,
                    height: 32,
                    fill: "currentColor",
                    viewBox: "0 0 24 24"
                }, e), l || (l = m.createElement("path", {
                    d: "M15.852 8.981h-4.588V0h4.588c2.476 0 4.49 2.014 4.49 4.49s-2.014 4.491-4.49 4.491zM12.735 7.51h3.117c1.665 0 3.019-1.355 3.019-3.019s-1.355-3.019-3.019-3.019h-3.117V7.51zm0 1.471H8.148c-2.476 0-4.49-2.014-4.49-4.49S5.672 0 8.148 0h4.588v8.981zm-4.587-7.51c-1.665 0-3.019 1.355-3.019 3.019s1.354 3.02 3.019 3.02h3.117V1.471H8.148zm4.587 15.019H8.148c-2.476 0-4.49-2.014-4.49-4.49s2.014-4.49 4.49-4.49h4.588v8.98zM8.148 8.981c-1.665 0-3.019 1.355-3.019 3.019s1.355 3.019 3.019 3.019h3.117V8.981H8.148zM8.172 24c-2.489 0-4.515-2.014-4.515-4.49s2.014-4.49 4.49-4.49h4.588v4.441c0 2.503-2.047 4.539-4.563 4.539zm-.024-7.51a3.023 3.023 0 0 0-3.019 3.019c0 1.665 1.365 3.019 3.044 3.019 1.705 0 3.093-1.376 3.093-3.068v-2.97H8.148zm7.704 0h-.098c-2.476 0-4.49-2.014-4.49-4.49s2.014-4.49 4.49-4.49h.098c2.476 0 4.49 2.014 4.49 4.49s-2.014 4.49-4.49 4.49zm-.097-7.509c-1.665 0-3.019 1.355-3.019 3.019s1.355 3.019 3.019 3.019h.098c1.665 0 3.019-1.355 3.019-3.019s-1.355-3.019-3.019-3.019h-.098z"
                })))
            };

            function eX() {
                return (eX = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            var eG = function(e) {
                return m.createElement("svg", eX({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 32,
                    height: 32,
                    fill: "currentColor",
                    viewBox: "0 0 800 800"
                }, e), r || (r = m.createElement("path", {
                    d: "M0 400C0 179.44 179.44 0 400 0c89.078 0 173.39 28.66 243.825 82.88l-92.953 120.747c-43.55-33.524-95.722-51.246-150.872-51.246-136.537 0-247.619 111.082-247.619 247.619S263.463 647.619 400 647.619c109.97 0 203.421-72.049 235.627-171.429H400V323.81h400V400c0 220.56-179.44 400-400 400S0 620.56 0 400Z"
                })))
            };

            function eU() {
                return (eU = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            var eK = function(e) {
                return m.createElement("svg", eU({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 32,
                    height: 32,
                    fill: "currentColor",
                    viewBox: "0 0 50 50"
                }, e), c || (c = m.createElement("path", {
                    d: "M41.3 44c.5-.4.9-.8 1.3-1.3 9.8-9.8 9.8-25.6 0-35.4-9.8-9.8-25.6-9.8-35.4 0-.4.5-.8.9-1.2 1.4L41.3 44ZM38.3 46.2 3.8 11.7c-.7 1.1-1.3 2.2-1.8 3.4L34.9 48c1.2-.5 2.3-1.1 3.4-1.8ZM31.1 49.3.7 18.9c-.4 1.5-.6 3-.7 4.5L26.6 50c1.5-.1 3-.3 4.5-.7ZM21.1 49.8.2 28.9c.8 5.1 3.1 9.9 7 13.9 4 3.8 8.9 6.2 13.9 7Z"
                })))
            };

            function eJ() {
                return (eJ = Object.assign ? Object.assign.bind() : function(e) {
                    for (var s = 1; s < arguments.length; s++) {
                        var t = arguments[s];
                        for (var a in t)({}).hasOwnProperty.call(t, a) && (e[a] = t[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            var eY = function(e) {
                    return m.createElement("svg", eJ({
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 32,
                        height: 32,
                        fill: "currentColor",
                        viewBox: "0 0 60 60"
                    }, e), o || (o = m.createElement("path", {
                        d: "M13.031 12.467c1.68 1.365 2.31 1.26 5.464 1.05l29.733-1.785c.63 0 .106-.63-.104-.734l-4.938-3.57c-.946-.734-2.207-1.575-4.623-1.365l-28.79 2.1c-1.05.104-1.26.629-.842 1.05l4.1 3.254Zm1.785 6.93v31.285c0 1.68.84 2.31 2.732 2.206l32.677-1.89c1.892-.105 2.103-1.262 2.103-2.627V17.296c0-1.364-.525-2.1-1.683-1.994l-34.148 1.994c-1.26.106-1.68.736-1.68 2.1Zm32.26 1.678c.209.946 0 1.89-.948 1.997l-1.575.314v23.096c-1.367.735-2.627 1.155-3.678 1.155-1.682 0-2.103-.525-3.363-2.1L27.214 29.37v15.643l3.259.735s0 1.889-2.63 1.889l-7.248.42c-.21-.42 0-1.469.735-1.68l1.892-.523V25.17l-2.626-.21c-.211-.946.314-2.31 1.786-2.416l7.775-.524L40.875 38.4V23.911l-2.733-.314c-.21-1.156.63-1.996 1.681-2.1l7.252-.422ZM7.354 5.328l29.947-2.205c3.678-.315 4.624-.104 6.936 1.575l9.559 6.719c1.577 1.155 2.103 1.47 2.103 2.73v36.85c0 2.31-.841 3.675-3.783 3.884l-34.777 2.1c-2.208.106-3.26-.209-4.416-1.68l-7.04-9.133c-1.26-1.682-1.785-2.94-1.785-4.411V9.002c0-1.889.841-3.464 3.256-3.674Z"
                    })))
                },
                eQ = () => (0, d.jsxs)("div", {
                    role: "img",
                    "aria-label": "Illustration of Figma, Linear, Google, and Notion logos merging into a notification inbox.",
                    className: "pointer-events-none absolute inset-0 -mb-gutter flex select-none flex-col items-center justify-end pt-gutter",
                    children: [(0, d.jsxs)("div", {
                        className: "flex items-center gap-6",
                        children: [(0, d.jsx)(eW, {
                            className: "size-8 opacity-90"
                        }), (0, d.jsx)(eK, {
                            className: "size-8 opacity-90"
                        }), (0, d.jsx)(eG, {
                            className: "size-8 opacity-90"
                        }), (0, d.jsx)(eY, {
                            className: "size-9 opacity-90"
                        })]
                    }), (0, d.jsxs)("div", {
                        className: "relative mt-8 flex w-full flex-col items-center",
                        children: [(0, d.jsx)("svg", {
                            "aria-hidden": !0,
                            className: "absolute bottom-full left-1/2 h-10 w-auto -translate-x-1/2 translate-y-2 fill-white/30 blur-xl",
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 800 80",
                            children: (0, d.jsx)("path", {
                                d: "M400 80L0 0H800L400 80Z"
                            })
                        }), (0, d.jsxs)("div", {
                            className: "rounded-lg bg-marketing-surface-faded p-4 backdrop-blur-sm",
                            children: [(0, d.jsx)("svg", {
                                className: "relative size-12 opacity-90 md:size-12",
                                xmlns: "http://www.w3.org/2000/svg",
                                width: "32",
                                height: "32",
                                fill: "none",
                                viewBox: "0 0 32 32",
                                children: (0, d.jsx)("path", {
                                    fill: "currentColor",
                                    d: "M28.707 19.293 26 16.586V13a10.014 10.014 0 0 0-9-9.95V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-2.707 2.707A1 1 0 0 0 3 20v3a1 1 0 0 0 1 1h7v.777a5.152 5.152 0 0 0 4.5 5.198A5.005 5.005 0 0 0 21 25v-1h7a1 1 0 0 0 1-1v-3a1 1 0 0 0-.293-.707ZM19 25a3 3 0 0 1-6 0v-1h6v1Zm8-3H5v-1.586l2.707-2.707A1 1 0 0 0 8 17v-4a8 8 0 0 1 16 0v4a1 1 0 0 0 .293.707L27 20.414V22Z"
                                })
                            }), (0, d.jsx)(k.H, {
                                appearance: "notifications",
                                size: "md",
                                className: "absolute right-0 top-0 -translate-y-1/2 translate-x-1/2"
                            })]
                        }), (0, d.jsx)("div", {
                            className: "relative mt-5 flex h-6 w-full max-w-xs flex-col rounded-lg bg-gradient-to-b from-marketing-surface-faded to-transparent lg:h-16 lg:max-w-sm",
                            children: (0, d.jsx)("svg", {
                                className: "absolute left-1/2 top-0 h-2 w-auto -translate-x-1/2 -translate-y-full fill-marketing-surface-faded",
                                width: "32",
                                height: "16",
                                viewBox: "0 0 32 16",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: (0, d.jsx)("path", {
                                    d: "M16 0L0 16H32L16 0Z"
                                })
                            })
                        })]
                    })]
                }),
                e$ = t(54735),
                e0 = t(35710),
                e1 = t(6123),
                e2 = t(21611);

            function e3(e) {
                let {
                    position: s,
                    name: t,
                    color: a,
                    otherPresence: i,
                    setPresence: n,
                    shapeOne: l,
                    shapeTwo: r,
                    setShapeOne: c,
                    setShapeTwo: o
                } = e, x = (0, m.useRef)(null), h = (0, e1.R)(x), u = (0, m.useRef)({
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                }), [g, p] = (0, m.useState)(!1), [f, j] = (0, m.useState)(null), [v, b] = (0, m.useState)(24), [w, N] = (0, m.useState)(1), [k, y] = (0, m.useState)({
                    x: 0,
                    y: 0
                }), [L] = (0, e2.Z)(x);
                (0, m.useEffect)(() => {
                    N(L < 340 ? .5 : 1), b(L < 340 ? 16 : 24)
                }, [L]), (0, m.useEffect)(() => {
                    if (!h) return;
                    let e = () => {
                        e$.ZP.read(() => {
                            if (!x.current) return;
                            let {
                                top: e,
                                right: s,
                                bottom: t,
                                left: a
                            } = x.current.getBoundingClientRect();
                            u.current = {
                                top: e,
                                right: s,
                                bottom: t,
                                left: a
                            }
                        })
                    };
                    return e(), window.addEventListener("resize", e), window.addEventListener("scroll", e), () => {
                        window.removeEventListener("resize", e), window.removeEventListener("scroll", e)
                    }
                }, [h]), (0, m.useEffect)(() => {
                    if (!h) return;
                    let e = e => {
                            let s = u.current;
                            if (n({
                                    position: {
                                        x: Math.round(e.clientX - (s.left + (s.right - s.left) / 2)),
                                        y: Math.round(e.clientY - (s.top + (s.bottom - s.top) / 2))
                                    },
                                    selectedShape: f,
                                    name: t,
                                    color: a
                                }), !g || !f) return;
                            let i = "one" === f ? l : r,
                                d = (0, e0.u)(e.clientX - k.x, s.left + (v + i.width * w / 2), s.right - (v + i.width * w / 2)),
                                m = (0, e0.u)(e.clientY - k.y, s.top + (2 * v + i.height * w / 2), s.bottom - (2 * v + i.height * w / 2)),
                                x = {
                                    x: Math.round(d - (s.left + (s.right - s.left) / 2)) * (1 / w),
                                    y: Math.round(m - (s.top + (s.bottom - s.top) / 2)) * (1 / w)
                                };
                            "one" === f ? c(e => ({ ...e,
                                ...x
                            })) : "two" === f && o(e => ({ ...e,
                                ...x
                            }))
                        },
                        s = () => {
                            g && f && (p(!1), document.body.style.removeProperty("cursor"))
                        };
                    return window.addEventListener("pointermove", e), window.addEventListener("wheel", e), window.addEventListener("pointerup", s), () => {
                        window.removeEventListener("pointermove", e), window.removeEventListener("wheel", e), window.removeEventListener("pointerup", s)
                    }
                }, [a, g, h, t, k.x, k.y, v, w, f, n, c, o, l, r]);
                let C = (e, i) => {
                    j(e), n({
                        position: s,
                        selectedShape: e,
                        name: t,
                        color: a
                    }), p(!0), y(i), document.body.style.cursor = "grabbing", "one" === e ? (c(e => ({ ...e,
                        isHighest: !0
                    })), o(e => ({ ...e,
                        isHighest: !1
                    }))) : "two" === e && (o(e => ({ ...e,
                        isHighest: !0
                    })), c(e => ({ ...e,
                        isHighest: !1
                    })))
                };
                return (0, d.jsxs)("div", {
                    ref: x,
                    className: "absolute inset-0 flex select-none items-center justify-center",
                    onPointerDown: () => {
                        j(null), n({
                            position: s,
                            selectedShape: null,
                            name: t,
                            color: a
                        })
                    },
                    onPointerLeave: () => {
                        n({
                            position: null,
                            selectedShape: null,
                            name: t,
                            color: a
                        })
                    },
                    children: [(0, d.jsxs)("div", {
                        className: "flex items-center justify-center",
                        style: {
                            transform: "scale(".concat(w, ")")
                        },
                        children: [(0, d.jsx)(e4, {
                            shape: l,
                            onPointerDown: e => C("one", e),
                            isSelected: "one" === f,
                            isDragging: g
                        }), (0, d.jsx)(e4, {
                            shape: r,
                            onPointerDown: e => C("two", e),
                            isSelected: "two" === f,
                            isDragging: g
                        })]
                    }), (0, d.jsx)("div", {
                        className: "pointer-events-none absolute bottom-6 animate-mask-flare-loop select-none text-xs text-marketing-subtlest",
                        children: "Drag the shapes"
                    }), i.position && (0, d.jsxs)("div", {
                        className: "absolute will-change-transform",
                        style: {
                            transform: "translateX(".concat(i.position.x, "px) translateY(").concat(i.position.y, "px)")
                        },
                        children: [(0, d.jsx)("svg", {
                            className: "size-3.5",
                            xmlns: "http://www.w3.org/2000/svg",
                            width: "20",
                            height: "20",
                            fill: "none",
                            viewBox: "0 0 20 20",
                            children: (0, d.jsx)("path", {
                                fill: i.color,
                                d: "M19.438 6.716 1.115.05A.832.832 0 0 0 .05 1.116L6.712 19.45a.834.834 0 0 0 1.557.025l3.198-8 7.995-3.2a.833.833 0 0 0 0-1.559h-.024Z"
                            })
                        }), (0, d.jsx)("div", {
                            className: "absolute left-3.5 top-3.5 flex h-6 items-center whitespace-nowrap rounded px-2 text-xs font-medium text-marketing-inverse",
                            style: {
                                backgroundColor: i.color
                            },
                            children: i.name
                        })]
                    })]
                })
            }

            function e4(e) {
                let {
                    shape: s,
                    onPointerDown: t,
                    isSelected: a,
                    isDragging: i
                } = e, n = (0, m.useRef)(null);
                return (0, d.jsx)("div", {
                    ref: n,
                    className: "absolute",
                    onPointerDown: e => {
                        if (e.stopPropagation(), !n.current) return;
                        let {
                            top: s,
                            right: a,
                            bottom: i,
                            left: l
                        } = n.current.getBoundingClientRect();
                        t({
                            x: e.clientX - (l + (a - l) / 2),
                            y: e.clientY - (s + (i - s) / 2)
                        })
                    },
                    style: {
                        borderRadius: "ellipse" === s.type ? 9999 : 8,
                        cursor: i ? "grabbing" : "grab",
                        background: s.background,
                        width: s.width,
                        height: s.height,
                        transform: "translate3d(".concat(s.x, "px, ").concat(s.y, "px, 0)"),
                        boxShadow: "0px 0px 2px 0px rgba(255, 255, 255, 0.30) inset, 0px 0px 20px 0px ".concat(s.colorA, " inset, 0px 0px 40px 0px ").concat(s.colorB, " inset"),
                        zIndex: s.isHighest ? 1 : 0,
                        touchAction: "none"
                    },
                    children: (0, d.jsx)("div", {
                        className: (0, X.cn)("pointer-events-none absolute -inset-1 transform transition-transform", {
                            "scale-95 opacity-0": !a,
                            "scale-100 opacity-100": a
                        }),
                        style: {
                            border: "2px solid rgba(255, 255, 255, 0.2)",
                            borderRadius: "ellipse" === s.type ? 9999 : 12
                        }
                    })
                })
            }
            let e5 = {
                    type: "ellipse",
                    x: -60,
                    y: 0,
                    width: 84,
                    height: 84,
                    background: "black",
                    colorA: "rgba(255,255,255,0.6)",
                    colorB: "#595959",
                    isHighest: !1
                },
                e6 = {
                    type: "rectangle",
                    x: 60,
                    y: 0,
                    width: 80,
                    height: 80,
                    background: "black",
                    colorA: "#FF2E00",
                    colorB: "#FF00B8",
                    isHighest: !0
                };

            function e7() {
                let [e, s] = (0, m.useState)(e5), [t, a] = (0, m.useState)(e6), [i, n] = (0, m.useState)({
                    position: null,
                    selectedShape: null,
                    name: "User A",
                    color: "var(--lb-marketing-color-fill)"
                }), [l, r] = (0, m.useState)({
                    position: null,
                    selectedShape: null,
                    name: "User B",
                    color: "var(--lb-marketing-color-fill-subtler)"
                });
                return (0, d.jsxs)(d.Fragment, {
                    children: [(0, d.jsx)(b.S.Cell, {
                        className: "flex aspect-[4/3] flex-col sm:aspect-video md:aspect-square",
                        noPadding: !0,
                        children: (0, d.jsx)(e9, {
                            name: i.name,
                            visual: (0, d.jsx)(e3, {
                                position: i.position,
                                name: i.name,
                                color: i.color,
                                otherPresence: l,
                                setPresence: n,
                                shapeOne: e,
                                shapeTwo: t,
                                setShapeOne: e => {
                                    s(e)
                                },
                                setShapeTwo: e => {
                                    a(e)
                                }
                            })
                        })
                    }), (0, d.jsx)(b.S.Cell, {
                        className: "flex aspect-[4/3] flex-col sm:aspect-video md:aspect-square",
                        noPadding: !0,
                        children: (0, d.jsx)(e9, {
                            name: l.name,
                            visual: (0, d.jsx)(e3, {
                                position: l.position,
                                name: l.name,
                                color: l.color,
                                otherPresence: i,
                                setPresence: r,
                                shapeOne: e,
                                shapeTwo: t,
                                setShapeOne: e => {
                                    s(e)
                                },
                                setShapeTwo: e => {
                                    a(e)
                                }
                            })
                        })
                    })]
                })
            }

            function e9(e) {
                let {
                    visual: s,
                    name: t
                } = e;
                return (0, d.jsxs)("div", {
                    className: "relative flex-1 overflow-hidden",
                    children: [(0, d.jsxs)("div", {
                        className: "pointer-events-none absolute left-4 top-4 z-10 flex items-center space-x-1 md:left-5 md:top-5",
                        children: [(0, d.jsx)("span", {
                            className: "size-1.5 rounded-full bg-white/20"
                        }), (0, d.jsx)("span", {
                            className: "size-1.5 rounded-full bg-white/20"
                        }), (0, d.jsx)("span", {
                            className: "size-1.5 rounded-full bg-white/20"
                        })]
                    }), t && (0, d.jsx)("div", {
                        className: "pointer-events-none absolute right-4 top-2 flex h-9 items-center text-xs text-marketing-subtler md:right-6 md:top-2",
                        children: t
                    }), (0, d.jsx)("div", {
                        className: "absolute inset-0",
                        children: s
                    })]
                })
            }
            let e8 = (0, eE.$)("comments"),
                se = (0, eE.$)("notifications"),
                ss = (0, eE.$)("text-editor"),
                st = (0, eE.$)("realtime-apis");
            var sa = () => (0, d.jsx)("section", {
                    children: (0, d.jsx)(w.Z, {
                        children: (0, d.jsxs)(b.S.System, {
                            children: [(0, d.jsxs)(b.S, {
                                columns: {
                                    sm: 1,
                                    md: 1,
                                    lg: 3
                                },
                                children: [(0, d.jsxs)(b.S.Cell, {
                                    children: [(0, d.jsx)(S(), {
                                        className: "-ml-0.5 -mt-1 size-16 sm:-ml-1 sm:-mt-2 sm:size-20 md:-ml-1.5 md:size-24 lg:-ml-2 lg:-mt-3 lg:size-32",
                                        src: "/images/products/comments.png",
                                        alt: "Comments",
                                        width: 128,
                                        height: 128,
                                        quality: 20
                                    }), (0, d.jsx)(B.Z, {
                                        isLeftAligned: !0,
                                        matchingSize: !0,
                                        className: "mt-5 max-w-64 lg:max-w-72",
                                        headingAs: "h2",
                                        heading: e8.title,
                                        description: "".concat(e8.description.mid, "."),
                                        actions: (0, d.jsxs)(v.Z, {
                                            href: e8.href,
                                            appearance: "primary",
                                            size: "md",
                                            children: ["Learn more ", (0, d.jsx)("span", {
                                                className: "sr-only",
                                                children: "about Comments"
                                            })]
                                        })
                                    })]
                                }), (0, d.jsx)(b.S.Cell, {
                                    column: {
                                        sm: 1,
                                        md: 1,
                                        lg: 2
                                    },
                                    noPadding: !0,
                                    children: (0, d.jsxs)(b.S, {
                                        columns: {
                                            sm: 1,
                                            md: 2,
                                            lg: 2
                                        },
                                        rows: {
                                            sm: 3,
                                            md: 1,
                                            lg: 2
                                        },
                                        children: [(0, d.jsxs)(b.S.Cell, {
                                            className: "flex flex-col lg:aspect-square",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-xs",
                                                isLeftAligned: !0,
                                                size: "sm",
                                                matchingSize: !0,
                                                headingAs: "h3",
                                                heading: "Mentions",
                                                description: "Allow users to mention collaborators for seamless feedback."
                                            }), (0, d.jsx)(N.Z, {
                                                children: (0, d.jsx)(eR, {})
                                            })]
                                        }), (0, d.jsxs)(b.S.Cell, {
                                            className: "flex flex-col lg:aspect-square",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-xs",
                                                isLeftAligned: !0,
                                                size: "sm",
                                                matchingSize: !0,
                                                headingAs: "h3",
                                                heading: "Bring AI in the conversation",
                                                description: (0, d.jsx)(d.Fragment, {
                                                    children: "Get feedback from both humans and AI agents, whatever works best for you."
                                                })
                                            }), (0, d.jsx)(N.Z, {
                                                children: (0, d.jsx)(ek, {})
                                            })]
                                        }), (0, d.jsx)(b.S.Cell, {
                                            className: "text-center",
                                            column: {
                                                sm: 1,
                                                md: 2,
                                                lg: 2
                                            },
                                            children: (0, d.jsxs)("p", {
                                                className: "f-marketing-body-sm py-gutter text-marketing-subtler sm:py-0",
                                                children: ["Fully integrated with", " ", (0, d.jsxs)("span", {
                                                    className: "whitespace-nowrap",
                                                    children: [(0, d.jsx)(S(), {
                                                        className: "ml-1 mr-1.5 inline size-4 select-none lg:size-5",
                                                        src: "/images/products/notifications.png",
                                                        width: 20,
                                                        height: 20,
                                                        alt: "Notifications",
                                                        quality: 5,
                                                        "aria-hidden": !0
                                                    }), (0, d.jsx)("strong", {
                                                        className: "font-medium text-marketing",
                                                        children: "Notifications"
                                                    })]
                                                }), " ", "and", " ", (0, d.jsxs)("span", {
                                                    className: "whitespace-nowrap",
                                                    children: [(0, d.jsx)(S(), {
                                                        className: "ml-1 mr-1.5 inline size-4 select-none lg:size-5",
                                                        src: "/images/products/text-editor.png",
                                                        width: 20,
                                                        height: 20,
                                                        alt: "Text Editor",
                                                        quality: 5,
                                                        "aria-hidden": !0
                                                    }), (0, d.jsx)("strong", {
                                                        className: "font-medium text-marketing",
                                                        children: "Text\xa0Editor"
                                                    })]
                                                })]
                                            })
                                        }), (0, d.jsxs)(b.S.Cell, {
                                            column: {
                                                sm: 1,
                                                md: 2,
                                                lg: 2
                                            },
                                            className: "flex flex-col lg:aspect-video",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-xs",
                                                isLeftAligned: !0,
                                                size: "sm",
                                                matchingSize: !0,
                                                headingAs: "h3",
                                                heading: "Endlessly customizable",
                                                description: "Add a perfectly on-brand commenting system to any part of your product."
                                            }), (0, d.jsx)(N.Z, {
                                                pointerEventsEnabled: !0,
                                                children: (0, d.jsx)(eO, {})
                                            })]
                                        })]
                                    })
                                })]
                            }), (0, d.jsxs)(b.S, {
                                columns: {
                                    sm: 1,
                                    md: 1,
                                    lg: 3
                                },
                                rows: {
                                    sm: 1
                                },
                                children: [(0, d.jsxs)(b.S.Cell, {
                                    children: [(0, d.jsx)(S(), {
                                        className: "-ml-1.5 size-16 sm:-ml-2 sm:size-20 md:-ml-2.5 md:size-24 lg:-ml-3.5 lg:size-32",
                                        src: "/images/products/notifications.png",
                                        alt: "Notifications",
                                        width: 128,
                                        height: 128,
                                        quality: 20
                                    }), (0, d.jsx)(B.Z, {
                                        isLeftAligned: !0,
                                        matchingSize: !0,
                                        className: "mt-2 max-w-64 lg:max-w-72",
                                        headingAs: "h2",
                                        heading: se.title,
                                        description: "".concat(se.description.mid, "."),
                                        actions: (0, d.jsxs)(v.Z, {
                                            href: se.href,
                                            appearance: "primary",
                                            size: "md",
                                            children: ["Learn more", " ", (0, d.jsx)("span", {
                                                className: "sr-only",
                                                children: "about Notifications"
                                            })]
                                        })
                                    })]
                                }), (0, d.jsx)(b.S.Cell, {
                                    column: {
                                        sm: 1,
                                        md: 1,
                                        lg: 2
                                    },
                                    noPadding: !0,
                                    children: (0, d.jsxs)(b.S, {
                                        columns: {
                                            sm: 1,
                                            md: 2,
                                            lg: 2
                                        },
                                        rows: {
                                            sm: 3,
                                            md: 1,
                                            lg: 2
                                        },
                                        children: [(0, d.jsxs)(b.S.Cell, {
                                            column: {
                                                sm: 1,
                                                md: 1,
                                                lg: 1
                                            },
                                            className: "flex flex-col lg:aspect-square",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-xs",
                                                isLeftAligned: !0,
                                                size: "sm",
                                                matchingSize: !0,
                                                headingAs: "h3",
                                                heading: "Optimized for collaboration",
                                                description: "Crafted to match UX patterns world‑class companies spent years optimizing."
                                            }), (0, d.jsx)(N.Z, {
                                                children: (0, d.jsx)(eQ, {})
                                            })]
                                        }), (0, d.jsxs)(b.S.Cell, {
                                            column: {
                                                sm: 1,
                                                md: 1,
                                                lg: 1
                                            },
                                            className: "flex flex-col lg:aspect-square",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-xs sm:max-w-sm",
                                                isLeftAligned: !0,
                                                size: "sm",
                                                matchingSize: !0,
                                                headingAs: "h3",
                                                heading: "Custom notifications",
                                                description: "Feed your own custom notifications into the Liveblocks notification system."
                                            }), (0, d.jsx)(N.Z, {
                                                children: (0, d.jsx)(eF.Z, {})
                                            })]
                                        }), (0, d.jsx)(b.S.Cell, {
                                            className: "text-center",
                                            column: {
                                                sm: 1,
                                                md: 2,
                                                lg: 2
                                            },
                                            children: (0, d.jsxs)("p", {
                                                className: "f-marketing-body-sm py-gutter text-marketing-subtler sm:py-0",
                                                children: ["Fully integrated with", " ", (0, d.jsxs)("span", {
                                                    className: "whitespace-nowrap",
                                                    children: [(0, d.jsx)(S(), {
                                                        className: "ml-1 mr-1.5 inline size-4 select-none lg:size-5",
                                                        src: "/images/products/comments.png",
                                                        width: 20,
                                                        height: 20,
                                                        alt: "Comments",
                                                        quality: 5,
                                                        "aria-hidden": !0
                                                    }), (0, d.jsx)("strong", {
                                                        className: "font-medium text-marketing",
                                                        children: "Comments"
                                                    })]
                                                }), " ", "and", " ", (0, d.jsxs)("span", {
                                                    className: "whitespace-nowrap",
                                                    children: [(0, d.jsx)(S(), {
                                                        className: "ml-1 mr-1.5 inline size-4 select-none lg:size-5",
                                                        src: "/images/products/text-editor.png",
                                                        width: 20,
                                                        height: 20,
                                                        alt: "Text Editor",
                                                        quality: 5,
                                                        "aria-hidden": !0
                                                    }), (0, d.jsx)("strong", {
                                                        className: "font-medium text-marketing",
                                                        children: "Text\xa0Editor"
                                                    })]
                                                })]
                                            })
                                        }), (0, d.jsxs)(b.S.Cell, {
                                            column: {
                                                sm: 1,
                                                md: 2,
                                                lg: 2
                                            },
                                            className: "flex flex-col lg:aspect-video",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-sm",
                                                isLeftAligned: !0,
                                                size: "sm",
                                                matchingSize: !0,
                                                headingAs: "h3",
                                                heading: "Intelligent notifications",
                                                description: "Email notifications are automatically grouped together to avoid spamming people."
                                            }), (0, d.jsx)(N.Z, {
                                                children: (0, d.jsx)(ey.Z, {})
                                            })]
                                        })]
                                    })
                                })]
                            }), (0, d.jsxs)(b.S, {
                                columns: {
                                    sm: 1,
                                    md: 1,
                                    lg: 3
                                },
                                rows: {
                                    sm: 1
                                },
                                children: [(0, d.jsxs)(b.S.Cell, {
                                    children: [(0, d.jsx)(S(), {
                                        className: "-ml-0.5 size-16 sm:-ml-1 sm:-mt-1 sm:size-20 md:-ml-1.5 md:size-24 lg:-ml-2 lg:-mt-2 lg:size-32",
                                        src: "/images/products/text-editor.png",
                                        alt: "Text editor",
                                        width: 128,
                                        height: 128,
                                        quality: 20
                                    }), (0, d.jsx)(B.Z, {
                                        isLeftAligned: !0,
                                        matchingSize: !0,
                                        className: "mt-4 max-w-64 lg:max-w-72",
                                        headingAs: "h2",
                                        heading: ss.title,
                                        description: "".concat(ss.description.mid, "."),
                                        actions: (0, d.jsxs)(v.Z, {
                                            href: ss.href,
                                            appearance: "primary",
                                            size: "md",
                                            children: ["Learn more ", (0, d.jsx)("span", {
                                                className: "sr-only",
                                                children: "about Text Editor"
                                            })]
                                        })
                                    })]
                                }), (0, d.jsx)(b.S.Cell, {
                                    column: {
                                        sm: 1,
                                        md: 1,
                                        lg: 2
                                    },
                                    noPadding: !0,
                                    children: (0, d.jsxs)(b.S, {
                                        columns: {
                                            sm: 1,
                                            md: 2,
                                            lg: 2
                                        },
                                        children: [(0, d.jsxs)(b.S.Cell, {
                                            column: {
                                                sm: 1,
                                                md: 2,
                                                lg: 2
                                            },
                                            className: "flex flex-col lg:aspect-video",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-xs sm:max-w-sm",
                                                isLeftAligned: !0,
                                                size: "sm",
                                                matchingSize: !0,
                                                headingAs: "h3",
                                                heading: "All the table stakes features",
                                                description: "Add collaborative features like mentions, comments, notifications, and AI in minutes."
                                            }), (0, d.jsx)(N.Z, {
                                                children: (0, d.jsx)(eL, {})
                                            })]
                                        }), (0, d.jsx)(b.S.Cell, {
                                            column: {
                                                sm: 1,
                                                md: 2,
                                                lg: 2
                                            },
                                            className: "text-center",
                                            children: (0, d.jsxs)("p", {
                                                className: "f-marketing-body-sm py-gutter text-marketing-subtler sm:py-0",
                                                children: ["Fully integrated with", " ", (0, d.jsxs)("span", {
                                                    className: "whitespace-nowrap",
                                                    children: [(0, d.jsx)(S(), {
                                                        "aria-hidden": !0,
                                                        src: "/images/products/comments.png",
                                                        alt: "Comments",
                                                        width: 20,
                                                        height: 20,
                                                        className: "ml-1 mr-1.5 inline size-4 select-none lg:size-5",
                                                        quality: 5
                                                    }), (0, d.jsx)("strong", {
                                                        className: "font-medium text-marketing",
                                                        children: "Comments"
                                                    })]
                                                }), " ", "and", " ", (0, d.jsxs)("span", {
                                                    className: "whitespace-nowrap",
                                                    children: [(0, d.jsx)(S(), {
                                                        "aria-hidden": !0,
                                                        src: "/images/products/notifications.png",
                                                        alt: "Notifications",
                                                        width: 20,
                                                        height: 20,
                                                        className: "ml-1 mr-1.5 inline size-4 select-none lg:size-5",
                                                        quality: 5
                                                    }), (0, d.jsx)("strong", {
                                                        className: "font-medium text-marketing",
                                                        children: "Notifications"
                                                    })]
                                                })]
                                            })
                                        }), (0, d.jsxs)(b.S.Cell, {
                                            className: "relative flex flex-col before:pointer-events-none before:absolute before:bottom-[--inner-gutter] before:left-1/2 before:z-0 before:aspect-square before:w-[200%] before:-translate-x-1/2 before:rounded-full before:bg-transparent before:shadow-[0px_0px_12px_0px_rgba(255,255,255,0.2)_inset,0px_0px_60px_0px_rgba(255,255,255,0.1)_inset,0px_0px_120px_0px_rgba(255,255,255,0.2)_inset] lg:aspect-square",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-xs",
                                                isLeftAligned: !0,
                                                size: "sm",
                                                matchingSize: !0,
                                                headingAs: "h3",
                                                heading: "Use your favorite editor",
                                                description: "Dedicated packages to integrate with popular text editor frameworks."
                                            }), (0, d.jsx)(N.Z, {
                                                children: (0, d.jsx)(eA.Z, {})
                                            })]
                                        }), (0, d.jsxs)(b.S.Cell, {
                                            className: "flex flex-col lg:aspect-square",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-xs",
                                                isLeftAligned: !0,
                                                size: "sm",
                                                matchingSize: !0,
                                                headingAs: "h3",
                                                heading: "AI suggestions",
                                                description: "Allow users to create, edit, and enrich content with AI."
                                            }), (0, d.jsx)(N.Z, {
                                                children: (0, d.jsx)(eZ, {})
                                            })]
                                        })]
                                    })
                                })]
                            }), (0, d.jsxs)(b.S, {
                                columns: {
                                    sm: 1,
                                    md: 1,
                                    lg: 3
                                },
                                rows: {
                                    sm: 1
                                },
                                children: [(0, d.jsxs)(b.S.Cell, {
                                    children: [(0, d.jsx)(S(), {
                                        className: "-ml-0.5 size-16 sm:-ml-1 sm:-mt-1 sm:size-20 md:-ml-1.5 md:size-24 lg:-ml-2 lg:-mt-2 lg:size-32",
                                        src: "/images/products/realtime-apis.png",
                                        alt: "Realtime APIs",
                                        width: 128,
                                        height: 128,
                                        quality: 20
                                    }), (0, d.jsx)(B.Z, {
                                        isLeftAligned: !0,
                                        matchingSize: !0,
                                        className: "mt-4 max-w-64 lg:max-w-72",
                                        headingAs: "h2",
                                        heading: st.title,
                                        description: "".concat(st.description.mid, "."),
                                        actions: (0, d.jsxs)(v.Z, {
                                            href: st.href,
                                            appearance: "primary",
                                            size: "md",
                                            children: ["Learn more", " ", (0, d.jsx)("span", {
                                                className: "sr-only",
                                                children: "about Realtime APIs"
                                            })]
                                        })
                                    })]
                                }), (0, d.jsx)(b.S.Cell, {
                                    column: {
                                        sm: 1,
                                        md: 1,
                                        lg: 2
                                    },
                                    noPadding: !0,
                                    children: (0, d.jsxs)(b.S, {
                                        columns: {
                                            sm: 1,
                                            md: 2,
                                            lg: 2
                                        },
                                        children: [(0, d.jsx)(e7, {}), (0, d.jsxs)(b.S.Cell, {
                                            className: "flex flex-col lg:aspect-square",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-xs",
                                                isLeftAligned: !0,
                                                size: "sm",
                                                matchingSize: !0,
                                                headingAs: "h3",
                                                heading: "Infinitely flexible",
                                                description: "Build any collaborative experience with the Liveblocks Realtime APIs."
                                            }), (0, d.jsx)("div", {
                                                className: "my-10 flex flex-1 flex-col items-center justify-center",
                                                children: (0, d.jsx)(eV, {})
                                            })]
                                        }), (0, d.jsxs)(b.S.Cell, {
                                            className: "flex flex-col lg:aspect-square",
                                            children: [(0, d.jsx)(B.Z, {
                                                className: "max-w-xs",
                                                isLeftAligned: !0,
                                                matchingSize: !0,
                                                size: "sm",
                                                headingAs: "h3",
                                                heading: "Live presence",
                                                description: "Make people feel like they’re collaborating together in the same room."
                                            }), (0, d.jsx)(N.Z, {
                                                children: (0, d.jsx)(eq, {})
                                            })]
                                        })]
                                    })
                                })]
                            })]
                        })
                    })
                }),
                si = function() {
                    return (0, d.jsxs)(x.Z, {
                        prefixTitle: "Liveblocks",
                        suffixTitle: "Build collaborative experiences faster",
                        description: "Ship features like comments, notifications, a text editor, or build any collaborative experience in days, not months. Engage users, fuel creativity, and drive growth. Finally.",
                        canonicalPath: "",
                        children: [(0, d.jsx)(u.H, {
                            id: "organization-schema",
                            schema: (0, h.U)()
                        }), (0, d.jsx)(u.H, {
                            id: "website-schema",
                            schema: p
                        }), (0, d.jsx)(ee, {}), (0, d.jsx)(j.Z, {
                            className: "mt-marketing-spacing-xs",
                            headline: "Trusted by companies of all sizes and industries",
                            logos: ["vercel", "dock", "zapier", "salesloft", "facet", "hourone", "hashnode", "arcol", "agility-cms", "tango"],
                            linkToCustomersPage: !0
                        }), (0, d.jsx)(en, {}), (0, d.jsx)(sa, {}), (0, d.jsx)(V, {}), (0, d.jsx)(ew, {}), (0, d.jsx)(f.Z, {})]
                    })
                }
        },
        16061: function(e, s, t) {
            "use strict";
            t.d(s, {
                H: function() {
                    return l
                }
            });
            var a = t(85893),
                i = t(4298),
                n = t.n(i);

            function l(e) {
                let {
                    id: s,
                    schema: t
                } = e;
                return (0, a.jsx)(n(), {
                    id: s,
                    type: "application/ld+json",
                    dangerouslySetInnerHTML: {
                        __html: JSON.stringify(t)
                    }
                })
            }
        },
        6875: function(e, s, t) {
            "use strict";
            t.d(s, {
                U: function() {
                    return n
                }
            });
            var a = t(16003);
            let i = {
                "@context": "https://schema.org",
                "@type": "Organization",
                name: a.pB,
                url: a.R4,
                logo: "".concat(a.R4, "/images/logo-liveblocks-organization-schema.png"),
                address: {
                    "@type": "PostalAddress",
                    streetAddress: a.lX.street,
                    addressLocality: a.lX.locality,
                    addressRegion: a.lX.region,
                    postalCode: a.lX.zipCode,
                    addressCountry: a.lX.country
                },
                sameAs: [a.mK.TWITTER, a.mK.LINKEDIN, a.mK.LINKEDIN, a.mK.YOUTUBE, a.mK.GITHUB]
            };

            function n() {
                return i
            }
        },
        6123: function(e, s, t) {
            "use strict";
            t.d(s, {
                R: function() {
                    return i
                }
            });
            var a = t(67294);

            function i(e) {
                let s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "0px",
                    [t, i] = (0, a.useState)(!1);
                return (0, a.useEffect)(() => {
                    if (!("IntersectionObserver" in window)) {
                        i(!0);
                        return
                    }
                    let t = new IntersectionObserver(e => {
                        let [s] = e;
                        i(s.isIntersecting)
                    }, {
                        rootMargin: s
                    });
                    e.current && t.observe(e.current);
                    let a = e.current;
                    return () => {
                        a && t.unobserve(a)
                    }
                }, []), t
            }
        },
        21611: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return i
                }
            });
            var a = t(67294);

            function i(e, s) {
                let [t, i] = (0, a.useState)(0), [n, l] = (0, a.useState)(0), r = (0, a.useCallback)(e => {
                    if (!Array.isArray(e)) return;
                    let t = e[0];
                    i(t.contentRect.width), l(t.contentRect.height), s && s(t.contentRect)
                }, [s]);
                return (0, a.useEffect)(() => {
                    if (!e.current) return;
                    let s = new ResizeObserver(e => r(e));
                    return s.observe(e.current), () => {
                        s.disconnect()
                    }
                }, [r, e]), [t, n]
            }
        },
        51393: function(e, s, t) {
            "use strict";
            t.d(s, {
                ZP: function() {
                    return p
                }
            });
            var a = t(85893),
                i = t(93967),
                n = t.n(i),
                l = t(54735),
                r = t(67294),
                c = t(16003),
                o = t(20402),
                d = t(92569),
                m = t(74602),
                x = t(33629),
                h = t.n(x);
            let u = "--pointer-x",
                g = "--pointer-y";

            function p(e) {
                let {
                    children: s,
                    className: t,
                    tagAs: i = "div",
                    breakpoint: x,
                    lightRadius: p = 84,
                    lightIntensity: f = .15
                } = e, [j, v] = (0, r.useState)(!1), b = (0, m.ac)("(max-width: ".concat(c.j$.SM, "px)")), [w, N] = (0, r.useState)(!1), k = b || w, y = (0, r.useRef)(null), [L, C] = (0, r.useState)(null);
                (0, r.useEffect)(() => {
                    N((0, d.G6)())
                }, []);
                let z = (0, r.useCallback)(() => {
                        let e = y.current;
                        e && C(e.getBoundingClientRect())
                    }, [C]),
                    S = (0, r.useCallback)(() => {
                        z()
                    }, [z]),
                    Z = (0, r.useCallback)(() => {
                        v(!0), z()
                    }, [z]),
                    A = (0, r.useCallback)(() => {
                        v(!1), C(null)
                    }, []),
                    E = (0, r.useCallback)(e => {
                        let s, t;
                        let a = y.current;
                        L && a && (l.ZP.read(() => {
                            s = e.clientX - L.x, t = e.clientY - L.y
                        }), l.ZP.update(() => {
                            void 0 !== s && void 0 !== t && (a.style.setProperty(u, "".concat(s, "px")), a.style.setProperty(g, "".concat(t, "px")))
                        }))
                    }, [L]);
                return (0, r.useEffect)(() => (window.addEventListener("scroll", S), () => {
                    window.removeEventListener("scroll", S)
                }), [S]), (0, a.jsxs)(i, {
                    ref: y,
                    className: (0, o.cn)("relative", t),
                    onPointerEnter: k ? void 0 : Z,
                    onPointerLeave: k ? void 0 : A,
                    onPointerMove: k ? void 0 : E,
                    children: [(0, a.jsx)("div", {
                        className: (0, o.cn)("pointer-events-none absolute -ml-[0.5px] -mt-[0.5px] h-full w-full justify-center", {
                            "xl:flex": "xl" === x,
                            "lg:flex": "lg" === x,
                            "md:flex": "md" === x,
                            "sm:flex": "sm" === x,
                            flex: !x,
                            hidden: x
                        }),
                        children: (0, a.jsx)("div", {
                            className: n()("absolute -bottom-[1.5px] left-0 right-0 top-0 bg-marketing-surface-faded", h().grid),
                            children: !k && (0, a.jsx)("div", {
                                className: n()("pointer-events-none absolute transition-opacity duration-150", {
                                    "opacity-0": !j,
                                    "opacity-100": j
                                }),
                                style: {
                                    top: "-".concat(p, "px"),
                                    left: "-".concat(p, "px"),
                                    width: "".concat(2 * p, "px"),
                                    height: "".concat(2 * p, "px"),
                                    transform: "translateX(var(".concat(u, ")) translateY(var(").concat(g, "))"),
                                    backgroundImage: "radial-gradient(".concat(p, "px circle, hsla(256, 7%, 97%, ").concat(f, "), hsla(256, 7%, 97%, 0))")
                                }
                            })
                        })
                    }), s]
                })
            }
        },
        27893: function(e, s, t) {
            "use strict";
            var a = t(85893),
                i = t(20402);
            s.Z = e => {
                let {
                    className: s,
                    name: t,
                    content: n,
                    color: l = "var(--lb-marketing-color-background-surface-base-inverse)",
                    isTyping: r
                } = e;
                return (0, a.jsxs)("div", {
                    className: (0, i.cn)(s, "pointer-events-none absolute select-none"),
                    children: [(0, a.jsx)("svg", {
                        "aria-hidden": "true",
                        focusable: "false",
                        className: "size-3.5",
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "20",
                        height: "20",
                        fill: "none",
                        viewBox: "0 0 20 20",
                        children: (0, a.jsx)("path", {
                            fill: l,
                            d: "M19.438 6.716 1.115.05A.832.832 0 0 0 .05 1.116L6.712 19.45a.834.834 0 0 0 1.557.025l3.198-8 7.995-3.2a.833.833 0 0 0 0-1.559h-.024Z"
                        })
                    }), (n || t) && (0, a.jsx)("div", {
                        className: (0, i.cn)("absolute left-3.5 top-3.5 flex items-center whitespace-nowrap py-1 text-xs font-medium text-marketing-inverse", n ? "rounded-xl rounded-tl px-2.5" : "rounded px-2"),
                        style: {
                            backgroundColor: l
                        },
                        children: r || n && t ? (0, a.jsxs)("span", {
                            className: "flex flex-col",
                            children: [(0, a.jsx)("span", {
                                className: "text-2xs opacity-70",
                                children: t
                            }), n && (0, a.jsx)("span", {
                                children: n
                            })]
                        }) : (0, a.jsx)("span", {
                            className: "line-clamp-1",
                            children: null != n ? n : t
                        })
                    })]
                })
            }
        },
        75107: function(e, s, t) {
            "use strict";
            t.d(s, {
                J: function() {
                    return c
                }
            });
            var a = t(85893),
                i = t(67294),
                n = t(20402),
                l = t(30659),
                r = t(86113);
            let c = e => {
                let {
                    className: s,
                    appearance: t,
                    items: c,
                    highlightedWord: o,
                    hideNewIndicator: d,
                    hideComposer: m
                } = e, x = e => e === c.length - 1 && c.length > 1 && !d && (0, a.jsx)("li", {
                    role: "separator",
                    className: "-mx-4 flex justify-center text-3xs font-medium uppercase tracking-widest",
                    children: (0, a.jsxs)("span", {
                        className: "relative -my-2 flex items-center gap-1.5 px-3 text-marketing-subtle before:absolute before:right-full before:top-1/2 before:z-10 before:h-px before:w-screen before:-translate-y-1/2 before:bg-marketing-surface-base after:absolute after:left-full after:top-1/2 after:h-px after:w-screen after:-translate-y-1/2 after:bg-marketing-surface-base",
                        children: [(0, a.jsx)("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            width: "6",
                            height: "8",
                            fill: "none",
                            viewBox: "0 0 8 10",
                            children: (0, a.jsx)("path", {
                                fill: "currentColor",
                                d: "M4.566.163V7.7l2.727-2.726.707.72-4 4-3.999-4 .72-.72L3.435 7.7V.163h1.131Z"
                            })
                        }), " ", "New"]
                    })
                });
                return (0, a.jsxs)("div", {
                    role: "img",
                    "aria-label": "Illustration of a comments thread, complemented by a composer for replies.",
                    className: (0, n.cn)("pointer-events-none relative flex select-none flex-col overflow-hidden bg-marketing-surface-base", s),
                    children: [(0, a.jsx)("div", {
                        className: "pointer-events-none absolute inset-0 z-0 rounded-[inherit] bg-marketing-surface-faded-subtle"
                    }), o && (0, a.jsx)("div", {
                        className: "relative z-10 border-b border-marketing-divider-surface px-4 py-3",
                        children: (0, a.jsx)("span", {
                            className: (0, n.cn)("border-l-2 px-1.5 text-sm", {
                                "border-marketing-divider-product-comments bg-marketing-surface-product-comments-subtle": "comments" === t,
                                "border-marketing-divider-product-notifications bg-marketing-surface-product-notifications-subtle": "notifications" === t,
                                "border-marketing-divider-product-text-editor bg-marketing-surface-product-text-editor-subtle": "text-editor" === t,
                                "border-marketing-divider-product-realtime-apis bg-marketing-surface-product-realtime-apis-subtle": "realtime-apis" === t,
                                "border-marketing-divider bg-marketing-surface-faded-subtle": !t
                            }),
                            children: o
                        })
                    }), (0, a.jsx)("ul", {
                        className: "relative z-10 space-y-4 p-4",
                        children: c.map((e, s) => {
                            var n, c, o;
                            return (0, a.jsxs)(i.Fragment, {
                                children: [x(s), (0, a.jsxs)("li", {
                                    className: "text-sm",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-3",
                                        children: [(0, a.jsx)(l.H, {
                                            appearance: e.isActive ? null !== (o = null !== (c = e.appearance) && void 0 !== c ? c : t) && void 0 !== o ? o : "comments" : void 0
                                        }), (0, a.jsxs)("div", {
                                            className: "flex items-baseline gap-1.5",
                                            children: [(0, a.jsx)("div", {
                                                className: "font-medium",
                                                children: e.author
                                            }), (0, a.jsx)("div", {
                                                className: "text-xs text-marketing-subtler",
                                                children: e.date
                                            })]
                                        })]
                                    }), (0, a.jsx)("div", {
                                        className: "ml-10 text-marketing-subtle [&>em]:not-italic [&>em]:text-marketing",
                                        children: e.content
                                    }), (null === (n = e.emojis) || void 0 === n ? void 0 : n.length) && (0, a.jsx)("div", {
                                        className: "ml-10 mt-2 flex items-center gap-1",
                                        children: e.emojis.map((e, s) => {
                                            let {
                                                symbol: t,
                                                count: i
                                            } = e;
                                            return (0, a.jsx)(r.l, {
                                                symbol: t,
                                                initialCount: i
                                            }, s)
                                        })
                                    })]
                                })]
                            }, s)
                        })
                    }), !m && (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("div", {
                            className: "relative z-10 w-full border-t border-marketing-divider-surface"
                        }), (0, a.jsx)("div", {
                            className: "p-4 text-sm text-marketing-subtlest",
                            children: "Reply to thread…"
                        })]
                    })]
                })
            }
        },
        65202: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return r
                }
            });
            var a = t(85893),
                i = t(56831),
                n = t(20402),
                l = t(30659);

            function r() {
                return (0, a.jsxs)("div", {
                    className: "pointer-events-none absolute inset-0 select-none pt-gutter",
                    children: [(0, a.jsxs)("div", {
                        className: "absolute -left-gutter bottom-0 right-0 z-0 flex h-px items-center",
                        children: [(0, a.jsx)("div", {
                            className: "h-px grow border-t border-marketing-divider-bold-opaque"
                        }), (0, a.jsx)("div", {
                            className: "absolute bottom-0 right-0 top-0 w-20 bg-gradient-to-l from-marketing-surface-base to-transparent"
                        })]
                    }), (0, a.jsxs)("div", {
                        className: "relative z-10 flex h-full items-stretch justify-between",
                        children: [(0, a.jsxs)("div", {
                            className: "relative flex grow justify-start",
                            children: [(0, a.jsx)(c, {
                                type: "comments",
                                className: "mt-16 hidden sm:flex",
                                children: "New comment"
                            }), (0, a.jsx)(c, {
                                type: "text-editor",
                                className: "mt-[120px] sm:-ml-6 md:-ml-3",
                                children: "Inline mention"
                            }), (0, a.jsx)(c, {
                                type: "user-view",
                                className: "-z-10 -ml-28 sm:-ml-10 md:-ml-6",
                                children: "Stacy reads items"
                            }), (0, a.jsx)(c, {
                                type: "comments",
                                className: "-z-10 -ml-28 mt-16 sm:-ml-10 md:-ml-6",
                                children: "New comment"
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "absolute bottom-0 right-0 top-0 z-20 flex flex-col items-center",
                            children: [(0, a.jsxs)("div", {
                                className: "relative flex h-36 w-40 grow-0 flex-col rounded-md bg-marketing-surface-base ring-4 ring-marketing-divider-surface sm:w-48",
                                children: [(0, a.jsx)("div", {
                                    className: "absolute inset-0 rounded-[inherit] bg-marketing-surface-faded-subtle"
                                }), (0, a.jsx)("div", {
                                    className: "relative z-10 border-b border-marketing-divider-surface p-3",
                                    children: (0, a.jsxs)("div", {
                                        className: "flex items-center gap-1.5",
                                        children: [(0, a.jsx)(l.H, {
                                            size: "xs",
                                            appearance: "notifications"
                                        }), (0, a.jsxs)("span", {
                                            className: "text-3xs",
                                            children: [(0, a.jsx)("span", {
                                                className: "text-marketing-subtlest",
                                                children: "to"
                                            }), " ", (0, a.jsx)("span", {
                                                className: "font-medium",
                                                children: "stacy@acme.inc"
                                            })]
                                        })]
                                    })
                                }), (0, a.jsxs)("div", {
                                    className: "space-be flex flex-grow flex-col justify-center p-3",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex flex-col gap-2.5",
                                        children: [(0, a.jsx)("div", {
                                            className: "h-2 w-11 rounded-sm bg-marketing-surface-base-inverse opacity-30"
                                        }), (0, a.jsxs)("div", {
                                            className: "flex flex-col gap-1",
                                            children: [(0, a.jsx)("div", {
                                                className: "h-1 w-full rounded-sm bg-marketing-surface-base-inverse opacity-20"
                                            }), (0, a.jsx)("div", {
                                                className: "h-1 w-9/12 rounded-sm bg-marketing-surface-base-inverse opacity-20"
                                            }), (0, a.jsx)("div", {
                                                className: "h-1 w-10/12 rounded-sm bg-marketing-surface-base-inverse opacity-20"
                                            })]
                                        })]
                                    }), (0, a.jsx)("div", {
                                        className: "mt-auto flex items-center justify-center rounded-sm bg-marketing-surface-base-inverse px-3 py-1 text-2xs font-medium text-marketing-inverse",
                                        children: "View comment"
                                    })]
                                })]
                            }), (0, a.jsx)("div", {
                                className: "relative flex w-px grow flex-col items-center border-r border-marketing-divider-bold-opaque",
                                children: (0, a.jsx)("div", {
                                    className: "absolute -bottom-[6.5px] size-[13px] rounded-full border-2 border-marketing-divider-surface bg-marketing-surface-base-inverse-subtlest"
                                })
                            })]
                        })]
                    })]
                })
            }

            function c(e) {
                let {
                    className: s,
                    children: t,
                    type: r
                } = e;
                return (0, a.jsxs)("div", {
                    className: (0, n.cn)("relative flex flex-col items-start", s),
                    children: [(0, a.jsxs)("div", {
                        className: (0, n.cn)("relative flex grow-0 items-center whitespace-nowrap rounded-md bg-marketing-surface-base px-3 py-3 text-2xs font-medium ring-4 ring-marketing-divider-surface", "user-view" === r ? "gap-2.5" : "gap-2"),
                        children: [(0, a.jsx)("div", {
                            className: "absolute inset-0 rounded-[inherit] bg-marketing-surface-faded-subtle"
                        }), "user-view" === r ? (0, a.jsx)("div", {
                            className: "relative flex size-3 items-center justify-center",
                            children: (0, a.jsx)(i.Z, {
                                className: "absolute size-4 fill-current"
                            })
                        }) : (0, a.jsx)(l.H, {
                            size: "xs",
                            appearance: r
                        }), t]
                    }), (0, a.jsxs)("div", {
                        className: "relative ml-[17px] flex w-px grow flex-col items-center",
                        children: [(0, a.jsx)("div", {
                            className: "absolute inset-0 border-r border-marketing-divider-bold-opaque"
                        }), (0, a.jsx)("div", {
                            className: "absolute -bottom-[6.5px] size-[13px] grow rounded-full border-2 border-marketing-divider-surface bg-marketing-surface-base-inverse-subtlest"
                        })]
                    })]
                })
            }
        },
        17245: function(e, s, t) {
            "use strict";
            var a = t(85893);
            t(67294);
            var i = t(14498);
            let n = [{
                date: "now",
                title: "Your export is ready for download",
                hideAvatar: !0,
                seen: !1
            }, {
                date: "5m ago",
                title: (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)("em", {
                        children: "Vincent"
                    }), " invited you to ", (0, a.jsx)("em", {
                        children: "Design explorations"
                    })]
                }),
                content: (0, a.jsxs)("div", {
                    className: "mt-2.5 flex items-center gap-1.5",
                    children: [(0, a.jsx)("button", {
                        className: "h-7 rounded bg-marketing-surface-base-inverse px-3 text-xs font-medium text-marketing-inverse",
                        type: "button",
                        children: "Accept"
                    }), (0, a.jsx)("button", {
                        className: "h-7 rounded bg-white/5 px-3 text-xs font-medium",
                        type: "button",
                        children: "Decline"
                    })]
                }),
                hideAvatar: !0,
                seen: !0
            }, {
                date: "4d ago",
                title: (0, a.jsxs)(a.Fragment, {
                    children: ["You can now edit ", (0, a.jsx)("em", {
                        children: "Roadmap"
                    })]
                }),
                hideAvatar: !0,
                seen: !0
            }];
            s.Z = () => (0, a.jsx)("div", {
                className: "pointer-events-none absolute inset-0 mt-gutter select-none pt-gutter lg:mt-[52px]",
                children: (0, a.jsx)(i.Z, {
                    role: "img",
                    "aria-label": "Illustration of inbox notifications originating from various activities.",
                    items: n
                })
            })
        },
        14498: function(e, s, t) {
            "use strict";
            var a = t(85893),
                i = t(20402),
                n = t(30659),
                l = t(86113);
            s.Z = e => {
                let {
                    items: s,
                    showTrigger: t,
                    className: r
                } = e;
                return (0, a.jsxs)("div", {
                    className: (0, i.cn)("pointer-events-none flex flex-col gap-3 overflow-hidden", r),
                    children: [t ? (0, a.jsx)("div", {
                        className: "relative mx-auto flex size-10 items-center justify-center rounded-lg bg-marketing-surface-faded-subtle",
                        children: (0, a.jsx)("svg", {
                            className: "size-5",
                            xmlns: "http://www.w3.org/2000/svg",
                            width: "32",
                            height: "32",
                            fill: "none",
                            viewBox: "0 0 32 32",
                            children: (0, a.jsx)("path", {
                                fill: "currentColor",
                                d: "M28.707 19.293 26 16.586V13a10.014 10.014 0 0 0-9-9.95V1h-2v2.05A10.014 10.014 0 0 0 6 13v3.586l-2.707 2.707A1 1 0 0 0 3 20v3a1 1 0 0 0 1 1h7v.777a5.152 5.152 0 0 0 4.5 5.198A5.005 5.005 0 0 0 21 25v-1h7a1 1 0 0 0 1-1v-3a1 1 0 0 0-.293-.707ZM19 25a3 3 0 0 1-6 0v-1h6v1Zm8-3H5v-1.586l2.707-2.707A1 1 0 0 0 8 17v-4a8 8 0 0 1 16 0v4a1 1 0 0 0 .293.707L27 20.414V22Z"
                            })
                        })
                    }) : null, (0, a.jsx)("ul", {
                        className: "flex flex-col divide-y divide-black",
                        children: s.map((e, s) => {
                            var r;
                            return (0, a.jsxs)("li", {
                                className: (0, i.cn)("relative bg-marketing-surface-faded-subtle p-4 text-sm first-of-type:rounded-t-lg last-of-type:rounded-b-lg", {
                                    relative: t && 0 === s
                                }),
                                children: [t && 0 === s && (0, a.jsx)("svg", {
                                    className: "absolute left-1/2 top-0 h-1.5 w-auto -translate-x-1/2 -translate-y-full fill-marketing-surface-faded-subtle",
                                    width: "32",
                                    height: "16",
                                    viewBox: "0 0 32 16",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: (0, a.jsx)("path", {
                                        d: "M16 0L0 16H32L16 0Z"
                                    })
                                }), (0, a.jsxs)("div", {
                                    className: "flex items-center justify-between gap-3",
                                    children: [(0, a.jsxs)("div", {
                                        className: "flex items-center gap-3 truncate",
                                        children: [!e.hideAvatar && (0, a.jsx)(n.H, {
                                            className: "shrink-0"
                                        }), (0, a.jsx)("div", {
                                            className: "truncate text-product-subtle [&>em]:not-italic [&>em]:text-marketing",
                                            children: e.title
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex shrink-0 items-center gap-2 text-xs text-marketing-subtler",
                                        children: [!e.seen && (0, a.jsx)(n.H, {
                                            size: "xs",
                                            appearance: "notifications"
                                        }), e.date]
                                    })]
                                }), e.content && (0, a.jsx)("div", {
                                    className: (0, i.cn)(!e.hideAvatar && "ml-10", "truncate text-product-subtle [&>em]:not-italic [&>em]:text-marketing"),
                                    children: e.content
                                }), (null === (r = e.emojis) || void 0 === r ? void 0 : r.length) ? (0, a.jsx)("div", {
                                    className: "ml-10 mt-2 flex items-center gap-1",
                                    children: e.emojis.map((e, s) => (0, a.jsx)(l.l, {
                                        symbol: e.symbol,
                                        initialCount: e.count
                                    }, s))
                                }) : null]
                            }, s)
                        })
                    })]
                })
            }
        },
        86113: function(e, s, t) {
            "use strict";
            t.d(s, {
                l: function() {
                    return l
                }
            });
            var a = t(85893),
                i = t(67294),
                n = t(20402);

            function l(e) {
                let {
                    symbol: s,
                    initialCount: t
                } = e, [l, r] = (0, i.useState)(t);
                return (0, a.jsxs)("button", {
                    onClick: () => {
                        if (l === t) {
                            r(l + 1);
                            return
                        }
                        r(l - 1)
                    },
                    className: (0, n.cn)("pointer-events-auto inline-flex items-center gap-1.5 rounded-full border border-marketing-divider px-2 py-1.5 text-2xs tabular-nums leading-none transition-colors duration-75 ease-out focus:bg-marketing-surface-faded-subtle", l === t ? "hover:bg-marketing-surface-faded-subtle focus:border-marketing-divider-bold" : "bg-marketing-surface-faded-subtle hover:bg-marketing-surface-faded"),
                    children: [(0, a.jsx)("span", {
                        children: s
                    }), (0, a.jsx)("span", {
                        className: "text-marketing-subtle",
                        children: l
                    })]
                })
            }
        },
        40211: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return o
                }
            });
            var a = t(85893),
                i = t(87527),
                n = t(16003),
                l = t(88312),
                r = t(49329),
                c = t(22132);

            function o() {
                return (0, a.jsx)(a.Fragment, {
                    children: (0, a.jsxs)("section", {
                        className: "pt-marketing-spacing-xl pb-marketing-spacing-xl relative flex flex-col items-center overflow-hidden",
                        children: [(0, a.jsx)("span", {
                            className: "pointer-events-none absolute top-0 block aspect-square w-[400%] rounded-full bg-marketing-surface-base shadow-[0px_0px_16px_0px_rgba(255,255,255,0.40)_inset,0px_0px_80px_0px_rgba(255,255,255,0.6)_inset,0px_0px_160px_0px_rgba(255,255,255,0.2)_inset]"
                        }), (0, a.jsx)(r.Z, {
                            children: (0, a.jsx)(c.Z, {
                                className: "mx-auto lg:max-w-2xl",
                                size: "lg",
                                heading: "Add collaboration to\xa0your product today",
                                actions: (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)(l.Z, {
                                        size: "lg",
                                        href: n.qf.SIGN_UP,
                                        appearance: "primary",
                                        children: "Start building for free"
                                    }), (0, a.jsxs)(l.Z, {
                                        size: "lg",
                                        appearance: "ghost",
                                        href: n.qk.CONTACT_SALES,
                                        children: ["Book a demo", (0, a.jsx)(i.Z, {
                                            className: "-mr-0.5 ml-1.5 fill-current"
                                        })]
                                    })]
                                })
                            })
                        })]
                    })
                })
            }
        },
        33629: function(e) {
            e.exports = {
                grid: "BackgroundGrid_grid__G4A4Q"
            }
        },
        31422: function(e) {
            e.exports = {
                heroGradientTop: "SectionHero_heroGradientTop__2iuhz",
                heroLight: "SectionHero_heroLight__CjeXo",
                heroLightStreaks1: "SectionHero_heroLightStreaks1__t5VSe",
                heroLightStreaks2: "SectionHero_heroLightStreaks2__xXK2g",
                heroLightStreaks3: "SectionHero_heroLightStreaks3__0JWiR",
                lightStreaks: "SectionHero_lightStreaks__3ebvR",
                heroContainer: "SectionHero_heroContainer__k02Ar"
            }
        }
    },
    function(e) {
        e.O(0, [3662, 2944, 4919, 3230, 1664, 7821, 1818, 2785, 3496, 5675, 6417, 7680, 297, 8739, 5889, 3492, 169, 7360, 9270, 5615, 2760, 9426, 5208, 7770, 2888, 9774, 179], function() {
            return e(e.s = 48312)
        }), _N_E = e.O()
    }
]);