(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7701], {
        49637: function(e, t, r) {
            "use strict";
            r.d(t, {
                V: function() {
                    return s
                }
            });
            var n = r(87462),
                i = r(67294),
                a = r(99477),
                o = r(19390);
            let s = i.forwardRef(function({
                children: e,
                follow: t = !0,
                lockX: r = !1,
                lockY: s = !1,
                lockZ: l = !1,
                ...u
            }, c) {
                let d = i.useRef(null),
                    f = i.useRef(null),
                    h = new a.Quaternion;
                return (0, o.C)(({
                    camera: e
                }) => {
                    if (!t || !f.current) return;
                    let n = f.current.rotation.clone();
                    f.current.updateMatrix(), f.current.updateWorldMatrix(!1, !1), f.current.getWorldQuaternion(h), e.getWorldQuaternion(d.current.quaternion).premultiply(h.invert()), r && (f.current.rotation.x = n.x), s && (f.current.rotation.y = n.y), l && (f.current.rotation.z = n.z)
                }), i.useImperativeHandle(c, () => f.current, []), i.createElement("group", (0, n.Z)({
                    ref: f,
                    matrixAutoUpdate: !1,
                    matrixWorldAutoUpdate: !1
                }, u), i.createElement("group", {
                    ref: d
                }, e))
            })
        },
        97134: function(e, t, r) {
            "use strict";
            r.d(t, {
                B: function() {
                    return l
                }
            });
            var n = r(87462),
                i = r(99477),
                a = r(67294),
                o = r(19390),
                s = r(10105);
            let l = (0, a.forwardRef)((e, t) => {
                (0, a.useMemo)(() => {
                    let e = {
                        Box3: i.Box3,
                        MathUtils: {
                            clamp: i.MathUtils.clamp
                        },
                        Matrix4: i.Matrix4,
                        Quaternion: i.Quaternion,
                        Raycaster: i.Raycaster,
                        Sphere: i.Sphere,
                        Spherical: i.Spherical,
                        Vector2: i.Vector2,
                        Vector3: i.Vector3,
                        Vector4: i.Vector4
                    };
                    s.Z.install({
                        THREE: e
                    }), (0, o.e)({
                        CameraControlsImpl: s.Z
                    })
                }, []);
                let {
                    camera: r,
                    domElement: l,
                    makeDefault: u,
                    onStart: c,
                    onEnd: d,
                    onChange: f,
                    regress: h,
                    ...p
                } = e, m = (0, o.A)(e => e.camera), g = (0, o.A)(e => e.gl), A = (0, o.A)(e => e.invalidate), v = (0, o.A)(e => e.events), y = (0, o.A)(e => e.setEvents), C = (0, o.A)(e => e.set), B = (0, o.A)(e => e.get), _ = (0, o.A)(e => e.performance), b = r || m, E = l || v.connected || g.domElement, w = (0, a.useMemo)(() => new s.Z(b), [b]);
                return (0, o.C)((e, t) => {
                    w.enabled && w.update(t)
                }, -1), (0, a.useEffect)(() => (w.connect(E), () => void w.disconnect()), [E, w]), (0, a.useEffect)(() => {
                    let e = e => {
                            A(), h && _.regress(), f && f(e)
                        },
                        t = e => {
                            c && c(e)
                        },
                        r = e => {
                            d && d(e)
                        };
                    return w.addEventListener("update", e), w.addEventListener("controlstart", t), w.addEventListener("controlend", r), w.addEventListener("control", e), w.addEventListener("transitionstart", e), w.addEventListener("wake", e), () => {
                        w.removeEventListener("update", e), w.removeEventListener("controlstart", t), w.removeEventListener("controlend", r), w.removeEventListener("control", e), w.removeEventListener("transitionstart", e), w.removeEventListener("wake", e)
                    }
                }, [w, c, d, A, y, h, f]), (0, a.useEffect)(() => {
                    if (u) {
                        let e = B().controls;
                        return C({
                            controls: w
                        }), () => C({
                            controls: e
                        })
                    }
                }, [u, w]), a.createElement("primitive", (0, n.Z)({
                    ref: t,
                    object: w
                }, p))
            })
        },
        51007: function(e, t, r) {
            "use strict";
            let n;
            r.d(t, {
                qA: function() {
                    return eT
                }
            });
            var i = r(87462),
                a = r(67294),
                o = r(19390),
                s = r(99477);
            let l = e => e && e.isCubeTexture;
            class u extends s.Mesh {
                constructor(e, t) {
                    var r, n;
                    let i = l(e),
                        a = Math.floor(Math.log2((null != (n = i ? null == (r = e.image[0]) ? void 0 : r.width : e.image.width) ? n : 1024) / 4)),
                        o = Math.pow(2, a),
                        u = `
        varying vec3 vWorldPosition;
        void main() 
        {
            vec4 worldPosition = ( modelMatrix * vec4( position, 1.0 ) );
            vWorldPosition = worldPosition.xyz;
            
            gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
        }
        `,
                        c = [i ? "#define ENVMAP_TYPE_CUBE" : "", `#define CUBEUV_TEXEL_WIDTH ${1/(3*Math.max(o,112))}`, `#define CUBEUV_TEXEL_HEIGHT ${1/(4*o)}`, `#define CUBEUV_MAX_MIP ${a}.0`].join("\n") + `
        #define ENVMAP_TYPE_CUBE_UV
        varying vec3 vWorldPosition;
        uniform float radius;
        uniform float height;
        uniform float angle;
        #ifdef ENVMAP_TYPE_CUBE
            uniform samplerCube map;
        #else
            uniform sampler2D map;
        #endif
        // From: https://www.shadertoy.com/view/4tsBD7
        float diskIntersectWithBackFaceCulling( vec3 ro, vec3 rd, vec3 c, vec3 n, float r ) 
        {
            float d = dot ( rd, n );
            
            if( d > 0.0 ) { return 1e6; }
            
            vec3  o = ro - c;
            float t = - dot( n, o ) / d;
            vec3  q = o + rd * t;
            
            return ( dot( q, q ) < r * r ) ? t : 1e6;
        }
        // From: https://www.iquilezles.org/www/articles/intersectors/intersectors.htm
        float sphereIntersect( vec3 ro, vec3 rd, vec3 ce, float ra ) 
        {
            vec3 oc = ro - ce;
            float b = dot( oc, rd );
            float c = dot( oc, oc ) - ra * ra;
            float h = b * b - c;
            
            if( h < 0.0 ) { return -1.0; }
            
            h = sqrt( h );
            
            return - b + h;
        }
        vec3 project() 
        {
            vec3 p = normalize( vWorldPosition );
            vec3 camPos = cameraPosition;
            camPos.y -= height;
            float intersection = sphereIntersect( camPos, p, vec3( 0.0 ), radius );
            if( intersection > 0.0 ) {
                
                vec3 h = vec3( 0.0, - height, 0.0 );
                float intersection2 = diskIntersectWithBackFaceCulling( camPos, p, h, vec3( 0.0, 1.0, 0.0 ), radius );
                p = ( camPos + min( intersection, intersection2 ) * p ) / radius;
            } else {
                p = vec3( 0.0, 1.0, 0.0 );
            }
            return p;
        }
        #include <common>
        #include <cube_uv_reflection_fragment>
        void main() 
        {
            vec3 projectedWorldPosition = project();
            
            #ifdef ENVMAP_TYPE_CUBE
                vec3 outcolor = textureCube( map, projectedWorldPosition ).rgb;
            #else
                vec3 direction = normalize( projectedWorldPosition );
                vec2 uv = equirectUv( direction );
                vec3 outcolor = texture2D( map, uv ).rgb;
            #endif
            gl_FragColor = vec4( outcolor, 1.0 );
            #include <tonemapping_fragment>
            #include <${parseInt(s.REVISION.replace(/\D+/g,""))>=154?"colorspace_fragment":"encodings_fragment"}>
        }
        `;
                    super(new s.IcosahedronGeometry(1, 16), new s.ShaderMaterial({
                        uniforms: {
                            map: {
                                value: e
                            },
                            height: {
                                value: (null == t ? void 0 : t.height) || 15
                            },
                            radius: {
                                value: (null == t ? void 0 : t.radius) || 100
                            }
                        },
                        fragmentShader: c,
                        vertexShader: u,
                        side: s.DoubleSide
                    }))
                }
                set radius(e) {
                    this.material.uniforms.radius.value = e
                }
                get radius() {
                    return this.material.uniforms.radius.value
                }
                set height(e) {
                    this.material.uniforms.height.value = e
                }
                get height() {
                    return this.material.uniforms.height.value
                }
            }
            class c extends s.DataTextureLoader {
                constructor(e) {
                    super(e), this.type = s.HalfFloatType
                }
                parse(e) {
                    let t, r, n;
                    let i = function(e, t) {
                            switch (e) {
                                case 1:
                                    throw Error("THREE.RGBELoader: Read Error: " + (t || ""));
                                case 2:
                                    throw Error("THREE.RGBELoader: Write Error: " + (t || ""));
                                case 3:
                                    throw Error("THREE.RGBELoader: Bad File Format: " + (t || ""));
                                default:
                                    throw Error("THREE.RGBELoader: Memory Error: " + (t || ""))
                            }
                        },
                        a = function(e, t, r) {
                            t = t || 1024;
                            let n = e.pos,
                                i = -1,
                                a = 0,
                                o = "",
                                s = String.fromCharCode.apply(null, new Uint16Array(e.subarray(n, n + 128)));
                            for (; 0 > (i = s.indexOf("\n")) && a < t && n < e.byteLength;) o += s, a += s.length, n += 128, s += String.fromCharCode.apply(null, new Uint16Array(e.subarray(n, n + 128)));
                            return -1 < i && (!1 !== r && (e.pos += a + i + 1), o + s.slice(0, i))
                        },
                        o = new Uint8Array(e);
                    o.pos = 0;
                    let l = function(e) {
                            let t, r;
                            let n = /^\s*GAMMA\s*=\s*(\d+(\.\d+)?)\s*$/,
                                o = /^\s*EXPOSURE\s*=\s*(\d+(\.\d+)?)\s*$/,
                                s = /^\s*FORMAT=(\S+)\s*$/,
                                l = /^\s*\-Y\s+(\d+)\s+\+X\s+(\d+)\s*$/,
                                u = {
                                    valid: 0,
                                    string: "",
                                    comments: "",
                                    programtype: "RGBE",
                                    format: "",
                                    gamma: 1,
                                    exposure: 1,
                                    width: 0,
                                    height: 0
                                };
                            for (!(e.pos >= e.byteLength) && (t = a(e)) || i(1, "no header found"), (r = t.match(/^#\?(\S+)/)) || i(3, "bad initial token"), u.valid |= 1, u.programtype = r[1], u.string += t + "\n"; !1 !== (t = a(e));) {
                                if (u.string += t + "\n", "#" === t.charAt(0)) {
                                    u.comments += t + "\n";
                                    continue
                                }
                                if ((r = t.match(n)) && (u.gamma = parseFloat(r[1])), (r = t.match(o)) && (u.exposure = parseFloat(r[1])), (r = t.match(s)) && (u.valid |= 2, u.format = r[1]), (r = t.match(l)) && (u.valid |= 4, u.height = parseInt(r[1], 10), u.width = parseInt(r[2], 10)), 2 & u.valid && 4 & u.valid) break
                            }
                            return 2 & u.valid || i(3, "missing format specifier"), 4 & u.valid || i(3, "missing image size specifier"), u
                        }(o),
                        u = l.width,
                        c = l.height,
                        d = function(e, t, r) {
                            if (t < 8 || t > 32767 || 2 !== e[0] || 2 !== e[1] || 128 & e[2]) return new Uint8Array(e);
                            t !== (e[2] << 8 | e[3]) && i(3, "wrong scanline width");
                            let n = new Uint8Array(4 * t * r);
                            n.length || i(4, "unable to allocate buffer space");
                            let a = 0,
                                o = 0,
                                s = 4 * t,
                                l = new Uint8Array(4),
                                u = new Uint8Array(s),
                                c = r;
                            for (; c > 0 && o < e.byteLength;) {
                                o + 4 > e.byteLength && i(1), l[0] = e[o++], l[1] = e[o++], l[2] = e[o++], l[3] = e[o++], (2 != l[0] || 2 != l[1] || (l[2] << 8 | l[3]) != t) && i(3, "bad rgbe scanline format");
                                let r = 0,
                                    d;
                                for (; r < s && o < e.byteLength;) {
                                    let t = (d = e[o++]) > 128;
                                    if (t && (d -= 128), (0 === d || r + d > s) && i(3, "bad scanline data"), t) {
                                        let t = e[o++];
                                        for (let e = 0; e < d; e++) u[r++] = t
                                    } else u.set(e.subarray(o, o + d), r), r += d, o += d
                                }
                                for (let e = 0; e < t; e++) {
                                    let r = 0;
                                    n[a] = u[e + r], r += t, n[a + 1] = u[e + r], r += t, n[a + 2] = u[e + r], r += t, n[a + 3] = u[e + r], a += 4
                                }
                                c--
                            }
                            return n
                        }(o.subarray(o.pos), u, c);
                    switch (this.type) {
                        case s.FloatType:
                            let f = new Float32Array(4 * (n = d.length / 4));
                            for (let e = 0; e < n; e++) ! function(e, t, r, n) {
                                let i = Math.pow(2, e[t + 3] - 128) / 255;
                                r[n + 0] = e[t + 0] * i, r[n + 1] = e[t + 1] * i, r[n + 2] = e[t + 2] * i, r[n + 3] = 1
                            }(d, 4 * e, f, 4 * e);
                            t = f, r = s.FloatType;
                            break;
                        case s.HalfFloatType:
                            let h = new Uint16Array(4 * (n = d.length / 4));
                            for (let e = 0; e < n; e++) ! function(e, t, r, n) {
                                let i = Math.pow(2, e[t + 3] - 128) / 255;
                                r[n + 0] = s.DataUtils.toHalfFloat(Math.min(e[t + 0] * i, 65504)), r[n + 1] = s.DataUtils.toHalfFloat(Math.min(e[t + 1] * i, 65504)), r[n + 2] = s.DataUtils.toHalfFloat(Math.min(e[t + 2] * i, 65504)), r[n + 3] = s.DataUtils.toHalfFloat(1)
                            }(d, 4 * e, h, 4 * e);
                            t = h, r = s.HalfFloatType;
                            break;
                        default:
                            throw Error("THREE.RGBELoader: Unsupported type: " + this.type)
                    }
                    return {
                        width: u,
                        height: c,
                        data: t,
                        header: l.string,
                        gamma: l.gamma,
                        exposure: l.exposure,
                        type: r
                    }
                }
                setDataType(e) {
                    return this.type = e, this
                }
                load(e, t, r, n) {
                    return super.load(e, function(e, r) {
                        switch (e.type) {
                            case s.FloatType:
                            case s.HalfFloatType:
                                "colorSpace" in e ? e.colorSpace = "srgb-linear" : e.encoding = 3e3, e.minFilter = s.LinearFilter, e.magFilter = s.LinearFilter, e.generateMipmaps = !1, e.flipY = !0
                        }
                        t && t(e, r)
                    }, r, n)
                }
            }
            var d = {},
                f = Uint8Array,
                h = Uint16Array,
                p = Uint32Array,
                m = new f([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0]),
                g = new f([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0]),
                A = new f([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
                v = function(e, t) {
                    for (var r = new h(31), n = 0; n < 31; ++n) r[n] = t += 1 << e[n - 1];
                    for (var i = new p(r[30]), n = 1; n < 30; ++n)
                        for (var a = r[n]; a < r[n + 1]; ++a) i[a] = a - r[n] << 5 | n;
                    return [r, i]
                },
                y = v(m, 2),
                C = y[0],
                B = y[1];
            C[28] = 258, B[258] = 28;
            for (var _ = v(g, 0), b = _[0], E = _[1], w = new h(32768), M = 0; M < 32768; ++M) {
                var T = (43690 & M) >>> 1 | (21845 & M) << 1;
                T = (61680 & (T = (52428 & T) >>> 2 | (13107 & T) << 2)) >>> 4 | (3855 & T) << 4, w[M] = ((65280 & T) >>> 8 | (255 & T) << 8) >>> 1
            }
            for (var x = function(e, t, r) {
                    for (var n, i = e.length, a = 0, o = new h(t); a < i; ++a) ++o[e[a] - 1];
                    var s = new h(t);
                    for (a = 0; a < t; ++a) s[a] = s[a - 1] + o[a - 1] << 1;
                    if (r) {
                        n = new h(1 << t);
                        var l = 15 - t;
                        for (a = 0; a < i; ++a)
                            if (e[a])
                                for (var u = a << 4 | e[a], c = t - e[a], d = s[e[a] - 1]++ << c, f = d | (1 << c) - 1; d <= f; ++d) n[w[d] >>> l] = u
                    } else
                        for (a = 0, n = new h(i); a < i; ++a) e[a] && (n[a] = w[s[e[a] - 1]++] >>> 15 - e[a]);
                    return n
                }, F = new f(288), M = 0; M < 144; ++M) F[M] = 8;
            for (var M = 144; M < 256; ++M) F[M] = 9;
            for (var M = 256; M < 280; ++M) F[M] = 7;
            for (var M = 280; M < 288; ++M) F[M] = 8;
            for (var S = new f(32), M = 0; M < 32; ++M) S[M] = 5;
            var R = x(F, 9, 1),
                O = x(S, 5, 1),
                I = function(e) {
                    for (var t = e[0], r = 1; r < e.length; ++r) e[r] > t && (t = e[r]);
                    return t
                },
                D = function(e, t, r) {
                    var n = t / 8 | 0;
                    return (e[n] | e[n + 1] << 8) >> (7 & t) & r
                },
                P = function(e, t) {
                    var r = t / 8 | 0;
                    return (e[r] | e[r + 1] << 8 | e[r + 2] << 16) >> (7 & t)
                },
                L = function(e) {
                    return (e / 8 | 0) + (7 & e && 1)
                },
                H = function(e, t, r) {
                    (null == t || t < 0) && (t = 0), (null == r || r > e.length) && (r = e.length);
                    var n = new(e instanceof h ? h : e instanceof p ? p : f)(r - t);
                    return n.set(e.subarray(t, r)), n
                },
                U = function(e, t, r) {
                    var n = e.length;
                    if (!n || r && !r.l && n < 5) return t || new f(0);
                    var i = !t || r,
                        a = !r || r.i;
                    r || (r = {}), t || (t = new f(3 * n));
                    var o = function(e) {
                            var r = t.length;
                            if (e > r) {
                                var n = new f(Math.max(2 * r, e));
                                n.set(t), t = n
                            }
                        },
                        s = r.f || 0,
                        l = r.p || 0,
                        u = r.b || 0,
                        c = r.l,
                        d = r.d,
                        h = r.m,
                        p = r.n,
                        v = 8 * n;
                    do {
                        if (!c) {
                            r.f = s = D(e, l, 1);
                            var y = D(e, l + 1, 3);
                            if (l += 3, y) {
                                if (1 == y) c = R, d = O, h = 9, p = 5;
                                else if (2 == y) {
                                    var B = D(e, l, 31) + 257,
                                        _ = D(e, l + 10, 15) + 4,
                                        E = B + D(e, l + 5, 31) + 1;
                                    l += 14;
                                    for (var w = new f(E), M = new f(19), T = 0; T < _; ++T) M[A[T]] = D(e, l + 3 * T, 7);
                                    l += 3 * _;
                                    for (var F = I(M), S = (1 << F) - 1, U = x(M, F, 1), T = 0; T < E;) {
                                        var G = U[D(e, l, S)];
                                        l += 15 & G;
                                        var k = G >>> 4;
                                        if (k < 16) w[T++] = k;
                                        else {
                                            var N = 0,
                                                J = 0;
                                            for (16 == k ? (J = 3 + D(e, l, 3), l += 2, N = w[T - 1]) : 17 == k ? (J = 3 + D(e, l, 7), l += 3) : 18 == k && (J = 11 + D(e, l, 127), l += 7); J--;) w[T++] = N
                                        }
                                    }
                                    var z = w.subarray(0, B),
                                        j = w.subarray(B);
                                    h = I(z), p = I(j), c = x(z, h, 1), d = x(j, p, 1)
                                } else throw "invalid block type"
                            } else {
                                var k = L(l) + 4,
                                    K = e[k - 4] | e[k - 3] << 8,
                                    Q = k + K;
                                if (Q > n) {
                                    if (a) throw "unexpected EOF";
                                    break
                                }
                                i && o(u + K), t.set(e.subarray(k, Q), u), r.b = u += K, r.p = l = 8 * Q;
                                continue
                            }
                            if (l > v) {
                                if (a) throw "unexpected EOF";
                                break
                            }
                        }
                        i && o(u + 131072);
                        for (var V = (1 << h) - 1, Y = (1 << p) - 1, X = l;; X = l) {
                            var N = c[P(e, l) & V],
                                W = N >>> 4;
                            if ((l += 15 & N) > v) {
                                if (a) throw "unexpected EOF";
                                break
                            }
                            if (!N) throw "invalid length/literal";
                            if (W < 256) t[u++] = W;
                            else if (256 == W) {
                                X = l, c = null;
                                break
                            } else {
                                var Z = W - 254;
                                if (W > 264) {
                                    var T = W - 257,
                                        q = m[T];
                                    Z = D(e, l, (1 << q) - 1) + C[T], l += q
                                }
                                var $ = d[P(e, l) & Y],
                                    ee = $ >>> 4;
                                if (!$) throw "invalid distance";
                                l += 15 & $;
                                var j = b[ee];
                                if (ee > 3) {
                                    var q = g[ee];
                                    j += P(e, l) & (1 << q) - 1, l += q
                                }
                                if (l > v) {
                                    if (a) throw "unexpected EOF";
                                    break
                                }
                                i && o(u + 131072);
                                for (var et = u + Z; u < et; u += 4) t[u] = t[u - j], t[u + 1] = t[u + 1 - j], t[u + 2] = t[u + 2 - j], t[u + 3] = t[u + 3 - j];
                                u = et
                            }
                        }
                        r.l = c, r.p = X, r.b = u, c && (s = 1, r.m = h, r.d = d, r.n = p)
                    } while (!s);
                    return u == t.length ? t : H(t, 0, u)
                },
                G = function(e, t, r) {
                    r <<= 7 & t;
                    var n = t / 8 | 0;
                    e[n] |= r, e[n + 1] |= r >>> 8
                },
                k = function(e, t, r) {
                    r <<= 7 & t;
                    var n = t / 8 | 0;
                    e[n] |= r, e[n + 1] |= r >>> 8, e[n + 2] |= r >>> 16
                },
                N = function(e, t) {
                    for (var r = [], n = 0; n < e.length; ++n) e[n] && r.push({
                        s: n,
                        f: e[n]
                    });
                    var i = r.length,
                        a = r.slice();
                    if (!i) return [Y, 0];
                    if (1 == i) {
                        var o = new f(r[0].s + 1);
                        return o[r[0].s] = 1, [o, 1]
                    }
                    r.sort(function(e, t) {
                        return e.f - t.f
                    }), r.push({
                        s: -1,
                        f: 25001
                    });
                    var s = r[0],
                        l = r[1],
                        u = 0,
                        c = 1,
                        d = 2;
                    for (r[0] = {
                            s: -1,
                            f: s.f + l.f,
                            l: s,
                            r: l
                        }; c != i - 1;) s = r[r[u].f < r[d].f ? u++ : d++], l = r[u != c && r[u].f < r[d].f ? u++ : d++], r[c++] = {
                        s: -1,
                        f: s.f + l.f,
                        l: s,
                        r: l
                    };
                    for (var p = a[0].s, n = 1; n < i; ++n) a[n].s > p && (p = a[n].s);
                    var m = new h(p + 1),
                        g = J(r[c - 1], m, 0);
                    if (g > t) {
                        var n = 0,
                            A = 0,
                            v = g - t,
                            y = 1 << v;
                        for (a.sort(function(e, t) {
                                return m[t.s] - m[e.s] || e.f - t.f
                            }); n < i; ++n) {
                            var C = a[n].s;
                            if (m[C] > t) A += y - (1 << g - m[C]), m[C] = t;
                            else break
                        }
                        for (A >>>= v; A > 0;) {
                            var B = a[n].s;
                            m[B] < t ? A -= 1 << t - m[B]++ - 1 : ++n
                        }
                        for (; n >= 0 && A; --n) {
                            var _ = a[n].s;
                            m[_] == t && (--m[_], ++A)
                        }
                        g = t
                    }
                    return [new f(m), g]
                },
                J = function(e, t, r) {
                    return -1 == e.s ? Math.max(J(e.l, t, r + 1), J(e.r, t, r + 1)) : t[e.s] = r
                },
                z = function(e) {
                    for (var t = e.length; t && !e[--t];);
                    for (var r = new h(++t), n = 0, i = e[0], a = 1, o = function(e) {
                            r[n++] = e
                        }, s = 1; s <= t; ++s)
                        if (e[s] == i && s != t) ++a;
                        else {
                            if (!i && a > 2) {
                                for (; a > 138; a -= 138) o(32754);
                                a > 2 && (o(a > 10 ? a - 11 << 5 | 28690 : a - 3 << 5 | 12305), a = 0)
                            } else if (a > 3) {
                                for (o(i), --a; a > 6; a -= 6) o(8304);
                                a > 2 && (o(a - 3 << 5 | 8208), a = 0)
                            }
                            for (; a--;) o(i);
                            a = 1, i = e[s]
                        }
                    return [r.subarray(0, n), t]
                },
                j = function(e, t) {
                    for (var r = 0, n = 0; n < t.length; ++n) r += e[n] * t[n];
                    return r
                },
                K = function(e, t, r) {
                    var n = r.length,
                        i = L(t + 2);
                    e[i] = 255 & n, e[i + 1] = n >>> 8, e[i + 2] = 255 ^ e[i], e[i + 3] = 255 ^ e[i + 1];
                    for (var a = 0; a < n; ++a) e[i + a + 4] = r[a];
                    return (i + 4 + n) * 8
                },
                Q = function(e, t, r, n, i, a, o, s, l, u, c) {
                    G(t, c++, r), ++i[256];
                    for (var d, f, p, v, y = N(i, 15), C = y[0], B = y[1], _ = N(a, 15), b = _[0], E = _[1], w = z(C), M = w[0], T = w[1], R = z(b), O = R[0], I = R[1], D = new h(19), P = 0; P < M.length; ++P) D[31 & M[P]]++;
                    for (var P = 0; P < O.length; ++P) D[31 & O[P]]++;
                    for (var L = N(D, 7), H = L[0], U = L[1], J = 19; J > 4 && !H[A[J - 1]]; --J);
                    var Q = u + 5 << 3,
                        V = j(i, F) + j(a, S) + o,
                        Y = j(i, C) + j(a, b) + o + 14 + 3 * J + j(D, H) + (2 * D[16] + 3 * D[17] + 7 * D[18]);
                    if (Q <= V && Q <= Y) return K(t, c, e.subarray(l, l + u));
                    if (G(t, c, 1 + (Y < V)), c += 2, Y < V) {
                        d = x(C, B, 0), f = C, p = x(b, E, 0), v = b;
                        var X = x(H, U, 0);
                        G(t, c, T - 257), G(t, c + 5, I - 1), G(t, c + 10, J - 4), c += 14;
                        for (var P = 0; P < J; ++P) G(t, c + 3 * P, H[A[P]]);
                        c += 3 * J;
                        for (var W = [M, O], Z = 0; Z < 2; ++Z)
                            for (var q = W[Z], P = 0; P < q.length; ++P) {
                                var $ = 31 & q[P];
                                G(t, c, X[$]), c += H[$], $ > 15 && (G(t, c, q[P] >>> 5 & 127), c += q[P] >>> 12)
                            }
                    } else d = null, f = F, p = null, v = S;
                    for (var P = 0; P < s; ++P)
                        if (n[P] > 255) {
                            var $ = n[P] >>> 18 & 31;
                            k(t, c, d[$ + 257]), c += f[$ + 257], $ > 7 && (G(t, c, n[P] >>> 23 & 31), c += m[$]);
                            var ee = 31 & n[P];
                            k(t, c, p[ee]), c += v[ee], ee > 3 && (k(t, c, n[P] >>> 5 & 8191), c += g[ee])
                        } else k(t, c, d[n[P]]), c += f[n[P]];
                    return k(t, c, d[256]), c + f[256]
                },
                V = new p([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]),
                Y = new f(0),
                X = function(e) {
                    if ((15 & e[0]) != 8 || e[0] >>> 4 > 7 || (e[0] << 8 | e[1]) % 31) throw "invalid zlib data";
                    if (32 & e[1]) throw "invalid zlib data: preset dictionaries not supported"
                };

            function W(e, t) {
                return U((X(e), e.subarray(2, -4)), t)
            }
            var Z = "undefined" != typeof TextDecoder && new TextDecoder;
            try {
                Z.decode(Y, {
                    stream: !0
                })
            } catch (e) {}
            let q = "colorSpace" in new s.Texture;
            class $ extends s.DataTextureLoader {
                constructor(e) {
                    super(e), this.type = s.HalfFloatType
                }
                parse(e) {
                    let t = {
                        l: 0,
                        c: 0,
                        lc: 0
                    };

                    function r(e, r, n, i, a) {
                        for (; n < e;) r = r << 8 | M(i, a), n += 8;
                        n -= e, t.l = r >> n & (1 << e) - 1, t.c = r, t.lc = n
                    }
                    let n = Array(59),
                        i = {
                            c: 0,
                            lc: 0
                        };

                    function a(e, t, r, n) {
                        e = e << 8 | M(r, n), t += 8, i.c = e, i.lc = t
                    }
                    let o = {
                        c: 0,
                        lc: 0
                    };

                    function l(e, t, r, n, s, l, u, c, d, f) {
                        if (e == t) {
                            n < 8 && (a(r, n, s, u), r = i.c, n = i.lc);
                            var h = r >> (n -= 8),
                                h = new Uint8Array([h])[0];
                            if (d.value + h > f) return !1;
                            for (var p = c[d.value - 1]; h-- > 0;) c[d.value++] = p
                        } else {
                            if (!(d.value < f)) return !1;
                            c[d.value++] = e
                        }
                        o.c = r, o.lc = n
                    }

                    function u(e) {
                        var t = 65535 & e;
                        return t > 32767 ? t - 65536 : t
                    }
                    let c = {
                        a: 0,
                        b: 0
                    };

                    function d(e, t) {
                        var r = u(e),
                            n = u(t),
                            i = r + (1 & n) + (n >> 1),
                            a = i - n;
                        c.a = i, c.b = a
                    }

                    function f(e, t) {
                        var r = 65535 & t,
                            n = (65535 & e) - (r >> 1) & 65535;
                        c.a = r + n - 32768 & 65535, c.b = n
                    }

                    function h(e, s, u, c, d, f) {
                        var h = u.value,
                            p = w(s, u),
                            m = w(s, u);
                        u.value += 4;
                        var g = w(s, u);
                        if (u.value += 4, p < 0 || p >= 65537 || m < 0 || m >= 65537) throw "Something wrong with HUF_ENCSIZE";
                        var A = Array(65537),
                            v = Array(16384);
                        ! function(e) {
                            for (var t = 0; t < 16384; t++) e[t] = {}, e[t].len = 0, e[t].lit = 0, e[t].p = null
                        }(v);
                        var y = c - (u.value - h);
                        if (! function(e, i, a, o, s, l, u) {
                                for (var c = 0, d = 0; s <= l; s++) {
                                    if (a.value - a.value > o) return !1;
                                    r(6, c, d, e, a);
                                    var f = t.l;
                                    if (c = t.c, d = t.lc, u[s] = f, 63 == f) {
                                        if (a.value - a.value > o) throw "Something wrong with hufUnpackEncTable";
                                        r(8, c, d, e, a);
                                        var h = t.l + 6;
                                        if (c = t.c, d = t.lc, s + h > l + 1) throw "Something wrong with hufUnpackEncTable";
                                        for (; h--;) u[s++] = 0;
                                        s--
                                    } else if (f >= 59) {
                                        var h = f - 59 + 2;
                                        if (s + h > l + 1) throw "Something wrong with hufUnpackEncTable";
                                        for (; h--;) u[s++] = 0;
                                        s--
                                    }
                                }! function(e) {
                                    for (var t = 0; t <= 58; ++t) n[t] = 0;
                                    for (var t = 0; t < 65537; ++t) n[e[t]] += 1;
                                    for (var r = 0, t = 58; t > 0; --t) {
                                        var i = r + n[t] >> 1;
                                        n[t] = r, r = i
                                    }
                                    for (var t = 0; t < 65537; ++t) {
                                        var a = e[t];
                                        a > 0 && (e[t] = a | n[a]++ << 6)
                                    }
                                }(u)
                            }(e, 0, u, y, p, m, A), g > 8 * (c - (u.value - h))) throw "Something wrong with hufUncompress";
                        ! function(e, t, r, n) {
                            for (; t <= r; t++) {
                                var i = e[t] >> 6,
                                    a = 63 & e[t];
                                if (i >> a) throw "Invalid table entry";
                                if (a > 14) {
                                    var o = n[i >> a - 14];
                                    if (o.len) throw "Invalid table entry";
                                    if (o.lit++, o.p) {
                                        var s = o.p;
                                        o.p = Array(o.lit);
                                        for (var l = 0; l < o.lit - 1; ++l) o.p[l] = s[l]
                                    } else o.p = [, ];
                                    o.p[o.lit - 1] = t
                                } else if (a)
                                    for (var u = 0, l = 1 << 14 - a; l > 0; l--) {
                                        var o = n[(i << 14 - a) + u];
                                        if (o.len || o.p) throw "Invalid table entry";
                                        o.len = a, o.lit = t, u++
                                    }
                            }
                        }(A, p, m, v),
                        function(e, t, r, n, s, u, c, d, f, h) {
                            for (var p = 0, m = 0, g = Math.trunc(s.value + (u + 7) / 8); s.value < g;)
                                for (a(p, m, r, s), p = i.c, m = i.lc; m >= 14;) {
                                    var A = t[p >> m - 14 & 16383];
                                    if (A.len) m -= A.len, l(A.lit, c, p, m, r, n, s, f, h, d), p = o.c, m = o.lc;
                                    else {
                                        if (!A.p) throw "hufDecode issues";
                                        for (v = 0; v < A.lit; v++) {
                                            for (var v, y = 63 & e[A.p[v]]; m < y && s.value < g;) a(p, m, r, s), p = i.c, m = i.lc;
                                            if (m >= y && e[A.p[v]] >> 6 == (p >> m - y & (1 << y) - 1)) {
                                                m -= y, l(A.p[v], c, p, m, r, n, s, f, h, d), p = o.c, m = o.lc;
                                                break
                                            }
                                        }
                                        if (v == A.lit) throw "hufDecode issues"
                                    }
                                }
                            var C = 8 - u & 7;
                            for (p >>= C, m -= C; m > 0;) {
                                var A = t[p << 14 - m & 16383];
                                if (A.len) m -= A.len, l(A.lit, c, p, m, r, n, s, f, h, d), p = o.c, m = o.lc;
                                else throw "hufDecode issues"
                            }
                        }(A, v, e, s, u, g, m, f, d, {
                            value: 0
                        })
                    }

                    function p(e) {
                        for (var t = 1; t < e.length; t++) {
                            var r = e[t - 1] + e[t] - 128;
                            e[t] = r
                        }
                    }

                    function m(e, t) {
                        for (var r = 0, n = Math.floor((e.length + 1) / 2), i = 0, a = e.length - 1; !(i > a) && (t[i++] = e[r++], !(i > a));) t[i++] = e[n++]
                    }

                    function g(e) {
                        for (var t = e.byteLength, r = [], n = 0, i = new DataView(e); t > 0;) {
                            var a = i.getInt8(n++);
                            if (a < 0) {
                                var o = -a;
                                t -= o + 1;
                                for (var s = 0; s < o; s++) r.push(i.getUint8(n++))
                            } else {
                                var o = a;
                                t -= 2;
                                for (var l = i.getUint8(n++), s = 0; s < o + 1; s++) r.push(l)
                            }
                        }
                        return r
                    }

                    function A(e) {
                        return new DataView(e.array.buffer, e.offset.value, e.size)
                    }

                    function v(e) {
                        var t = new Uint8Array(g(e.viewer.buffer.slice(e.offset.value, e.offset.value + e.size))),
                            r = new Uint8Array(t.length);
                        return p(t), m(t, r), new DataView(r.buffer)
                    }

                    function y(e) {
                        var t = W(e.array.slice(e.offset.value, e.offset.value + e.size)),
                            r = new Uint8Array(t.length);
                        return p(t), m(t, r), new DataView(r.buffer)
                    }

                    function C(e) {
                        for (var t = e.viewer, r = {
                                value: e.offset.value
                            }, n = new Uint16Array(e.width * e.scanlineBlockSize * (e.channels * e.type)), i = new Uint8Array(8192), a = 0, o = Array(e.channels), s = 0; s < e.channels; s++) o[s] = {}, o[s].start = a, o[s].end = o[s].start, o[s].nx = e.width, o[s].ny = e.lines, o[s].size = e.type, a += o[s].nx * o[s].ny * o[s].size;
                        var l = O(t, r),
                            u = O(t, r);
                        if (u >= 8192) throw "Something is wrong with PIZ_COMPRESSION BITMAP_SIZE";
                        if (l <= u)
                            for (var s = 0; s < u - l + 1; s++) i[s + l] = T(t, r);
                        var p = new Uint16Array(65536),
                            m = function(e, t) {
                                for (var r = 0, n = 0; n < 65536; ++n)(0 == n || e[n >> 3] & 1 << (7 & n)) && (t[r++] = n);
                                for (var i = r - 1; r < 65536;) t[r++] = 0;
                                return i
                            }(i, p),
                            g = w(t, r);
                        h(e.array, t, r, g, n, a);
                        for (var s = 0; s < e.channels; ++s)
                            for (var A = o[s], v = 0; v < o[s].size; ++v) ! function(e, t, r, n, i, a, o) {
                                for (var s = o < 16384, l = r > i ? i : r, u = 1; u <= l;) u <<= 1;
                                for (u >>= 1, h = u, u >>= 1; u >= 1;) {
                                    for (var h, p, m, g, A, v = 0, y = 0 + a * (i - h), C = a * u, B = a * h, _ = n * u, b = n * h; v <= y; v += B) {
                                        for (var E = v, w = v + n * (r - h); E <= w; E += b) {
                                            var M = E + _,
                                                T = E + C,
                                                x = T + _;
                                            s ? (d(e[E + t], e[T + t]), p = c.a, g = c.b, d(e[M + t], e[x + t]), m = c.a, A = c.b, d(p, m), e[E + t] = c.a, e[M + t] = c.b, d(g, A)) : (f(e[E + t], e[T + t]), p = c.a, g = c.b, f(e[M + t], e[x + t]), m = c.a, A = c.b, f(p, m), e[E + t] = c.a, e[M + t] = c.b, f(g, A)), e[T + t] = c.a, e[x + t] = c.b
                                        }
                                        if (r & u) {
                                            var T = E + C;
                                            s ? d(e[E + t], e[T + t]) : f(e[E + t], e[T + t]), p = c.a, e[T + t] = c.b, e[E + t] = p
                                        }
                                    }
                                    if (i & u)
                                        for (var E = v, w = v + n * (r - h); E <= w; E += b) {
                                            var M = E + _;
                                            s ? d(e[E + t], e[M + t]) : f(e[E + t], e[M + t]), p = c.a, e[M + t] = c.b, e[E + t] = p
                                        }
                                    h = u, u >>= 1
                                }
                            }(n, A.start + v, A.nx, A.size, A.ny, A.nx * A.size, m);
                        ! function(e, t, r) {
                            for (var n = 0; n < r; ++n) t[n] = e[t[n]]
                        }(p, n, a);
                        for (var y = 0, C = new Uint8Array(n.buffer.byteLength), B = 0; B < e.lines; B++)
                            for (var _ = 0; _ < e.channels; _++) {
                                var A = o[_],
                                    b = A.nx * A.size,
                                    E = new Uint8Array(n.buffer, 2 * A.end, 2 * b);
                                C.set(E, y), y += 2 * b, A.end += b
                            }
                        return new DataView(C.buffer)
                    }

                    function B(e) {
                        var t = W(e.array.slice(e.offset.value, e.offset.value + e.size));
                        let r = e.lines * e.channels * e.width,
                            n = 1 == e.type ? new Uint16Array(r) : new Uint32Array(r),
                            i = 0,
                            a = 0,
                            o = [, , , , ];
                        for (let r = 0; r < e.lines; r++)
                            for (let r = 0; r < e.channels; r++) {
                                let r = 0;
                                switch (e.type) {
                                    case 1:
                                        o[0] = i, o[1] = o[0] + e.width, i = o[1] + e.width;
                                        for (let i = 0; i < e.width; ++i) r += t[o[0]++] << 8 | t[o[1]++], n[a] = r, a++;
                                        break;
                                    case 2:
                                        o[0] = i, o[1] = o[0] + e.width, o[2] = o[1] + e.width, i = o[2] + e.width;
                                        for (let i = 0; i < e.width; ++i) r += t[o[0]++] << 24 | t[o[1]++] << 16 | t[o[2]++] << 8, n[a] = r, a++
                                }
                            }
                        return new DataView(n.buffer)
                    }

                    function _(e) {
                        var t = e.viewer,
                            r = {
                                value: e.offset.value
                            },
                            n = new Uint8Array(e.width * e.lines * (e.channels * e.type * 2)),
                            i = {
                                version: x(t, r),
                                unknownUncompressedSize: x(t, r),
                                unknownCompressedSize: x(t, r),
                                acCompressedSize: x(t, r),
                                dcCompressedSize: x(t, r),
                                rleCompressedSize: x(t, r),
                                rleUncompressedSize: x(t, r),
                                rleRawSize: x(t, r),
                                totalAcUncompressedCount: x(t, r),
                                totalDcUncompressedCount: x(t, r),
                                acCompression: x(t, r)
                            };
                        if (i.version < 2) throw "EXRLoader.parse: " + H.compression + " version " + i.version + " is unsupported";
                        for (var a = [], o = O(t, r) - 2; o > 0;) {
                            var l = b(t.buffer, r),
                                u = T(t, r),
                                c = u >> 2 & 3,
                                d = new Int8Array([(u >> 4) - 1])[0],
                                f = T(t, r);
                            a.push({
                                name: l,
                                index: d,
                                type: f,
                                compression: c
                            }), o -= l.length + 3
                        }
                        for (var p = H.channels, m = Array(e.channels), A = 0; A < e.channels; ++A) {
                            var v = m[A] = {},
                                C = p[A];
                            v.name = C.name, v.compression = 0, v.decoded = !1, v.type = C.pixelType, v.pLinear = C.pLinear, v.width = e.width, v.height = e.lines
                        }
                        for (var B = {
                                idx: [, , , ]
                            }, _ = 0; _ < e.channels; ++_)
                            for (var v = m[_], A = 0; A < a.length; ++A) {
                                var E = a[A];
                                v.name == E.name && (v.compression = E.compression, E.index >= 0 && (B.idx[E.index] = _), v.offset = _)
                            }
                        if (i.acCompressedSize > 0) switch (i.acCompression) {
                            case 0:
                                var w = new Uint16Array(i.totalAcUncompressedCount);
                                h(e.array, t, r, i.acCompressedSize, w, i.totalAcUncompressedCount);
                                break;
                            case 1:
                                var M = e.array.slice(r.value, r.value + i.totalAcUncompressedCount),
                                    F = W(M),
                                    w = new Uint16Array(F.buffer);
                                r.value += i.totalAcUncompressedCount
                        }
                        if (i.dcCompressedSize > 0) {
                            var S = new Uint16Array(y({
                                array: e.array,
                                offset: r,
                                size: i.dcCompressedSize
                            }).buffer);
                            r.value += i.dcCompressedSize
                        }
                        if (i.rleRawSize > 0) {
                            var M = e.array.slice(r.value, r.value + i.rleCompressedSize),
                                F = W(M),
                                I = g(F.buffer);
                            r.value += i.rleCompressedSize
                        }
                        for (var D = 0, P = Array(m.length), A = 0; A < P.length; ++A) P[A] = [];
                        for (var L = 0; L < e.lines; ++L)
                            for (var U = 0; U < m.length; ++U) P[U].push(D), D += m[U].width * e.type * 2;
                        ! function(e, t, r, n, i, a) {
                            var o = new DataView(a.buffer),
                                l = r[e.idx[0]].width,
                                u = r[e.idx[0]].height,
                                c = Math.floor(l / 8),
                                d = Math.ceil(l / 8),
                                f = Math.ceil(u / 8),
                                h = l - (d - 1) * 8,
                                p = u - (f - 1) * 8,
                                m = {
                                    value: 0
                                },
                                g = [, , , ],
                                A = [, , , ],
                                v = [, , , ],
                                y = [, , , ],
                                C = [, , , ];
                            for (let r = 0; r < 3; ++r) C[r] = t[e.idx[r]], g[r] = r < 1 ? 0 : g[r - 1] + d * f, A[r] = new Float32Array(64), v[r] = new Uint16Array(64), y[r] = new Uint16Array(64 * d);
                            for (let t = 0; t < f; ++t) {
                                var B, _, b = 8;
                                t == f - 1 && (b = p);
                                var E = 8;
                                for (let e = 0; e < d; ++e) {
                                    e == d - 1 && (E = h);
                                    for (let e = 0; e < 3; ++e) v[e].fill(0), v[e][0] = i[g[e]++],
                                        function(e, t, r) {
                                            for (var n, i = 1; i < 64;) 65280 == (n = t[e.value]) ? i = 64 : n >> 8 == 255 ? i += 255 & n : (r[i] = n, i++), e.value++
                                        }(m, n, v[e]), B = v[e], (_ = A[e])[0] = R(B[0]), _[1] = R(B[1]), _[2] = R(B[5]), _[3] = R(B[6]), _[4] = R(B[14]), _[5] = R(B[15]), _[6] = R(B[27]), _[7] = R(B[28]), _[8] = R(B[2]), _[9] = R(B[4]), _[10] = R(B[7]), _[11] = R(B[13]), _[12] = R(B[16]), _[13] = R(B[26]), _[14] = R(B[29]), _[15] = R(B[42]), _[16] = R(B[3]), _[17] = R(B[8]), _[18] = R(B[12]), _[19] = R(B[17]), _[20] = R(B[25]), _[21] = R(B[30]), _[22] = R(B[41]), _[23] = R(B[43]), _[24] = R(B[9]), _[25] = R(B[11]), _[26] = R(B[18]), _[27] = R(B[24]), _[28] = R(B[31]), _[29] = R(B[40]), _[30] = R(B[44]), _[31] = R(B[53]), _[32] = R(B[10]), _[33] = R(B[19]), _[34] = R(B[23]), _[35] = R(B[32]), _[36] = R(B[39]), _[37] = R(B[45]), _[38] = R(B[52]), _[39] = R(B[54]), _[40] = R(B[20]), _[41] = R(B[22]), _[42] = R(B[33]), _[43] = R(B[38]), _[44] = R(B[46]), _[45] = R(B[51]), _[46] = R(B[55]), _[47] = R(B[60]), _[48] = R(B[21]), _[49] = R(B[34]), _[50] = R(B[37]), _[51] = R(B[47]), _[52] = R(B[50]), _[53] = R(B[56]), _[54] = R(B[59]), _[55] = R(B[61]), _[56] = R(B[35]), _[57] = R(B[36]), _[58] = R(B[48]), _[59] = R(B[49]), _[60] = R(B[57]), _[61] = R(B[58]), _[62] = R(B[62]), _[63] = R(B[63]),
                                        function(e) {
                                            let t = .5 * Math.cos(3.14159 / 16),
                                                r = .5 * Math.cos(3.14159 / 8),
                                                n = .5 * Math.cos(3 * 3.14159 / 16),
                                                i = .5 * Math.cos(3 * 3.14159 / 8);
                                            for (var a = [, , , , ], o = [, , , , ], s = [, , , , ], l = [, , , , ], u = 0; u < 8; ++u) {
                                                var c = 8 * u;
                                                a[0] = r * e[c + 2], a[1] = i * e[c + 2], a[2] = r * e[c + 6], a[3] = i * e[c + 6], o[0] = t * e[c + 1] + n * e[c + 3] + .2777854612564676 * e[c + 5] + .09754573032714427 * e[c + 7], o[1] = n * e[c + 1] - .09754573032714427 * e[c + 3] - t * e[c + 5] - .2777854612564676 * e[c + 7], o[2] = .2777854612564676 * e[c + 1] - t * e[c + 3] + .09754573032714427 * e[c + 5] + n * e[c + 7], o[3] = .09754573032714427 * e[c + 1] - .2777854612564676 * e[c + 3] + n * e[c + 5] - t * e[c + 7], s[0] = .35355362513961314 * (e[c + 0] + e[c + 4]), s[3] = .35355362513961314 * (e[c + 0] - e[c + 4]), s[1] = a[0] + a[3], s[2] = a[1] - a[2], l[0] = s[0] + s[1], l[1] = s[3] + s[2], l[2] = s[3] - s[2], l[3] = s[0] - s[1], e[c + 0] = l[0] + o[0], e[c + 1] = l[1] + o[1], e[c + 2] = l[2] + o[2], e[c + 3] = l[3] + o[3], e[c + 4] = l[3] - o[3], e[c + 5] = l[2] - o[2], e[c + 6] = l[1] - o[1], e[c + 7] = l[0] - o[0]
                                            }
                                            for (var d = 0; d < 8; ++d) a[0] = r * e[16 + d], a[1] = i * e[16 + d], a[2] = r * e[48 + d], a[3] = i * e[48 + d], o[0] = t * e[8 + d] + n * e[24 + d] + .2777854612564676 * e[40 + d] + .09754573032714427 * e[56 + d], o[1] = n * e[8 + d] - .09754573032714427 * e[24 + d] - t * e[40 + d] - .2777854612564676 * e[56 + d], o[2] = .2777854612564676 * e[8 + d] - t * e[24 + d] + .09754573032714427 * e[40 + d] + n * e[56 + d], o[3] = .09754573032714427 * e[8 + d] - .2777854612564676 * e[24 + d] + n * e[40 + d] - t * e[56 + d], s[0] = .35355362513961314 * (e[d] + e[32 + d]), s[3] = .35355362513961314 * (e[d] - e[32 + d]), s[1] = a[0] + a[3], s[2] = a[1] - a[2], l[0] = s[0] + s[1], l[1] = s[3] + s[2], l[2] = s[3] - s[2], l[3] = s[0] - s[1], e[0 + d] = l[0] + o[0], e[8 + d] = l[1] + o[1], e[16 + d] = l[2] + o[2], e[24 + d] = l[3] + o[3], e[32 + d] = l[3] - o[3], e[40 + d] = l[2] - o[2], e[48 + d] = l[1] - o[1], e[56 + d] = l[0] - o[0]
                                        }(A[e]);
                                    ! function(e) {
                                        for (var t = 0; t < 64; ++t) {
                                            var r = e[0][t],
                                                n = e[1][t],
                                                i = e[2][t];
                                            e[0][t] = r + 1.5747 * i, e[1][t] = r - .1873 * n - .4682 * i, e[2][t] = r + 1.8556 * n
                                        }
                                    }(A);
                                    for (let t = 0; t < 3; ++t) ! function(e, t, r) {
                                        for (var n, i = 0; i < 64; ++i) t[r + i] = s.DataUtils.toHalfFloat((n = e[i]) <= 1 ? Math.sign(n) * Math.pow(Math.abs(n), 2.2) : Math.sign(n) * Math.pow(9.025013291561939, Math.abs(n) - 1))
                                    }(A[t], y[t], 64 * e)
                                }
                                let a = 0;
                                for (let n = 0; n < 3; ++n) {
                                    let i = r[e.idx[n]].type;
                                    for (let e = 8 * t; e < 8 * t + b; ++e) {
                                        a = C[n][e];
                                        for (let t = 0; t < c; ++t) {
                                            let r = 64 * t + (7 & e) * 8;
                                            o.setUint16(a + 0 * i, y[n][r + 0], !0), o.setUint16(a + 2 * i, y[n][r + 1], !0), o.setUint16(a + 4 * i, y[n][r + 2], !0), o.setUint16(a + 6 * i, y[n][r + 3], !0), o.setUint16(a + 8 * i, y[n][r + 4], !0), o.setUint16(a + 10 * i, y[n][r + 5], !0), o.setUint16(a + 12 * i, y[n][r + 6], !0), o.setUint16(a + 14 * i, y[n][r + 7], !0), a += 16 * i
                                        }
                                    }
                                    if (c != d)
                                        for (let e = 8 * t; e < 8 * t + b; ++e) {
                                            let t = C[n][e] + 8 * c * 2 * i,
                                                r = 64 * c + (7 & e) * 8;
                                            for (let e = 0; e < E; ++e) o.setUint16(t + 2 * e * i, y[n][r + e], !0)
                                        }
                                }
                            }
                            for (var w = new Uint16Array(l), o = new DataView(a.buffer), M = 0; M < 3; ++M) {
                                r[e.idx[M]].decoded = !0;
                                var T = r[e.idx[M]].type;
                                if (2 == r[M].type)
                                    for (var x = 0; x < u; ++x) {
                                        let e = C[M][x];
                                        for (var F = 0; F < l; ++F) w[F] = o.getUint16(e + 2 * F * T, !0);
                                        for (var F = 0; F < l; ++F) o.setFloat32(e + 2 * F * T, R(w[F]), !0)
                                    }
                            }
                        }(B, P, m, w, S, n);
                        for (var A = 0; A < m.length; ++A) {
                            var v = m[A];
                            if (!v.decoded) {
                                if (2 === v.compression)
                                    for (var G = 0, k = 0, L = 0; L < e.lines; ++L) {
                                        for (var N = P[A][G], J = 0; J < v.width; ++J) {
                                            for (var z = 0; z < 2 * v.type; ++z) n[N++] = I[k + z * v.width * v.height];
                                            k++
                                        }
                                        G++
                                    } else throw "EXRLoader.parse: unsupported channel compression"
                            }
                        }
                        return new DataView(n.buffer)
                    }

                    function b(e, t) {
                        for (var r = new Uint8Array(e), n = 0; 0 != r[t.value + n];) n += 1;
                        var i = new TextDecoder().decode(r.slice(t.value, t.value + n));
                        return t.value = t.value + n + 1, i
                    }

                    function E(e, t) {
                        var r = e.getInt32(t.value, !0);
                        return t.value = t.value + 4, r
                    }

                    function w(e, t) {
                        var r = e.getUint32(t.value, !0);
                        return t.value = t.value + 4, r
                    }

                    function M(e, t) {
                        var r = e[t.value];
                        return t.value = t.value + 1, r
                    }

                    function T(e, t) {
                        var r = e.getUint8(t.value);
                        return t.value = t.value + 1, r
                    }
                    let x = function(e, t) {
                        let r;
                        return "getBigInt64" in DataView.prototype ? r = Number(e.getBigInt64(t.value, !0)) : r = e.getUint32(t.value + 4, !0) + Number(e.getUint32(t.value, !0) << 32), t.value += 8, r
                    };

                    function F(e, t) {
                        var r = e.getFloat32(t.value, !0);
                        return t.value += 4, r
                    }

                    function S(e, t) {
                        return s.DataUtils.toHalfFloat(F(e, t))
                    }

                    function R(e) {
                        var t = (31744 & e) >> 10,
                            r = 1023 & e;
                        return (e >> 15 ? -1 : 1) * (t ? 31 === t ? r ? NaN : 1 / 0 : Math.pow(2, t - 15) * (1 + r / 1024) : r / 1024 * 6103515625e-14)
                    }

                    function O(e, t) {
                        var r = e.getUint16(t.value, !0);
                        return t.value += 2, r
                    }

                    function I(e, t) {
                        return R(O(e, t))
                    }
                    let D = new DataView(e),
                        P = new Uint8Array(e),
                        L = {
                            value: 0
                        },
                        H = function(e, t, r) {
                            let n = {};
                            if (20000630 != e.getUint32(0, !0)) throw "THREE.EXRLoader: provided file doesn't appear to be in OpenEXR format.";
                            n.version = e.getUint8(4);
                            let i = e.getUint8(5);
                            n.spec = {
                                singleTile: !!(2 & i),
                                longName: !!(4 & i),
                                deepFormat: !!(8 & i),
                                multiPart: !!(16 & i)
                            }, r.value = 8;
                            for (var a = !0; a;) {
                                var o = b(t, r);
                                if (0 == o) a = !1;
                                else {
                                    var s = b(t, r),
                                        l = w(e, r),
                                        u = function(e, t, r, n, i) {
                                            var a, o, s, l, u;
                                            if ("string" === n || "stringvector" === n || "iccProfile" === n) return a = new TextDecoder().decode(new Uint8Array(t).slice(r.value, r.value + i)), r.value = r.value + i, a;
                                            if ("chlist" === n) return function(e, t, r, n) {
                                                for (var i = r.value, a = []; r.value < i + n - 1;) {
                                                    var o = b(t, r),
                                                        s = E(e, r),
                                                        l = T(e, r);
                                                    r.value += 3;
                                                    var u = E(e, r),
                                                        c = E(e, r);
                                                    a.push({
                                                        name: o,
                                                        pixelType: s,
                                                        pLinear: l,
                                                        xSampling: u,
                                                        ySampling: c
                                                    })
                                                }
                                                return r.value += 1, a
                                            }(e, t, r, i);
                                            if ("chromaticities" === n) return o = F(e, r), s = F(e, r), l = F(e, r), u = F(e, r), {
                                                redX: o,
                                                redY: s,
                                                greenX: l,
                                                greenY: u,
                                                blueX: F(e, r),
                                                blueY: F(e, r),
                                                whiteX: F(e, r),
                                                whiteY: F(e, r)
                                            };
                                            if ("compression" === n) return ["NO_COMPRESSION", "RLE_COMPRESSION", "ZIPS_COMPRESSION", "ZIP_COMPRESSION", "PIZ_COMPRESSION", "PXR24_COMPRESSION", "B44_COMPRESSION", "B44A_COMPRESSION", "DWAA_COMPRESSION", "DWAB_COMPRESSION"][T(e, r)];
                                            if ("box2i" === n) return {
                                                xMin: w(e, r),
                                                yMin: w(e, r),
                                                xMax: w(e, r),
                                                yMax: w(e, r)
                                            };
                                            if ("lineOrder" === n) return ["INCREASING_Y"][T(e, r)];
                                            if ("float" === n) return F(e, r);
                                            else if ("v2f" === n) return [F(e, r), F(e, r)];
                                            else if ("v3f" === n) return [F(e, r), F(e, r), F(e, r)];
                                            else if ("int" === n) return E(e, r);
                                            else if ("rational" === n) return [E(e, r), w(e, r)];
                                            else if ("timecode" === n) return [w(e, r), w(e, r)];
                                            else return "preview" === n ? (r.value += i, "skipped") : void(r.value += i)
                                        }(e, t, r, s, l);
                                    void 0 === u ? console.warn(`EXRLoader.parse: skipped unknown header attribute type '${s}'.`) : n[o] = u
                                }
                            }
                            if ((-5 & i) != 0) throw console.error("EXRHeader:", n), "THREE.EXRLoader: provided file is currently unsupported.";
                            return n
                        }(D, e, L),
                        U = function(e, t, r, n, i) {
                            let a = {
                                size: 0,
                                viewer: t,
                                array: r,
                                offset: n,
                                width: e.dataWindow.xMax - e.dataWindow.xMin + 1,
                                height: e.dataWindow.yMax - e.dataWindow.yMin + 1,
                                channels: e.channels.length,
                                bytesPerLine: null,
                                lines: null,
                                inputSize: null,
                                type: e.channels[0].pixelType,
                                uncompress: null,
                                getter: null,
                                format: null,
                                [q ? "colorSpace" : "encoding"]: null
                            };
                            switch (e.compression) {
                                case "NO_COMPRESSION":
                                    a.lines = 1, a.uncompress = A;
                                    break;
                                case "RLE_COMPRESSION":
                                    a.lines = 1, a.uncompress = v;
                                    break;
                                case "ZIPS_COMPRESSION":
                                    a.lines = 1, a.uncompress = y;
                                    break;
                                case "ZIP_COMPRESSION":
                                    a.lines = 16, a.uncompress = y;
                                    break;
                                case "PIZ_COMPRESSION":
                                    a.lines = 32, a.uncompress = C;
                                    break;
                                case "PXR24_COMPRESSION":
                                    a.lines = 16, a.uncompress = B;
                                    break;
                                case "DWAA_COMPRESSION":
                                    a.lines = 32, a.uncompress = _;
                                    break;
                                case "DWAB_COMPRESSION":
                                    a.lines = 256, a.uncompress = _;
                                    break;
                                default:
                                    throw "EXRLoader.parse: " + e.compression + " is unsupported"
                            }
                            if (a.scanlineBlockSize = a.lines, 1 == a.type) switch (i) {
                                case s.FloatType:
                                    a.getter = I, a.inputSize = 2;
                                    break;
                                case s.HalfFloatType:
                                    a.getter = O, a.inputSize = 2
                            } else if (2 == a.type) switch (i) {
                                case s.FloatType:
                                    a.getter = F, a.inputSize = 4;
                                    break;
                                case s.HalfFloatType:
                                    a.getter = S, a.inputSize = 4
                            } else throw "EXRLoader.parse: unsupported pixelType " + a.type + " for " + e.compression + ".";
                            a.blockCount = (e.dataWindow.yMax + 1) / a.scanlineBlockSize;
                            for (var o = 0; o < a.blockCount; o++) x(t, n);
                            a.outputChannels = 3 == a.channels ? 4 : a.channels;
                            let l = a.width * a.height * a.outputChannels;
                            switch (i) {
                                case s.FloatType:
                                    a.byteArray = new Float32Array(l), a.channels < a.outputChannels && a.byteArray.fill(1, 0, l);
                                    break;
                                case s.HalfFloatType:
                                    a.byteArray = new Uint16Array(l), a.channels < a.outputChannels && a.byteArray.fill(15360, 0, l);
                                    break;
                                default:
                                    console.error("THREE.EXRLoader: unsupported type: ", i)
                            }
                            return a.bytesPerLine = a.width * a.inputSize * a.channels, 4 == a.outputChannels ? a.format = s.RGBAFormat : a.format = s.RedFormat, q ? a.colorSpace = "srgb-linear" : a.encoding = 3e3, a
                        }(H, D, P, L, this.type),
                        G = {
                            value: 0
                        },
                        k = {
                            R: 0,
                            G: 1,
                            B: 2,
                            A: 3,
                            Y: 0
                        };
                    for (let e = 0; e < U.height / U.scanlineBlockSize; e++) {
                        let t = w(D, L);
                        U.size = w(D, L), U.lines = t + U.scanlineBlockSize > U.height ? U.height - t : U.scanlineBlockSize;
                        let r = U.size < U.lines * U.bytesPerLine ? U.uncompress(U) : A(U);
                        L.value += U.size;
                        for (let t = 0; t < U.scanlineBlockSize; t++) {
                            let n = t + e * U.scanlineBlockSize;
                            if (n >= U.height) break;
                            for (let e = 0; e < U.channels; e++) {
                                let i = k[H.channels[e].name];
                                for (let a = 0; a < U.width; a++) {
                                    G.value = (U.channels * U.width * t + e * U.width + a) * U.inputSize;
                                    let o = (U.height - 1 - n) * (U.width * U.outputChannels) + a * U.outputChannels + i;
                                    U.byteArray[o] = U.getter(r, G)
                                }
                            }
                        }
                    }
                    return {
                        header: H,
                        width: U.width,
                        height: U.height,
                        data: U.byteArray,
                        format: U.format,
                        [q ? "colorSpace" : "encoding"]: U[q ? "colorSpace" : "encoding"],
                        type: this.type
                    }
                }
                setDataType(e) {
                    return this.type = e, this
                }
                load(e, t, r, n) {
                    return super.load(e, function(e, r) {
                        q ? e.colorSpace = r.colorSpace : e.encoding = r.encoding, e.minFilter = s.LinearFilter, e.magFilter = s.LinearFilter, e.generateMipmaps = !1, e.flipY = !1, t && t(e, r)
                    }, r, n)
                }
            }
            let ee = (e, t, r) => {
                    let n;
                    switch (e) {
                        case s.UnsignedByteType:
                            n = new Uint8ClampedArray(t * r * 4);
                            break;
                        case s.HalfFloatType:
                            n = new Uint16Array(t * r * 4);
                            break;
                        case s.UnsignedIntType:
                            n = new Uint32Array(t * r * 4);
                            break;
                        case s.ByteType:
                            n = new Int8Array(t * r * 4);
                            break;
                        case s.ShortType:
                            n = new Int16Array(t * r * 4);
                            break;
                        case s.IntType:
                            n = new Int32Array(t * r * 4);
                            break;
                        case s.FloatType:
                            n = new Float32Array(t * r * 4);
                            break;
                        default:
                            throw Error("Unsupported data type")
                    }
                    return n
                },
                et = (e, t, r, i) => {
                    if (void 0 !== n) return n;
                    let a = new s.WebGLRenderTarget(1, 1, i);
                    t.setRenderTarget(a);
                    let o = new s.Mesh(new s.PlaneGeometry, new s.MeshBasicMaterial({
                        color: 16777215
                    }));
                    t.render(o, r), t.setRenderTarget(null);
                    let l = ee(e, a.width, a.height);
                    return t.readRenderTargetPixels(a, 0, 0, a.width, a.height, l), a.dispose(), o.geometry.dispose(), o.material.dispose(), n = 0 !== l[0]
                };
            class er {
                constructor(e) {
                    var t, r, n, i, a, o, l, u, c, d, f, h, p, m, g, A;
                    this._rendererIsDisposable = !1, this._supportsReadPixels = !0, this.render = () => {
                        this._renderer.setRenderTarget(this._renderTarget);
                        try {
                            this._renderer.render(this._scene, this._camera)
                        } catch (e) {
                            throw this._renderer.setRenderTarget(null), e
                        }
                        this._renderer.setRenderTarget(null)
                    }, this._width = e.width, this._height = e.height, this._type = e.type, this._colorSpace = e.colorSpace;
                    let v = {
                        format: s.RGBAFormat,
                        depthBuffer: !1,
                        stencilBuffer: !1,
                        type: this._type,
                        colorSpace: this._colorSpace,
                        anisotropy: (null === (t = e.renderTargetOptions) || void 0 === t ? void 0 : t.anisotropy) !== void 0 ? null === (r = e.renderTargetOptions) || void 0 === r ? void 0 : r.anisotropy : 1,
                        generateMipmaps: (null === (n = e.renderTargetOptions) || void 0 === n ? void 0 : n.generateMipmaps) !== void 0 && (null === (i = e.renderTargetOptions) || void 0 === i ? void 0 : i.generateMipmaps),
                        magFilter: (null === (a = e.renderTargetOptions) || void 0 === a ? void 0 : a.magFilter) !== void 0 ? null === (o = e.renderTargetOptions) || void 0 === o ? void 0 : o.magFilter : s.LinearFilter,
                        minFilter: (null === (l = e.renderTargetOptions) || void 0 === l ? void 0 : l.minFilter) !== void 0 ? null === (u = e.renderTargetOptions) || void 0 === u ? void 0 : u.minFilter : s.LinearFilter,
                        samples: (null === (c = e.renderTargetOptions) || void 0 === c ? void 0 : c.samples) !== void 0 ? null === (d = e.renderTargetOptions) || void 0 === d ? void 0 : d.samples : void 0,
                        wrapS: (null === (f = e.renderTargetOptions) || void 0 === f ? void 0 : f.wrapS) !== void 0 ? null === (h = e.renderTargetOptions) || void 0 === h ? void 0 : h.wrapS : s.ClampToEdgeWrapping,
                        wrapT: (null === (p = e.renderTargetOptions) || void 0 === p ? void 0 : p.wrapT) !== void 0 ? null === (m = e.renderTargetOptions) || void 0 === m ? void 0 : m.wrapT : s.ClampToEdgeWrapping
                    };
                    if (this._material = e.material, e.renderer ? this._renderer = e.renderer : (this._renderer = er.instantiateRenderer(), this._rendererIsDisposable = !0), this._scene = new s.Scene, this._camera = new s.OrthographicCamera, this._camera.position.set(0, 0, 10), this._camera.left = -.5, this._camera.right = .5, this._camera.top = .5, this._camera.bottom = -.5, this._camera.updateProjectionMatrix(), !et(this._type, this._renderer, this._camera, v)) {
                        let e;
                        this._type === s.HalfFloatType && (e = this._renderer.extensions.has("EXT_color_buffer_float") ? s.FloatType : void 0), void 0 !== e ? (console.warn(`This browser does not support reading pixels from ${this._type} RenderTargets, switching to ${s.FloatType}`), this._type = e) : (this._supportsReadPixels = !1, console.warn("This browser dos not support toArray or toDataTexture, calls to those methods will result in an error thrown"))
                    }
                    this._quad = new s.Mesh(new s.PlaneGeometry, this._material), this._quad.geometry.computeBoundingBox(), this._scene.add(this._quad), this._renderTarget = new s.WebGLRenderTarget(this.width, this.height, v), this._renderTarget.texture.mapping = (null === (g = e.renderTargetOptions) || void 0 === g ? void 0 : g.mapping) !== void 0 ? null === (A = e.renderTargetOptions) || void 0 === A ? void 0 : A.mapping : s.UVMapping
                }
                static instantiateRenderer() {
                    let e = new s.WebGLRenderer;
                    return e.setSize(128, 128), e
                }
                toArray() {
                    if (!this._supportsReadPixels) throw Error("Can't read pixels in this browser");
                    let e = ee(this._type, this._width, this._height);
                    return this._renderer.readRenderTargetPixels(this._renderTarget, 0, 0, this._width, this._height, e), e
                }
                toDataTexture(e) {
                    let t = new s.DataTexture(this.toArray(), this.width, this.height, s.RGBAFormat, this._type, (null == e ? void 0 : e.mapping) || s.UVMapping, (null == e ? void 0 : e.wrapS) || s.ClampToEdgeWrapping, (null == e ? void 0 : e.wrapT) || s.ClampToEdgeWrapping, (null == e ? void 0 : e.magFilter) || s.LinearFilter, (null == e ? void 0 : e.minFilter) || s.LinearFilter, (null == e ? void 0 : e.anisotropy) || 1, s.LinearSRGBColorSpace);
                    return t.generateMipmaps = (null == e ? void 0 : e.generateMipmaps) !== void 0 && (null == e ? void 0 : e.generateMipmaps), t
                }
                disposeOnDemandRenderer() {
                    this._renderer.setRenderTarget(null), this._rendererIsDisposable && (this._renderer.dispose(), this._renderer.forceContextLoss())
                }
                dispose(e) {
                    this.disposeOnDemandRenderer(), e && this.renderTarget.dispose(), this.material instanceof s.ShaderMaterial && Object.values(this.material.uniforms).forEach(e => {
                        e.value instanceof s.Texture && e.value.dispose()
                    }), Object.values(this.material).forEach(e => {
                        e instanceof s.Texture && e.dispose()
                    }), this.material.dispose(), this._quad.geometry.dispose()
                }
                get width() {
                    return this._width
                }
                set width(e) {
                    this._width = e, this._renderTarget.setSize(this._width, this._height)
                }
                get height() {
                    return this._height
                }
                set height(e) {
                    this._height = e, this._renderTarget.setSize(this._width, this._height)
                }
                get renderer() {
                    return this._renderer
                }
                get renderTarget() {
                    return this._renderTarget
                }
                set renderTarget(e) {
                    this._renderTarget = e, this._width = e.width, this._height = e.height
                }
                get material() {
                    return this._material
                }
                get type() {
                    return this._type
                }
                get colorSpace() {
                    return this._colorSpace
                }
            }
            let en = `
varying vec2 vUv;

void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,
                ei = `
// min half float value
#define HALF_FLOAT_MIN vec3( -65504, -65504, -65504 )
// max half float value
#define HALF_FLOAT_MAX vec3( 65504, 65504, 65504 )

uniform sampler2D sdr;
uniform sampler2D gainMap;
uniform vec3 gamma;
uniform vec3 offsetHdr;
uniform vec3 offsetSdr;
uniform vec3 gainMapMin;
uniform vec3 gainMapMax;
uniform float weightFactor;

varying vec2 vUv;

void main() {
  vec3 rgb = texture2D( sdr, vUv ).rgb;
  vec3 recovery = texture2D( gainMap, vUv ).rgb;
  vec3 logRecovery = pow( recovery, gamma );
  vec3 logBoost = gainMapMin * ( 1.0 - logRecovery ) + gainMapMax * logRecovery;
  vec3 hdrColor = (rgb + offsetSdr) * exp2( logBoost * weightFactor ) - offsetHdr;
  vec3 clampedHdrColor = max( HALF_FLOAT_MIN, min( HALF_FLOAT_MAX, hdrColor ));
  gl_FragColor = vec4( clampedHdrColor , 1.0 );
}
`;
            class ea extends s.ShaderMaterial {
                constructor({
                    gamma: e,
                    offsetHdr: t,
                    offsetSdr: r,
                    gainMapMin: n,
                    gainMapMax: i,
                    maxDisplayBoost: a,
                    hdrCapacityMin: o,
                    hdrCapacityMax: l,
                    sdr: u,
                    gainMap: c
                }) {
                    super({
                        name: "GainMapDecoderMaterial",
                        vertexShader: en,
                        fragmentShader: ei,
                        uniforms: {
                            sdr: {
                                value: u
                            },
                            gainMap: {
                                value: c
                            },
                            gamma: {
                                value: new s.Vector3(1 / e[0], 1 / e[1], 1 / e[2])
                            },
                            offsetHdr: {
                                value: new s.Vector3().fromArray(t)
                            },
                            offsetSdr: {
                                value: new s.Vector3().fromArray(r)
                            },
                            gainMapMin: {
                                value: new s.Vector3().fromArray(n)
                            },
                            gainMapMax: {
                                value: new s.Vector3().fromArray(i)
                            },
                            weightFactor: {
                                value: (Math.log2(a) - o) / (l - o)
                            }
                        },
                        blending: s.NoBlending,
                        depthTest: !1,
                        depthWrite: !1
                    }), this._maxDisplayBoost = a, this._hdrCapacityMin = o, this._hdrCapacityMax = l, this.needsUpdate = !0, this.uniformsNeedUpdate = !0
                }
                get sdr() {
                    return this.uniforms.sdr.value
                }
                set sdr(e) {
                    this.uniforms.sdr.value = e
                }
                get gainMap() {
                    return this.uniforms.gainMap.value
                }
                set gainMap(e) {
                    this.uniforms.gainMap.value = e
                }
                get offsetHdr() {
                    return this.uniforms.offsetHdr.value.toArray()
                }
                set offsetHdr(e) {
                    this.uniforms.offsetHdr.value.fromArray(e)
                }
                get offsetSdr() {
                    return this.uniforms.offsetSdr.value.toArray()
                }
                set offsetSdr(e) {
                    this.uniforms.offsetSdr.value.fromArray(e)
                }
                get gainMapMin() {
                    return this.uniforms.gainMapMin.value.toArray()
                }
                set gainMapMin(e) {
                    this.uniforms.gainMapMin.value.fromArray(e)
                }
                get gainMapMax() {
                    return this.uniforms.gainMapMax.value.toArray()
                }
                set gainMapMax(e) {
                    this.uniforms.gainMapMax.value.fromArray(e)
                }
                get gamma() {
                    let e = this.uniforms.gamma.value;
                    return [1 / e.x, 1 / e.y, 1 / e.z]
                }
                set gamma(e) {
                    let t = this.uniforms.gamma.value;
                    t.x = 1 / e[0], t.y = 1 / e[1], t.z = 1 / e[2]
                }
                get hdrCapacityMin() {
                    return this._hdrCapacityMin
                }
                set hdrCapacityMin(e) {
                    this._hdrCapacityMin = e, this.calculateWeight()
                }
                get hdrCapacityMax() {
                    return this._hdrCapacityMax
                }
                set hdrCapacityMax(e) {
                    this._hdrCapacityMax = e, this.calculateWeight()
                }
                get maxDisplayBoost() {
                    return this._maxDisplayBoost
                }
                set maxDisplayBoost(e) {
                    this._maxDisplayBoost = Math.max(1, Math.min(65504, e)), this.calculateWeight()
                }
                calculateWeight() {
                    let e = (Math.log2(this._maxDisplayBoost) - this._hdrCapacityMin) / (this._hdrCapacityMax - this._hdrCapacityMin);
                    this.uniforms.weightFactor.value = Math.max(0, Math.min(1, e))
                }
            }
            class eo extends Error {}
            class es extends Error {}
            let el = (e, t, r) => {
                    var n;
                    let i;
                    let a = null === (n = e.attributes.getNamedItem(t)) || void 0 === n ? void 0 : n.nodeValue;
                    if (a) i = a;
                    else {
                        let n = e.getElementsByTagName(t)[0];
                        if (n) {
                            let e = n.getElementsByTagName("rdf:li");
                            if (3 === e.length) i = Array.from(e).map(e => e.innerHTML);
                            else throw Error(`Gainmap metadata contains an array of items for ${t} but its length is not 3`)
                        } else {
                            if (r) return r;
                            throw Error(`Can't find ${t} in gainmap metadata`)
                        }
                    }
                    return i
                },
                eu = e => {
                    var t, r;
                    let n;
                    "undefined" != typeof TextDecoder ? n = new TextDecoder().decode(e) : n = e.toString();
                    let i = n.indexOf("<x:xmpmeta"),
                        a = new DOMParser;
                    for (; - 1 !== i;) {
                        let e = n.indexOf("x:xmpmeta>", i);
                        n.slice(i, e + 10);
                        let o = n.slice(i, e + 10);
                        try {
                            let e = a.parseFromString(o, "text/xml").getElementsByTagName("rdf:Description")[0],
                                n = el(e, "hdrgm:GainMapMin", "0"),
                                i = el(e, "hdrgm:GainMapMax"),
                                s = el(e, "hdrgm:Gamma", "1"),
                                l = el(e, "hdrgm:OffsetSDR", "0.015625"),
                                u = el(e, "hdrgm:OffsetHDR", "0.015625"),
                                c = null === (t = e.attributes.getNamedItem("hdrgm:HDRCapacityMin")) || void 0 === t ? void 0 : t.nodeValue;
                            c || (c = "0");
                            let d = null === (r = e.attributes.getNamedItem("hdrgm:HDRCapacityMax")) || void 0 === r ? void 0 : r.nodeValue;
                            if (!d) throw Error("Incomplete gainmap metadata");
                            return {
                                gainMapMin: Array.isArray(n) ? n.map(e => parseFloat(e)) : [parseFloat(n), parseFloat(n), parseFloat(n)],
                                gainMapMax: Array.isArray(i) ? i.map(e => parseFloat(e)) : [parseFloat(i), parseFloat(i), parseFloat(i)],
                                gamma: Array.isArray(s) ? s.map(e => parseFloat(e)) : [parseFloat(s), parseFloat(s), parseFloat(s)],
                                offsetSdr: Array.isArray(l) ? l.map(e => parseFloat(e)) : [parseFloat(l), parseFloat(l), parseFloat(l)],
                                offsetHdr: Array.isArray(u) ? u.map(e => parseFloat(e)) : [parseFloat(u), parseFloat(u), parseFloat(u)],
                                hdrCapacityMin: parseFloat(c),
                                hdrCapacityMax: parseFloat(d)
                            }
                        } catch (e) {}
                        i = n.indexOf("<x:xmpmeta", e)
                    }
                };
            class ec {
                constructor(e) {
                    this.options = {
                        debug: !!e && void 0 !== e.debug && e.debug,
                        extractFII: !e || void 0 === e.extractFII || e.extractFII,
                        extractNonFII: !e || void 0 === e.extractNonFII || e.extractNonFII
                    }
                }
                extract(e) {
                    return new Promise((t, r) => {
                        let n;
                        let i = this.options.debug,
                            a = new DataView(e.buffer);
                        if (65496 !== a.getUint16(0)) {
                            r(Error("Not a valid jpeg"));
                            return
                        }
                        let o = a.byteLength,
                            s = 2,
                            l = 0;
                        for (; s < o;) {
                            if (++l > 250) {
                                r(Error(`Found no marker after ${l} loops 😵`));
                                return
                            }
                            if (255 !== a.getUint8(s)) {
                                r(Error(`Not a valid marker at offset 0x${s.toString(16)}, found: 0x${a.getUint8(s).toString(16)}`));
                                return
                            }
                            if (n = a.getUint8(s + 1), i && console.log(`Marker: ${n.toString(16)}`), 226 === n) {
                                i && console.log("Found APP2 marker (0xffe2)");
                                let e = s + 4;
                                if (1297106432 === a.getUint32(e)) {
                                    let n;
                                    let i = e + 4;
                                    if (18761 === a.getUint16(i)) n = !1;
                                    else if (19789 === a.getUint16(i)) n = !0;
                                    else {
                                        r(Error("No valid endianness marker found in TIFF header"));
                                        return
                                    }
                                    if (42 !== a.getUint16(i + 2, !n)) {
                                        r(Error("Not valid TIFF data! (no 0x002A marker)"));
                                        return
                                    }
                                    let o = a.getUint32(i + 4, !n);
                                    if (o < 8) {
                                        r(Error("Not valid TIFF data! (First offset less than 8)"));
                                        return
                                    }
                                    let s = i + o,
                                        l = a.getUint16(s, !n),
                                        u = s + 2,
                                        c = 0;
                                    for (let e = u; e < u + 12 * l; e += 12) 45057 === a.getUint16(e, !n) && (c = a.getUint32(e + 8, !n));
                                    let d = s + 2 + 12 * l + 4,
                                        f = [];
                                    for (let e = d; e < d + 16 * c; e += 16) {
                                        let t = {
                                            MPType: a.getUint32(e, !n),
                                            size: a.getUint32(e + 4, !n),
                                            dataOffset: a.getUint32(e + 8, !n),
                                            dependantImages: a.getUint32(e + 12, !n),
                                            start: -1,
                                            end: -1,
                                            isFII: !1
                                        };
                                        t.dataOffset ? (t.start = i + t.dataOffset, t.isFII = !1) : (t.start = 0, t.isFII = !0), t.end = t.start + t.size, f.push(t)
                                    }
                                    if (this.options.extractNonFII && f.length) {
                                        let e = new Blob([a]),
                                            r = [];
                                        for (let t of f) {
                                            if (t.isFII && !this.options.extractFII) continue;
                                            let n = e.slice(t.start, t.end + 1, "image/jpeg");
                                            r.push(n)
                                        }
                                        t(r)
                                    }
                                }
                            }
                            s += 2 + a.getUint16(s + 2)
                        }
                    })
                }
            }
            let ed = async e => {
                    let t = eu(e);
                    if (!t) throw new es("Gain map XMP metadata not found");
                    let r = new ec({
                            extractFII: !0,
                            extractNonFII: !0
                        }),
                        n = await r.extract(e);
                    if (2 !== n.length) throw new eo("Gain map recovery image not found");
                    return {
                        sdr: new Uint8Array(await n[0].arrayBuffer()),
                        gainMap: new Uint8Array(await n[1].arrayBuffer()),
                        metadata: t
                    }
                },
                ef = e => new Promise((t, r) => {
                    let n = document.createElement("img");
                    n.onload = () => {
                        t(n)
                    }, n.onerror = e => {
                        r(e)
                    }, n.src = URL.createObjectURL(e)
                });
            class eh extends s.Loader {
                constructor(e, t) {
                    super(t), e && (this._renderer = e), this._internalLoadingManager = new s.LoadingManager
                }
                setRenderer(e) {
                    return this._renderer = e, this
                }
                setRenderTargetOptions(e) {
                    return this._renderTargetOptions = e, this
                }
                prepareQuadRenderer() {
                    this._renderer || console.warn("WARNING: An existing WebGL Renderer was not passed to this Loader constructor or in setRenderer, the result of this Loader will need to be converted to a Data Texture with toDataTexture() before you can use it in your renderer.");
                    let e = new ea({
                        gainMapMax: [1, 1, 1],
                        gainMapMin: [0, 0, 0],
                        gamma: [1, 1, 1],
                        offsetHdr: [1, 1, 1],
                        offsetSdr: [1, 1, 1],
                        hdrCapacityMax: 1,
                        hdrCapacityMin: 0,
                        maxDisplayBoost: 1,
                        gainMap: new s.Texture,
                        sdr: new s.Texture
                    });
                    return new er({
                        width: 16,
                        height: 16,
                        type: s.HalfFloatType,
                        colorSpace: s.LinearSRGBColorSpace,
                        material: e,
                        renderer: this._renderer,
                        renderTargetOptions: this._renderTargetOptions
                    })
                }
                async render(e, t, r, n) {
                    let i, a;
                    let o = n ? new Blob([n], {
                            type: "image/jpeg"
                        }) : void 0,
                        l = new Blob([r], {
                            type: "image/jpeg"
                        }),
                        u = !1;
                    if ("undefined" == typeof createImageBitmap) {
                        let e = await Promise.all([o ? ef(o) : Promise.resolve(void 0), ef(l)]);
                        a = e[0], i = e[1], u = !0
                    } else {
                        let e = await Promise.all([o ? createImageBitmap(o, {
                            imageOrientation: "flipY"
                        }) : Promise.resolve(void 0), createImageBitmap(l, {
                            imageOrientation: "flipY"
                        })]);
                        a = e[0], i = e[1]
                    }
                    let c = new s.Texture(a || new ImageData(2, 2), s.UVMapping, s.ClampToEdgeWrapping, s.ClampToEdgeWrapping, s.LinearFilter, s.LinearMipMapLinearFilter, s.RGBAFormat, s.UnsignedByteType, 1, s.LinearSRGBColorSpace);
                    c.flipY = u, c.needsUpdate = !0;
                    let d = new s.Texture(i, s.UVMapping, s.ClampToEdgeWrapping, s.ClampToEdgeWrapping, s.LinearFilter, s.LinearMipMapLinearFilter, s.RGBAFormat, s.UnsignedByteType, 1, s.SRGBColorSpace);
                    d.flipY = u, d.needsUpdate = !0, e.width = i.width, e.height = i.height, e.material.gainMap = c, e.material.sdr = d, e.material.gainMapMin = t.gainMapMin, e.material.gainMapMax = t.gainMapMax, e.material.offsetHdr = t.offsetHdr, e.material.offsetSdr = t.offsetSdr, e.material.gamma = t.gamma, e.material.hdrCapacityMin = t.hdrCapacityMin, e.material.hdrCapacityMax = t.hdrCapacityMax, e.material.maxDisplayBoost = Math.pow(2, t.hdrCapacityMax), e.material.needsUpdate = !0, e.render()
                }
            }
            class ep extends eh {
                load([e, t, r], n, i, a) {
                    let o, l, u;
                    let c = this.prepareQuadRenderer(),
                        d = async () => {
                            if (o && l && u) {
                                try {
                                    await this.render(c, u, o, l)
                                } catch (n) {
                                    this.manager.itemError(e), this.manager.itemError(t), this.manager.itemError(r), "function" == typeof a && a(n), c.disposeOnDemandRenderer();
                                    return
                                }
                                "function" == typeof n && n(c), this.manager.itemEnd(e), this.manager.itemEnd(t), this.manager.itemEnd(r), c.disposeOnDemandRenderer()
                            }
                        },
                        f = !0,
                        h = 0,
                        p = 0,
                        m = !0,
                        g = 0,
                        A = 0,
                        v = !0,
                        y = 0,
                        C = 0,
                        B = () => {
                            "function" == typeof i && i(new ProgressEvent("progress", {
                                lengthComputable: f && m && v,
                                loaded: p + A + C,
                                total: h + g + y
                            }))
                        };
                    this.manager.itemStart(e), this.manager.itemStart(t), this.manager.itemStart(r);
                    let _ = new s.FileLoader(this._internalLoadingManager);
                    _.setResponseType("arraybuffer"), _.setRequestHeader(this.requestHeader), _.setPath(this.path), _.setWithCredentials(this.withCredentials), _.load(e, async e => {
                        if ("string" == typeof e) throw Error("Invalid sdr buffer");
                        o = e, await d()
                    }, e => {
                        f = e.lengthComputable, p = e.loaded, h = e.total, B()
                    }, t => {
                        this.manager.itemError(e), "function" == typeof a && a(t)
                    });
                    let b = new s.FileLoader(this._internalLoadingManager);
                    b.setResponseType("arraybuffer"), b.setRequestHeader(this.requestHeader), b.setPath(this.path), b.setWithCredentials(this.withCredentials), b.load(t, async e => {
                        if ("string" == typeof e) throw Error("Invalid gainmap buffer");
                        l = e, await d()
                    }, e => {
                        m = e.lengthComputable, A = e.loaded, g = e.total, B()
                    }, e => {
                        this.manager.itemError(t), "function" == typeof a && a(e)
                    });
                    let E = new s.FileLoader(this._internalLoadingManager);
                    return E.setRequestHeader(this.requestHeader), E.setPath(this.path), E.setWithCredentials(this.withCredentials), E.load(r, async e => {
                        if ("string" != typeof e) throw Error("Invalid metadata string");
                        u = JSON.parse(e), await d()
                    }, e => {
                        v = e.lengthComputable, C = e.loaded, y = e.total, B()
                    }, e => {
                        this.manager.itemError(r), "function" == typeof a && a(e)
                    }), c
                }
            }
            class em extends eh {
                load(e, t, r, n) {
                    let i = this.prepareQuadRenderer(),
                        a = new s.FileLoader(this._internalLoadingManager);
                    return a.setResponseType("arraybuffer"), a.setRequestHeader(this.requestHeader), a.setPath(this.path), a.setWithCredentials(this.withCredentials), this.manager.itemStart(e), a.load(e, async r => {
                        let a, o, s;
                        if ("string" == typeof r) throw Error("Invalid buffer, received [string], was expecting [ArrayBuffer]");
                        let l = new Uint8Array(r);
                        try {
                            let e = await ed(l);
                            a = e.sdr, o = e.gainMap, s = e.metadata
                        } catch (t) {
                            if (t instanceof es || t instanceof eo) console.warn(`Failure to reconstruct an HDR image from ${e}: Gain map metadata not found in the file, HDRJPGLoader will render the SDR jpeg`), s = {
                                gainMapMin: [0, 0, 0],
                                gainMapMax: [1, 1, 1],
                                gamma: [1, 1, 1],
                                hdrCapacityMin: 0,
                                hdrCapacityMax: 1,
                                offsetHdr: [0, 0, 0],
                                offsetSdr: [0, 0, 0]
                            }, a = l;
                            else throw t
                        }
                        try {
                            await this.render(i, s, a, o)
                        } catch (t) {
                            this.manager.itemError(e), "function" == typeof n && n(t), i.disposeOnDemandRenderer();
                            return
                        }
                        "function" == typeof t && t(i), this.manager.itemEnd(e), i.disposeOnDemandRenderer()
                    }, r, t => {
                        this.manager.itemError(e), "function" == typeof n && n(t)
                    }), i
                }
            }
            let eg = {
                apartment: "lebombo_1k.hdr",
                city: "potsdamer_platz_1k.hdr",
                dawn: "kiara_1_dawn_1k.hdr",
                forest: "forest_slope_1k.hdr",
                lobby: "st_fagans_interior_1k.hdr",
                night: "dikhololo_night_1k.hdr",
                park: "rooitou_park_1k.hdr",
                studio: "studio_small_03_1k.hdr",
                sunset: "venice_sunset_1k.hdr",
                warehouse: "empty_warehouse_01_1k.hdr"
            };
            var eA = r(86600);
            let ev = e => Array.isArray(e);

            function ey({
                files: e = ["/px.png", "/nx.png", "/py.png", "/ny.png", "/pz.png", "/nz.png"],
                path: t = "",
                preset: r,
                encoding: n,
                extensions: i
            } = {}) {
                var a, l;
                let u;
                let d = null,
                    f = !1;
                if (r) {
                    if (!(r in eg)) throw Error("Preset must be one of: " + Object.keys(eg).join(", "));
                    e = eg[r], t = "https://raw.githack.com/pmndrs/drei-assets/456060a26bbeb8fdf79326f224b6d99b8bcce736/hdri/"
                }
                let h = ev(e) && 6 === e.length,
                    p = ev(e) && 3 === e.length && e.some(e => e.endsWith("json")),
                    m = ev(e) ? e[0] : e;
                if (f = ev(e), !(d = "cube" === (u = h ? "cube" : p ? "webp" : m.startsWith("data:application/exr") ? "exr" : m.startsWith("data:application/hdr") ? "hdr" : m.startsWith("data:image/jpeg") ? "jpg" : null == (a = m.split(".").pop()) || null == (a = a.split("?")) || null == (a = a.shift()) ? void 0 : a.toLowerCase()) ? s.CubeTextureLoader : "hdr" === u ? c : "exr" === u ? $ : "jpg" === u || "jpeg" === u ? em : "webp" === u ? ep : null)) throw Error("useEnvironment: Unrecognized file extension: " + e);
                let g = (0, o.A)(e => e.gl),
                    A = (0, o.F)(d, f ? [e] : e, e => {
                        ("webp" === u || "jpg" === u || "jpeg" === u) && e.setRenderer(g), null == e.setPath || e.setPath(t), i && i(e)
                    }),
                    v = f ? A[0] : A;
                return ("jpg" === u || "jpeg" === u || "webp" === u) && (v = null == (l = v.renderTarget) ? void 0 : l.texture), v.mapping = h ? s.CubeReflectionMapping : s.EquirectangularReflectionMapping, "colorSpace" in v ? v.colorSpace = (null != n ? n : h) ? "srgb" : "srgb-linear" : v.encoding = (null != n ? n : h) ? eA.kn : eA.rn, v
            }
            let eC = e => e.current && e.current.isScene,
                eB = e => eC(e) ? e.current : e;

            function e_(e, t, r, n, i = {}) {
                var a, s, l, u, c;
                i = {
                    backgroundBlurriness: null !== (a = i.blur) && void 0 !== a ? a : 0,
                    backgroundIntensity: 1,
                    backgroundRotation: [0, 0, 0],
                    environmentIntensity: 1,
                    environmentRotation: [0, 0, 0],
                    ...i
                };
                let d = eB(t || r),
                    f = d.background,
                    h = d.environment,
                    p = {
                        backgroundBlurriness: d.backgroundBlurriness,
                        backgroundIntensity: d.backgroundIntensity,
                        backgroundRotation: null !== (s = null == (l = d.backgroundRotation) || null == l.clone ? void 0 : l.clone()) && void 0 !== s ? s : [0, 0, 0],
                        environmentIntensity: d.environmentIntensity,
                        environmentRotation: null !== (u = null == (c = d.environmentRotation) || null == c.clone ? void 0 : c.clone()) && void 0 !== u ? u : [0, 0, 0]
                    };
                return "only" !== e && (d.environment = n), e && (d.background = n), (0, o.j)(d, i), () => {
                    "only" !== e && (d.environment = h), e && (d.background = f), (0, o.j)(d, p)
                }
            }

            function eb({
                scene: e,
                background: t = !1,
                map: r,
                ...n
            }) {
                let i = (0, o.A)(e => e.scene);
                return a.useLayoutEffect(() => {
                    if (r) return e_(t, e, i, r, n)
                }), null
            }

            function eE({
                background: e = !1,
                scene: t,
                blur: r,
                backgroundBlurriness: n,
                backgroundIntensity: i,
                backgroundRotation: s,
                environmentIntensity: l,
                environmentRotation: u,
                ...c
            }) {
                let d = ey(c),
                    f = (0, o.A)(e => e.scene);
                return a.useLayoutEffect(() => e_(e, t, f, d, {
                    blur: r,
                    backgroundBlurriness: n,
                    backgroundIntensity: i,
                    backgroundRotation: s,
                    environmentIntensity: l,
                    environmentRotation: u
                })), null
            }

            function ew({
                children: e,
                near: t = 1,
                far: r = 1e3,
                resolution: n = 256,
                frames: i = 1,
                map: l,
                background: u = !1,
                blur: c,
                backgroundBlurriness: d,
                backgroundIntensity: f,
                backgroundRotation: h,
                environmentIntensity: p,
                environmentRotation: m,
                scene: g,
                files: A,
                path: v,
                preset: y,
                extensions: C
            }) {
                let B = (0, o.A)(e => e.gl),
                    _ = (0, o.A)(e => e.scene),
                    b = a.useRef(null),
                    [E] = a.useState(() => new s.Scene),
                    w = a.useMemo(() => {
                        let e = new s.WebGLCubeRenderTarget(n);
                        return e.texture.type = s.HalfFloatType, e
                    }, [n]);
                a.useLayoutEffect(() => (1 === i && b.current.update(B, E), e_(u, g, _, w.texture, {
                    blur: c,
                    backgroundBlurriness: d,
                    backgroundIntensity: f,
                    backgroundRotation: h,
                    environmentIntensity: p,
                    environmentRotation: m
                })), [e, E, w.texture, g, _, u, i, B]);
                let M = 1;
                return (0, o.C)(() => {
                    (i === 1 / 0 || M < i) && (b.current.update(B, E), M++)
                }), a.createElement(a.Fragment, null, (0, o.g)(a.createElement(a.Fragment, null, e, a.createElement("cubeCamera", {
                    ref: b,
                    args: [t, r, w]
                }), A || y ? a.createElement(eE, {
                    background: !0,
                    files: A,
                    preset: y,
                    path: v,
                    extensions: C
                }) : l ? a.createElement(eb, {
                    background: !0,
                    map: l,
                    extensions: C
                }) : null), E))
            }

            function eM(e) {
                var t, r, n, s;
                let l = ey(e),
                    c = e.map || l;
                a.useMemo(() => (0, o.e)({
                    GroundProjectedEnvImpl: u
                }), []);
                let d = a.useMemo(() => [c], [c]),
                    f = null == (t = e.ground) ? void 0 : t.height,
                    h = null == (r = e.ground) ? void 0 : r.radius,
                    p = null !== (n = null == (s = e.ground) ? void 0 : s.scale) && void 0 !== n ? n : 1e3;
                return a.createElement(a.Fragment, null, a.createElement(eb, (0, i.Z)({}, e, {
                    map: c
                })), a.createElement("groundProjectedEnvImpl", {
                    args: d,
                    scale: p,
                    height: f,
                    radius: h
                }))
            }

            function eT(e) {
                return e.ground ? a.createElement(eM, e) : e.map ? a.createElement(eb, e) : e.children ? a.createElement(ew, e) : a.createElement(eE, e)
            }
        },
        97547: function(e, t, r) {
            "use strict";
            r.d(t, {
                K4: function() {
                    return _
                },
                EJ: function() {
                    return b
                }
            });
            var n = r(87462),
                i = r(99477),
                a = r(67294),
                o = r(19390),
                s = r(45697),
                l = r.n(s);
            l().func.isRequired, l().arrayOf(l().oneOfType([l().element, l().func])).isRequired;
            var u = r(86600);
            let c = new i.Matrix4,
                d = new i.Matrix4,
                f = [],
                h = new i.Mesh;
            class p extends i.Group {
                constructor() {
                    super(), this.color = new i.Color("white"), this.instance = {
                        current: void 0
                    }, this.instanceKey = {
                        current: void 0
                    }
                }
                get geometry() {
                    var e;
                    return null == (e = this.instance.current) ? void 0 : e.geometry
                }
                raycast(e, t) {
                    let r = this.instance.current;
                    if (!r || !r.geometry || !r.material) return;
                    h.geometry = r.geometry;
                    let n = r.matrixWorld,
                        a = r.userData.instances.indexOf(this.instanceKey);
                    if (-1 !== a && !(a > r.count)) {
                        r.getMatrixAt(a, c), d.multiplyMatrices(n, c), h.matrixWorld = d, r.material instanceof i.Material ? h.material.side = r.material.side : h.material.side = r.material[0].side, h.raycast(e, f);
                        for (let e = 0, r = f.length; e < r; e++) {
                            let r = f[e];
                            r.instanceId = a, r.object = this, t.push(r)
                        }
                        f.length = 0
                    }
                }
            }
            let m = a.createContext(null),
                g = new i.Matrix4,
                A = new i.Matrix4,
                v = new i.Matrix4,
                y = new i.Vector3,
                C = new i.Quaternion,
                B = new i.Vector3,
                _ = a.forwardRef(({
                    context: e,
                    children: t,
                    ...r
                }, i) => {
                    a.useMemo(() => (0, o.e)({
                        PositionMesh: p
                    }), []);
                    let s = a.useRef();
                    a.useImperativeHandle(i, () => s.current, []);
                    let {
                        subscribe: l,
                        getParent: u
                    } = a.useContext(e || m);
                    return a.useLayoutEffect(() => l(s), []), a.createElement("positionMesh", (0, n.Z)({
                        instance: u(),
                        instanceKey: s,
                        ref: s
                    }, r), t)
                }),
                b = a.forwardRef(({
                    children: e,
                    range: t,
                    limit: r = 1e3,
                    frames: s = 1 / 0,
                    ...l
                }, c) => {
                    let [{
                        context: d,
                        instance: f
                    }] = a.useState(() => {
                        let e = a.createContext(null);
                        return {
                            context: e,
                            instance: a.forwardRef((t, r) => a.createElement(_, (0, n.Z)({
                                context: e
                            }, t, {
                                ref: r
                            })))
                        }
                    }), h = a.useRef(null);
                    a.useImperativeHandle(c, () => h.current, []);
                    let [p, b] = a.useState([]), [
                        [E, w]
                    ] = a.useState(() => {
                        let e = new Float32Array(16 * r);
                        for (let t = 0; t < r; t++) v.identity().toArray(e, 16 * t);
                        return [e, new Float32Array([...Array(3 * r)].map(() => 1))]
                    });
                    a.useEffect(() => {
                        h.current.instanceMatrix.needsUpdate = !0
                    });
                    let M = 0,
                        T = 0;
                    (0, o.C)(() => {
                        if (s === 1 / 0 || M < s) {
                            h.current.updateMatrix(), h.current.updateMatrixWorld(), g.copy(h.current.matrixWorld).invert(), T = Math.min(r, void 0 !== t ? t : r, p.length), h.current.count = T, (0, u.Jj)(h.current.instanceMatrix, {
                                offset: 0,
                                count: 16 * T
                            }), (0, u.Jj)(h.current.instanceColor, {
                                offset: 0,
                                count: 3 * T
                            });
                            for (let e = 0; e < p.length; e++) {
                                let t = p[e].current;
                                t.matrixWorld.decompose(y, C, B), A.compose(y, C, B).premultiply(g), A.toArray(E, 16 * e), h.current.instanceMatrix.needsUpdate = !0, t.color.toArray(w, 3 * e), h.current.instanceColor.needsUpdate = !0
                            }
                            M++
                        }
                    });
                    let x = a.useMemo(() => ({
                        getParent: () => h,
                        subscribe: e => (b(t => [...t, e]), () => b(t => t.filter(t => t.current !== e.current)))
                    }), []);
                    return a.createElement("instancedMesh", (0, n.Z)({
                        userData: {
                            instances: p
                        },
                        matrixAutoUpdate: !1,
                        ref: h,
                        args: [null, null, 0],
                        raycast: () => null
                    }, l), a.createElement("instancedBufferAttribute", {
                        attach: "instanceMatrix",
                        count: E.length / 16,
                        array: E,
                        itemSize: 16,
                        usage: i.DynamicDrawUsage
                    }), a.createElement("instancedBufferAttribute", {
                        attach: "instanceColor",
                        count: w.length / 3,
                        array: w,
                        itemSize: 3,
                        usage: i.DynamicDrawUsage
                    }), "function" == typeof e ? a.createElement(d.Provider, {
                        value: x
                    }, e(f)) : a.createElement(m.Provider, {
                        value: x
                    }, e))
                })
        },
        52314: function(e, t, r) {
            "use strict";
            r.d(t, {
                D: function() {
                    return s
                }
            });
            var n = r(87462),
                i = r(19390),
                a = r(67294),
                o = r(99477);
            let s = a.forwardRef(({
                args: e,
                map: t,
                toneMapped: r = !1,
                color: s = "white",
                form: l = "rect",
                intensity: u = 1,
                scale: c = 1,
                target: d,
                children: f,
                ...h
            }, p) => {
                let m = a.useRef(null);
                return a.useImperativeHandle(p, () => m.current, []), a.useLayoutEffect(() => {
                    f || h.material || ((0, i.j)(m.current.material, {
                        color: s
                    }), m.current.material.color.multiplyScalar(u))
                }, [s, u, f, h.material]), a.useLayoutEffect(() => {
                    d && m.current.lookAt(Array.isArray(d) ? new o.Vector3(...d) : d)
                }, [d]), c = Array.isArray(c) && 2 === c.length ? [c[0], c[1], 1] : c, a.createElement("mesh", (0, n.Z)({
                    ref: m,
                    scale: c
                }, h), "circle" === l ? a.createElement("ringGeometry", {
                    args: [0, 1, 64]
                }) : "ring" === l ? a.createElement("ringGeometry", {
                    args: [.5, 1, 64]
                }) : "rect" === l ? a.createElement("planeGeometry", null) : a.createElement(l, {
                    args: e
                }), f || (h.material ? null : a.createElement("meshBasicMaterial", {
                    toneMapped: r,
                    map: t,
                    side: o.DoubleSide
                })))
            })
        },
        70587: function(e, t, r) {
            "use strict";
            r.d(t, {
                q: function() {
                    return o
                }
            });
            var n = r(99477),
                i = r(67294),
                a = r(19390);

            function o({
                all: e,
                scene: t,
                camera: r
            }) {
                let o = (0, a.A)(({
                        gl: e
                    }) => e),
                    s = (0, a.A)(({
                        camera: e
                    }) => e),
                    l = (0, a.A)(({
                        scene: e
                    }) => e);
                return i.useLayoutEffect(() => {
                    let i = [];
                    e && (t || l).traverse(e => {
                        !1 === e.visible && (i.push(e), e.visible = !0)
                    }), o.compile(t || l, r || s);
                    let a = new n.WebGLCubeRenderTarget(128);
                    new n.CubeCamera(.01, 1e5, a).update(o, t || l), a.dispose(), i.forEach(e => e.visible = !1)
                }, []), null
            }
        },
        4950: function(e, t, r) {
            "use strict";
            r.d(t, {
                g: function() {
                    return i
                }
            });
            var n = r(99477);

            function i(e, t, r, i) {
                let a = class extends n.ShaderMaterial {
                    constructor(a = {}) {
                        let o = Object.entries(e);
                        super({
                            uniforms: o.reduce((e, [t, r]) => {
                                let i = n.UniformsUtils.clone({
                                    [t]: {
                                        value: r
                                    }
                                });
                                return { ...e,
                                    ...i
                                }
                            }, {}),
                            vertexShader: t,
                            fragmentShader: r
                        }), this.key = "", o.forEach(([e]) => Object.defineProperty(this, e, {
                            get: () => this.uniforms[e].value,
                            set: t => this.uniforms[e].value = t
                        })), Object.assign(this, a), i && i(this)
                    }
                };
                return a.key = n.MathUtils.generateUUID(), a
            }
        },
        5964: function(e, t, r) {
            "use strict";
            r.d(t, {
                A: function() {
                    return l
                }
            });
            var n = r(67294),
                i = r(99477),
                a = r(19390);
            let o = ({
                focus: e = 0,
                size: t = 25,
                samples: r = 10
            } = {}) => `
#define PENUMBRA_FILTER_SIZE float(${t})
#define RGB_NOISE_FUNCTION(uv) (randRGB(uv))
vec3 randRGB(vec2 uv) {
  return vec3(
    fract(sin(dot(uv, vec2(12.75613, 38.12123))) * 13234.76575),
    fract(sin(dot(uv, vec2(19.45531, 58.46547))) * 43678.23431),
    fract(sin(dot(uv, vec2(23.67817, 78.23121))) * 93567.23423)
  );
}

vec3 lowPassRandRGB(vec2 uv) {
  // 3x3 convolution (average)
  // can be implemented as separable with an extra buffer for a total of 6 samples instead of 9
  vec3 result = vec3(0);
  result += RGB_NOISE_FUNCTION(uv + vec2(-1.0, -1.0));
  result += RGB_NOISE_FUNCTION(uv + vec2(-1.0,  0.0));
  result += RGB_NOISE_FUNCTION(uv + vec2(-1.0, +1.0));
  result += RGB_NOISE_FUNCTION(uv + vec2( 0.0, -1.0));
  result += RGB_NOISE_FUNCTION(uv + vec2( 0.0,  0.0));
  result += RGB_NOISE_FUNCTION(uv + vec2( 0.0, +1.0));
  result += RGB_NOISE_FUNCTION(uv + vec2(+1.0, -1.0));
  result += RGB_NOISE_FUNCTION(uv + vec2(+1.0,  0.0));
  result += RGB_NOISE_FUNCTION(uv + vec2(+1.0, +1.0));
  result *= 0.111111111; // 1.0 / 9.0
  return result;
}
vec3 highPassRandRGB(vec2 uv) {
  // by subtracting the low-pass signal from the original signal, we're being left with the high-pass signal
  // hp(x) = x - lp(x)
  return RGB_NOISE_FUNCTION(uv) - lowPassRandRGB(uv) + 0.5;
}


vec2 vogelDiskSample(int sampleIndex, int sampleCount, float angle) {
  const float goldenAngle = 2.399963f; // radians
  float r = sqrt(float(sampleIndex) + 0.5f) / sqrt(float(sampleCount));
  float theta = float(sampleIndex) * goldenAngle + angle;
  float sine = sin(theta);
  float cosine = cos(theta);
  return vec2(cosine, sine) * r;
}
float penumbraSize( const in float zReceiver, const in float zBlocker ) { // Parallel plane estimation
  return (zReceiver - zBlocker) / zBlocker;
}
float findBlocker(sampler2D shadowMap, vec2 uv, float compare, float angle) {
  float texelSize = 1.0 / float(textureSize(shadowMap, 0).x);
  float blockerDepthSum = float(${e});
  float blockers = 0.0;

  int j = 0;
  vec2 offset = vec2(0.);
  float depth = 0.;

  #pragma unroll_loop_start
  for(int i = 0; i < ${r}; i ++) {
    offset = (vogelDiskSample(j, ${r}, angle) * texelSize) * 2.0 * PENUMBRA_FILTER_SIZE;
    depth = unpackRGBAToDepth( texture2D( shadowMap, uv + offset));
    if (depth < compare) {
      blockerDepthSum += depth;
      blockers++;
    }
    j++;
  }
  #pragma unroll_loop_end

  if (blockers > 0.0) {
    return blockerDepthSum / blockers;
  }
  return -1.0;
}

        
float vogelFilter(sampler2D shadowMap, vec2 uv, float zReceiver, float filterRadius, float angle) {
  float texelSize = 1.0 / float(textureSize(shadowMap, 0).x);
  float shadow = 0.0f;
  int j = 0;
  vec2 vogelSample = vec2(0.0);
  vec2 offset = vec2(0.0);
  #pragma unroll_loop_start
  for (int i = 0; i < ${r}; i++) {
    vogelSample = vogelDiskSample(j, ${r}, angle) * texelSize;
    offset = vogelSample * (1.0 + filterRadius * float(${t}));
    shadow += step( zReceiver, unpackRGBAToDepth( texture2D( shadowMap, uv + offset ) ) );
    j++;
  }
  #pragma unroll_loop_end
  return shadow * 1.0 / ${r}.0;
}

float PCSS (sampler2D shadowMap, vec4 coords) {
  vec2 uv = coords.xy;
  float zReceiver = coords.z; // Assumed to be eye-space z in this code
  float angle = highPassRandRGB(gl_FragCoord.xy).r * PI2;
  float avgBlockerDepth = findBlocker(shadowMap, uv, zReceiver, angle);
  if (avgBlockerDepth == -1.0) {
    return 1.0;
  }
  float penumbraRatio = penumbraSize(zReceiver, avgBlockerDepth);
  return vogelFilter(shadowMap, uv, zReceiver, 1.25 * penumbraRatio, angle);
}`;

            function s(e, t, r) {
                t.traverse(t => {
                    t.material && (e.properties.remove(t.material), null == t.material.dispose || t.material.dispose())
                }), e.info.programs.length = 0, e.compile(t, r)
            }

            function l({
                focus: e = 0,
                samples: t = 10,
                size: r = 25
            }) {
                let l = (0, a.A)(e => e.gl),
                    u = (0, a.A)(e => e.scene),
                    c = (0, a.A)(e => e.camera);
                return n.useEffect(() => {
                    let n = i.ShaderChunk.shadowmap_pars_fragment;
                    return i.ShaderChunk.shadowmap_pars_fragment = i.ShaderChunk.shadowmap_pars_fragment.replace("#ifdef USE_SHADOWMAP", "#ifdef USE_SHADOWMAP\n" + o({
                        size: r,
                        samples: t,
                        focus: e
                    })).replace("#if defined( SHADOWMAP_TYPE_PCF )", "\nreturn PCSS(shadowMap, shadowCoord);\n#if defined( SHADOWMAP_TYPE_PCF )"), s(l, u, c), () => {
                        i.ShaderChunk.shadowmap_pars_fragment = n, s(l, u, c)
                    }
                }, [e, r, t]), null
            }
        },
        90319: function(e, t, r) {
            "use strict";
            r.d(t, {
                R: function() {
                    return o
                }
            });
            var n = r(67294),
                i = r(99477),
                a = r(19390);

            function o(e, t, r) {
                let o = (0, a.A)(e => e.size),
                    s = (0, a.A)(e => e.viewport),
                    l = "number" == typeof e ? e : o.width * s.dpr,
                    u = "number" == typeof t ? t : o.height * s.dpr,
                    {
                        samples: c = 0,
                        depth: d,
                        ...f
                    } = ("number" == typeof e ? r : e) || {},
                    h = n.useMemo(() => {
                        let e = new i.WebGLRenderTarget(l, u, {
                            minFilter: i.LinearFilter,
                            magFilter: i.LinearFilter,
                            type: i.HalfFloatType,
                            ...f
                        });
                        return d && (e.depthTexture = new i.DepthTexture(l, u, i.FloatType)), e.samples = c, e
                    }, []);
                return n.useLayoutEffect(() => {
                    h.setSize(l, u), c && (h.samples = c)
                }, [c, h, l, u]), n.useEffect(() => () => h.dispose(), []), h
            }
        },
        53840: function(e, t, r) {
            "use strict";
            let n;
            r.d(t, {
                L: function() {
                    return eu
                }
            });
            var i = r(99477);
            let a = new WeakMap;
            class o extends i.Loader {
                constructor(e) {
                    super(e), this.decoderPath = "", this.decoderConfig = {}, this.decoderBinary = null, this.decoderPending = null, this.workerLimit = 4, this.workerPool = [], this.workerNextTaskID = 1, this.workerSourceURL = "", this.defaultAttributeIDs = {
                        position: "POSITION",
                        normal: "NORMAL",
                        color: "COLOR",
                        uv: "TEX_COORD"
                    }, this.defaultAttributeTypes = {
                        position: "Float32Array",
                        normal: "Float32Array",
                        color: "Float32Array",
                        uv: "Float32Array"
                    }
                }
                setDecoderPath(e) {
                    return this.decoderPath = e, this
                }
                setDecoderConfig(e) {
                    return this.decoderConfig = e, this
                }
                setWorkerLimit(e) {
                    return this.workerLimit = e, this
                }
                load(e, t, r, n) {
                    let a = new i.FileLoader(this.manager);
                    a.setPath(this.path), a.setResponseType("arraybuffer"), a.setRequestHeader(this.requestHeader), a.setWithCredentials(this.withCredentials), a.load(e, e => {
                        let r = {
                            attributeIDs: this.defaultAttributeIDs,
                            attributeTypes: this.defaultAttributeTypes,
                            useUniqueIDs: !1
                        };
                        this.decodeGeometry(e, r).then(t).catch(n)
                    }, r, n)
                }
                decodeDracoFile(e, t, r, n) {
                    let i = {
                        attributeIDs: r || this.defaultAttributeIDs,
                        attributeTypes: n || this.defaultAttributeTypes,
                        useUniqueIDs: !!r
                    };
                    this.decodeGeometry(e, i).then(t)
                }
                decodeGeometry(e, t) {
                    let r;
                    for (let e in t.attributeTypes) {
                        let r = t.attributeTypes[e];
                        void 0 !== r.BYTES_PER_ELEMENT && (t.attributeTypes[e] = r.name)
                    }
                    let n = JSON.stringify(t);
                    if (a.has(e)) {
                        let t = a.get(e);
                        if (t.key === n) return t.promise;
                        if (0 === e.byteLength) throw Error("THREE.DRACOLoader: Unable to re-decode a buffer with different settings. Buffer has already been transferred.")
                    }
                    let i = this.workerNextTaskID++,
                        o = e.byteLength,
                        s = this._getWorker(i, o).then(n => (r = n, new Promise((n, a) => {
                            r._callbacks[i] = {
                                resolve: n,
                                reject: a
                            }, r.postMessage({
                                type: "decode",
                                id: i,
                                taskConfig: t,
                                buffer: e
                            }, [e])
                        }))).then(e => this._createGeometry(e.geometry));
                    return s.catch(() => !0).then(() => {
                        r && i && this._releaseTask(r, i)
                    }), a.set(e, {
                        key: n,
                        promise: s
                    }), s
                }
                _createGeometry(e) {
                    let t = new i.BufferGeometry;
                    e.index && t.setIndex(new i.BufferAttribute(e.index.array, 1));
                    for (let r = 0; r < e.attributes.length; r++) {
                        let n = e.attributes[r],
                            a = n.name,
                            o = n.array,
                            s = n.itemSize;
                        t.setAttribute(a, new i.BufferAttribute(o, s))
                    }
                    return t
                }
                _loadLibrary(e, t) {
                    let r = new i.FileLoader(this.manager);
                    return r.setPath(this.decoderPath), r.setResponseType(t), r.setWithCredentials(this.withCredentials), new Promise((t, n) => {
                        r.load(e, t, void 0, n)
                    })
                }
                preload() {
                    return this._initDecoder(), this
                }
                _initDecoder() {
                    if (this.decoderPending) return this.decoderPending;
                    let e = "object" != typeof WebAssembly || "js" === this.decoderConfig.type,
                        t = [];
                    return e ? t.push(this._loadLibrary("draco_decoder.js", "text")) : (t.push(this._loadLibrary("draco_wasm_wrapper.js", "text")), t.push(this._loadLibrary("draco_decoder.wasm", "arraybuffer"))), this.decoderPending = Promise.all(t).then(t => {
                        let r = t[0];
                        e || (this.decoderConfig.wasmBinary = t[1]);
                        let n = s.toString(),
                            i = ["/* draco decoder */", r, "", "/* worker */", n.substring(n.indexOf("{") + 1, n.lastIndexOf("}"))].join("\n");
                        this.workerSourceURL = URL.createObjectURL(new Blob([i]))
                    }), this.decoderPending
                }
                _getWorker(e, t) {
                    return this._initDecoder().then(() => {
                        if (this.workerPool.length < this.workerLimit) {
                            let e = new Worker(this.workerSourceURL);
                            e._callbacks = {}, e._taskCosts = {}, e._taskLoad = 0, e.postMessage({
                                type: "init",
                                decoderConfig: this.decoderConfig
                            }), e.onmessage = function(t) {
                                let r = t.data;
                                switch (r.type) {
                                    case "decode":
                                        e._callbacks[r.id].resolve(r);
                                        break;
                                    case "error":
                                        e._callbacks[r.id].reject(r);
                                        break;
                                    default:
                                        console.error('THREE.DRACOLoader: Unexpected message, "' + r.type + '"')
                                }
                            }, this.workerPool.push(e)
                        } else this.workerPool.sort(function(e, t) {
                            return e._taskLoad > t._taskLoad ? -1 : 1
                        });
                        let r = this.workerPool[this.workerPool.length - 1];
                        return r._taskCosts[e] = t, r._taskLoad += t, r
                    })
                }
                _releaseTask(e, t) {
                    e._taskLoad -= e._taskCosts[t], delete e._callbacks[t], delete e._taskCosts[t]
                }
                debug() {
                    console.log("Task load: ", this.workerPool.map(e => e._taskLoad))
                }
                dispose() {
                    for (let e = 0; e < this.workerPool.length; ++e) this.workerPool[e].terminate();
                    return this.workerPool.length = 0, this
                }
            }

            function s() {
                let e, t;
                onmessage = function(r) {
                    let n = r.data;
                    switch (n.type) {
                        case "init":
                            e = n.decoderConfig, t = new Promise(function(t) {
                                e.onModuleLoaded = function(e) {
                                    t({
                                        draco: e
                                    })
                                }, DracoDecoderModule(e)
                            });
                            break;
                        case "decode":
                            let i = n.buffer,
                                a = n.taskConfig;
                            t.then(e => {
                                let t = e.draco,
                                    r = new t.Decoder,
                                    o = new t.DecoderBuffer;
                                o.Init(new Int8Array(i), i.byteLength);
                                try {
                                    let e = function(e, t, r, n) {
                                            let i, a;
                                            let o = n.attributeIDs,
                                                s = n.attributeTypes,
                                                l = t.GetEncodedGeometryType(r);
                                            if (l === e.TRIANGULAR_MESH) i = new e.Mesh, a = t.DecodeBufferToMesh(r, i);
                                            else if (l === e.POINT_CLOUD) i = new e.PointCloud, a = t.DecodeBufferToPointCloud(r, i);
                                            else throw Error("THREE.DRACOLoader: Unexpected geometry type.");
                                            if (!a.ok() || 0 === i.ptr) throw Error("THREE.DRACOLoader: Decoding failed: " + a.error_msg());
                                            let u = {
                                                index: null,
                                                attributes: []
                                            };
                                            for (let r in o) {
                                                let a, l;
                                                let c = self[s[r]];
                                                if (n.useUniqueIDs) l = o[r], a = t.GetAttributeByUniqueId(i, l);
                                                else {
                                                    if (-1 === (l = t.GetAttributeId(i, e[o[r]]))) continue;
                                                    a = t.GetAttribute(i, l)
                                                }
                                                u.attributes.push(function(e, t, r, n, i, a) {
                                                    let o = a.num_components(),
                                                        s = r.num_points() * o,
                                                        l = s * i.BYTES_PER_ELEMENT,
                                                        u = function(e, t) {
                                                            switch (t) {
                                                                case Float32Array:
                                                                    return e.DT_FLOAT32;
                                                                case Int8Array:
                                                                    return e.DT_INT8;
                                                                case Int16Array:
                                                                    return e.DT_INT16;
                                                                case Int32Array:
                                                                    return e.DT_INT32;
                                                                case Uint8Array:
                                                                    return e.DT_UINT8;
                                                                case Uint16Array:
                                                                    return e.DT_UINT16;
                                                                case Uint32Array:
                                                                    return e.DT_UINT32
                                                            }
                                                        }(e, i),
                                                        c = e._malloc(l);
                                                    t.GetAttributeDataArrayForAllPoints(r, a, u, l, c);
                                                    let d = new i(e.HEAPF32.buffer, c, s).slice();
                                                    return e._free(c), {
                                                        name: n,
                                                        array: d,
                                                        itemSize: o
                                                    }
                                                }(e, t, i, r, c, a))
                                            }
                                            return l === e.TRIANGULAR_MESH && (u.index = function(e, t, r) {
                                                let n = 3 * r.num_faces(),
                                                    i = 4 * n,
                                                    a = e._malloc(i);
                                                t.GetTrianglesUInt32Array(r, i, a);
                                                let o = new Uint32Array(e.HEAPF32.buffer, a, n).slice();
                                                return e._free(a), {
                                                    array: o,
                                                    itemSize: 1
                                                }
                                            }(e, t, i)), e.destroy(i), u
                                        }(t, r, o, a),
                                        i = e.attributes.map(e => e.array.buffer);
                                    e.index && i.push(e.index.array.buffer), self.postMessage({
                                        type: "decode",
                                        id: n.id,
                                        geometry: e
                                    }, i)
                                } catch (e) {
                                    console.error(e), self.postMessage({
                                        type: "error",
                                        id: n.id,
                                        error: e.message
                                    })
                                } finally {
                                    t.destroy(o), t.destroy(r)
                                }
                            })
                    }
                }
            }
            let l = () => {
                let e;
                if (n) return n;
                let t = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 3, 2, 0, 0, 5, 3, 1, 0, 1, 12, 1, 0, 10, 22, 2, 12, 0, 65, 0, 65, 0, 65, 0, 252, 10, 0, 0, 11, 7, 0, 65, 0, 253, 15, 26, 11]),
                    r = new Uint8Array([32, 0, 65, 253, 3, 1, 2, 34, 4, 106, 6, 5, 11, 8, 7, 20, 13, 33, 12, 16, 128, 9, 116, 64, 19, 113, 127, 15, 10, 21, 22, 14, 255, 66, 24, 54, 136, 107, 18, 23, 192, 26, 114, 118, 132, 17, 77, 101, 130, 144, 27, 87, 131, 44, 45, 74, 156, 154, 70, 167]);
                if ("object" != typeof WebAssembly) return {
                    supported: !1
                };
                let i = "B9h9z9tFBBBF8fL9gBB9gLaaaaaFa9gEaaaB9gFaFa9gEaaaFaEMcBFFFGGGEIIILF9wFFFLEFBFKNFaFCx/IFMO/LFVK9tv9t9vq95GBt9f9f939h9z9t9f9j9h9s9s9f9jW9vq9zBBp9tv9z9o9v9wW9f9kv9j9v9kv9WvqWv94h919m9mvqBF8Z9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv94h919m9mvqBGy9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv949TvZ91v9u9jvBEn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9P9jWBIi9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9R919hWBLn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9F949wBKI9z9iqlBOc+x8ycGBM/qQFTa8jUUUUBCU/EBlHL8kUUUUBC9+RKGXAGCFJAI9LQBCaRKAE2BBC+gF9HQBALAEAIJHOAGlAGTkUUUBRNCUoBAG9uC/wgBZHKCUGAKCUG9JyRVAECFJRICBRcGXEXAcAF9PQFAVAFAclAcAVJAF9JyRMGXGXAG9FQBAMCbJHKC9wZRSAKCIrCEJCGrRQANCUGJRfCBRbAIRTEXGXAOATlAQ9PQBCBRISEMATAQJRIGXAS9FQBCBRtCBREEXGXAOAIlCi9PQBCBRISLMANCU/CBJAEJRKGXGXGXGXGXATAECKrJ2BBAtCKZrCEZfIBFGEBMAKhB83EBAKCNJhB83EBSEMAKAI2BIAI2BBHmCKrHYAYCE6HYy86BBAKCFJAICIJAYJHY2BBAmCIrCEZHPAPCE6HPy86BBAKCGJAYAPJHY2BBAmCGrCEZHPAPCE6HPy86BBAKCEJAYAPJHY2BBAmCEZHmAmCE6Hmy86BBAKCIJAYAmJHY2BBAI2BFHmCKrHPAPCE6HPy86BBAKCLJAYAPJHY2BBAmCIrCEZHPAPCE6HPy86BBAKCKJAYAPJHY2BBAmCGrCEZHPAPCE6HPy86BBAKCOJAYAPJHY2BBAmCEZHmAmCE6Hmy86BBAKCNJAYAmJHY2BBAI2BGHmCKrHPAPCE6HPy86BBAKCVJAYAPJHY2BBAmCIrCEZHPAPCE6HPy86BBAKCcJAYAPJHY2BBAmCGrCEZHPAPCE6HPy86BBAKCMJAYAPJHY2BBAmCEZHmAmCE6Hmy86BBAKCSJAYAmJHm2BBAI2BEHICKrHYAYCE6HYy86BBAKCQJAmAYJHm2BBAICIrCEZHYAYCE6HYy86BBAKCfJAmAYJHm2BBAICGrCEZHYAYCE6HYy86BBAKCbJAmAYJHK2BBAICEZHIAICE6HIy86BBAKAIJRISGMAKAI2BNAI2BBHmCIrHYAYCb6HYy86BBAKCFJAICNJAYJHY2BBAmCbZHmAmCb6Hmy86BBAKCGJAYAmJHm2BBAI2BFHYCIrHPAPCb6HPy86BBAKCEJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCIJAmAYJHm2BBAI2BGHYCIrHPAPCb6HPy86BBAKCLJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCKJAmAYJHm2BBAI2BEHYCIrHPAPCb6HPy86BBAKCOJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCNJAmAYJHm2BBAI2BIHYCIrHPAPCb6HPy86BBAKCVJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCcJAmAYJHm2BBAI2BLHYCIrHPAPCb6HPy86BBAKCMJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCSJAmAYJHm2BBAI2BKHYCIrHPAPCb6HPy86BBAKCQJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCfJAmAYJHm2BBAI2BOHICIrHYAYCb6HYy86BBAKCbJAmAYJHK2BBAICbZHIAICb6HIy86BBAKAIJRISFMAKAI8pBB83BBAKCNJAICNJ8pBB83BBAICTJRIMAtCGJRtAECTJHEAS9JQBMMGXAIQBCBRISEMGXAM9FQBANAbJ2BBRtCBRKAfREEXAEANCU/CBJAKJ2BBHTCFrCBATCFZl9zAtJHt86BBAEAGJREAKCFJHKAM9HQBMMAfCFJRfAIRTAbCFJHbAG9HQBMMABAcAG9sJANCUGJAMAG9sTkUUUBpANANCUGJAMCaJAG9sJAGTkUUUBpMAMCBAIyAcJRcAIQBMC9+RKSFMCBC99AOAIlAGCAAGCA9Ly6yRKMALCU/EBJ8kUUUUBAKM+OmFTa8jUUUUBCoFlHL8kUUUUBC9+RKGXAFCE9uHOCtJAI9LQBCaRKAE2BBHNC/wFZC/gF9HQBANCbZHVCF9LQBALCoBJCgFCUFT+JUUUBpALC84Jha83EBALC8wJha83EBALC8oJha83EBALCAJha83EBALCiJha83EBALCTJha83EBALha83ENALha83EBAEAIJC9wJRcAECFJHNAOJRMGXAF9FQBCQCbAVCF6yRSABRECBRVCBRQCBRfCBRICBRKEXGXAMAcuQBC9+RKSEMGXGXAN2BBHOC/vF9LQBALCoBJAOCIrCa9zAKJCbZCEWJHb8oGIRTAb8oGBRtGXAOCbZHbAS9PQBALAOCa9zAIJCbZCGWJ8oGBAVAbyROAb9FRbGXGXAGCG9HQBABAt87FBABCIJAO87FBABCGJAT87FBSFMAEAtjGBAECNJAOjGBAECIJATjGBMAVAbJRVALCoBJAKCEWJHmAOjGBAmATjGIALAICGWJAOjGBALCoBJAKCFJCbZHKCEWJHTAtjGBATAOjGIAIAbJRIAKCFJRKSGMGXGXAbCb6QBAQAbJAbC989zJCFJRQSFMAM1BBHbCgFZROGXGXAbCa9MQBAMCFJRMSFMAM1BFHbCgBZCOWAOCgBZqROGXAbCa9MQBAMCGJRMSFMAM1BGHbCgBZCfWAOqROGXAbCa9MQBAMCEJRMSFMAM1BEHbCgBZCdWAOqROGXAbCa9MQBAMCIJRMSFMAM2BIC8cWAOqROAMCLJRMMAOCFrCBAOCFZl9zAQJRQMGXGXAGCG9HQBABAt87FBABCIJAQ87FBABCGJAT87FBSFMAEAtjGBAECNJAQjGBAECIJATjGBMALCoBJAKCEWJHOAQjGBAOATjGIALAICGWJAQjGBALCoBJAKCFJCbZHKCEWJHOAtjGBAOAQjGIAICFJRIAKCFJRKSFMGXAOCDF9LQBALAIAcAOCbZJ2BBHbCIrHTlCbZCGWJ8oGBAVCFJHtATyROALAIAblCbZCGWJ8oGBAtAT9FHmJHtAbCbZHTyRbAT9FRTGXGXAGCG9HQBABAV87FBABCIJAb87FBABCGJAO87FBSFMAEAVjGBAECNJAbjGBAECIJAOjGBMALAICGWJAVjGBALCoBJAKCEWJHYAOjGBAYAVjGIALAICFJHICbZCGWJAOjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAIAmJCbZHICGWJAbjGBALCoBJAKCGJCbZHKCEWJHOAVjGBAOAbjGIAKCFJRKAIATJRIAtATJRVSFMAVCBAM2BBHYyHTAOC/+F6HPJROAYCbZRtGXGXAYCIrHmQBAOCFJRbSFMAORbALAIAmlCbZCGWJ8oGBROMGXGXAtQBAbCFJRVSFMAbRVALAIAYlCbZCGWJ8oGBRbMGXGXAP9FQBAMCFJRYSFMAM1BFHYCgFZRTGXGXAYCa9MQBAMCGJRYSFMAM1BGHYCgBZCOWATCgBZqRTGXAYCa9MQBAMCEJRYSFMAM1BEHYCgBZCfWATqRTGXAYCa9MQBAMCIJRYSFMAM1BIHYCgBZCdWATqRTGXAYCa9MQBAMCLJRYSFMAMCKJRYAM2BLC8cWATqRTMATCFrCBATCFZl9zAQJHQRTMGXGXAmCb6QBAYRPSFMAY1BBHMCgFZROGXGXAMCa9MQBAYCFJRPSFMAY1BFHMCgBZCOWAOCgBZqROGXAMCa9MQBAYCGJRPSFMAY1BGHMCgBZCfWAOqROGXAMCa9MQBAYCEJRPSFMAY1BEHMCgBZCdWAOqROGXAMCa9MQBAYCIJRPSFMAYCLJRPAY2BIC8cWAOqROMAOCFrCBAOCFZl9zAQJHQROMGXGXAtCb6QBAPRMSFMAP1BBHMCgFZRbGXGXAMCa9MQBAPCFJRMSFMAP1BFHMCgBZCOWAbCgBZqRbGXAMCa9MQBAPCGJRMSFMAP1BGHMCgBZCfWAbqRbGXAMCa9MQBAPCEJRMSFMAP1BEHMCgBZCdWAbqRbGXAMCa9MQBAPCIJRMSFMAPCLJRMAP2BIC8cWAbqRbMAbCFrCBAbCFZl9zAQJHQRbMGXGXAGCG9HQBABAT87FBABCIJAb87FBABCGJAO87FBSFMAEATjGBAECNJAbjGBAECIJAOjGBMALCoBJAKCEWJHYAOjGBAYATjGIALAICGWJATjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAICFJHICbZCGWJAOjGBALCoBJAKCGJCbZCEWJHOATjGBAOAbjGIALAIAm9FAmCb6qJHICbZCGWJAbjGBAIAt9FAtCb6qJRIAKCEJRKMANCFJRNABCKJRBAECSJREAKCbZRKAICbZRIAfCEJHfAF9JQBMMCBC99AMAc6yRKMALCoFJ8kUUUUBAKM/tIFGa8jUUUUBCTlRLC9+RKGXAFCLJAI9LQBCaRKAE2BBC/+FZC/QF9HQBALhB83ENAECFJRKAEAIJC98JREGXAF9FQBGXAGCG6QBEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMALCNJAICFZCGWqHGAICGrCBAICFrCFZl9zAG8oGBJHIjGBABAIjGBABCIJRBAFCaJHFQBSGMMEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMABAICGrCBAICFrCFZl9zALCNJAICFZCGWqHI8oGBJHG87FBAIAGjGBABCGJRBAFCaJHFQBMMCBC99AKAE6yRKMAKM+lLKFaF99GaG99FaG99GXGXAGCI9HQBAF9FQFEXGXGX9DBBB8/9DBBB+/ABCGJHG1BB+yAB1BBHE+yHI+L+TABCFJHL1BBHK+yHO+L+THN9DBBBB9gHVyAN9DBB/+hANAN+U9DBBBBANAVyHcAc+MHMAECa3yAI+SHIAI+UAcAMAKCa3yAO+SHcAc+U+S+S+R+VHO+U+SHN+L9DBBB9P9d9FQBAN+oRESFMCUUUU94REMAGAE86BBGXGX9DBBB8/9DBBB+/Ac9DBBBB9gyAcAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMALAG86BBGXGX9DBBB8/9DBBB+/AI9DBBBB9gyAIAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMABAG86BBABCIJRBAFCaJHFQBSGMMAF9FQBEXGXGX9DBBB8/9DBBB+/ABCIJHG8uFB+yAB8uFBHE+yHI+L+TABCGJHL8uFBHK+yHO+L+THN9DBBBB9gHVyAN9DB/+g6ANAN+U9DBBBBANAVyHcAc+MHMAECa3yAI+SHIAI+UAcAMAKCa3yAO+SHcAc+U+S+S+R+VHO+U+SHN+L9DBBB9P9d9FQBAN+oRESFMCUUUU94REMAGAE87FBGXGX9DBBB8/9DBBB+/Ac9DBBBB9gyAcAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMALAG87FBGXGX9DBBB8/9DBBB+/AI9DBBBB9gyAIAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMABAG87FBABCNJRBAFCaJHFQBMMM/SEIEaE99EaF99GXAF9FQBCBREABRIEXGXGX9D/zI818/AICKJ8uFBHLCEq+y+VHKAI8uFB+y+UHO9DB/+g6+U9DBBB8/9DBBB+/AO9DBBBB9gy+SHN+L9DBBB9P9d9FQBAN+oRVSFMCUUUU94RVMAICIJ8uFBRcAICGJ8uFBRMABALCFJCEZAEqCFWJAV87FBGXGXAKAM+y+UHN9DB/+g6+U9DBBB8/9DBBB+/AN9DBBBB9gy+SHS+L9DBBB9P9d9FQBAS+oRMSFMCUUUU94RMMABALCGJCEZAEqCFWJAM87FBGXGXAKAc+y+UHK9DB/+g6+U9DBBB8/9DBBB+/AK9DBBBB9gy+SHS+L9DBBB9P9d9FQBAS+oRcSFMCUUUU94RcMABALCaJCEZAEqCFWJAc87FBGXGX9DBBU8/AOAO+U+TANAN+U+TAKAK+U+THO9DBBBBAO9DBBBB9gy+R9DB/+g6+U9DBBB8/+SHO+L9DBBB9P9d9FQBAO+oRcSFMCUUUU94RcMABALCEZAEqCFWJAc87FBAICNJRIAECIJREAFCaJHFQBMMM9JBGXAGCGrAF9sHF9FQBEXABAB8oGBHGCNWCN91+yAGCi91CnWCUUU/8EJ+++U84GBABCIJRBAFCaJHFQBMMM9TFEaCBCB8oGUkUUBHFABCEJC98ZJHBjGUkUUBGXGXAB8/BCTWHGuQBCaREABAGlCggEJCTrXBCa6QFMAFREMAEM/lFFFaGXGXAFABqCEZ9FQBABRESFMGXGXAGCT9PQBABRESFMABREEXAEAF8oGBjGBAECIJAFCIJ8oGBjGBAECNJAFCNJ8oGBjGBAECSJAFCSJ8oGBjGBAECTJREAFCTJRFAGC9wJHGCb9LQBMMAGCI9JQBEXAEAF8oGBjGBAFCIJRFAECIJREAGC98JHGCE9LQBMMGXAG9FQBEXAEAF2BB86BBAECFJREAFCFJRFAGCaJHGQBMMABMoFFGaGXGXABCEZ9FQBABRESFMAFCgFZC+BwsN9sRIGXGXAGCT9PQBABRESFMABREEXAEAIjGBAECSJAIjGBAECNJAIjGBAECIJAIjGBAECTJREAGC9wJHGCb9LQBMMAGCI9JQBEXAEAIjGBAECIJREAGC98JHGCE9LQBMMGXAG9FQBEXAEAF86BBAECFJREAGCaJHGQBMMABMMMFBCUNMIT9kBB";
                WebAssembly.validate(t) && (i = "B9h9z9tFBBBFiI9gBB9gLaaaaaFa9gEaaaB9gFaFaEMcBBFBFFGGGEILF9wFFFLEFBFKNFaFCx/aFMO/LFVK9tv9t9vq95GBt9f9f939h9z9t9f9j9h9s9s9f9jW9vq9zBBp9tv9z9o9v9wW9f9kv9j9v9kv9WvqWv94h919m9mvqBG8Z9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv94h919m9mvqBIy9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv949TvZ91v9u9jvBLn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9P9jWBKi9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9R919hWBOn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9F949wBNI9z9iqlBVc+N9IcIBTEM9+FLa8jUUUUBCTlRBCBRFEXCBRGCBREEXABCNJAGJAECUaAFAGrCFZHIy86BBAEAIJREAGCFJHGCN9HQBMAFCx+YUUBJAE86BBAFCEWCxkUUBJAB8pEN83EBAFCFJHFCUG9HQBMMk8lLbaE97F9+FaL978jUUUUBCU/KBlHL8kUUUUBC9+RKGXAGCFJAI9LQBCaRKAE2BBC+gF9HQBALAEAIJHOAGlAG/8cBBCUoBAG9uC/wgBZHKCUGAKCUG9JyRNAECFJRKCBRVGXEXAVAF9PQFANAFAVlAVANJAF9JyRcGXGXAG9FQBAcCbJHIC9wZHMCE9sRSAMCFWRQAICIrCEJCGrRfCBRbEXAKRTCBRtGXEXGXAOATlAf9PQBCBRKSLMALCU/CBJAtAM9sJRmATAfJRKCBREGXAMCoB9JQBAOAKlC/gB9JQBCBRIEXAmAIJREGXGXGXGXGXATAICKrJ2BBHYCEZfIBFGEBMAECBDtDMIBSEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAEAKDBBBDMIBAKCTJRKMGXGXGXGXGXAYCGrCEZfIBFGEBMAECBDtDMITSEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMITAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMITAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAEAKDBBBDMITAKCTJRKMGXGXGXGXGXAYCIrCEZfIBFGEBMAECBDtDMIASEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIAAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIAAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAEAKDBBBDMIAAKCTJRKMGXGXGXGXGXAYCKrfIBFGEBMAECBDtDMI8wSEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHYCEWCxkUUBJDBEBAYCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHYCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMI8wAKCIJAeDeBJAYCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHYCEWCxkUUBJDBEBAYCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHYCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMI8wAKCNJAeDeBJAYCx+YUUBJ2BBJRKSFMAEAKDBBBDMI8wAKCTJRKMAICoBJREAICUFJAM9LQFAERIAOAKlC/fB9LQBMMGXAEAM9PQBAECErRIEXGXAOAKlCi9PQBCBRKSOMAmAEJRYGXGXGXGXGXATAECKrJ2BBAICKZrCEZfIBFGEBMAYCBDtDMIBSEMAYAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAYAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAYAKDBBBDMIBAKCTJRKMAICGJRIAECTJHEAM9JQBMMGXAK9FQBAKRTAtCFJHtCI6QGSFMMCBRKSEMGXAM9FQBALCUGJAbJREALAbJDBGBReCBRYEXAEALCU/CBJAYJHIDBIBHdCFD9tAdCFDbHPD9OD9hD9RHdAIAMJDBIBH8ZCFD9tA8ZAPD9OD9hD9RH8ZDQBTFtGmEYIPLdKeOnHpAIAQJDBIBHyCFD9tAyAPD9OD9hD9RHyAIASJDBIBH8cCFD9tA8cAPD9OD9hD9RH8cDQBTFtGmEYIPLdKeOnH8dDQBFTtGEmYILPdKOenHPAPDQBFGEBFGEBFGEBFGEAeD9uHeDyBjGBAEAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJHIAeApA8dDQNVi8ZcMpySQ8c8dfb8e8fHPAPDQBFGEBFGEBFGEBFGED9uHeDyBjGBAIAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJHIAeAdA8ZDQNiV8ZcpMyS8cQ8df8eb8fHdAyA8cDQNiV8ZcpMyS8cQ8df8eb8fH8ZDQBFTtGEmYILPdKOenHPAPDQBFGEBFGEBFGEBFGED9uHeDyBjGBAIAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJHIAeAdA8ZDQNVi8ZcMpySQ8c8dfb8e8fHPAPDQBFGEBFGEBFGEBFGED9uHeDyBjGBAIAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJREAYCTJHYAM9JQBMMAbCIJHbAG9JQBMMABAVAG9sJALCUGJAcAG9s/8cBBALALCUGJAcCaJAG9sJAG/8cBBMAcCBAKyAVJRVAKQBMC9+RKSFMCBC99AOAKlAGCAAGCA9Ly6yRKMALCU/KBJ8kUUUUBAKMNBT+BUUUBM+KmFTa8jUUUUBCoFlHL8kUUUUBC9+RKGXAFCE9uHOCtJAI9LQBCaRKAE2BBHNC/wFZC/gF9HQBANCbZHVCF9LQBALCoBJCgFCUF/8MBALC84Jha83EBALC8wJha83EBALC8oJha83EBALCAJha83EBALCiJha83EBALCTJha83EBALha83ENALha83EBAEAIJC9wJRcAECFJHNAOJRMGXAF9FQBCQCbAVCF6yRSABRECBRVCBRQCBRfCBRICBRKEXGXAMAcuQBC9+RKSEMGXGXAN2BBHOC/vF9LQBALCoBJAOCIrCa9zAKJCbZCEWJHb8oGIRTAb8oGBRtGXAOCbZHbAS9PQBALAOCa9zAIJCbZCGWJ8oGBAVAbyROAb9FRbGXGXAGCG9HQBABAt87FBABCIJAO87FBABCGJAT87FBSFMAEAtjGBAECNJAOjGBAECIJATjGBMAVAbJRVALCoBJAKCEWJHmAOjGBAmATjGIALAICGWJAOjGBALCoBJAKCFJCbZHKCEWJHTAtjGBATAOjGIAIAbJRIAKCFJRKSGMGXGXAbCb6QBAQAbJAbC989zJCFJRQSFMAM1BBHbCgFZROGXGXAbCa9MQBAMCFJRMSFMAM1BFHbCgBZCOWAOCgBZqROGXAbCa9MQBAMCGJRMSFMAM1BGHbCgBZCfWAOqROGXAbCa9MQBAMCEJRMSFMAM1BEHbCgBZCdWAOqROGXAbCa9MQBAMCIJRMSFMAM2BIC8cWAOqROAMCLJRMMAOCFrCBAOCFZl9zAQJRQMGXGXAGCG9HQBABAt87FBABCIJAQ87FBABCGJAT87FBSFMAEAtjGBAECNJAQjGBAECIJATjGBMALCoBJAKCEWJHOAQjGBAOATjGIALAICGWJAQjGBALCoBJAKCFJCbZHKCEWJHOAtjGBAOAQjGIAICFJRIAKCFJRKSFMGXAOCDF9LQBALAIAcAOCbZJ2BBHbCIrHTlCbZCGWJ8oGBAVCFJHtATyROALAIAblCbZCGWJ8oGBAtAT9FHmJHtAbCbZHTyRbAT9FRTGXGXAGCG9HQBABAV87FBABCIJAb87FBABCGJAO87FBSFMAEAVjGBAECNJAbjGBAECIJAOjGBMALAICGWJAVjGBALCoBJAKCEWJHYAOjGBAYAVjGIALAICFJHICbZCGWJAOjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAIAmJCbZHICGWJAbjGBALCoBJAKCGJCbZHKCEWJHOAVjGBAOAbjGIAKCFJRKAIATJRIAtATJRVSFMAVCBAM2BBHYyHTAOC/+F6HPJROAYCbZRtGXGXAYCIrHmQBAOCFJRbSFMAORbALAIAmlCbZCGWJ8oGBROMGXGXAtQBAbCFJRVSFMAbRVALAIAYlCbZCGWJ8oGBRbMGXGXAP9FQBAMCFJRYSFMAM1BFHYCgFZRTGXGXAYCa9MQBAMCGJRYSFMAM1BGHYCgBZCOWATCgBZqRTGXAYCa9MQBAMCEJRYSFMAM1BEHYCgBZCfWATqRTGXAYCa9MQBAMCIJRYSFMAM1BIHYCgBZCdWATqRTGXAYCa9MQBAMCLJRYSFMAMCKJRYAM2BLC8cWATqRTMATCFrCBATCFZl9zAQJHQRTMGXGXAmCb6QBAYRPSFMAY1BBHMCgFZROGXGXAMCa9MQBAYCFJRPSFMAY1BFHMCgBZCOWAOCgBZqROGXAMCa9MQBAYCGJRPSFMAY1BGHMCgBZCfWAOqROGXAMCa9MQBAYCEJRPSFMAY1BEHMCgBZCdWAOqROGXAMCa9MQBAYCIJRPSFMAYCLJRPAY2BIC8cWAOqROMAOCFrCBAOCFZl9zAQJHQROMGXGXAtCb6QBAPRMSFMAP1BBHMCgFZRbGXGXAMCa9MQBAPCFJRMSFMAP1BFHMCgBZCOWAbCgBZqRbGXAMCa9MQBAPCGJRMSFMAP1BGHMCgBZCfWAbqRbGXAMCa9MQBAPCEJRMSFMAP1BEHMCgBZCdWAbqRbGXAMCa9MQBAPCIJRMSFMAPCLJRMAP2BIC8cWAbqRbMAbCFrCBAbCFZl9zAQJHQRbMGXGXAGCG9HQBABAT87FBABCIJAb87FBABCGJAO87FBSFMAEATjGBAECNJAbjGBAECIJAOjGBMALCoBJAKCEWJHYAOjGBAYATjGIALAICGWJATjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAICFJHICbZCGWJAOjGBALCoBJAKCGJCbZCEWJHOATjGBAOAbjGIALAIAm9FAmCb6qJHICbZCGWJAbjGBAIAt9FAtCb6qJRIAKCEJRKMANCFJRNABCKJRBAECSJREAKCbZRKAICbZRIAfCEJHfAF9JQBMMCBC99AMAc6yRKMALCoFJ8kUUUUBAKM/tIFGa8jUUUUBCTlRLC9+RKGXAFCLJAI9LQBCaRKAE2BBC/+FZC/QF9HQBALhB83ENAECFJRKAEAIJC98JREGXAF9FQBGXAGCG6QBEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMALCNJAICFZCGWqHGAICGrCBAICFrCFZl9zAG8oGBJHIjGBABAIjGBABCIJRBAFCaJHFQBSGMMEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMABAICGrCBAICFrCFZl9zALCNJAICFZCGWqHI8oGBJHG87FBAIAGjGBABCGJRBAFCaJHFQBMMCBC99AKAE6yRKMAKM/dLEK97FaF97GXGXAGCI9HQBAF9FQFCBRGEXABABDBBBHECiD+rFCiD+sFD/6FHIAECND+rFCiD+sFD/6FAID/gFAECTD+rFCiD+sFD/6FHLD/gFD/kFD/lFHKCBDtD+2FHOAICUUUU94DtHND9OD9RD/kFHI9DBB/+hDYAIAID/mFAKAKD/mFALAOALAND9OD9RD/kFHIAID/mFD/kFD/kFD/jFD/nFHLD/mF9DBBX9LDYHOD/kFCgFDtD9OAECUUU94DtD9OD9QAIALD/mFAOD/kFCND+rFCU/+EDtD9OD9QAKALD/mFAOD/kFCTD+rFCUU/8ODtD9OD9QDMBBABCTJRBAGCIJHGAF9JQBSGMMAF9FQBCBRGEXABCTJHVAVDBBBHECBDtHOCUU98D8cFCUU98D8cEHND9OABDBBBHKAEDQILKOSQfbPden8c8d8e8fCggFDtD9OD/6FAKAEDQBFGENVcMTtmYi8ZpyHECTD+sFD/6FHID/gFAECTD+rFCTD+sFD/6FHLD/gFD/kFD/lFHE9DB/+g6DYALAEAOD+2FHOALCUUUU94DtHcD9OD9RD/kFHLALD/mFAEAED/mFAIAOAIAcD9OD9RD/kFHEAED/mFD/kFD/kFD/jFD/nFHID/mF9DBBX9LDYHOD/kFCTD+rFALAID/mFAOD/kFCggEDtD9OD9QHLAEAID/mFAOD/kFCaDbCBDnGCBDnECBDnKCBDnOCBDncCBDnMCBDnfCBDnbD9OHEDQNVi8ZcMpySQ8c8dfb8e8fD9QDMBBABAKAND9OALAEDQBFTtGEmYILPdKOenD9QDMBBABCAJRBAGCIJHGAF9JQBMMM/hEIGaF97FaL978jUUUUBCTlREGXAF9FQBCBRIEXAEABDBBBHLABCTJHKDBBBHODQILKOSQfbPden8c8d8e8fHNCTD+sFHVCID+rFDMIBAB9DBBU8/DY9D/zI818/DYAVCEDtD9QD/6FD/nFHVALAODQBFGENVcMTtmYi8ZpyHLCTD+rFCTD+sFD/6FD/mFHOAOD/mFAVALCTD+sFD/6FD/mFHcAcD/mFAVANCTD+rFCTD+sFD/6FD/mFHNAND/mFD/kFD/kFD/lFCBDtD+4FD/jF9DB/+g6DYHVD/mF9DBBX9LDYHLD/kFCggEDtHMD9OAcAVD/mFALD/kFCTD+rFD9QHcANAVD/mFALD/kFCTD+rFAOAVD/mFALD/kFAMD9OD9QHVDQBFTtGEmYILPdKOenHLD8dBAEDBIBDyB+t+J83EBABCNJALD8dFAEDBIBDyF+t+J83EBAKAcAVDQNVi8ZcMpySQ8c8dfb8e8fHVD8dBAEDBIBDyG+t+J83EBABCiJAVD8dFAEDBIBDyE+t+J83EBABCAJRBAICIJHIAF9JQBMMM9jFF97GXAGCGrAF9sHG9FQBCBRFEXABABDBBBHECND+rFCND+sFD/6FAECiD+sFCnD+rFCUUU/8EDtD+uFD/mFDMBBABCTJRBAFCIJHFAG9JQBMMM9TFEaCBCB8oGUkUUBHFABCEJC98ZJHBjGUkUUBGXGXAB8/BCTWHGuQBCaREABAGlCggEJCTrXBCa6QFMAFREMAEMMMFBCUNMIT9tBB");
                let a = WebAssembly.instantiate(function(e) {
                    let t = new Uint8Array(e.length);
                    for (let r = 0; r < e.length; ++r) {
                        let n = e.charCodeAt(r);
                        t[r] = n > 96 ? n - 71 : n > 64 ? n - 65 : n > 47 ? n + 4 : n > 46 ? 63 : 62
                    }
                    let n = 0;
                    for (let i = 0; i < e.length; ++i) t[n++] = t[i] < 60 ? r[t[i]] : (t[i] - 60) * 64 + t[++i];
                    return t.buffer.slice(0, n)
                }(i), {}).then(t => {
                    (e = t.instance).exports.__wasm_call_ctors()
                });

                function o(t, r, n, i, a, o) {
                    let s = e.exports.sbrk,
                        l = n + 3 & -4,
                        u = s(l * i),
                        c = s(a.length),
                        d = new Uint8Array(e.exports.memory.buffer);
                    d.set(a, c);
                    let f = t(u, n, i, c, a.length);
                    if (0 === f && o && o(u, l, i), r.set(d.subarray(u, u + n * i)), s(u - s(0)), 0 !== f) throw Error(`Malformed buffer data: ${f}`)
                }
                let s = {
                        0: "",
                        1: "meshopt_decodeFilterOct",
                        2: "meshopt_decodeFilterQuat",
                        3: "meshopt_decodeFilterExp",
                        NONE: "",
                        OCTAHEDRAL: "meshopt_decodeFilterOct",
                        QUATERNION: "meshopt_decodeFilterQuat",
                        EXPONENTIAL: "meshopt_decodeFilterExp"
                    },
                    l = {
                        0: "meshopt_decodeVertexBuffer",
                        1: "meshopt_decodeIndexBuffer",
                        2: "meshopt_decodeIndexSequence",
                        ATTRIBUTES: "meshopt_decodeVertexBuffer",
                        TRIANGLES: "meshopt_decodeIndexBuffer",
                        INDICES: "meshopt_decodeIndexSequence"
                    };
                return n = {
                    ready: a,
                    supported: !0,
                    decodeVertexBuffer(t, r, n, i, a) {
                        o(e.exports.meshopt_decodeVertexBuffer, t, r, n, i, e.exports[s[a]])
                    },
                    decodeIndexBuffer(t, r, n, i) {
                        o(e.exports.meshopt_decodeIndexBuffer, t, r, n, i)
                    },
                    decodeIndexSequence(t, r, n, i) {
                        o(e.exports.meshopt_decodeIndexSequence, t, r, n, i)
                    },
                    decodeGltfBuffer(t, r, n, i, a, u) {
                        o(e.exports[l[a]], t, r, n, i, e.exports[s[u]])
                    }
                }
            };

            function u(e, t) {
                if (t === i.TrianglesDrawMode) return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."), e;
                if (t !== i.TriangleFanDrawMode && t !== i.TriangleStripDrawMode) return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:", t), e; {
                    let r = e.getIndex();
                    if (null === r) {
                        let t = [],
                            n = e.getAttribute("position");
                        if (void 0 === n) return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."), e;
                        for (let e = 0; e < n.count; e++) t.push(e);
                        e.setIndex(t), r = e.getIndex()
                    }
                    let n = r.count - 2,
                        a = [];
                    if (r) {
                        if (t === i.TriangleFanDrawMode)
                            for (let e = 1; e <= n; e++) a.push(r.getX(0)), a.push(r.getX(e)), a.push(r.getX(e + 1));
                        else
                            for (let e = 0; e < n; e++) e % 2 == 0 ? (a.push(r.getX(e)), a.push(r.getX(e + 1)), a.push(r.getX(e + 2))) : (a.push(r.getX(e + 2)), a.push(r.getX(e + 1)), a.push(r.getX(e)))
                    }
                    a.length / 3 !== n && console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");
                    let o = e.clone();
                    return o.setIndex(a), o.clearGroups(), o
                }
            }
            let c = parseInt(i.REVISION.replace(/\D+/g, "")),
                d = "srgb",
                f = "srgb-linear";
            class h extends i.Loader {
                constructor(e) {
                    super(e), this.dracoLoader = null, this.ktx2Loader = null, this.meshoptDecoder = null, this.pluginCallbacks = [], this.register(function(e) {
                        return new y(e)
                    }), this.register(function(e) {
                        return new C(e)
                    }), this.register(function(e) {
                        return new F(e)
                    }), this.register(function(e) {
                        return new S(e)
                    }), this.register(function(e) {
                        return new R(e)
                    }), this.register(function(e) {
                        return new _(e)
                    }), this.register(function(e) {
                        return new b(e)
                    }), this.register(function(e) {
                        return new E(e)
                    }), this.register(function(e) {
                        return new w(e)
                    }), this.register(function(e) {
                        return new v(e)
                    }), this.register(function(e) {
                        return new M(e)
                    }), this.register(function(e) {
                        return new B(e)
                    }), this.register(function(e) {
                        return new x(e)
                    }), this.register(function(e) {
                        return new T(e)
                    }), this.register(function(e) {
                        return new g(e)
                    }), this.register(function(e) {
                        return new O(e)
                    }), this.register(function(e) {
                        return new I(e)
                    })
                }
                load(e, t, r, n) {
                    let a;
                    let o = this;
                    if ("" !== this.resourcePath) a = this.resourcePath;
                    else if ("" !== this.path) {
                        let t = i.LoaderUtils.extractUrlBase(e);
                        a = i.LoaderUtils.resolveURL(t, this.path)
                    } else a = i.LoaderUtils.extractUrlBase(e);
                    this.manager.itemStart(e);
                    let s = function(t) {
                            n ? n(t) : console.error(t), o.manager.itemError(e), o.manager.itemEnd(e)
                        },
                        l = new i.FileLoader(this.manager);
                    l.setPath(this.path), l.setResponseType("arraybuffer"), l.setRequestHeader(this.requestHeader), l.setWithCredentials(this.withCredentials), l.load(e, function(r) {
                        try {
                            o.parse(r, a, function(r) {
                                t(r), o.manager.itemEnd(e)
                            }, s)
                        } catch (e) {
                            s(e)
                        }
                    }, r, s)
                }
                setDRACOLoader(e) {
                    return this.dracoLoader = e, this
                }
                setDDSLoader() {
                    throw Error('THREE.GLTFLoader: "MSFT_texture_dds" no longer supported. Please update to "KHR_texture_basisu".')
                }
                setKTX2Loader(e) {
                    return this.ktx2Loader = e, this
                }
                setMeshoptDecoder(e) {
                    return this.meshoptDecoder = e, this
                }
                register(e) {
                    return -1 === this.pluginCallbacks.indexOf(e) && this.pluginCallbacks.push(e), this
                }
                unregister(e) {
                    return -1 !== this.pluginCallbacks.indexOf(e) && this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e), 1), this
                }
                parse(e, t, r, n) {
                    let a;
                    let o = {},
                        s = {};
                    if ("string" == typeof e) a = JSON.parse(e);
                    else if (e instanceof ArrayBuffer) {
                        if (i.LoaderUtils.decodeText(new Uint8Array(e.slice(0, 4))) === D) {
                            try {
                                o[m.KHR_BINARY_GLTF] = new L(e)
                            } catch (e) {
                                n && n(e);
                                return
                            }
                            a = JSON.parse(o[m.KHR_BINARY_GLTF].content)
                        } else a = JSON.parse(i.LoaderUtils.decodeText(new Uint8Array(e)))
                    } else a = e;
                    if (void 0 === a.asset || a.asset.version[0] < 2) {
                        n && n(Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));
                        return
                    }
                    let l = new en(a, {
                        path: t || this.resourcePath || "",
                        crossOrigin: this.crossOrigin,
                        requestHeader: this.requestHeader,
                        manager: this.manager,
                        ktx2Loader: this.ktx2Loader,
                        meshoptDecoder: this.meshoptDecoder
                    });
                    l.fileLoader.setRequestHeader(this.requestHeader);
                    for (let e = 0; e < this.pluginCallbacks.length; e++) {
                        let t = this.pluginCallbacks[e](l);
                        t.name || console.error("THREE.GLTFLoader: Invalid plugin found: missing name"), s[t.name] = t, o[t.name] = !0
                    }
                    if (a.extensionsUsed)
                        for (let e = 0; e < a.extensionsUsed.length; ++e) {
                            let t = a.extensionsUsed[e],
                                r = a.extensionsRequired || [];
                            switch (t) {
                                case m.KHR_MATERIALS_UNLIT:
                                    o[t] = new A;
                                    break;
                                case m.KHR_DRACO_MESH_COMPRESSION:
                                    o[t] = new H(a, this.dracoLoader);
                                    break;
                                case m.KHR_TEXTURE_TRANSFORM:
                                    o[t] = new U;
                                    break;
                                case m.KHR_MESH_QUANTIZATION:
                                    o[t] = new G;
                                    break;
                                default:
                                    r.indexOf(t) >= 0 && void 0 === s[t] && console.warn('THREE.GLTFLoader: Unknown extension "' + t + '".')
                            }
                        }
                    l.setExtensions(o), l.setPlugins(s), l.parse(r, n)
                }
                parseAsync(e, t) {
                    let r = this;
                    return new Promise(function(n, i) {
                        r.parse(e, t, n, i)
                    })
                }
            }

            function p() {
                let e = {};
                return {
                    get: function(t) {
                        return e[t]
                    },
                    add: function(t, r) {
                        e[t] = r
                    },
                    remove: function(t) {
                        delete e[t]
                    },
                    removeAll: function() {
                        e = {}
                    }
                }
            }
            let m = {
                KHR_BINARY_GLTF: "KHR_binary_glTF",
                KHR_DRACO_MESH_COMPRESSION: "KHR_draco_mesh_compression",
                KHR_LIGHTS_PUNCTUAL: "KHR_lights_punctual",
                KHR_MATERIALS_CLEARCOAT: "KHR_materials_clearcoat",
                KHR_MATERIALS_DISPERSION: "KHR_materials_dispersion",
                KHR_MATERIALS_IOR: "KHR_materials_ior",
                KHR_MATERIALS_SHEEN: "KHR_materials_sheen",
                KHR_MATERIALS_SPECULAR: "KHR_materials_specular",
                KHR_MATERIALS_TRANSMISSION: "KHR_materials_transmission",
                KHR_MATERIALS_IRIDESCENCE: "KHR_materials_iridescence",
                KHR_MATERIALS_ANISOTROPY: "KHR_materials_anisotropy",
                KHR_MATERIALS_UNLIT: "KHR_materials_unlit",
                KHR_MATERIALS_VOLUME: "KHR_materials_volume",
                KHR_TEXTURE_BASISU: "KHR_texture_basisu",
                KHR_TEXTURE_TRANSFORM: "KHR_texture_transform",
                KHR_MESH_QUANTIZATION: "KHR_mesh_quantization",
                KHR_MATERIALS_EMISSIVE_STRENGTH: "KHR_materials_emissive_strength",
                EXT_MATERIALS_BUMP: "EXT_materials_bump",
                EXT_TEXTURE_WEBP: "EXT_texture_webp",
                EXT_TEXTURE_AVIF: "EXT_texture_avif",
                EXT_MESHOPT_COMPRESSION: "EXT_meshopt_compression",
                EXT_MESH_GPU_INSTANCING: "EXT_mesh_gpu_instancing"
            };
            class g {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_LIGHTS_PUNCTUAL, this.cache = {
                        refs: {},
                        uses: {}
                    }
                }
                _markDefs() {
                    let e = this.parser,
                        t = this.parser.json.nodes || [];
                    for (let r = 0, n = t.length; r < n; r++) {
                        let n = t[r];
                        n.extensions && n.extensions[this.name] && void 0 !== n.extensions[this.name].light && e._addNodeRef(this.cache, n.extensions[this.name].light)
                    }
                }
                _loadLight(e) {
                    let t;
                    let r = this.parser,
                        n = "light:" + e,
                        a = r.cache.get(n);
                    if (a) return a;
                    let o = r.json,
                        s = ((o.extensions && o.extensions[this.name] || {}).lights || [])[e],
                        l = new i.Color(16777215);
                    void 0 !== s.color && l.setRGB(s.color[0], s.color[1], s.color[2], f);
                    let u = void 0 !== s.range ? s.range : 0;
                    switch (s.type) {
                        case "directional":
                            (t = new i.DirectionalLight(l)).target.position.set(0, 0, -1), t.add(t.target);
                            break;
                        case "point":
                            (t = new i.PointLight(l)).distance = u;
                            break;
                        case "spot":
                            (t = new i.SpotLight(l)).distance = u, s.spot = s.spot || {}, s.spot.innerConeAngle = void 0 !== s.spot.innerConeAngle ? s.spot.innerConeAngle : 0, s.spot.outerConeAngle = void 0 !== s.spot.outerConeAngle ? s.spot.outerConeAngle : Math.PI / 4, t.angle = s.spot.outerConeAngle, t.penumbra = 1 - s.spot.innerConeAngle / s.spot.outerConeAngle, t.target.position.set(0, 0, -1), t.add(t.target);
                            break;
                        default:
                            throw Error("THREE.GLTFLoader: Unexpected light type: " + s.type)
                    }
                    return t.position.set(0, 0, 0), t.decay = 2, $(t, s), void 0 !== s.intensity && (t.intensity = s.intensity), t.name = r.createUniqueName(s.name || "light_" + e), a = Promise.resolve(t), r.cache.add(n, a), a
                }
                getDependency(e, t) {
                    if ("light" === e) return this._loadLight(t)
                }
                createNodeAttachment(e) {
                    let t = this,
                        r = this.parser,
                        n = r.json.nodes[e],
                        i = (n.extensions && n.extensions[this.name] || {}).light;
                    return void 0 === i ? null : this._loadLight(i).then(function(e) {
                        return r._getNodeRef(t.cache, i, e)
                    })
                }
            }
            class A {
                constructor() {
                    this.name = m.KHR_MATERIALS_UNLIT
                }
                getMaterialType() {
                    return i.MeshBasicMaterial
                }
                extendParams(e, t, r) {
                    let n = [];
                    e.color = new i.Color(1, 1, 1), e.opacity = 1;
                    let a = t.pbrMetallicRoughness;
                    if (a) {
                        if (Array.isArray(a.baseColorFactor)) {
                            let t = a.baseColorFactor;
                            e.color.setRGB(t[0], t[1], t[2], f), e.opacity = t[3]
                        }
                        void 0 !== a.baseColorTexture && n.push(r.assignTexture(e, "map", a.baseColorTexture, d))
                    }
                    return Promise.all(n)
                }
            }
            class v {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_EMISSIVE_STRENGTH
                }
                extendMaterialParams(e, t) {
                    let r = this.parser.json.materials[e];
                    if (!r.extensions || !r.extensions[this.name]) return Promise.resolve();
                    let n = r.extensions[this.name].emissiveStrength;
                    return void 0 !== n && (t.emissiveIntensity = n), Promise.resolve()
                }
            }
            class y {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_CLEARCOAT
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.MeshPhysicalMaterial : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let a = [],
                        o = n.extensions[this.name];
                    if (void 0 !== o.clearcoatFactor && (t.clearcoat = o.clearcoatFactor), void 0 !== o.clearcoatTexture && a.push(r.assignTexture(t, "clearcoatMap", o.clearcoatTexture)), void 0 !== o.clearcoatRoughnessFactor && (t.clearcoatRoughness = o.clearcoatRoughnessFactor), void 0 !== o.clearcoatRoughnessTexture && a.push(r.assignTexture(t, "clearcoatRoughnessMap", o.clearcoatRoughnessTexture)), void 0 !== o.clearcoatNormalTexture && (a.push(r.assignTexture(t, "clearcoatNormalMap", o.clearcoatNormalTexture)), void 0 !== o.clearcoatNormalTexture.scale)) {
                        let e = o.clearcoatNormalTexture.scale;
                        t.clearcoatNormalScale = new i.Vector2(e, e)
                    }
                    return Promise.all(a)
                }
            }
            class C {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_DISPERSION
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.MeshPhysicalMaterial : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser.json.materials[e];
                    if (!r.extensions || !r.extensions[this.name]) return Promise.resolve();
                    let n = r.extensions[this.name];
                    return t.dispersion = void 0 !== n.dispersion ? n.dispersion : 0, Promise.resolve()
                }
            }
            class B {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_IRIDESCENCE
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.MeshPhysicalMaterial : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let i = [],
                        a = n.extensions[this.name];
                    return void 0 !== a.iridescenceFactor && (t.iridescence = a.iridescenceFactor), void 0 !== a.iridescenceTexture && i.push(r.assignTexture(t, "iridescenceMap", a.iridescenceTexture)), void 0 !== a.iridescenceIor && (t.iridescenceIOR = a.iridescenceIor), void 0 === t.iridescenceThicknessRange && (t.iridescenceThicknessRange = [100, 400]), void 0 !== a.iridescenceThicknessMinimum && (t.iridescenceThicknessRange[0] = a.iridescenceThicknessMinimum), void 0 !== a.iridescenceThicknessMaximum && (t.iridescenceThicknessRange[1] = a.iridescenceThicknessMaximum), void 0 !== a.iridescenceThicknessTexture && i.push(r.assignTexture(t, "iridescenceThicknessMap", a.iridescenceThicknessTexture)), Promise.all(i)
                }
            }
            class _ {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_SHEEN
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.MeshPhysicalMaterial : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let a = [];
                    t.sheenColor = new i.Color(0, 0, 0), t.sheenRoughness = 0, t.sheen = 1;
                    let o = n.extensions[this.name];
                    if (void 0 !== o.sheenColorFactor) {
                        let e = o.sheenColorFactor;
                        t.sheenColor.setRGB(e[0], e[1], e[2], f)
                    }
                    return void 0 !== o.sheenRoughnessFactor && (t.sheenRoughness = o.sheenRoughnessFactor), void 0 !== o.sheenColorTexture && a.push(r.assignTexture(t, "sheenColorMap", o.sheenColorTexture, d)), void 0 !== o.sheenRoughnessTexture && a.push(r.assignTexture(t, "sheenRoughnessMap", o.sheenRoughnessTexture)), Promise.all(a)
                }
            }
            class b {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_TRANSMISSION
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.MeshPhysicalMaterial : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let i = [],
                        a = n.extensions[this.name];
                    return void 0 !== a.transmissionFactor && (t.transmission = a.transmissionFactor), void 0 !== a.transmissionTexture && i.push(r.assignTexture(t, "transmissionMap", a.transmissionTexture)), Promise.all(i)
                }
            }
            class E {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_VOLUME
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.MeshPhysicalMaterial : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let a = [],
                        o = n.extensions[this.name];
                    t.thickness = void 0 !== o.thicknessFactor ? o.thicknessFactor : 0, void 0 !== o.thicknessTexture && a.push(r.assignTexture(t, "thicknessMap", o.thicknessTexture)), t.attenuationDistance = o.attenuationDistance || 1 / 0;
                    let s = o.attenuationColor || [1, 1, 1];
                    return t.attenuationColor = new i.Color().setRGB(s[0], s[1], s[2], f), Promise.all(a)
                }
            }
            class w {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_IOR
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.MeshPhysicalMaterial : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser.json.materials[e];
                    if (!r.extensions || !r.extensions[this.name]) return Promise.resolve();
                    let n = r.extensions[this.name];
                    return t.ior = void 0 !== n.ior ? n.ior : 1.5, Promise.resolve()
                }
            }
            class M {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_SPECULAR
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.MeshPhysicalMaterial : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let a = [],
                        o = n.extensions[this.name];
                    t.specularIntensity = void 0 !== o.specularFactor ? o.specularFactor : 1, void 0 !== o.specularTexture && a.push(r.assignTexture(t, "specularIntensityMap", o.specularTexture));
                    let s = o.specularColorFactor || [1, 1, 1];
                    return t.specularColor = new i.Color().setRGB(s[0], s[1], s[2], f), void 0 !== o.specularColorTexture && a.push(r.assignTexture(t, "specularColorMap", o.specularColorTexture, d)), Promise.all(a)
                }
            }
            class T {
                constructor(e) {
                    this.parser = e, this.name = m.EXT_MATERIALS_BUMP
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.MeshPhysicalMaterial : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let i = [],
                        a = n.extensions[this.name];
                    return t.bumpScale = void 0 !== a.bumpFactor ? a.bumpFactor : 1, void 0 !== a.bumpTexture && i.push(r.assignTexture(t, "bumpMap", a.bumpTexture)), Promise.all(i)
                }
            }
            class x {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_ANISOTROPY
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.MeshPhysicalMaterial : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let i = [],
                        a = n.extensions[this.name];
                    return void 0 !== a.anisotropyStrength && (t.anisotropy = a.anisotropyStrength), void 0 !== a.anisotropyRotation && (t.anisotropyRotation = a.anisotropyRotation), void 0 !== a.anisotropyTexture && i.push(r.assignTexture(t, "anisotropyMap", a.anisotropyTexture)), Promise.all(i)
                }
            }
            class F {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_TEXTURE_BASISU
                }
                loadTexture(e) {
                    let t = this.parser,
                        r = t.json,
                        n = r.textures[e];
                    if (!n.extensions || !n.extensions[this.name]) return null;
                    let i = n.extensions[this.name],
                        a = t.options.ktx2Loader;
                    if (!a) {
                        if (!(r.extensionsRequired && r.extensionsRequired.indexOf(this.name) >= 0)) return null;
                        throw Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures")
                    }
                    return t.loadTextureImage(e, i.source, a)
                }
            }
            class S {
                constructor(e) {
                    this.parser = e, this.name = m.EXT_TEXTURE_WEBP, this.isSupported = null
                }
                loadTexture(e) {
                    let t = this.name,
                        r = this.parser,
                        n = r.json,
                        i = n.textures[e];
                    if (!i.extensions || !i.extensions[t]) return null;
                    let a = i.extensions[t],
                        o = n.images[a.source],
                        s = r.textureLoader;
                    if (o.uri) {
                        let e = r.options.manager.getHandler(o.uri);
                        null !== e && (s = e)
                    }
                    return this.detectSupport().then(function(i) {
                        if (i) return r.loadTextureImage(e, a.source, s);
                        if (n.extensionsRequired && n.extensionsRequired.indexOf(t) >= 0) throw Error("THREE.GLTFLoader: WebP required by asset but unsupported.");
                        return r.loadTexture(e)
                    })
                }
                detectSupport() {
                    return this.isSupported || (this.isSupported = new Promise(function(e) {
                        let t = new Image;
                        t.src = "data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA", t.onload = t.onerror = function() {
                            e(1 === t.height)
                        }
                    })), this.isSupported
                }
            }
            class R {
                constructor(e) {
                    this.parser = e, this.name = m.EXT_TEXTURE_AVIF, this.isSupported = null
                }
                loadTexture(e) {
                    let t = this.name,
                        r = this.parser,
                        n = r.json,
                        i = n.textures[e];
                    if (!i.extensions || !i.extensions[t]) return null;
                    let a = i.extensions[t],
                        o = n.images[a.source],
                        s = r.textureLoader;
                    if (o.uri) {
                        let e = r.options.manager.getHandler(o.uri);
                        null !== e && (s = e)
                    }
                    return this.detectSupport().then(function(i) {
                        if (i) return r.loadTextureImage(e, a.source, s);
                        if (n.extensionsRequired && n.extensionsRequired.indexOf(t) >= 0) throw Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");
                        return r.loadTexture(e)
                    })
                }
                detectSupport() {
                    return this.isSupported || (this.isSupported = new Promise(function(e) {
                        let t = new Image;
                        t.src = "data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=", t.onload = t.onerror = function() {
                            e(1 === t.height)
                        }
                    })), this.isSupported
                }
            }
            class O {
                constructor(e) {
                    this.name = m.EXT_MESHOPT_COMPRESSION, this.parser = e
                }
                loadBufferView(e) {
                    let t = this.parser.json,
                        r = t.bufferViews[e];
                    if (!r.extensions || !r.extensions[this.name]) return null; {
                        let e = r.extensions[this.name],
                            n = this.parser.getDependency("buffer", e.buffer),
                            i = this.parser.options.meshoptDecoder;
                        if (!i || !i.supported) {
                            if (!(t.extensionsRequired && t.extensionsRequired.indexOf(this.name) >= 0)) return null;
                            throw Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files")
                        }
                        return n.then(function(t) {
                            let r = e.byteOffset || 0,
                                n = e.byteLength || 0,
                                a = e.count,
                                o = e.byteStride,
                                s = new Uint8Array(t, r, n);
                            return i.decodeGltfBufferAsync ? i.decodeGltfBufferAsync(a, o, s, e.mode, e.filter).then(function(e) {
                                return e.buffer
                            }) : i.ready.then(function() {
                                let t = new ArrayBuffer(a * o);
                                return i.decodeGltfBuffer(new Uint8Array(t), a, o, s, e.mode, e.filter), t
                            })
                        })
                    }
                }
            }
            class I {
                constructor(e) {
                    this.name = m.EXT_MESH_GPU_INSTANCING, this.parser = e
                }
                createNodeMesh(e) {
                    let t = this.parser.json,
                        r = t.nodes[e];
                    if (!r.extensions || !r.extensions[this.name] || void 0 === r.mesh) return null;
                    for (let e of t.meshes[r.mesh].primitives)
                        if (e.mode !== z.TRIANGLES && e.mode !== z.TRIANGLE_STRIP && e.mode !== z.TRIANGLE_FAN && void 0 !== e.mode) return null;
                    let n = r.extensions[this.name].attributes,
                        a = [],
                        o = {};
                    for (let e in n) a.push(this.parser.getDependency("accessor", n[e]).then(t => (o[e] = t, o[e])));
                    return a.length < 1 ? null : (a.push(this.parser.createNodeMesh(e)), Promise.all(a).then(e => {
                        let t = e.pop(),
                            r = t.isGroup ? t.children : [t],
                            n = e[0].count,
                            a = [];
                        for (let e of r) {
                            let t = new i.Matrix4,
                                r = new i.Vector3,
                                s = new i.Quaternion,
                                l = new i.Vector3(1, 1, 1),
                                u = new i.InstancedMesh(e.geometry, e.material, n);
                            for (let e = 0; e < n; e++) o.TRANSLATION && r.fromBufferAttribute(o.TRANSLATION, e), o.ROTATION && s.fromBufferAttribute(o.ROTATION, e), o.SCALE && l.fromBufferAttribute(o.SCALE, e), u.setMatrixAt(e, t.compose(r, s, l));
                            for (let t in o)
                                if ("_COLOR_0" === t) {
                                    let e = o[t];
                                    u.instanceColor = new i.InstancedBufferAttribute(e.array, e.itemSize, e.normalized)
                                } else "TRANSLATION" !== t && "ROTATION" !== t && "SCALE" !== t && e.geometry.setAttribute(t, o[t]);
                            i.Object3D.prototype.copy.call(u, e), this.parser.assignFinalMaterial(u), a.push(u)
                        }
                        return t.isGroup ? (t.clear(), t.add(...a), t) : a[0]
                    }))
                }
            }
            let D = "glTF",
                P = {
                    JSON: 1313821514,
                    BIN: 5130562
                };
            class L {
                constructor(e) {
                    this.name = m.KHR_BINARY_GLTF, this.content = null, this.body = null;
                    let t = new DataView(e, 0, 12);
                    if (this.header = {
                            magic: i.LoaderUtils.decodeText(new Uint8Array(e.slice(0, 4))),
                            version: t.getUint32(4, !0),
                            length: t.getUint32(8, !0)
                        }, this.header.magic !== D) throw Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");
                    if (this.header.version < 2) throw Error("THREE.GLTFLoader: Legacy binary file detected.");
                    let r = this.header.length - 12,
                        n = new DataView(e, 12),
                        a = 0;
                    for (; a < r;) {
                        let t = n.getUint32(a, !0);
                        a += 4;
                        let r = n.getUint32(a, !0);
                        if (a += 4, r === P.JSON) {
                            let r = new Uint8Array(e, 12 + a, t);
                            this.content = i.LoaderUtils.decodeText(r)
                        } else if (r === P.BIN) {
                            let r = 12 + a;
                            this.body = e.slice(r, r + t)
                        }
                        a += t
                    }
                    if (null === this.content) throw Error("THREE.GLTFLoader: JSON content not found.")
                }
            }
            class H {
                constructor(e, t) {
                    if (!t) throw Error("THREE.GLTFLoader: No DRACOLoader instance provided.");
                    this.name = m.KHR_DRACO_MESH_COMPRESSION, this.json = e, this.dracoLoader = t, this.dracoLoader.preload()
                }
                decodePrimitive(e, t) {
                    let r = this.json,
                        n = this.dracoLoader,
                        i = e.extensions[this.name].bufferView,
                        a = e.extensions[this.name].attributes,
                        o = {},
                        s = {},
                        l = {};
                    for (let e in a) o[Y[e] || e.toLowerCase()] = a[e];
                    for (let t in e.attributes) {
                        let n = Y[t] || t.toLowerCase();
                        if (void 0 !== a[t]) {
                            let i = r.accessors[e.attributes[t]],
                                a = j[i.componentType];
                            l[n] = a.name, s[n] = !0 === i.normalized
                        }
                    }
                    return t.getDependency("bufferView", i).then(function(e) {
                        return new Promise(function(t, r) {
                            n.decodeDracoFile(e, function(e) {
                                for (let t in e.attributes) {
                                    let r = e.attributes[t],
                                        n = s[t];
                                    void 0 !== n && (r.normalized = n)
                                }
                                t(e)
                            }, o, l, f, r)
                        })
                    })
                }
            }
            class U {
                constructor() {
                    this.name = m.KHR_TEXTURE_TRANSFORM
                }
                extendTexture(e, t) {
                    return (void 0 === t.texCoord || t.texCoord === e.channel) && void 0 === t.offset && void 0 === t.rotation && void 0 === t.scale || (e = e.clone(), void 0 !== t.texCoord && (e.channel = t.texCoord), void 0 !== t.offset && e.offset.fromArray(t.offset), void 0 !== t.rotation && (e.rotation = t.rotation), void 0 !== t.scale && e.repeat.fromArray(t.scale), e.needsUpdate = !0), e
                }
            }
            class G {
                constructor() {
                    this.name = m.KHR_MESH_QUANTIZATION
                }
            }
            class k extends i.Interpolant {
                constructor(e, t, r, n) {
                    super(e, t, r, n)
                }
                copySampleValue_(e) {
                    let t = this.resultBuffer,
                        r = this.sampleValues,
                        n = this.valueSize,
                        i = e * n * 3 + n;
                    for (let e = 0; e !== n; e++) t[e] = r[i + e];
                    return t
                }
                interpolate_(e, t, r, n) {
                    let i = this.resultBuffer,
                        a = this.sampleValues,
                        o = this.valueSize,
                        s = 2 * o,
                        l = 3 * o,
                        u = n - t,
                        c = (r - t) / u,
                        d = c * c,
                        f = d * c,
                        h = e * l,
                        p = h - l,
                        m = -2 * f + 3 * d,
                        g = f - d,
                        A = 1 - m,
                        v = g - d + c;
                    for (let e = 0; e !== o; e++) {
                        let t = a[p + e + o],
                            r = a[p + e + s] * u,
                            n = a[h + e + o],
                            l = a[h + e] * u;
                        i[e] = A * t + v * r + m * n + g * l
                    }
                    return i
                }
            }
            let N = new i.Quaternion;
            class J extends k {
                interpolate_(e, t, r, n) {
                    let i = super.interpolate_(e, t, r, n);
                    return N.fromArray(i).normalize().toArray(i), i
                }
            }
            let z = {
                    POINTS: 0,
                    LINES: 1,
                    LINE_LOOP: 2,
                    LINE_STRIP: 3,
                    TRIANGLES: 4,
                    TRIANGLE_STRIP: 5,
                    TRIANGLE_FAN: 6
                },
                j = {
                    5120: Int8Array,
                    5121: Uint8Array,
                    5122: Int16Array,
                    5123: Uint16Array,
                    5125: Uint32Array,
                    5126: Float32Array
                },
                K = {
                    9728: i.NearestFilter,
                    9729: i.LinearFilter,
                    9984: i.NearestMipmapNearestFilter,
                    9985: i.LinearMipmapNearestFilter,
                    9986: i.NearestMipmapLinearFilter,
                    9987: i.LinearMipmapLinearFilter
                },
                Q = {
                    33071: i.ClampToEdgeWrapping,
                    33648: i.MirroredRepeatWrapping,
                    10497: i.RepeatWrapping
                },
                V = {
                    SCALAR: 1,
                    VEC2: 2,
                    VEC3: 3,
                    VEC4: 4,
                    MAT2: 4,
                    MAT3: 9,
                    MAT4: 16
                },
                Y = {
                    POSITION: "position",
                    NORMAL: "normal",
                    TANGENT: "tangent",
                    ...c >= 152 ? {
                        TEXCOORD_0: "uv",
                        TEXCOORD_1: "uv1",
                        TEXCOORD_2: "uv2",
                        TEXCOORD_3: "uv3"
                    } : {
                        TEXCOORD_0: "uv",
                        TEXCOORD_1: "uv2"
                    },
                    COLOR_0: "color",
                    WEIGHTS_0: "skinWeight",
                    JOINTS_0: "skinIndex"
                },
                X = {
                    scale: "scale",
                    translation: "position",
                    rotation: "quaternion",
                    weights: "morphTargetInfluences"
                },
                W = {
                    CUBICSPLINE: void 0,
                    LINEAR: i.InterpolateLinear,
                    STEP: i.InterpolateDiscrete
                },
                Z = {
                    OPAQUE: "OPAQUE",
                    MASK: "MASK",
                    BLEND: "BLEND"
                };

            function q(e, t, r) {
                for (let n in r.extensions) void 0 === e[n] && (t.userData.gltfExtensions = t.userData.gltfExtensions || {}, t.userData.gltfExtensions[n] = r.extensions[n])
            }

            function $(e, t) {
                void 0 !== t.extras && ("object" == typeof t.extras ? Object.assign(e.userData, t.extras) : console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, " + t.extras))
            }

            function ee(e) {
                let t = "",
                    r = Object.keys(e).sort();
                for (let n = 0, i = r.length; n < i; n++) t += r[n] + ":" + e[r[n]] + ";";
                return t
            }

            function et(e) {
                switch (e) {
                    case Int8Array:
                        return 1 / 127;
                    case Uint8Array:
                        return 1 / 255;
                    case Int16Array:
                        return 1 / 32767;
                    case Uint16Array:
                        return 1 / 65535;
                    default:
                        throw Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")
                }
            }
            let er = new i.Matrix4;
            class en {
                constructor(e = {}, t = {}) {
                    this.json = e, this.extensions = {}, this.plugins = {}, this.options = t, this.cache = new p, this.associations = new Map, this.primitiveCache = {}, this.nodeCache = {}, this.meshCache = {
                        refs: {},
                        uses: {}
                    }, this.cameraCache = {
                        refs: {},
                        uses: {}
                    }, this.lightCache = {
                        refs: {},
                        uses: {}
                    }, this.sourceCache = {}, this.textureCache = {}, this.nodeNamesUsed = {};
                    let r = !1,
                        n = !1,
                        a = -1;
                    "undefined" != typeof navigator && void 0 !== navigator.userAgent && (r = !0 === /^((?!chrome|android).)*safari/i.test(navigator.userAgent), a = (n = navigator.userAgent.indexOf("Firefox") > -1) ? navigator.userAgent.match(/Firefox\/([0-9]+)\./)[1] : -1), "undefined" == typeof createImageBitmap || r || n && a < 98 ? this.textureLoader = new i.TextureLoader(this.options.manager) : this.textureLoader = new i.ImageBitmapLoader(this.options.manager), this.textureLoader.setCrossOrigin(this.options.crossOrigin), this.textureLoader.setRequestHeader(this.options.requestHeader), this.fileLoader = new i.FileLoader(this.options.manager), this.fileLoader.setResponseType("arraybuffer"), "use-credentials" === this.options.crossOrigin && this.fileLoader.setWithCredentials(!0)
                }
                setExtensions(e) {
                    this.extensions = e
                }
                setPlugins(e) {
                    this.plugins = e
                }
                parse(e, t) {
                    let r = this,
                        n = this.json,
                        i = this.extensions;
                    this.cache.removeAll(), this.nodeCache = {}, this._invokeAll(function(e) {
                        return e._markDefs && e._markDefs()
                    }), Promise.all(this._invokeAll(function(e) {
                        return e.beforeRoot && e.beforeRoot()
                    })).then(function() {
                        return Promise.all([r.getDependencies("scene"), r.getDependencies("animation"), r.getDependencies("camera")])
                    }).then(function(t) {
                        let a = {
                            scene: t[0][n.scene || 0],
                            scenes: t[0],
                            animations: t[1],
                            cameras: t[2],
                            asset: n.asset,
                            parser: r,
                            userData: {}
                        };
                        return q(i, a, n), $(a, n), Promise.all(r._invokeAll(function(e) {
                            return e.afterRoot && e.afterRoot(a)
                        })).then(function() {
                            for (let e of a.scenes) e.updateMatrixWorld();
                            e(a)
                        })
                    }).catch(t)
                }
                _markDefs() {
                    let e = this.json.nodes || [],
                        t = this.json.skins || [],
                        r = this.json.meshes || [];
                    for (let r = 0, n = t.length; r < n; r++) {
                        let n = t[r].joints;
                        for (let t = 0, r = n.length; t < r; t++) e[n[t]].isBone = !0
                    }
                    for (let t = 0, n = e.length; t < n; t++) {
                        let n = e[t];
                        void 0 !== n.mesh && (this._addNodeRef(this.meshCache, n.mesh), void 0 !== n.skin && (r[n.mesh].isSkinnedMesh = !0)), void 0 !== n.camera && this._addNodeRef(this.cameraCache, n.camera)
                    }
                }
                _addNodeRef(e, t) {
                    void 0 !== t && (void 0 === e.refs[t] && (e.refs[t] = e.uses[t] = 0), e.refs[t]++)
                }
                _getNodeRef(e, t, r) {
                    if (e.refs[t] <= 1) return r;
                    let n = r.clone(),
                        i = (e, t) => {
                            let r = this.associations.get(e);
                            for (let [n, a] of (null != r && this.associations.set(t, r), e.children.entries())) i(a, t.children[n])
                        };
                    return i(r, n), n.name += "_instance_" + e.uses[t]++, n
                }
                _invokeOne(e) {
                    let t = Object.values(this.plugins);
                    t.push(this);
                    for (let r = 0; r < t.length; r++) {
                        let n = e(t[r]);
                        if (n) return n
                    }
                    return null
                }
                _invokeAll(e) {
                    let t = Object.values(this.plugins);
                    t.unshift(this);
                    let r = [];
                    for (let n = 0; n < t.length; n++) {
                        let i = e(t[n]);
                        i && r.push(i)
                    }
                    return r
                }
                getDependency(e, t) {
                    let r = e + ":" + t,
                        n = this.cache.get(r);
                    if (!n) {
                        switch (e) {
                            case "scene":
                                n = this.loadScene(t);
                                break;
                            case "node":
                                n = this._invokeOne(function(e) {
                                    return e.loadNode && e.loadNode(t)
                                });
                                break;
                            case "mesh":
                                n = this._invokeOne(function(e) {
                                    return e.loadMesh && e.loadMesh(t)
                                });
                                break;
                            case "accessor":
                                n = this.loadAccessor(t);
                                break;
                            case "bufferView":
                                n = this._invokeOne(function(e) {
                                    return e.loadBufferView && e.loadBufferView(t)
                                });
                                break;
                            case "buffer":
                                n = this.loadBuffer(t);
                                break;
                            case "material":
                                n = this._invokeOne(function(e) {
                                    return e.loadMaterial && e.loadMaterial(t)
                                });
                                break;
                            case "texture":
                                n = this._invokeOne(function(e) {
                                    return e.loadTexture && e.loadTexture(t)
                                });
                                break;
                            case "skin":
                                n = this.loadSkin(t);
                                break;
                            case "animation":
                                n = this._invokeOne(function(e) {
                                    return e.loadAnimation && e.loadAnimation(t)
                                });
                                break;
                            case "camera":
                                n = this.loadCamera(t);
                                break;
                            default:
                                if (!(n = this._invokeOne(function(r) {
                                        return r != this && r.getDependency && r.getDependency(e, t)
                                    }))) throw Error("Unknown type: " + e)
                        }
                        this.cache.add(r, n)
                    }
                    return n
                }
                getDependencies(e) {
                    let t = this.cache.get(e);
                    if (!t) {
                        let r = this;
                        t = Promise.all((this.json[e + ("mesh" === e ? "es" : "s")] || []).map(function(t, n) {
                            return r.getDependency(e, n)
                        })), this.cache.add(e, t)
                    }
                    return t
                }
                loadBuffer(e) {
                    let t = this.json.buffers[e],
                        r = this.fileLoader;
                    if (t.type && "arraybuffer" !== t.type) throw Error("THREE.GLTFLoader: " + t.type + " buffer type is not supported.");
                    if (void 0 === t.uri && 0 === e) return Promise.resolve(this.extensions[m.KHR_BINARY_GLTF].body);
                    let n = this.options;
                    return new Promise(function(e, a) {
                        r.load(i.LoaderUtils.resolveURL(t.uri, n.path), e, void 0, function() {
                            a(Error('THREE.GLTFLoader: Failed to load buffer "' + t.uri + '".'))
                        })
                    })
                }
                loadBufferView(e) {
                    let t = this.json.bufferViews[e];
                    return this.getDependency("buffer", t.buffer).then(function(e) {
                        let r = t.byteLength || 0,
                            n = t.byteOffset || 0;
                        return e.slice(n, n + r)
                    })
                }
                loadAccessor(e) {
                    let t = this,
                        r = this.json,
                        n = this.json.accessors[e];
                    if (void 0 === n.bufferView && void 0 === n.sparse) {
                        let e = V[n.type],
                            t = j[n.componentType],
                            r = !0 === n.normalized,
                            a = new t(n.count * e);
                        return Promise.resolve(new i.BufferAttribute(a, e, r))
                    }
                    let a = [];
                    return void 0 !== n.bufferView ? a.push(this.getDependency("bufferView", n.bufferView)) : a.push(null), void 0 !== n.sparse && (a.push(this.getDependency("bufferView", n.sparse.indices.bufferView)), a.push(this.getDependency("bufferView", n.sparse.values.bufferView))), Promise.all(a).then(function(e) {
                        let a, o;
                        let s = e[0],
                            l = V[n.type],
                            u = j[n.componentType],
                            c = u.BYTES_PER_ELEMENT,
                            d = c * l,
                            f = n.byteOffset || 0,
                            h = void 0 !== n.bufferView ? r.bufferViews[n.bufferView].byteStride : void 0,
                            p = !0 === n.normalized;
                        if (h && h !== d) {
                            let e = Math.floor(f / h),
                                r = "InterleavedBuffer:" + n.bufferView + ":" + n.componentType + ":" + e + ":" + n.count,
                                d = t.cache.get(r);
                            d || (a = new u(s, e * h, n.count * h / c), d = new i.InterleavedBuffer(a, h / c), t.cache.add(r, d)), o = new i.InterleavedBufferAttribute(d, l, f % h / c, p)
                        } else a = null === s ? new u(n.count * l) : new u(s, f, n.count * l), o = new i.BufferAttribute(a, l, p);
                        if (void 0 !== n.sparse) {
                            let t = V.SCALAR,
                                r = j[n.sparse.indices.componentType],
                                a = n.sparse.indices.byteOffset || 0,
                                c = n.sparse.values.byteOffset || 0,
                                d = new r(e[1], a, n.sparse.count * t),
                                f = new u(e[2], c, n.sparse.count * l);
                            null !== s && (o = new i.BufferAttribute(o.array.slice(), o.itemSize, o.normalized));
                            for (let e = 0, t = d.length; e < t; e++) {
                                let t = d[e];
                                if (o.setX(t, f[e * l]), l >= 2 && o.setY(t, f[e * l + 1]), l >= 3 && o.setZ(t, f[e * l + 2]), l >= 4 && o.setW(t, f[e * l + 3]), l >= 5) throw Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")
                            }
                        }
                        return o
                    })
                }
                loadTexture(e) {
                    let t = this.json,
                        r = this.options,
                        n = t.textures[e].source,
                        i = t.images[n],
                        a = this.textureLoader;
                    if (i.uri) {
                        let e = r.manager.getHandler(i.uri);
                        null !== e && (a = e)
                    }
                    return this.loadTextureImage(e, n, a)
                }
                loadTextureImage(e, t, r) {
                    let n = this,
                        a = this.json,
                        o = a.textures[e],
                        s = a.images[t],
                        l = (s.uri || s.bufferView) + ":" + o.sampler;
                    if (this.textureCache[l]) return this.textureCache[l];
                    let u = this.loadImageSource(t, r).then(function(t) {
                        t.flipY = !1, t.name = o.name || s.name || "", "" === t.name && "string" == typeof s.uri && !1 === s.uri.startsWith("data:image/") && (t.name = s.uri);
                        let r = (a.samplers || {})[o.sampler] || {};
                        return t.magFilter = K[r.magFilter] || i.LinearFilter, t.minFilter = K[r.minFilter] || i.LinearMipmapLinearFilter, t.wrapS = Q[r.wrapS] || i.RepeatWrapping, t.wrapT = Q[r.wrapT] || i.RepeatWrapping, n.associations.set(t, {
                            textures: e
                        }), t
                    }).catch(function() {
                        return null
                    });
                    return this.textureCache[l] = u, u
                }
                loadImageSource(e, t) {
                    let r = this.json,
                        n = this.options;
                    if (void 0 !== this.sourceCache[e]) return this.sourceCache[e].then(e => e.clone());
                    let a = r.images[e],
                        o = self.URL || self.webkitURL,
                        s = a.uri || "",
                        l = !1;
                    if (void 0 !== a.bufferView) s = this.getDependency("bufferView", a.bufferView).then(function(e) {
                        l = !0;
                        let t = new Blob([e], {
                            type: a.mimeType
                        });
                        return s = o.createObjectURL(t)
                    });
                    else if (void 0 === a.uri) throw Error("THREE.GLTFLoader: Image " + e + " is missing URI and bufferView");
                    let u = Promise.resolve(s).then(function(e) {
                        return new Promise(function(r, a) {
                            let o = r;
                            !0 === t.isImageBitmapLoader && (o = function(e) {
                                let t = new i.Texture(e);
                                t.needsUpdate = !0, r(t)
                            }), t.load(i.LoaderUtils.resolveURL(e, n.path), o, void 0, a)
                        })
                    }).then(function(e) {
                        var t;
                        return !0 === l && o.revokeObjectURL(s), $(e, a), e.userData.mimeType = a.mimeType || ((t = a.uri).search(/\.jpe?g($|\?)/i) > 0 || 0 === t.search(/^data\:image\/jpeg/) ? "image/jpeg" : t.search(/\.webp($|\?)/i) > 0 || 0 === t.search(/^data\:image\/webp/) ? "image/webp" : "image/png"), e
                    }).catch(function(e) {
                        throw console.error("THREE.GLTFLoader: Couldn't load texture", s), e
                    });
                    return this.sourceCache[e] = u, u
                }
                assignTexture(e, t, r, n) {
                    let i = this;
                    return this.getDependency("texture", r.index).then(function(a) {
                        if (!a) return null;
                        if (void 0 !== r.texCoord && r.texCoord > 0 && ((a = a.clone()).channel = r.texCoord), i.extensions[m.KHR_TEXTURE_TRANSFORM]) {
                            let e = void 0 !== r.extensions ? r.extensions[m.KHR_TEXTURE_TRANSFORM] : void 0;
                            if (e) {
                                let t = i.associations.get(a);
                                a = i.extensions[m.KHR_TEXTURE_TRANSFORM].extendTexture(a, e), i.associations.set(a, t)
                            }
                        }
                        return void 0 !== n && ("number" == typeof n && (n = 3001 === n ? d : f), "colorSpace" in a ? a.colorSpace = n : a.encoding = n === d ? 3001 : 3e3), e[t] = a, a
                    })
                }
                assignFinalMaterial(e) {
                    let t = e.geometry,
                        r = e.material,
                        n = void 0 === t.attributes.tangent,
                        a = void 0 !== t.attributes.color,
                        o = void 0 === t.attributes.normal;
                    if (e.isPoints) {
                        let e = "PointsMaterial:" + r.uuid,
                            t = this.cache.get(e);
                        t || (t = new i.PointsMaterial, i.Material.prototype.copy.call(t, r), t.color.copy(r.color), t.map = r.map, t.sizeAttenuation = !1, this.cache.add(e, t)), r = t
                    } else if (e.isLine) {
                        let e = "LineBasicMaterial:" + r.uuid,
                            t = this.cache.get(e);
                        t || (t = new i.LineBasicMaterial, i.Material.prototype.copy.call(t, r), t.color.copy(r.color), t.map = r.map, this.cache.add(e, t)), r = t
                    }
                    if (n || a || o) {
                        let e = "ClonedMaterial:" + r.uuid + ":";
                        n && (e += "derivative-tangents:"), a && (e += "vertex-colors:"), o && (e += "flat-shading:");
                        let t = this.cache.get(e);
                        t || (t = r.clone(), a && (t.vertexColors = !0), o && (t.flatShading = !0), n && (t.normalScale && (t.normalScale.y *= -1), t.clearcoatNormalScale && (t.clearcoatNormalScale.y *= -1)), this.cache.add(e, t), this.associations.set(t, this.associations.get(r))), r = t
                    }
                    e.material = r
                }
                getMaterialType() {
                    return i.MeshStandardMaterial
                }
                loadMaterial(e) {
                    let t;
                    let r = this,
                        n = this.json,
                        a = this.extensions,
                        o = n.materials[e],
                        s = {},
                        l = o.extensions || {},
                        u = [];
                    if (l[m.KHR_MATERIALS_UNLIT]) {
                        let e = a[m.KHR_MATERIALS_UNLIT];
                        t = e.getMaterialType(), u.push(e.extendParams(s, o, r))
                    } else {
                        let n = o.pbrMetallicRoughness || {};
                        if (s.color = new i.Color(1, 1, 1), s.opacity = 1, Array.isArray(n.baseColorFactor)) {
                            let e = n.baseColorFactor;
                            s.color.setRGB(e[0], e[1], e[2], f), s.opacity = e[3]
                        }
                        void 0 !== n.baseColorTexture && u.push(r.assignTexture(s, "map", n.baseColorTexture, d)), s.metalness = void 0 !== n.metallicFactor ? n.metallicFactor : 1, s.roughness = void 0 !== n.roughnessFactor ? n.roughnessFactor : 1, void 0 !== n.metallicRoughnessTexture && (u.push(r.assignTexture(s, "metalnessMap", n.metallicRoughnessTexture)), u.push(r.assignTexture(s, "roughnessMap", n.metallicRoughnessTexture))), t = this._invokeOne(function(t) {
                            return t.getMaterialType && t.getMaterialType(e)
                        }), u.push(Promise.all(this._invokeAll(function(t) {
                            return t.extendMaterialParams && t.extendMaterialParams(e, s)
                        })))
                    }!0 === o.doubleSided && (s.side = i.DoubleSide);
                    let c = o.alphaMode || Z.OPAQUE;
                    if (c === Z.BLEND ? (s.transparent = !0, s.depthWrite = !1) : (s.transparent = !1, c === Z.MASK && (s.alphaTest = void 0 !== o.alphaCutoff ? o.alphaCutoff : .5)), void 0 !== o.normalTexture && t !== i.MeshBasicMaterial && (u.push(r.assignTexture(s, "normalMap", o.normalTexture)), s.normalScale = new i.Vector2(1, 1), void 0 !== o.normalTexture.scale)) {
                        let e = o.normalTexture.scale;
                        s.normalScale.set(e, e)
                    }
                    if (void 0 !== o.occlusionTexture && t !== i.MeshBasicMaterial && (u.push(r.assignTexture(s, "aoMap", o.occlusionTexture)), void 0 !== o.occlusionTexture.strength && (s.aoMapIntensity = o.occlusionTexture.strength)), void 0 !== o.emissiveFactor && t !== i.MeshBasicMaterial) {
                        let e = o.emissiveFactor;
                        s.emissive = new i.Color().setRGB(e[0], e[1], e[2], f)
                    }
                    return void 0 !== o.emissiveTexture && t !== i.MeshBasicMaterial && u.push(r.assignTexture(s, "emissiveMap", o.emissiveTexture, d)), Promise.all(u).then(function() {
                        let n = new t(s);
                        return o.name && (n.name = o.name), $(n, o), r.associations.set(n, {
                            materials: e
                        }), o.extensions && q(a, n, o), n
                    })
                }
                createUniqueName(e) {
                    let t = i.PropertyBinding.sanitizeNodeName(e || "");
                    return t in this.nodeNamesUsed ? t + "_" + ++this.nodeNamesUsed[t] : (this.nodeNamesUsed[t] = 0, t)
                }
                loadGeometries(e) {
                    let t = this,
                        r = this.extensions,
                        n = this.primitiveCache,
                        a = [];
                    for (let o = 0, s = e.length; o < s; o++) {
                        let s = e[o],
                            l = function(e) {
                                let t;
                                let r = e.extensions && e.extensions[m.KHR_DRACO_MESH_COMPRESSION];
                                if (t = r ? "draco:" + r.bufferView + ":" + r.indices + ":" + ee(r.attributes) : e.indices + ":" + ee(e.attributes) + ":" + e.mode, void 0 !== e.targets)
                                    for (let r = 0, n = e.targets.length; r < n; r++) t += ":" + ee(e.targets[r]);
                                return t
                            }(s),
                            u = n[l];
                        if (u) a.push(u.promise);
                        else {
                            let e;
                            e = s.extensions && s.extensions[m.KHR_DRACO_MESH_COMPRESSION] ? function(e) {
                                return r[m.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(e, t).then(function(r) {
                                    return ei(r, e, t)
                                })
                            }(s) : ei(new i.BufferGeometry, s, t), n[l] = {
                                primitive: s,
                                promise: e
                            }, a.push(e)
                        }
                    }
                    return Promise.all(a)
                }
                loadMesh(e) {
                    let t = this,
                        r = this.json,
                        n = this.extensions,
                        a = r.meshes[e],
                        o = a.primitives,
                        s = [];
                    for (let e = 0, t = o.length; e < t; e++) {
                        var l;
                        let t = void 0 === o[e].material ? (void 0 === (l = this.cache).DefaultMaterial && (l.DefaultMaterial = new i.MeshStandardMaterial({
                            color: 16777215,
                            emissive: 0,
                            metalness: 1,
                            roughness: 1,
                            transparent: !1,
                            depthTest: !0,
                            side: i.FrontSide
                        })), l.DefaultMaterial) : this.getDependency("material", o[e].material);
                        s.push(t)
                    }
                    return s.push(t.loadGeometries(o)), Promise.all(s).then(function(r) {
                        let s = r.slice(0, r.length - 1),
                            l = r[r.length - 1],
                            c = [];
                        for (let r = 0, d = l.length; r < d; r++) {
                            let d;
                            let f = l[r],
                                h = o[r],
                                p = s[r];
                            if (h.mode === z.TRIANGLES || h.mode === z.TRIANGLE_STRIP || h.mode === z.TRIANGLE_FAN || void 0 === h.mode) !0 === (d = !0 === a.isSkinnedMesh ? new i.SkinnedMesh(f, p) : new i.Mesh(f, p)).isSkinnedMesh && d.normalizeSkinWeights(), h.mode === z.TRIANGLE_STRIP ? d.geometry = u(d.geometry, i.TriangleStripDrawMode) : h.mode === z.TRIANGLE_FAN && (d.geometry = u(d.geometry, i.TriangleFanDrawMode));
                            else if (h.mode === z.LINES) d = new i.LineSegments(f, p);
                            else if (h.mode === z.LINE_STRIP) d = new i.Line(f, p);
                            else if (h.mode === z.LINE_LOOP) d = new i.LineLoop(f, p);
                            else if (h.mode === z.POINTS) d = new i.Points(f, p);
                            else throw Error("THREE.GLTFLoader: Primitive mode unsupported: " + h.mode);
                            Object.keys(d.geometry.morphAttributes).length > 0 && function(e, t) {
                                if (e.updateMorphTargets(), void 0 !== t.weights)
                                    for (let r = 0, n = t.weights.length; r < n; r++) e.morphTargetInfluences[r] = t.weights[r];
                                if (t.extras && Array.isArray(t.extras.targetNames)) {
                                    let r = t.extras.targetNames;
                                    if (e.morphTargetInfluences.length === r.length) {
                                        e.morphTargetDictionary = {};
                                        for (let t = 0, n = r.length; t < n; t++) e.morphTargetDictionary[r[t]] = t
                                    } else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")
                                }
                            }(d, a), d.name = t.createUniqueName(a.name || "mesh_" + e), $(d, a), h.extensions && q(n, d, h), t.assignFinalMaterial(d), c.push(d)
                        }
                        for (let r = 0, n = c.length; r < n; r++) t.associations.set(c[r], {
                            meshes: e,
                            primitives: r
                        });
                        if (1 === c.length) return a.extensions && q(n, c[0], a), c[0];
                        let d = new i.Group;
                        a.extensions && q(n, d, a), t.associations.set(d, {
                            meshes: e
                        });
                        for (let e = 0, t = c.length; e < t; e++) d.add(c[e]);
                        return d
                    })
                }
                loadCamera(e) {
                    let t;
                    let r = this.json.cameras[e],
                        n = r[r.type];
                    if (!n) {
                        console.warn("THREE.GLTFLoader: Missing camera parameters.");
                        return
                    }
                    return "perspective" === r.type ? t = new i.PerspectiveCamera(i.MathUtils.radToDeg(n.yfov), n.aspectRatio || 1, n.znear || 1, n.zfar || 2e6) : "orthographic" === r.type && (t = new i.OrthographicCamera(-n.xmag, n.xmag, n.ymag, -n.ymag, n.znear, n.zfar)), r.name && (t.name = this.createUniqueName(r.name)), $(t, r), Promise.resolve(t)
                }
                loadSkin(e) {
                    let t = this.json.skins[e],
                        r = [];
                    for (let e = 0, n = t.joints.length; e < n; e++) r.push(this._loadNodeShallow(t.joints[e]));
                    return void 0 !== t.inverseBindMatrices ? r.push(this.getDependency("accessor", t.inverseBindMatrices)) : r.push(null), Promise.all(r).then(function(e) {
                        let r = e.pop(),
                            n = [],
                            a = [];
                        for (let o = 0, s = e.length; o < s; o++) {
                            let s = e[o];
                            if (s) {
                                n.push(s);
                                let e = new i.Matrix4;
                                null !== r && e.fromArray(r.array, 16 * o), a.push(e)
                            } else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.', t.joints[o])
                        }
                        return new i.Skeleton(n, a)
                    })
                }
                loadAnimation(e) {
                    let t = this.json,
                        r = this,
                        n = t.animations[e],
                        a = n.name ? n.name : "animation_" + e,
                        o = [],
                        s = [],
                        l = [],
                        u = [],
                        c = [];
                    for (let e = 0, t = n.channels.length; e < t; e++) {
                        let t = n.channels[e],
                            r = n.samplers[t.sampler],
                            i = t.target,
                            a = i.node,
                            d = void 0 !== n.parameters ? n.parameters[r.input] : r.input,
                            f = void 0 !== n.parameters ? n.parameters[r.output] : r.output;
                        void 0 !== i.node && (o.push(this.getDependency("node", a)), s.push(this.getDependency("accessor", d)), l.push(this.getDependency("accessor", f)), u.push(r), c.push(i))
                    }
                    return Promise.all([Promise.all(o), Promise.all(s), Promise.all(l), Promise.all(u), Promise.all(c)]).then(function(e) {
                        let t = e[0],
                            n = e[1],
                            o = e[2],
                            s = e[3],
                            l = e[4],
                            u = [];
                        for (let e = 0, i = t.length; e < i; e++) {
                            let i = t[e],
                                a = n[e],
                                c = o[e],
                                d = s[e],
                                f = l[e];
                            if (void 0 === i) continue;
                            i.updateMatrix && i.updateMatrix();
                            let h = r._createAnimationTracks(i, a, c, d, f);
                            if (h)
                                for (let e = 0; e < h.length; e++) u.push(h[e])
                        }
                        return new i.AnimationClip(a, void 0, u)
                    })
                }
                createNodeMesh(e) {
                    let t = this.json,
                        r = this,
                        n = t.nodes[e];
                    return void 0 === n.mesh ? null : r.getDependency("mesh", n.mesh).then(function(e) {
                        let t = r._getNodeRef(r.meshCache, n.mesh, e);
                        return void 0 !== n.weights && t.traverse(function(e) {
                            if (e.isMesh)
                                for (let t = 0, r = n.weights.length; t < r; t++) e.morphTargetInfluences[t] = n.weights[t]
                        }), t
                    })
                }
                loadNode(e) {
                    let t = this.json.nodes[e],
                        r = this._loadNodeShallow(e),
                        n = [],
                        i = t.children || [];
                    for (let e = 0, t = i.length; e < t; e++) n.push(this.getDependency("node", i[e]));
                    let a = void 0 === t.skin ? Promise.resolve(null) : this.getDependency("skin", t.skin);
                    return Promise.all([r, Promise.all(n), a]).then(function(e) {
                        let t = e[0],
                            r = e[1],
                            n = e[2];
                        null !== n && t.traverse(function(e) {
                            e.isSkinnedMesh && e.bind(n, er)
                        });
                        for (let e = 0, n = r.length; e < n; e++) t.add(r[e]);
                        return t
                    })
                }
                _loadNodeShallow(e) {
                    let t = this.json,
                        r = this.extensions,
                        n = this;
                    if (void 0 !== this.nodeCache[e]) return this.nodeCache[e];
                    let a = t.nodes[e],
                        o = a.name ? n.createUniqueName(a.name) : "",
                        s = [],
                        l = n._invokeOne(function(t) {
                            return t.createNodeMesh && t.createNodeMesh(e)
                        });
                    return l && s.push(l), void 0 !== a.camera && s.push(n.getDependency("camera", a.camera).then(function(e) {
                        return n._getNodeRef(n.cameraCache, a.camera, e)
                    })), n._invokeAll(function(t) {
                        return t.createNodeAttachment && t.createNodeAttachment(e)
                    }).forEach(function(e) {
                        s.push(e)
                    }), this.nodeCache[e] = Promise.all(s).then(function(t) {
                        let s;
                        if ((s = !0 === a.isBone ? new i.Bone : t.length > 1 ? new i.Group : 1 === t.length ? t[0] : new i.Object3D) !== t[0])
                            for (let e = 0, r = t.length; e < r; e++) s.add(t[e]);
                        if (a.name && (s.userData.name = a.name, s.name = o), $(s, a), a.extensions && q(r, s, a), void 0 !== a.matrix) {
                            let e = new i.Matrix4;
                            e.fromArray(a.matrix), s.applyMatrix4(e)
                        } else void 0 !== a.translation && s.position.fromArray(a.translation), void 0 !== a.rotation && s.quaternion.fromArray(a.rotation), void 0 !== a.scale && s.scale.fromArray(a.scale);
                        return n.associations.has(s) || n.associations.set(s, {}), n.associations.get(s).nodes = e, s
                    }), this.nodeCache[e]
                }
                loadScene(e) {
                    let t = this.extensions,
                        r = this.json.scenes[e],
                        n = this,
                        a = new i.Group;
                    r.name && (a.name = n.createUniqueName(r.name)), $(a, r), r.extensions && q(t, a, r);
                    let o = r.nodes || [],
                        s = [];
                    for (let e = 0, t = o.length; e < t; e++) s.push(n.getDependency("node", o[e]));
                    return Promise.all(s).then(function(e) {
                        for (let t = 0, r = e.length; t < r; t++) a.add(e[t]);
                        return n.associations = (e => {
                            let t = new Map;
                            for (let [e, r] of n.associations)(e instanceof i.Material || e instanceof i.Texture) && t.set(e, r);
                            return e.traverse(e => {
                                let r = n.associations.get(e);
                                null != r && t.set(e, r)
                            }), t
                        })(a), a
                    })
                }
                _createAnimationTracks(e, t, r, n, a) {
                    let o;
                    let s = [],
                        l = e.name ? e.name : e.uuid,
                        u = [];
                    switch (X[a.path] === X.weights ? e.traverse(function(e) {
                        e.morphTargetInfluences && u.push(e.name ? e.name : e.uuid)
                    }) : u.push(l), X[a.path]) {
                        case X.weights:
                            o = i.NumberKeyframeTrack;
                            break;
                        case X.rotation:
                            o = i.QuaternionKeyframeTrack;
                            break;
                        case X.position:
                        case X.scale:
                            o = i.VectorKeyframeTrack;
                            break;
                        default:
                            o = 1 === r.itemSize ? i.NumberKeyframeTrack : i.VectorKeyframeTrack
                    }
                    let c = void 0 !== n.interpolation ? W[n.interpolation] : i.InterpolateLinear,
                        d = this._getArrayFromAccessor(r);
                    for (let e = 0, r = u.length; e < r; e++) {
                        let r = new o(u[e] + "." + X[a.path], t.array, d, c);
                        "CUBICSPLINE" === n.interpolation && this._createCubicSplineTrackInterpolant(r), s.push(r)
                    }
                    return s
                }
                _getArrayFromAccessor(e) {
                    let t = e.array;
                    if (e.normalized) {
                        let e = et(t.constructor),
                            r = new Float32Array(t.length);
                        for (let n = 0, i = t.length; n < i; n++) r[n] = t[n] * e;
                        t = r
                    }
                    return t
                }
                _createCubicSplineTrackInterpolant(e) {
                    e.createInterpolant = function(e) {
                        return new(this instanceof i.QuaternionKeyframeTrack ? J : k)(this.times, this.values, this.getValueSize() / 3, e)
                    }, e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline = !0
                }
            }

            function ei(e, t, r) {
                let n = t.attributes,
                    a = [];
                for (let t in n) {
                    let i = Y[t] || t.toLowerCase();
                    i in e.attributes || a.push(function(t, n) {
                        return r.getDependency("accessor", t).then(function(t) {
                            e.setAttribute(n, t)
                        })
                    }(n[t], i))
                }
                if (void 0 !== t.indices && !e.index) {
                    let n = r.getDependency("accessor", t.indices).then(function(t) {
                        e.setIndex(t)
                    });
                    a.push(n)
                }
                return $(e, t), ! function(e, t, r) {
                    let n = t.attributes,
                        a = new i.Box3;
                    if (void 0 === n.POSITION) return; {
                        let e = r.json.accessors[n.POSITION],
                            t = e.min,
                            o = e.max;
                        if (void 0 !== t && void 0 !== o) {
                            if (a.set(new i.Vector3(t[0], t[1], t[2]), new i.Vector3(o[0], o[1], o[2])), e.normalized) {
                                let t = et(j[e.componentType]);
                                a.min.multiplyScalar(t), a.max.multiplyScalar(t)
                            }
                        } else {
                            console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");
                            return
                        }
                    }
                    let o = t.targets;
                    if (void 0 !== o) {
                        let e = new i.Vector3,
                            t = new i.Vector3;
                        for (let n = 0, i = o.length; n < i; n++) {
                            let i = o[n];
                            if (void 0 !== i.POSITION) {
                                let n = r.json.accessors[i.POSITION],
                                    a = n.min,
                                    o = n.max;
                                if (void 0 !== a && void 0 !== o) {
                                    if (t.setX(Math.max(Math.abs(a[0]), Math.abs(o[0]))), t.setY(Math.max(Math.abs(a[1]), Math.abs(o[1]))), t.setZ(Math.max(Math.abs(a[2]), Math.abs(o[2]))), n.normalized) {
                                        let e = et(j[n.componentType]);
                                        t.multiplyScalar(e)
                                    }
                                    e.max(t)
                                } else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")
                            }
                        }
                        a.expandByVector(e)
                    }
                    e.boundingBox = a;
                    let s = new i.Sphere;
                    a.getCenter(s.center), s.radius = a.min.distanceTo(a.max) / 2, e.boundingSphere = s
                }(e, t, r), Promise.all(a).then(function() {
                    return void 0 !== t.targets ? function(e, t, r) {
                        let n = !1,
                            i = !1,
                            a = !1;
                        for (let e = 0, r = t.length; e < r; e++) {
                            let r = t[e];
                            if (void 0 !== r.POSITION && (n = !0), void 0 !== r.NORMAL && (i = !0), void 0 !== r.COLOR_0 && (a = !0), n && i && a) break
                        }
                        if (!n && !i && !a) return Promise.resolve(e);
                        let o = [],
                            s = [],
                            l = [];
                        for (let u = 0, c = t.length; u < c; u++) {
                            let c = t[u];
                            if (n) {
                                let t = void 0 !== c.POSITION ? r.getDependency("accessor", c.POSITION) : e.attributes.position;
                                o.push(t)
                            }
                            if (i) {
                                let t = void 0 !== c.NORMAL ? r.getDependency("accessor", c.NORMAL) : e.attributes.normal;
                                s.push(t)
                            }
                            if (a) {
                                let t = void 0 !== c.COLOR_0 ? r.getDependency("accessor", c.COLOR_0) : e.attributes.color;
                                l.push(t)
                            }
                        }
                        return Promise.all([Promise.all(o), Promise.all(s), Promise.all(l)]).then(function(t) {
                            let r = t[0],
                                o = t[1],
                                s = t[2];
                            return n && (e.morphAttributes.position = r), i && (e.morphAttributes.normal = o), a && (e.morphAttributes.color = s), e.morphTargetsRelative = !0, e
                        })
                    }(e, t.targets, r) : e
                })
            }
            var ea = r(19390);
            let eo = null,
                es = "https://www.gstatic.com/draco/versioned/decoders/1.5.5/";

            function el(e, t, r) {
                return n => {
                    r && r(n), e && (eo || (eo = new o), eo.setDecoderPath("string" == typeof e ? e : es), n.setDRACOLoader(eo)), t && n.setMeshoptDecoder("function" == typeof l ? l() : l)
                }
            }

            function eu(e, t = !0, r = !0, n) {
                return (0, ea.F)(h, e, el(t, r, n))
            }
            eu.preload = (e, t = !0, r = !0, n) => ea.F.preload(h, e, el(t, r, n)), eu.clear = e => ea.F.clear(h, e), eu.setDecoderPath = e => {
                es = e
            }
        },
        69015: function(e, t, r) {
            "use strict";
            r.d(t, {
                S: function() {
                    return s
                }
            });
            var n = r(99477),
                i = r(67294);
            let a = "undefined" == typeof window || !window.navigator || /ServerSideRendering|^Deno\//.test(window.navigator.userAgent) ? i.useEffect : i.useLayoutEffect,
                o = 0,
                s = function(e) {
                    let t = "function" == typeof e ? function(e) {
                            let t;
                            let r = new Set,
                                n = (e, n) => {
                                    let i = "function" == typeof e ? e(t) : e;
                                    if (i !== t) {
                                        let e = t;
                                        t = n ? i : Object.assign({}, t, i), r.forEach(r => r(t, e))
                                    }
                                },
                                i = () => t,
                                a = (e, n = i, a = Object.is) => {
                                    console.warn("[DEPRECATED] Please use `subscribeWithSelector` middleware");
                                    let o = n(t);

                                    function s() {
                                        let r = n(t);
                                        if (!a(o, r)) {
                                            let t = o;
                                            e(o = r, t)
                                        }
                                    }
                                    return r.add(s), () => r.delete(s)
                                },
                                o = {
                                    setState: n,
                                    getState: i,
                                    subscribe: (e, t, n) => t || n ? a(e, t, n) : (r.add(e), () => r.delete(e)),
                                    destroy: () => r.clear()
                                };
                            return t = e(n, i, o), o
                        }(e) : e,
                        r = (e = t.getState, r = Object.is) => {
                            let n;
                            let [, o] = (0, i.useReducer)(e => e + 1, 0), s = t.getState(), l = (0, i.useRef)(s), u = (0, i.useRef)(e), c = (0, i.useRef)(r), d = (0, i.useRef)(!1), f = (0, i.useRef)();
                            void 0 === f.current && (f.current = e(s));
                            let h = !1;
                            (l.current !== s || u.current !== e || c.current !== r || d.current) && (n = e(s), h = !r(f.current, n)), a(() => {
                                h && (f.current = n), l.current = s, u.current = e, c.current = r, d.current = !1
                            });
                            let p = (0, i.useRef)(s);
                            a(() => {
                                let e = () => {
                                        try {
                                            let e = t.getState(),
                                                r = u.current(e);
                                            c.current(f.current, r) || (l.current = e, f.current = r, o())
                                        } catch (e) {
                                            d.current = !0, o()
                                        }
                                    },
                                    r = t.subscribe(e);
                                return t.getState() !== p.current && e(), r
                            }, []);
                            let m = h ? n : f.current;
                            return (0, i.useDebugValue)(m), m
                        };
                    return Object.assign(r, t), r[Symbol.iterator] = function() {
                        console.warn("[useStore, api] = create() is deprecated and will be removed in v4");
                        let e = [r, t];
                        return {
                            next() {
                                let t = e.length <= 0;
                                return {
                                    value: e.shift(),
                                    done: t
                                }
                            }
                        }
                    }, r
                }(e => (n.DefaultLoadingManager.onStart = (t, r, n) => {
                    e({
                        active: !0,
                        item: t,
                        loaded: r,
                        total: n,
                        progress: (r - o) / (n - o) * 100
                    })
                }, n.DefaultLoadingManager.onLoad = () => {
                    e({
                        active: !1
                    })
                }, n.DefaultLoadingManager.onError = t => e(e => ({
                    errors: [...e.errors, t]
                })), n.DefaultLoadingManager.onProgress = (t, r, n) => {
                    r === n && (o = n), e({
                        active: !0,
                        item: t,
                        loaded: r,
                        total: n,
                        progress: (r - o) / (n - o) * 100 || 100
                    })
                }, {
                    errors: [],
                    active: !1,
                    progress: 0,
                    item: "",
                    loaded: 0,
                    total: 0
                }))
        },
        85769: function(e, t, r) {
            "use strict";
            r.d(t, {
                m: function() {
                    return s
                }
            });
            var n = r(99477),
                i = r(19390),
                a = r(67294);
            let o = e => e === Object(e) && !Array.isArray(e) && "function" != typeof e;

            function s(e, t) {
                let r = (0, i.A)(e => e.gl),
                    s = (0, i.F)(n.TextureLoader, o(e) ? Object.values(e) : e);
                return (0, a.useLayoutEffect)(() => {
                    null == t || t(s)
                }, [t]), (0, a.useEffect)(() => {
                    if ("initTexture" in r) {
                        let e = [];
                        Array.isArray(s) ? e = s : s instanceof n.Texture ? e = [s] : o(s) && (e = Object.values(s)), e.forEach(e => {
                            e instanceof n.Texture && r.initTexture(e)
                        })
                    }
                }, [r, s]), (0, a.useMemo)(() => {
                    if (!o(e)) return s; {
                        let t = {},
                            r = 0;
                        for (let n in e) t[n] = s[r++];
                        return t
                    }
                }, [e, s])
            }
            s.preload = e => i.F.preload(n.TextureLoader, e), s.clear = e => i.F.clear(n.TextureLoader, e)
        },
        86600: function(e, t, r) {
            "use strict";
            r.d(t, {
                Jj: function() {
                    return n
                },
                kn: function() {
                    return a
                },
                rn: function() {
                    return i
                }
            });
            let n = (e, t) => {
                    "updateRanges" in e ? e.updateRanges[0] = t : e.updateRange = t
                },
                i = 3e3,
                a = 3001
        },
        38198: function(e, t, r) {
            "use strict";
            r.d(t, {
                l: function() {
                    return n
                }
            });
            let n = (0, r(4950).g)({}, "void main() { }", "void main() { gl_FragColor = vec4(0.0, 0.0, 0.0, 0.0); discard;  }")
        },
        19390: function(e, t, r) {
            "use strict";
            let n, i, a;
            r.d(t, {
                A: function() {
                    return el
                },
                B: function() {
                    return T
                },
                C: function() {
                    return eu
                },
                E: function() {
                    return x
                },
                F: function() {
                    return ef
                },
                a: function() {
                    return w
                },
                b: function() {
                    return eC
                },
                c: function() {
                    return X
                },
                d: function() {
                    return e_
                },
                e: function() {
                    return C
                },
                g: function() {
                    return eb
                },
                i: function() {
                    return E
                },
                j: function() {
                    return eA
                },
                u: function() {
                    return M
                },
                y: function() {
                    return eo
                }
            });
            var o, s, l = r(99477),
                u = r(67294),
                c = r(32576);
            let d = "undefined" == typeof window || !window.navigator || /ServerSideRendering|^Deno\//.test(window.navigator.userAgent) ? u.useEffect : u.useLayoutEffect;

            function f(e) {
                let t = "function" == typeof e ? function(e) {
                        let t;
                        let r = new Set,
                            n = (e, n) => {
                                let i = "function" == typeof e ? e(t) : e;
                                if (i !== t) {
                                    let e = t;
                                    t = n ? i : Object.assign({}, t, i), r.forEach(r => r(t, e))
                                }
                            },
                            i = () => t,
                            a = (e, n = i, a = Object.is) => {
                                console.warn("[DEPRECATED] Please use `subscribeWithSelector` middleware");
                                let o = n(t);

                                function s() {
                                    let r = n(t);
                                    if (!a(o, r)) {
                                        let t = o;
                                        e(o = r, t)
                                    }
                                }
                                return r.add(s), () => r.delete(s)
                            },
                            o = {
                                setState: n,
                                getState: i,
                                subscribe: (e, t, n) => t || n ? a(e, t, n) : (r.add(e), () => r.delete(e)),
                                destroy: () => r.clear()
                            };
                        return t = e(n, i, o), o
                    }(e) : e,
                    r = (e = t.getState, r = Object.is) => {
                        let n;
                        let [, i] = (0, u.useReducer)(e => e + 1, 0), a = t.getState(), o = (0, u.useRef)(a), s = (0, u.useRef)(e), l = (0, u.useRef)(r), c = (0, u.useRef)(!1), f = (0, u.useRef)();
                        void 0 === f.current && (f.current = e(a));
                        let h = !1;
                        (o.current !== a || s.current !== e || l.current !== r || c.current) && (n = e(a), h = !r(f.current, n)), d(() => {
                            h && (f.current = n), o.current = a, s.current = e, l.current = r, c.current = !1
                        });
                        let p = (0, u.useRef)(a);
                        d(() => {
                            let e = () => {
                                    try {
                                        let e = t.getState(),
                                            r = s.current(e);
                                        l.current(f.current, r) || (o.current = e, f.current = r, i())
                                    } catch (e) {
                                        c.current = !0, i()
                                    }
                                },
                                r = t.subscribe(e);
                            return t.getState() !== p.current && e(), r
                        }, []);
                        let m = h ? n : f.current;
                        return (0, u.useDebugValue)(m), m
                    };
                return Object.assign(r, t), r[Symbol.iterator] = function() {
                    console.warn("[useStore, api] = create() is deprecated and will be removed in v4");
                    let e = [r, t];
                    return {
                        next() {
                            let t = e.length <= 0;
                            return {
                                value: e.shift(),
                                done: t
                            }
                        }
                    }
                }, r
            }
            var h = r(76525),
                p = r.n(h),
                m = r(45431),
                g = r(58139),
                A = r(85893),
                v = r(83454);
            let y = {},
                C = e => void Object.assign(y, e),
                B = e => "colorSpace" in e || "outputColorSpace" in e,
                _ = () => {
                    var e;
                    return null != (e = y.ColorManagement) ? e : null
                },
                b = e => e && e.isOrthographicCamera,
                E = e => e && e.hasOwnProperty("current"),
                w = "undefined" != typeof window && (null != (o = window.document) && o.createElement || (null == (s = window.navigator) ? void 0 : s.product) === "ReactNative") ? u.useLayoutEffect : u.useEffect;

            function M(e) {
                let t = u.useRef(e);
                return w(() => void(t.current = e), [e]), t
            }

            function T({
                set: e
            }) {
                return w(() => (e(new Promise(() => null)), () => e(!1)), [e]), null
            }
            class x extends u.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        error: !1
                    }
                }
                componentDidCatch(e) {
                    this.props.set(e)
                }
                render() {
                    return this.state.error ? null : this.props.children
                }
            }
            x.getDerivedStateFromError = () => ({
                error: !0
            });
            let F = "__default",
                S = new Map,
                R = e => e && !!e.memoized && !!e.changes;

            function O(e) {
                var t;
                let r = "undefined" != typeof window ? null != (t = window.devicePixelRatio) ? t : 2 : 1;
                return Array.isArray(e) ? Math.min(Math.max(e[0], r), e[1]) : e
            }
            let I = e => {
                var t;
                return null == (t = e.__r3f) ? void 0 : t.root.getState()
            };

            function D(e) {
                let t = e.__r3f.root;
                for (; t.getState().previousRoot;) t = t.getState().previousRoot;
                return t
            }
            let P = {
                obj: e => e === Object(e) && !P.arr(e) && "function" != typeof e,
                fun: e => "function" == typeof e,
                str: e => "string" == typeof e,
                num: e => "number" == typeof e,
                boo: e => "boolean" == typeof e,
                und: e => void 0 === e,
                arr: e => Array.isArray(e),
                equ(e, t, {
                    arrays: r = "shallow",
                    objects: n = "reference",
                    strict: i = !0
                } = {}) {
                    let a;
                    if (typeof e != typeof t || !!e != !!t) return !1;
                    if (P.str(e) || P.num(e)) return e === t;
                    let o = P.obj(e);
                    if (o && "reference" === n) return e === t;
                    let s = P.arr(e);
                    if (s && "reference" === r) return e === t;
                    if ((s || o) && e === t) return !0;
                    for (a in e)
                        if (!(a in t)) return !1;
                    if (o && "shallow" === r && "shallow" === n) {
                        for (a in i ? t : e)
                            if (!P.equ(e[a], t[a], {
                                    strict: i,
                                    objects: "reference"
                                })) return !1
                    } else
                        for (a in i ? t : e)
                            if (e[a] !== t[a]) return !1;
                    if (P.und(a)) {
                        if (s && 0 === e.length && 0 === t.length || o && 0 === Object.keys(e).length && 0 === Object.keys(t).length) return !0;
                        if (e !== t) return !1
                    }
                    return !0
                }
            };

            function L(e, t) {
                return e.__r3f = {
                    type: "",
                    root: null,
                    previousAttach: null,
                    memoizedProps: {},
                    eventCount: 0,
                    handlers: {},
                    objects: [],
                    parent: null,
                    ...t
                }, e
            }

            function H(e, t) {
                let r = e;
                if (!t.includes("-")) return {
                    target: r,
                    key: t
                }; {
                    let n = t.split("-"),
                        i = n.pop();
                    return {
                        target: r = n.reduce((e, t) => e[t], e),
                        key: i
                    }
                }
            }
            let U = /-\d+$/;

            function G(e, t, r) {
                if (P.str(r)) {
                    if (U.test(r)) {
                        let {
                            target: t,
                            key: n
                        } = H(e, r.replace(U, ""));
                        Array.isArray(t[n]) || (t[n] = [])
                    }
                    let {
                        target: n,
                        key: i
                    } = H(e, r);
                    t.__r3f.previousAttach = n[i], n[i] = t
                } else t.__r3f.previousAttach = r(e, t)
            }

            function k(e, t, r) {
                var n, i;
                if (P.str(r)) {
                    let {
                        target: n,
                        key: i
                    } = H(e, r), a = t.__r3f.previousAttach;
                    void 0 === a ? delete n[i] : n[i] = a
                } else null == (n = t.__r3f) || null == n.previousAttach || n.previousAttach(e, t);
                null == (i = t.__r3f) || delete i.previousAttach
            }

            function N(e, {
                children: t,
                key: r,
                ref: n,
                ...i
            }, {
                children: a,
                key: o,
                ref: s,
                ...l
            } = {}, u = !1) {
                let c = e.__r3f,
                    d = Object.entries(i),
                    f = [];
                if (u) {
                    let e = Object.keys(l);
                    for (let t = 0; t < e.length; t++) i.hasOwnProperty(e[t]) || d.unshift([e[t], F + "remove"])
                }
                d.forEach(([t, r]) => {
                    var n;
                    if (null != (n = e.__r3f) && n.primitive && "object" === t || P.equ(r, l[t])) return;
                    if (/^on(Pointer|Click|DoubleClick|ContextMenu|Wheel)/.test(t)) return f.push([t, r, !0, []]);
                    let a = [];
                    for (let e in t.includes("-") && (a = t.split("-")), f.push([t, r, !1, a]), i) {
                        let r = i[e];
                        e.startsWith(`${t}-`) && f.push([e, r, !1, e.split("-")])
                    }
                });
                let h = { ...i
                };
                return null != c && c.memoizedProps && null != c && c.memoizedProps.args && (h.args = c.memoizedProps.args), null != c && c.memoizedProps && null != c && c.memoizedProps.attach && (h.attach = c.memoizedProps.attach), {
                    memoized: h,
                    changes: f
                }
            }
            let J = void 0 !== v && !1;

            function z(e, t) {
                var r;
                let n = e.__r3f,
                    i = null == n ? void 0 : n.root,
                    a = null == i ? void 0 : null == i.getState ? void 0 : i.getState(),
                    {
                        memoized: o,
                        changes: s
                    } = R(t) ? t : N(e, t),
                    u = null == n ? void 0 : n.eventCount;
                e.__r3f && (e.__r3f.memoizedProps = o);
                for (let t = 0; t < s.length; t++) {
                    let [r, i, o, u] = s[t];
                    if (B(e)) {
                        let e = "srgb",
                            t = "srgb-linear";
                        "encoding" === r ? (r = "colorSpace", i = 3001 === i ? e : t) : "outputEncoding" === r && (r = "outputColorSpace", i = 3001 === i ? e : t)
                    }
                    let c = e,
                        d = c[r];
                    if (u.length && !((d = u.reduce((e, t) => e[t], e)) && d.set)) {
                        let [t, ...n] = u.reverse();
                        c = n.reverse().reduce((e, t) => e[t], e), r = t
                    }
                    if (i === F + "remove") {
                        if (c.constructor) {
                            let e = S.get(c.constructor);
                            e || (e = new c.constructor, S.set(c.constructor, e)), i = e[r]
                        } else i = 0
                    }
                    if (o && n) i ? n.handlers[r] = i : delete n.handlers[r], n.eventCount = Object.keys(n.handlers).length;
                    else if (d && d.set && (d.copy || d instanceof l.Layers)) {
                        if (Array.isArray(i)) d.fromArray ? d.fromArray(i) : d.set(...i);
                        else if (d.copy && i && i.constructor && (J ? d.constructor.name === i.constructor.name : d.constructor === i.constructor)) d.copy(i);
                        else if (void 0 !== i) {
                            let e = d instanceof l.Color;
                            !e && d.setScalar ? d.setScalar(i) : d instanceof l.Layers && i instanceof l.Layers ? d.mask = i.mask : d.set(i), !_() && a && !a.linear && e && d.convertSRGBToLinear()
                        }
                    } else if (c[r] = i, c[r] instanceof l.Texture && c[r].format === l.RGBAFormat && c[r].type === l.UnsignedByteType && a) {
                        let e = c[r];
                        B(e) && B(a.gl) ? e.colorSpace = a.gl.outputColorSpace : e.encoding = a.gl.outputEncoding
                    }
                    j(e)
                }
                if (n && n.parent && e.raycast && u !== n.eventCount) {
                    let t = D(e).getState().internal,
                        r = t.interaction.indexOf(e);
                    r > -1 && t.interaction.splice(r, 1), n.eventCount && t.interaction.push(e)
                }
                return !(1 === s.length && "onUpdate" === s[0][0]) && s.length && null != (r = e.__r3f) && r.parent && K(e), e
            }

            function j(e) {
                var t, r;
                let n = null == (t = e.__r3f) ? void 0 : null == (r = t.root) ? void 0 : null == r.getState ? void 0 : r.getState();
                n && 0 === n.internal.frames && n.invalidate()
            }

            function K(e) {
                null == e.onUpdate || e.onUpdate(e)
            }

            function Q(e, t) {
                e.manual || (b(e) ? (e.left = -(t.width / 2), e.right = t.width / 2, e.top = t.height / 2, e.bottom = -(t.height / 2)) : e.aspect = t.width / t.height, e.updateProjectionMatrix(), e.updateMatrixWorld())
            }

            function V(e) {
                return (e.eventObject || e.object).uuid + "/" + e.index + e.instanceId
            }

            function Y(e, t, r, n) {
                let i = r.get(t);
                i && (r.delete(t), 0 === r.size && (e.delete(n), i.target.releasePointerCapture(n)))
            }

            function X(e) {
                function t(e) {
                    return e.filter(e => ["Move", "Over", "Enter", "Out", "Leave"].some(t => {
                        var r;
                        return null == (r = e.__r3f) ? void 0 : r.handlers["onPointer" + t]
                    }))
                }

                function r(t) {
                    let {
                        internal: r
                    } = e.getState();
                    for (let e of r.hovered.values())
                        if (!t.length || !t.find(t => t.object === e.object && t.index === e.index && t.instanceId === e.instanceId)) {
                            let n = e.eventObject.__r3f,
                                i = null == n ? void 0 : n.handlers;
                            if (r.hovered.delete(V(e)), null != n && n.eventCount) {
                                let r = { ...e,
                                    intersections: t
                                };
                                null == i.onPointerOut || i.onPointerOut(r), null == i.onPointerLeave || i.onPointerLeave(r)
                            }
                        }
                }

                function n(e, t) {
                    for (let r = 0; r < t.length; r++) {
                        let n = t[r].__r3f;
                        null == n || null == n.handlers.onPointerMissed || n.handlers.onPointerMissed(e)
                    }
                }
                return {
                    handlePointer: function(i) {
                        switch (i) {
                            case "onPointerLeave":
                            case "onPointerCancel":
                                return () => r([]);
                            case "onLostPointerCapture":
                                return t => {
                                    let {
                                        internal: n
                                    } = e.getState();
                                    "pointerId" in t && n.capturedMap.has(t.pointerId) && requestAnimationFrame(() => {
                                        n.capturedMap.has(t.pointerId) && (n.capturedMap.delete(t.pointerId), r([]))
                                    })
                                }
                        }
                        return function(a) {
                            let {
                                onPointerMissed: o,
                                internal: s
                            } = e.getState();
                            s.lastEvent.current = a;
                            let u = "onPointerMove" === i,
                                c = "onClick" === i || "onContextMenu" === i || "onDoubleClick" === i,
                                d = function(t, r) {
                                    let n = e.getState(),
                                        i = new Set,
                                        a = [],
                                        o = r ? r(n.internal.interaction) : n.internal.interaction;
                                    for (let e = 0; e < o.length; e++) {
                                        let t = I(o[e]);
                                        t && (t.raycaster.camera = void 0)
                                    }
                                    n.previousRoot || null == n.events.compute || n.events.compute(t, n);
                                    let s = o.flatMap(function(e) {
                                        let r = I(e);
                                        if (!r || !r.events.enabled || null === r.raycaster.camera) return [];
                                        if (void 0 === r.raycaster.camera) {
                                            var n;
                                            null == r.events.compute || r.events.compute(t, r, null == (n = r.previousRoot) ? void 0 : n.getState()), void 0 === r.raycaster.camera && (r.raycaster.camera = null)
                                        }
                                        return r.raycaster.camera ? r.raycaster.intersectObject(e, !0) : []
                                    }).sort((e, t) => {
                                        let r = I(e.object),
                                            n = I(t.object);
                                        return r && n && n.events.priority - r.events.priority || e.distance - t.distance
                                    }).filter(e => {
                                        let t = V(e);
                                        return !i.has(t) && (i.add(t), !0)
                                    });
                                    for (let e of (n.events.filter && (s = n.events.filter(s, n)), s)) {
                                        let t = e.object;
                                        for (; t;) {
                                            var l;
                                            null != (l = t.__r3f) && l.eventCount && a.push({ ...e,
                                                eventObject: t
                                            }), t = t.parent
                                        }
                                    }
                                    if ("pointerId" in t && n.internal.capturedMap.has(t.pointerId))
                                        for (let e of n.internal.capturedMap.get(t.pointerId).values()) i.has(V(e.intersection)) || a.push(e.intersection);
                                    return a
                                }(a, u ? t : void 0),
                                f = c ? function(t) {
                                    let {
                                        internal: r
                                    } = e.getState(), n = t.offsetX - r.initialClick[0], i = t.offsetY - r.initialClick[1];
                                    return Math.round(Math.sqrt(n * n + i * i))
                                }(a) : 0;
                            "onPointerDown" === i && (s.initialClick = [a.offsetX, a.offsetY], s.initialHits = d.map(e => e.eventObject)), c && !d.length && f <= 2 && (n(a, s.interaction), o && o(a)), u && r(d),
                                function(t, n, i, a) {
                                    let o = e.getState();
                                    if (t.length) {
                                        let e = {
                                            stopped: !1
                                        };
                                        for (let s of t) {
                                            let {
                                                raycaster: u,
                                                pointer: c,
                                                camera: d,
                                                internal: f
                                            } = I(s.object) || o, h = new l.Vector3(c.x, c.y, 0).unproject(d), p = e => {
                                                var t, r;
                                                return null != (t = null == (r = f.capturedMap.get(e)) ? void 0 : r.has(s.eventObject)) && t
                                            }, m = e => {
                                                let t = {
                                                    intersection: s,
                                                    target: n.target
                                                };
                                                f.capturedMap.has(e) ? f.capturedMap.get(e).set(s.eventObject, t) : f.capturedMap.set(e, new Map([
                                                    [s.eventObject, t]
                                                ])), n.target.setPointerCapture(e)
                                            }, g = e => {
                                                let t = f.capturedMap.get(e);
                                                t && Y(f.capturedMap, s.eventObject, t, e)
                                            }, A = {};
                                            for (let e in n) {
                                                let t = n[e];
                                                "function" != typeof t && (A[e] = t)
                                            }
                                            let v = { ...s,
                                                ...A,
                                                pointer: c,
                                                intersections: t,
                                                stopped: e.stopped,
                                                delta: i,
                                                unprojectedPoint: h,
                                                ray: u.ray,
                                                camera: d,
                                                stopPropagation() {
                                                    let i = "pointerId" in n && f.capturedMap.get(n.pointerId);
                                                    (!i || i.has(s.eventObject)) && (v.stopped = e.stopped = !0, f.hovered.size && Array.from(f.hovered.values()).find(e => e.eventObject === s.eventObject) && r([...t.slice(0, t.indexOf(s)), s]))
                                                },
                                                target: {
                                                    hasPointerCapture: p,
                                                    setPointerCapture: m,
                                                    releasePointerCapture: g
                                                },
                                                currentTarget: {
                                                    hasPointerCapture: p,
                                                    setPointerCapture: m,
                                                    releasePointerCapture: g
                                                },
                                                nativeEvent: n
                                            };
                                            if (a(v), !0 === e.stopped) break
                                        }
                                    }
                                }(d, a, f, function(e) {
                                    let t = e.eventObject,
                                        r = t.__r3f,
                                        o = null == r ? void 0 : r.handlers;
                                    if (null != r && r.eventCount) {
                                        if (u) {
                                            if (o.onPointerOver || o.onPointerEnter || o.onPointerOut || o.onPointerLeave) {
                                                let t = V(e),
                                                    r = s.hovered.get(t);
                                                r ? r.stopped && e.stopPropagation() : (s.hovered.set(t, e), null == o.onPointerOver || o.onPointerOver(e), null == o.onPointerEnter || o.onPointerEnter(e))
                                            }
                                            null == o.onPointerMove || o.onPointerMove(e)
                                        } else {
                                            let r = o[i];
                                            r ? (!c || s.initialHits.includes(t)) && (n(a, s.interaction.filter(e => !s.initialHits.includes(e))), r(e)) : c && s.initialHits.includes(t) && n(a, s.interaction.filter(e => !s.initialHits.includes(e)))
                                        }
                                    }
                                })
                        }
                    }
                }
            }
            let W = ["set", "get", "setSize", "setFrameloop", "setDpr", "events", "invalidate", "advance", "size", "viewport"],
                Z = e => !!(null != e && e.render),
                q = u.createContext(null),
                $ = (e, t) => {
                    let r = f((r, n) => {
                            let i;
                            let a = new l.Vector3,
                                o = new l.Vector3,
                                s = new l.Vector3;

                            function c(e = n().camera, t = o, r = n().size) {
                                let {
                                    width: i,
                                    height: u,
                                    top: c,
                                    left: d
                                } = r, f = i / u;
                                t instanceof l.Vector3 ? s.copy(t) : s.set(...t);
                                let h = e.getWorldPosition(a).distanceTo(s);
                                if (b(e)) return {
                                    width: i / e.zoom,
                                    height: u / e.zoom,
                                    top: c,
                                    left: d,
                                    factor: 1,
                                    distance: h,
                                    aspect: f
                                }; {
                                    let t = 2 * Math.tan(e.fov * Math.PI / 180 / 2) * h,
                                        r = i / u * t;
                                    return {
                                        width: r,
                                        height: t,
                                        top: c,
                                        left: d,
                                        factor: i / r,
                                        distance: h,
                                        aspect: f
                                    }
                                }
                            }
                            let d = e => r(t => ({
                                    performance: { ...t.performance,
                                        current: e
                                    }
                                })),
                                f = new l.Vector2;
                            return {
                                set: r,
                                get: n,
                                gl: null,
                                camera: null,
                                raycaster: null,
                                events: {
                                    priority: 1,
                                    enabled: !0,
                                    connected: !1
                                },
                                xr: null,
                                scene: null,
                                invalidate: (t = 1) => e(n(), t),
                                advance: (e, r) => t(e, r, n()),
                                legacy: !1,
                                linear: !1,
                                flat: !1,
                                controls: null,
                                clock: new l.Clock,
                                pointer: f,
                                mouse: f,
                                frameloop: "always",
                                onPointerMissed: void 0,
                                performance: {
                                    current: 1,
                                    min: .5,
                                    max: 1,
                                    debounce: 200,
                                    regress: () => {
                                        let e = n();
                                        i && clearTimeout(i), e.performance.current !== e.performance.min && d(e.performance.min), i = setTimeout(() => d(n().performance.max), e.performance.debounce)
                                    }
                                },
                                size: {
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    left: 0,
                                    updateStyle: !1
                                },
                                viewport: {
                                    initialDpr: 0,
                                    dpr: 0,
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    left: 0,
                                    aspect: 0,
                                    distance: 0,
                                    factor: 0,
                                    getCurrentViewport: c
                                },
                                setEvents: e => r(t => ({ ...t,
                                    events: { ...t.events,
                                        ...e
                                    }
                                })),
                                setSize: (e, t, i, a, s) => {
                                    let l = n().camera,
                                        u = {
                                            width: e,
                                            height: t,
                                            top: a || 0,
                                            left: s || 0,
                                            updateStyle: i
                                        };
                                    r(e => ({
                                        size: u,
                                        viewport: { ...e.viewport,
                                            ...c(l, o, u)
                                        }
                                    }))
                                },
                                setDpr: e => r(t => {
                                    let r = O(e);
                                    return {
                                        viewport: { ...t.viewport,
                                            dpr: r,
                                            initialDpr: t.viewport.initialDpr || r
                                        }
                                    }
                                }),
                                setFrameloop: (e = "always") => {
                                    let t = n().clock;
                                    t.stop(), t.elapsedTime = 0, "never" !== e && (t.start(), t.elapsedTime = 0), r(() => ({
                                        frameloop: e
                                    }))
                                },
                                previousRoot: void 0,
                                internal: {
                                    active: !1,
                                    priority: 0,
                                    frames: 0,
                                    lastEvent: u.createRef(),
                                    interaction: [],
                                    hovered: new Map,
                                    subscribers: [],
                                    initialClick: [0, 0],
                                    initialHits: [],
                                    capturedMap: new Map,
                                    subscribe: (e, t, r) => {
                                        let i = n().internal;
                                        return i.priority = i.priority + (t > 0 ? 1 : 0), i.subscribers.push({
                                            ref: e,
                                            priority: t,
                                            store: r
                                        }), i.subscribers = i.subscribers.sort((e, t) => e.priority - t.priority), () => {
                                            let r = n().internal;
                                            null != r && r.subscribers && (r.priority = r.priority - (t > 0 ? 1 : 0), r.subscribers = r.subscribers.filter(t => t.ref !== e))
                                        }
                                    }
                                }
                            }
                        }),
                        n = r.getState(),
                        i = n.size,
                        a = n.viewport.dpr,
                        o = n.camera;
                    return r.subscribe(() => {
                        let {
                            camera: e,
                            size: t,
                            viewport: n,
                            gl: s,
                            set: l
                        } = r.getState();
                        if (t.width !== i.width || t.height !== i.height || n.dpr !== a) {
                            var u;
                            i = t, a = n.dpr, Q(e, t), s.setPixelRatio(n.dpr);
                            let r = null != (u = t.updateStyle) ? u : "undefined" != typeof HTMLCanvasElement && s.domElement instanceof HTMLCanvasElement;
                            s.setSize(t.width, t.height, r)
                        }
                        e !== o && (o = e, l(t => ({
                            viewport: { ...t.viewport,
                                ...t.viewport.getCurrentViewport(e)
                            }
                        })))
                    }), r.subscribe(t => e(t)), r
                },
                ee = new Set,
                et = new Set,
                er = new Set;

            function en(e, t) {
                if (e.size)
                    for (let {
                            callback: r
                        } of e.values()) r(t)
            }

            function ei(e, t) {
                switch (e) {
                    case "before":
                        return en(ee, t);
                    case "after":
                        return en(et, t);
                    case "tail":
                        return en(er, t)
                }
            }

            function ea(e, t, r) {
                let o = t.clock.getDelta();
                for ("never" === t.frameloop && "number" == typeof e && (o = e - t.clock.elapsedTime, t.clock.oldTime = t.clock.elapsedTime, t.clock.elapsedTime = e), i = t.internal.subscribers, n = 0; n < i.length; n++)(a = i[n]).ref.current(a.store.getState(), o, r);
                return !t.internal.priority && t.gl.render && t.gl.render(t.scene, t.camera), t.internal.frames = Math.max(0, t.internal.frames - 1), "always" === t.frameloop ? 1 : t.internal.frames
            }

            function eo(e) {
                let t = u.useRef(null);
                return w(() => void(t.current = e.current.__r3f), [e]), t
            }

            function es() {
                let e = u.useContext(q);
                if (!e) throw Error("R3F: Hooks can only be used within the Canvas component!");
                return e
            }

            function el(e = e => e, t) {
                return es()(e, t)
            }

            function eu(e, t = 0) {
                let r = es(),
                    n = r.getState().internal.subscribe,
                    i = M(e);
                return w(() => n(i, t, r), [t, n, r]), null
            }
            let ec = new WeakMap;

            function ed(e, t) {
                return function(r, ...n) {
                    let i = ec.get(r);
                    return i || (i = new r, ec.set(r, i)), e && e(i), Promise.all(n.map(e => new Promise((r, n) => i.load(e, e => {
                        e.scene && Object.assign(e, function(e) {
                            let t = {
                                nodes: {},
                                materials: {}
                            };
                            return e && e.traverse(e => {
                                e.name && (t.nodes[e.name] = e), e.material && !t.materials[e.material.name] && (t.materials[e.material.name] = e.material)
                            }), t
                        }(e.scene)), r(e)
                    }, t, t => n(Error(`Could not load ${e}: ${null==t?void 0:t.message}`))))))
                }
            }

            function ef(e, t, r, n) {
                let i = Array.isArray(t) ? t : [t],
                    a = (0, g.Rq)(ed(r, n), [e, ...i], {
                        equal: P.equ
                    });
                return Array.isArray(t) ? a : a[0]
            }
            ef.preload = function(e, t, r) {
                let n = Array.isArray(t) ? t : [t];
                return (0, g.MA)(ed(r), [e, ...n])
            }, ef.clear = function(e, t) {
                let r = Array.isArray(t) ? t : [t];
                return (0, g.ZH)([e, ...r])
            };
            let eh = new Map,
                {
                    invalidate: ep,
                    advance: em
                } = function(e) {
                    let t, r, n, i = !1,
                        a = !1;

                    function o(s) {
                        for (let u of (r = requestAnimationFrame(o), i = !0, t = 0, ei("before", s), a = !0, e.values())) {
                            var l;
                            (n = u.store.getState()).internal.active && ("always" === n.frameloop || n.internal.frames > 0) && !(null != (l = n.gl.xr) && l.isPresenting) && (t += ea(s, n))
                        }
                        if (a = !1, ei("after", s), 0 === t) return ei("tail", s), i = !1, cancelAnimationFrame(r)
                    }
                    return {
                        loop: o,
                        invalidate: function t(r, n = 1) {
                            var s;
                            if (!r) return e.forEach(e => t(e.store.getState(), n));
                            null != (s = r.gl.xr) && s.isPresenting || !r.internal.active || "never" === r.frameloop || (n > 1 ? r.internal.frames = Math.min(60, r.internal.frames + n) : a ? r.internal.frames = 2 : r.internal.frames = 1, i || (i = !0, requestAnimationFrame(o)))
                        },
                        advance: function(t, r = !0, n, i) {
                            if (r && ei("before", t), n) ea(t, n, i);
                            else
                                for (let r of e.values()) ea(t, r.store.getState());
                            r && ei("after", t)
                        }
                    }
                }(eh),
                {
                    reconciler: eg,
                    applyProps: eA
                } = function(e, t) {
                    function r(e, {
                        args: t = [],
                        attach: r,
                        ...n
                    }, i) {
                        let a, o = `${e[0].toUpperCase()}${e.slice(1)}`;
                        if ("primitive" === e) {
                            if (void 0 === n.object) throw Error("R3F: Primitives without 'object' are invalid!");
                            a = L(n.object, {
                                type: e,
                                root: i,
                                attach: r,
                                primitive: !0
                            })
                        } else {
                            let n = y[o];
                            if (!n) throw Error(`R3F: ${o} is not part of the THREE namespace! Did you forget to extend? See: https://docs.pmnd.rs/react-three-fiber/api/objects#using-3rd-party-objects-declaratively`);
                            if (!Array.isArray(t)) throw Error("R3F: The args prop must be an array!");
                            a = L(new n(...t), {
                                type: e,
                                root: i,
                                attach: r,
                                memoizedProps: {
                                    args: t
                                }
                            })
                        }
                        return void 0 === a.__r3f.attach && (a instanceof l.BufferGeometry ? a.__r3f.attach = "geometry" : a instanceof l.Material && (a.__r3f.attach = "material")), "inject" !== o && z(a, n), a
                    }

                    function n(e, t) {
                        let r = !1;
                        if (t) {
                            var n, i;
                            null != (n = t.__r3f) && n.attach ? G(e, t, t.__r3f.attach) : t.isObject3D && e.isObject3D && (e.add(t), r = !0), r || null == (i = e.__r3f) || i.objects.push(t), t.__r3f || L(t, {}), t.__r3f.parent = e, K(t), j(t)
                        }
                    }

                    function i(e, t, r) {
                        let n = !1;
                        if (t) {
                            var i, a;
                            if (null != (i = t.__r3f) && i.attach) G(e, t, t.__r3f.attach);
                            else if (t.isObject3D && e.isObject3D) {
                                t.parent = e, t.dispatchEvent({
                                    type: "added"
                                }), e.dispatchEvent({
                                    type: "childadded",
                                    child: t
                                });
                                let i = e.children.filter(e => e !== t),
                                    a = i.indexOf(r);
                                e.children = [...i.slice(0, a), t, ...i.slice(a)], n = !0
                            }
                            n || null == (a = e.__r3f) || a.objects.push(t), t.__r3f || L(t, {}), t.__r3f.parent = e, K(t), j(t)
                        }
                    }

                    function a(e, t, r = !1) {
                        e && [...e].forEach(e => o(t, e, r))
                    }

                    function o(e, t, r) {
                        if (t) {
                            var n, i, o, s, l;
                            t.__r3f && (t.__r3f.parent = null), null != (n = e.__r3f) && n.objects && (e.__r3f.objects = e.__r3f.objects.filter(e => e !== t)), null != (i = t.__r3f) && i.attach ? k(e, t, t.__r3f.attach) : t.isObject3D && e.isObject3D && (e.remove(t), null != (s = t.__r3f) && s.root && function(e, t) {
                                let {
                                    internal: r
                                } = e.getState();
                                r.interaction = r.interaction.filter(e => e !== t), r.initialHits = r.initialHits.filter(e => e !== t), r.hovered.forEach((e, n) => {
                                    (e.eventObject === t || e.object === t) && r.hovered.delete(n)
                                }), r.capturedMap.forEach((e, n) => {
                                    Y(r.capturedMap, t, e, n)
                                })
                            }(D(t), t));
                            let u = null == (o = t.__r3f) ? void 0 : o.primitive,
                                c = !u && (void 0 === r ? null !== t.dispose : r);
                            if (u || (a(null == (l = t.__r3f) ? void 0 : l.objects, t, c), a(t.children, t, c)), delete t.__r3f, c && t.dispose && "Scene" !== t.type) {
                                let e = () => {
                                    try {
                                        t.dispose()
                                    } catch (e) {}
                                };
                                "undefined" == typeof IS_REACT_ACT_ENVIRONMENT ? (0, m.unstable_scheduleCallback)(m.unstable_IdlePriority, e) : e()
                            }
                            j(e)
                        }
                    }
                    let s = () => console.warn("Text is not allowed in the R3F tree! This could be stray whitespace or characters.");
                    return {
                        reconciler: p()({
                            createInstance: r,
                            removeChild: o,
                            appendChild: n,
                            appendInitialChild: n,
                            insertBefore: i,
                            supportsMutation: !0,
                            isPrimaryRenderer: !1,
                            supportsPersistence: !1,
                            supportsHydration: !1,
                            noTimeout: -1,
                            appendChildToContainer: (e, t) => {
                                if (!t) return;
                                let r = e.getState().scene;
                                r.__r3f && (r.__r3f.root = e, n(r, t))
                            },
                            removeChildFromContainer: (e, t) => {
                                t && o(e.getState().scene, t)
                            },
                            insertInContainerBefore: (e, t, r) => {
                                if (!t || !r) return;
                                let n = e.getState().scene;
                                n.__r3f && i(n, t, r)
                            },
                            getRootHostContext: () => null,
                            getChildHostContext: e => e,
                            finalizeInitialChildren(e) {
                                var t;
                                return !!(null != (t = null == e ? void 0 : e.__r3f) ? t : {}).handlers
                            },
                            prepareUpdate(e, t, r, n) {
                                var i;
                                if ((null != (i = null == e ? void 0 : e.__r3f) ? i : {}).primitive && n.object && n.object !== e) return [!0]; {
                                    let {
                                        args: t = [],
                                        children: i,
                                        ...a
                                    } = n, {
                                        args: o = [],
                                        children: s,
                                        ...l
                                    } = r;
                                    if (!Array.isArray(t)) throw Error("R3F: the args prop must be an array!");
                                    if (t.some((e, t) => e !== o[t])) return [!0];
                                    let u = N(e, a, l, !0);
                                    return u.changes.length ? [!1, u] : null
                                }
                            },
                            commitUpdate(e, [t, i], a, s, l, u) {
                                t ? function(e, t, i, a) {
                                    var s;
                                    let l = null == (s = e.__r3f) ? void 0 : s.parent;
                                    if (!l) return;
                                    let u = r(t, i, e.__r3f.root);
                                    if (e.children) {
                                        for (let t of e.children) t.__r3f && n(u, t);
                                        e.children = e.children.filter(e => !e.__r3f)
                                    }
                                    e.__r3f.objects.forEach(e => n(u, e)), e.__r3f.objects = [], e.__r3f.autoRemovedBeforeAppend || o(l, e), u.parent && (u.__r3f.autoRemovedBeforeAppend = !0), n(l, u), u.raycast && u.__r3f.eventCount && D(u).getState().internal.interaction.push(u), [a, a.alternate].forEach(e => {
                                        null !== e && (e.stateNode = u, e.ref && ("function" == typeof e.ref ? e.ref(u) : e.ref.current = u))
                                    })
                                }(e, a, l, u) : z(e, i)
                            },
                            commitMount(e, t, r, n) {
                                var i;
                                let a = null != (i = e.__r3f) ? i : {};
                                e.raycast && a.handlers && a.eventCount && D(e).getState().internal.interaction.push(e)
                            },
                            getPublicInstance: e => e,
                            prepareForCommit: () => null,
                            preparePortalMount: e => L(e.getState().scene),
                            resetAfterCommit: () => {},
                            shouldSetTextContent: () => !1,
                            clearContainer: () => !1,
                            hideInstance(e) {
                                var t;
                                let {
                                    attach: r,
                                    parent: n
                                } = null != (t = e.__r3f) ? t : {};
                                r && n && k(n, e, r), e.isObject3D && (e.visible = !1), j(e)
                            },
                            unhideInstance(e, t) {
                                var r;
                                let {
                                    attach: n,
                                    parent: i
                                } = null != (r = e.__r3f) ? r : {};
                                n && i && G(i, e, n), (e.isObject3D && null == t.visible || t.visible) && (e.visible = !0), j(e)
                            },
                            createTextInstance: s,
                            hideTextInstance: s,
                            unhideTextInstance: s,
                            getCurrentEventPriority: () => t ? t() : c.DefaultEventPriority,
                            beforeActiveInstanceBlur: () => {},
                            afterActiveInstanceBlur: () => {},
                            detachDeletedInstance: () => {},
                            now: "undefined" != typeof performance && P.fun(performance.now) ? performance.now : P.fun(Date.now) ? Date.now : () => 0,
                            scheduleTimeout: P.fun(setTimeout) ? setTimeout : void 0,
                            cancelTimeout: P.fun(clearTimeout) ? clearTimeout : void 0
                        }),
                        applyProps: z
                    }
                }(0, function() {
                    var e;
                    let t = "undefined" != typeof self && self || "undefined" != typeof window && window;
                    if (!t) return c.DefaultEventPriority;
                    switch (null == (e = t.event) ? void 0 : e.type) {
                        case "click":
                        case "contextmenu":
                        case "dblclick":
                        case "pointercancel":
                        case "pointerdown":
                        case "pointerup":
                            return c.DiscreteEventPriority;
                        case "pointermove":
                        case "pointerout":
                        case "pointerover":
                        case "pointerenter":
                        case "pointerleave":
                        case "wheel":
                            return c.ContinuousEventPriority;
                        default:
                            return c.DefaultEventPriority
                    }
                }),
                ev = {
                    objects: "shallow",
                    strict: !1
                },
                ey = (e, t) => {
                    let r = "function" == typeof e ? e(t) : e;
                    return Z(r) ? r : new l.WebGLRenderer({
                        powerPreference: "high-performance",
                        canvas: t,
                        antialias: !0,
                        alpha: !0,
                        ...e
                    })
                };

            function eC(e) {
                let t, r;
                let n = eh.get(e),
                    i = null == n ? void 0 : n.fiber,
                    a = null == n ? void 0 : n.store;
                n && console.warn("R3F.createRoot should only be called once!");
                let o = "function" == typeof reportError ? reportError : console.error,
                    s = a || $(ep, em),
                    u = i || eg.createContainer(s, c.ConcurrentRoot, null, !1, null, "", o, null);
                n || eh.set(e, {
                    fiber: u,
                    store: s
                });
                let d = !1;
                return {
                    configure(n = {}) {
                        var i, a;
                        let {
                            gl: o,
                            size: u,
                            scene: c,
                            events: f,
                            onCreated: h,
                            shadows: p = !1,
                            linear: m = !1,
                            flat: g = !1,
                            legacy: A = !1,
                            orthographic: v = !1,
                            frameloop: y = "always",
                            dpr: C = [1, 2],
                            performance: B,
                            raycaster: b,
                            camera: E,
                            onPointerMissed: w
                        } = n, M = s.getState(), T = M.gl;
                        M.gl || M.set({
                            gl: T = ey(o, e)
                        });
                        let x = M.raycaster;
                        x || M.set({
                            raycaster: x = new l.Raycaster
                        });
                        let {
                            params: F,
                            ...S
                        } = b || {};
                        if (P.equ(S, x, ev) || eA(x, { ...S
                            }), P.equ(F, x.params, ev) || eA(x, {
                                params: { ...x.params,
                                    ...F
                                }
                            }), !M.camera || M.camera === r && !P.equ(r, E, ev)) {
                            r = E;
                            let e = E instanceof l.Camera,
                                t = e ? E : v ? new l.OrthographicCamera(0, 0, 0, 0, .1, 1e3) : new l.PerspectiveCamera(75, 0, .1, 1e3);
                            e || (t.position.z = 5, E && (eA(t, E), ("aspect" in E || "left" in E || "right" in E || "bottom" in E || "top" in E) && (t.manual = !0, t.updateProjectionMatrix())), M.camera || null != E && E.rotation || t.lookAt(0, 0, 0)), M.set({
                                camera: t
                            }), x.camera = t
                        }
                        if (!M.scene) {
                            let e;
                            c instanceof l.Scene ? e = c : (e = new l.Scene, c && eA(e, c)), M.set({
                                scene: L(e)
                            })
                        }
                        if (!M.xr) {
                            let e = (e, t) => {
                                    let r = s.getState();
                                    "never" !== r.frameloop && em(e, !0, r, t)
                                },
                                t = () => {
                                    let t = s.getState();
                                    t.gl.xr.enabled = t.gl.xr.isPresenting, t.gl.xr.setAnimationLoop(t.gl.xr.isPresenting ? e : null), t.gl.xr.isPresenting || ep(t)
                                },
                                r = {
                                    connect() {
                                        let e = s.getState().gl;
                                        e.xr.addEventListener("sessionstart", t), e.xr.addEventListener("sessionend", t)
                                    },
                                    disconnect() {
                                        let e = s.getState().gl;
                                        e.xr.removeEventListener("sessionstart", t), e.xr.removeEventListener("sessionend", t)
                                    }
                                };
                            "function" == typeof(null == (i = T.xr) ? void 0 : i.addEventListener) && r.connect(), M.set({
                                xr: r
                            })
                        }
                        if (T.shadowMap) {
                            let e = T.shadowMap.enabled,
                                t = T.shadowMap.type;
                            if (T.shadowMap.enabled = !!p, P.boo(p)) T.shadowMap.type = l.PCFSoftShadowMap;
                            else if (P.str(p)) {
                                let e = {
                                    basic: l.BasicShadowMap,
                                    percentage: l.PCFShadowMap,
                                    soft: l.PCFSoftShadowMap,
                                    variance: l.VSMShadowMap
                                };
                                T.shadowMap.type = null != (a = e[p]) ? a : l.PCFSoftShadowMap
                            } else P.obj(p) && Object.assign(T.shadowMap, p);
                            (e !== T.shadowMap.enabled || t !== T.shadowMap.type) && (T.shadowMap.needsUpdate = !0)
                        }
                        let R = _();
                        R && ("enabled" in R ? R.enabled = !A : "legacyMode" in R && (R.legacyMode = A)), d || eA(T, {
                            outputEncoding: m ? 3e3 : 3001,
                            toneMapping: g ? l.NoToneMapping : l.ACESFilmicToneMapping
                        }), M.legacy !== A && M.set(() => ({
                            legacy: A
                        })), M.linear !== m && M.set(() => ({
                            linear: m
                        })), M.flat !== g && M.set(() => ({
                            flat: g
                        })), !o || P.fun(o) || Z(o) || P.equ(o, T, ev) || eA(T, o), f && !M.events.handlers && M.set({
                            events: f(s)
                        });
                        let I = function(e, t) {
                            let r = "undefined" != typeof HTMLCanvasElement && e instanceof HTMLCanvasElement;
                            if (t) {
                                let {
                                    width: e,
                                    height: n,
                                    top: i,
                                    left: a,
                                    updateStyle: o = r
                                } = t;
                                return {
                                    width: e,
                                    height: n,
                                    top: i,
                                    left: a,
                                    updateStyle: o
                                }
                            }
                            if ("undefined" != typeof HTMLCanvasElement && e instanceof HTMLCanvasElement && e.parentElement) {
                                let {
                                    width: t,
                                    height: n,
                                    top: i,
                                    left: a
                                } = e.parentElement.getBoundingClientRect();
                                return {
                                    width: t,
                                    height: n,
                                    top: i,
                                    left: a,
                                    updateStyle: r
                                }
                            }
                            return "undefined" != typeof OffscreenCanvas && e instanceof OffscreenCanvas ? {
                                width: e.width,
                                height: e.height,
                                top: 0,
                                left: 0,
                                updateStyle: r
                            } : {
                                width: 0,
                                height: 0,
                                top: 0,
                                left: 0
                            }
                        }(e, u);
                        return P.equ(I, M.size, ev) || M.setSize(I.width, I.height, I.updateStyle, I.top, I.left), C && M.viewport.dpr !== O(C) && M.setDpr(C), M.frameloop !== y && M.setFrameloop(y), M.onPointerMissed || M.set({
                            onPointerMissed: w
                        }), B && !P.equ(B, M.performance, ev) && M.set(e => ({
                            performance: { ...e.performance,
                                ...B
                            }
                        })), t = h, d = !0, this
                    },
                    render(r) {
                        return d || this.configure(), eg.updateContainer((0, A.jsx)(eB, {
                            store: s,
                            children: r,
                            onCreated: t,
                            rootElement: e
                        }), u, null, () => void 0), s
                    },
                    unmount() {
                        e_(e)
                    }
                }
            }

            function eB({
                store: e,
                children: t,
                onCreated: r,
                rootElement: n
            }) {
                return w(() => {
                    let t = e.getState();
                    t.set(e => ({
                        internal: { ...e.internal,
                            active: !0
                        }
                    })), r && r(t), e.getState().events.connected || null == t.events.connect || t.events.connect(n)
                }, []), (0, A.jsx)(q.Provider, {
                    value: e,
                    children: t
                })
            }

            function e_(e, t) {
                let r = eh.get(e),
                    n = null == r ? void 0 : r.fiber;
                if (n) {
                    let i = null == r ? void 0 : r.store.getState();
                    i && (i.internal.active = !1), eg.updateContainer(null, n, null, () => {
                        i && setTimeout(() => {
                            try {
                                var r, n, a, o;
                                null == i.events.disconnect || i.events.disconnect(), null == (r = i.gl) || null == (n = r.renderLists) || null == n.dispose || n.dispose(), null == (a = i.gl) || null == a.forceContextLoss || a.forceContextLoss(), null != (o = i.gl) && o.xr && i.xr.disconnect(),
                                    function(e) {
                                        for (let t in e.dispose && "Scene" !== e.type && e.dispose(), e) null == t.dispose || t.dispose(), delete e[t]
                                    }(i), eh.delete(e), t && t(e)
                            } catch (e) {}
                        }, 500)
                    })
                }
            }

            function eb(e, t, r) {
                return (0, A.jsx)(eE, {
                    children: e,
                    container: t,
                    state: r
                }, t.uuid)
            }

            function eE({
                state: e = {},
                children: t,
                container: r
            }) {
                let {
                    events: n,
                    size: i,
                    ...a
                } = e, o = es(), [s] = u.useState(() => new l.Raycaster), [c] = u.useState(() => new l.Vector2), d = u.useCallback((e, t) => {
                    let u;
                    let d = { ...e
                    };
                    if (Object.keys(e).forEach(r => {
                            (W.includes(r) || e[r] !== t[r] && t[r]) && delete d[r]
                        }), t && i) {
                        let r = t.camera;
                        u = e.viewport.getCurrentViewport(r, new l.Vector3, i), r !== e.camera && Q(r, i)
                    }
                    return { ...d,
                        scene: r,
                        raycaster: s,
                        pointer: c,
                        mouse: c,
                        previousRoot: o,
                        events: { ...e.events,
                            ...null == t ? void 0 : t.events,
                            ...n
                        },
                        size: { ...e.size,
                            ...i
                        },
                        viewport: { ...e.viewport,
                            ...u
                        },
                        ...a
                    }
                }, [e]), [h] = u.useState(() => {
                    let e = o.getState();
                    return f((t, l) => ({ ...e,
                        scene: r,
                        raycaster: s,
                        pointer: c,
                        mouse: c,
                        previousRoot: o,
                        events: { ...e.events,
                            ...n
                        },
                        size: { ...e.size,
                            ...i
                        },
                        ...a,
                        set: t,
                        get: l,
                        setEvents: e => t(t => ({ ...t,
                            events: { ...t.events,
                                ...e
                            }
                        }))
                    }))
                });
                return u.useEffect(() => {
                    let e = o.subscribe(e => h.setState(t => d(e, t)));
                    return () => {
                        e()
                    }
                }, [d]), u.useEffect(() => {
                    h.setState(e => d(o.getState(), e))
                }, [d]), u.useEffect(() => () => {
                    h.destroy()
                }, []), (0, A.jsx)(A.Fragment, {
                    children: eg.createPortal((0, A.jsx)(q.Provider, {
                        value: h,
                        children: t
                    }), h, null)
                })
            }
            eg.injectIntoDevTools({
                bundleType: 0,
                rendererPackageName: "@react-three/fiber",
                version: u.version
            }), u.unstable_act
        },
        15029: function(e, t, r) {
            "use strict";
            r.d(t, {
                Xz: function() {
                    return F
                },
                U3: function() {
                    return T
                }
            });
            var n, i, a = r(19390),
                o = r(67294),
                s = r(99477),
                l = r(83826),
                u = r.n(l);
            let c = ["x", "y", "top", "bottom", "left", "right", "width", "height"],
                d = (e, t) => c.every(r => e[r] === t[r]);
            var f = Object.defineProperty,
                h = Object.defineProperties,
                p = Object.getOwnPropertyDescriptors,
                m = Object.getOwnPropertySymbols,
                g = Object.prototype.hasOwnProperty,
                A = Object.prototype.propertyIsEnumerable,
                v = (e, t, r) => t in e ? f(e, t, {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: r
                }) : e[t] = r,
                y = (e, t) => {
                    for (var r in t || (t = {})) g.call(t, r) && v(e, r, t[r]);
                    if (m)
                        for (var r of m(t)) A.call(t, r) && v(e, r, t[r]);
                    return e
                },
                C = (e, t) => h(e, p(t));

            function B(e) {
                try {
                    return Object.defineProperties(e, {
                        _currentRenderer: {
                            get: () => null,
                            set() {}
                        },
                        _currentRenderer2: {
                            get: () => null,
                            set() {}
                        }
                    })
                } catch (t) {
                    return e
                }
            }
            "undefined" != typeof window && ((null == (n = window.document) ? void 0 : n.createElement) || (null == (i = window.navigator) ? void 0 : i.product) === "ReactNative") ? o.useLayoutEffect : o.useEffect;
            let _ = console.error;
            console.error = function() {
                let e = [...arguments].join("");
                if ((null == e ? void 0 : e.startsWith("Warning:")) && e.includes("useContext")) {
                    console.error = _;
                    return
                }
                return _.apply(this, arguments)
            };
            let b = B(o.createContext(null));
            class E extends o.Component {
                render() {
                    return o.createElement(b.Provider, {
                        value: this._reactInternals
                    }, this.props.children)
                }
            }
            var w = r(85893);
            r(32576), r(76525), r(45431);
            let M = {
                onClick: ["click", !1],
                onContextMenu: ["contextmenu", !1],
                onDoubleClick: ["dblclick", !1],
                onWheel: ["wheel", !0],
                onPointerDown: ["pointerdown", !0],
                onPointerUp: ["pointerup", !0],
                onPointerLeave: ["pointerleave", !0],
                onPointerMove: ["pointermove", !0],
                onPointerCancel: ["pointercancel", !0],
                onLostPointerCapture: ["lostpointercapture", !0]
            };

            function T(e) {
                let {
                    handlePointer: t
                } = (0, a.c)(e);
                return {
                    priority: 1,
                    enabled: !0,
                    compute(e, t, r) {
                        t.pointer.set(e.offsetX / t.size.width * 2 - 1, -(e.offsetY / t.size.height * 2) + 1), t.raycaster.setFromCamera(t.pointer, t.camera)
                    },
                    connected: void 0,
                    handlers: Object.keys(M).reduce((e, r) => ({ ...e,
                        [r]: t(r)
                    }), {}),
                    update: () => {
                        var t;
                        let {
                            events: r,
                            internal: n
                        } = e.getState();
                        null != (t = n.lastEvent) && t.current && r.handlers && r.handlers.onPointerMove(n.lastEvent.current)
                    },
                    connect: t => {
                        var r;
                        let {
                            set: n,
                            events: i
                        } = e.getState();
                        null == i.disconnect || i.disconnect(), n(e => ({
                            events: { ...e.events,
                                connected: t
                            }
                        })), Object.entries(null != (r = i.handlers) ? r : []).forEach(([e, r]) => {
                            let [n, i] = M[e];
                            t.addEventListener(n, r, {
                                passive: i
                            })
                        })
                    },
                    disconnect: () => {
                        let {
                            set: t,
                            events: r
                        } = e.getState();
                        if (r.connected) {
                            var n;
                            Object.entries(null != (n = r.handlers) ? n : []).forEach(([e, t]) => {
                                if (r && r.connected instanceof HTMLElement) {
                                    let [n] = M[e];
                                    r.connected.removeEventListener(n, t)
                                }
                            }), t(e => ({
                                events: { ...e.events,
                                    connected: void 0
                                }
                            }))
                        }
                    }
                }
            }
            let x = o.forwardRef(function({
                    children: e,
                    fallback: t,
                    resize: r,
                    style: n,
                    gl: i,
                    events: l = T,
                    eventSource: c,
                    eventPrefix: f,
                    shadows: h,
                    linear: p,
                    flat: m,
                    legacy: g,
                    orthographic: A,
                    frameloop: v,
                    dpr: _,
                    performance: M,
                    raycaster: x,
                    camera: F,
                    scene: S,
                    onPointerMissed: R,
                    onCreated: O,
                    ...I
                }, D) {
                    o.useMemo(() => (0, a.e)(s), []);
                    let P = function() {
                            let e = function() {
                                let e = function() {
                                        let e = o.useContext(b);
                                        if (null === e) throw Error("its-fine: useFiber must be called within a <FiberProvider />!");
                                        let t = o.useId();
                                        return o.useMemo(() => {
                                            for (let r of [e, null == e ? void 0 : e.alternate]) {
                                                if (!r) continue;
                                                let e = function e(t, r, n) {
                                                    if (!t) return;
                                                    if (!0 === n(t)) return t;
                                                    let i = r ? t.return : t.child;
                                                    for (; i;) {
                                                        let t = e(i, r, n);
                                                        if (t) return t;
                                                        i = r ? null : i.sibling
                                                    }
                                                }(r, !1, e => {
                                                    let r = e.memoizedState;
                                                    for (; r;) {
                                                        if (r.memoizedState === t) return !0;
                                                        r = r.next
                                                    }
                                                });
                                                if (e) return e
                                            }
                                        }, [e, t])
                                    }(),
                                    [t] = o.useState(() => new Map);
                                t.clear();
                                let r = e;
                                for (; r;) {
                                    if (r.type && "object" == typeof r.type) {
                                        let e = void 0 === r.type._context && r.type.Provider === r.type ? r.type : r.type._context;
                                        e && e !== b && !t.has(e) && t.set(e, o.useContext(B(e)))
                                    }
                                    r = r.return
                                }
                                return t
                            }();
                            return o.useMemo(() => Array.from(e.keys()).reduce((t, r) => n => o.createElement(t, null, o.createElement(r.Provider, C(y({}, n), {
                                value: e.get(r)
                            }))), e => o.createElement(E, y({}, e))), [e])
                        }(),
                        [L, H] = function(e) {
                            var t;
                            let {
                                debounce: r,
                                scroll: n,
                                polyfill: i,
                                offsetSize: a
                            } = void 0 === e ? {
                                debounce: 0,
                                scroll: !1,
                                offsetSize: !1
                            } : e, s = i || ("undefined" == typeof window ? class {} : window.ResizeObserver);
                            if (!s) throw Error("This browser does not support ResizeObserver out of the box. See: https://github.com/react-spring/react-use-measure/#resize-observer-polyfills");
                            let [l, c] = (0, o.useState)({
                                left: 0,
                                top: 0,
                                width: 0,
                                height: 0,
                                bottom: 0,
                                right: 0,
                                x: 0,
                                y: 0
                            }), f = (0, o.useRef)({
                                element: null,
                                scrollContainers: null,
                                resizeObserver: null,
                                lastBounds: l
                            }), h = r ? "number" == typeof r ? r : r.scroll : null, p = r ? "number" == typeof r ? r : r.resize : null, m = (0, o.useRef)(!1);
                            (0, o.useEffect)(() => (m.current = !0, () => void(m.current = !1)));
                            let [g, A, v] = (0, o.useMemo)(() => {
                                let e = () => {
                                    if (!f.current.element) return;
                                    let {
                                        left: e,
                                        top: t,
                                        width: r,
                                        height: n,
                                        bottom: i,
                                        right: o,
                                        x: s,
                                        y: l
                                    } = f.current.element.getBoundingClientRect(), u = {
                                        left: e,
                                        top: t,
                                        width: r,
                                        height: n,
                                        bottom: i,
                                        right: o,
                                        x: s,
                                        y: l
                                    };
                                    f.current.element instanceof HTMLElement && a && (u.height = f.current.element.offsetHeight, u.width = f.current.element.offsetWidth), Object.freeze(u), m.current && !d(f.current.lastBounds, u) && c(f.current.lastBounds = u)
                                };
                                return [e, p ? u()(e, p) : e, h ? u()(e, h) : e]
                            }, [c, a, h, p]);

                            function y() {
                                f.current.scrollContainers && (f.current.scrollContainers.forEach(e => e.removeEventListener("scroll", v, !0)), f.current.scrollContainers = null), f.current.resizeObserver && (f.current.resizeObserver.disconnect(), f.current.resizeObserver = null)
                            }

                            function C() {
                                f.current.element && (f.current.resizeObserver = new s(v), f.current.resizeObserver.observe(f.current.element), n && f.current.scrollContainers && f.current.scrollContainers.forEach(e => e.addEventListener("scroll", v, {
                                    capture: !0,
                                    passive: !0
                                })))
                            }
                            return t = !!n, (0, o.useEffect)(() => {
                                if (t) return window.addEventListener("scroll", v, {
                                    capture: !0,
                                    passive: !0
                                }), () => void window.removeEventListener("scroll", v, !0)
                            }, [v, t]), (0, o.useEffect)(() => (window.addEventListener("resize", A), () => void window.removeEventListener("resize", A)), [A]), (0, o.useEffect)(() => {
                                y(), C()
                            }, [n, v, A]), (0, o.useEffect)(() => y, []), [e => {
                                e && e !== f.current.element && (y(), f.current.element = e, f.current.scrollContainers = function e(t) {
                                    let r = [];
                                    if (!t || t === document.body) return r;
                                    let {
                                        overflow: n,
                                        overflowX: i,
                                        overflowY: a
                                    } = window.getComputedStyle(t);
                                    return [n, i, a].some(e => "auto" === e || "scroll" === e) && r.push(t), [...r, ...e(t.parentElement)]
                                }(e), C())
                            }, l, g]
                        }({
                            scroll: !0,
                            debounce: {
                                scroll: 50,
                                resize: 0
                            },
                            ...r
                        }),
                        U = o.useRef(null),
                        G = o.useRef(null);
                    o.useImperativeHandle(D, () => U.current);
                    let k = (0, a.u)(R),
                        [N, J] = o.useState(!1),
                        [z, j] = o.useState(!1);
                    if (N) throw N;
                    if (z) throw z;
                    let K = o.useRef(null);
                    (0, a.a)(() => {
                        let t = U.current;
                        H.width > 0 && H.height > 0 && t && (K.current || (K.current = (0, a.b)(t)), K.current.configure({
                            gl: i,
                            events: l,
                            shadows: h,
                            linear: p,
                            flat: m,
                            legacy: g,
                            orthographic: A,
                            frameloop: v,
                            dpr: _,
                            performance: M,
                            raycaster: x,
                            camera: F,
                            scene: S,
                            size: H,
                            onPointerMissed: (...e) => null == k.current ? void 0 : k.current(...e),
                            onCreated: e => {
                                null == e.events.connect || e.events.connect(c ? (0, a.i)(c) ? c.current : c : G.current), f && e.setEvents({
                                    compute: (e, t) => {
                                        let r = e[f + "X"],
                                            n = e[f + "Y"];
                                        t.pointer.set(r / t.size.width * 2 - 1, -(n / t.size.height * 2) + 1), t.raycaster.setFromCamera(t.pointer, t.camera)
                                    }
                                }), null == O || O(e)
                            }
                        }), K.current.render((0, w.jsx)(P, {
                            children: (0, w.jsx)(a.E, {
                                set: j,
                                children: (0, w.jsx)(o.Suspense, {
                                    fallback: (0, w.jsx)(a.B, {
                                        set: J
                                    }),
                                    children: e
                                })
                            })
                        })))
                    }), o.useEffect(() => {
                        let e = U.current;
                        if (e) return () => (0, a.d)(e)
                    }, []);
                    let Q = c ? "none" : "auto";
                    return (0, w.jsx)("div", {
                        ref: G,
                        style: {
                            position: "relative",
                            width: "100%",
                            height: "100%",
                            overflow: "hidden",
                            pointerEvents: Q,
                            ...n
                        },
                        ...I,
                        children: (0, w.jsx)("div", {
                            ref: L,
                            style: {
                                width: "100%",
                                height: "100%"
                            },
                            children: (0, w.jsx)("canvas", {
                                ref: U,
                                style: {
                                    display: "block"
                                },
                                children: t
                            })
                        })
                    })
                }),
                F = o.forwardRef(function(e, t) {
                    return (0, w.jsx)(E, {
                        children: (0, w.jsx)(x, { ...e,
                            ref: t
                        })
                    })
                })
        },
        51906: function(e, t) {
            "use strict";

            function r(e, t) {
                var r = e.length;
                for (e.push(t); 0 < r;) {
                    var n = r - 1 >>> 1,
                        i = e[n];
                    if (0 < a(i, t)) e[n] = t, e[r] = i, r = n;
                    else break
                }
            }

            function n(e) {
                return 0 === e.length ? null : e[0]
            }

            function i(e) {
                if (0 === e.length) return null;
                var t = e[0],
                    r = e.pop();
                if (r !== t) {
                    e[0] = r;
                    for (var n = 0, i = e.length, o = i >>> 1; n < o;) {
                        var s = 2 * (n + 1) - 1,
                            l = e[s],
                            u = s + 1,
                            c = e[u];
                        if (0 > a(l, r)) u < i && 0 > a(c, l) ? (e[n] = c, e[u] = r, n = u) : (e[n] = l, e[s] = r, n = s);
                        else if (u < i && 0 > a(c, r)) e[n] = c, e[u] = r, n = u;
                        else break
                    }
                }
                return t
            }

            function a(e, t) {
                var r = e.sortIndex - t.sortIndex;
                return 0 !== r ? r : e.id - t.id
            }
            if ("object" == typeof performance && "function" == typeof performance.now) {
                var o, s = performance;
                t.unstable_now = function() {
                    return s.now()
                }
            } else {
                var l = Date,
                    u = l.now();
                t.unstable_now = function() {
                    return l.now() - u
                }
            }
            var c = [],
                d = [],
                f = 1,
                h = null,
                p = 3,
                m = !1,
                g = !1,
                A = !1,
                v = "function" == typeof setTimeout ? setTimeout : null,
                y = "function" == typeof clearTimeout ? clearTimeout : null,
                C = "undefined" != typeof setImmediate ? setImmediate : null;

            function B(e) {
                for (var t = n(d); null !== t;) {
                    if (null === t.callback) i(d);
                    else if (t.startTime <= e) i(d), t.sortIndex = t.expirationTime, r(c, t);
                    else break;
                    t = n(d)
                }
            }

            function _(e) {
                if (A = !1, B(e), !g) {
                    if (null !== n(c)) g = !0, I(b);
                    else {
                        var t = n(d);
                        null !== t && D(_, t.startTime - e)
                    }
                }
            }

            function b(e, r) {
                g = !1, A && (A = !1, y(M), M = -1), m = !0;
                var a = p;
                try {
                    for (B(r), h = n(c); null !== h && (!(h.expirationTime > r) || e && !F());) {
                        var o = h.callback;
                        if ("function" == typeof o) {
                            h.callback = null, p = h.priorityLevel;
                            var s = o(h.expirationTime <= r);
                            r = t.unstable_now(), "function" == typeof s ? h.callback = s : h === n(c) && i(c), B(r)
                        } else i(c);
                        h = n(c)
                    }
                    if (null !== h) var l = !0;
                    else {
                        var u = n(d);
                        null !== u && D(_, u.startTime - r), l = !1
                    }
                    return l
                } finally {
                    h = null, p = a, m = !1
                }
            }
            "undefined" != typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
            var E = !1,
                w = null,
                M = -1,
                T = 5,
                x = -1;

            function F() {
                return !(t.unstable_now() - x < T)
            }

            function S() {
                if (null !== w) {
                    var e = t.unstable_now();
                    x = e;
                    var r = !0;
                    try {
                        r = w(!0, e)
                    } finally {
                        r ? o() : (E = !1, w = null)
                    }
                } else E = !1
            }
            if ("function" == typeof C) o = function() {
                C(S)
            };
            else if ("undefined" != typeof MessageChannel) {
                var R = new MessageChannel,
                    O = R.port2;
                R.port1.onmessage = S, o = function() {
                    O.postMessage(null)
                }
            } else o = function() {
                v(S, 0)
            };

            function I(e) {
                w = e, E || (E = !0, o())
            }

            function D(e, r) {
                M = v(function() {
                    e(t.unstable_now())
                }, r)
            }
            t.unstable_IdlePriority = 5, t.unstable_ImmediatePriority = 1, t.unstable_LowPriority = 4, t.unstable_NormalPriority = 3, t.unstable_Profiling = null, t.unstable_UserBlockingPriority = 2, t.unstable_cancelCallback = function(e) {
                e.callback = null
            }, t.unstable_continueExecution = function() {
                g || m || (g = !0, I(b))
            }, t.unstable_forceFrameRate = function(e) {
                0 > e || 125 < e ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : T = 0 < e ? Math.floor(1e3 / e) : 5
            }, t.unstable_getCurrentPriorityLevel = function() {
                return p
            }, t.unstable_getFirstCallbackNode = function() {
                return n(c)
            }, t.unstable_next = function(e) {
                switch (p) {
                    case 1:
                    case 2:
                    case 3:
                        var t = 3;
                        break;
                    default:
                        t = p
                }
                var r = p;
                p = t;
                try {
                    return e()
                } finally {
                    p = r
                }
            }, t.unstable_pauseExecution = function() {}, t.unstable_requestPaint = function() {}, t.unstable_runWithPriority = function(e, t) {
                switch (e) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        break;
                    default:
                        e = 3
                }
                var r = p;
                p = e;
                try {
                    return t()
                } finally {
                    p = r
                }
            }, t.unstable_scheduleCallback = function(e, i, a) {
                var o = t.unstable_now();
                switch (a = "object" == typeof a && null !== a && "number" == typeof(a = a.delay) && 0 < a ? o + a : o, e) {
                    case 1:
                        var s = -1;
                        break;
                    case 2:
                        s = 250;
                        break;
                    case 5:
                        s = 1073741823;
                        break;
                    case 4:
                        s = 1e4;
                        break;
                    default:
                        s = 5e3
                }
                return s = a + s, e = {
                    id: f++,
                    callback: i,
                    priorityLevel: e,
                    startTime: a,
                    expirationTime: s,
                    sortIndex: -1
                }, a > o ? (e.sortIndex = a, r(d, e), null === n(c) && e === n(d) && (A ? (y(M), M = -1) : A = !0, D(_, a - o))) : (e.sortIndex = s, r(c, e), g || m || (g = !0, I(b))), e
            }, t.unstable_shouldYield = F, t.unstable_wrapCallback = function(e) {
                var t = p;
                return function() {
                    var r = p;
                    p = t;
                    try {
                        return e.apply(this, arguments)
                    } finally {
                        p = r
                    }
                }
            }
        },
        45431: function(e, t, r) {
            "use strict";
            e.exports = r(51906)
        },
        63301: function(e, t, r) {
            "use strict";
            r.d(t, {
                jc: function() {
                    return eu
                },
                wI: function() {
                    return en
                },
                ib: function() {
                    return e_
                },
                MZ: function() {
                    return W
                },
                DL: function() {
                    return X
                },
                Ji: function() {
                    return ew
                }
            });
            var n = r(4162),
                i = r(19390),
                a = r(67294),
                o = r(99477),
                s = r(58139);

            function l(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), r.push.apply(r, n)
                }
                return r
            }

            function u(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? l(Object(r), !0).forEach(function(t) {
                        var n;
                        n = r[t], t in e ? Object.defineProperty(e, t, {
                            value: n,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : e[t] = n
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : l(Object(r)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    })
                }
                return e
            }
            let c = new o.Quaternion;
            new o.Euler;
            let d = new o.Vector3;
            new o.Object3D;
            let f = new o.Matrix4,
                h = new o.Vector3,
                p = new o.Quaternion,
                m = new o.Vector3,
                g = e => {
                    let [t, r, n] = e;
                    return new o.Vector3(t, r, n)
                },
                A = ({
                    x: e,
                    y: t,
                    z: r,
                    w: n
                }) => c.set(e, t, r, n),
                v = e => Array.isArray(e) ? new n.Vector3(e[0], e[1], e[2]) : "number" == typeof e ? new n.Vector3(e, e, e) : new n.Vector3(e.x, e.y, e.z),
                y = {
                    fixed: 1,
                    dynamic: 0,
                    kinematicPosition: 2,
                    kinematicVelocity: 3
                },
                C = e => y[e],
                B = (e, t) => {
                    let r = Array.from(e);
                    for (let n = 0; n < e.length / 3; n++) r[3 * n] *= t.x, r[3 * n + 1] *= t.y, r[3 * n + 2] *= t.z;
                    return r
                },
                _ = e => e ? e instanceof o.Quaternion ? [e.x, e.y, e.z, e.w] : e instanceof o.Vector3 || e instanceof o.Euler ? [e.x, e.y, e.z] : Array.isArray(e) ? e : [e] : [0];

            function b(e) {
                let t = (0, a.useRef)();
                return void 0 === t.current && (t.current = {
                    value: "function" == typeof e ? e() : e
                }), t.current.value
            }
            let E = e => {
                    let t = (0, a.useRef)(e),
                        r = (0, a.useRef)(0),
                        n = (0, a.useRef)(0);
                    (0, a.useEffect)(() => {
                        t.current = e
                    }, [e]), (0, a.useEffect)(() => {
                        let e = () => {
                            let i = performance.now(),
                                a = i - n.current;
                            r.current = requestAnimationFrame(e), t.current(a / 1e3), n.current = i
                        };
                        return r.current = requestAnimationFrame(e), () => cancelAnimationFrame(r.current)
                    }, [])
                },
                w = ({
                    onStep: e,
                    updatePriority: t
                }) => ((0, i.C)((t, r) => {
                    e(r)
                }, t), null),
                M = ({
                    onStep: e
                }) => (E(t => {
                    e(t)
                }), null);
            var T = (0, a.memo)(({
                onStep: e,
                type: t,
                updatePriority: r
            }) => "independent" === t ? a.createElement(M, {
                onStep: e
            }) : a.createElement(w, {
                onStep: e,
                updatePriority: r
            }));

            function x(e, t) {
                if (null == e) return {};
                var r, n, i = function(e, t) {
                    if (null == e) return {};
                    var r, n, i = {},
                        a = Object.keys(e);
                    for (n = 0; n < a.length; n++) r = a[n], t.indexOf(r) >= 0 || (i[r] = e[r]);
                    return i
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < a.length; n++) r = a[n], !(t.indexOf(r) >= 0) && Object.prototype.propertyIsEnumerable.call(e, r) && (i[r] = e[r])
                }
                return i
            }
            let F = ["mass", "linearDamping", "angularDamping", "type", "onCollisionEnter", "onCollisionExit", "onIntersectionEnter", "onIntersectionExit", "onContactForce", "children", "canSleep", "ccd", "gravityScale"],
                S = (e, t, r) => {
                    let n = t.slice();
                    if ("heightfield" === e) {
                        let e = n[3];
                        return e.x *= r.x, e.x *= r.y, e.x *= r.z, n
                    }
                    if ("trimesh" === e || "convexHull" === e) return n[0] = B(n[0], r), n;
                    let i = [r.x, r.y, r.z, r.x, r.x];
                    return n.map((e, t) => i[t] * e)
                },
                R = (e, t, r, i) => {
                    let a = S(e.shape, e.args, r),
                        o = n.ColliderDesc[e.shape](...a);
                    return t.createCollider(o, null == i ? void 0 : i())
                },
                O = ["shape", "args"],
                I = "Please pick ONLY ONE of the `density`, `mass` and `massProperties` options.",
                D = (e, t) => {
                    if (void 0 !== t.density) {
                        if (void 0 !== t.mass || void 0 !== t.massProperties) throw Error(I);
                        e.setDensity(t.density);
                        return
                    }
                    if (void 0 !== t.mass) {
                        if (void 0 !== t.massProperties) throw Error(I);
                        e.setMass(t.mass);
                        return
                    }
                    void 0 !== t.massProperties && e.setMassProperties(t.massProperties.mass, t.massProperties.centerOfMass, t.massProperties.principalAngularInertia, t.massProperties.angularInertiaLocalFrame)
                },
                P = {
                    sensor: (e, t) => {
                        e.setSensor(t)
                    },
                    collisionGroups: (e, t) => {
                        e.setCollisionGroups(t)
                    },
                    solverGroups: (e, t) => {
                        e.setSolverGroups(t)
                    },
                    friction: (e, t) => {
                        e.setFriction(t)
                    },
                    frictionCombineRule: (e, t) => {
                        e.setFrictionCombineRule(t)
                    },
                    restitution: (e, t) => {
                        e.setRestitution(t)
                    },
                    restitutionCombineRule: (e, t) => {
                        e.setRestitutionCombineRule(t)
                    },
                    quaternion: () => {},
                    position: () => {},
                    rotation: () => {},
                    scale: () => {}
                },
                L = Object.keys(P),
                H = (e, t, r) => {
                    let n = r.get(e.handle);
                    if (n) {
                        var i;
                        let r = n.object.parent.getWorldScale(d),
                            a = null === (i = n.worldParent) || void 0 === i ? void 0 : i.matrixWorld.clone().invert();
                        n.object.updateWorldMatrix(!0, !1), f.copy(n.object.matrixWorld), a && f.premultiply(a), f.decompose(h, p, m), e.parent() ? (e.setTranslationWrtParent({
                            x: h.x * r.x,
                            y: h.y * r.y,
                            z: h.z * r.z
                        }), e.setRotationWrtParent(p)) : (e.setTranslation({
                            x: h.x * r.x,
                            y: h.y * r.y,
                            z: h.z * r.z
                        }), e.setRotation(p)), L.forEach(r => {
                            if (r in t) {
                                let n = t[r];
                                P[r](e, n, t)
                            }
                        }), D(e, t)
                    }
                },
                U = (e, t, r) => {
                    let n = (0, a.useMemo)(() => L.flatMap(e => _(t[e])), [t]);
                    (0, a.useEffect)(() => {
                        H(e(), t, r)
                    }, [...n, e])
                },
                G = e => {
                    let t = !1;
                    return e.traverseAncestors(e => {
                        "MeshCollider" === e.userData.r3RapierType && (t = !0)
                    }), t
                },
                k = (e, t, r) => ({
                    collider: e,
                    worldParent: r || void 0,
                    object: t
                }),
                N = {
                    cuboid: "cuboid",
                    ball: "ball",
                    hull: "convexHull",
                    trimesh: "trimesh"
                },
                J = ({
                    object: e,
                    ignoreMeshColliders: t = !0,
                    options: r
                }) => {
                    let n = [];
                    e.updateWorldMatrix(!0, !1);
                    let i = e.matrixWorld.clone().invert(),
                        a = e => {
                            if ("isMesh" in e) {
                                if (t && G(e)) return;
                                let a = e.getWorldScale(m),
                                    s = N[r.colliders || "cuboid"];
                                e.updateWorldMatrix(!0, !1), f.copy(e.matrixWorld).premultiply(i).decompose(h, p, m);
                                let l = new o.Euler().setFromQuaternion(p, "XYZ"),
                                    {
                                        geometry: c
                                    } = e,
                                    {
                                        args: d,
                                        offset: g
                                    } = z(c, r.colliders || "cuboid"),
                                    A = u(u({}, Q(r)), {}, {
                                        args: d,
                                        shape: s,
                                        rotation: [l.x, l.y, l.z],
                                        position: [h.x + g.x * a.x, h.y + g.y * a.y, h.z + g.z * a.z],
                                        scale: [a.x, a.y, a.z]
                                    });
                                n.push(A)
                            }
                        };
                    return r.includeInvisible ? e.traverse(a) : e.traverseVisible(a), n
                },
                z = (e, t) => {
                    switch (t) {
                        case "cuboid":
                            {
                                e.computeBoundingBox();
                                let {
                                    boundingBox: t
                                } = e,
                                r = t.getSize(new o.Vector3);
                                return {
                                    args: [r.x / 2, r.y / 2, r.z / 2],
                                    offset: t.getCenter(new o.Vector3)
                                }
                            }
                        case "ball":
                            {
                                e.computeBoundingSphere();
                                let {
                                    boundingSphere: t
                                } = e;
                                return {
                                    args: [t.radius],
                                    offset: t.center
                                }
                            }
                        case "trimesh":
                            {
                                var r;
                                let t = e.index ? e.clone() : function(e, t = 1e-4) {
                                    t = Math.max(t, Number.EPSILON);
                                    let r = {},
                                        n = e.getIndex(),
                                        i = e.getAttribute("position"),
                                        a = n ? n.count : i.count,
                                        s = 0,
                                        l = Object.keys(e.attributes),
                                        u = {},
                                        c = {},
                                        d = [],
                                        f = ["getX", "getY", "getZ", "getW"];
                                    for (let t = 0, r = l.length; t < r; t++) {
                                        let r = l[t];
                                        u[r] = [];
                                        let n = e.morphAttributes[r];
                                        n && (c[r] = Array(n.length).fill(0).map(() => []))
                                    }
                                    let h = Math.pow(10, Math.log10(1 / t));
                                    for (let t = 0; t < a; t++) {
                                        let i = n ? n.getX(t) : t,
                                            a = "";
                                        for (let t = 0, r = l.length; t < r; t++) {
                                            let r = l[t],
                                                n = e.getAttribute(r),
                                                o = n.itemSize;
                                            for (let e = 0; e < o; e++) a += `${~~(n[f[e]](i)*h)},`
                                        }
                                        if (a in r) d.push(r[a]);
                                        else {
                                            for (let t = 0, r = l.length; t < r; t++) {
                                                let r = l[t],
                                                    n = e.getAttribute(r),
                                                    a = e.morphAttributes[r],
                                                    o = n.itemSize,
                                                    s = u[r],
                                                    d = c[r];
                                                for (let e = 0; e < o; e++) {
                                                    let t = f[e];
                                                    if (s.push(n[t](i)), a)
                                                        for (let e = 0, r = a.length; e < r; e++) d[e].push(a[e][t](i))
                                                }
                                            }
                                            r[a] = s, d.push(s), s++
                                        }
                                    }
                                    let p = e.clone();
                                    for (let t = 0, r = l.length; t < r; t++) {
                                        let r = l[t],
                                            n = e.getAttribute(r),
                                            i = new n.array.constructor(u[r]),
                                            a = new o.BufferAttribute(i, n.itemSize, n.normalized);
                                        if (p.setAttribute(r, a), r in c)
                                            for (let t = 0; t < c[r].length; t++) {
                                                let n = e.morphAttributes[r][t],
                                                    i = new n.array.constructor(c[r][t]),
                                                    a = new o.BufferAttribute(i, n.itemSize, n.normalized);
                                                p.morphAttributes[r][t] = a
                                            }
                                    }
                                    return p.setIndex(d), p
                                }(e);
                                return {
                                    args: [t.attributes.position.array, null === (r = t.index) || void 0 === r ? void 0 : r.array],
                                    offset: new o.Vector3
                                }
                            }
                        case "hull":
                            return {
                                args: [e.clone().attributes.position.array],
                                offset: new o.Vector3
                            }
                    }
                    return {
                        args: [],
                        offset: new o.Vector3
                    }
                },
                j = e => ({
                    collision: !!(null != e && e.onCollisionEnter || null != e && e.onCollisionExit || null != e && e.onIntersectionEnter || null != e && e.onIntersectionExit),
                    contactForce: !!(null != e && e.onContactForce)
                }),
                K = (e, t, r, i = {}) => {
                    let {
                        onCollisionEnter: o,
                        onCollisionExit: s,
                        onIntersectionEnter: l,
                        onIntersectionExit: u,
                        onContactForce: c
                    } = t;
                    (0, a.useEffect)(() => {
                        let a = e();
                        if (a) {
                            let {
                                collision: e,
                                contactForce: d
                            } = j(t), f = e || i.collision, h = d || i.contactForce;
                            f && h ? a.setActiveEvents(n.ActiveEvents.COLLISION_EVENTS | n.ActiveEvents.CONTACT_FORCE_EVENTS) : f ? a.setActiveEvents(n.ActiveEvents.COLLISION_EVENTS) : h && a.setActiveEvents(n.ActiveEvents.CONTACT_FORCE_EVENTS), r.set(a.handle, {
                                onCollisionEnter: o,
                                onCollisionExit: s,
                                onIntersectionEnter: l,
                                onIntersectionExit: u,
                                onContactForce: c
                            })
                        }
                        return () => {
                            a && r.delete(a.handle)
                        }
                    }, [o, s, l, u, c, i])
                },
                Q = (e = {}) => x(e, F),
                V = e => {
                    let t = (0, a.useRef)(e);
                    return (0, a.useEffect)(() => {
                        t.current = e
                    }, [e]), t
                },
                Y = () => {
                    let e = (0, a.useContext)(ee);
                    if (!e) throw Error("react-three-rapier: useRapier must be used within <Physics />!");
                    return e
                },
                X = e => {
                    let {
                        beforeStepCallbacks: t
                    } = Y(), r = V(e);
                    (0, a.useEffect)(() => (t.add(r), () => {
                        t.delete(r)
                    }), [])
                },
                W = e => {
                    let {
                        afterStepCallbacks: t
                    } = Y(), r = V(e);
                    (0, a.useEffect)(() => (t.add(r), () => {
                        t.delete(r)
                    }), [])
                },
                Z = (e, t, r = !0) => {
                    let [n, i] = (0, a.useState)([]);
                    return (0, a.useEffect)(() => {
                        e.current && !1 !== t.colliders && i(J({
                            object: e.current,
                            options: t,
                            ignoreMeshColliders: r
                        }))
                    }, [t.colliders]), n
                },
                q = (0, a.memo)(() => {
                    let {
                        world: e
                    } = Y(), t = (0, a.useRef)(null);
                    return (0, i.C)(() => {
                        let r = t.current;
                        if (!r) return;
                        let n = e.debugRender();
                        r.geometry.setAttribute("position", new o.BufferAttribute(n.vertices, 3)), r.geometry.setAttribute("color", new o.BufferAttribute(n.colors, 4))
                    }), a.createElement("group", null, a.createElement("lineSegments", {
                        ref: t,
                        frustumCulled: !1
                    }, a.createElement("lineBasicMaterial", {
                        color: 16777215,
                        vertexColors: !0
                    }), a.createElement("bufferGeometry", null)))
                }),
                $ = e => {
                    let t;
                    return {
                        proxy: new Proxy({}, {
                            get: (r, n) => (t || (t = e()), Reflect.get(t, n)),
                            set: (r, n, i) => (t || (t = e()), Reflect.set(t, n, i))
                        }),
                        reset: () => {
                            t = void 0
                        },
                        set: e => {
                            t = e
                        }
                    }
                },
                ee = (0, a.createContext)(void 0),
                et = (e, t) => {
                    var r, n, i, a, o, s;
                    return {
                        target: {
                            rigidBody: e.rigidBody.object,
                            collider: e.collider.object,
                            colliderObject: null === (r = e.collider.state) || void 0 === r ? void 0 : r.object,
                            rigidBodyObject: null === (n = e.rigidBody.state) || void 0 === n ? void 0 : n.object
                        },
                        other: {
                            rigidBody: t.rigidBody.object,
                            collider: t.collider.object,
                            colliderObject: null === (i = t.collider.state) || void 0 === i ? void 0 : i.object,
                            rigidBodyObject: null === (a = t.rigidBody.state) || void 0 === a ? void 0 : a.object
                        },
                        rigidBody: t.rigidBody.object,
                        collider: t.collider.object,
                        colliderObject: null === (o = t.collider.state) || void 0 === o ? void 0 : o.object,
                        rigidBodyObject: null === (s = t.rigidBody.state) || void 0 === s ? void 0 : s.object
                    }
                },
                er = async () => {
                    let e = await Promise.resolve().then(r.bind(r, 4162));
                    return await e.init(), e
                },
                en = e => {
                    let {
                        colliders: t = "cuboid",
                        children: r,
                        timeStep: l = 1 / 60,
                        paused: c = !1,
                        interpolate: d = !0,
                        updatePriority: y,
                        updateLoop: C = "follow",
                        debug: B = !1,
                        gravity: _ = [0, -9.81, 0],
                        allowedLinearError: E = .001,
                        predictionDistance: w = .002,
                        numSolverIterations: M = 4,
                        numAdditionalFrictionIterations: x = 4,
                        numInternalPgsIterations: F = 1,
                        minIslandSize: S = 128,
                        maxCcdSubsteps: R = 1,
                        erp: O = .8
                    } = e, I = (0, s.Rq)(er, ["@react-thee/rapier", er]), {
                        invalidate: D
                    } = (0, i.A)(), P = b(() => new Map), L = b(() => new Map), H = b(() => new Map), U = b(() => new Map), G = b(() => new n.EventQueue(!1)), k = b(() => new Set), N = b(() => new Set), {
                        proxy: J,
                        reset: z,
                        set: j
                    } = b(() => $(() => new I.World(g(_))));
                    (0, a.useEffect)(() => () => {
                        J.free(), z()
                    }, []), (0, a.useEffect)(() => {
                        J.gravity = v(_), J.integrationParameters.numSolverIterations = M, J.integrationParameters.numAdditionalFrictionIterations = x, J.integrationParameters.numInternalPgsIterations = F, J.integrationParameters.allowedLinearError = E, J.integrationParameters.minIslandSize = S, J.integrationParameters.maxCcdSubsteps = R, J.integrationParameters.predictionDistance = w, J.integrationParameters.erp = O
                    }, [J, ..._, M, x, F, E, S, R, w, O]);
                    let K = (0, a.useCallback)(e => {
                            var t;
                            let r = J.getCollider(e),
                                n = U.get(e),
                                i = L.get(e),
                                a = null == r ? void 0 : null === (t = r.parent()) || void 0 === t ? void 0 : t.handle,
                                o = void 0 !== a ? J.getRigidBody(a) : void 0,
                                s = o && void 0 !== a ? H.get(a) : void 0;
                            return {
                                collider: {
                                    object: r,
                                    events: n,
                                    state: i
                                },
                                rigidBody: {
                                    object: o,
                                    events: s,
                                    state: void 0 !== a ? P.get(a) : void 0
                                }
                            }
                        }, []),
                        [Q] = (0, a.useState)({
                            previousState: {},
                            accumulator: 0
                        }),
                        V = (0, a.useCallback)(e => {
                            let t = "vary" === l,
                                r = o.MathUtils.clamp(e, 0, .5),
                                n = e => {
                                    k.forEach(e => {
                                        e.current(J)
                                    }), J.timestep = e, J.step(G), N.forEach(e => {
                                        e.current(J)
                                    })
                                };
                            if (t) n(r);
                            else
                                for (Q.accumulator += r; Q.accumulator >= l;) d && (Q.previousState = {}, J.forEachRigidBody(e => {
                                    Q.previousState[e.handle] = {
                                        position: e.translation(),
                                        rotation: e.rotation()
                                    }
                                })), n(l), Q.accumulator -= l;
                            let i = t || !d || c ? 1 : Q.accumulator / l;
                            P.forEach((e, t) => {
                                let r = J.getRigidBody(t),
                                    n = H.get(t);
                                if (null != n && n.onSleep || null != n && n.onWake) {
                                    var a, o;
                                    r.isSleeping() && !e.isSleeping && (null == n || null === (a = n.onSleep) || void 0 === a || a.call(n)), !r.isSleeping() && e.isSleeping && (null == n || null === (o = n.onWake) || void 0 === o || o.call(n)), e.isSleeping = r.isSleeping()
                                }
                                if (!r || r.isSleeping() && !("isInstancedMesh" in e.object) || !e.setMatrix) return;
                                let s = r.translation(),
                                    l = r.rotation(),
                                    u = Q.previousState[t];
                                u && (f.compose(u.position, A(u.rotation), e.scale).premultiply(e.invertedWorldMatrix).decompose(h, p, m), "mesh" == e.meshType && (e.object.position.copy(h), e.object.quaternion.copy(p))), f.compose(s, A(l), e.scale).premultiply(e.invertedWorldMatrix).decompose(h, p, m), "instancedMesh" == e.meshType ? e.setMatrix(f) : (e.object.position.lerp(h, i), e.object.quaternion.slerp(p, i))
                            }), G.drainCollisionEvents((e, t, r) => {
                                var n, i, a, o, s, l, c, d, f, h, p, m, g, A, v, y, C, B, _, b, E, w, M, T;
                                let x = K(e),
                                    F = K(t);
                                if (!(null != x && x.collider.object) || !(null != F && F.collider.object)) return;
                                let S = et(x, F),
                                    R = et(F, x);
                                r ? J.contactPair(x.collider.object, F.collider.object, (e, t) => {
                                    var r, n, i, a, o, s, l, c;
                                    null === (r = x.rigidBody.events) || void 0 === r || null === (n = r.onCollisionEnter) || void 0 === n || n.call(r, u(u({}, S), {}, {
                                        manifold: e,
                                        flipped: t
                                    })), null === (i = F.rigidBody.events) || void 0 === i || null === (a = i.onCollisionEnter) || void 0 === a || a.call(i, u(u({}, R), {}, {
                                        manifold: e,
                                        flipped: t
                                    })), null === (o = x.collider.events) || void 0 === o || null === (s = o.onCollisionEnter) || void 0 === s || s.call(o, u(u({}, S), {}, {
                                        manifold: e,
                                        flipped: t
                                    })), null === (l = F.collider.events) || void 0 === l || null === (c = l.onCollisionEnter) || void 0 === c || c.call(l, u(u({}, R), {}, {
                                        manifold: e,
                                        flipped: t
                                    }))
                                }) : (null === (n = x.rigidBody.events) || void 0 === n || null === (i = n.onCollisionExit) || void 0 === i || i.call(n, S), null === (a = F.rigidBody.events) || void 0 === a || null === (o = a.onCollisionExit) || void 0 === o || o.call(a, R), null === (s = x.collider.events) || void 0 === s || null === (l = s.onCollisionExit) || void 0 === l || l.call(s, S), null === (c = F.collider.events) || void 0 === c || null === (d = c.onCollisionExit) || void 0 === d || d.call(c, R)), r ? J.intersectionPair(x.collider.object, F.collider.object) && (null === (f = x.rigidBody.events) || void 0 === f || null === (h = f.onIntersectionEnter) || void 0 === h || h.call(f, S), null === (p = F.rigidBody.events) || void 0 === p || null === (m = p.onIntersectionEnter) || void 0 === m || m.call(p, R), null === (g = x.collider.events) || void 0 === g || null === (A = g.onIntersectionEnter) || void 0 === A || A.call(g, S), null === (v = F.collider.events) || void 0 === v || null === (y = v.onIntersectionEnter) || void 0 === y || y.call(v, R)) : (null === (C = x.rigidBody.events) || void 0 === C || null === (B = C.onIntersectionExit) || void 0 === B || B.call(C, S), null === (_ = F.rigidBody.events) || void 0 === _ || null === (b = _.onIntersectionExit) || void 0 === b || b.call(_, R), null === (E = x.collider.events) || void 0 === E || null === (w = E.onIntersectionExit) || void 0 === w || w.call(E, S), null === (M = F.collider.events) || void 0 === M || null === (T = M.onIntersectionExit) || void 0 === T || T.call(M, R))
                            }), G.drainContactForceEvents(e => {
                                var t, r, n, i, a, o, s, l;
                                let c = K(e.collider1()),
                                    d = K(e.collider2());
                                if (!(null != c && c.collider.object) || !(null != d && d.collider.object)) return;
                                let f = et(c, d),
                                    h = et(d, c);
                                null === (t = c.rigidBody.events) || void 0 === t || null === (r = t.onContactForce) || void 0 === r || r.call(t, u(u({}, f), {}, {
                                    totalForce: e.totalForce(),
                                    totalForceMagnitude: e.totalForceMagnitude(),
                                    maxForceDirection: e.maxForceDirection(),
                                    maxForceMagnitude: e.maxForceMagnitude()
                                })), null === (n = d.rigidBody.events) || void 0 === n || null === (i = n.onContactForce) || void 0 === i || i.call(n, u(u({}, h), {}, {
                                    totalForce: e.totalForce(),
                                    totalForceMagnitude: e.totalForceMagnitude(),
                                    maxForceDirection: e.maxForceDirection(),
                                    maxForceMagnitude: e.maxForceMagnitude()
                                })), null === (a = c.collider.events) || void 0 === a || null === (o = a.onContactForce) || void 0 === o || o.call(a, u(u({}, f), {}, {
                                    totalForce: e.totalForce(),
                                    totalForceMagnitude: e.totalForceMagnitude(),
                                    maxForceDirection: e.maxForceDirection(),
                                    maxForceMagnitude: e.maxForceMagnitude()
                                })), null === (s = d.collider.events) || void 0 === s || null === (l = s.onContactForce) || void 0 === l || l.call(s, u(u({}, h), {}, {
                                    totalForce: e.totalForce(),
                                    totalForceMagnitude: e.totalForceMagnitude(),
                                    maxForceDirection: e.maxForceDirection(),
                                    maxForceMagnitude: e.maxForceMagnitude()
                                }))
                            }), J.forEachActiveRigidBody(() => {
                                D()
                            })
                        }, [c, l, d, J]),
                        Y = (0, a.useMemo)(() => ({
                            rapier: I,
                            world: J,
                            setWorld: e => {
                                j(e)
                            },
                            physicsOptions: {
                                colliders: t,
                                gravity: _
                            },
                            rigidBodyStates: P,
                            colliderStates: L,
                            rigidBodyEvents: H,
                            colliderEvents: U,
                            beforeStepCallbacks: k,
                            afterStepCallbacks: N,
                            isPaused: c,
                            isDebug: B,
                            step: V
                        }), [c, V, B, t, _]),
                        X = (0, a.useCallback)(e => {
                            c || V(e)
                        }, [c, V]);
                    return a.createElement(ee.Provider, {
                        value: Y
                    }, a.createElement(T, {
                        onStep: X,
                        type: C,
                        updatePriority: y
                    }), B && a.createElement(q, null), r)
                };

            function ei() {
                return (ei = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            let ea = (e, t, r) => {
                    let n = (0, a.useRef)(),
                        i = (0, a.useCallback)(() => (n.current || (n.current = e()), n.current), r);
                    return (0, a.useEffect)(() => {
                        let e = i(),
                            r = () => t(e);
                        return () => {
                            r(), n.current = void 0
                        }
                    }, [i]), i
                },
                eo = ({
                    x: e,
                    y: t,
                    z: r
                } = {
                    x: 0,
                    y: 0,
                    z: 0
                }) => new o.Vector3(e, t, r),
                es = (e, t = null) => {
                    let r = (0, a.useRef)(t);
                    return e && "function" != typeof e ? (e.current || (e.current = r.current), e) : r
                },
                el = (0, a.memo)((0, a.forwardRef)((e, t) => {
                    let {
                        children: r,
                        position: n,
                        rotation: i,
                        quaternion: o,
                        scale: s,
                        name: l
                    } = e, {
                        world: c,
                        colliderEvents: d,
                        colliderStates: f
                    } = Y(), h = eB(), p = es(t), m = (0, a.useRef)(null), g = ea(() => {
                        let r = R(e, c, m.current.getWorldScale(eo()), null == h ? void 0 : h.getRigidBody);
                        return "function" == typeof t && t(r), p.current = r, r
                    }, e => {
                        c.getCollider(e.handle) && c.removeCollider(e, !0)
                    }, [...O.flatMap(t => Array.isArray(e[t]) ? [...e[t]] : e[t]), h]);
                    (0, a.useEffect)(() => {
                        let e = g();
                        return f.set(e.handle, k(e, m.current, null == h ? void 0 : h.ref.current)), () => {
                            f.delete(e.handle)
                        }
                    }, [g]);
                    let A = (0, a.useMemo)(() => u(u({}, Q(null == h ? void 0 : h.options)), e), [e, null == h ? void 0 : h.options]);
                    return U(g, A, f), K(g, A, d, j(null == h ? void 0 : h.options)), a.createElement("object3D", {
                        position: n,
                        rotation: i,
                        quaternion: o,
                        scale: s,
                        ref: m,
                        name: l
                    }, r)
                })),
                eu = a.forwardRef((e, t) => a.createElement(el, ei({}, e, {
                    shape: "cuboid",
                    ref: t
                })));
            eu.displayName = "CuboidCollider", a.forwardRef((e, t) => a.createElement(el, ei({}, e, {
                shape: "roundCuboid",
                ref: t
            }))).displayName = "RoundCuboidCollider", a.forwardRef((e, t) => a.createElement(el, ei({}, e, {
                shape: "ball",
                ref: t
            }))).displayName = "BallCollider", a.forwardRef((e, t) => a.createElement(el, ei({}, e, {
                shape: "capsule",
                ref: t
            }))).displayName = "CapsuleCollider", a.forwardRef((e, t) => a.createElement(el, ei({}, e, {
                shape: "heightfield",
                ref: t
            }))).displayName = "HeightfieldCollider", a.forwardRef((e, t) => a.createElement(el, ei({}, e, {
                shape: "trimesh",
                ref: t
            }))).displayName = "TrimeshCollider", a.forwardRef((e, t) => a.createElement(el, ei({}, e, {
                shape: "cone",
                ref: t
            }))).displayName = "ConeCollider", a.forwardRef((e, t) => a.createElement(el, ei({}, e, {
                shape: "roundCone",
                ref: t
            }))).displayName = "RoundConeCollider";
            let ec = a.forwardRef((e, t) => a.createElement(el, ei({}, e, {
                shape: "cylinder",
                ref: t
            })));
            ec.displayName = "CylinderCollider", ec.displayName = "RoundCylinderCollider", a.forwardRef((e, t) => a.createElement(el, ei({}, e, {
                shape: "convexHull",
                ref: t
            }))).displayName = "ConvexHullCollider";
            let ed = e => {
                    var t;
                    let r = C((null == e ? void 0 : e.type) || "dynamic"),
                        i = new n.RigidBodyDesc(r);
                    return i.canSleep = null === (t = null == e ? void 0 : e.canSleep) || void 0 === t || t, i
                },
                ef = ({
                    rigidBody: e,
                    object: t,
                    setMatrix: r,
                    getMatrix: n,
                    worldScale: i,
                    meshType: a = "mesh"
                }) => {
                    t.updateWorldMatrix(!0, !1);
                    let o = t.parent.matrixWorld.clone().invert();
                    return {
                        object: t,
                        rigidBody: e,
                        invertedWorldMatrix: o,
                        setMatrix: r || (e => {
                            t.matrix.copy(e)
                        }),
                        getMatrix: n || (e => e.copy(t.matrix)),
                        scale: i || t.getWorldScale(m).clone(),
                        isSleeping: !1,
                        meshType: a
                    }
                },
                eh = ["args", "colliders", "canSleep"],
                ep = {
                    gravityScale: (e, t) => {
                        e.setGravityScale(t, !0)
                    },
                    additionalSolverIterations(e, t) {
                        e.setAdditionalSolverIterations(t)
                    },
                    linearDamping: (e, t) => {
                        e.setLinearDamping(t)
                    },
                    angularDamping: (e, t) => {
                        e.setAngularDamping(t)
                    },
                    dominanceGroup: (e, t) => {
                        e.setDominanceGroup(t)
                    },
                    enabledRotations: (e, [t, r, n]) => {
                        e.setEnabledRotations(t, r, n, !0)
                    },
                    enabledTranslations: (e, [t, r, n]) => {
                        e.setEnabledTranslations(t, r, n, !0)
                    },
                    lockRotations: (e, t) => {
                        e.lockRotations(t, !0)
                    },
                    lockTranslations: (e, t) => {
                        e.lockTranslations(t, !0)
                    },
                    angularVelocity: (e, [t, r, n]) => {
                        e.setAngvel({
                            x: t,
                            y: r,
                            z: n
                        }, !0)
                    },
                    linearVelocity: (e, [t, r, n]) => {
                        e.setLinvel({
                            x: t,
                            y: r,
                            z: n
                        }, !0)
                    },
                    ccd: (e, t) => {
                        e.enableCcd(t)
                    },
                    userData: (e, t) => {
                        e.userData = t
                    },
                    type(e, t) {
                        e.setBodyType(C(t), !0)
                    },
                    position: () => {},
                    rotation: () => {},
                    quaternion: () => {},
                    scale: () => {}
                },
                em = Object.keys(ep),
                eg = (e, t, r, n = !0) => {
                    if (!e) return;
                    let i = r.get(e.handle);
                    i && (n && (i.object.updateWorldMatrix(!0, !1), f.copy(i.object.matrixWorld).decompose(h, p, m), e.setTranslation(h, !1), e.setRotation(p, !1)), em.forEach(r => {
                        r in t && ep[r](e, t[r])
                    }))
                },
                eA = (e, t, r, n = !0) => {
                    let i = (0, a.useMemo)(() => em.flatMap(e => _(t[e])), [t]);
                    (0, a.useEffect)(() => {
                        eg(e(), t, r, n)
                    }, i)
                },
                ev = (e, t, r) => {
                    let {
                        onWake: n,
                        onSleep: i,
                        onCollisionEnter: o,
                        onCollisionExit: s,
                        onIntersectionEnter: l,
                        onIntersectionExit: u,
                        onContactForce: c
                    } = t, d = {
                        onWake: n,
                        onSleep: i,
                        onCollisionEnter: o,
                        onCollisionExit: s,
                        onIntersectionEnter: l,
                        onIntersectionExit: u,
                        onContactForce: c
                    };
                    (0, a.useEffect)(() => {
                        let t = e();
                        return r.set(t.handle, d), () => {
                            r.delete(t.handle)
                        }
                    }, [n, i, o, s, l, u, c])
                },
                ey = ["children", "type", "position", "rotation", "scale", "quaternion", "transformState"],
                eC = (0, a.createContext)(void 0),
                eB = () => (0, a.useContext)(eC),
                e_ = (0, a.memo)((0, a.forwardRef)((e, t) => {
                    let {
                        children: r,
                        type: n,
                        position: i,
                        rotation: o,
                        scale: s,
                        quaternion: l,
                        transformState: c
                    } = e, d = x(e, ey), f = (0, a.useRef)(null), h = es(t), {
                        world: p,
                        rigidBodyStates: m,
                        physicsOptions: g,
                        rigidBodyEvents: A
                    } = Y(), v = (0, a.useMemo)(() => u(u(u({}, g), e), {}, {
                        children: void 0
                    }), [g, e]), y = eh.flatMap(e => Array.isArray(v[e]) ? [...v[e]] : v[e]), C = Z(f, v), B = ea(() => {
                        let e = ed(v),
                            r = p.createRigidBody(e);
                        return "function" == typeof t && t(r), h.current = r, r
                    }, e => {
                        p.getRigidBody(e.handle) && p.removeRigidBody(e)
                    }, y);
                    (0, a.useEffect)(() => {
                        let t = B(),
                            r = ef({
                                rigidBody: t,
                                object: f.current
                            });
                        return m.set(t.handle, e.transformState ? e.transformState(r) : r), () => {
                            m.delete(t.handle)
                        }
                    }, [B]), eA(B, v, m), ev(B, v, A);
                    let _ = (0, a.useMemo)(() => ({
                        ref: f,
                        getRigidBody: B,
                        options: v
                    }), [B]);
                    return a.createElement(eC.Provider, {
                        value: _
                    }, a.createElement("object3D", ei({
                        ref: f
                    }, d, {
                        position: i,
                        rotation: o,
                        quaternion: l,
                        scale: s
                    }), r, C.map((e, t) => a.createElement(el, ei({
                        key: t
                    }, e)))))
                }));
            e_.displayName = "RigidBody", (0, a.memo)(e => {
                let {
                    children: t,
                    type: r
                } = e, {
                    physicsOptions: n
                } = Y(), i = (0, a.useRef)(null), {
                    options: o
                } = eB(), s = Z(i, (0, a.useMemo)(() => u(u(u({}, n), o), {}, {
                    children: void 0,
                    colliders: r
                }), [n, o]), !1);
                return a.createElement("object3D", {
                    ref: i,
                    userData: {
                        r3RapierType: "MeshCollider"
                    }
                }, t, s.map((e, t) => a.createElement(el, ei({
                    key: t
                }, e))))
            }).displayName = "MeshCollider";
            let eb = ["children", "instances", "colliderNodes", "position", "rotation", "quaternion", "scale"];
            (0, a.memo)((0, a.forwardRef)((e, t) => {
                let r = es(t, []),
                    n = (0, a.useRef)(null),
                    i = (0, a.useRef)(null),
                    {
                        children: s,
                        instances: l,
                        colliderNodes: c = [],
                        position: d,
                        rotation: f,
                        quaternion: h,
                        scale: p
                    } = e,
                    m = x(e, eb),
                    g = Z(n, u(u({}, e), {}, {
                        children: void 0
                    })),
                    A = () => {
                        let e = i.current.children[0];
                        if (e && "isInstancedMesh" in e) return e
                    };
                (0, a.useEffect)(() => {
                    let e = A();
                    e ? e.instanceMatrix.setUsage(o.DynamicDrawUsage) : console.warn("InstancedRigidBodies expects exactly one child, which must be an InstancedMesh")
                }, []);
                let v = (e, t) => {
                    let r = A();
                    return r ? u(u({}, e), {}, {
                        getMatrix: e => (r.getMatrixAt(t, e), e),
                        setMatrix: e => {
                            r.setMatrixAt(t, e), r.instanceMatrix.needsUpdate = !0
                        },
                        meshType: "instancedMesh"
                    }) : e
                };
                return a.createElement("object3D", ei({
                    ref: n
                }, m, {
                    position: d,
                    rotation: f,
                    quaternion: h,
                    scale: p
                }), a.createElement("object3D", {
                    ref: i
                }, s), null == l ? void 0 : l.map((e, t) => a.createElement(e_, ei({}, m, e, {
                    ref: e => r.current[t] = e,
                    transformState: e => v(e, t)
                }), a.createElement(a.Fragment, null, c.map((e, t) => a.createElement(a.Fragment, {
                    key: t
                }, e)), g.map((e, t) => a.createElement(el, ei({
                    key: t
                }, e)))))))
            })).displayName = "InstancedRigidBodies";
            let eE = (e, t, r) => {
                    let {
                        world: n
                    } = Y(), i = (0, a.useRef)();
                    return ea(() => {
                        if (e.current && t.current) {
                            let a = n.createImpulseJoint(r, e.current, t.current, !0);
                            return i.current = a, a
                        }
                    }, e => {
                        e && (i.current = void 0, n.getImpulseJoint(e.handle) && n.removeImpulseJoint(e, !0))
                    }, []), i
                },
                ew = (e, t, [r, n, i, a, o]) => {
                    let {
                        rapier: s
                    } = Y(), l = v(r), u = v(n);
                    return eE(e, t, s.JointData.spring(i, a, o, l, u))
                }
        },
        10105: function(e, t, r) {
            "use strict";
            var n;
            let i, a, o, s, l, u, c, d, f, h, p, m, g, A, v, y, C, B, _, b, E, w, M;
            r.d(t, {
                Z: function() {
                    return Y
                }
            });
            let T = {
                    LEFT: 1,
                    RIGHT: 2,
                    MIDDLE: 4
                },
                x = Object.freeze({
                    NONE: 0,
                    ROTATE: 1,
                    TRUCK: 2,
                    OFFSET: 4,
                    DOLLY: 8,
                    ZOOM: 16,
                    TOUCH_ROTATE: 32,
                    TOUCH_TRUCK: 64,
                    TOUCH_OFFSET: 128,
                    TOUCH_DOLLY: 256,
                    TOUCH_ZOOM: 512,
                    TOUCH_DOLLY_TRUCK: 1024,
                    TOUCH_DOLLY_OFFSET: 2048,
                    TOUCH_DOLLY_ROTATE: 4096,
                    TOUCH_ZOOM_TRUCK: 8192,
                    TOUCH_ZOOM_OFFSET: 16384,
                    TOUCH_ZOOM_ROTATE: 32768
                }),
                F = {
                    NONE: 0,
                    IN: 1,
                    OUT: -1
                };

            function S(e) {
                return e.isPerspectiveCamera
            }

            function R(e) {
                return e.isOrthographicCamera
            }
            let O = 2 * Math.PI,
                I = Math.PI / 2,
                D = Math.PI / 180;

            function P(e, t, r) {
                return Math.max(t, Math.min(r, e))
            }

            function L(e, t = 1e-5) {
                return Math.abs(e) < t
            }

            function H(e, t, r = 1e-5) {
                return L(e - t, r)
            }

            function U(e, t) {
                return Math.round(e / t) * t
            }

            function G(e) {
                return isFinite(e) ? e : e < 0 ? -Number.MAX_VALUE : Number.MAX_VALUE
            }

            function k(e) {
                return Math.abs(e) < Number.MAX_VALUE ? e : 1 / 0 * e
            }

            function N(e, t, r, n, i = 1 / 0, a) {
                let o = 2 / (n = Math.max(1e-4, n)),
                    s = o * a,
                    l = 1 / (1 + s + .48 * s * s + .235 * s * s * s),
                    u = e - t,
                    c = t,
                    d = i * n;
                t = e - (u = P(u, -d, d));
                let f = (r.value + o * u) * a;
                r.value = (r.value - o * f) * l;
                let h = t + (u + f) * l;
                return c - e > 0 == h > c && (h = c, r.value = (h - c) / a), h
            }

            function J(e, t, r, n, i = 1 / 0, a, o) {
                let s = 2 / (n = Math.max(1e-4, n)),
                    l = s * a,
                    u = 1 / (1 + l + .48 * l * l + .235 * l * l * l),
                    c = t.x,
                    d = t.y,
                    f = t.z,
                    h = e.x - c,
                    p = e.y - d,
                    m = e.z - f,
                    g = c,
                    A = d,
                    v = f,
                    y = i * n,
                    C = h * h + p * p + m * m;
                if (C > y * y) {
                    let e = Math.sqrt(C);
                    h = h / e * y, p = p / e * y, m = m / e * y
                }
                c = e.x - h, d = e.y - p, f = e.z - m;
                let B = (r.x + s * h) * a,
                    _ = (r.y + s * p) * a,
                    b = (r.z + s * m) * a;
                r.x = (r.x - s * B) * u, r.y = (r.y - s * _) * u, r.z = (r.z - s * b) * u, o.x = c + (h + B) * u, o.y = d + (p + _) * u, o.z = f + (m + b) * u;
                let E = g - e.x,
                    w = A - e.y,
                    M = v - e.z;
                return E * (o.x - g) + w * (o.y - A) + M * (o.z - v) > 0 && (o.x = g, o.y = A, o.z = v, r.x = (o.x - g) / a, r.y = (o.y - A) / a, r.z = (o.z - v) / a), o
            }

            function z(e, t) {
                t.set(0, 0), e.forEach(e => {
                    t.x += e.clientX, t.y += e.clientY
                }), t.x /= e.length, t.y /= e.length
            }

            function j(e, t) {
                return !!R(e) && (console.warn(`${t} is not supported in OrthographicCamera`), !0)
            }
            class K {
                constructor() {
                    this._listeners = {}
                }
                addEventListener(e, t) {
                    let r = this._listeners;
                    void 0 === r[e] && (r[e] = []), -1 === r[e].indexOf(t) && r[e].push(t)
                }
                hasEventListener(e, t) {
                    let r = this._listeners;
                    return void 0 !== r[e] && -1 !== r[e].indexOf(t)
                }
                removeEventListener(e, t) {
                    let r = this._listeners[e];
                    if (void 0 !== r) {
                        let e = r.indexOf(t); - 1 !== e && r.splice(e, 1)
                    }
                }
                removeAllEventListeners(e) {
                    if (!e) {
                        this._listeners = {};
                        return
                    }
                    Array.isArray(this._listeners[e]) && (this._listeners[e].length = 0)
                }
                dispatchEvent(e) {
                    let t = this._listeners[e.type];
                    if (void 0 !== t) {
                        e.target = this;
                        let r = t.slice(0);
                        for (let t = 0, n = r.length; t < n; t++) r[t].call(this, e)
                    }
                }
            }
            let Q = 1 / 8,
                V = /Mac/.test(null === (n = null == globalThis ? void 0 : globalThis.navigator) || void 0 === n ? void 0 : n.platform);
            class Y extends K {
                static install(e) {
                    a = Object.freeze(new(i = e.THREE).Vector3(0, 0, 0)), o = Object.freeze(new i.Vector3(0, 1, 0)), s = Object.freeze(new i.Vector3(0, 0, 1)), l = new i.Vector2, u = new i.Vector3, c = new i.Vector3, d = new i.Vector3, f = new i.Vector3, h = new i.Vector3, p = new i.Vector3, m = new i.Vector3, g = new i.Vector3, A = new i.Vector3, v = new i.Spherical, y = new i.Spherical, C = new i.Box3, B = new i.Box3, _ = new i.Sphere, b = new i.Quaternion, E = new i.Quaternion, w = new i.Matrix4, M = new i.Raycaster
                }
                static get ACTION() {
                    return x
                }
                constructor(e, t) {
                    super(), this.minPolarAngle = 0, this.maxPolarAngle = Math.PI, this.minAzimuthAngle = -1 / 0, this.maxAzimuthAngle = 1 / 0, this.minDistance = Number.EPSILON, this.maxDistance = 1 / 0, this.infinityDolly = !1, this.minZoom = .01, this.maxZoom = 1 / 0, this.smoothTime = .25, this.draggingSmoothTime = .125, this.maxSpeed = 1 / 0, this.azimuthRotateSpeed = 1, this.polarRotateSpeed = 1, this.dollySpeed = 1, this.dollyDragInverted = !1, this.truckSpeed = 2, this.dollyToCursor = !1, this.dragToOffset = !1, this.verticalDragToForward = !1, this.boundaryFriction = 0, this.restThreshold = .01, this.colliderMeshes = [], this.cancel = () => {}, this._enabled = !0, this._state = x.NONE, this._viewport = null, this._changedDolly = 0, this._changedZoom = 0, this._hasRested = !0, this._boundaryEnclosesCamera = !1, this._needsUpdate = !0, this._updatedLastTime = !1, this._elementRect = new DOMRect, this._isDragging = !1, this._dragNeedsUpdate = !0, this._activePointers = [], this._lockedPointer = null, this._interactiveArea = new DOMRect(0, 0, 1, 1), this._isUserControllingRotate = !1, this._isUserControllingDolly = !1, this._isUserControllingTruck = !1, this._isUserControllingOffset = !1, this._isUserControllingZoom = !1, this._lastDollyDirection = F.NONE, this._thetaVelocity = {
                        value: 0
                    }, this._phiVelocity = {
                        value: 0
                    }, this._radiusVelocity = {
                        value: 0
                    }, this._targetVelocity = new i.Vector3, this._focalOffsetVelocity = new i.Vector3, this._zoomVelocity = {
                        value: 0
                    }, this._truckInternal = (e, t, r) => {
                        let n, i;
                        if (S(this._camera)) {
                            let r = u.copy(this._camera.position).sub(this._target),
                                a = this._camera.getEffectiveFOV() * D,
                                o = r.length() * Math.tan(.5 * a);
                            n = this.truckSpeed * e * o / this._elementRect.height, i = this.truckSpeed * t * o / this._elementRect.height
                        } else {
                            if (!R(this._camera)) return;
                            let r = this._camera;
                            n = e * (r.right - r.left) / r.zoom / this._elementRect.width, i = t * (r.top - r.bottom) / r.zoom / this._elementRect.height
                        }
                        this.verticalDragToForward ? (r ? this.setFocalOffset(this._focalOffsetEnd.x + n, this._focalOffsetEnd.y, this._focalOffsetEnd.z, !0) : this.truck(n, 0, !0), this.forward(-i, !0)) : r ? this.setFocalOffset(this._focalOffsetEnd.x + n, this._focalOffsetEnd.y + i, this._focalOffsetEnd.z, !0) : this.truck(n, i, !0)
                    }, this._rotateInternal = (e, t) => {
                        let r = O * this.azimuthRotateSpeed * e / this._elementRect.height,
                            n = O * this.polarRotateSpeed * t / this._elementRect.height;
                        this.rotate(r, n, !0)
                    }, this._dollyInternal = (e, t, r) => {
                        let n = Math.pow(.95, -e * this.dollySpeed),
                            i = this._sphericalEnd.radius,
                            a = this._sphericalEnd.radius * n,
                            o = P(a, this.minDistance, this.maxDistance);
                        this.infinityDolly && this.dollyToCursor ? this._dollyToNoClamp(a, !0) : (this.infinityDolly && !this.dollyToCursor && this.dollyInFixed(o - a, !0), this._dollyToNoClamp(o, !0)), this.dollyToCursor && (this._changedDolly += (this.infinityDolly ? a : o) - i, this._dollyControlCoord.set(t, r)), this._lastDollyDirection = Math.sign(-e)
                    }, this._zoomInternal = (e, t, r) => {
                        let n = Math.pow(.95, e * this.dollySpeed),
                            i = this._zoom,
                            a = this._zoom * n;
                        this.zoomTo(a, !0), this.dollyToCursor && (this._changedZoom += a - i, this._dollyControlCoord.set(t, r))
                    }, void 0 === i && console.error("camera-controls: `THREE` is undefined. You must first run `CameraControls.install( { THREE: THREE } )`. Check the docs for further information."), this._camera = e, this._yAxisUpSpace = new i.Quaternion().setFromUnitVectors(this._camera.up, o), this._yAxisUpSpaceInverse = this._yAxisUpSpace.clone().invert(), this._state = x.NONE, this._target = new i.Vector3, this._targetEnd = this._target.clone(), this._focalOffset = new i.Vector3, this._focalOffsetEnd = this._focalOffset.clone(), this._spherical = new i.Spherical().setFromVector3(u.copy(this._camera.position).applyQuaternion(this._yAxisUpSpace)), this._sphericalEnd = this._spherical.clone(), this._lastDistance = this._spherical.radius, this._zoom = this._camera.zoom, this._zoomEnd = this._zoom, this._lastZoom = this._zoom, this._nearPlaneCorners = [new i.Vector3, new i.Vector3, new i.Vector3, new i.Vector3], this._updateNearPlaneCorners(), this._boundary = new i.Box3(new i.Vector3(-1 / 0, -1 / 0, -1 / 0), new i.Vector3(1 / 0, 1 / 0, 1 / 0)), this._cameraUp0 = this._camera.up.clone(), this._target0 = this._target.clone(), this._position0 = this._camera.position.clone(), this._zoom0 = this._zoom, this._focalOffset0 = this._focalOffset.clone(), this._dollyControlCoord = new i.Vector2, this.mouseButtons = {
                        left: x.ROTATE,
                        middle: x.DOLLY,
                        right: x.TRUCK,
                        wheel: S(this._camera) ? x.DOLLY : R(this._camera) ? x.ZOOM : x.NONE
                    }, this.touches = {
                        one: x.TOUCH_ROTATE,
                        two: S(this._camera) ? x.TOUCH_DOLLY_TRUCK : R(this._camera) ? x.TOUCH_ZOOM_TRUCK : x.NONE,
                        three: x.TOUCH_TRUCK
                    };
                    let r = new i.Vector2,
                        n = new i.Vector2,
                        a = new i.Vector2,
                        s = e => {
                            if (!this._enabled || !this._domElement) return;
                            if (0 !== this._interactiveArea.left || 0 !== this._interactiveArea.top || 1 !== this._interactiveArea.width || 1 !== this._interactiveArea.height) {
                                let t = this._domElement.getBoundingClientRect(),
                                    r = e.clientX / t.width,
                                    n = e.clientY / t.height;
                                if (r < this._interactiveArea.left || r > this._interactiveArea.right || n < this._interactiveArea.top || n > this._interactiveArea.bottom) return
                            }
                            let t = "mouse" !== e.pointerType ? null : (e.buttons & T.LEFT) === T.LEFT ? T.LEFT : (e.buttons & T.MIDDLE) === T.MIDDLE ? T.MIDDLE : (e.buttons & T.RIGHT) === T.RIGHT ? T.RIGHT : null;
                            if (null !== t) {
                                let e = this._findPointerByMouseButton(t);
                                e && this._disposePointer(e)
                            }
                            if ((e.buttons & T.LEFT) === T.LEFT && this._lockedPointer) return;
                            let r = {
                                pointerId: e.pointerId,
                                clientX: e.clientX,
                                clientY: e.clientY,
                                deltaX: 0,
                                deltaY: 0,
                                mouseButton: t
                            };
                            this._activePointers.push(r), this._domElement.ownerDocument.removeEventListener("pointermove", c, {
                                passive: !1
                            }), this._domElement.ownerDocument.removeEventListener("pointerup", d), this._domElement.ownerDocument.addEventListener("pointermove", c, {
                                passive: !1
                            }), this._domElement.ownerDocument.addEventListener("pointerup", d), this._isDragging = !0, m(e)
                        },
                        c = e => {
                            e.cancelable && e.preventDefault();
                            let t = e.pointerId,
                                r = this._lockedPointer || this._findPointerById(t);
                            if (r) {
                                if (r.clientX = e.clientX, r.clientY = e.clientY, r.deltaX = e.movementX, r.deltaY = e.movementY, this._state = 0, "touch" === e.pointerType) switch (this._activePointers.length) {
                                    case 1:
                                        this._state = this.touches.one;
                                        break;
                                    case 2:
                                        this._state = this.touches.two;
                                        break;
                                    case 3:
                                        this._state = this.touches.three
                                } else(!this._isDragging && this._lockedPointer || this._isDragging && (e.buttons & T.LEFT) === T.LEFT) && (this._state = this._state | this.mouseButtons.left), this._isDragging && (e.buttons & T.MIDDLE) === T.MIDDLE && (this._state = this._state | this.mouseButtons.middle), this._isDragging && (e.buttons & T.RIGHT) === T.RIGHT && (this._state = this._state | this.mouseButtons.right);
                                g()
                            }
                        },
                        d = e => {
                            let t = this._findPointerById(e.pointerId);
                            if (!t || t !== this._lockedPointer) {
                                if (t && this._disposePointer(t), "touch" === e.pointerType) switch (this._activePointers.length) {
                                    case 0:
                                        this._state = x.NONE;
                                        break;
                                    case 1:
                                        this._state = this.touches.one;
                                        break;
                                    case 2:
                                        this._state = this.touches.two;
                                        break;
                                    case 3:
                                        this._state = this.touches.three
                                } else this._state = x.NONE;
                                A()
                            }
                        },
                        f = -1,
                        h = e => {
                            if (!this._domElement || !this._enabled || this.mouseButtons.wheel === x.NONE) return;
                            if (0 !== this._interactiveArea.left || 0 !== this._interactiveArea.top || 1 !== this._interactiveArea.width || 1 !== this._interactiveArea.height) {
                                let t = this._domElement.getBoundingClientRect(),
                                    r = e.clientX / t.width,
                                    n = e.clientY / t.height;
                                if (r < this._interactiveArea.left || r > this._interactiveArea.right || n < this._interactiveArea.top || n > this._interactiveArea.bottom) return
                            }
                            if (e.preventDefault(), this.dollyToCursor || this.mouseButtons.wheel === x.ROTATE || this.mouseButtons.wheel === x.TRUCK) {
                                let e = performance.now();
                                f - e < 1e3 && this._getClientRect(this._elementRect), f = e
                            }
                            let t = V ? -1 : -3,
                                r = 1 === e.deltaMode ? e.deltaY / t : e.deltaY / (10 * t),
                                n = this.dollyToCursor ? (e.clientX - this._elementRect.x) / this._elementRect.width * 2 - 1 : 0,
                                i = this.dollyToCursor ? -((e.clientY - this._elementRect.y) / this._elementRect.height * 2) + 1 : 0;
                            switch (this.mouseButtons.wheel) {
                                case x.ROTATE:
                                    this._rotateInternal(e.deltaX, e.deltaY), this._isUserControllingRotate = !0;
                                    break;
                                case x.TRUCK:
                                    this._truckInternal(e.deltaX, e.deltaY, !1), this._isUserControllingTruck = !0;
                                    break;
                                case x.OFFSET:
                                    this._truckInternal(e.deltaX, e.deltaY, !0), this._isUserControllingOffset = !0;
                                    break;
                                case x.DOLLY:
                                    this._dollyInternal(-r, n, i), this._isUserControllingDolly = !0;
                                    break;
                                case x.ZOOM:
                                    this._zoomInternal(-r, n, i), this._isUserControllingZoom = !0
                            }
                            this.dispatchEvent({
                                type: "control"
                            })
                        },
                        p = e => {
                            if (this._domElement && this._enabled) {
                                if (this.mouseButtons.right === Y.ACTION.NONE) {
                                    let t = e instanceof PointerEvent ? e.pointerId : 0,
                                        r = this._findPointerById(t);
                                    r && this._disposePointer(r), this._domElement.ownerDocument.removeEventListener("pointermove", c, {
                                        passive: !1
                                    }), this._domElement.ownerDocument.removeEventListener("pointerup", d);
                                    return
                                }
                                e.preventDefault()
                            }
                        },
                        m = e => {
                            if (this._enabled) {
                                if (z(this._activePointers, l), this._getClientRect(this._elementRect), r.copy(l), n.copy(l), this._activePointers.length >= 2) {
                                    let e = l.x - this._activePointers[1].clientX,
                                        t = l.y - this._activePointers[1].clientY;
                                    a.set(0, Math.sqrt(e * e + t * t));
                                    let r = (this._activePointers[0].clientX + this._activePointers[1].clientX) * .5,
                                        i = (this._activePointers[0].clientY + this._activePointers[1].clientY) * .5;
                                    n.set(r, i)
                                }
                                if (this._state = 0, e) {
                                    if ("pointerType" in e && "touch" === e.pointerType) switch (this._activePointers.length) {
                                        case 1:
                                            this._state = this.touches.one;
                                            break;
                                        case 2:
                                            this._state = this.touches.two;
                                            break;
                                        case 3:
                                            this._state = this.touches.three
                                    } else this._lockedPointer || (e.buttons & T.LEFT) !== T.LEFT || (this._state = this._state | this.mouseButtons.left), (e.buttons & T.MIDDLE) === T.MIDDLE && (this._state = this._state | this.mouseButtons.middle), (e.buttons & T.RIGHT) === T.RIGHT && (this._state = this._state | this.mouseButtons.right)
                                } else this._lockedPointer && (this._state = this._state | this.mouseButtons.left);
                                ((this._state & x.ROTATE) === x.ROTATE || (this._state & x.TOUCH_ROTATE) === x.TOUCH_ROTATE || (this._state & x.TOUCH_DOLLY_ROTATE) === x.TOUCH_DOLLY_ROTATE || (this._state & x.TOUCH_ZOOM_ROTATE) === x.TOUCH_ZOOM_ROTATE) && (this._sphericalEnd.theta = this._spherical.theta, this._sphericalEnd.phi = this._spherical.phi, this._thetaVelocity.value = 0, this._phiVelocity.value = 0), ((this._state & x.TRUCK) === x.TRUCK || (this._state & x.TOUCH_TRUCK) === x.TOUCH_TRUCK || (this._state & x.TOUCH_DOLLY_TRUCK) === x.TOUCH_DOLLY_TRUCK || (this._state & x.TOUCH_ZOOM_TRUCK) === x.TOUCH_ZOOM_TRUCK) && (this._targetEnd.copy(this._target), this._targetVelocity.set(0, 0, 0)), ((this._state & x.DOLLY) === x.DOLLY || (this._state & x.TOUCH_DOLLY) === x.TOUCH_DOLLY || (this._state & x.TOUCH_DOLLY_TRUCK) === x.TOUCH_DOLLY_TRUCK || (this._state & x.TOUCH_DOLLY_OFFSET) === x.TOUCH_DOLLY_OFFSET || (this._state & x.TOUCH_DOLLY_ROTATE) === x.TOUCH_DOLLY_ROTATE) && (this._sphericalEnd.radius = this._spherical.radius, this._radiusVelocity.value = 0), ((this._state & x.ZOOM) === x.ZOOM || (this._state & x.TOUCH_ZOOM) === x.TOUCH_ZOOM || (this._state & x.TOUCH_ZOOM_TRUCK) === x.TOUCH_ZOOM_TRUCK || (this._state & x.TOUCH_ZOOM_OFFSET) === x.TOUCH_ZOOM_OFFSET || (this._state & x.TOUCH_ZOOM_ROTATE) === x.TOUCH_ZOOM_ROTATE) && (this._zoomEnd = this._zoom, this._zoomVelocity.value = 0), ((this._state & x.OFFSET) === x.OFFSET || (this._state & x.TOUCH_OFFSET) === x.TOUCH_OFFSET || (this._state & x.TOUCH_DOLLY_OFFSET) === x.TOUCH_DOLLY_OFFSET || (this._state & x.TOUCH_ZOOM_OFFSET) === x.TOUCH_ZOOM_OFFSET) && (this._focalOffsetEnd.copy(this._focalOffset), this._focalOffsetVelocity.set(0, 0, 0)), this.dispatchEvent({
                                    type: "controlstart"
                                })
                            }
                        },
                        g = () => {
                            if (!this._enabled || !this._dragNeedsUpdate) return;
                            this._dragNeedsUpdate = !1, z(this._activePointers, l);
                            let e = this._domElement && this._domElement.ownerDocument.pointerLockElement === this._domElement ? this._lockedPointer || this._activePointers[0] : null,
                                t = e ? -e.deltaX : n.x - l.x,
                                i = e ? -e.deltaY : n.y - l.y;
                            if (n.copy(l), ((this._state & x.ROTATE) === x.ROTATE || (this._state & x.TOUCH_ROTATE) === x.TOUCH_ROTATE || (this._state & x.TOUCH_DOLLY_ROTATE) === x.TOUCH_DOLLY_ROTATE || (this._state & x.TOUCH_ZOOM_ROTATE) === x.TOUCH_ZOOM_ROTATE) && (this._rotateInternal(t, i), this._isUserControllingRotate = !0), (this._state & x.DOLLY) === x.DOLLY || (this._state & x.ZOOM) === x.ZOOM) {
                                let e = this.dollyToCursor ? (r.x - this._elementRect.x) / this._elementRect.width * 2 - 1 : 0,
                                    t = this.dollyToCursor ? -((r.y - this._elementRect.y) / this._elementRect.height * 2) + 1 : 0,
                                    n = this.dollyDragInverted ? -1 : 1;
                                (this._state & x.DOLLY) === x.DOLLY ? (this._dollyInternal(n * i * Q, e, t), this._isUserControllingDolly = !0) : (this._zoomInternal(n * i * Q, e, t), this._isUserControllingZoom = !0)
                            }
                            if ((this._state & x.TOUCH_DOLLY) === x.TOUCH_DOLLY || (this._state & x.TOUCH_ZOOM) === x.TOUCH_ZOOM || (this._state & x.TOUCH_DOLLY_TRUCK) === x.TOUCH_DOLLY_TRUCK || (this._state & x.TOUCH_ZOOM_TRUCK) === x.TOUCH_ZOOM_TRUCK || (this._state & x.TOUCH_DOLLY_OFFSET) === x.TOUCH_DOLLY_OFFSET || (this._state & x.TOUCH_ZOOM_OFFSET) === x.TOUCH_ZOOM_OFFSET || (this._state & x.TOUCH_DOLLY_ROTATE) === x.TOUCH_DOLLY_ROTATE || (this._state & x.TOUCH_ZOOM_ROTATE) === x.TOUCH_ZOOM_ROTATE) {
                                let e = l.x - this._activePointers[1].clientX,
                                    t = l.y - this._activePointers[1].clientY,
                                    r = Math.sqrt(e * e + t * t),
                                    i = a.y - r;
                                a.set(0, r);
                                let o = this.dollyToCursor ? (n.x - this._elementRect.x) / this._elementRect.width * 2 - 1 : 0,
                                    s = this.dollyToCursor ? -((n.y - this._elementRect.y) / this._elementRect.height * 2) + 1 : 0;
                                (this._state & x.TOUCH_DOLLY) === x.TOUCH_DOLLY || (this._state & x.TOUCH_DOLLY_ROTATE) === x.TOUCH_DOLLY_ROTATE || (this._state & x.TOUCH_DOLLY_TRUCK) === x.TOUCH_DOLLY_TRUCK || (this._state & x.TOUCH_DOLLY_OFFSET) === x.TOUCH_DOLLY_OFFSET ? (this._dollyInternal(i * Q, o, s), this._isUserControllingDolly = !0) : (this._zoomInternal(i * Q, o, s), this._isUserControllingZoom = !0)
                            }((this._state & x.TRUCK) === x.TRUCK || (this._state & x.TOUCH_TRUCK) === x.TOUCH_TRUCK || (this._state & x.TOUCH_DOLLY_TRUCK) === x.TOUCH_DOLLY_TRUCK || (this._state & x.TOUCH_ZOOM_TRUCK) === x.TOUCH_ZOOM_TRUCK) && (this._truckInternal(t, i, !1), this._isUserControllingTruck = !0), ((this._state & x.OFFSET) === x.OFFSET || (this._state & x.TOUCH_OFFSET) === x.TOUCH_OFFSET || (this._state & x.TOUCH_DOLLY_OFFSET) === x.TOUCH_DOLLY_OFFSET || (this._state & x.TOUCH_ZOOM_OFFSET) === x.TOUCH_ZOOM_OFFSET) && (this._truckInternal(t, i, !0), this._isUserControllingOffset = !0), this.dispatchEvent({
                                type: "control"
                            })
                        },
                        A = () => {
                            z(this._activePointers, l), n.copy(l), this._dragNeedsUpdate = !1, (0 === this._activePointers.length || 1 === this._activePointers.length && this._activePointers[0] === this._lockedPointer) && (this._isDragging = !1), 0 === this._activePointers.length && this._domElement && (this._domElement.ownerDocument.removeEventListener("pointermove", c, {
                                passive: !1
                            }), this._domElement.ownerDocument.removeEventListener("pointerup", d), this.dispatchEvent({
                                type: "controlend"
                            }))
                        };
                    this.lockPointer = () => {
                        this._enabled && this._domElement && (this.cancel(), this._lockedPointer = {
                            pointerId: -1,
                            clientX: 0,
                            clientY: 0,
                            deltaX: 0,
                            deltaY: 0,
                            mouseButton: null
                        }, this._activePointers.push(this._lockedPointer), this._domElement.ownerDocument.removeEventListener("pointermove", c, {
                            passive: !1
                        }), this._domElement.ownerDocument.removeEventListener("pointerup", d), this._domElement.requestPointerLock(), this._domElement.ownerDocument.addEventListener("pointerlockchange", v), this._domElement.ownerDocument.addEventListener("pointerlockerror", y), this._domElement.ownerDocument.addEventListener("pointermove", c, {
                            passive: !1
                        }), this._domElement.ownerDocument.addEventListener("pointerup", d), m())
                    }, this.unlockPointer = () => {
                        var e, t, r;
                        null !== this._lockedPointer && (this._disposePointer(this._lockedPointer), this._lockedPointer = null), null === (e = this._domElement) || void 0 === e || e.ownerDocument.exitPointerLock(), null === (t = this._domElement) || void 0 === t || t.ownerDocument.removeEventListener("pointerlockchange", v), null === (r = this._domElement) || void 0 === r || r.ownerDocument.removeEventListener("pointerlockerror", y), this.cancel()
                    };
                    let v = () => {
                            this._domElement && this._domElement.ownerDocument.pointerLockElement === this._domElement || this.unlockPointer()
                        },
                        y = () => {
                            this.unlockPointer()
                        };
                    this._addAllEventListeners = e => {
                        this._domElement = e, this._domElement.style.touchAction = "none", this._domElement.style.userSelect = "none", this._domElement.style.webkitUserSelect = "none", this._domElement.addEventListener("pointerdown", s), this._domElement.addEventListener("pointercancel", d), this._domElement.addEventListener("wheel", h, {
                            passive: !1
                        }), this._domElement.addEventListener("contextmenu", p)
                    }, this._removeAllEventListeners = () => {
                        this._domElement && (this._domElement.style.touchAction = "", this._domElement.style.userSelect = "", this._domElement.style.webkitUserSelect = "", this._domElement.removeEventListener("pointerdown", s), this._domElement.removeEventListener("pointercancel", d), this._domElement.removeEventListener("wheel", h, {
                            passive: !1
                        }), this._domElement.removeEventListener("contextmenu", p), this._domElement.ownerDocument.removeEventListener("pointermove", c, {
                            passive: !1
                        }), this._domElement.ownerDocument.removeEventListener("pointerup", d), this._domElement.ownerDocument.removeEventListener("pointerlockchange", v), this._domElement.ownerDocument.removeEventListener("pointerlockerror", y))
                    }, this.cancel = () => {
                        this._state !== x.NONE && (this._state = x.NONE, this._activePointers.length = 0, A())
                    }, t && this.connect(t), this.update(0)
                }
                get camera() {
                    return this._camera
                }
                set camera(e) {
                    this._camera = e, this.updateCameraUp(), this._camera.updateProjectionMatrix(), this._updateNearPlaneCorners(), this._needsUpdate = !0
                }
                get enabled() {
                    return this._enabled
                }
                set enabled(e) {
                    this._enabled = e, this._domElement && (e ? (this._domElement.style.touchAction = "none", this._domElement.style.userSelect = "none", this._domElement.style.webkitUserSelect = "none") : (this.cancel(), this._domElement.style.touchAction = "", this._domElement.style.userSelect = "", this._domElement.style.webkitUserSelect = ""))
                }
                get active() {
                    return !this._hasRested
                }
                get currentAction() {
                    return this._state
                }
                get distance() {
                    return this._spherical.radius
                }
                set distance(e) {
                    (this._spherical.radius !== e || this._sphericalEnd.radius !== e) && (this._spherical.radius = e, this._sphericalEnd.radius = e, this._needsUpdate = !0)
                }
                get azimuthAngle() {
                    return this._spherical.theta
                }
                set azimuthAngle(e) {
                    (this._spherical.theta !== e || this._sphericalEnd.theta !== e) && (this._spherical.theta = e, this._sphericalEnd.theta = e, this._needsUpdate = !0)
                }
                get polarAngle() {
                    return this._spherical.phi
                }
                set polarAngle(e) {
                    (this._spherical.phi !== e || this._sphericalEnd.phi !== e) && (this._spherical.phi = e, this._sphericalEnd.phi = e, this._needsUpdate = !0)
                }
                get boundaryEnclosesCamera() {
                    return this._boundaryEnclosesCamera
                }
                set boundaryEnclosesCamera(e) {
                    this._boundaryEnclosesCamera = e, this._needsUpdate = !0
                }
                set interactiveArea(e) {
                    this._interactiveArea.width = P(e.width, 0, 1), this._interactiveArea.height = P(e.height, 0, 1), this._interactiveArea.x = P(e.x, 0, 1 - this._interactiveArea.width), this._interactiveArea.y = P(e.y, 0, 1 - this._interactiveArea.height)
                }
                addEventListener(e, t) {
                    super.addEventListener(e, t)
                }
                removeEventListener(e, t) {
                    super.removeEventListener(e, t)
                }
                rotate(e, t, r = !1) {
                    return this.rotateTo(this._sphericalEnd.theta + e, this._sphericalEnd.phi + t, r)
                }
                rotateAzimuthTo(e, t = !1) {
                    return this.rotateTo(e, this._sphericalEnd.phi, t)
                }
                rotatePolarTo(e, t = !1) {
                    return this.rotateTo(this._sphericalEnd.theta, e, t)
                }
                rotateTo(e, t, r = !1) {
                    this._isUserControllingRotate = !1;
                    let n = P(e, this.minAzimuthAngle, this.maxAzimuthAngle),
                        i = P(t, this.minPolarAngle, this.maxPolarAngle);
                    this._sphericalEnd.theta = n, this._sphericalEnd.phi = i, this._sphericalEnd.makeSafe(), this._needsUpdate = !0, r || (this._spherical.theta = this._sphericalEnd.theta, this._spherical.phi = this._sphericalEnd.phi);
                    let a = !r || H(this._spherical.theta, this._sphericalEnd.theta, this.restThreshold) && H(this._spherical.phi, this._sphericalEnd.phi, this.restThreshold);
                    return this._createOnRestPromise(a)
                }
                dolly(e, t = !1) {
                    return this.dollyTo(this._sphericalEnd.radius - e, t)
                }
                dollyTo(e, t = !1) {
                    return this._isUserControllingDolly = !1, this._lastDollyDirection = F.NONE, this._changedDolly = 0, this._dollyToNoClamp(P(e, this.minDistance, this.maxDistance), t)
                }
                _dollyToNoClamp(e, t = !1) {
                    let r = this._sphericalEnd.radius;
                    if (this.colliderMeshes.length >= 1) {
                        let t = this._collisionTest(),
                            n = H(t, this._spherical.radius);
                        if (!(r > e) && n) return Promise.resolve();
                        this._sphericalEnd.radius = Math.min(e, t)
                    } else this._sphericalEnd.radius = e;
                    this._needsUpdate = !0, t || (this._spherical.radius = this._sphericalEnd.radius);
                    let n = !t || H(this._spherical.radius, this._sphericalEnd.radius, this.restThreshold);
                    return this._createOnRestPromise(n)
                }
                dollyInFixed(e, t = !1) {
                    this._targetEnd.add(this._getCameraDirection(f).multiplyScalar(e)), t || this._target.copy(this._targetEnd);
                    let r = !t || H(this._target.x, this._targetEnd.x, this.restThreshold) && H(this._target.y, this._targetEnd.y, this.restThreshold) && H(this._target.z, this._targetEnd.z, this.restThreshold);
                    return this._createOnRestPromise(r)
                }
                zoom(e, t = !1) {
                    return this.zoomTo(this._zoomEnd + e, t)
                }
                zoomTo(e, t = !1) {
                    this._isUserControllingZoom = !1, this._zoomEnd = P(e, this.minZoom, this.maxZoom), this._needsUpdate = !0, t || (this._zoom = this._zoomEnd);
                    let r = !t || H(this._zoom, this._zoomEnd, this.restThreshold);
                    return this._changedZoom = 0, this._createOnRestPromise(r)
                }
                pan(e, t, r = !1) {
                    return console.warn("`pan` has been renamed to `truck`"), this.truck(e, t, r)
                }
                truck(e, t, r = !1) {
                    this._camera.updateMatrix(), h.setFromMatrixColumn(this._camera.matrix, 0), p.setFromMatrixColumn(this._camera.matrix, 1), h.multiplyScalar(e), p.multiplyScalar(-t);
                    let n = u.copy(h).add(p),
                        i = c.copy(this._targetEnd).add(n);
                    return this.moveTo(i.x, i.y, i.z, r)
                }
                forward(e, t = !1) {
                    u.setFromMatrixColumn(this._camera.matrix, 0), u.crossVectors(this._camera.up, u), u.multiplyScalar(e);
                    let r = c.copy(this._targetEnd).add(u);
                    return this.moveTo(r.x, r.y, r.z, t)
                }
                elevate(e, t = !1) {
                    return u.copy(this._camera.up).multiplyScalar(e), this.moveTo(this._targetEnd.x + u.x, this._targetEnd.y + u.y, this._targetEnd.z + u.z, t)
                }
                moveTo(e, t, r, n = !1) {
                    this._isUserControllingTruck = !1;
                    let i = u.set(e, t, r).sub(this._targetEnd);
                    this._encloseToBoundary(this._targetEnd, i, this.boundaryFriction), this._needsUpdate = !0, n || this._target.copy(this._targetEnd);
                    let a = !n || H(this._target.x, this._targetEnd.x, this.restThreshold) && H(this._target.y, this._targetEnd.y, this.restThreshold) && H(this._target.z, this._targetEnd.z, this.restThreshold);
                    return this._createOnRestPromise(a)
                }
                lookInDirectionOf(e, t, r, n = !1) {
                    let i = u.set(e, t, r).sub(this._targetEnd).normalize().multiplyScalar(-this._sphericalEnd.radius).add(this._targetEnd);
                    return this.setPosition(i.x, i.y, i.z, n)
                }
                fitToBox(e, t, {
                    cover: r = !1,
                    paddingLeft: n = 0,
                    paddingRight: i = 0,
                    paddingBottom: a = 0,
                    paddingTop: l = 0
                } = {}) {
                    let d = [],
                        f = e.isBox3 ? C.copy(e) : C.setFromObject(e);
                    f.isEmpty() && (console.warn("camera-controls: fitTo() cannot be used with an empty box. Aborting"), Promise.resolve());
                    let h = U(this._sphericalEnd.theta, I),
                        p = U(this._sphericalEnd.phi, I);
                    d.push(this.rotateTo(h, p, t));
                    let m = u.setFromSpherical(this._sphericalEnd).normalize(),
                        g = b.setFromUnitVectors(m, s),
                        A = H(Math.abs(m.y), 1);
                    A && g.multiply(E.setFromAxisAngle(o, h)), g.multiply(this._yAxisUpSpaceInverse);
                    let v = B.makeEmpty();
                    c.copy(f.min).applyQuaternion(g), v.expandByPoint(c), c.copy(f.min).setX(f.max.x).applyQuaternion(g), v.expandByPoint(c), c.copy(f.min).setY(f.max.y).applyQuaternion(g), v.expandByPoint(c), c.copy(f.max).setZ(f.min.z).applyQuaternion(g), v.expandByPoint(c), c.copy(f.min).setZ(f.max.z).applyQuaternion(g), v.expandByPoint(c), c.copy(f.max).setY(f.min.y).applyQuaternion(g), v.expandByPoint(c), c.copy(f.max).setX(f.min.x).applyQuaternion(g), v.expandByPoint(c), c.copy(f.max).applyQuaternion(g), v.expandByPoint(c), v.min.x -= n, v.min.y -= a, v.max.x += i, v.max.y += l, g.setFromUnitVectors(s, m), A && g.premultiply(E.invert()), g.premultiply(this._yAxisUpSpace);
                    let y = v.getSize(u),
                        _ = v.getCenter(c).applyQuaternion(g);
                    if (S(this._camera)) {
                        let e = this.getDistanceToFitBox(y.x, y.y, y.z, r);
                        d.push(this.moveTo(_.x, _.y, _.z, t)), d.push(this.dollyTo(e, t)), d.push(this.setFocalOffset(0, 0, 0, t))
                    } else if (R(this._camera)) {
                        let e = this._camera,
                            n = e.right - e.left,
                            i = e.top - e.bottom,
                            a = r ? Math.max(n / y.x, i / y.y) : Math.min(n / y.x, i / y.y);
                        d.push(this.moveTo(_.x, _.y, _.z, t)), d.push(this.zoomTo(a, t)), d.push(this.setFocalOffset(0, 0, 0, t))
                    }
                    return Promise.all(d)
                }
                fitToSphere(e, t) {
                    let r = [],
                        n = e instanceof i.Sphere ? _.copy(e) : Y.createBoundingSphere(e, _);
                    if (r.push(this.moveTo(n.center.x, n.center.y, n.center.z, t)), S(this._camera)) {
                        let e = this.getDistanceToFitSphere(n.radius);
                        r.push(this.dollyTo(e, t))
                    } else if (R(this._camera)) {
                        let e = this._camera.right - this._camera.left,
                            i = this._camera.top - this._camera.bottom,
                            a = 2 * n.radius;
                        r.push(this.zoomTo(Math.min(e / a, i / a), t))
                    }
                    return r.push(this.setFocalOffset(0, 0, 0, t)), Promise.all(r)
                }
                setLookAt(e, t, r, n, i, a, o = !1) {
                    this._isUserControllingRotate = !1, this._isUserControllingDolly = !1, this._isUserControllingTruck = !1, this._lastDollyDirection = F.NONE, this._changedDolly = 0;
                    let s = c.set(n, i, a),
                        l = u.set(e, t, r);
                    this._targetEnd.copy(s), this._sphericalEnd.setFromVector3(l.sub(s).applyQuaternion(this._yAxisUpSpace)), this.normalizeRotations(), this._needsUpdate = !0, o || (this._target.copy(this._targetEnd), this._spherical.copy(this._sphericalEnd));
                    let d = !o || H(this._target.x, this._targetEnd.x, this.restThreshold) && H(this._target.y, this._targetEnd.y, this.restThreshold) && H(this._target.z, this._targetEnd.z, this.restThreshold) && H(this._spherical.theta, this._sphericalEnd.theta, this.restThreshold) && H(this._spherical.phi, this._sphericalEnd.phi, this.restThreshold) && H(this._spherical.radius, this._sphericalEnd.radius, this.restThreshold);
                    return this._createOnRestPromise(d)
                }
                lerpLookAt(e, t, r, n, i, a, o, s, l, f, h, p, m, g = !1) {
                    this._isUserControllingRotate = !1, this._isUserControllingDolly = !1, this._isUserControllingTruck = !1, this._lastDollyDirection = F.NONE, this._changedDolly = 0;
                    let A = u.set(n, i, a),
                        C = c.set(e, t, r);
                    v.setFromVector3(C.sub(A).applyQuaternion(this._yAxisUpSpace));
                    let B = d.set(f, h, p),
                        _ = c.set(o, s, l);
                    y.setFromVector3(_.sub(B).applyQuaternion(this._yAxisUpSpace)), this._targetEnd.copy(A.lerp(B, m));
                    let b = y.theta - v.theta,
                        E = y.phi - v.phi,
                        w = y.radius - v.radius;
                    this._sphericalEnd.set(v.radius + w * m, v.phi + E * m, v.theta + b * m), this.normalizeRotations(), this._needsUpdate = !0, g || (this._target.copy(this._targetEnd), this._spherical.copy(this._sphericalEnd));
                    let M = !g || H(this._target.x, this._targetEnd.x, this.restThreshold) && H(this._target.y, this._targetEnd.y, this.restThreshold) && H(this._target.z, this._targetEnd.z, this.restThreshold) && H(this._spherical.theta, this._sphericalEnd.theta, this.restThreshold) && H(this._spherical.phi, this._sphericalEnd.phi, this.restThreshold) && H(this._spherical.radius, this._sphericalEnd.radius, this.restThreshold);
                    return this._createOnRestPromise(M)
                }
                setPosition(e, t, r, n = !1) {
                    return this.setLookAt(e, t, r, this._targetEnd.x, this._targetEnd.y, this._targetEnd.z, n)
                }
                setTarget(e, t, r, n = !1) {
                    let i = this.getPosition(u),
                        a = this.setLookAt(i.x, i.y, i.z, e, t, r, n);
                    return this._sphericalEnd.phi = P(this._sphericalEnd.phi, this.minPolarAngle, this.maxPolarAngle), a
                }
                setFocalOffset(e, t, r, n = !1) {
                    this._isUserControllingOffset = !1, this._focalOffsetEnd.set(e, t, r), this._needsUpdate = !0, n || this._focalOffset.copy(this._focalOffsetEnd);
                    let i = !n || H(this._focalOffset.x, this._focalOffsetEnd.x, this.restThreshold) && H(this._focalOffset.y, this._focalOffsetEnd.y, this.restThreshold) && H(this._focalOffset.z, this._focalOffsetEnd.z, this.restThreshold);
                    return this._createOnRestPromise(i)
                }
                setOrbitPoint(e, t, r) {
                    this._camera.updateMatrixWorld(), h.setFromMatrixColumn(this._camera.matrixWorldInverse, 0), p.setFromMatrixColumn(this._camera.matrixWorldInverse, 1), m.setFromMatrixColumn(this._camera.matrixWorldInverse, 2);
                    let n = u.set(e, t, r),
                        i = n.distanceTo(this._camera.position),
                        a = n.sub(this._camera.position);
                    h.multiplyScalar(a.x), p.multiplyScalar(a.y), m.multiplyScalar(a.z), u.copy(h).add(p).add(m), u.z = u.z + i, this.dollyTo(i, !1), this.setFocalOffset(-u.x, u.y, -u.z, !1), this.moveTo(e, t, r, !1)
                }
                setBoundary(e) {
                    if (!e) {
                        this._boundary.min.set(-1 / 0, -1 / 0, -1 / 0), this._boundary.max.set(1 / 0, 1 / 0, 1 / 0), this._needsUpdate = !0;
                        return
                    }
                    this._boundary.copy(e), this._boundary.clampPoint(this._targetEnd, this._targetEnd), this._needsUpdate = !0
                }
                setViewport(e, t, r, n) {
                    if (null === e) {
                        this._viewport = null;
                        return
                    }
                    this._viewport = this._viewport || new i.Vector4, "number" == typeof e ? this._viewport.set(e, t, r, n) : this._viewport.copy(e)
                }
                getDistanceToFitBox(e, t, r, n = !1) {
                    if (j(this._camera, "getDistanceToFitBox")) return this._spherical.radius;
                    let i = e / t,
                        a = this._camera.getEffectiveFOV() * D,
                        o = this._camera.aspect;
                    return .5 * ((n ? i > o : i < o) ? t : e / o) / Math.tan(.5 * a) + .5 * r
                }
                getDistanceToFitSphere(e) {
                    if (j(this._camera, "getDistanceToFitSphere")) return this._spherical.radius;
                    let t = this._camera.getEffectiveFOV() * D,
                        r = 2 * Math.atan(Math.tan(.5 * t) * this._camera.aspect);
                    return e / Math.sin(.5 * (1 < this._camera.aspect ? t : r))
                }
                getTarget(e, t = !0) {
                    return (e && e.isVector3 ? e : new i.Vector3).copy(t ? this._targetEnd : this._target)
                }
                getPosition(e, t = !0) {
                    return (e && e.isVector3 ? e : new i.Vector3).setFromSpherical(t ? this._sphericalEnd : this._spherical).applyQuaternion(this._yAxisUpSpaceInverse).add(t ? this._targetEnd : this._target)
                }
                getSpherical(e, t = !0) {
                    return (e && e instanceof i.Spherical ? e : new i.Spherical).copy(t ? this._sphericalEnd : this._spherical)
                }
                getFocalOffset(e, t = !0) {
                    return (e && e.isVector3 ? e : new i.Vector3).copy(t ? this._focalOffsetEnd : this._focalOffset)
                }
                normalizeRotations() {
                    this._sphericalEnd.theta = this._sphericalEnd.theta % O, this._sphericalEnd.theta < 0 && (this._sphericalEnd.theta += O), this._spherical.theta += O * Math.round((this._sphericalEnd.theta - this._spherical.theta) / O)
                }
                reset(e = !1) {
                    if (!H(this._camera.up.x, this._cameraUp0.x) || !H(this._camera.up.y, this._cameraUp0.y) || !H(this._camera.up.z, this._cameraUp0.z)) {
                        this._camera.up.copy(this._cameraUp0);
                        let e = this.getPosition(u);
                        this.updateCameraUp(), this.setPosition(e.x, e.y, e.z)
                    }
                    return Promise.all([this.setLookAt(this._position0.x, this._position0.y, this._position0.z, this._target0.x, this._target0.y, this._target0.z, e), this.setFocalOffset(this._focalOffset0.x, this._focalOffset0.y, this._focalOffset0.z, e), this.zoomTo(this._zoom0, e)])
                }
                saveState() {
                    this._cameraUp0.copy(this._camera.up), this.getTarget(this._target0), this.getPosition(this._position0), this._zoom0 = this._zoom, this._focalOffset0.copy(this._focalOffset)
                }
                updateCameraUp() {
                    this._yAxisUpSpace.setFromUnitVectors(this._camera.up, o), this._yAxisUpSpaceInverse.copy(this._yAxisUpSpace).invert()
                }
                applyCameraUp() {
                    let e = u.subVectors(this._target, this._camera.position).normalize(),
                        t = c.crossVectors(e, this._camera.up);
                    this._camera.up.crossVectors(t, e).normalize(), this._camera.updateMatrixWorld();
                    let r = this.getPosition(u);
                    this.updateCameraUp(), this.setPosition(r.x, r.y, r.z)
                }
                update(e) {
                    let t = this._sphericalEnd.theta - this._spherical.theta,
                        r = this._sphericalEnd.phi - this._spherical.phi,
                        n = this._sphericalEnd.radius - this._spherical.radius,
                        i = g.subVectors(this._targetEnd, this._target),
                        a = A.subVectors(this._focalOffsetEnd, this._focalOffset),
                        o = this._zoomEnd - this._zoom;
                    if (L(t)) this._thetaVelocity.value = 0, this._spherical.theta = this._sphericalEnd.theta;
                    else {
                        let t = this._isUserControllingRotate ? this.draggingSmoothTime : this.smoothTime;
                        this._spherical.theta = N(this._spherical.theta, this._sphericalEnd.theta, this._thetaVelocity, t, 1 / 0, e), this._needsUpdate = !0
                    }
                    if (L(r)) this._phiVelocity.value = 0, this._spherical.phi = this._sphericalEnd.phi;
                    else {
                        let t = this._isUserControllingRotate ? this.draggingSmoothTime : this.smoothTime;
                        this._spherical.phi = N(this._spherical.phi, this._sphericalEnd.phi, this._phiVelocity, t, 1 / 0, e), this._needsUpdate = !0
                    }
                    if (L(n)) this._radiusVelocity.value = 0, this._spherical.radius = this._sphericalEnd.radius;
                    else {
                        let t = this._isUserControllingDolly ? this.draggingSmoothTime : this.smoothTime;
                        this._spherical.radius = N(this._spherical.radius, this._sphericalEnd.radius, this._radiusVelocity, t, this.maxSpeed, e), this._needsUpdate = !0
                    }
                    if (L(i.x) && L(i.y) && L(i.z)) this._targetVelocity.set(0, 0, 0), this._target.copy(this._targetEnd);
                    else {
                        let t = this._isUserControllingTruck ? this.draggingSmoothTime : this.smoothTime;
                        J(this._target, this._targetEnd, this._targetVelocity, t, this.maxSpeed, e, this._target), this._needsUpdate = !0
                    }
                    if (L(a.x) && L(a.y) && L(a.z)) this._focalOffsetVelocity.set(0, 0, 0), this._focalOffset.copy(this._focalOffsetEnd);
                    else {
                        let t = this._isUserControllingOffset ? this.draggingSmoothTime : this.smoothTime;
                        J(this._focalOffset, this._focalOffsetEnd, this._focalOffsetVelocity, t, this.maxSpeed, e, this._focalOffset), this._needsUpdate = !0
                    }
                    if (L(o)) this._zoomVelocity.value = 0, this._zoom = this._zoomEnd;
                    else {
                        let t = this._isUserControllingZoom ? this.draggingSmoothTime : this.smoothTime;
                        this._zoom = N(this._zoom, this._zoomEnd, this._zoomVelocity, t, 1 / 0, e)
                    }
                    if (this.dollyToCursor) {
                        if (S(this._camera) && 0 !== this._changedDolly) {
                            let e = this._spherical.radius - this._lastDistance,
                                t = this._camera,
                                r = this._getCameraDirection(f),
                                n = u.copy(r).cross(t.up).normalize();
                            0 === n.lengthSq() && (n.x = 1);
                            let i = c.crossVectors(n, r),
                                a = this._sphericalEnd.radius * Math.tan(t.getEffectiveFOV() * D * .5),
                                o = (this._sphericalEnd.radius - e - this._sphericalEnd.radius) / this._sphericalEnd.radius,
                                s = d.copy(this._targetEnd).add(n.multiplyScalar(this._dollyControlCoord.x * a * t.aspect)).add(i.multiplyScalar(this._dollyControlCoord.y * a)),
                                l = u.copy(this._targetEnd).lerp(s, o),
                                h = this._lastDollyDirection === F.IN && this._spherical.radius <= this.minDistance,
                                p = this._lastDollyDirection === F.OUT && this.maxDistance <= this._spherical.radius;
                            if (this.infinityDolly && (h || p)) {
                                this._sphericalEnd.radius -= e, this._spherical.radius -= e;
                                let t = c.copy(r).multiplyScalar(-e);
                                l.add(t)
                            }
                            this._boundary.clampPoint(l, l);
                            let m = c.subVectors(l, this._targetEnd);
                            this._targetEnd.copy(l), this._target.add(m), this._changedDolly -= e, L(this._changedDolly) && (this._changedDolly = 0)
                        } else if (R(this._camera) && 0 !== this._changedZoom) {
                            let e = this._zoom - this._lastZoom,
                                t = this._camera,
                                r = u.set(this._dollyControlCoord.x, this._dollyControlCoord.y, (t.near + t.far) / (t.near - t.far)).unproject(t),
                                n = c.set(0, 0, -1).applyQuaternion(t.quaternion),
                                i = d.copy(r).add(n.multiplyScalar(-r.dot(t.up))),
                                a = -(this._zoom - e - this._zoom) / this._zoom,
                                o = this._getCameraDirection(f),
                                s = this._targetEnd.dot(o),
                                l = u.copy(this._targetEnd).lerp(i, a),
                                h = l.dot(o),
                                p = o.multiplyScalar(h - s);
                            l.sub(p), this._boundary.clampPoint(l, l);
                            let m = c.subVectors(l, this._targetEnd);
                            this._targetEnd.copy(l), this._target.add(m), this._changedZoom -= e, L(this._changedZoom) && (this._changedZoom = 0)
                        }
                    }
                    this._camera.zoom !== this._zoom && (this._camera.zoom = this._zoom, this._camera.updateProjectionMatrix(), this._updateNearPlaneCorners(), this._needsUpdate = !0), this._dragNeedsUpdate = !0;
                    let s = this._collisionTest();
                    this._spherical.radius = Math.min(this._spherical.radius, s), this._spherical.makeSafe(), this._camera.position.setFromSpherical(this._spherical).applyQuaternion(this._yAxisUpSpaceInverse).add(this._target), this._camera.lookAt(this._target), L(this._focalOffset.x) && L(this._focalOffset.y) && L(this._focalOffset.z) || (this._camera.updateMatrixWorld(), h.setFromMatrixColumn(this._camera.matrix, 0), p.setFromMatrixColumn(this._camera.matrix, 1), m.setFromMatrixColumn(this._camera.matrix, 2), h.multiplyScalar(this._focalOffset.x), p.multiplyScalar(-this._focalOffset.y), m.multiplyScalar(this._focalOffset.z), u.copy(h).add(p).add(m), this._camera.position.add(u)), this._boundaryEnclosesCamera && this._encloseToBoundary(this._camera.position.copy(this._target), u.setFromSpherical(this._spherical).applyQuaternion(this._yAxisUpSpaceInverse), 1);
                    let l = this._needsUpdate;
                    return l && !this._updatedLastTime ? (this._hasRested = !1, this.dispatchEvent({
                        type: "wake"
                    }), this.dispatchEvent({
                        type: "update"
                    })) : l ? (this.dispatchEvent({
                        type: "update"
                    }), L(t, this.restThreshold) && L(r, this.restThreshold) && L(n, this.restThreshold) && L(i.x, this.restThreshold) && L(i.y, this.restThreshold) && L(i.z, this.restThreshold) && L(a.x, this.restThreshold) && L(a.y, this.restThreshold) && L(a.z, this.restThreshold) && L(o, this.restThreshold) && !this._hasRested && (this._hasRested = !0, this.dispatchEvent({
                        type: "rest"
                    }))) : !l && this._updatedLastTime && this.dispatchEvent({
                        type: "sleep"
                    }), this._lastDistance = this._spherical.radius, this._lastZoom = this._zoom, this._updatedLastTime = l, this._needsUpdate = !1, l
                }
                toJSON() {
                    return JSON.stringify({
                        enabled: this._enabled,
                        minDistance: this.minDistance,
                        maxDistance: G(this.maxDistance),
                        minZoom: this.minZoom,
                        maxZoom: G(this.maxZoom),
                        minPolarAngle: this.minPolarAngle,
                        maxPolarAngle: G(this.maxPolarAngle),
                        minAzimuthAngle: G(this.minAzimuthAngle),
                        maxAzimuthAngle: G(this.maxAzimuthAngle),
                        smoothTime: this.smoothTime,
                        draggingSmoothTime: this.draggingSmoothTime,
                        dollySpeed: this.dollySpeed,
                        truckSpeed: this.truckSpeed,
                        dollyToCursor: this.dollyToCursor,
                        verticalDragToForward: this.verticalDragToForward,
                        target: this._targetEnd.toArray(),
                        position: u.setFromSpherical(this._sphericalEnd).add(this._targetEnd).toArray(),
                        zoom: this._zoomEnd,
                        focalOffset: this._focalOffsetEnd.toArray(),
                        target0: this._target0.toArray(),
                        position0: this._position0.toArray(),
                        zoom0: this._zoom0,
                        focalOffset0: this._focalOffset0.toArray()
                    })
                }
                fromJSON(e, t = !1) {
                    let r = JSON.parse(e);
                    this.enabled = r.enabled, this.minDistance = r.minDistance, this.maxDistance = k(r.maxDistance), this.minZoom = r.minZoom, this.maxZoom = k(r.maxZoom), this.minPolarAngle = r.minPolarAngle, this.maxPolarAngle = k(r.maxPolarAngle), this.minAzimuthAngle = k(r.minAzimuthAngle), this.maxAzimuthAngle = k(r.maxAzimuthAngle), this.smoothTime = r.smoothTime, this.draggingSmoothTime = r.draggingSmoothTime, this.dollySpeed = r.dollySpeed, this.truckSpeed = r.truckSpeed, this.dollyToCursor = r.dollyToCursor, this.verticalDragToForward = r.verticalDragToForward, this._target0.fromArray(r.target0), this._position0.fromArray(r.position0), this._zoom0 = r.zoom0, this._focalOffset0.fromArray(r.focalOffset0), this.moveTo(r.target[0], r.target[1], r.target[2], t), v.setFromVector3(u.fromArray(r.position).sub(this._targetEnd).applyQuaternion(this._yAxisUpSpace)), this.rotateTo(v.theta, v.phi, t), this.dollyTo(v.radius, t), this.zoomTo(r.zoom, t), this.setFocalOffset(r.focalOffset[0], r.focalOffset[1], r.focalOffset[2], t), this._needsUpdate = !0
                }
                connect(e) {
                    if (this._domElement) {
                        console.warn("camera-controls is already connected.");
                        return
                    }
                    e.setAttribute("data-camera-controls-version", "2.8.3"), this._addAllEventListeners(e), this._getClientRect(this._elementRect)
                }
                disconnect() {
                    this.cancel(), this._removeAllEventListeners(), this._domElement && (this._domElement.removeAttribute("data-camera-controls-version"), this._domElement = void 0)
                }
                dispose() {
                    this.removeAllEventListeners(), this.disconnect()
                }
                _getTargetDirection(e) {
                    return e.setFromSpherical(this._spherical).divideScalar(this._spherical.radius).applyQuaternion(this._yAxisUpSpaceInverse)
                }
                _getCameraDirection(e) {
                    return this._getTargetDirection(e).negate()
                }
                _findPointerById(e) {
                    return this._activePointers.find(t => t.pointerId === e)
                }
                _findPointerByMouseButton(e) {
                    return this._activePointers.find(t => t.mouseButton === e)
                }
                _disposePointer(e) {
                    this._activePointers.splice(this._activePointers.indexOf(e), 1)
                }
                _encloseToBoundary(e, t, r) {
                    let n = t.lengthSq();
                    if (0 === n) return e;
                    let i = c.copy(t).add(e),
                        a = this._boundary.clampPoint(i, d).sub(i),
                        o = a.lengthSq();
                    if (0 === o) return e.add(t);
                    if (o === n) return e;
                    if (0 === r) return e.add(t).add(a); {
                        let n = 1 + r * o / t.dot(a);
                        return e.add(c.copy(t).multiplyScalar(n)).add(a.multiplyScalar(1 - r))
                    }
                }
                _updateNearPlaneCorners() {
                    if (S(this._camera)) {
                        let e = this._camera,
                            t = e.near,
                            r = Math.tan(e.getEffectiveFOV() * D * .5) * t,
                            n = r * e.aspect;
                        this._nearPlaneCorners[0].set(-n, -r, 0), this._nearPlaneCorners[1].set(n, -r, 0), this._nearPlaneCorners[2].set(n, r, 0), this._nearPlaneCorners[3].set(-n, r, 0)
                    } else if (R(this._camera)) {
                        let e = this._camera,
                            t = 1 / e.zoom,
                            r = e.left * t,
                            n = e.right * t,
                            i = e.top * t,
                            a = e.bottom * t;
                        this._nearPlaneCorners[0].set(r, i, 0), this._nearPlaneCorners[1].set(n, i, 0), this._nearPlaneCorners[2].set(n, a, 0), this._nearPlaneCorners[3].set(r, a, 0)
                    }
                }
                _collisionTest() {
                    let e = 1 / 0;
                    if (!(this.colliderMeshes.length >= 1) || j(this._camera, "_collisionTest")) return e;
                    let t = this._getTargetDirection(f);
                    w.lookAt(a, t, this._camera.up);
                    for (let r = 0; r < 4; r++) {
                        let n = c.copy(this._nearPlaneCorners[r]);
                        n.applyMatrix4(w);
                        let i = d.addVectors(this._target, n);
                        M.set(i, t), M.far = this._spherical.radius + 1;
                        let a = M.intersectObjects(this.colliderMeshes);
                        0 !== a.length && a[0].distance < e && (e = a[0].distance)
                    }
                    return e
                }
                _getClientRect(e) {
                    if (!this._domElement) return;
                    let t = this._domElement.getBoundingClientRect();
                    return e.x = t.left, e.y = t.top, this._viewport ? (e.x += this._viewport.x, e.y += t.height - this._viewport.w - this._viewport.y, e.width = this._viewport.z, e.height = this._viewport.w) : (e.width = t.width, e.height = t.height), e
                }
                _createOnRestPromise(e) {
                    return e ? Promise.resolve() : (this._hasRested = !1, this.dispatchEvent({
                        type: "transitionstart"
                    }), new Promise(e => {
                        let t = () => {
                            this.removeEventListener("rest", t), e()
                        };
                        this.addEventListener("rest", t)
                    }))
                }
                _addAllEventListeners(e) {}
                _removeAllEventListeners() {}
                get dampingFactor() {
                    return console.warn(".dampingFactor has been deprecated. use smoothTime (in seconds) instead."), 0
                }
                set dampingFactor(e) {
                    console.warn(".dampingFactor has been deprecated. use smoothTime (in seconds) instead.")
                }
                get draggingDampingFactor() {
                    return console.warn(".draggingDampingFactor has been deprecated. use draggingSmoothTime (in seconds) instead."), 0
                }
                set draggingDampingFactor(e) {
                    console.warn(".draggingDampingFactor has been deprecated. use draggingSmoothTime (in seconds) instead.")
                }
                static createBoundingSphere(e, t = new i.Sphere) {
                    let r = t.center;
                    C.makeEmpty(), e.traverseVisible(e => {
                        e.isMesh && C.expandByObject(e)
                    }), C.getCenter(r);
                    let n = 0;
                    return e.traverseVisible(e => {
                        if (!e.isMesh) return;
                        let t = e.geometry.clone();
                        t.applyMatrix4(e.matrixWorld);
                        let i = t.attributes.position;
                        for (let e = 0, t = i.count; e < t; e++) u.fromBufferAttribute(i, e), n = Math.max(n, r.distanceToSquared(u))
                    }), t.radius = Math.sqrt(n), t
                }
            }
        },
        19188: function(e, t, r) {
            "use strict";

            function n(e, t) {
                return (n = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            r.d(t, {
                G0: function() {
                    return A
                },
                OZ: function() {
                    return _
                }
            });
            var i, a, o, s, l, u, c, d = r(99477);

            function f(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var r = 0, n = Array(t); r < t; r++) n[r] = e[r];
                return n
            }

            function h(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    var r, n, i = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != i) {
                        var a = [],
                            o = !0,
                            s = !1;
                        try {
                            for (i = i.call(e); !(o = (r = i.next()).done) && (a.push(r.value), !t || a.length !== t); o = !0);
                        } catch (e) {
                            s = !0, n = e
                        } finally {
                            try {
                                o || null == i.return || i.return()
                            } finally {
                                if (s) throw n
                            }
                        }
                        return a
                    }
                }(e, t) || function(e, t) {
                    if (e) {
                        if ("string" == typeof e) return f(e, t);
                        var r = Object.prototype.toString.call(e).slice(8, -1);
                        if ("Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r) return Array.from(e);
                        if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return f(e, t)
                    }
                }(e, t) || function() {
                    throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }
            new d.Vector2, new d.Vector2;
            var p = function(e) {
                return 1 / (1 + e + .48 * e * e + .235 * e * e * e)
            };

            function m(e, t, r) {
                var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : .25,
                    i = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : .01,
                    a = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1 / 0,
                    o = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : p,
                    s = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : .001,
                    l = "velocity_" + t;
                if (void 0 === e.__damp && (e.__damp = {}), void 0 === e.__damp[l] && (e.__damp[l] = 0), Math.abs(e[t] - r) <= s) return e[t] = r, !1;
                var u = 2 / (n = Math.max(1e-4, n)),
                    c = o(u * i),
                    d = e[t] - r,
                    f = r,
                    h = a * n;
                d = Math.min(Math.max(d, -h), h), r = e[t] - d;
                var m = (e.__damp[l] + u * d) * i;
                e.__damp[l] = (e.__damp[l] - u * m) * c;
                var g = r + (d + m) * c;
                return f - e[t] > 0 == g > f && (g = f, e.__damp[l] = (g - f) / i), e[t] = g, !0
            }
            var g = new d.Vector3;

            function A(e, t, r, n, s, l, u) {
                return "number" == typeof t ? g.setScalar(t) : Array.isArray(t) ? g.set(t[0], t[1], t[2]) : g.copy(t), i = m(e, "x", g.x, r, n, s, l, u), a = m(e, "y", g.y, r, n, s, l, u), o = m(e, "z", g.z, r, n, s, l, u), i || a || o
            }
            var v = new d.Quaternion,
                y = new d.Vector4,
                C = new d.Vector4,
                B = new d.Vector4;

            function _(e, t, r, n, i, a, o) {
                Array.isArray(t) ? v.set(t[0], t[1], t[2], t[3]) : v.copy(t);
                var d = e.dot(v) > 0 ? 1 : -1;
                return v.x *= d, v.y *= d, v.z *= d, v.w *= d, s = m(e, "x", v.x, r, n, i, a, o), l = m(e, "y", v.y, r, n, i, a, o), u = m(e, "z", v.z, r, n, i, a, o), c = m(e, "w", v.w, r, n, i, a, o), y.set(e.x, e.y, e.z, e.w).normalize(), C.set(e.__damp.velocity_x, e.__damp.velocity_y, e.__damp.velocity_z, e.__damp.velocity_w), B.copy(y).multiplyScalar(C.dot(y) / y.dot(y)), e.__damp.velocity_x -= B.x, e.__damp.velocity_y -= B.y, e.__damp.velocity_z -= B.z, e.__damp.velocity_w -= B.w, e.set(y.x, y.y, y.z, y.w), s || l || u || c
            }
        },
        92703: function(e, t, r) {
            "use strict";
            var n = r(50414);

            function i() {}

            function a() {}
            a.resetWarningCache = i, e.exports = function() {
                function e(e, t, r, i, a, o) {
                    if (o !== n) {
                        var s = Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                        throw s.name = "Invariant Violation", s
                    }
                }

                function t() {
                    return e
                }
                e.isRequired = e;
                var r = {
                    array: e,
                    bigint: e,
                    bool: e,
                    func: e,
                    number: e,
                    object: e,
                    string: e,
                    symbol: e,
                    any: e,
                    arrayOf: t,
                    element: e,
                    elementType: e,
                    instanceOf: t,
                    node: e,
                    objectOf: t,
                    oneOf: t,
                    oneOfType: t,
                    shape: t,
                    exact: t,
                    checkPropTypes: a,
                    resetWarningCache: i
                };
                return r.PropTypes = r, r
            }
        },
        45697: function(e, t, r) {
            e.exports = r(92703)()
        },
        50414: function(e) {
            "use strict";
            e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
        },
        46511: function(e, t) {
            "use strict";
            t.ConcurrentRoot = 1, t.ContinuousEventPriority = 4, t.DefaultEventPriority = 16, t.DiscreteEventPriority = 1
        },
        67287: function(e, t, r) {
            e.exports = function(e) {
                "use strict";
                var t, n, i, a, o, s = {},
                    l = r(67294),
                    u = r(60373),
                    c = Object.assign;

                function d(e) {
                    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, r = 1; r < arguments.length; r++) t += "&args[]=" + encodeURIComponent(arguments[r]);
                    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
                }
                var f = l.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
                    h = Symbol.for("react.element"),
                    p = Symbol.for("react.portal"),
                    m = Symbol.for("react.fragment"),
                    g = Symbol.for("react.strict_mode"),
                    A = Symbol.for("react.profiler"),
                    v = Symbol.for("react.provider"),
                    y = Symbol.for("react.context"),
                    C = Symbol.for("react.forward_ref"),
                    B = Symbol.for("react.suspense"),
                    _ = Symbol.for("react.suspense_list"),
                    b = Symbol.for("react.memo"),
                    E = Symbol.for("react.lazy");
                Symbol.for("react.scope"), Symbol.for("react.debug_trace_mode");
                var w = Symbol.for("react.offscreen");
                Symbol.for("react.legacy_hidden"), Symbol.for("react.cache"), Symbol.for("react.tracing_marker");
                var M = Symbol.iterator;

                function T(e) {
                    return null === e || "object" != typeof e ? null : "function" == typeof(e = M && e[M] || e["@@iterator"]) ? e : null
                }

                function x(e) {
                    if (null == e) return null;
                    if ("function" == typeof e) return e.displayName || e.name || null;
                    if ("string" == typeof e) return e;
                    switch (e) {
                        case m:
                            return "Fragment";
                        case p:
                            return "Portal";
                        case A:
                            return "Profiler";
                        case g:
                            return "StrictMode";
                        case B:
                            return "Suspense";
                        case _:
                            return "SuspenseList"
                    }
                    if ("object" == typeof e) switch (e.$$typeof) {
                        case y:
                            return (e.displayName || "Context") + ".Consumer";
                        case v:
                            return (e._context.displayName || "Context") + ".Provider";
                        case C:
                            var t = e.render;
                            return (e = e.displayName) || (e = "" !== (e = t.displayName || t.name || "") ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
                        case b:
                            return null !== (t = e.displayName || null) ? t : x(e.type) || "Memo";
                        case E:
                            t = e._payload, e = e._init;
                            try {
                                return x(e(t))
                            } catch (e) {}
                    }
                    return null
                }

                function F(e) {
                    var t = e,
                        r = e;
                    if (e.alternate)
                        for (; t.return;) t = t.return;
                    else {
                        e = t;
                        do 0 != (4098 & (t = e).flags) && (r = t.return), e = t.return; while (e)
                    }
                    return 3 === t.tag ? r : null
                }

                function S(e) {
                    if (F(e) !== e) throw Error(d(188))
                }

                function R(e) {
                    var t = e.alternate;
                    if (!t) {
                        if (null === (t = F(e))) throw Error(d(188));
                        return t !== e ? null : e
                    }
                    for (var r = e, n = t;;) {
                        var i = r.return;
                        if (null === i) break;
                        var a = i.alternate;
                        if (null === a) {
                            if (null !== (n = i.return)) {
                                r = n;
                                continue
                            }
                            break
                        }
                        if (i.child === a.child) {
                            for (a = i.child; a;) {
                                if (a === r) return S(i), e;
                                if (a === n) return S(i), t;
                                a = a.sibling
                            }
                            throw Error(d(188))
                        }
                        if (r.return !== n.return) r = i, n = a;
                        else {
                            for (var o = !1, s = i.child; s;) {
                                if (s === r) {
                                    o = !0, r = i, n = a;
                                    break
                                }
                                if (s === n) {
                                    o = !0, n = i, r = a;
                                    break
                                }
                                s = s.sibling
                            }
                            if (!o) {
                                for (s = a.child; s;) {
                                    if (s === r) {
                                        o = !0, r = a, n = i;
                                        break
                                    }
                                    if (s === n) {
                                        o = !0, n = a, r = i;
                                        break
                                    }
                                    s = s.sibling
                                }
                                if (!o) throw Error(d(189))
                            }
                        }
                        if (r.alternate !== n) throw Error(d(190))
                    }
                    if (3 !== r.tag) throw Error(d(188));
                    return r.stateNode.current === r ? e : t
                }

                function O(e) {
                    return null !== (e = R(e)) ? function e(t) {
                        if (5 === t.tag || 6 === t.tag) return t;
                        for (t = t.child; null !== t;) {
                            var r = e(t);
                            if (null !== r) return r;
                            t = t.sibling
                        }
                        return null
                    }(e) : null
                }
                var I, D = Array.isArray,
                    P = e.getPublicInstance,
                    L = e.getRootHostContext,
                    H = e.getChildHostContext,
                    U = e.prepareForCommit,
                    G = e.resetAfterCommit,
                    k = e.createInstance,
                    N = e.appendInitialChild,
                    J = e.finalizeInitialChildren,
                    z = e.prepareUpdate,
                    j = e.shouldSetTextContent,
                    K = e.createTextInstance,
                    Q = e.scheduleTimeout,
                    V = e.cancelTimeout,
                    Y = e.noTimeout,
                    X = e.isPrimaryRenderer,
                    W = e.supportsMutation,
                    Z = e.supportsPersistence,
                    q = e.supportsHydration,
                    $ = e.getInstanceFromNode,
                    ee = e.preparePortalMount,
                    et = e.getCurrentEventPriority,
                    er = e.detachDeletedInstance,
                    en = e.supportsMicrotasks,
                    ei = e.scheduleMicrotask,
                    ea = e.supportsTestSelectors,
                    eo = e.findFiberRoot,
                    es = e.getBoundingRect,
                    el = e.getTextContent,
                    eu = e.isHiddenSubtree,
                    ec = e.matchAccessibilityRole,
                    ed = e.setFocusIfFocusable,
                    ef = e.setupIntersectionObserver,
                    eh = e.appendChild,
                    ep = e.appendChildToContainer,
                    em = e.commitTextUpdate,
                    eg = e.commitMount,
                    eA = e.commitUpdate,
                    ev = e.insertBefore,
                    ey = e.insertInContainerBefore,
                    eC = e.removeChild,
                    eB = e.removeChildFromContainer,
                    e_ = e.resetTextContent,
                    eb = e.hideInstance,
                    eE = e.hideTextInstance,
                    ew = e.unhideInstance,
                    eM = e.unhideTextInstance,
                    eT = e.clearContainer,
                    ex = e.cloneInstance,
                    eF = e.createContainerChildSet,
                    eS = e.appendChildToContainerChildSet,
                    eR = e.finalizeContainerChildren,
                    eO = e.replaceContainerChildren,
                    eI = e.cloneHiddenInstance,
                    eD = e.cloneHiddenTextInstance,
                    eP = e.canHydrateInstance,
                    eL = e.canHydrateTextInstance,
                    eH = e.canHydrateSuspenseInstance,
                    eU = e.isSuspenseInstancePending,
                    eG = e.isSuspenseInstanceFallback,
                    ek = e.registerSuspenseInstanceRetry,
                    eN = e.getNextHydratableSibling,
                    eJ = e.getFirstHydratableChild,
                    ez = e.getFirstHydratableChildWithinContainer,
                    ej = e.getFirstHydratableChildWithinSuspenseInstance,
                    eK = e.hydrateInstance,
                    eQ = e.hydrateTextInstance,
                    eV = e.hydrateSuspenseInstance,
                    eY = e.getNextHydratableInstanceAfterSuspenseInstance,
                    eX = e.commitHydratedContainer,
                    eW = e.commitHydratedSuspenseInstance,
                    eZ = e.clearSuspenseBoundary,
                    eq = e.clearSuspenseBoundaryFromContainer,
                    e$ = e.shouldDeleteUnhydratedTailInstances,
                    e0 = e.didNotMatchHydratedContainerTextInstance,
                    e1 = e.didNotMatchHydratedTextInstance;

                function e2(e) {
                    if (void 0 === I) try {
                        throw Error()
                    } catch (e) {
                        var t = e.stack.trim().match(/\n( *(at )?)/);
                        I = t && t[1] || ""
                    }
                    return "\n" + I + e
                }
                var e9 = !1;

                function e3(e, t) {
                    if (!e || e9) return "";
                    e9 = !0;
                    var r = Error.prepareStackTrace;
                    Error.prepareStackTrace = void 0;
                    try {
                        if (t) {
                            if (t = function() {
                                    throw Error()
                                }, Object.defineProperty(t.prototype, "props", {
                                    set: function() {
                                        throw Error()
                                    }
                                }), "object" == typeof Reflect && Reflect.construct) {
                                try {
                                    Reflect.construct(t, [])
                                } catch (e) {
                                    var n = e
                                }
                                Reflect.construct(e, [], t)
                            } else {
                                try {
                                    t.call()
                                } catch (e) {
                                    n = e
                                }
                                e.call(t.prototype)
                            }
                        } else {
                            try {
                                throw Error()
                            } catch (e) {
                                n = e
                            }
                            e()
                        }
                    } catch (t) {
                        if (t && n && "string" == typeof t.stack) {
                            for (var i = t.stack.split("\n"), a = n.stack.split("\n"), o = i.length - 1, s = a.length - 1; 1 <= o && 0 <= s && i[o] !== a[s];) s--;
                            for (; 1 <= o && 0 <= s; o--, s--)
                                if (i[o] !== a[s]) {
                                    if (1 !== o || 1 !== s)
                                        do
                                            if (o--, 0 > --s || i[o] !== a[s]) {
                                                var l = "\n" + i[o].replace(" at new ", " at ");
                                                return e.displayName && l.includes("<anonymous>") && (l = l.replace("<anonymous>", e.displayName)), l
                                            }
                                    while (1 <= o && 0 <= s);
                                    break
                                }
                        }
                    } finally {
                        e9 = !1, Error.prepareStackTrace = r
                    }
                    return (e = e ? e.displayName || e.name : "") ? e2(e) : ""
                }
                var e8 = Object.prototype.hasOwnProperty,
                    e4 = [],
                    e6 = -1;

                function e5(e) {
                    return {
                        current: e
                    }
                }

                function e7(e) {
                    0 > e6 || (e.current = e4[e6], e4[e6] = null, e6--)
                }

                function te(e, t) {
                    e4[++e6] = e.current, e.current = t
                }
                var tt = {},
                    tr = e5(tt),
                    tn = e5(!1),
                    ti = tt;

                function ta(e, t) {
                    var r = e.type.contextTypes;
                    if (!r) return tt;
                    var n = e.stateNode;
                    if (n && n.__reactInternalMemoizedUnmaskedChildContext === t) return n.__reactInternalMemoizedMaskedChildContext;
                    var i, a = {};
                    for (i in r) a[i] = t[i];
                    return n && ((e = e.stateNode).__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = a), a
                }

                function to(e) {
                    return null != (e = e.childContextTypes)
                }

                function ts() {
                    e7(tn), e7(tr)
                }

                function tl(e, t, r) {
                    if (tr.current !== tt) throw Error(d(168));
                    te(tr, t), te(tn, r)
                }

                function tu(e, t, r) {
                    var n = e.stateNode;
                    if (t = t.childContextTypes, "function" != typeof n.getChildContext) return r;
                    for (var i in n = n.getChildContext())
                        if (!(i in t)) throw Error(d(108, function(e) {
                            var t = e.type;
                            switch (e.tag) {
                                case 24:
                                    return "Cache";
                                case 9:
                                    return (t.displayName || "Context") + ".Consumer";
                                case 10:
                                    return (t._context.displayName || "Context") + ".Provider";
                                case 18:
                                    return "DehydratedFragment";
                                case 11:
                                    return e = (e = t.render).displayName || e.name || "", t.displayName || ("" !== e ? "ForwardRef(" + e + ")" : "ForwardRef");
                                case 7:
                                    return "Fragment";
                                case 5:
                                    return t;
                                case 4:
                                    return "Portal";
                                case 3:
                                    return "Root";
                                case 6:
                                    return "Text";
                                case 16:
                                    return x(t);
                                case 8:
                                    return t === g ? "StrictMode" : "Mode";
                                case 22:
                                    return "Offscreen";
                                case 12:
                                    return "Profiler";
                                case 21:
                                    return "Scope";
                                case 13:
                                    return "Suspense";
                                case 19:
                                    return "SuspenseList";
                                case 25:
                                    return "TracingMarker";
                                case 1:
                                case 0:
                                case 17:
                                case 2:
                                case 14:
                                case 15:
                                    if ("function" == typeof t) return t.displayName || t.name || null;
                                    if ("string" == typeof t) return t
                            }
                            return null
                        }(e) || "Unknown", i));
                    return c({}, r, n)
                }

                function tc(e) {
                    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || tt, ti = tr.current, te(tr, e), te(tn, tn.current), !0
                }

                function td(e, t, r) {
                    var n = e.stateNode;
                    if (!n) throw Error(d(169));
                    r ? (e = tu(e, t, ti), n.__reactInternalMemoizedMergedChildContext = e, e7(tn), e7(tr), te(tr, e)) : e7(tn), te(tn, r)
                }
                var tf = Math.clz32 ? Math.clz32 : function(e) {
                        return 0 == (e >>>= 0) ? 32 : 31 - (th(e) / tp | 0) | 0
                    },
                    th = Math.log,
                    tp = Math.LN2,
                    tm = 64,
                    tg = 4194304;

                function tA(e) {
                    switch (e & -e) {
                        case 1:
                            return 1;
                        case 2:
                            return 2;
                        case 4:
                            return 4;
                        case 8:
                            return 8;
                        case 16:
                            return 16;
                        case 32:
                            return 32;
                        case 64:
                        case 128:
                        case 256:
                        case 512:
                        case 1024:
                        case 2048:
                        case 4096:
                        case 8192:
                        case 16384:
                        case 32768:
                        case 65536:
                        case 131072:
                        case 262144:
                        case 524288:
                        case 1048576:
                        case 2097152:
                            return 4194240 & e;
                        case 4194304:
                        case 8388608:
                        case 16777216:
                        case 33554432:
                        case 67108864:
                            return 130023424 & e;
                        case 134217728:
                            return 134217728;
                        case 268435456:
                            return 268435456;
                        case 536870912:
                            return 536870912;
                        case 1073741824:
                            return 1073741824;
                        default:
                            return e
                    }
                }

                function tv(e, t) {
                    var r = e.pendingLanes;
                    if (0 === r) return 0;
                    var n = 0,
                        i = e.suspendedLanes,
                        a = e.pingedLanes,
                        o = 268435455 & r;
                    if (0 !== o) {
                        var s = o & ~i;
                        0 !== s ? n = tA(s) : 0 != (a &= o) && (n = tA(a))
                    } else 0 != (o = r & ~i) ? n = tA(o) : 0 !== a && (n = tA(a));
                    if (0 === n) return 0;
                    if (0 !== t && t !== n && 0 == (t & i) && ((i = n & -n) >= (a = t & -t) || 16 === i && 0 != (4194240 & a))) return t;
                    if (0 != (4 & n) && (n |= 16 & r), 0 !== (t = e.entangledLanes))
                        for (e = e.entanglements, t &= n; 0 < t;) i = 1 << (r = 31 - tf(t)), n |= e[r], t &= ~i;
                    return n
                }

                function ty(e) {
                    return 0 != (e = -1073741825 & e.pendingLanes) ? e : 1073741824 & e ? 1073741824 : 0
                }

                function tC(e) {
                    for (var t = [], r = 0; 31 > r; r++) t.push(e);
                    return t
                }

                function tB(e, t, r) {
                    e.pendingLanes |= t, 536870912 !== t && (e.suspendedLanes = 0, e.pingedLanes = 0), (e = e.eventTimes)[t = 31 - tf(t)] = r
                }

                function t_(e, t) {
                    var r = e.entangledLanes |= t;
                    for (e = e.entanglements; r;) {
                        var n = 31 - tf(r),
                            i = 1 << n;
                        i & t | e[n] & t && (e[n] |= t), r &= ~i
                    }
                }
                var tb = 0;

                function tE(e) {
                    return 1 < (e &= -e) ? 4 < e ? 0 != (268435455 & e) ? 16 : 536870912 : 4 : 1
                }
                var tw = u.unstable_scheduleCallback,
                    tM = u.unstable_cancelCallback,
                    tT = u.unstable_shouldYield,
                    tx = u.unstable_requestPaint,
                    tF = u.unstable_now,
                    tS = u.unstable_ImmediatePriority,
                    tR = u.unstable_UserBlockingPriority,
                    tO = u.unstable_NormalPriority,
                    tI = u.unstable_IdlePriority,
                    tD = null,
                    tP = null,
                    tL = "function" == typeof Object.is ? Object.is : function(e, t) {
                        return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
                    },
                    tH = null,
                    tU = !1,
                    tG = !1;

                function tk(e) {
                    null === tH ? tH = [e] : tH.push(e)
                }

                function tN() {
                    if (!tG && null !== tH) {
                        tG = !0;
                        var e = 0,
                            t = tb;
                        try {
                            var r = tH;
                            for (tb = 1; e < r.length; e++) {
                                var n = r[e];
                                do n = n(!0); while (null !== n)
                            }
                            tH = null, tU = !1
                        } catch (t) {
                            throw null !== tH && (tH = tH.slice(e + 1)), tw(tS, tN), t
                        } finally {
                            tb = t, tG = !1
                        }
                    }
                    return null
                }
                var tJ = f.ReactCurrentBatchConfig;

                function tz(e, t) {
                    if (tL(e, t)) return !0;
                    if ("object" != typeof e || null === e || "object" != typeof t || null === t) return !1;
                    var r = Object.keys(e),
                        n = Object.keys(t);
                    if (r.length !== n.length) return !1;
                    for (n = 0; n < r.length; n++) {
                        var i = r[n];
                        if (!e8.call(t, i) || !tL(e[i], t[i])) return !1
                    }
                    return !0
                }

                function tj(e, t) {
                    if (e && e.defaultProps)
                        for (var r in t = c({}, t), e = e.defaultProps) void 0 === t[r] && (t[r] = e[r]);
                    return t
                }
                var tK = e5(null),
                    tQ = null,
                    tV = null,
                    tY = null;

                function tX() {
                    tY = tV = tQ = null
                }

                function tW(e, t, r) {
                    X ? (te(tK, t._currentValue), t._currentValue = r) : (te(tK, t._currentValue2), t._currentValue2 = r)
                }

                function tZ(e) {
                    var t = tK.current;
                    e7(tK), X ? e._currentValue = t : e._currentValue2 = t
                }

                function tq(e, t, r) {
                    for (; null !== e;) {
                        var n = e.alternate;
                        if ((e.childLanes & t) !== t ? (e.childLanes |= t, null !== n && (n.childLanes |= t)) : null !== n && (n.childLanes & t) !== t && (n.childLanes |= t), e === r) break;
                        e = e.return
                    }
                }

                function t$(e, t) {
                    tQ = e, tY = tV = null, null !== (e = e.dependencies) && null !== e.firstContext && (0 != (e.lanes & t) && (n0 = !0), e.firstContext = null)
                }

                function t0(e) {
                    var t = X ? e._currentValue : e._currentValue2;
                    if (tY !== e) {
                        if (e = {
                                context: e,
                                memoizedValue: t,
                                next: null
                            }, null === tV) {
                            if (null === tQ) throw Error(d(308));
                            tV = e, tQ.dependencies = {
                                lanes: 0,
                                firstContext: e
                            }
                        } else tV = tV.next = e
                    }
                    return t
                }
                var t1 = null,
                    t2 = !1;

                function t9(e) {
                    e.updateQueue = {
                        baseState: e.memoizedState,
                        firstBaseUpdate: null,
                        lastBaseUpdate: null,
                        shared: {
                            pending: null,
                            interleaved: null,
                            lanes: 0
                        },
                        effects: null
                    }
                }

                function t3(e, t) {
                    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
                        baseState: e.baseState,
                        firstBaseUpdate: e.firstBaseUpdate,
                        lastBaseUpdate: e.lastBaseUpdate,
                        shared: e.shared,
                        effects: e.effects
                    })
                }

                function t8(e, t) {
                    return {
                        eventTime: e,
                        lane: t,
                        tag: 0,
                        payload: null,
                        callback: null,
                        next: null
                    }
                }

                function t4(e, t) {
                    var r = e.updateQueue;
                    null !== r && (r = r.shared, null !== iW && 0 != (1 & e.mode) && 0 == (2 & iX) ? (null === (e = r.interleaved) ? (t.next = t, null === t1 ? t1 = [r] : t1.push(r)) : (t.next = e.next, e.next = t), r.interleaved = t) : (null === (e = r.pending) ? t.next = t : (t.next = e.next, e.next = t), r.pending = t))
                }

                function t6(e, t, r) {
                    if (null !== (t = t.updateQueue) && (t = t.shared, 0 != (4194240 & r))) {
                        var n = t.lanes;
                        n &= e.pendingLanes, r |= n, t.lanes = r, t_(e, r)
                    }
                }

                function t5(e, t) {
                    var r = e.updateQueue,
                        n = e.alternate;
                    if (null !== n && r === (n = n.updateQueue)) {
                        var i = null,
                            a = null;
                        if (null !== (r = r.firstBaseUpdate)) {
                            do {
                                var o = {
                                    eventTime: r.eventTime,
                                    lane: r.lane,
                                    tag: r.tag,
                                    payload: r.payload,
                                    callback: r.callback,
                                    next: null
                                };
                                null === a ? i = a = o : a = a.next = o, r = r.next
                            } while (null !== r);
                            null === a ? i = a = t : a = a.next = t
                        } else i = a = t;
                        r = {
                            baseState: n.baseState,
                            firstBaseUpdate: i,
                            lastBaseUpdate: a,
                            shared: n.shared,
                            effects: n.effects
                        }, e.updateQueue = r;
                        return
                    }
                    null === (e = r.lastBaseUpdate) ? r.firstBaseUpdate = t : e.next = t, r.lastBaseUpdate = t
                }

                function t7(e, t, r, n) {
                    var i = e.updateQueue;
                    t2 = !1;
                    var a = i.firstBaseUpdate,
                        o = i.lastBaseUpdate,
                        s = i.shared.pending;
                    if (null !== s) {
                        i.shared.pending = null;
                        var l = s,
                            u = l.next;
                        l.next = null, null === o ? a = u : o.next = u, o = l;
                        var d = e.alternate;
                        null !== d && (s = (d = d.updateQueue).lastBaseUpdate) !== o && (null === s ? d.firstBaseUpdate = u : s.next = u, d.lastBaseUpdate = l)
                    }
                    if (null !== a) {
                        var f = i.baseState;
                        for (o = 0, d = u = l = null, s = a;;) {
                            var h = s.lane,
                                p = s.eventTime;
                            if ((n & h) === h) {
                                null !== d && (d = d.next = {
                                    eventTime: p,
                                    lane: 0,
                                    tag: s.tag,
                                    payload: s.payload,
                                    callback: s.callback,
                                    next: null
                                });
                                e: {
                                    var m = e,
                                        g = s;
                                    switch (h = t, p = r, g.tag) {
                                        case 1:
                                            if ("function" == typeof(m = g.payload)) {
                                                f = m.call(p, f, h);
                                                break e
                                            }
                                            f = m;
                                            break e;
                                        case 3:
                                            m.flags = -65537 & m.flags | 128;
                                        case 0:
                                            if (null == (h = "function" == typeof(m = g.payload) ? m.call(p, f, h) : m)) break e;
                                            f = c({}, f, h);
                                            break e;
                                        case 2:
                                            t2 = !0
                                    }
                                }
                                null !== s.callback && 0 !== s.lane && (e.flags |= 64, null === (h = i.effects) ? i.effects = [s] : h.push(s))
                            } else p = {
                                eventTime: p,
                                lane: h,
                                tag: s.tag,
                                payload: s.payload,
                                callback: s.callback,
                                next: null
                            }, null === d ? (u = d = p, l = f) : d = d.next = p, o |= h;
                            if (null === (s = s.next)) {
                                if (null === (s = i.shared.pending)) break;
                                s = (h = s).next, h.next = null, i.lastBaseUpdate = h, i.shared.pending = null
                            }
                        }
                        if (null === d && (l = f), i.baseState = l, i.firstBaseUpdate = u, i.lastBaseUpdate = d, null !== (t = i.shared.interleaved)) {
                            i = t;
                            do o |= i.lane, i = i.next; while (i !== t)
                        } else null === a && (i.shared.lanes = 0);
                        i9 |= o, e.lanes = o, e.memoizedState = f
                    }
                }

                function re(e, t, r) {
                    if (e = t.effects, t.effects = null, null !== e)
                        for (t = 0; t < e.length; t++) {
                            var n = e[t],
                                i = n.callback;
                            if (null !== i) {
                                if (n.callback = null, n = r, "function" != typeof i) throw Error(d(191, i));
                                i.call(n)
                            }
                        }
                }
                var rt = (new l.Component).refs;

                function rr(e, t, r, n) {
                    r = null == (r = r(n, t = e.memoizedState)) ? t : c({}, t, r), e.memoizedState = r, 0 === e.lanes && (e.updateQueue.baseState = r)
                }
                var rn = {
                    isMounted: function(e) {
                        return !!(e = e._reactInternals) && F(e) === e
                    },
                    enqueueSetState: function(e, t, r) {
                        e = e._reactInternals;
                        var n = ad(),
                            i = af(e),
                            a = t8(n, i);
                        a.payload = t, null != r && (a.callback = r), t4(e, a), null !== (t = ah(e, i, n)) && t6(t, e, i)
                    },
                    enqueueReplaceState: function(e, t, r) {
                        e = e._reactInternals;
                        var n = ad(),
                            i = af(e),
                            a = t8(n, i);
                        a.tag = 1, a.payload = t, null != r && (a.callback = r), t4(e, a), null !== (t = ah(e, i, n)) && t6(t, e, i)
                    },
                    enqueueForceUpdate: function(e, t) {
                        e = e._reactInternals;
                        var r = ad(),
                            n = af(e),
                            i = t8(r, n);
                        i.tag = 2, null != t && (i.callback = t), t4(e, i), null !== (t = ah(e, n, r)) && t6(t, e, n)
                    }
                };

                function ri(e, t, r, n, i, a, o) {
                    return "function" == typeof(e = e.stateNode).shouldComponentUpdate ? e.shouldComponentUpdate(n, a, o) : !t.prototype || !t.prototype.isPureReactComponent || !tz(r, n) || !tz(i, a)
                }

                function ra(e, t, r) {
                    var n = !1,
                        i = tt,
                        a = t.contextType;
                    return "object" == typeof a && null !== a ? a = t0(a) : (i = to(t) ? ti : tr.current, a = (n = null != (n = t.contextTypes)) ? ta(e, i) : tt), t = new t(r, a), e.memoizedState = null !== t.state && void 0 !== t.state ? t.state : null, t.updater = rn, e.stateNode = t, t._reactInternals = e, n && ((e = e.stateNode).__reactInternalMemoizedUnmaskedChildContext = i, e.__reactInternalMemoizedMaskedChildContext = a), t
                }

                function ro(e, t, r, n) {
                    e = t.state, "function" == typeof t.componentWillReceiveProps && t.componentWillReceiveProps(r, n), "function" == typeof t.UNSAFE_componentWillReceiveProps && t.UNSAFE_componentWillReceiveProps(r, n), t.state !== e && rn.enqueueReplaceState(t, t.state, null)
                }

                function rs(e, t, r, n) {
                    var i = e.stateNode;
                    i.props = r, i.state = e.memoizedState, i.refs = rt, t9(e);
                    var a = t.contextType;
                    "object" == typeof a && null !== a ? i.context = t0(a) : (a = to(t) ? ti : tr.current, i.context = ta(e, a)), i.state = e.memoizedState, "function" == typeof(a = t.getDerivedStateFromProps) && (rr(e, t, a, r), i.state = e.memoizedState), "function" == typeof t.getDerivedStateFromProps || "function" == typeof i.getSnapshotBeforeUpdate || "function" != typeof i.UNSAFE_componentWillMount && "function" != typeof i.componentWillMount || (t = i.state, "function" == typeof i.componentWillMount && i.componentWillMount(), "function" == typeof i.UNSAFE_componentWillMount && i.UNSAFE_componentWillMount(), t !== i.state && rn.enqueueReplaceState(i, i.state, null), t7(e, r, i, n), i.state = e.memoizedState), "function" == typeof i.componentDidMount && (e.flags |= 4194308)
                }
                var rl = [],
                    ru = 0,
                    rc = null,
                    rd = 0,
                    rf = [],
                    rh = 0,
                    rp = null,
                    rm = 1,
                    rg = "";

                function rA(e, t) {
                    rl[ru++] = rd, rl[ru++] = rc, rc = e, rd = t
                }

                function rv(e, t, r) {
                    rf[rh++] = rm, rf[rh++] = rg, rf[rh++] = rp, rp = e;
                    var n = rm;
                    e = rg;
                    var i = 32 - tf(n) - 1;
                    n &= ~(1 << i), r += 1;
                    var a = 32 - tf(t) + i;
                    if (30 < a) {
                        var o = i - i % 5;
                        a = (n & (1 << o) - 1).toString(32), n >>= o, i -= o, rm = 1 << 32 - tf(t) + i | r << i | n, rg = a + e
                    } else rm = 1 << a | r << i | n, rg = e
                }

                function ry(e) {
                    null !== e.return && (rA(e, 1), rv(e, 1, 0))
                }

                function rC(e) {
                    for (; e === rc;) rc = rl[--ru], rl[ru] = null, rd = rl[--ru], rl[ru] = null;
                    for (; e === rp;) rp = rf[--rh], rf[rh] = null, rg = rf[--rh], rf[rh] = null, rm = rf[--rh], rf[rh] = null
                }
                var rB = null,
                    r_ = null,
                    rb = !1,
                    rE = !1,
                    rw = null;

                function rM(e, t) {
                    var r = aG(5, null, null, 0);
                    r.elementType = "DELETED", r.stateNode = t, r.return = e, null === (t = e.deletions) ? (e.deletions = [r], e.flags |= 16) : t.push(r)
                }

                function rT(e, t) {
                    switch (e.tag) {
                        case 5:
                            return null !== (t = eP(t, e.type, e.pendingProps)) && (e.stateNode = t, rB = e, r_ = eJ(t), !0);
                        case 6:
                            return null !== (t = eL(t, e.pendingProps)) && (e.stateNode = t, rB = e, r_ = null, !0);
                        case 13:
                            if (null !== (t = eH(t))) {
                                var r = null !== rp ? {
                                    id: rm,
                                    overflow: rg
                                } : null;
                                return e.memoizedState = {
                                    dehydrated: t,
                                    treeContext: r,
                                    retryLane: 1073741824
                                }, (r = aG(18, null, null, 0)).stateNode = t, r.return = e, e.child = r, rB = e, r_ = null, !0
                            }
                            return !1;
                        default:
                            return !1
                    }
                }

                function rx(e) {
                    return 0 != (1 & e.mode) && 0 == (128 & e.flags)
                }

                function rF(e) {
                    if (rb) {
                        var t = r_;
                        if (t) {
                            var r = t;
                            if (!rT(e, t)) {
                                if (rx(e)) throw Error(d(418));
                                t = eN(r);
                                var n = rB;
                                t && rT(e, t) ? rM(n, r) : (e.flags = -4097 & e.flags | 2, rb = !1, rB = e)
                            }
                        } else {
                            if (rx(e)) throw Error(d(418));
                            e.flags = -4097 & e.flags | 2, rb = !1, rB = e
                        }
                    }
                }

                function rS(e) {
                    for (e = e.return; null !== e && 5 !== e.tag && 3 !== e.tag && 13 !== e.tag;) e = e.return;
                    rB = e
                }

                function rR(e) {
                    if (!q || e !== rB) return !1;
                    if (!rb) return rS(e), rb = !0, !1;
                    if (3 !== e.tag && (5 !== e.tag || e$(e.type) && !j(e.type, e.memoizedProps))) {
                        var t = r_;
                        if (t) {
                            if (rx(e)) {
                                for (e = r_; e;) e = eN(e);
                                throw Error(d(418))
                            }
                            for (; t;) rM(e, t), t = eN(t)
                        }
                    }
                    if (rS(e), 13 === e.tag) {
                        if (!q) throw Error(d(316));
                        if (!(e = null !== (e = e.memoizedState) ? e.dehydrated : null)) throw Error(d(317));
                        r_ = eY(e)
                    } else r_ = rB ? eN(e.stateNode) : null;
                    return !0
                }

                function rO() {
                    q && (r_ = rB = null, rE = rb = !1)
                }

                function rI(e) {
                    null === rw ? rw = [e] : rw.push(e)
                }

                function rD(e, t, r) {
                    if (null !== (e = r.ref) && "function" != typeof e && "object" != typeof e) {
                        if (r._owner) {
                            if (r = r._owner) {
                                if (1 !== r.tag) throw Error(d(309));
                                var n = r.stateNode
                            }
                            if (!n) throw Error(d(147, e));
                            var i = n,
                                a = "" + e;
                            return null !== t && null !== t.ref && "function" == typeof t.ref && t.ref._stringRef === a ? t.ref : ((t = function(e) {
                                var t = i.refs;
                                t === rt && (t = i.refs = {}), null === e ? delete t[a] : t[a] = e
                            })._stringRef = a, t)
                        }
                        if ("string" != typeof e) throw Error(d(284));
                        if (!r._owner) throw Error(d(290, e))
                    }
                    return e
                }

                function rP(e, t) {
                    throw Error(d(31, "[object Object]" === (e = Object.prototype.toString.call(t)) ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
                }

                function rL(e) {
                    return (0, e._init)(e._payload)
                }

                function rH(e) {
                    function t(t, r) {
                        if (e) {
                            var n = t.deletions;
                            null === n ? (t.deletions = [r], t.flags |= 16) : n.push(r)
                        }
                    }

                    function r(r, n) {
                        if (!e) return null;
                        for (; null !== n;) t(r, n), n = n.sibling;
                        return null
                    }

                    function n(e, t) {
                        for (e = new Map; null !== t;) null !== t.key ? e.set(t.key, t) : e.set(t.index, t), t = t.sibling;
                        return e
                    }

                    function i(e, t) {
                        return (e = aN(e, t)).index = 0, e.sibling = null, e
                    }

                    function a(t, r, n) {
                        return (t.index = n, e) ? null !== (n = t.alternate) ? (n = n.index) < r ? (t.flags |= 2, r) : n : (t.flags |= 2, r) : (t.flags |= 1048576, r)
                    }

                    function o(t) {
                        return e && null === t.alternate && (t.flags |= 2), t
                    }

                    function s(e, t, r, n) {
                        return null === t || 6 !== t.tag ? (t = aK(r, e.mode, n)).return = e : (t = i(t, r)).return = e, t
                    }

                    function l(e, t, r, n) {
                        var a = r.type;
                        return a === m ? c(e, t, r.props.children, n, r.key) : (null !== t && (t.elementType === a || "object" == typeof a && null !== a && a.$$typeof === E && rL(a) === t.type) ? (n = i(t, r.props)).ref = rD(e, t, r) : (n = aJ(r.type, r.key, r.props, null, e.mode, n)).ref = rD(e, t, r), n.return = e, n)
                    }

                    function u(e, t, r, n) {
                        return null === t || 4 !== t.tag || t.stateNode.containerInfo !== r.containerInfo || t.stateNode.implementation !== r.implementation ? (t = aQ(r, e.mode, n)).return = e : (t = i(t, r.children || [])).return = e, t
                    }

                    function c(e, t, r, n, a) {
                        return null === t || 7 !== t.tag ? (t = az(r, e.mode, n, a)).return = e : (t = i(t, r)).return = e, t
                    }

                    function f(e, t, r) {
                        if ("string" == typeof t && "" !== t || "number" == typeof t) return (t = aK("" + t, e.mode, r)).return = e, t;
                        if ("object" == typeof t && null !== t) {
                            switch (t.$$typeof) {
                                case h:
                                    return (r = aJ(t.type, t.key, t.props, null, e.mode, r)).ref = rD(e, null, t), r.return = e, r;
                                case p:
                                    return (t = aQ(t, e.mode, r)).return = e, t;
                                case E:
                                    return f(e, (0, t._init)(t._payload), r)
                            }
                            if (D(t) || T(t)) return (t = az(t, e.mode, r, null)).return = e, t;
                            rP(e, t)
                        }
                        return null
                    }

                    function g(e, t, r, n) {
                        var i = null !== t ? t.key : null;
                        if ("string" == typeof r && "" !== r || "number" == typeof r) return null !== i ? null : s(e, t, "" + r, n);
                        if ("object" == typeof r && null !== r) {
                            switch (r.$$typeof) {
                                case h:
                                    return r.key === i ? l(e, t, r, n) : null;
                                case p:
                                    return r.key === i ? u(e, t, r, n) : null;
                                case E:
                                    return g(e, t, (i = r._init)(r._payload), n)
                            }
                            if (D(r) || T(r)) return null !== i ? null : c(e, t, r, n, null);
                            rP(e, r)
                        }
                        return null
                    }

                    function A(e, t, r, n, i) {
                        if ("string" == typeof n && "" !== n || "number" == typeof n) return s(t, e = e.get(r) || null, "" + n, i);
                        if ("object" == typeof n && null !== n) {
                            switch (n.$$typeof) {
                                case h:
                                    return l(t, e = e.get(null === n.key ? r : n.key) || null, n, i);
                                case p:
                                    return u(t, e = e.get(null === n.key ? r : n.key) || null, n, i);
                                case E:
                                    return A(e, t, r, (0, n._init)(n._payload), i)
                            }
                            if (D(n) || T(n)) return c(t, e = e.get(r) || null, n, i, null);
                            rP(t, n)
                        }
                        return null
                    }
                    return function s(l, u, c, v) {
                        if ("object" == typeof c && null !== c && c.type === m && null === c.key && (c = c.props.children), "object" == typeof c && null !== c) {
                            switch (c.$$typeof) {
                                case h:
                                    e: {
                                        for (var y = c.key, C = u; null !== C;) {
                                            if (C.key === y) {
                                                if ((y = c.type) === m) {
                                                    if (7 === C.tag) {
                                                        r(l, C.sibling), (u = i(C, c.props.children)).return = l, l = u;
                                                        break e
                                                    }
                                                } else if (C.elementType === y || "object" == typeof y && null !== y && y.$$typeof === E && rL(y) === C.type) {
                                                    r(l, C.sibling), (u = i(C, c.props)).ref = rD(l, C, c), u.return = l, l = u;
                                                    break e
                                                }
                                                r(l, C);
                                                break
                                            }
                                            t(l, C), C = C.sibling
                                        }
                                        c.type === m ? ((u = az(c.props.children, l.mode, v, c.key)).return = l, l = u) : ((v = aJ(c.type, c.key, c.props, null, l.mode, v)).ref = rD(l, u, c), v.return = l, l = v)
                                    }
                                    return o(l);
                                case p:
                                    e: {
                                        for (C = c.key; null !== u;) {
                                            if (u.key === C) {
                                                if (4 === u.tag && u.stateNode.containerInfo === c.containerInfo && u.stateNode.implementation === c.implementation) {
                                                    r(l, u.sibling), (u = i(u, c.children || [])).return = l, l = u;
                                                    break e
                                                }
                                                r(l, u);
                                                break
                                            }
                                            t(l, u), u = u.sibling
                                        }(u = aQ(c, l.mode, v)).return = l,
                                        l = u
                                    }
                                    return o(l);
                                case E:
                                    return s(l, u, (C = c._init)(c._payload), v)
                            }
                            if (D(c)) return function(i, o, s, l) {
                                for (var u = null, c = null, d = o, h = o = 0, p = null; null !== d && h < s.length; h++) {
                                    d.index > h ? (p = d, d = null) : p = d.sibling;
                                    var m = g(i, d, s[h], l);
                                    if (null === m) {
                                        null === d && (d = p);
                                        break
                                    }
                                    e && d && null === m.alternate && t(i, d), o = a(m, o, h), null === c ? u = m : c.sibling = m, c = m, d = p
                                }
                                if (h === s.length) return r(i, d), rb && rA(i, h), u;
                                if (null === d) {
                                    for (; h < s.length; h++) null !== (d = f(i, s[h], l)) && (o = a(d, o, h), null === c ? u = d : c.sibling = d, c = d);
                                    return rb && rA(i, h), u
                                }
                                for (d = n(i, d); h < s.length; h++) null !== (p = A(d, i, h, s[h], l)) && (e && null !== p.alternate && d.delete(null === p.key ? h : p.key), o = a(p, o, h), null === c ? u = p : c.sibling = p, c = p);
                                return e && d.forEach(function(e) {
                                    return t(i, e)
                                }), rb && rA(i, h), u
                            }(l, u, c, v);
                            if (T(c)) return function(i, o, s, l) {
                                var u = T(s);
                                if ("function" != typeof u) throw Error(d(150));
                                if (null == (s = u.call(s))) throw Error(d(151));
                                for (var c = u = null, h = o, p = o = 0, m = null, v = s.next(); null !== h && !v.done; p++, v = s.next()) {
                                    h.index > p ? (m = h, h = null) : m = h.sibling;
                                    var y = g(i, h, v.value, l);
                                    if (null === y) {
                                        null === h && (h = m);
                                        break
                                    }
                                    e && h && null === y.alternate && t(i, h), o = a(y, o, p), null === c ? u = y : c.sibling = y, c = y, h = m
                                }
                                if (v.done) return r(i, h), rb && rA(i, p), u;
                                if (null === h) {
                                    for (; !v.done; p++, v = s.next()) null !== (v = f(i, v.value, l)) && (o = a(v, o, p), null === c ? u = v : c.sibling = v, c = v);
                                    return rb && rA(i, p), u
                                }
                                for (h = n(i, h); !v.done; p++, v = s.next()) null !== (v = A(h, i, p, v.value, l)) && (e && null !== v.alternate && h.delete(null === v.key ? p : v.key), o = a(v, o, p), null === c ? u = v : c.sibling = v, c = v);
                                return e && h.forEach(function(e) {
                                    return t(i, e)
                                }), rb && rA(i, p), u
                            }(l, u, c, v);
                            rP(l, c)
                        }
                        return "string" == typeof c && "" !== c || "number" == typeof c ? (c = "" + c, null !== u && 6 === u.tag ? (r(l, u.sibling), (u = i(u, c)).return = l) : (r(l, u), (u = aK(c, l.mode, v)).return = l), o(l = u)) : r(l, u)
                    }
                }
                var rU = rH(!0),
                    rG = rH(!1),
                    rk = {},
                    rN = e5(rk),
                    rJ = e5(rk),
                    rz = e5(rk);

                function rj(e) {
                    if (e === rk) throw Error(d(174));
                    return e
                }

                function rK(e, t) {
                    te(rz, t), te(rJ, e), te(rN, rk), e = L(t), e7(rN), te(rN, e)
                }

                function rQ() {
                    e7(rN), e7(rJ), e7(rz)
                }

                function rV(e) {
                    var t = rj(rz.current),
                        r = rj(rN.current);
                    t = H(r, e.type, t), r !== t && (te(rJ, e), te(rN, t))
                }

                function rY(e) {
                    rJ.current === e && (e7(rN), e7(rJ))
                }
                var rX = e5(0);

                function rW(e) {
                    for (var t = e; null !== t;) {
                        if (13 === t.tag) {
                            var r = t.memoizedState;
                            if (null !== r && (null === (r = r.dehydrated) || eU(r) || eG(r))) return t
                        } else if (19 === t.tag && void 0 !== t.memoizedProps.revealOrder) {
                            if (0 != (128 & t.flags)) return t
                        } else if (null !== t.child) {
                            t.child.return = t, t = t.child;
                            continue
                        }
                        if (t === e) break;
                        for (; null === t.sibling;) {
                            if (null === t.return || t.return === e) return null;
                            t = t.return
                        }
                        t.sibling.return = t.return, t = t.sibling
                    }
                    return null
                }
                var rZ = [];

                function rq() {
                    for (var e = 0; e < rZ.length; e++) {
                        var t = rZ[e];
                        X ? t._workInProgressVersionPrimary = null : t._workInProgressVersionSecondary = null
                    }
                    rZ.length = 0
                }
                var r$ = f.ReactCurrentDispatcher,
                    r0 = f.ReactCurrentBatchConfig,
                    r1 = 0,
                    r2 = null,
                    r9 = null,
                    r3 = null,
                    r8 = !1,
                    r4 = !1,
                    r6 = 0,
                    r5 = 0;

                function r7() {
                    throw Error(d(321))
                }

                function ne(e, t) {
                    if (null === t) return !1;
                    for (var r = 0; r < t.length && r < e.length; r++)
                        if (!tL(e[r], t[r])) return !1;
                    return !0
                }

                function nt(e, t, r, n, i, a) {
                    if (r1 = a, r2 = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, r$.current = null === e || null === e.memoizedState ? nH : nU, e = r(n, i), r4) {
                        a = 0;
                        do {
                            if (r4 = !1, r6 = 0, 25 <= a) throw Error(d(301));
                            a += 1, r3 = r9 = null, t.updateQueue = null, r$.current = nG, e = r(n, i)
                        } while (r4)
                    }
                    if (r$.current = nL, t = null !== r9 && null !== r9.next, r1 = 0, r3 = r9 = r2 = null, r8 = !1, t) throw Error(d(300));
                    return e
                }

                function nr() {
                    var e = 0 !== r6;
                    return r6 = 0, e
                }

                function nn() {
                    var e = {
                        memoizedState: null,
                        baseState: null,
                        baseQueue: null,
                        queue: null,
                        next: null
                    };
                    return null === r3 ? r2.memoizedState = r3 = e : r3 = r3.next = e, r3
                }

                function ni() {
                    if (null === r9) {
                        var e = r2.alternate;
                        e = null !== e ? e.memoizedState : null
                    } else e = r9.next;
                    var t = null === r3 ? r2.memoizedState : r3.next;
                    if (null !== t) r3 = t, r9 = e;
                    else {
                        if (null === e) throw Error(d(310));
                        e = {
                            memoizedState: (r9 = e).memoizedState,
                            baseState: r9.baseState,
                            baseQueue: r9.baseQueue,
                            queue: r9.queue,
                            next: null
                        }, null === r3 ? r2.memoizedState = r3 = e : r3 = r3.next = e
                    }
                    return r3
                }

                function na(e, t) {
                    return "function" == typeof t ? t(e) : t
                }

                function no(e) {
                    var t = ni(),
                        r = t.queue;
                    if (null === r) throw Error(d(311));
                    r.lastRenderedReducer = e;
                    var n = r9,
                        i = n.baseQueue,
                        a = r.pending;
                    if (null !== a) {
                        if (null !== i) {
                            var o = i.next;
                            i.next = a.next, a.next = o
                        }
                        n.baseQueue = i = a, r.pending = null
                    }
                    if (null !== i) {
                        a = i.next, n = n.baseState;
                        var s = o = null,
                            l = null,
                            u = a;
                        do {
                            var c = u.lane;
                            if ((r1 & c) === c) null !== l && (l = l.next = {
                                lane: 0,
                                action: u.action,
                                hasEagerState: u.hasEagerState,
                                eagerState: u.eagerState,
                                next: null
                            }), n = u.hasEagerState ? u.eagerState : e(n, u.action);
                            else {
                                var f = {
                                    lane: c,
                                    action: u.action,
                                    hasEagerState: u.hasEagerState,
                                    eagerState: u.eagerState,
                                    next: null
                                };
                                null === l ? (s = l = f, o = n) : l = l.next = f, r2.lanes |= c, i9 |= c
                            }
                            u = u.next
                        } while (null !== u && u !== a);
                        null === l ? o = n : l.next = s, tL(n, t.memoizedState) || (n0 = !0), t.memoizedState = n, t.baseState = o, t.baseQueue = l, r.lastRenderedState = n
                    }
                    if (null !== (e = r.interleaved)) {
                        i = e;
                        do a = i.lane, r2.lanes |= a, i9 |= a, i = i.next; while (i !== e)
                    } else null === i && (r.lanes = 0);
                    return [t.memoizedState, r.dispatch]
                }

                function ns(e) {
                    var t = ni(),
                        r = t.queue;
                    if (null === r) throw Error(d(311));
                    r.lastRenderedReducer = e;
                    var n = r.dispatch,
                        i = r.pending,
                        a = t.memoizedState;
                    if (null !== i) {
                        r.pending = null;
                        var o = i = i.next;
                        do a = e(a, o.action), o = o.next; while (o !== i);
                        tL(a, t.memoizedState) || (n0 = !0), t.memoizedState = a, null === t.baseQueue && (t.baseState = a), r.lastRenderedState = a
                    }
                    return [a, n]
                }

                function nl() {}

                function nu(e, t) {
                    var r = r2,
                        n = ni(),
                        i = t(),
                        a = !tL(n.memoizedState, i);
                    if (a && (n.memoizedState = i, n0 = !0), n = n.queue, nC(nf.bind(null, r, n, e), [e]), n.getSnapshot !== t || a || null !== r3 && 1 & r3.memoizedState.tag) {
                        if (r.flags |= 2048, nm(9, nd.bind(null, r, n, i, t), void 0, null), null === iW) throw Error(d(349));
                        0 != (30 & r1) || nc(r, t, i)
                    }
                    return i
                }

                function nc(e, t, r) {
                    e.flags |= 16384, e = {
                        getSnapshot: t,
                        value: r
                    }, null === (t = r2.updateQueue) ? (t = {
                        lastEffect: null,
                        stores: null
                    }, r2.updateQueue = t, t.stores = [e]) : null === (r = t.stores) ? t.stores = [e] : r.push(e)
                }

                function nd(e, t, r, n) {
                    t.value = r, t.getSnapshot = n, nh(t) && ah(e, 1, -1)
                }

                function nf(e, t, r) {
                    return r(function() {
                        nh(t) && ah(e, 1, -1)
                    })
                }

                function nh(e) {
                    var t = e.getSnapshot;
                    e = e.value;
                    try {
                        var r = t();
                        return !tL(e, r)
                    } catch (e) {
                        return !0
                    }
                }

                function np(e) {
                    var t = nn();
                    return "function" == typeof e && (e = e()), t.memoizedState = t.baseState = e, e = {
                        pending: null,
                        interleaved: null,
                        lanes: 0,
                        dispatch: null,
                        lastRenderedReducer: na,
                        lastRenderedState: e
                    }, t.queue = e, e = e.dispatch = nR.bind(null, r2, e), [t.memoizedState, e]
                }

                function nm(e, t, r, n) {
                    return e = {
                        tag: e,
                        create: t,
                        destroy: r,
                        deps: n,
                        next: null
                    }, null === (t = r2.updateQueue) ? (t = {
                        lastEffect: null,
                        stores: null
                    }, r2.updateQueue = t, t.lastEffect = e.next = e) : null === (r = t.lastEffect) ? t.lastEffect = e.next = e : (n = r.next, r.next = e, e.next = n, t.lastEffect = e), e
                }

                function ng() {
                    return ni().memoizedState
                }

                function nA(e, t, r, n) {
                    var i = nn();
                    r2.flags |= e, i.memoizedState = nm(1 | t, r, void 0, void 0 === n ? null : n)
                }

                function nv(e, t, r, n) {
                    var i = ni();
                    n = void 0 === n ? null : n;
                    var a = void 0;
                    if (null !== r9) {
                        var o = r9.memoizedState;
                        if (a = o.destroy, null !== n && ne(n, o.deps)) {
                            i.memoizedState = nm(t, r, a, n);
                            return
                        }
                    }
                    r2.flags |= e, i.memoizedState = nm(1 | t, r, a, n)
                }

                function ny(e, t) {
                    return nA(8390656, 8, e, t)
                }

                function nC(e, t) {
                    return nv(2048, 8, e, t)
                }

                function nB(e, t) {
                    return nv(4, 2, e, t)
                }

                function n_(e, t) {
                    return nv(4, 4, e, t)
                }

                function nb(e, t) {
                    return "function" == typeof t ? (t(e = e()), function() {
                        t(null)
                    }) : null != t ? (e = e(), t.current = e, function() {
                        t.current = null
                    }) : void 0
                }

                function nE(e, t, r) {
                    return r = null != r ? r.concat([e]) : null, nv(4, 4, nb.bind(null, t, e), r)
                }

                function nw() {}

                function nM(e, t) {
                    var r = ni();
                    t = void 0 === t ? null : t;
                    var n = r.memoizedState;
                    return null !== n && null !== t && ne(t, n[1]) ? n[0] : (r.memoizedState = [e, t], e)
                }

                function nT(e, t) {
                    var r = ni();
                    t = void 0 === t ? null : t;
                    var n = r.memoizedState;
                    return null !== n && null !== t && ne(t, n[1]) ? n[0] : (e = e(), r.memoizedState = [e, t], e)
                }

                function nx(e, t) {
                    var r = tb;
                    tb = 0 !== r && 4 > r ? r : 4, e(!0);
                    var n = r0.transition;
                    r0.transition = {};
                    try {
                        e(!1), t()
                    } finally {
                        tb = r, r0.transition = n
                    }
                }

                function nF() {
                    return ni().memoizedState
                }

                function nS(e, t, r) {
                    var n = af(e);
                    r = {
                        lane: n,
                        action: r,
                        hasEagerState: !1,
                        eagerState: null,
                        next: null
                    }, nO(e) ? nI(t, r) : (nD(e, t, r), null !== (e = ah(e, n, r = ad())) && nP(e, t, n))
                }

                function nR(e, t, r) {
                    var n = af(e),
                        i = {
                            lane: n,
                            action: r,
                            hasEagerState: !1,
                            eagerState: null,
                            next: null
                        };
                    if (nO(e)) nI(t, i);
                    else {
                        nD(e, t, i);
                        var a = e.alternate;
                        if (0 === e.lanes && (null === a || 0 === a.lanes) && null !== (a = t.lastRenderedReducer)) try {
                            var o = t.lastRenderedState,
                                s = a(o, r);
                            if (i.hasEagerState = !0, i.eagerState = s, tL(s, o)) return
                        } catch (e) {} finally {}
                        null !== (e = ah(e, n, r = ad())) && nP(e, t, n)
                    }
                }

                function nO(e) {
                    var t = e.alternate;
                    return e === r2 || null !== t && t === r2
                }

                function nI(e, t) {
                    r4 = r8 = !0;
                    var r = e.pending;
                    null === r ? t.next = t : (t.next = r.next, r.next = t), e.pending = t
                }

                function nD(e, t, r) {
                    null !== iW && 0 != (1 & e.mode) && 0 == (2 & iX) ? (null === (e = t.interleaved) ? (r.next = r, null === t1 ? t1 = [t] : t1.push(t)) : (r.next = e.next, e.next = r), t.interleaved = r) : (null === (e = t.pending) ? r.next = r : (r.next = e.next, e.next = r), t.pending = r)
                }

                function nP(e, t, r) {
                    if (0 != (4194240 & r)) {
                        var n = t.lanes;
                        n &= e.pendingLanes, r |= n, t.lanes = r, t_(e, r)
                    }
                }
                var nL = {
                        readContext: t0,
                        useCallback: r7,
                        useContext: r7,
                        useEffect: r7,
                        useImperativeHandle: r7,
                        useInsertionEffect: r7,
                        useLayoutEffect: r7,
                        useMemo: r7,
                        useReducer: r7,
                        useRef: r7,
                        useState: r7,
                        useDebugValue: r7,
                        useDeferredValue: r7,
                        useTransition: r7,
                        useMutableSource: r7,
                        useSyncExternalStore: r7,
                        useId: r7,
                        unstable_isNewReconciler: !1
                    },
                    nH = {
                        readContext: t0,
                        useCallback: function(e, t) {
                            return nn().memoizedState = [e, void 0 === t ? null : t], e
                        },
                        useContext: t0,
                        useEffect: ny,
                        useImperativeHandle: function(e, t, r) {
                            return r = null != r ? r.concat([e]) : null, nA(4194308, 4, nb.bind(null, t, e), r)
                        },
                        useLayoutEffect: function(e, t) {
                            return nA(4194308, 4, e, t)
                        },
                        useInsertionEffect: function(e, t) {
                            return nA(4, 2, e, t)
                        },
                        useMemo: function(e, t) {
                            var r = nn();
                            return t = void 0 === t ? null : t, e = e(), r.memoizedState = [e, t], e
                        },
                        useReducer: function(e, t, r) {
                            var n = nn();
                            return t = void 0 !== r ? r(t) : t, n.memoizedState = n.baseState = t, e = {
                                pending: null,
                                interleaved: null,
                                lanes: 0,
                                dispatch: null,
                                lastRenderedReducer: e,
                                lastRenderedState: t
                            }, n.queue = e, e = e.dispatch = nS.bind(null, r2, e), [n.memoizedState, e]
                        },
                        useRef: function(e) {
                            return e = {
                                current: e
                            }, nn().memoizedState = e
                        },
                        useState: np,
                        useDebugValue: nw,
                        useDeferredValue: function(e) {
                            var t = np(e),
                                r = t[0],
                                n = t[1];
                            return ny(function() {
                                var t = r0.transition;
                                r0.transition = {};
                                try {
                                    n(e)
                                } finally {
                                    r0.transition = t
                                }
                            }, [e]), r
                        },
                        useTransition: function() {
                            var e = np(!1),
                                t = e[0];
                            return e = nx.bind(null, e[1]), nn().memoizedState = e, [t, e]
                        },
                        useMutableSource: function() {},
                        useSyncExternalStore: function(e, t, r) {
                            var n = r2,
                                i = nn();
                            if (rb) {
                                if (void 0 === r) throw Error(d(407));
                                r = r()
                            } else {
                                if (r = t(), null === iW) throw Error(d(349));
                                0 != (30 & r1) || nc(n, t, r)
                            }
                            i.memoizedState = r;
                            var a = {
                                value: r,
                                getSnapshot: t
                            };
                            return i.queue = a, ny(nf.bind(null, n, a, e), [e]), n.flags |= 2048, nm(9, nd.bind(null, n, a, r, t), void 0, null), r
                        },
                        useId: function() {
                            var e = nn(),
                                t = iW.identifierPrefix;
                            if (rb) {
                                var r = rg,
                                    n = rm;
                                t = ":" + t + "R" + (r = (n & ~(1 << 32 - tf(n) - 1)).toString(32) + r), 0 < (r = r6++) && (t += "H" + r.toString(32)), t += ":"
                            } else t = ":" + t + "r" + (r = r5++).toString(32) + ":";
                            return e.memoizedState = t
                        },
                        unstable_isNewReconciler: !1
                    },
                    nU = {
                        readContext: t0,
                        useCallback: nM,
                        useContext: t0,
                        useEffect: nC,
                        useImperativeHandle: nE,
                        useInsertionEffect: nB,
                        useLayoutEffect: n_,
                        useMemo: nT,
                        useReducer: no,
                        useRef: ng,
                        useState: function() {
                            return no(na)
                        },
                        useDebugValue: nw,
                        useDeferredValue: function(e) {
                            var t = no(na),
                                r = t[0],
                                n = t[1];
                            return nC(function() {
                                var t = r0.transition;
                                r0.transition = {};
                                try {
                                    n(e)
                                } finally {
                                    r0.transition = t
                                }
                            }, [e]), r
                        },
                        useTransition: function() {
                            return [no(na)[0], ni().memoizedState]
                        },
                        useMutableSource: nl,
                        useSyncExternalStore: nu,
                        useId: nF,
                        unstable_isNewReconciler: !1
                    },
                    nG = {
                        readContext: t0,
                        useCallback: nM,
                        useContext: t0,
                        useEffect: nC,
                        useImperativeHandle: nE,
                        useInsertionEffect: nB,
                        useLayoutEffect: n_,
                        useMemo: nT,
                        useReducer: ns,
                        useRef: ng,
                        useState: function() {
                            return ns(na)
                        },
                        useDebugValue: nw,
                        useDeferredValue: function(e) {
                            var t = ns(na),
                                r = t[0],
                                n = t[1];
                            return nC(function() {
                                var t = r0.transition;
                                r0.transition = {};
                                try {
                                    n(e)
                                } finally {
                                    r0.transition = t
                                }
                            }, [e]), r
                        },
                        useTransition: function() {
                            return [ns(na)[0], ni().memoizedState]
                        },
                        useMutableSource: nl,
                        useSyncExternalStore: nu,
                        useId: nF,
                        unstable_isNewReconciler: !1
                    };

                function nk(e, t) {
                    try {
                        var r = "",
                            n = t;
                        do r += function(e) {
                            switch (e.tag) {
                                case 5:
                                    return e2(e.type);
                                case 16:
                                    return e2("Lazy");
                                case 13:
                                    return e2("Suspense");
                                case 19:
                                    return e2("SuspenseList");
                                case 0:
                                case 2:
                                case 15:
                                    return e = e3(e.type, !1);
                                case 11:
                                    return e = e3(e.type.render, !1);
                                case 1:
                                    return e = e3(e.type, !0);
                                default:
                                    return ""
                            }
                        }(n), n = n.return; while (n);
                        var i = r
                    } catch (e) {
                        i = "\nError generating stack: " + e.message + "\n" + e.stack
                    }
                    return {
                        value: e,
                        source: t,
                        stack: i
                    }
                }

                function nN(e, t) {
                    try {
                        console.error(t.value)
                    } catch (e) {
                        setTimeout(function() {
                            throw e
                        })
                    }
                }
                var nJ = "function" == typeof WeakMap ? WeakMap : Map;

                function nz(e, t, r) {
                    (r = t8(-1, r)).tag = 3, r.payload = {
                        element: null
                    };
                    var n = t.value;
                    return r.callback = function() {
                        at || (at = !0, ar = n), nN(e, t)
                    }, r
                }

                function nj(e, t, r) {
                    (r = t8(-1, r)).tag = 3;
                    var n = e.type.getDerivedStateFromError;
                    if ("function" == typeof n) {
                        var i = t.value;
                        r.payload = function() {
                            return n(i)
                        }, r.callback = function() {
                            nN(e, t)
                        }
                    }
                    var a = e.stateNode;
                    return null !== a && "function" == typeof a.componentDidCatch && (r.callback = function() {
                        nN(e, t), "function" != typeof n && (null === an ? an = new Set([this]) : an.add(this));
                        var r = t.stack;
                        this.componentDidCatch(t.value, {
                            componentStack: null !== r ? r : ""
                        })
                    }), r
                }

                function nK(e, t, r) {
                    var n = e.pingCache;
                    if (null === n) {
                        n = e.pingCache = new nJ;
                        var i = new Set;
                        n.set(t, i)
                    } else void 0 === (i = n.get(t)) && (i = new Set, n.set(t, i));
                    i.has(r) || (i.add(r), e = aD.bind(null, e, t, r), t.then(e, e))
                }

                function nQ(e) {
                    do {
                        var t;
                        if ((t = 13 === e.tag) && (t = null === (t = e.memoizedState) || null !== t.dehydrated), t) return e;
                        e = e.return
                    } while (null !== e);
                    return null
                }

                function nV(e, t, r, n, i) {
                    return 0 == (1 & e.mode) ? e === t ? e.flags |= 65536 : (e.flags |= 128, r.flags |= 131072, r.flags &= -52805, 1 === r.tag && (null === r.alternate ? r.tag = 17 : ((t = t8(-1, 1)).tag = 2, t4(r, t))), r.lanes |= 1) : (e.flags |= 65536, e.lanes = i), e
                }

                function nY(e) {
                    e.flags |= 4
                }

                function nX(e, t) {
                    if (null !== e && e.child === t.child) return !0;
                    if (0 != (16 & t.flags)) return !1;
                    for (e = t.child; null !== e;) {
                        if (0 != (12854 & e.flags) || 0 != (12854 & e.subtreeFlags)) return !1;
                        e = e.sibling
                    }
                    return !0
                }
                if (W) t = function(e, t) {
                    for (var r = t.child; null !== r;) {
                        if (5 === r.tag || 6 === r.tag) N(e, r.stateNode);
                        else if (4 !== r.tag && null !== r.child) {
                            r.child.return = r, r = r.child;
                            continue
                        }
                        if (r === t) break;
                        for (; null === r.sibling;) {
                            if (null === r.return || r.return === t) return;
                            r = r.return
                        }
                        r.sibling.return = r.return, r = r.sibling
                    }
                }, n = function() {}, i = function(e, t, r, n, i) {
                    (e = e.memoizedProps) !== n && (r = z(t.stateNode, r, e, n, i, rj(rN.current)), (t.updateQueue = r) && nY(t))
                }, a = function(e, t, r, n) {
                    r !== n && nY(t)
                };
                else if (Z) {
                    t = function(e, r, n, i) {
                        for (var a = r.child; null !== a;) {
                            if (5 === a.tag) {
                                var o = a.stateNode;
                                n && i && (o = eI(o, a.type, a.memoizedProps, a)), N(e, o)
                            } else if (6 === a.tag) o = a.stateNode, n && i && (o = eD(o, a.memoizedProps, a)), N(e, o);
                            else if (4 !== a.tag) {
                                if (22 === a.tag && null !== a.memoizedState) null !== (o = a.child) && (o.return = a), t(e, a, !0, !0);
                                else if (null !== a.child) {
                                    a.child.return = a, a = a.child;
                                    continue
                                }
                            }
                            if (a === r) break;
                            for (; null === a.sibling;) {
                                if (null === a.return || a.return === r) return;
                                a = a.return
                            }
                            a.sibling.return = a.return, a = a.sibling
                        }
                    };
                    var nW = function(e, t, r, n) {
                        for (var i = t.child; null !== i;) {
                            if (5 === i.tag) {
                                var a = i.stateNode;
                                r && n && (a = eI(a, i.type, i.memoizedProps, i)), eS(e, a)
                            } else if (6 === i.tag) a = i.stateNode, r && n && (a = eD(a, i.memoizedProps, i)), eS(e, a);
                            else if (4 !== i.tag) {
                                if (22 === i.tag && null !== i.memoizedState) null !== (a = i.child) && (a.return = i), nW(e, i, !0, !0);
                                else if (null !== i.child) {
                                    i.child.return = i, i = i.child;
                                    continue
                                }
                            }
                            if (i === t) break;
                            for (; null === i.sibling;) {
                                if (null === i.return || i.return === t) return;
                                i = i.return
                            }
                            i.sibling.return = i.return, i = i.sibling
                        }
                    };
                    n = function(e, t) {
                        var r = t.stateNode;
                        if (!nX(e, t)) {
                            var n = eF(e = r.containerInfo);
                            nW(n, t, !1, !1), r.pendingChildren = n, nY(t), eR(e, n)
                        }
                    }, i = function(e, r, n, i, a) {
                        var o = e.stateNode,
                            s = e.memoizedProps;
                        if ((e = nX(e, r)) && s === i) r.stateNode = o;
                        else {
                            var l = r.stateNode,
                                u = rj(rN.current),
                                c = null;
                            s !== i && (c = z(l, n, s, i, a, u)), e && null === c ? r.stateNode = o : (J(o = ex(o, c, n, s, i, r, e, l), n, i, a, u) && nY(r), r.stateNode = o, e ? nY(r) : t(o, r, !1, !1))
                        }
                    }, a = function(e, t, r, n) {
                        r !== n ? (e = rj(rz.current), r = rj(rN.current), t.stateNode = K(n, e, r, t), nY(t)) : t.stateNode = e.stateNode
                    }
                } else n = function() {}, i = function() {}, a = function() {};

                function nZ(e, t) {
                    if (!rb) switch (e.tailMode) {
                        case "hidden":
                            t = e.tail;
                            for (var r = null; null !== t;) null !== t.alternate && (r = t), t = t.sibling;
                            null === r ? e.tail = null : r.sibling = null;
                            break;
                        case "collapsed":
                            r = e.tail;
                            for (var n = null; null !== r;) null !== r.alternate && (n = r), r = r.sibling;
                            null === n ? t || null === e.tail ? e.tail = null : e.tail.sibling = null : n.sibling = null
                    }
                }

                function nq(e) {
                    var t = null !== e.alternate && e.alternate.child === e.child,
                        r = 0,
                        n = 0;
                    if (t)
                        for (var i = e.child; null !== i;) r |= i.lanes | i.childLanes, n |= 14680064 & i.subtreeFlags, n |= 14680064 & i.flags, i.return = e, i = i.sibling;
                    else
                        for (i = e.child; null !== i;) r |= i.lanes | i.childLanes, n |= i.subtreeFlags, n |= i.flags, i.return = e, i = i.sibling;
                    return e.subtreeFlags |= n, e.childLanes = r, t
                }
                var n$ = f.ReactCurrentOwner,
                    n0 = !1;

                function n1(e, t, r, n) {
                    t.child = null === e ? rG(t, null, r, n) : rU(t, e.child, r, n)
                }

                function n2(e, t, r, n, i) {
                    r = r.render;
                    var a = t.ref;
                    return (t$(t, i), n = nt(e, t, r, n, a, i), r = nr(), null === e || n0) ? (rb && r && ry(t), t.flags |= 1, n1(e, t, n, i), t.child) : (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, id(e, t, i))
                }

                function n9(e, t, r, n, i) {
                    if (null === e) {
                        var a = r.type;
                        return "function" != typeof a || ak(a) || void 0 !== a.defaultProps || null !== r.compare || void 0 !== r.defaultProps ? ((e = aJ(r.type, null, n, t, t.mode, i)).ref = t.ref, e.return = t, t.child = e) : (t.tag = 15, t.type = a, n3(e, t, a, n, i))
                    }
                    if (a = e.child, 0 == (e.lanes & i)) {
                        var o = a.memoizedProps;
                        if ((r = null !== (r = r.compare) ? r : tz)(o, n) && e.ref === t.ref) return id(e, t, i)
                    }
                    return t.flags |= 1, (e = aN(a, n)).ref = t.ref, e.return = t, t.child = e
                }

                function n3(e, t, r, n, i) {
                    if (null !== e && tz(e.memoizedProps, n) && e.ref === t.ref) {
                        if (n0 = !1, 0 == (e.lanes & i)) return t.lanes = e.lanes, id(e, t, i);
                        0 != (131072 & e.flags) && (n0 = !0)
                    }
                    return n6(e, t, r, n, i)
                }

                function n8(e, t, r) {
                    var n = t.pendingProps,
                        i = n.children,
                        a = null !== e ? e.memoizedState : null;
                    if ("hidden" === n.mode) {
                        if (0 == (1 & t.mode)) t.memoizedState = {
                            baseLanes: 0,
                            cachePool: null
                        }, te(i0, i$), i$ |= r;
                        else {
                            if (0 == (1073741824 & r)) return e = null !== a ? a.baseLanes | r : r, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
                                baseLanes: e,
                                cachePool: null
                            }, t.updateQueue = null, te(i0, i$), i$ |= e, null;
                            t.memoizedState = {
                                baseLanes: 0,
                                cachePool: null
                            }, n = null !== a ? a.baseLanes : r, te(i0, i$), i$ |= n
                        }
                    } else null !== a ? (n = a.baseLanes | r, t.memoizedState = null) : n = r, te(i0, i$), i$ |= n;
                    return n1(e, t, i, r), t.child
                }

                function n4(e, t) {
                    var r = t.ref;
                    (null === e && null !== r || null !== e && e.ref !== r) && (t.flags |= 512, t.flags |= 2097152)
                }

                function n6(e, t, r, n, i) {
                    var a = to(r) ? ti : tr.current;
                    return (a = ta(t, a), t$(t, i), r = nt(e, t, r, n, a, i), n = nr(), null === e || n0) ? (rb && n && ry(t), t.flags |= 1, n1(e, t, r, i), t.child) : (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, id(e, t, i))
                }

                function n5(e, t, r, n, i) {
                    if (to(r)) {
                        var a = !0;
                        tc(t)
                    } else a = !1;
                    if (t$(t, i), null === t.stateNode) null !== e && (e.alternate = null, t.alternate = null, t.flags |= 2), ra(t, r, n), rs(t, r, n, i), n = !0;
                    else if (null === e) {
                        var o = t.stateNode,
                            s = t.memoizedProps;
                        o.props = s;
                        var l = o.context,
                            u = r.contextType;
                        u = "object" == typeof u && null !== u ? t0(u) : ta(t, u = to(r) ? ti : tr.current);
                        var c = r.getDerivedStateFromProps,
                            d = "function" == typeof c || "function" == typeof o.getSnapshotBeforeUpdate;
                        d || "function" != typeof o.UNSAFE_componentWillReceiveProps && "function" != typeof o.componentWillReceiveProps || (s !== n || l !== u) && ro(t, o, n, u), t2 = !1;
                        var f = t.memoizedState;
                        o.state = f, t7(t, n, o, i), l = t.memoizedState, s !== n || f !== l || tn.current || t2 ? ("function" == typeof c && (rr(t, r, c, n), l = t.memoizedState), (s = t2 || ri(t, r, s, n, f, l, u)) ? (d || "function" != typeof o.UNSAFE_componentWillMount && "function" != typeof o.componentWillMount || ("function" == typeof o.componentWillMount && o.componentWillMount(), "function" == typeof o.UNSAFE_componentWillMount && o.UNSAFE_componentWillMount()), "function" == typeof o.componentDidMount && (t.flags |= 4194308)) : ("function" == typeof o.componentDidMount && (t.flags |= 4194308), t.memoizedProps = n, t.memoizedState = l), o.props = n, o.state = l, o.context = u, n = s) : ("function" == typeof o.componentDidMount && (t.flags |= 4194308), n = !1)
                    } else {
                        o = t.stateNode, t3(e, t), s = t.memoizedProps, u = t.type === t.elementType ? s : tj(t.type, s), o.props = u, d = t.pendingProps, f = o.context, l = "object" == typeof(l = r.contextType) && null !== l ? t0(l) : ta(t, l = to(r) ? ti : tr.current);
                        var h = r.getDerivedStateFromProps;
                        (c = "function" == typeof h || "function" == typeof o.getSnapshotBeforeUpdate) || "function" != typeof o.UNSAFE_componentWillReceiveProps && "function" != typeof o.componentWillReceiveProps || (s !== d || f !== l) && ro(t, o, n, l), t2 = !1, f = t.memoizedState, o.state = f, t7(t, n, o, i);
                        var p = t.memoizedState;
                        s !== d || f !== p || tn.current || t2 ? ("function" == typeof h && (rr(t, r, h, n), p = t.memoizedState), (u = t2 || ri(t, r, u, n, f, p, l) || !1) ? (c || "function" != typeof o.UNSAFE_componentWillUpdate && "function" != typeof o.componentWillUpdate || ("function" == typeof o.componentWillUpdate && o.componentWillUpdate(n, p, l), "function" == typeof o.UNSAFE_componentWillUpdate && o.UNSAFE_componentWillUpdate(n, p, l)), "function" == typeof o.componentDidUpdate && (t.flags |= 4), "function" == typeof o.getSnapshotBeforeUpdate && (t.flags |= 1024)) : ("function" != typeof o.componentDidUpdate || s === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), "function" != typeof o.getSnapshotBeforeUpdate || s === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = n, t.memoizedState = p), o.props = n, o.state = p, o.context = l, n = u) : ("function" != typeof o.componentDidUpdate || s === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), "function" != typeof o.getSnapshotBeforeUpdate || s === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), n = !1)
                    }
                    return n7(e, t, r, n, a, i)
                }

                function n7(e, t, r, n, i, a) {
                    n4(e, t);
                    var o = 0 != (128 & t.flags);
                    if (!n && !o) return i && td(t, r, !1), id(e, t, a);
                    n = t.stateNode, n$.current = t;
                    var s = o && "function" != typeof r.getDerivedStateFromError ? null : n.render();
                    return t.flags |= 1, null !== e && o ? (t.child = rU(t, e.child, null, a), t.child = rU(t, null, s, a)) : n1(e, t, s, a), t.memoizedState = n.state, i && td(t, r, !0), t.child
                }

                function ie(e) {
                    var t = e.stateNode;
                    t.pendingContext ? tl(e, t.pendingContext, t.pendingContext !== t.context) : t.context && tl(e, t.context, !1), rK(e, t.containerInfo)
                }

                function it(e, t, r, n, i) {
                    return rO(), rI(i), t.flags |= 256, n1(e, t, r, n), t.child
                }
                var ir = {
                    dehydrated: null,
                    treeContext: null,
                    retryLane: 0
                };

                function ii(e) {
                    return {
                        baseLanes: e,
                        cachePool: null
                    }
                }

                function ia(e, t, r) {
                    var n, i, a, o, s, l, u, c, f, h, p, m, g, A, v = t.pendingProps,
                        y = rX.current,
                        C = !1,
                        B = 0 != (128 & t.flags);
                    if ((A = B) || (A = (null === e || null !== e.memoizedState) && 0 != (2 & y)), A ? (C = !0, t.flags &= -129) : (null === e || null !== e.memoizedState) && (y |= 1), te(rX, 1 & y), null === e) return (rF(t), null !== (e = t.memoizedState) && null !== (e = e.dehydrated)) ? (0 == (1 & t.mode) ? t.lanes = 1 : eG(e) ? t.lanes = 8 : t.lanes = 1073741824, null) : (y = v.children, e = v.fallback, C ? (v = t.mode, C = t.child, y = {
                        mode: "hidden",
                        children: y
                    }, 0 == (1 & v) && null !== C ? (C.childLanes = 0, C.pendingProps = y) : C = aj(y, v, 0, null), e = az(e, v, r, null), C.return = t, e.return = t, C.sibling = e, t.child = C, t.child.memoizedState = ii(r), t.memoizedState = ir, e) : io(t, y));
                    if (null !== (y = e.memoizedState) && null !== (A = y.dehydrated)) {
                        if (B) return 256 & t.flags ? (t.flags &= -257, is(e, t, r, Error(d(422)))) : null !== t.memoizedState ? (t.child = e.child, t.flags |= 128, null) : (C = v.fallback, y = t.mode, v = aj({
                            mode: "visible",
                            children: v.children
                        }, y, 0, null), C = az(C, y, r, null), C.flags |= 2, v.return = t, C.return = t, v.sibling = C, t.child = v, 0 != (1 & t.mode) && rU(t, e.child, null, r), t.child.memoizedState = ii(r), t.memoizedState = ir, C);
                        if (0 == (1 & t.mode)) t = is(e, t, r, null);
                        else if (eG(A)) t = is(e, t, r, Error(d(419)));
                        else if (v = 0 != (r & e.childLanes), n0 || v) {
                            if (null !== (v = iW)) {
                                switch (r & -r) {
                                    case 4:
                                        C = 2;
                                        break;
                                    case 16:
                                        C = 8;
                                        break;
                                    case 64:
                                    case 128:
                                    case 256:
                                    case 512:
                                    case 1024:
                                    case 2048:
                                    case 4096:
                                    case 8192:
                                    case 16384:
                                    case 32768:
                                    case 65536:
                                    case 131072:
                                    case 262144:
                                    case 524288:
                                    case 1048576:
                                    case 2097152:
                                    case 4194304:
                                    case 8388608:
                                    case 16777216:
                                    case 33554432:
                                    case 67108864:
                                        C = 32;
                                        break;
                                    case 536870912:
                                        C = 268435456;
                                        break;
                                    default:
                                        C = 0
                                }
                                0 !== (v = 0 != (C & (v.suspendedLanes | r)) ? 0 : C) && v !== y.retryLane && (y.retryLane = v, ah(e, v, -1))
                            }
                            aM(), t = is(e, t, r, Error(d(421)))
                        } else eU(A) ? (t.flags |= 128, t.child = e.child, ek(A, t = aL.bind(null, e)), t = null) : (r = y.treeContext, q && (r_ = ej(A), rB = t, rb = !0, rw = null, rE = !1, null !== r && (rf[rh++] = rm, rf[rh++] = rg, rf[rh++] = rp, rm = r.id, rg = r.overflow, rp = t)), t = io(t, t.pendingProps.children), t.flags |= 4096);
                        return t
                    }
                    return C ? (n = e, i = t, a = v.children, o = v.fallback, s = r, l = i.mode, u = (n = n.child).sibling, c = {
                        mode: "hidden",
                        children: a
                    }, 0 == (1 & l) && i.child !== n ? ((a = i.child).childLanes = 0, a.pendingProps = c, i.deletions = null) : (a = aN(n, c)).subtreeFlags = 14680064 & n.subtreeFlags, null !== u ? o = aN(u, o) : (o = az(o, l, s, null), o.flags |= 2), o.return = i, a.return = i, a.sibling = o, i.child = a, v = o, C = t.child, y = e.child.memoizedState, C.memoizedState = null === y ? ii(r) : {
                        baseLanes: y.baseLanes | r,
                        cachePool: null
                    }, C.childLanes = e.childLanes & ~r, t.memoizedState = ir, v) : (f = e, h = t, p = v.children, m = r, f = (g = f.child).sibling, p = aN(g, {
                        mode: "visible",
                        children: p
                    }), 0 == (1 & h.mode) && (p.lanes = m), p.return = h, p.sibling = null, null !== f && (null === (m = h.deletions) ? (h.deletions = [f], h.flags |= 16) : m.push(f)), r = h.child = p, t.memoizedState = null, r)
                }

                function io(e, t) {
                    return (t = aj({
                        mode: "visible",
                        children: t
                    }, e.mode, 0, null)).return = e, e.child = t
                }

                function is(e, t, r, n) {
                    return null !== n && rI(n), rU(t, e.child, null, r), e = io(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
                }

                function il(e, t, r) {
                    e.lanes |= t;
                    var n = e.alternate;
                    null !== n && (n.lanes |= t), tq(e.return, t, r)
                }

                function iu(e, t, r, n, i) {
                    var a = e.memoizedState;
                    null === a ? e.memoizedState = {
                        isBackwards: t,
                        rendering: null,
                        renderingStartTime: 0,
                        last: n,
                        tail: r,
                        tailMode: i
                    } : (a.isBackwards = t, a.rendering = null, a.renderingStartTime = 0, a.last = n, a.tail = r, a.tailMode = i)
                }

                function ic(e, t, r) {
                    var n = t.pendingProps,
                        i = n.revealOrder,
                        a = n.tail;
                    if (n1(e, t, n.children, r), 0 != (2 & (n = rX.current))) n = 1 & n | 2, t.flags |= 128;
                    else {
                        if (null !== e && 0 != (128 & e.flags)) e: for (e = t.child; null !== e;) {
                            if (13 === e.tag) null !== e.memoizedState && il(e, r, t);
                            else if (19 === e.tag) il(e, r, t);
                            else if (null !== e.child) {
                                e.child.return = e, e = e.child;
                                continue
                            }
                            if (e === t) break;
                            for (; null === e.sibling;) {
                                if (null === e.return || e.return === t) break e;
                                e = e.return
                            }
                            e.sibling.return = e.return, e = e.sibling
                        }
                        n &= 1
                    }
                    if (te(rX, n), 0 == (1 & t.mode)) t.memoizedState = null;
                    else switch (i) {
                        case "forwards":
                            for (i = null, r = t.child; null !== r;) null !== (e = r.alternate) && null === rW(e) && (i = r), r = r.sibling;
                            null === (r = i) ? (i = t.child, t.child = null) : (i = r.sibling, r.sibling = null), iu(t, !1, i, r, a);
                            break;
                        case "backwards":
                            for (r = null, i = t.child, t.child = null; null !== i;) {
                                if (null !== (e = i.alternate) && null === rW(e)) {
                                    t.child = i;
                                    break
                                }
                                e = i.sibling, i.sibling = r, r = i, i = e
                            }
                            iu(t, !0, r, null, a);
                            break;
                        case "together":
                            iu(t, !1, null, null, void 0);
                            break;
                        default:
                            t.memoizedState = null
                    }
                    return t.child
                }

                function id(e, t, r) {
                    if (null !== e && (t.dependencies = e.dependencies), i9 |= t.lanes, 0 == (r & t.childLanes)) return null;
                    if (null !== e && t.child !== e.child) throw Error(d(153));
                    if (null !== t.child) {
                        for (r = aN(e = t.child, e.pendingProps), t.child = r, r.return = t; null !== e.sibling;) e = e.sibling, (r = r.sibling = aN(e, e.pendingProps)).return = t;
                        r.sibling = null
                    }
                    return t.child
                }
                var ih = !1,
                    ip = !1,
                    im = "function" == typeof WeakSet ? WeakSet : Set,
                    ig = null;

                function iA(e, t) {
                    var r = e.ref;
                    if (null !== r) {
                        if ("function" == typeof r) try {
                            r(null)
                        } catch (r) {
                            aI(e, t, r)
                        } else r.current = null
                    }
                }

                function iv(e, t, r) {
                    try {
                        r()
                    } catch (r) {
                        aI(e, t, r)
                    }
                }
                var iy = !1;

                function iC(e, t, r) {
                    var n = t.updateQueue;
                    if (null !== (n = null !== n ? n.lastEffect : null)) {
                        var i = n = n.next;
                        do {
                            if ((i.tag & e) === e) {
                                var a = i.destroy;
                                i.destroy = void 0, void 0 !== a && iv(t, r, a)
                            }
                            i = i.next
                        } while (i !== n)
                    }
                }

                function iB(e, t) {
                    if (null !== (t = null !== (t = t.updateQueue) ? t.lastEffect : null)) {
                        var r = t = t.next;
                        do {
                            if ((r.tag & e) === e) {
                                var n = r.create;
                                r.destroy = n()
                            }
                            r = r.next
                        } while (r !== t)
                    }
                }

                function i_(e) {
                    var t = e.ref;
                    if (null !== t) {
                        var r = e.stateNode;
                        e = 5 === e.tag ? P(r) : r, "function" == typeof t ? t(e) : t.current = e
                    }
                }

                function ib(e, t, r) {
                    if (tP && "function" == typeof tP.onCommitFiberUnmount) try {
                        tP.onCommitFiberUnmount(tD, t)
                    } catch (e) {}
                    switch (t.tag) {
                        case 0:
                        case 11:
                        case 14:
                        case 15:
                            if (null !== (e = t.updateQueue) && null !== (e = e.lastEffect)) {
                                var n = e = e.next;
                                do {
                                    var i = n,
                                        a = i.destroy;
                                    i = i.tag, void 0 !== a && (0 != (2 & i) ? iv(t, r, a) : 0 != (4 & i) && iv(t, r, a)), n = n.next
                                } while (n !== e)
                            }
                            break;
                        case 1:
                            if (iA(t, r), "function" == typeof(e = t.stateNode).componentWillUnmount) try {
                                e.props = t.memoizedProps, e.state = t.memoizedState, e.componentWillUnmount()
                            } catch (e) {
                                aI(t, r, e)
                            }
                            break;
                        case 5:
                            iA(t, r);
                            break;
                        case 4:
                            W ? ix(e, t, r) : Z && Z && (r = eF(t = t.stateNode.containerInfo), eO(t, r))
                    }
                }

                function iE(e, t, r) {
                    for (var n = t;;)
                        if (ib(e, n, r), null === n.child || W && 4 === n.tag) {
                            if (n === t) break;
                            for (; null === n.sibling;) {
                                if (null === n.return || n.return === t) return;
                                n = n.return
                            }
                            n.sibling.return = n.return, n = n.sibling
                        } else n.child.return = n, n = n.child
                }

                function iw(e) {
                    return 5 === e.tag || 3 === e.tag || 4 === e.tag
                }

                function iM(e) {
                    e: for (;;) {
                        for (; null === e.sibling;) {
                            if (null === e.return || iw(e.return)) return null;
                            e = e.return
                        }
                        for (e.sibling.return = e.return, e = e.sibling; 5 !== e.tag && 6 !== e.tag && 18 !== e.tag;) {
                            if (2 & e.flags || null === e.child || 4 === e.tag) continue e;
                            e.child.return = e, e = e.child
                        }
                        if (!(2 & e.flags)) return e.stateNode
                    }
                }

                function iT(e) {
                    if (W) {
                        e: {
                            for (var t = e.return; null !== t;) {
                                if (iw(t)) break e;
                                t = t.return
                            }
                            throw Error(d(160))
                        }
                        var r = t;
                        switch (r.tag) {
                            case 5:
                                t = r.stateNode, 32 & r.flags && (e_(t), r.flags &= -33), r = iM(e),
                                    function e(t, r, n) {
                                        var i = t.tag;
                                        if (5 === i || 6 === i) t = t.stateNode, r ? ev(n, t, r) : eh(n, t);
                                        else if (4 !== i && null !== (t = t.child))
                                            for (e(t, r, n), t = t.sibling; null !== t;) e(t, r, n), t = t.sibling
                                    }(e, r, t);
                                break;
                            case 3:
                            case 4:
                                t = r.stateNode.containerInfo, r = iM(e),
                                    function e(t, r, n) {
                                        var i = t.tag;
                                        if (5 === i || 6 === i) t = t.stateNode, r ? ey(n, t, r) : ep(n, t);
                                        else if (4 !== i && null !== (t = t.child))
                                            for (e(t, r, n), t = t.sibling; null !== t;) e(t, r, n), t = t.sibling
                                    }(e, r, t);
                                break;
                            default:
                                throw Error(d(161))
                        }
                    }
                }

                function ix(e, t, r) {
                    for (var n, i, a = t, o = !1;;) {
                        if (!o) {
                            o = a.return;
                            e: for (;;) {
                                if (null === o) throw Error(d(160));
                                switch (n = o.stateNode, o.tag) {
                                    case 5:
                                        i = !1;
                                        break e;
                                    case 3:
                                    case 4:
                                        n = n.containerInfo, i = !0;
                                        break e
                                }
                                o = o.return
                            }
                            o = !0
                        }
                        if (5 === a.tag || 6 === a.tag) iE(e, a, r), i ? eB(n, a.stateNode) : eC(n, a.stateNode);
                        else if (18 === a.tag) i ? eq(n, a.stateNode) : eZ(n, a.stateNode);
                        else if (4 === a.tag) {
                            if (null !== a.child) {
                                n = a.stateNode.containerInfo, i = !0, a.child.return = a, a = a.child;
                                continue
                            }
                        } else if (ib(e, a, r), null !== a.child) {
                            a.child.return = a, a = a.child;
                            continue
                        }
                        if (a === t) break;
                        for (; null === a.sibling;) {
                            if (null === a.return || a.return === t) return;
                            4 === (a = a.return).tag && (o = !1)
                        }
                        a.sibling.return = a.return, a = a.sibling
                    }
                }

                function iF(e, t) {
                    if (W) {
                        switch (t.tag) {
                            case 0:
                            case 11:
                            case 14:
                            case 15:
                                iC(3, t, t.return), iB(3, t), iC(5, t, t.return);
                                return;
                            case 1:
                            case 12:
                            case 17:
                                return;
                            case 5:
                                var r = t.stateNode;
                                if (null != r) {
                                    var n = t.memoizedProps;
                                    e = null !== e ? e.memoizedProps : n;
                                    var i = t.type,
                                        a = t.updateQueue;
                                    t.updateQueue = null, null !== a && eA(r, a, i, e, n, t)
                                }
                                return;
                            case 6:
                                if (null === t.stateNode) throw Error(d(162));
                                r = t.memoizedProps, em(t.stateNode, null !== e ? e.memoizedProps : r, r);
                                return;
                            case 3:
                                q && null !== e && e.memoizedState.isDehydrated && eX(t.stateNode.containerInfo);
                                return;
                            case 13:
                            case 19:
                                iS(t);
                                return
                        }
                        throw Error(d(163))
                    }
                    switch (t.tag) {
                        case 0:
                        case 11:
                        case 14:
                        case 15:
                            iC(3, t, t.return), iB(3, t), iC(5, t, t.return);
                            return;
                        case 12:
                        case 22:
                        case 23:
                            return;
                        case 13:
                        case 19:
                            iS(t);
                            return;
                        case 3:
                            q && null !== e && e.memoizedState.isDehydrated && eX(t.stateNode.containerInfo)
                    }
                    e: if (Z) {
                        switch (t.tag) {
                            case 1:
                            case 5:
                            case 6:
                                break e;
                            case 3:
                            case 4:
                                eO((t = t.stateNode).containerInfo, t.pendingChildren);
                                break e
                        }
                        throw Error(d(163))
                    }
                }

                function iS(e) {
                    var t = e.updateQueue;
                    if (null !== t) {
                        e.updateQueue = null;
                        var r = e.stateNode;
                        null === r && (r = e.stateNode = new im), t.forEach(function(t) {
                            var n = aH.bind(null, e, t);
                            r.has(t) || (r.add(t), t.then(n, n))
                        })
                    }
                }

                function iR(e) {
                    for (; null !== ig;) {
                        var t = ig;
                        if (0 != (8772 & t.flags)) {
                            var r = t.alternate;
                            try {
                                if (0 != (8772 & t.flags)) switch (t.tag) {
                                    case 0:
                                    case 11:
                                    case 15:
                                        ip || iB(5, t);
                                        break;
                                    case 1:
                                        var n = t.stateNode;
                                        if (4 & t.flags && !ip) {
                                            if (null === r) n.componentDidMount();
                                            else {
                                                var i = t.elementType === t.type ? r.memoizedProps : tj(t.type, r.memoizedProps);
                                                n.componentDidUpdate(i, r.memoizedState, n.__reactInternalSnapshotBeforeUpdate)
                                            }
                                        }
                                        var a = t.updateQueue;
                                        null !== a && re(t, a, n);
                                        break;
                                    case 3:
                                        var o = t.updateQueue;
                                        if (null !== o) {
                                            if (r = null, null !== t.child) switch (t.child.tag) {
                                                case 5:
                                                    r = P(t.child.stateNode);
                                                    break;
                                                case 1:
                                                    r = t.child.stateNode
                                            }
                                            re(t, o, r)
                                        }
                                        break;
                                    case 5:
                                        var s = t.stateNode;
                                        null === r && 4 & t.flags && eg(s, t.type, t.memoizedProps, t);
                                        break;
                                    case 6:
                                    case 4:
                                    case 12:
                                    case 19:
                                    case 17:
                                    case 21:
                                    case 22:
                                    case 23:
                                        break;
                                    case 13:
                                        if (q && null === t.memoizedState) {
                                            var l = t.alternate;
                                            if (null !== l) {
                                                var u = l.memoizedState;
                                                if (null !== u) {
                                                    var c = u.dehydrated;
                                                    null !== c && eW(c)
                                                }
                                            }
                                        }
                                        break;
                                    default:
                                        throw Error(d(163))
                                }
                                ip || 512 & t.flags && i_(t)
                            } catch (e) {
                                aI(t, t.return, e)
                            }
                        }
                        if (t === e) {
                            ig = null;
                            break
                        }
                        if (null !== (r = t.sibling)) {
                            r.return = t.return, ig = r;
                            break
                        }
                        ig = t.return
                    }
                }

                function iO(e) {
                    for (; null !== ig;) {
                        var t = ig;
                        if (t === e) {
                            ig = null;
                            break
                        }
                        var r = t.sibling;
                        if (null !== r) {
                            r.return = t.return, ig = r;
                            break
                        }
                        ig = t.return
                    }
                }

                function iI(e) {
                    for (; null !== ig;) {
                        var t = ig;
                        try {
                            switch (t.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    var r = t.return;
                                    try {
                                        iB(4, t)
                                    } catch (e) {
                                        aI(t, r, e)
                                    }
                                    break;
                                case 1:
                                    var n = t.stateNode;
                                    if ("function" == typeof n.componentDidMount) {
                                        var i = t.return;
                                        try {
                                            n.componentDidMount()
                                        } catch (e) {
                                            aI(t, i, e)
                                        }
                                    }
                                    var a = t.return;
                                    try {
                                        i_(t)
                                    } catch (e) {
                                        aI(t, a, e)
                                    }
                                    break;
                                case 5:
                                    var o = t.return;
                                    try {
                                        i_(t)
                                    } catch (e) {
                                        aI(t, o, e)
                                    }
                            }
                        } catch (e) {
                            aI(t, t.return, e)
                        }
                        if (t === e) {
                            ig = null;
                            break
                        }
                        var s = t.sibling;
                        if (null !== s) {
                            s.return = t.return, ig = s;
                            break
                        }
                        ig = t.return
                    }
                }
                var iD = 0,
                    iP = 1,
                    iL = 2,
                    iH = 3,
                    iU = 4;
                if ("function" == typeof Symbol && Symbol.for) {
                    var iG = Symbol.for;
                    iD = iG("selector.component"), iP = iG("selector.has_pseudo_class"), iL = iG("selector.role"), iH = iG("selector.test_id"), iU = iG("selector.text")
                }

                function ik(e) {
                    var t = $(e);
                    if (null != t) {
                        if ("string" != typeof t.memoizedProps["data-testname"]) throw Error(d(364));
                        return t
                    }
                    if (null === (e = eo(e))) throw Error(d(362));
                    return e.stateNode.current
                }

                function iN(e, t) {
                    switch (t.$$typeof) {
                        case iD:
                            if (e.type === t.value) return !0;
                            break;
                        case iP:
                            e: {
                                t = t.value,
                                e = [e, 0];
                                for (var r = 0; r < e.length;) {
                                    var n = e[r++],
                                        i = e[r++],
                                        a = t[i];
                                    if (5 !== n.tag || !eu(n)) {
                                        for (; null != a && iN(n, a);) a = t[++i];
                                        if (i === t.length) {
                                            t = !0;
                                            break e
                                        }
                                        for (n = n.child; null !== n;) e.push(n, i), n = n.sibling
                                    }
                                }
                                t = !1
                            }
                            return t;
                        case iL:
                            if (5 === e.tag && ec(e.stateNode, t.value)) return !0;
                            break;
                        case iU:
                            if ((5 === e.tag || 6 === e.tag) && null !== (e = el(e)) && 0 <= e.indexOf(t.value)) return !0;
                            break;
                        case iH:
                            if (5 === e.tag && "string" == typeof(e = e.memoizedProps["data-testname"]) && e.toLowerCase() === t.value.toLowerCase()) return !0;
                            break;
                        default:
                            throw Error(d(365))
                    }
                    return !1
                }

                function iJ(e) {
                    switch (e.$$typeof) {
                        case iD:
                            return "<" + (x(e.value) || "Unknown") + ">";
                        case iP:
                            return ":has(" + (iJ(e) || "") + ")";
                        case iL:
                            return '[role="' + e.value + '"]';
                        case iU:
                            return '"' + e.value + '"';
                        case iH:
                            return '[data-testname="' + e.value + '"]';
                        default:
                            throw Error(d(365))
                    }
                }

                function iz(e, t) {
                    var r = [];
                    e = [e, 0];
                    for (var n = 0; n < e.length;) {
                        var i = e[n++],
                            a = e[n++],
                            o = t[a];
                        if (5 !== i.tag || !eu(i)) {
                            for (; null != o && iN(i, o);) o = t[++a];
                            if (a === t.length) r.push(i);
                            else
                                for (i = i.child; null !== i;) e.push(i, a), i = i.sibling
                        }
                    }
                    return r
                }

                function ij(e, t) {
                    if (!ea) throw Error(d(363));
                    e = iz(e = ik(e), t), t = [], e = Array.from(e);
                    for (var r = 0; r < e.length;) {
                        var n = e[r++];
                        if (5 === n.tag) eu(n) || t.push(n.stateNode);
                        else
                            for (n = n.child; null !== n;) e.push(n), n = n.sibling
                    }
                    return t
                }
                var iK = Math.ceil,
                    iQ = f.ReactCurrentDispatcher,
                    iV = f.ReactCurrentOwner,
                    iY = f.ReactCurrentBatchConfig,
                    iX = 0,
                    iW = null,
                    iZ = null,
                    iq = 0,
                    i$ = 0,
                    i0 = e5(0),
                    i1 = 0,
                    i2 = null,
                    i9 = 0,
                    i3 = 0,
                    i8 = 0,
                    i4 = null,
                    i6 = null,
                    i5 = 0,
                    i7 = 1 / 0;

                function ae() {
                    i7 = tF() + 500
                }
                var at = !1,
                    ar = null,
                    an = null,
                    ai = !1,
                    aa = null,
                    ao = 0,
                    as = 0,
                    al = null,
                    au = -1,
                    ac = 0;

                function ad() {
                    return 0 != (6 & iX) ? tF() : -1 !== au ? au : au = tF()
                }

                function af(e) {
                    return 0 == (1 & e.mode) ? 1 : 0 != (2 & iX) && 0 !== iq ? iq & -iq : null !== tJ.transition ? (0 === ac && (e = tm, 0 == (4194240 & (tm <<= 1)) && (tm = 64), ac = e), ac) : 0 !== (e = tb) ? e : et()
                }

                function ah(e, t, r) {
                    if (50 < as) throw as = 0, al = null, Error(d(185));
                    var n = ap(e, t);
                    return null === n ? null : (tB(n, t, r), (0 == (2 & iX) || n !== iW) && (n === iW && (0 == (2 & iX) && (i3 |= t), 4 === i1 && ay(n, iq)), am(n, r), 1 === t && 0 === iX && 0 == (1 & e.mode) && (ae(), tU && tN())), n)
                }

                function ap(e, t) {
                    e.lanes |= t;
                    var r = e.alternate;
                    for (null !== r && (r.lanes |= t), r = e, e = e.return; null !== e;) e.childLanes |= t, null !== (r = e.alternate) && (r.childLanes |= t), r = e, e = e.return;
                    return 3 === r.tag ? r.stateNode : null
                }

                function am(e, t) {
                    var r, n = e.callbackNode;
                    ! function(e, t) {
                        for (var r = e.suspendedLanes, n = e.pingedLanes, i = e.expirationTimes, a = e.pendingLanes; 0 < a;) {
                            var o = 31 - tf(a),
                                s = 1 << o,
                                l = i[o]; - 1 === l ? (0 == (s & r) || 0 != (s & n)) && (i[o] = function(e, t) {
                                switch (e) {
                                    case 1:
                                    case 2:
                                    case 4:
                                        return t + 250;
                                    case 8:
                                    case 16:
                                    case 32:
                                    case 64:
                                    case 128:
                                    case 256:
                                    case 512:
                                    case 1024:
                                    case 2048:
                                    case 4096:
                                    case 8192:
                                    case 16384:
                                    case 32768:
                                    case 65536:
                                    case 131072:
                                    case 262144:
                                    case 524288:
                                    case 1048576:
                                    case 2097152:
                                        return t + 5e3;
                                    default:
                                        return -1
                                }
                            }(s, t)) : l <= t && (e.expiredLanes |= s), a &= ~s
                        }
                    }(e, t);
                    var i = tv(e, e === iW ? iq : 0);
                    if (0 === i) null !== n && tM(n), e.callbackNode = null, e.callbackPriority = 0;
                    else if (t = i & -i, e.callbackPriority !== t) {
                        if (null != n && tM(n), 1 === t) 0 === e.tag ? (r = aC.bind(null, e), tU = !0, tk(r)) : tk(aC.bind(null, e)), en ? ei(function() {
                            0 === iX && tN()
                        }) : tw(tS, tN), n = null;
                        else {
                            switch (tE(i)) {
                                case 1:
                                    n = tS;
                                    break;
                                case 4:
                                    n = tR;
                                    break;
                                case 16:
                                default:
                                    n = tO;
                                    break;
                                case 536870912:
                                    n = tI
                            }
                            n = tw(n, ag.bind(null, e))
                        }
                        e.callbackPriority = t, e.callbackNode = n
                    }
                }

                function ag(e, t) {
                    if (au = -1, ac = 0, 0 != (6 & iX)) throw Error(d(327));
                    var r = e.callbackNode;
                    if (aR() && e.callbackNode !== r) return null;
                    var n = tv(e, e === iW ? iq : 0);
                    if (0 === n) return null;
                    if (0 != (30 & n) || 0 != (n & e.expiredLanes) || t) t = aT(e, n);
                    else {
                        t = n;
                        var i = iX;
                        iX |= 2;
                        var a = aw();
                        for ((iW !== e || iq !== t) && (ae(), ab(e, t));;) try {
                            ! function() {
                                for (; null !== iZ && !tT();) ax(iZ)
                            }();
                            break
                        } catch (t) {
                            aE(e, t)
                        }
                        tX(), iQ.current = a, iX = i, null !== iZ ? t = 0 : (iW = null, iq = 0, t = i1)
                    }
                    if (0 !== t) {
                        if (2 === t && 0 !== (i = ty(e)) && (n = i, t = aA(e, i)), 1 === t) throw r = i2, ab(e, 0), ay(e, n), am(e, tF()), r;
                        if (6 === t) ay(e, n);
                        else {
                            if (i = e.current.alternate, 0 == (30 & n) && ! function(e) {
                                    for (var t = e;;) {
                                        if (16384 & t.flags) {
                                            var r = t.updateQueue;
                                            if (null !== r && null !== (r = r.stores))
                                                for (var n = 0; n < r.length; n++) {
                                                    var i = r[n],
                                                        a = i.getSnapshot;
                                                    i = i.value;
                                                    try {
                                                        if (!tL(a(), i)) return !1
                                                    } catch (e) {
                                                        return !1
                                                    }
                                                }
                                        }
                                        if (r = t.child, 16384 & t.subtreeFlags && null !== r) r.return = t, t = r;
                                        else {
                                            if (t === e) break;
                                            for (; null === t.sibling;) {
                                                if (null === t.return || t.return === e) return !0;
                                                t = t.return
                                            }
                                            t.sibling.return = t.return, t = t.sibling
                                        }
                                    }
                                    return !0
                                }(i) && (2 === (t = aT(e, n)) && 0 !== (a = ty(e)) && (n = a, t = aA(e, a)), 1 === t)) throw r = i2, ab(e, 0), ay(e, n), am(e, tF()), r;
                            switch (e.finishedWork = i, e.finishedLanes = n, t) {
                                case 0:
                                case 1:
                                    throw Error(d(345));
                                case 2:
                                case 5:
                                    aS(e, i6);
                                    break;
                                case 3:
                                    if (ay(e, n), (130023424 & n) === n && 10 < (t = i5 + 500 - tF())) {
                                        if (0 !== tv(e, 0)) break;
                                        if (((i = e.suspendedLanes) & n) !== n) {
                                            ad(), e.pingedLanes |= e.suspendedLanes & i;
                                            break
                                        }
                                        e.timeoutHandle = Q(aS.bind(null, e, i6), t);
                                        break
                                    }
                                    aS(e, i6);
                                    break;
                                case 4:
                                    if (ay(e, n), (4194240 & n) === n) break;
                                    for (i = -1, t = e.eventTimes; 0 < n;) {
                                        var o = 31 - tf(n);
                                        a = 1 << o, (o = t[o]) > i && (i = o), n &= ~a
                                    }
                                    if (n = i, 10 < (n = (120 > (n = tF() - n) ? 120 : 480 > n ? 480 : 1080 > n ? 1080 : 1920 > n ? 1920 : 3e3 > n ? 3e3 : 4320 > n ? 4320 : 1960 * iK(n / 1960)) - n)) {
                                        e.timeoutHandle = Q(aS.bind(null, e, i6), n);
                                        break
                                    }
                                    aS(e, i6);
                                    break;
                                default:
                                    throw Error(d(329))
                            }
                        }
                    }
                    return am(e, tF()), e.callbackNode === r ? ag.bind(null, e) : null
                }

                function aA(e, t) {
                    var r = i4;
                    return e.current.memoizedState.isDehydrated && (ab(e, t).flags |= 256), 2 !== (e = aT(e, t)) && (t = i6, i6 = r, null !== t && av(t)), e
                }

                function av(e) {
                    null === i6 ? i6 = e : i6.push.apply(i6, e)
                }

                function ay(e, t) {
                    for (t &= ~i8, t &= ~i3, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
                        var r = 31 - tf(t),
                            n = 1 << r;
                        e[r] = -1, t &= ~n
                    }
                }

                function aC(e) {
                    if (0 != (6 & iX)) throw Error(d(327));
                    aR();
                    var t = tv(e, 0);
                    if (0 == (1 & t)) return am(e, tF()), null;
                    var r = aT(e, t);
                    if (0 !== e.tag && 2 === r) {
                        var n = ty(e);
                        0 !== n && (t = n, r = aA(e, n))
                    }
                    if (1 === r) throw r = i2, ab(e, 0), ay(e, t), am(e, tF()), r;
                    if (6 === r) throw Error(d(345));
                    return e.finishedWork = e.current.alternate, e.finishedLanes = t, aS(e, i6), am(e, tF()), null
                }

                function aB(e) {
                    null !== aa && 0 === aa.tag && 0 == (6 & iX) && aR();
                    var t = iX;
                    iX |= 1;
                    var r = iY.transition,
                        n = tb;
                    try {
                        if (iY.transition = null, tb = 1, e) return e()
                    } finally {
                        tb = n, iY.transition = r, 0 == (6 & (iX = t)) && tN()
                    }
                }

                function a_() {
                    i$ = i0.current, e7(i0)
                }

                function ab(e, t) {
                    e.finishedWork = null, e.finishedLanes = 0;
                    var r = e.timeoutHandle;
                    if (r !== Y && (e.timeoutHandle = Y, V(r)), null !== iZ)
                        for (r = iZ.return; null !== r;) {
                            var n = r;
                            switch (rC(n), n.tag) {
                                case 1:
                                    null != (n = n.type.childContextTypes) && ts();
                                    break;
                                case 3:
                                    rQ(), e7(tn), e7(tr), rq();
                                    break;
                                case 5:
                                    rY(n);
                                    break;
                                case 4:
                                    rQ();
                                    break;
                                case 13:
                                case 19:
                                    e7(rX);
                                    break;
                                case 10:
                                    tZ(n.type._context);
                                    break;
                                case 22:
                                case 23:
                                    a_()
                            }
                            r = r.return
                        }
                    if (iW = e, iZ = e = aN(e.current, null), iq = i$ = t, i1 = 0, i2 = null, i8 = i3 = i9 = 0, i6 = i4 = null, null !== t1) {
                        for (t = 0; t < t1.length; t++)
                            if (null !== (n = (r = t1[t]).interleaved)) {
                                r.interleaved = null;
                                var i = n.next,
                                    a = r.pending;
                                if (null !== a) {
                                    var o = a.next;
                                    a.next = i, n.next = o
                                }
                                r.pending = n
                            }
                        t1 = null
                    }
                    return e
                }

                function aE(e, t) {
                    for (;;) {
                        var r = iZ;
                        try {
                            if (tX(), r$.current = nL, r8) {
                                for (var n = r2.memoizedState; null !== n;) {
                                    var i = n.queue;
                                    null !== i && (i.pending = null), n = n.next
                                }
                                r8 = !1
                            }
                            if (r1 = 0, r3 = r9 = r2 = null, r4 = !1, r6 = 0, iV.current = null, null === r || null === r.return) {
                                i1 = 1, i2 = t, iZ = null;
                                break
                            }
                            e: {
                                var a = e,
                                    o = r.return,
                                    s = r,
                                    l = t;
                                if (t = iq, s.flags |= 32768, null !== l && "object" == typeof l && "function" == typeof l.then) {
                                    var u = l,
                                        c = s,
                                        f = c.tag;
                                    if (0 == (1 & c.mode) && (0 === f || 11 === f || 15 === f)) {
                                        var h = c.alternate;
                                        h ? (c.updateQueue = h.updateQueue, c.memoizedState = h.memoizedState, c.lanes = h.lanes) : (c.updateQueue = null, c.memoizedState = null)
                                    }
                                    var p = nQ(o);
                                    if (null !== p) {
                                        p.flags &= -257, nV(p, o, s, a, t), 1 & p.mode && nK(a, u, t), t = p, l = u;
                                        var m = t.updateQueue;
                                        if (null === m) {
                                            var g = new Set;
                                            g.add(l), t.updateQueue = g
                                        } else m.add(l);
                                        break e
                                    }
                                    if (0 == (1 & t)) {
                                        nK(a, u, t), aM();
                                        break e
                                    }
                                    l = Error(d(426))
                                } else if (rb && 1 & s.mode) {
                                    var A = nQ(o);
                                    if (null !== A) {
                                        0 == (65536 & A.flags) && (A.flags |= 256), nV(A, o, s, a, t), rI(l);
                                        break e
                                    }
                                }
                                a = l,
                                4 !== i1 && (i1 = 2),
                                null === i4 ? i4 = [a] : i4.push(a),
                                l = nk(l, s),
                                s = o;do {
                                    switch (s.tag) {
                                        case 3:
                                            s.flags |= 65536, t &= -t, s.lanes |= t;
                                            var v = nz(s, l, t);
                                            t5(s, v);
                                            break e;
                                        case 1:
                                            a = l;
                                            var y = s.type,
                                                C = s.stateNode;
                                            if (0 == (128 & s.flags) && ("function" == typeof y.getDerivedStateFromError || null !== C && "function" == typeof C.componentDidCatch && (null === an || !an.has(C)))) {
                                                s.flags |= 65536, t &= -t, s.lanes |= t;
                                                var B = nj(s, a, t);
                                                t5(s, B);
                                                break e
                                            }
                                    }
                                    s = s.return
                                } while (null !== s)
                            }
                            aF(r)
                        } catch (e) {
                            t = e, iZ === r && null !== r && (iZ = r = r.return);
                            continue
                        }
                        break
                    }
                }

                function aw() {
                    var e = iQ.current;
                    return iQ.current = nL, null === e ? nL : e
                }

                function aM() {
                    (0 === i1 || 3 === i1 || 2 === i1) && (i1 = 4), null === iW || 0 == (268435455 & i9) && 0 == (268435455 & i3) || ay(iW, iq)
                }

                function aT(e, t) {
                    var r = iX;
                    iX |= 2;
                    var n = aw();
                    for (iW === e && iq === t || ab(e, t);;) try {
                        ! function() {
                            for (; null !== iZ;) ax(iZ)
                        }();
                        break
                    } catch (t) {
                        aE(e, t)
                    }
                    if (tX(), iX = r, iQ.current = n, null !== iZ) throw Error(d(261));
                    return iW = null, iq = 0, i1
                }

                function ax(e) {
                    var t = o(e.alternate, e, i$);
                    e.memoizedProps = e.pendingProps, null === t ? aF(e) : iZ = t, iV.current = null
                }

                function aF(e) {
                    var r = e;
                    do {
                        var o = r.alternate;
                        if (e = r.return, 0 == (32768 & r.flags)) {
                            if (null !== (o = function(e, r, o) {
                                    var s = r.pendingProps;
                                    switch (rC(r), r.tag) {
                                        case 2:
                                        case 16:
                                        case 15:
                                        case 0:
                                        case 11:
                                        case 7:
                                        case 8:
                                        case 12:
                                        case 9:
                                        case 14:
                                            return nq(r), null;
                                        case 1:
                                        case 17:
                                            return to(r.type) && ts(), nq(r), null;
                                        case 3:
                                            return s = r.stateNode, rQ(), e7(tn), e7(tr), rq(), s.pendingContext && (s.context = s.pendingContext, s.pendingContext = null), (null === e || null === e.child) && (rR(r) ? nY(r) : null === e || e.memoizedState.isDehydrated && 0 == (256 & r.flags) || (r.flags |= 1024, null !== rw && (av(rw), rw = null))), n(e, r), nq(r), null;
                                        case 5:
                                            rY(r), o = rj(rz.current);
                                            var l = r.type;
                                            if (null !== e && null != r.stateNode) i(e, r, l, s, o), e.ref !== r.ref && (r.flags |= 512, r.flags |= 2097152);
                                            else {
                                                if (!s) {
                                                    if (null === r.stateNode) throw Error(d(166));
                                                    return nq(r), null
                                                }
                                                if (e = rj(rN.current), rR(r)) {
                                                    if (!q) throw Error(d(175));
                                                    e = eK(r.stateNode, r.type, r.memoizedProps, o, e, r, !rE), r.updateQueue = e, null !== e && nY(r)
                                                } else {
                                                    var u = k(l, s, o, e, r);
                                                    t(u, r, !1, !1), r.stateNode = u, J(u, l, s, o, e) && nY(r)
                                                }
                                                null !== r.ref && (r.flags |= 512, r.flags |= 2097152)
                                            }
                                            return nq(r), null;
                                        case 6:
                                            if (e && null != r.stateNode) a(e, r, e.memoizedProps, s);
                                            else {
                                                if ("string" != typeof s && null === r.stateNode) throw Error(d(166));
                                                if (e = rj(rz.current), o = rj(rN.current), rR(r)) {
                                                    if (!q) throw Error(d(176));
                                                    if ((o = eQ(e = r.stateNode, s = r.memoizedProps, r, !rE)) && null !== (l = rB)) switch (u = 0 != (1 & l.mode), l.tag) {
                                                        case 3:
                                                            e0(l.stateNode.containerInfo, e, s, u);
                                                            break;
                                                        case 5:
                                                            e1(l.type, l.memoizedProps, l.stateNode, e, s, u)
                                                    }
                                                    o && nY(r)
                                                } else r.stateNode = K(s, e, o, r)
                                            }
                                            return nq(r), null;
                                        case 13:
                                            if (e7(rX), s = r.memoizedState, rb && null !== r_ && 0 != (1 & r.mode) && 0 == (128 & r.flags)) {
                                                for (e = r_; e;) e = eN(e);
                                                return rO(), r.flags |= 98560, r
                                            }
                                            if (null !== s && null !== s.dehydrated) {
                                                if (s = rR(r), null === e) {
                                                    if (!s) throw Error(d(318));
                                                    if (!q) throw Error(d(344));
                                                    if (!(e = null !== (e = r.memoizedState) ? e.dehydrated : null)) throw Error(d(317));
                                                    eV(e, r)
                                                } else rO(), 0 == (128 & r.flags) && (r.memoizedState = null), r.flags |= 4;
                                                return nq(r), null
                                            }
                                            if (null !== rw && (av(rw), rw = null), 0 != (128 & r.flags)) return r.lanes = o, r;
                                            return s = null !== s, o = !1, null === e ? rR(r) : o = null !== e.memoizedState, s && !o && (r.child.flags |= 8192, 0 != (1 & r.mode) && (null === e || 0 != (1 & rX.current) ? 0 === i1 && (i1 = 3) : aM())), null !== r.updateQueue && (r.flags |= 4), nq(r), null;
                                        case 4:
                                            return rQ(), n(e, r), null === e && ee(r.stateNode.containerInfo), nq(r), null;
                                        case 10:
                                            return tZ(r.type._context), nq(r), null;
                                        case 19:
                                            if (e7(rX), null === (l = r.memoizedState)) return nq(r), null;
                                            if (s = 0 != (128 & r.flags), null === (u = l.rendering)) {
                                                if (s) nZ(l, !1);
                                                else {
                                                    if (0 !== i1 || null !== e && 0 != (128 & e.flags))
                                                        for (e = r.child; null !== e;) {
                                                            if (null !== (u = rW(e))) {
                                                                for (r.flags |= 128, nZ(l, !1), null !== (e = u.updateQueue) && (r.updateQueue = e, r.flags |= 4), r.subtreeFlags = 0, e = o, s = r.child; null !== s;) o = s, l = e, o.flags &= 14680066, null === (u = o.alternate) ? (o.childLanes = 0, o.lanes = l, o.child = null, o.subtreeFlags = 0, o.memoizedProps = null, o.memoizedState = null, o.updateQueue = null, o.dependencies = null, o.stateNode = null) : (o.childLanes = u.childLanes, o.lanes = u.lanes, o.child = u.child, o.subtreeFlags = 0, o.deletions = null, o.memoizedProps = u.memoizedProps, o.memoizedState = u.memoizedState, o.updateQueue = u.updateQueue, o.type = u.type, l = u.dependencies, o.dependencies = null === l ? null : {
                                                                    lanes: l.lanes,
                                                                    firstContext: l.firstContext
                                                                }), s = s.sibling;
                                                                return te(rX, 1 & rX.current | 2), r.child
                                                            }
                                                            e = e.sibling
                                                        }
                                                    null !== l.tail && tF() > i7 && (r.flags |= 128, s = !0, nZ(l, !1), r.lanes = 4194304)
                                                }
                                            } else {
                                                if (!s) {
                                                    if (null !== (e = rW(u))) {
                                                        if (r.flags |= 128, s = !0, null !== (e = e.updateQueue) && (r.updateQueue = e, r.flags |= 4), nZ(l, !0), null === l.tail && "hidden" === l.tailMode && !u.alternate && !rb) return nq(r), null
                                                    } else 2 * tF() - l.renderingStartTime > i7 && 1073741824 !== o && (r.flags |= 128, s = !0, nZ(l, !1), r.lanes = 4194304)
                                                }
                                                l.isBackwards ? (u.sibling = r.child, r.child = u) : (null !== (e = l.last) ? e.sibling = u : r.child = u, l.last = u)
                                            }
                                            if (null !== l.tail) return r = l.tail, l.rendering = r, l.tail = r.sibling, l.renderingStartTime = tF(), r.sibling = null, e = rX.current, te(rX, s ? 1 & e | 2 : 1 & e), r;
                                            return nq(r), null;
                                        case 22:
                                        case 23:
                                            return a_(), s = null !== r.memoizedState, null !== e && null !== e.memoizedState !== s && (r.flags |= 8192), s && 0 != (1 & r.mode) ? 0 != (1073741824 & i$) && (nq(r), W && 6 & r.subtreeFlags && (r.flags |= 8192)) : nq(r), null;
                                        case 24:
                                        case 25:
                                            return null
                                    }
                                    throw Error(d(156, r.tag))
                                }(o, r, i$))) {
                                iZ = o;
                                return
                            }
                        } else {
                            if (null !== (o = function(e, t) {
                                    switch (rC(t), t.tag) {
                                        case 1:
                                            return to(t.type) && ts(), 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, t) : null;
                                        case 3:
                                            return rQ(), e7(tn), e7(tr), rq(), 0 != (65536 & (e = t.flags)) && 0 == (128 & e) ? (t.flags = -65537 & e | 128, t) : null;
                                        case 5:
                                            return rY(t), null;
                                        case 13:
                                            if (e7(rX), null !== (e = t.memoizedState) && null !== e.dehydrated) {
                                                if (null === t.alternate) throw Error(d(340));
                                                rO()
                                            }
                                            return 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, t) : null;
                                        case 19:
                                            return e7(rX), null;
                                        case 4:
                                            return rQ(), null;
                                        case 10:
                                            return tZ(t.type._context), null;
                                        case 22:
                                        case 23:
                                            return a_(), null;
                                        default:
                                            return null
                                    }
                                }(o, r))) {
                                o.flags &= 32767, iZ = o;
                                return
                            }
                            if (null !== e) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
                            else {
                                i1 = 6, iZ = null;
                                return
                            }
                        }
                        if (null !== (r = r.sibling)) {
                            iZ = r;
                            return
                        }
                        iZ = r = e
                    } while (null !== r);
                    0 === i1 && (i1 = 5)
                }

                function aS(e, t) {
                    var r = tb,
                        n = iY.transition;
                    try {
                        iY.transition = null, tb = 1,
                            function(e, t, r) {
                                do aR(); while (null !== aa);
                                if (0 != (6 & iX)) throw Error(d(327));
                                var n = e.finishedWork,
                                    i = e.finishedLanes;
                                if (null !== n) {
                                    if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(d(177));
                                    e.callbackNode = null, e.callbackPriority = 0;
                                    var a = n.lanes | n.childLanes;
                                    if (function(e, t) {
                                            var r = e.pendingLanes & ~t;
                                            e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
                                            var n = e.eventTimes;
                                            for (e = e.expirationTimes; 0 < r;) {
                                                var i = 31 - tf(r),
                                                    a = 1 << i;
                                                t[i] = 0, n[i] = -1, e[i] = -1, r &= ~a
                                            }
                                        }(e, a), e === iW && (iZ = iW = null, iq = 0), 0 == (2064 & n.subtreeFlags) && 0 == (2064 & n.flags) || ai || (ai = !0, o = tO, s = function() {
                                            return aR(), null
                                        }, tw(o, s)), a = 0 != (15990 & n.flags), 0 != (15990 & n.subtreeFlags) || a) {
                                        a = iY.transition, iY.transition = null;
                                        var o, s, l, u, c = tb;
                                        tb = 1;
                                        var f = iX;
                                        iX |= 4, iV.current = null,
                                            function(e, t) {
                                                for (U(e.containerInfo), ig = t; null !== ig;)
                                                    if (t = (e = ig).child, 0 != (1028 & e.subtreeFlags) && null !== t) t.return = e, ig = t;
                                                    else
                                                        for (; null !== ig;) {
                                                            e = ig;
                                                            try {
                                                                var r = e.alternate;
                                                                if (0 != (1024 & e.flags)) switch (e.tag) {
                                                                    case 0:
                                                                    case 11:
                                                                    case 15:
                                                                    case 5:
                                                                    case 6:
                                                                    case 4:
                                                                    case 17:
                                                                        break;
                                                                    case 1:
                                                                        if (null !== r) {
                                                                            var n = r.memoizedProps,
                                                                                i = r.memoizedState,
                                                                                a = e.stateNode,
                                                                                o = a.getSnapshotBeforeUpdate(e.elementType === e.type ? n : tj(e.type, n), i);
                                                                            a.__reactInternalSnapshotBeforeUpdate = o
                                                                        }
                                                                        break;
                                                                    case 3:
                                                                        W && eT(e.stateNode.containerInfo);
                                                                        break;
                                                                    default:
                                                                        throw Error(d(163))
                                                                }
                                                            } catch (t) {
                                                                aI(e, e.return, t)
                                                            }
                                                            if (null !== (t = e.sibling)) {
                                                                t.return = e.return, ig = t;
                                                                break
                                                            }
                                                            ig = e.return
                                                        }
                                                r = iy, iy = !1
                                            }(e, n),
                                            function(e, t) {
                                                for (ig = t; null !== ig;) {
                                                    var r = (t = ig).deletions;
                                                    if (null !== r)
                                                        for (var n = 0; n < r.length; n++) {
                                                            var i = r[n];
                                                            try {
                                                                var a = e;
                                                                W ? ix(a, i, t) : iE(a, i, t);
                                                                var o = i.alternate;
                                                                null !== o && (o.return = null), i.return = null
                                                            } catch (e) {
                                                                aI(i, t, e)
                                                            }
                                                        }
                                                    if (r = t.child, 0 != (12854 & t.subtreeFlags) && null !== r) r.return = t, ig = r;
                                                    else
                                                        for (; null !== ig;) {
                                                            t = ig;
                                                            try {
                                                                var s = t.flags;
                                                                if (32 & s && W && e_(t.stateNode), 512 & s) {
                                                                    var l = t.alternate;
                                                                    if (null !== l) {
                                                                        var u = l.ref;
                                                                        null !== u && ("function" == typeof u ? u(null) : u.current = null)
                                                                    }
                                                                }
                                                                if (8192 & s) switch (t.tag) {
                                                                    case 13:
                                                                        if (null !== t.memoizedState) {
                                                                            var c = t.alternate;
                                                                            (null === c || null === c.memoizedState) && (i5 = tF())
                                                                        }
                                                                        break;
                                                                    case 22:
                                                                        var d = null !== t.memoizedState,
                                                                            f = t.alternate,
                                                                            h = null !== f && null !== f.memoizedState;
                                                                        if (r = t, W) {
                                                                            e: if (n = r, i = d, a = null, W)
                                                                                for (var p = n;;) {
                                                                                    if (5 === p.tag) {
                                                                                        if (null === a) {
                                                                                            a = p;
                                                                                            var m = p.stateNode;
                                                                                            i ? eb(m) : ew(p.stateNode, p.memoizedProps)
                                                                                        }
                                                                                    } else if (6 === p.tag) {
                                                                                        if (null === a) {
                                                                                            var g = p.stateNode;
                                                                                            i ? eE(g) : eM(g, p.memoizedProps)
                                                                                        }
                                                                                    } else if ((22 !== p.tag && 23 !== p.tag || null === p.memoizedState || p === n) && null !== p.child) {
                                                                                        p.child.return = p, p = p.child;
                                                                                        continue
                                                                                    }
                                                                                    if (p === n) break;
                                                                                    for (; null === p.sibling;) {
                                                                                        if (null === p.return || p.return === n) break e;
                                                                                        a === p && (a = null), p = p.return
                                                                                    }
                                                                                    a === p && (a = null), p.sibling.return = p.return, p = p.sibling
                                                                                }
                                                                        }
                                                                        if (d && !h && 0 != (1 & r.mode)) {
                                                                            ig = r;
                                                                            for (var A = r.child; null !== A;) {
                                                                                for (r = ig = A; null !== ig;) {
                                                                                    var v = (n = ig).child;
                                                                                    switch (n.tag) {
                                                                                        case 0:
                                                                                        case 11:
                                                                                        case 14:
                                                                                        case 15:
                                                                                            iC(4, n, n.return);
                                                                                            break;
                                                                                        case 1:
                                                                                            iA(n, n.return);
                                                                                            var y = n.stateNode;
                                                                                            if ("function" == typeof y.componentWillUnmount) {
                                                                                                var C = n.return;
                                                                                                try {
                                                                                                    y.props = n.memoizedProps, y.state = n.memoizedState, y.componentWillUnmount()
                                                                                                } catch (e) {
                                                                                                    aI(n, C, e)
                                                                                                }
                                                                                            }
                                                                                            break;
                                                                                        case 5:
                                                                                            iA(n, n.return);
                                                                                            break;
                                                                                        case 22:
                                                                                            if (null !== n.memoizedState) {
                                                                                                iO(r);
                                                                                                continue
                                                                                            }
                                                                                    }
                                                                                    null !== v ? (v.return = n, ig = v) : iO(r)
                                                                                }
                                                                                A = A.sibling
                                                                            }
                                                                        }
                                                                }
                                                                switch (4102 & s) {
                                                                    case 2:
                                                                        iT(t), t.flags &= -3;
                                                                        break;
                                                                    case 6:
                                                                        iT(t), t.flags &= -3, iF(t.alternate, t);
                                                                        break;
                                                                    case 4096:
                                                                        t.flags &= -4097;
                                                                        break;
                                                                    case 4100:
                                                                        t.flags &= -4097, iF(t.alternate, t);
                                                                        break;
                                                                    case 4:
                                                                        iF(t.alternate, t)
                                                                }
                                                            } catch (e) {
                                                                aI(t, t.return, e)
                                                            }
                                                            if (null !== (r = t.sibling)) {
                                                                r.return = t.return, ig = r;
                                                                break
                                                            }
                                                            ig = t.return
                                                        }
                                                }
                                            }(e, n, i), G(e.containerInfo), e.current = n, l = n, u = e, ig = l,
                                            function e(t, r, n) {
                                                for (var i = 0 != (1 & t.mode); null !== ig;) {
                                                    var a = ig,
                                                        o = a.child;
                                                    if (22 === a.tag && i) {
                                                        var s = null !== a.memoizedState || ih;
                                                        if (!s) {
                                                            var l = a.alternate,
                                                                u = null !== l && null !== l.memoizedState || ip;
                                                            l = ih;
                                                            var c = ip;
                                                            if (ih = s, (ip = u) && !c)
                                                                for (ig = a; null !== ig;) u = (s = ig).child, 22 === s.tag && null !== s.memoizedState ? iI(a) : null !== u ? (u.return = s, ig = u) : iI(a);
                                                            for (; null !== o;) ig = o, e(o, r, n), o = o.sibling;
                                                            ig = a, ih = l, ip = c
                                                        }
                                                        iR(t, r, n)
                                                    } else 0 != (8772 & a.subtreeFlags) && null !== o ? (o.return = a, ig = o) : iR(t, r, n)
                                                }
                                            }(l, u, i), tx(), iX = f, tb = c, iY.transition = a
                                    } else e.current = n;
                                    if (ai && (ai = !1, aa = e, ao = i), 0 === (a = e.pendingLanes) && (an = null), function(e) {
                                            if (tP && "function" == typeof tP.onCommitFiberRoot) try {
                                                tP.onCommitFiberRoot(tD, e, void 0, 128 == (128 & e.current.flags))
                                            } catch (e) {}
                                        }(n.stateNode, r), am(e, tF()), null !== t)
                                        for (r = e.onRecoverableError, n = 0; n < t.length; n++) r(t[n]);
                                    if (at) throw at = !1, e = ar, ar = null, e;
                                    0 != (1 & ao) && 0 !== e.tag && aR(), 0 != (1 & (a = e.pendingLanes)) ? e === al ? as++ : (as = 0, al = e) : as = 0, tN()
                                }
                            }(e, t, r)
                    } finally {
                        iY.transition = n, tb = r
                    }
                    return null
                }

                function aR() {
                    if (null !== aa) {
                        var e = tE(ao),
                            t = iY.transition,
                            r = tb;
                        try {
                            if (iY.transition = null, tb = 16 > e ? 16 : e, null === aa) var n = !1;
                            else {
                                if (e = aa, aa = null, ao = 0, 0 != (6 & iX)) throw Error(d(331));
                                var i = iX;
                                for (iX |= 4, ig = e.current; null !== ig;) {
                                    var a = ig,
                                        o = a.child;
                                    if (0 != (16 & ig.flags)) {
                                        var s = a.deletions;
                                        if (null !== s) {
                                            for (var l = 0; l < s.length; l++) {
                                                var u = s[l];
                                                for (ig = u; null !== ig;) {
                                                    var c = ig;
                                                    switch (c.tag) {
                                                        case 0:
                                                        case 11:
                                                        case 15:
                                                            iC(8, c, a)
                                                    }
                                                    var f = c.child;
                                                    if (null !== f) f.return = c, ig = f;
                                                    else
                                                        for (; null !== ig;) {
                                                            var h = (c = ig).sibling,
                                                                p = c.return;
                                                            if (! function e(t) {
                                                                    var r = t.alternate;
                                                                    null !== r && (t.alternate = null, e(r)), t.child = null, t.deletions = null, t.sibling = null, 5 === t.tag && null !== (r = t.stateNode) && er(r), t.stateNode = null, t.return = null, t.dependencies = null, t.memoizedProps = null, t.memoizedState = null, t.pendingProps = null, t.stateNode = null, t.updateQueue = null
                                                                }(c), c === u) {
                                                                ig = null;
                                                                break
                                                            }
                                                            if (null !== h) {
                                                                h.return = p, ig = h;
                                                                break
                                                            }
                                                            ig = p
                                                        }
                                                }
                                            }
                                            var m = a.alternate;
                                            if (null !== m) {
                                                var g = m.child;
                                                if (null !== g) {
                                                    m.child = null;
                                                    do {
                                                        var A = g.sibling;
                                                        g.sibling = null, g = A
                                                    } while (null !== g)
                                                }
                                            }
                                            ig = a
                                        }
                                    }
                                    if (0 != (2064 & a.subtreeFlags) && null !== o) o.return = a, ig = o;
                                    else
                                        for (; null !== ig;) {
                                            if (a = ig, 0 != (2048 & a.flags)) switch (a.tag) {
                                                case 0:
                                                case 11:
                                                case 15:
                                                    iC(9, a, a.return)
                                            }
                                            var v = a.sibling;
                                            if (null !== v) {
                                                v.return = a.return, ig = v;
                                                break
                                            }
                                            ig = a.return
                                        }
                                }
                                var y = e.current;
                                for (ig = y; null !== ig;) {
                                    var C = (o = ig).child;
                                    if (0 != (2064 & o.subtreeFlags) && null !== C) C.return = o, ig = C;
                                    else
                                        for (o = y; null !== ig;) {
                                            if (s = ig, 0 != (2048 & s.flags)) try {
                                                switch (s.tag) {
                                                    case 0:
                                                    case 11:
                                                    case 15:
                                                        iB(9, s)
                                                }
                                            } catch (e) {
                                                aI(s, s.return, e)
                                            }
                                            if (s === o) {
                                                ig = null;
                                                break
                                            }
                                            var B = s.sibling;
                                            if (null !== B) {
                                                B.return = s.return, ig = B;
                                                break
                                            }
                                            ig = s.return
                                        }
                                }
                                if (iX = i, tN(), tP && "function" == typeof tP.onPostCommitFiberRoot) try {
                                    tP.onPostCommitFiberRoot(tD, e)
                                } catch (e) {}
                                n = !0
                            }
                            return n
                        } finally {
                            tb = r, iY.transition = t
                        }
                    }
                    return !1
                }

                function aO(e, t, r) {
                    t = nz(e, t = nk(r, t), 1), t4(e, t), t = ad(), null !== (e = ap(e, 1)) && (tB(e, 1, t), am(e, t))
                }

                function aI(e, t, r) {
                    if (3 === e.tag) aO(e, e, r);
                    else
                        for (; null !== t;) {
                            if (3 === t.tag) {
                                aO(t, e, r);
                                break
                            }
                            if (1 === t.tag) {
                                var n = t.stateNode;
                                if ("function" == typeof t.type.getDerivedStateFromError || "function" == typeof n.componentDidCatch && (null === an || !an.has(n))) {
                                    e = nj(t, e = nk(r, e), 1), t4(t, e), e = ad(), null !== (t = ap(t, 1)) && (tB(t, 1, e), am(t, e));
                                    break
                                }
                            }
                            t = t.return
                        }
                }

                function aD(e, t, r) {
                    var n = e.pingCache;
                    null !== n && n.delete(t), t = ad(), e.pingedLanes |= e.suspendedLanes & r, iW === e && (iq & r) === r && (4 === i1 || 3 === i1 && (130023424 & iq) === iq && 500 > tF() - i5 ? ab(e, 0) : i8 |= r), am(e, t)
                }

                function aP(e, t) {
                    0 === t && (0 == (1 & e.mode) ? t = 1 : (t = tg, 0 == (130023424 & (tg <<= 1)) && (tg = 4194304)));
                    var r = ad();
                    null !== (e = ap(e, t)) && (tB(e, t, r), am(e, r))
                }

                function aL(e) {
                    var t = e.memoizedState,
                        r = 0;
                    null !== t && (r = t.retryLane), aP(e, r)
                }

                function aH(e, t) {
                    var r = 0;
                    switch (e.tag) {
                        case 13:
                            var n = e.stateNode,
                                i = e.memoizedState;
                            null !== i && (r = i.retryLane);
                            break;
                        case 19:
                            n = e.stateNode;
                            break;
                        default:
                            throw Error(d(314))
                    }
                    null !== n && n.delete(t), aP(e, r)
                }

                function aU(e, t, r, n) {
                    this.tag = e, this.key = r, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = n, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
                }

                function aG(e, t, r, n) {
                    return new aU(e, t, r, n)
                }

                function ak(e) {
                    return !(!(e = e.prototype) || !e.isReactComponent)
                }

                function aN(e, t) {
                    var r = e.alternate;
                    return null === r ? ((r = aG(e.tag, t, e.key, e.mode)).elementType = e.elementType, r.type = e.type, r.stateNode = e.stateNode, r.alternate = e, e.alternate = r) : (r.pendingProps = t, r.type = e.type, r.flags = 0, r.subtreeFlags = 0, r.deletions = null), r.flags = 14680064 & e.flags, r.childLanes = e.childLanes, r.lanes = e.lanes, r.child = e.child, r.memoizedProps = e.memoizedProps, r.memoizedState = e.memoizedState, r.updateQueue = e.updateQueue, t = e.dependencies, r.dependencies = null === t ? null : {
                        lanes: t.lanes,
                        firstContext: t.firstContext
                    }, r.sibling = e.sibling, r.index = e.index, r.ref = e.ref, r
                }

                function aJ(e, t, r, n, i, a) {
                    var o = 2;
                    if (n = e, "function" == typeof e) ak(e) && (o = 1);
                    else if ("string" == typeof e) o = 5;
                    else e: switch (e) {
                        case m:
                            return az(r.children, i, a, t);
                        case g:
                            o = 8, i |= 8;
                            break;
                        case A:
                            return (e = aG(12, r, t, 2 | i)).elementType = A, e.lanes = a, e;
                        case B:
                            return (e = aG(13, r, t, i)).elementType = B, e.lanes = a, e;
                        case _:
                            return (e = aG(19, r, t, i)).elementType = _, e.lanes = a, e;
                        case w:
                            return aj(r, i, a, t);
                        default:
                            if ("object" == typeof e && null !== e) switch (e.$$typeof) {
                                case v:
                                    o = 10;
                                    break e;
                                case y:
                                    o = 9;
                                    break e;
                                case C:
                                    o = 11;
                                    break e;
                                case b:
                                    o = 14;
                                    break e;
                                case E:
                                    o = 16, n = null;
                                    break e
                            }
                            throw Error(d(130, null == e ? e : typeof e, ""))
                    }
                    return (t = aG(o, r, t, i)).elementType = e, t.type = n, t.lanes = a, t
                }

                function az(e, t, r, n) {
                    return (e = aG(7, e, n, t)).lanes = r, e
                }

                function aj(e, t, r, n) {
                    return (e = aG(22, e, n, t)).elementType = w, e.lanes = r, e.stateNode = {}, e
                }

                function aK(e, t, r) {
                    return (e = aG(6, e, null, t)).lanes = r, e
                }

                function aQ(e, t, r) {
                    return (t = aG(4, null !== e.children ? e.children : [], e.key, t)).lanes = r, t.stateNode = {
                        containerInfo: e.containerInfo,
                        pendingChildren: null,
                        implementation: e.implementation
                    }, t
                }

                function aV(e, t, r, n, i) {
                    this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = Y, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = tC(0), this.expirationTimes = tC(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = tC(0), this.identifierPrefix = n, this.onRecoverableError = i, q && (this.mutableSourceEagerHydrationData = null)
                }

                function aY(e, t, r, n, i, a, o, s, l) {
                    return e = new aV(e, t, r, s, l), 1 === t ? (t = 1, !0 === a && (t |= 8)) : t = 0, a = aG(3, null, null, t), e.current = a, a.stateNode = e, a.memoizedState = {
                        element: n,
                        isDehydrated: r,
                        cache: null,
                        transitions: null
                    }, t9(a), e
                }

                function aX(e) {
                    if (!e) return tt;
                    e = e._reactInternals;
                    e: {
                        if (F(e) !== e || 1 !== e.tag) throw Error(d(170));
                        var t = e;do {
                            switch (t.tag) {
                                case 3:
                                    t = t.stateNode.context;
                                    break e;
                                case 1:
                                    if (to(t.type)) {
                                        t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                                        break e
                                    }
                            }
                            t = t.return
                        } while (null !== t);
                        throw Error(d(171))
                    }
                    if (1 === e.tag) {
                        var r = e.type;
                        if (to(r)) return tu(e, r, t)
                    }
                    return t
                }

                function aW(e) {
                    var t = e._reactInternals;
                    if (void 0 === t) {
                        if ("function" == typeof e.render) throw Error(d(188));
                        throw Error(d(268, e = Object.keys(e).join(",")))
                    }
                    return null === (e = O(t)) ? null : e.stateNode
                }

                function aZ(e, t) {
                    if (null !== (e = e.memoizedState) && null !== e.dehydrated) {
                        var r = e.retryLane;
                        e.retryLane = 0 !== r && r < t ? r : t
                    }
                }

                function aq(e, t) {
                    aZ(e, t), (e = e.alternate) && aZ(e, t)
                }

                function a$(e) {
                    return null === (e = O(e)) ? null : e.stateNode
                }

                function a0() {
                    return null
                }
                return o = function(e, t, r) {
                    if (null !== e) {
                        if (e.memoizedProps !== t.pendingProps || tn.current) n0 = !0;
                        else {
                            if (0 == (e.lanes & r) && 0 == (128 & t.flags)) return n0 = !1,
                                function(e, t, r) {
                                    switch (t.tag) {
                                        case 3:
                                            ie(t), rO();
                                            break;
                                        case 5:
                                            rV(t);
                                            break;
                                        case 1:
                                            to(t.type) && tc(t);
                                            break;
                                        case 4:
                                            rK(t, t.stateNode.containerInfo);
                                            break;
                                        case 10:
                                            tW(t, t.type._context, t.memoizedProps.value);
                                            break;
                                        case 13:
                                            var n = t.memoizedState;
                                            if (null !== n) {
                                                if (null !== n.dehydrated) return te(rX, 1 & rX.current), t.flags |= 128, null;
                                                if (0 != (r & t.child.childLanes)) return ia(e, t, r);
                                                return te(rX, 1 & rX.current), null !== (e = id(e, t, r)) ? e.sibling : null
                                            }
                                            te(rX, 1 & rX.current);
                                            break;
                                        case 19:
                                            if (n = 0 != (r & t.childLanes), 0 != (128 & e.flags)) {
                                                if (n) return ic(e, t, r);
                                                t.flags |= 128
                                            }
                                            var i = t.memoizedState;
                                            if (null !== i && (i.rendering = null, i.tail = null, i.lastEffect = null), te(rX, rX.current), !n) return null;
                                            break;
                                        case 22:
                                        case 23:
                                            return t.lanes = 0, n8(e, t, r)
                                    }
                                    return id(e, t, r)
                                }(e, t, r);
                            n0 = 0 != (131072 & e.flags)
                        }
                    } else n0 = !1, rb && 0 != (1048576 & t.flags) && rv(t, rd, t.index);
                    switch (t.lanes = 0, t.tag) {
                        case 2:
                            var n = t.type;
                            null !== e && (e.alternate = null, t.alternate = null, t.flags |= 2), e = t.pendingProps;
                            var i = ta(t, tr.current);
                            t$(t, r), i = nt(null, t, n, e, i, r);
                            var a = nr();
                            return t.flags |= 1, "object" == typeof i && null !== i && "function" == typeof i.render && void 0 === i.$$typeof ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, to(n) ? (a = !0, tc(t)) : a = !1, t.memoizedState = null !== i.state && void 0 !== i.state ? i.state : null, t9(t), i.updater = rn, t.stateNode = i, i._reactInternals = t, rs(t, n, e, r), t = n7(null, t, n, !0, a, r)) : (t.tag = 0, rb && a && ry(t), n1(null, t, i, r), t = t.child), t;
                        case 16:
                            n = t.elementType;
                            e: {
                                switch (null !== e && (e.alternate = null, t.alternate = null, t.flags |= 2), e = t.pendingProps, n = (i = n._init)(n._payload), t.type = n, i = t.tag = function(e) {
                                    if ("function" == typeof e) return ak(e) ? 1 : 0;
                                    if (null != e) {
                                        if ((e = e.$$typeof) === C) return 11;
                                        if (e === b) return 14
                                    }
                                    return 2
                                }(n), e = tj(n, e), i) {
                                    case 0:
                                        t = n6(null, t, n, e, r);
                                        break e;
                                    case 1:
                                        t = n5(null, t, n, e, r);
                                        break e;
                                    case 11:
                                        t = n2(null, t, n, e, r);
                                        break e;
                                    case 14:
                                        t = n9(null, t, n, tj(n.type, e), r);
                                        break e
                                }
                                throw Error(d(306, n, ""))
                            }
                            return t;
                        case 0:
                            return n = t.type, i = t.pendingProps, i = t.elementType === n ? i : tj(n, i), n6(e, t, n, i, r);
                        case 1:
                            return n = t.type, i = t.pendingProps, i = t.elementType === n ? i : tj(n, i), n5(e, t, n, i, r);
                        case 3:
                            e: {
                                if (ie(t), null === e) throw Error(d(387));n = t.pendingProps,
                                i = (a = t.memoizedState).element,
                                t3(e, t),
                                t7(t, n, null, r);
                                var o = t.memoizedState;
                                if (n = o.element, q && a.isDehydrated) {
                                    if (a = {
                                            element: n,
                                            isDehydrated: !1,
                                            cache: o.cache,
                                            transitions: o.transitions
                                        }, t.updateQueue.baseState = a, t.memoizedState = a, 256 & t.flags) {
                                        t = it(e, t, n, r, i = Error(d(423)));
                                        break e
                                    }
                                    if (n !== i) {
                                        t = it(e, t, n, r, i = Error(d(424)));
                                        break e
                                    }
                                    for (q && (r_ = ez(t.stateNode.containerInfo), rB = t, rb = !0, rw = null, rE = !1), r = rG(t, null, n, r), t.child = r; r;) r.flags = -3 & r.flags | 4096, r = r.sibling
                                } else {
                                    if (rO(), n === i) {
                                        t = id(e, t, r);
                                        break e
                                    }
                                    n1(e, t, n, r)
                                }
                                t = t.child
                            }
                            return t;
                        case 5:
                            return rV(t), null === e && rF(t), n = t.type, i = t.pendingProps, a = null !== e ? e.memoizedProps : null, o = i.children, j(n, i) ? o = null : null !== a && j(n, a) && (t.flags |= 32), n4(e, t), n1(e, t, o, r), t.child;
                        case 6:
                            return null === e && rF(t), null;
                        case 13:
                            return ia(e, t, r);
                        case 4:
                            return rK(t, t.stateNode.containerInfo), n = t.pendingProps, null === e ? t.child = rU(t, null, n, r) : n1(e, t, n, r), t.child;
                        case 11:
                            return n = t.type, i = t.pendingProps, i = t.elementType === n ? i : tj(n, i), n2(e, t, n, i, r);
                        case 7:
                            return n1(e, t, t.pendingProps, r), t.child;
                        case 8:
                        case 12:
                            return n1(e, t, t.pendingProps.children, r), t.child;
                        case 10:
                            e: {
                                if (n = t.type._context, i = t.pendingProps, a = t.memoizedProps, tW(t, n, o = i.value), null !== a) {
                                    if (tL(a.value, o)) {
                                        if (a.children === i.children && !tn.current) {
                                            t = id(e, t, r);
                                            break e
                                        }
                                    } else
                                        for (null !== (a = t.child) && (a.return = t); null !== a;) {
                                            var s = a.dependencies;
                                            if (null !== s) {
                                                o = a.child;
                                                for (var l = s.firstContext; null !== l;) {
                                                    if (l.context === n) {
                                                        if (1 === a.tag) {
                                                            (l = t8(-1, r & -r)).tag = 2;
                                                            var u = a.updateQueue;
                                                            if (null !== u) {
                                                                var c = (u = u.shared).pending;
                                                                null === c ? l.next = l : (l.next = c.next, c.next = l), u.pending = l
                                                            }
                                                        }
                                                        a.lanes |= r, null !== (l = a.alternate) && (l.lanes |= r), tq(a.return, r, t), s.lanes |= r;
                                                        break
                                                    }
                                                    l = l.next
                                                }
                                            } else if (10 === a.tag) o = a.type === t.type ? null : a.child;
                                            else if (18 === a.tag) {
                                                if (null === (o = a.return)) throw Error(d(341));
                                                o.lanes |= r, null !== (s = o.alternate) && (s.lanes |= r), tq(o, r, t), o = a.sibling
                                            } else o = a.child;
                                            if (null !== o) o.return = a;
                                            else
                                                for (o = a; null !== o;) {
                                                    if (o === t) {
                                                        o = null;
                                                        break
                                                    }
                                                    if (null !== (a = o.sibling)) {
                                                        a.return = o.return, o = a;
                                                        break
                                                    }
                                                    o = o.return
                                                }
                                            a = o
                                        }
                                }
                                n1(e, t, i.children, r),
                                t = t.child
                            }
                            return t;
                        case 9:
                            return i = t.type, n = t.pendingProps.children, t$(t, r), n = n(i = t0(i)), t.flags |= 1, n1(e, t, n, r), t.child;
                        case 14:
                            return i = tj(n = t.type, t.pendingProps), i = tj(n.type, i), n9(e, t, n, i, r);
                        case 15:
                            return n3(e, t, t.type, t.pendingProps, r);
                        case 17:
                            return n = t.type, i = t.pendingProps, i = t.elementType === n ? i : tj(n, i), null !== e && (e.alternate = null, t.alternate = null, t.flags |= 2), t.tag = 1, to(n) ? (e = !0, tc(t)) : e = !1, t$(t, r), ra(t, n, i), rs(t, n, i, r), n7(null, t, n, !0, e, r);
                        case 19:
                            return ic(e, t, r);
                        case 22:
                            return n8(e, t, r)
                    }
                    throw Error(d(156, t.tag))
                }, s.attemptContinuousHydration = function(e) {
                    13 === e.tag && (ah(e, 134217728, ad()), aq(e, 134217728))
                }, s.attemptHydrationAtCurrentPriority = function(e) {
                    if (13 === e.tag) {
                        var t = ad(),
                            r = af(e);
                        ah(e, r, t), aq(e, r)
                    }
                }, s.attemptSynchronousHydration = function(e) {
                    switch (e.tag) {
                        case 3:
                            var t = e.stateNode;
                            if (t.current.memoizedState.isDehydrated) {
                                var r = tA(t.pendingLanes);
                                0 !== r && (t_(t, 1 | r), am(t, tF()), 0 == (6 & iX) && (ae(), tN()))
                            }
                            break;
                        case 13:
                            var n = ad();
                            aB(function() {
                                return ah(e, 1, n)
                            }), aq(e, 1)
                    }
                }, s.batchedUpdates = function(e, t) {
                    var r = iX;
                    iX |= 1;
                    try {
                        return e(t)
                    } finally {
                        0 === (iX = r) && (ae(), tU && tN())
                    }
                }, s.createComponentSelector = function(e) {
                    return {
                        $$typeof: iD,
                        value: e
                    }
                }, s.createContainer = function(e, t, r, n, i, a, o) {
                    return aY(e, t, !1, null, r, n, i, a, o)
                }, s.createHasPseudoClassSelector = function(e) {
                    return {
                        $$typeof: iP,
                        value: e
                    }
                }, s.createHydrationContainer = function(e, t, r, n, i, a, o, s, l) {
                    return (e = aY(r, n, !0, e, i, a, o, s, l)).context = aX(null), r = e.current, (a = t8(n = ad(), i = af(r))).callback = null != t ? t : null, t4(r, a), e.current.lanes = i, tB(e, i, n), am(e, n), e
                }, s.createPortal = function(e, t, r) {
                    var n = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
                    return {
                        $$typeof: p,
                        key: null == n ? null : "" + n,
                        children: e,
                        containerInfo: t,
                        implementation: r
                    }
                }, s.createRoleSelector = function(e) {
                    return {
                        $$typeof: iL,
                        value: e
                    }
                }, s.createTestNameSelector = function(e) {
                    return {
                        $$typeof: iH,
                        value: e
                    }
                }, s.createTextSelector = function(e) {
                    return {
                        $$typeof: iU,
                        value: e
                    }
                }, s.deferredUpdates = function(e) {
                    var t = tb,
                        r = iY.transition;
                    try {
                        return iY.transition = null, tb = 16, e()
                    } finally {
                        tb = t, iY.transition = r
                    }
                }, s.discreteUpdates = function(e, t, r, n, i) {
                    var a = tb,
                        o = iY.transition;
                    try {
                        return iY.transition = null, tb = 1, e(t, r, n, i)
                    } finally {
                        tb = a, iY.transition = o, 0 === iX && ae()
                    }
                }, s.findAllNodes = ij, s.findBoundingRects = function(e, t) {
                    if (!ea) throw Error(d(363));
                    t = ij(e, t), e = [];
                    for (var r = 0; r < t.length; r++) e.push(es(t[r]));
                    for (t = e.length - 1; 0 < t; t--) {
                        r = e[t];
                        for (var n = r.x, i = n + r.width, a = r.y, o = a + r.height, s = t - 1; 0 <= s; s--)
                            if (t !== s) {
                                var l = e[s],
                                    u = l.x,
                                    c = u + l.width,
                                    f = l.y,
                                    h = f + l.height;
                                if (n >= u && a >= f && i <= c && o <= h) {
                                    e.splice(t, 1);
                                    break
                                }
                                if (n !== u || r.width !== l.width || h < a || f > o) {
                                    if (!(a !== f || r.height !== l.height || c < n || u > i)) {
                                        u > n && (l.width += u - n, l.x = n), c < i && (l.width = i - u), e.splice(t, 1);
                                        break
                                    }
                                } else {
                                    f > a && (l.height += f - a, l.y = a), h < o && (l.height = o - f), e.splice(t, 1);
                                    break
                                }
                            }
                    }
                    return e
                }, s.findHostInstance = aW, s.findHostInstanceWithNoPortals = function(e) {
                    return null === (e = null !== (e = R(e)) ? function e(t) {
                        if (5 === t.tag || 6 === t.tag) return t;
                        for (t = t.child; null !== t;) {
                            if (4 !== t.tag) {
                                var r = e(t);
                                if (null !== r) return r
                            }
                            t = t.sibling
                        }
                        return null
                    }(e) : null) ? null : e.stateNode
                }, s.findHostInstanceWithWarning = function(e) {
                    return aW(e)
                }, s.flushControlled = function(e) {
                    var t = iX;
                    iX |= 1;
                    var r = iY.transition,
                        n = tb;
                    try {
                        iY.transition = null, tb = 1, e()
                    } finally {
                        tb = n, iY.transition = r, 0 === (iX = t) && (ae(), tN())
                    }
                }, s.flushPassiveEffects = aR, s.flushSync = aB, s.focusWithin = function(e, t) {
                    if (!ea) throw Error(d(363));
                    for (t = Array.from(t = iz(e = ik(e), t)), e = 0; e < t.length;) {
                        var r = t[e++];
                        if (!eu(r)) {
                            if (5 === r.tag && ed(r.stateNode)) return !0;
                            for (r = r.child; null !== r;) t.push(r), r = r.sibling
                        }
                    }
                    return !1
                }, s.getCurrentUpdatePriority = function() {
                    return tb
                }, s.getFindAllNodesFailureDescription = function(e, t) {
                    if (!ea) throw Error(d(363));
                    var r = 0,
                        n = [];
                    e = [ik(e), 0];
                    for (var i = 0; i < e.length;) {
                        var a = e[i++],
                            o = e[i++],
                            s = t[o];
                        if ((5 !== a.tag || !eu(a)) && (iN(a, s) && (n.push(iJ(s)), ++o > r && (r = o)), o < t.length))
                            for (a = a.child; null !== a;) e.push(a, o), a = a.sibling
                    }
                    if (r < t.length) {
                        for (e = []; r < t.length; r++) e.push(iJ(t[r]));
                        return "findAllNodes was able to match part of the selector:\n  " + n.join(" > ") + "\n\nNo matching component was found for:\n  " + e.join(" > ")
                    }
                    return null
                }, s.getPublicRootInstance = function(e) {
                    return (e = e.current).child ? 5 === e.child.tag ? P(e.child.stateNode) : e.child.stateNode : null
                }, s.injectIntoDevTools = function(e) {
                    if (e = {
                            bundleType: e.bundleType,
                            version: e.version,
                            rendererPackageName: e.rendererPackageName,
                            rendererConfig: e.rendererConfig,
                            overrideHookState: null,
                            overrideHookStateDeletePath: null,
                            overrideHookStateRenamePath: null,
                            overrideProps: null,
                            overridePropsDeletePath: null,
                            overridePropsRenamePath: null,
                            setErrorHandler: null,
                            setSuspenseHandler: null,
                            scheduleUpdate: null,
                            currentDispatcherRef: f.ReactCurrentDispatcher,
                            findHostInstanceByFiber: a$,
                            findFiberByHostInstance: e.findFiberByHostInstance || a0,
                            findHostInstancesForRefresh: null,
                            scheduleRefresh: null,
                            scheduleRoot: null,
                            setRefreshHandler: null,
                            getCurrentFiber: null,
                            reconcilerVersion: "18.0.0-fc46dba67-20220329"
                        }, "undefined" == typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) e = !1;
                    else {
                        var t = __REACT_DEVTOOLS_GLOBAL_HOOK__;
                        if (t.isDisabled || !t.supportsFiber) e = !0;
                        else {
                            try {
                                tD = t.inject(e), tP = t
                            } catch (e) {}
                            e = !!t.checkDCE
                        }
                    }
                    return e
                }, s.isAlreadyRendering = function() {
                    return !1
                }, s.observeVisibleRects = function(e, t, r, n) {
                    if (!ea) throw Error(d(363));
                    var i = ef(e = ij(e, t), r, n).disconnect;
                    return {
                        disconnect: function() {
                            i()
                        }
                    }
                }, s.registerMutableSourceForHydration = function(e, t) {
                    var r = t._getVersion;
                    r = r(t._source), null == e.mutableSourceEagerHydrationData ? e.mutableSourceEagerHydrationData = [t, r] : e.mutableSourceEagerHydrationData.push(t, r)
                }, s.runWithPriority = function(e, t) {
                    var r = tb;
                    try {
                        return tb = e, t()
                    } finally {
                        tb = r
                    }
                }, s.shouldError = function() {
                    return null
                }, s.shouldSuspend = function() {
                    return !1
                }, s.updateContainer = function(e, t, r, n) {
                    var i = t.current,
                        a = ad(),
                        o = af(i);
                    return r = aX(r), null === t.context ? t.context = r : t.pendingContext = r, (t = t8(a, o)).payload = {
                        element: e
                    }, null !== (n = void 0 === n ? null : n) && (t.callback = n), t4(i, t), null !== (e = ah(i, o, a)) && t6(e, i, o), o
                }, s
            }
        },
        32576: function(e, t, r) {
            "use strict";
            e.exports = r(46511)
        },
        76525: function(e, t, r) {
            "use strict";
            e.exports = r(67287)
        },
        52546: function(e, t) {
            "use strict";

            function r(e, t) {
                var r = e.length;
                for (e.push(t); 0 < r;) {
                    var n = r - 1 >>> 1,
                        i = e[n];
                    if (0 < a(i, t)) e[n] = t, e[r] = i, r = n;
                    else break
                }
            }

            function n(e) {
                return 0 === e.length ? null : e[0]
            }

            function i(e) {
                if (0 === e.length) return null;
                var t = e[0],
                    r = e.pop();
                if (r !== t) {
                    e[0] = r;
                    for (var n = 0, i = e.length, o = i >>> 1; n < o;) {
                        var s = 2 * (n + 1) - 1,
                            l = e[s],
                            u = s + 1,
                            c = e[u];
                        if (0 > a(l, r)) u < i && 0 > a(c, l) ? (e[n] = c, e[u] = r, n = u) : (e[n] = l, e[s] = r, n = s);
                        else if (u < i && 0 > a(c, r)) e[n] = c, e[u] = r, n = u;
                        else break
                    }
                }
                return t
            }

            function a(e, t) {
                var r = e.sortIndex - t.sortIndex;
                return 0 !== r ? r : e.id - t.id
            }
            if ("object" == typeof performance && "function" == typeof performance.now) {
                var o, s = performance;
                t.unstable_now = function() {
                    return s.now()
                }
            } else {
                var l = Date,
                    u = l.now();
                t.unstable_now = function() {
                    return l.now() - u
                }
            }
            var c = [],
                d = [],
                f = 1,
                h = null,
                p = 3,
                m = !1,
                g = !1,
                A = !1,
                v = "function" == typeof setTimeout ? setTimeout : null,
                y = "function" == typeof clearTimeout ? clearTimeout : null,
                C = "undefined" != typeof setImmediate ? setImmediate : null;

            function B(e) {
                for (var t = n(d); null !== t;) {
                    if (null === t.callback) i(d);
                    else if (t.startTime <= e) i(d), t.sortIndex = t.expirationTime, r(c, t);
                    else break;
                    t = n(d)
                }
            }

            function _(e) {
                if (A = !1, B(e), !g) {
                    if (null !== n(c)) g = !0, I(b);
                    else {
                        var t = n(d);
                        null !== t && D(_, t.startTime - e)
                    }
                }
            }

            function b(e, r) {
                g = !1, A && (A = !1, y(M), M = -1), m = !0;
                var a = p;
                try {
                    for (B(r), h = n(c); null !== h && (!(h.expirationTime > r) || e && !F());) {
                        var o = h.callback;
                        if ("function" == typeof o) {
                            h.callback = null, p = h.priorityLevel;
                            var s = o(h.expirationTime <= r);
                            r = t.unstable_now(), "function" == typeof s ? h.callback = s : h === n(c) && i(c), B(r)
                        } else i(c);
                        h = n(c)
                    }
                    if (null !== h) var l = !0;
                    else {
                        var u = n(d);
                        null !== u && D(_, u.startTime - r), l = !1
                    }
                    return l
                } finally {
                    h = null, p = a, m = !1
                }
            }
            "undefined" != typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
            var E = !1,
                w = null,
                M = -1,
                T = 5,
                x = -1;

            function F() {
                return !(t.unstable_now() - x < T)
            }

            function S() {
                if (null !== w) {
                    var e = t.unstable_now();
                    x = e;
                    var r = !0;
                    try {
                        r = w(!0, e)
                    } finally {
                        r ? o() : (E = !1, w = null)
                    }
                } else E = !1
            }
            if ("function" == typeof C) o = function() {
                C(S)
            };
            else if ("undefined" != typeof MessageChannel) {
                var R = new MessageChannel,
                    O = R.port2;
                R.port1.onmessage = S, o = function() {
                    O.postMessage(null)
                }
            } else o = function() {
                v(S, 0)
            };

            function I(e) {
                w = e, E || (E = !0, o())
            }

            function D(e, r) {
                M = v(function() {
                    e(t.unstable_now())
                }, r)
            }
            t.unstable_IdlePriority = 5, t.unstable_ImmediatePriority = 1, t.unstable_LowPriority = 4, t.unstable_NormalPriority = 3, t.unstable_Profiling = null, t.unstable_UserBlockingPriority = 2, t.unstable_cancelCallback = function(e) {
                e.callback = null
            }, t.unstable_continueExecution = function() {
                g || m || (g = !0, I(b))
            }, t.unstable_forceFrameRate = function(e) {
                0 > e || 125 < e ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : T = 0 < e ? Math.floor(1e3 / e) : 5
            }, t.unstable_getCurrentPriorityLevel = function() {
                return p
            }, t.unstable_getFirstCallbackNode = function() {
                return n(c)
            }, t.unstable_next = function(e) {
                switch (p) {
                    case 1:
                    case 2:
                    case 3:
                        var t = 3;
                        break;
                    default:
                        t = p
                }
                var r = p;
                p = t;
                try {
                    return e()
                } finally {
                    p = r
                }
            }, t.unstable_pauseExecution = function() {}, t.unstable_requestPaint = function() {}, t.unstable_runWithPriority = function(e, t) {
                switch (e) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        break;
                    default:
                        e = 3
                }
                var r = p;
                p = e;
                try {
                    return t()
                } finally {
                    p = r
                }
            }, t.unstable_scheduleCallback = function(e, i, a) {
                var o = t.unstable_now();
                switch (a = "object" == typeof a && null !== a && "number" == typeof(a = a.delay) && 0 < a ? o + a : o, e) {
                    case 1:
                        var s = -1;
                        break;
                    case 2:
                        s = 250;
                        break;
                    case 5:
                        s = 1073741823;
                        break;
                    case 4:
                        s = 1e4;
                        break;
                    default:
                        s = 5e3
                }
                return s = a + s, e = {
                    id: f++,
                    callback: i,
                    priorityLevel: e,
                    startTime: a,
                    expirationTime: s,
                    sortIndex: -1
                }, a > o ? (e.sortIndex = a, r(d, e), null === n(c) && e === n(d) && (A ? (y(M), M = -1) : A = !0, D(_, a - o))) : (e.sortIndex = s, r(c, e), g || m || (g = !0, I(b))), e
            }, t.unstable_shouldYield = F, t.unstable_wrapCallback = function(e) {
                var t = p;
                return function() {
                    var r = p;
                    p = t;
                    try {
                        return e.apply(this, arguments)
                    } finally {
                        p = r
                    }
                }
            }
        },
        60373: function(e, t, r) {
            "use strict";
            e.exports = r(52546)
        },
        83826: function(e) {
            function t(e, t, r) {
                function n() {
                    var u = Date.now() - s;
                    u < t && u >= 0 ? i = setTimeout(n, t - u) : (i = null, r || (l = e.apply(o, a), o = a = null))
                }
                null == t && (t = 100);
                var i, a, o, s, l, u = function() {
                    o = this, a = arguments, s = Date.now();
                    var u = r && !i;
                    return i || (i = setTimeout(n, t)), u && (l = e.apply(o, a), o = a = null), l
                };
                return u.clear = function() {
                    i && (clearTimeout(i), i = null)
                }, u.flush = function() {
                    i && (l = e.apply(o, a), o = a = null, clearTimeout(i), i = null)
                }, u
            }
            t.debounce = t, e.exports = t
        },
        58139: function(e, t, r) {
            "use strict";
            r.d(t, {
                MA: function() {
                    return l
                },
                Rq: function() {
                    return s
                },
                ZH: function() {
                    return u
                }
            });
            let n = e => "object" == typeof e && "function" == typeof e.then,
                i = [];

            function a(e, t, r = (e, t) => e === t) {
                if (e === t) return !0;
                if (!e || !t) return !1;
                let n = e.length;
                if (t.length !== n) return !1;
                for (let i = 0; i < n; i++)
                    if (!r(e[i], t[i])) return !1;
                return !0
            }

            function o(e, t = null, r = !1, o = {}) {
                for (let n of (null === t && (t = [e]), i))
                    if (a(t, n.keys, n.equal)) {
                        if (r) return;
                        if (Object.prototype.hasOwnProperty.call(n, "error")) throw n.error;
                        if (Object.prototype.hasOwnProperty.call(n, "response")) return o.lifespan && o.lifespan > 0 && (n.timeout && clearTimeout(n.timeout), n.timeout = setTimeout(n.remove, o.lifespan)), n.response;
                        if (!r) throw n.promise
                    }
                let s = {
                    keys: t,
                    equal: o.equal,
                    remove: () => {
                        let e = i.indexOf(s); - 1 !== e && i.splice(e, 1)
                    },
                    promise: (n(e) ? e : e(...t)).then(e => {
                        s.response = e, o.lifespan && o.lifespan > 0 && (s.timeout = setTimeout(s.remove, o.lifespan))
                    }).catch(e => s.error = e)
                };
                if (i.push(s), !r) throw s.promise
            }
            let s = (e, t, r) => o(e, t, !1, r),
                l = (e, t, r) => void o(e, t, !0, r),
                u = e => {
                    if (void 0 === e || 0 === e.length) i.splice(0, i.length);
                    else {
                        let t = i.find(t => a(e, t.keys, t.equal));
                        t && t.remove()
                    }
                }
        },
        63467: function(e, t, r) {
            "use strict";
            let n;
            r.d(t, {
                x: function() {
                    return d
                }
            });
            var i = r(85893),
                a = r(99477),
                o = r(67294),
                s = r(19390),
                l = r(62371);
            let u = (0, o.createContext)(null),
                c = e => (e.getAttributes() & l.VB.CONVOLUTION) === l.VB.CONVOLUTION,
                d = o.memo((0, o.forwardRef)(({
                    children: e,
                    camera: t,
                    scene: r,
                    resolutionScale: d,
                    enabled: f = !0,
                    renderPriority: h = 1,
                    autoClear: p = !0,
                    depthBuffer: m,
                    enableNormalPass: g,
                    stencilBuffer: A,
                    multisampling: v = 8,
                    frameBufferType: y = a.HalfFloatType
                }, C) => {
                    let {
                        gl: B,
                        scene: _,
                        camera: b,
                        size: E
                    } = (0, s.A)(), w = r || _, M = t || b, [T, x, F] = (0, o.useMemo)(() => {
                        let e = function() {
                                var e;
                                if (void 0 !== n) return n;
                                try {
                                    let t;
                                    let r = document.createElement("canvas");
                                    return n = !!(window.WebGL2RenderingContext && (t = r.getContext("webgl2"))), t && (null == (e = t.getExtension("WEBGL_lose_context")) || e.loseContext()), n
                                } catch (e) {
                                    return n = !1
                                }
                            }(),
                            t = new l.xC(B, {
                                depthBuffer: m,
                                stencilBuffer: A,
                                multisampling: v > 0 && e ? v : 0,
                                frameBufferType: y
                            });
                        t.addPass(new l.CD(w, M));
                        let r = null,
                            i = null;
                        return g && ((i = new l.gh(w, M)).enabled = !1, t.addPass(i), void 0 !== d && e && ((r = new l.xs({
                            normalBuffer: i.texture,
                            resolutionScale: d
                        })).enabled = !1, t.addPass(r))), [t, i, r]
                    }, [M, B, m, A, v, y, w, g, d]);
                    (0, o.useEffect)(() => null == T ? void 0 : T.setSize(E.width, E.height), [T, E]), (0, s.C)((e, t) => {
                        if (f) {
                            let e = B.autoClear;
                            B.autoClear = p, A && !p && B.clearStencil(), T.render(t), B.autoClear = e
                        }
                    }, f ? h : 0);
                    let S = (0, o.useRef)(null),
                        R = (0, s.y)(S);
                    (0, o.useLayoutEffect)(() => {
                        let e = [];
                        if (S.current && R.current && T) {
                            let t = R.current.objects;
                            for (let r = 0; r < t.length; r++) {
                                let n = t[r];
                                if (n instanceof l.Qm) {
                                    let i = [n];
                                    if (!c(n)) {
                                        let e = null;
                                        for (;
                                            (e = t[r + 1]) instanceof l.Qm && !c(e);) i.push(e), r++
                                    }
                                    let a = new l.H5(M, ...i);
                                    e.push(a)
                                } else n instanceof l.w2 && e.push(n)
                            }
                            for (let t of e) null == T || T.addPass(t);
                            x && (x.enabled = !0), F && (F.enabled = !0)
                        }
                        return () => {
                            for (let t of e) null == T || T.removePass(t);
                            x && (x.enabled = !1), F && (F.enabled = !1)
                        }
                    }, [T, e, M, x, F, R]), (0, o.useEffect)(() => {
                        let e = B.toneMapping;
                        return B.toneMapping = a.NoToneMapping, () => {
                            B.toneMapping = e
                        }
                    }, []);
                    let O = (0, o.useMemo)(() => ({
                        composer: T,
                        normalPass: x,
                        downSamplingPass: F,
                        resolutionScale: d,
                        camera: M,
                        scene: w
                    }), [T, x, F, d, M, w]);
                    return (0, o.useImperativeHandle)(C, () => T, [T]), (0, i.jsx)(u.Provider, {
                        value: O,
                        children: (0, i.jsx)("group", {
                            ref: S,
                            children: e
                        })
                    })
                }))
        },
        87316: function(e, t, r) {
            "use strict";
            r.d(t, {
                d: function() {
                    return i
                }
            });
            var n = r(62371);
            let i = (0, r(50126).p1)(n.rk, {
                blendFunction: n.YQ.ADD
            })
        },
        49972: function(e, t, r) {
            "use strict";
            r.d(t, {
                g: function() {
                    return i
                }
            });
            var n = r(62371);
            let i = (0, r(50126).p1)(n.Ln)
        },
        79716: function(e, t, r) {
            "use strict";
            r.d(t, {
                c: function() {
                    return i
                }
            });
            var n = r(62371);
            let i = (0, r(50126).p1)(n.xV, {
                blendFunction: n.YQ.COLOR_DODGE
            })
        },
        3937: function(e, t, r) {
            "use strict";
            r.d(t, {
                l: function() {
                    return o
                }
            });
            var n = r(85893),
                i = r(62371),
                a = r(67294);
            let o = (0, a.forwardRef)(function({
                blendFunction: e,
                adaptive: t,
                mode: r,
                resolution: o,
                maxLuminance: s,
                whitePoint: l,
                middleGrey: u,
                minLuminance: c,
                averageLuminance: d,
                adaptationRate: f,
                ...h
            }, p) {
                let m = (0, a.useMemo)(() => new i.M4({
                    blendFunction: e,
                    adaptive: t,
                    mode: r,
                    resolution: o,
                    maxLuminance: s,
                    whitePoint: l,
                    middleGrey: u,
                    minLuminance: c,
                    averageLuminance: d,
                    adaptationRate: f
                }), [e, t, r, o, s, l, u, c, d, f]);
                return (0, a.useEffect)(() => {
                    m.dispose()
                }, [m]), (0, n.jsx)("primitive", { ...h,
                    ref: p,
                    object: m,
                    attributes: i.VB.CONVOLUTION
                })
            })
        },
        50126: function(e, t, r) {
            "use strict";
            r.d(t, {
                p1: function() {
                    return l
                }
            });
            var n = r(85893),
                i = r(67294),
                a = r(19390);
            let o = 0,
                s = new WeakMap,
                l = (e, t) => i.forwardRef(function({
                    blendFunction: r = null == t ? void 0 : t.blendFunction,
                    opacity: l = null == t ? void 0 : t.opacity,
                    ...u
                }, c) {
                    let d = s.get(e);
                    if (!d) {
                        let t = `@react-three/postprocessing/${e.name}-${o++}`;
                        (0, a.e)({
                            [t]: e
                        }), s.set(e, d = t)
                    }
                    let f = (0, a.A)(e => e.camera),
                        h = i.useMemo(() => {
                            var e, r;
                            return [...null != (e = null == t ? void 0 : t.args) ? e : [], ...null != (r = u.args) ? r : [{ ...t,
                                ...u
                            }]]
                        }, [JSON.stringify(u)]);
                    return (0, n.jsx)(d, {
                        camera: f,
                        "blendMode-blendFunction": r,
                        "blendMode-opacity-value": l,
                        ...u,
                        ref: c,
                        args: h
                    })
                })
        },
        19575: function(e, t, r) {
            "use strict";
            r.d(t, {
                j: function() {
                    return O
                },
                n: function() {
                    return R
                }
            });
            var n = r(37301),
                i = r(56955),
                a = r(45487),
                o = r(28672),
                s = r(62711),
                l = r(75194),
                u = r(25794),
                c = r(34547),
                d = r(61059),
                f = r(85086),
                h = r(42284),
                p = r(86917),
                m = r(60599),
                g = r(26615),
                A = r(23967),
                v = r(40406);

            function y(e, t, r, n) {
                var i;
                return "number" == typeof t ? t : t.startsWith("-") || t.startsWith("+") ? Math.max(0, e + parseFloat(t)) : "<" === t ? r : null !== (i = n.get(t)) && void 0 !== i ? i : e
            }
            let C = (e, t, r) => {
                let n = t - e;
                return ((r - e) % n + n) % n + e
            };
            var B = r(43338),
                _ = r(10010),
                b = r(40179);

            function E(e, t) {
                return e.at !== t.at ? e.at - t.at : null === e.value ? 1 : null === t.value ? -1 : 0
            }

            function w(e, t) {
                return t.has(e) || t.set(e, {}), t.get(e)
            }

            function M(e, t) {
                return t[e] || (t[e] = []), t[e]
            }
            let T = e => "number" == typeof e,
                x = e => e.every(T);

            function F(e, t, r, d) {
                let f = (0, n.I)(e, d),
                    h = f.length;
                (0, a.k)(!!h, "No valid element provided.");
                let p = [];
                for (let e = 0; e < h; e++) {
                    let n = f[e];
                    i.R.has(n) || function(e) {
                        let t = {
                                presenceContext: null,
                                props: {},
                                visualState: {
                                    renderState: {
                                        transform: {},
                                        transformOrigin: {},
                                        style: {},
                                        vars: {},
                                        attrs: {}
                                    },
                                    latestValues: {}
                                }
                            },
                            r = (0, l.v)(e) ? new u.e(t) : new c.W(t);
                        r.mount(e), i.R.set(e, r)
                    }(n);
                    let a = i.R.get(n),
                        o = { ...r
                        };
                    "function" == typeof o.delay && (o.delay = o.delay(e, h)), p.push(...(0, s.w)(a, { ...t,
                        transition: o
                    }, {}))
                }
                return new o.s(p)
            }
            let S = e => Array.isArray(e) && Array.isArray(e[0]),
                R = e => function(t, r, i) {
                    let a;
                    return a = S(t) ? function(e, t, r) {
                        let i = [];
                        return (function(e, {
                            defaultTransition: t = {},
                            ...r
                        } = {}, i) {
                            let a = t.duration || .3,
                                o = new Map,
                                s = new Map,
                                l = {},
                                u = new Map,
                                c = 0,
                                d = 0,
                                T = 0;
                            for (let r = 0; r < e.length; r++) {
                                let o = e[r];
                                if ("string" == typeof o) {
                                    u.set(o, d);
                                    continue
                                }
                                if (!Array.isArray(o)) {
                                    u.set(o.name, y(d, o.at, c, u));
                                    continue
                                }
                                let [A, E, F = {}] = o;
                                void 0 !== F.at && (d = y(d, F.at, c, u));
                                let S = 0,
                                    R = (e, r, n, i = 0, o = 0) => {
                                        let s = Array.isArray(e) ? e : [e],
                                            {
                                                delay: l = 0,
                                                times: u = (0, m.Y)(s),
                                                type: c = "keyframes",
                                                ...A
                                            } = r,
                                            {
                                                ease: v = t.ease || "easeOut",
                                                duration: y
                                            } = r,
                                            E = "function" == typeof l ? l(i, o) : l,
                                            w = s.length;
                                        if (w <= 2 && "spring" === c) {
                                            let e = 100;
                                            2 === w && x(s) && (e = Math.abs(s[1] - s[0]));
                                            let t = { ...A
                                            };
                                            void 0 !== y && (t.duration = (0, p.w)(y));
                                            let r = function(e, t = 100) {
                                                let r = (0, f.S)({
                                                        keyframes: [0, t],
                                                        ...e
                                                    }),
                                                    n = Math.min((0, h.i)(r), h.E);
                                                return {
                                                    type: "keyframes",
                                                    ease: e => r.next(n * e).value / t,
                                                    duration: (0, p.X)(n)
                                                }
                                            }(t, e);
                                            v = r.ease, y = r.duration
                                        }
                                        null != y || (y = a);
                                        let M = d + E,
                                            F = M + y;
                                        1 === u.length && 0 === u[0] && (u[1] = 1);
                                        let R = u.length - s.length;
                                        R > 0 && (0, g.c)(u, R), 1 === s.length && s.unshift(null),
                                            function(e, t, r, n, i, a) {
                                                ! function(e, t, r) {
                                                    for (let n = 0; n < e.length; n++) {
                                                        let i = e[n];
                                                        i.at > t && i.at < r && ((0, _.cl)(e, i), n--)
                                                    }
                                                }(e, i, a);
                                                for (let s = 0; s < t.length; s++) {
                                                    var o;
                                                    e.push({
                                                        value: t[s],
                                                        at: (0, b.t)(i, a, n[s]),
                                                        easing: (o = s, (0, B.N)(r) ? r[C(0, r.length, o)] : r)
                                                    })
                                                }
                                            }(n, s, v, u, M, F), S = Math.max(E + y, S), T = Math.max(F, T)
                                    };
                                if ((0, v.i)(A)) R(E, F, M("default", w(A, s)));
                                else {
                                    let e = (0, n.I)(A, i, l),
                                        t = e.length;
                                    for (let r = 0; r < t; r++) {
                                        let n = w(e[r], s);
                                        for (let e in E) R(E[e], F[e] ? { ...F,
                                            ...F[e]
                                        } : { ...F
                                        }, M(e, n), r, t)
                                    }
                                }
                                c = d, d += S
                            }
                            return s.forEach((e, n) => {
                                for (let i in e) {
                                    let a = e[i];
                                    a.sort(E);
                                    let s = [],
                                        l = [],
                                        u = [];
                                    for (let e = 0; e < a.length; e++) {
                                        let {
                                            at: t,
                                            value: r,
                                            easing: n
                                        } = a[e];
                                        s.push(r), l.push((0, A.Y)(0, T, t)), u.push(n || "easeOut")
                                    }
                                    0 !== l[0] && (l.unshift(0), s.unshift(s[0]), u.unshift("easeInOut")), 1 !== l[l.length - 1] && (l.push(1), s.push(null)), o.has(n) || o.set(n, {
                                        keyframes: {},
                                        transition: {}
                                    });
                                    let c = o.get(n);
                                    c.keyframes[i] = s, c.transition[i] = { ...t,
                                        duration: T,
                                        ease: u,
                                        times: l,
                                        ...r
                                    }
                                }
                            }), o
                        })(e, t, r).forEach(({
                            keyframes: e,
                            transition: t
                        }, r) => {
                            let n;
                            n = (0, v.i)(r) ? (0, d.D)(r, e.default, t.default) : F(r, e, t), i.push(n)
                        }), new o.s(i)
                    }(t, r, e) : "object" != typeof r || Array.isArray(r) ? (0, d.D)(t, r, i) : F(t, r, i, e), e && e.animations.push(a), a
                },
                O = R()
        },
        14025: function(e, t, r) {
            "use strict";
            r.d(t, {
                W: function() {
                    return i
                }
            });
            var n = r(67294);

            function i(e, t, r) {
                (0, n.useInsertionEffect)(() => e.on(t, r), [e, t, r])
            }
        }
    }
]);