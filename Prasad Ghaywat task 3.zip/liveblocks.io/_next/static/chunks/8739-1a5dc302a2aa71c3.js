"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8739], {
        74417: function(e, t, i) {
            var r = i(67294),
                n = "function" == typeof Object.is ? Object.is : function(e, t) {
                    return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
                },
                s = r.useState,
                o = r.useEffect,
                a = r.useLayoutEffect,
                d = r.useDebugValue;

            function u(e) {
                var t = e.getSnapshot;
                e = e.value;
                try {
                    var i = t();
                    return !n(e, i)
                } catch (e) {
                    return !0
                }
            }
            var c = "undefined" == typeof window || void 0 === window.document || void 0 === window.document.createElement ? function(e, t) {
                return t()
            } : function(e, t) {
                var i = t(),
                    r = s({
                        inst: {
                            value: i,
                            getSnapshot: t
                        }
                    }),
                    n = r[0].inst,
                    c = r[1];
                return a(function() {
                    n.value = i, n.getSnapshot = t, u(n) && c({
                        inst: n
                    })
                }, [e, i, t]), o(function() {
                    return u(n) && c({
                        inst: n
                    }), e(function() {
                        u(n) && c({
                            inst: n
                        })
                    })
                }, [e]), d(i), i
            };
            t.useSyncExternalStore = void 0 !== r.useSyncExternalStore ? r.useSyncExternalStore : c
        },
        51034: function(e, t, i) {
            var r = i(67294),
                n = i(70490),
                s = "function" == typeof Object.is ? Object.is : function(e, t) {
                    return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
                },
                o = n.useSyncExternalStore,
                a = r.useRef,
                d = r.useEffect,
                u = r.useMemo,
                c = r.useDebugValue;
            t.useSyncExternalStoreWithSelector = function(e, t, i, r, n) {
                var l = a(null);
                if (null === l.current) {
                    var h = {
                        hasValue: !1,
                        value: null
                    };
                    l.current = h
                } else h = l.current;
                var f = o(e, (l = u(function() {
                    function e(e) {
                        if (!d) {
                            if (d = !0, o = e, e = r(e), void 0 !== n && h.hasValue) {
                                var t = h.value;
                                if (n(t, e)) return a = t
                            }
                            return a = e
                        }
                        if (t = a, s(o, e)) return t;
                        var i = r(e);
                        return void 0 !== n && n(t, i) ? t : (o = e, a = i)
                    }
                    var o, a, d = !1,
                        u = void 0 === i ? null : i;
                    return [function() {
                        return e(t())
                    }, null === u ? void 0 : function() {
                        return e(u())
                    }]
                }, [t, i, r, n]))[0], l[1]);
                return d(function() {
                    h.hasValue = !0, h.value = f
                }, [f]), c(f), f
            }
        },
        70490: function(e, t, i) {
            e.exports = i(74417)
        },
        26495: function(e, t, i) {
            e.exports = i(51034)
        },
        68739: function(e, t, i) {
            i.d(t, {
                EH: function() {
                    return a
                },
                m1: function() {
                    return to
                }
            });
            var r = i(67294),
                n = i(10893),
                s = i(70490),
                o = i(26495);

            function a(e) {
                let [t, i] = r.useState(!1);
                return r.useEffect(() => {
                    i(!0)
                }, []), r.createElement(r.Suspense, {
                    fallback: e.fallback
                }, t ? "function" == typeof e.children ? e.children() : e.children : e.fallback)
            }
            var d = r.createContext(null);

            function u() {
                return r.useContext(d)
            }

            function c() {
                return null !== u()
            }

            function l(e, t) {
                return e.createdAt.getTime() - t.createdAt.getTime()
            }

            function h(e, t) {
                return (t.updatedAt ? ? t.createdAt).getTime() - (e.updatedAt ? ? e.createdAt).getTime()
            }

            function f(e) {
                return "string" == typeof e
            }

            function m(e, t) {
                t >= 5 || setTimeout(() => {
                    e()
                }, 5e3 * Math.pow(2, t))
            }

            function b(e, t) {
                if (!(0, n.PO)(e) || !(0, n.PO)(t)) return (0, n.Xd)(e, t);
                let i = Object.keys(e);
                return i.length === Object.keys(t).length && i.every(i => Object.prototype.hasOwnProperty.call(t, i) && (0, n.Xd)(e[i], t[i]))
            }

            function p(e) {
                let t = (0, r.useRef)(e);
                return (0, r.useEffect)(() => {
                    t.current = e
                }, [e]), t
            }
            var y = e => e;

            function g(e) {
                return (0, r.useReducer)(y, e)[0]
            }
            var v = e => {
                    if ("pending" === e.status) throw e;
                    if ("fulfilled" === e.status) return e.value;
                    if ("rejected" === e.status) throw e.reason;
                    throw e.status = "pending", e.then(t => {
                        e.status = "fulfilled", e.value = t
                    }, t => {
                        e.status = "rejected", e.reason = t
                    }), e
                },
                I = Object.freeze({
                    isLoading: !0
                }),
                S = Object.freeze({
                    isLoading: !1,
                    data: void 0
                });

            function E(e) {
                return `${e}:NOTIFICATION_SETTINGS`
            }

            function x(e) {
                return `${e}-VERSIONS`
            }
            var A = class {
                constructor() {
                    this._prevState = null, this._stateCached = null, this._store = (0, n.MT)({
                        rawThreadsById: {},
                        query1: void 0,
                        queries2: {},
                        queries3: {},
                        queries4: {},
                        optimisticUpdates: [],
                        inboxNotificationsById: {},
                        notificationSettingsByRoomId: {},
                        versionsByRoomId: {}
                    }), this.getFullState = this.getFullState.bind(this), this.getInboxNotificationsAsync = this.getInboxNotificationsAsync.bind(this), this.subscribeThreads = this.subscribeThreads.bind(this), this.subscribeUserThreads = this.subscribeUserThreads.bind(this), this.subscribeThreadsOrInboxNotifications = this.subscribeThreadsOrInboxNotifications.bind(this), this.subscribeNotificationSettings = this.subscribeNotificationSettings.bind(this), this.subscribeVersions = this.subscribeVersions.bind(this), this._hasOptimisticUpdates = this._hasOptimisticUpdates.bind(this), this._subscribeOptimisticUpdates = this._subscribeOptimisticUpdates.bind(this)
                }
                get() {
                    let e = this._store.get();
                    return (this._prevState !== e || null === this._stateCached) && (this._prevState = e, this._stateCached = function(e) {
                        let t = {
                            threadsById: { ...e.rawThreadsById
                            },
                            inboxNotificationsById: { ...e.inboxNotificationsById
                            },
                            notificationSettingsByRoomId: { ...e.notificationSettingsByRoomId
                            }
                        };
                        for (let i of e.optimisticUpdates) switch (i.type) {
                            case "create-thread":
                                t.threadsById[i.thread.id] = i.thread;
                                break;
                            case "edit-thread-metadata":
                                {
                                    let e = t.threadsById[i.threadId];
                                    if (void 0 === e || void 0 !== e.deletedAt || void 0 !== e.updatedAt && e.updatedAt > i.updatedAt) break;t.threadsById[e.id] = { ...e,
                                        updatedAt: i.updatedAt,
                                        metadata: { ...e.metadata,
                                            ...i.metadata
                                        }
                                    };
                                    break
                                }
                            case "mark-thread-as-resolved":
                                {
                                    let e = t.threadsById[i.threadId];
                                    if (void 0 === e || void 0 !== e.deletedAt) break;t.threadsById[e.id] = { ...e,
                                        resolved: !0
                                    };
                                    break
                                }
                            case "mark-thread-as-unresolved":
                                {
                                    let e = t.threadsById[i.threadId];
                                    if (void 0 === e || void 0 !== e.deletedAt) break;t.threadsById[e.id] = { ...e,
                                        resolved: !1
                                    };
                                    break
                                }
                            case "create-comment":
                                {
                                    let e = t.threadsById[i.comment.threadId];
                                    if (void 0 === e) break;t.threadsById[e.id] = w(e, i.comment);
                                    let r = Object.values(t.inboxNotificationsById).find(t => "thread" === t.kind && t.threadId === e.id);
                                    if (void 0 === r) break;t.inboxNotificationsById[r.id] = { ...r,
                                        notifiedAt: i.comment.createdAt,
                                        readAt: i.comment.createdAt
                                    };
                                    break
                                }
                            case "edit-comment":
                                {
                                    let e = t.threadsById[i.comment.threadId];
                                    if (void 0 === e) break;t.threadsById[e.id] = w(e, i.comment);
                                    break
                                }
                            case "delete-comment":
                                {
                                    let e = t.threadsById[i.threadId];
                                    if (void 0 === e) break;t.threadsById[e.id] = T(e, i.commentId, i.deletedAt);
                                    break
                                }
                            case "delete-thread":
                                {
                                    let e = t.threadsById[i.threadId];
                                    if (void 0 === e) break;t.threadsById[i.threadId] = { ...e,
                                        deletedAt: i.deletedAt,
                                        updatedAt: i.deletedAt,
                                        comments: []
                                    };
                                    break
                                }
                            case "add-reaction":
                                {
                                    let e = t.threadsById[i.threadId];
                                    if (void 0 === e) break;t.threadsById[e.id] = k(e, i.commentId, i.reaction);
                                    break
                                }
                            case "remove-reaction":
                                {
                                    let e = t.threadsById[i.threadId];
                                    if (void 0 === e) break;t.threadsById[e.id] = C(e, i.commentId, i.emoji, i.userId, i.removedAt);
                                    break
                                }
                            case "mark-inbox-notification-as-read":
                                {
                                    let e = t.inboxNotificationsById[i.inboxNotificationId];
                                    if (void 0 === e) break;t.inboxNotificationsById[i.inboxNotificationId] = { ...e,
                                        readAt: i.readAt
                                    };
                                    break
                                }
                            case "mark-all-inbox-notifications-as-read":
                                for (let e in t.inboxNotificationsById) {
                                    let r = t.inboxNotificationsById[e];
                                    if (void 0 === r) break;
                                    t.inboxNotificationsById[e] = { ...r,
                                        readAt: i.readAt
                                    }
                                }
                                break;
                            case "delete-inbox-notification":
                                delete t.inboxNotificationsById[i.inboxNotificationId];
                                break;
                            case "delete-all-inbox-notifications":
                                t.inboxNotificationsById = {};
                                break;
                            case "update-notification-settings":
                                {
                                    let e = t.notificationSettingsByRoomId[i.roomId];
                                    if (void 0 === e) break;t.notificationSettingsByRoomId[i.roomId] = { ...e,
                                        ...i.settings
                                    }
                                }
                        }
                        let i = Object.values(t.threadsById).filter(e => !e.deletedAt).filter(e => e.comments.some(e => void 0 === e.deletedAt));
                        return {
                            inboxNotifications: Object.values(t.inboxNotificationsById).filter(e => "thread" !== e.kind || t.threadsById[e.threadId] && t.threadsById[e.threadId] ? .deletedAt === void 0).sort((e, t) => t.notifiedAt.getTime() - e.notifiedAt.getTime()),
                            inboxNotificationsById: t.inboxNotificationsById,
                            notificationSettingsByRoomId: t.notificationSettingsByRoomId,
                            queries2: e.queries2,
                            queries3: e.queries3,
                            queries4: e.queries4,
                            threads: i,
                            threadsById: t.threadsById,
                            versionsByRoomId: e.versionsByRoomId
                        }
                    }(e)), this._stateCached
                }
                batch(e) {
                    return this._store.batch(e)
                }
                getFullState() {
                    return this.get()
                }
                getThreadsAsync(e) {
                    let t = this._store.get().queries2[e];
                    return void 0 === t || t.isLoading ? I : t.error ? t : {
                        isLoading: !1,
                        fullState: this.getFullState()
                    }
                }
                getUserThreadsAsync(e) {
                    let t = this._store.get().queries2[e];
                    return void 0 === t || t.isLoading ? I : t.error ? t : {
                        isLoading: !1,
                        fullState: this.getFullState()
                    }
                }
                getInboxNotificationsAsync() {
                    let e = this._store.get().query1;
                    return void 0 === e || e.isLoading ? I : void 0 !== e.error ? e : {
                        isLoading: !1,
                        inboxNotifications: this.getFullState().inboxNotifications
                    }
                }
                getNotificationSettingsAsync(e) {
                    let t = this.get(),
                        i = t.queries3[E(e)];
                    return void 0 === i || i.isLoading ? I : void 0 !== i.error ? i : {
                        isLoading: !1,
                        settings: (0, n.nn)(t.notificationSettingsByRoomId[e])
                    }
                }
                getVersionsAsync(e) {
                    let t = this.get(),
                        i = t.queries4[x(e)];
                    return void 0 === i || i.isLoading ? I : void 0 !== i.error ? i : {
                        isLoading: !1,
                        versions: (0, n.nn)(t.versionsByRoomId[e])
                    }
                }
                _hasOptimisticUpdates() {
                    return this._store.get().optimisticUpdates.length > 0
                }
                subscribe(e) {
                    return this._store.subscribe(e)
                }
                _subscribeOptimisticUpdates(e) {
                    return this.subscribe(e)
                }
                subscribeThreads(e) {
                    return this.subscribe(e)
                }
                subscribeUserThreads(e) {
                    return this.subscribe(e)
                }
                subscribeThreadsOrInboxNotifications(e) {
                    return this.subscribe(e)
                }
                subscribeNotificationSettings(e) {
                    return this.subscribe(e)
                }
                subscribeVersions(e) {
                    return this.subscribe(e)
                }
                updateThreadsCache(e) {
                    this._store.set(t => {
                        let i = e(t.rawThreadsById);
                        return i !== t.rawThreadsById ? { ...t,
                            rawThreadsById: i
                        } : t
                    })
                }
                updateInboxNotificationsCache(e) {
                    this._store.set(t => {
                        let i = e(t.inboxNotificationsById);
                        return i !== t.inboxNotificationsById ? { ...t,
                            inboxNotificationsById: i
                        } : t
                    })
                }
                setNotificationSettings(e, t) {
                    this._store.set(i => ({ ...i,
                        notificationSettingsByRoomId: { ...i.notificationSettingsByRoomId,
                            [e]: t
                        }
                    }))
                }
                setVersions(e, t) {
                    this._store.set(i => ({ ...i,
                        versionsByRoomId: { ...i.versionsByRoomId,
                            [e]: t
                        }
                    }))
                }
                setQuery1State(e) {
                    this._store.set(t => ({ ...t,
                        query1: e
                    }))
                }
                setQuery2State(e, t) {
                    this._store.set(i => ({ ...i,
                        queries2: { ...i.queries2,
                            [e]: t
                        }
                    }))
                }
                setQuery3State(e, t) {
                    this._store.set(i => ({ ...i,
                        queries3: { ...i.queries3,
                            [e]: t
                        }
                    }))
                }
                setQuery4State(e, t) {
                    this._store.set(i => ({ ...i,
                        queries4: { ...i.queries4,
                            [e]: t
                        }
                    }))
                }
                updateOptimisticUpdatesCache(e) {
                    this._store.set(t => ({ ...t,
                        optimisticUpdates: e(t.optimisticUpdates)
                    }))
                }
                force_set(e) {
                    return this._store.set(e)
                }
                updateInboxNotification(e, t, i) {
                    this._store.batch(() => {
                        this.removeOptimisticUpdate(t), this.updateInboxNotificationsCache(t => {
                            let r = t[e];
                            return r ? { ...t,
                                [e]: i(r)
                            } : t
                        })
                    })
                }
                updateAllInboxNotifications(e, t) {
                    this._store.batch(() => {
                        this.removeOptimisticUpdate(e), this.updateInboxNotificationsCache(e => (0, n.Q8)(e, t))
                    })
                }
                deleteInboxNotification(e, t) {
                    this._store.batch(() => {
                        this.removeOptimisticUpdate(t), this.updateInboxNotificationsCache(t => {
                            let {
                                [e]: i, ...r
                            } = t;
                            return void 0 === i ? t : r
                        })
                    })
                }
                deleteAllInboxNotifications(e) {
                    this._store.batch(() => {
                        this.removeOptimisticUpdate(e), this.updateInboxNotificationsCache(() => ({}))
                    })
                }
                createThread(e, t) {
                    this._store.batch(() => {
                        this.removeOptimisticUpdate(e), this.updateThreadsCache(e => ({ ...e,
                            [t.id]: t
                        }))
                    })
                }
                updateThread(e, t, i, r) {
                    this._store.batch(() => {
                        null !== t && this.removeOptimisticUpdate(t), this.updateThreadsCache(t => {
                            let n = t[e];
                            return !n || void 0 !== n.deletedAt || r && n.updatedAt && n.updatedAt > r ? t : { ...t,
                                [e]: i(n)
                            }
                        })
                    })
                }
                patchThread(e, t, i, r) {
                    return this.updateThread(e, t, e => ({ ...e,
                        ...(0, n.yg)(i)
                    }), r)
                }
                addReaction(e, t, i, r, n) {
                    this.updateThread(e, t, e => k(e, i, r), n)
                }
                removeReaction(e, t, i, r, n, s) {
                    this.updateThread(e, t, e => C(e, i, r, n, s), s)
                }
                deleteThread(e, t) {
                    return this.updateThread(e, t, e => ({ ...e,
                        updatedAt: new Date,
                        deletedAt: new Date
                    }))
                }
                createComment(e, t) {
                    this._store.batch(() => {
                        this.removeOptimisticUpdate(t);
                        let i = this._store.get().rawThreadsById[e.threadId];
                        i && (this.updateThreadsCache(t => ({ ...t,
                            [e.threadId]: w(i, e)
                        })), this.updateInboxNotificationsCache(t => {
                            let i = Object.values(t).find(t => "thread" === t.kind && t.threadId === e.threadId);
                            return i ? { ...t,
                                [i.id]: { ...i,
                                    notifiedAt: e.createdAt,
                                    readAt: e.createdAt
                                }
                            } : t
                        }))
                    })
                }
                editComment(e, t, i) {
                    return this.updateThread(e, t, e => w(e, i))
                }
                deleteComment(e, t, i, r) {
                    return this.updateThread(e, t, e => T(e, i, r), r)
                }
                updateThreadAndNotification(e, t) {
                    this._store.batch(() => {
                        this.updateThreadsCache(t => {
                            let i = t[e.id];
                            return void 0 === i || 0 > h(e, i) ? { ...t,
                                [e.id]: e
                            } : t
                        }), void 0 !== t && this.updateInboxNotificationsCache(e => ({ ...e,
                            [t.id]: t
                        }))
                    })
                }
                updateThreadsAndNotifications(e, t, i, r) {
                    this._store.batch(() => {
                        this.updateThreadsCache(t => (function(e, t) {
                            let i = { ...e
                            };
                            return t.newThreads.forEach(e => {
                                let t = i[e.id];
                                !(t && 0 > h(t, e)) && (i[e.id] = e)
                            }), t.deletedThreads.forEach(({
                                id: e,
                                deletedAt: t
                            }) => {
                                let r = i[e];
                                void 0 !== r && (r.deletedAt = t, r.updatedAt = t, r.comments = [])
                            }), i
                        })(t, {
                            newThreads: e,
                            deletedThreads: i
                        })), this.updateInboxNotificationsCache(e => (function(e, t) {
                            let i = { ...e
                            };
                            return t.newInboxNotifications.forEach(e => {
                                let t = i[e.id];
                                (!t || 1 != (t.notifiedAt > e.notifiedAt ? 1 : t.notifiedAt < e.notifiedAt ? -1 : t.readAt && e.readAt ? t.readAt > e.readAt ? 1 : t.readAt < e.readAt ? -1 : 0 : t.readAt || e.readAt ? t.readAt ? 1 : -1 : 0)) && (i[e.id] = e)
                            }), t.deletedNotifications.forEach(({
                                id: e
                            }) => delete i[e]), i
                        })(e, {
                            newInboxNotifications: t,
                            deletedNotifications: r
                        }))
                    })
                }
                updateRoomInboxNotificationSettings2(e, t, i) {
                    this._store.batch(() => {
                        this.removeOptimisticUpdate(t), this.setNotificationSettings(e, i)
                    })
                }
                updateRoomInboxNotificationSettings(e, t, i) {
                    this._store.batch(() => {
                        this.setQuery3OK(i), this.setNotificationSettings(e, t)
                    })
                }
                updateRoomVersions(e, t, i) {
                    this._store.batch(() => {
                        this.setVersions(e, t), void 0 !== i && this.setQuery4OK(i)
                    })
                }
                addOptimisticUpdate(e) {
                    let t = (0, n.x0)(),
                        i = { ...e,
                            id: t
                        };
                    return this.updateOptimisticUpdatesCache(e => [...e, i]), t
                }
                removeOptimisticUpdate(e) {
                    this.updateOptimisticUpdatesCache(t => t.filter(t => t.id !== e))
                }
                setQuery1Loading() {
                    this.setQuery1State(I)
                }
                setQuery1OK() {
                    this.setQuery1State(S)
                }
                setQuery1Error(e) {
                    this.setQuery1State({
                        isLoading: !1,
                        error: e
                    })
                }
                setQuery2Loading(e) {
                    this.setQuery2State(e, I)
                }
                setQuery2OK(e) {
                    this.setQuery2State(e, S)
                }
                setQuery2Error(e, t) {
                    this.setQuery2State(e, {
                        isLoading: !1,
                        error: t
                    })
                }
                setQuery3Loading(e) {
                    this.setQuery3State(e, I)
                }
                setQuery3OK(e) {
                    this.setQuery3State(e, S)
                }
                setQuery3Error(e, t) {
                    this.setQuery3State(e, {
                        isLoading: !1,
                        error: t
                    })
                }
                setQuery4Loading(e) {
                    this.setQuery4State(e, I)
                }
                setQuery4OK(e) {
                    this.setQuery4State(e, S)
                }
                setQuery4Error(e, t) {
                    this.setQuery4State(e, {
                        isLoading: !1,
                        error: t
                    })
                }
            };

            function w(e, t) {
                if (void 0 !== e.deletedAt) return e;
                if (t.threadId !== e.id) return n.iV.warn(`Comment ${t.id} does not belong to thread ${e.id}`), e;
                let i = e.comments.find(e => e.id === t.id);
                if (void 0 === i) {
                    let i = new Date(Math.max(e.updatedAt ? .getTime() || 0, t.createdAt.getTime()));
                    return { ...e,
                        updatedAt: i,
                        comments: [...e.comments, t]
                    }
                }
                if (void 0 !== i.deletedAt) return e;
                if (void 0 === i.editedAt || void 0 === t.editedAt || i.editedAt <= t.editedAt) {
                    let i = e.comments.map(e => e.id === t.id ? t : e);
                    return { ...e,
                        updatedAt: new Date(Math.max(e.updatedAt ? .getTime() || 0, t.editedAt ? .getTime() || t.createdAt.getTime())),
                        comments: i
                    }
                }
                return e
            }

            function T(e, t, i) {
                if (void 0 !== e.deletedAt) return e;
                let r = e.comments.find(e => e.id === t);
                if (void 0 === r || void 0 !== r.deletedAt) return e;
                let n = e.comments.map(e => e.id === t ? { ...e,
                    deletedAt: i,
                    body: void 0,
                    attachments: []
                } : e);
                return n.every(e => void 0 !== e.deletedAt) ? { ...e,
                    deletedAt: i,
                    updatedAt: i
                } : { ...e,
                    updatedAt: i,
                    comments: n
                }
            }

            function k(e, t, i) {
                if (void 0 !== e.deletedAt) return e;
                let r = e.comments.find(e => e.id === t);
                if (void 0 === r || void 0 !== r.deletedAt) return e;
                let n = e.comments.map(e => e.id === t ? { ...e,
                    reactions: function(e, t) {
                        let i = e.find(e => e.emoji === t.emoji);
                        return void 0 === i ? [...e, {
                            emoji: t.emoji,
                            createdAt: t.createdAt,
                            users: [{
                                id: t.userId
                            }]
                        }] : !1 === i.users.some(e => e.id === t.userId) ? e.map(e => e.emoji === t.emoji ? { ...e,
                            users: [...e.users, {
                                id: t.userId
                            }]
                        } : e) : e
                    }(e.reactions, i)
                } : e);
                return { ...e,
                    updatedAt: new Date(Math.max(i.createdAt.getTime(), e.updatedAt ? .getTime() || 0)),
                    comments: n
                }
            }

            function C(e, t, i, r, n) {
                if (void 0 !== e.deletedAt) return e;
                let s = e.comments.find(e => e.id === t);
                if (void 0 === s || void 0 !== s.deletedAt) return e;
                let o = e.comments.map(e => e.id === t ? { ...e,
                    reactions: e.reactions.map(e => e.emoji === i ? { ...e,
                        users: e.users.filter(e => e.id !== r)
                    } : e).filter(e => e.users.length > 0)
                } : e);
                return { ...e,
                    updatedAt: new Date(Math.max(n.getTime(), e.updatedAt ? .getTime() || 0)),
                    comments: o
                }
            }
            var N = (0, r.createContext)(null);

            function O(e) {
                return Error(`resolveUsers didn't return anything for user '${e}'`)
            }

            function B(e) {
                return Error(`resolveRoomsInfo didn't return anything for room '${e}'`)
            }
            var _ = new WeakMap;

            function U(e, t) {
                let i = e.threads;
                null !== t.roomId && (i = i.filter(e => e.roomId === t.roomId));
                let r = t.query;
                return r && (i = i.filter(e => (void 0 === r.resolved || e.resolved === r.resolved) && function(e, t) {
                    let i = e.metadata;
                    return void 0 === t.metadata || Object.entries(t.metadata).every(([e, t]) => {
                        var r, s;
                        return void 0 === t || (r = i[e], s = t, (0, n.PO)(s) && f(s.startsWith) ? f(r) && r.startsWith(s.startsWith) : r === s)
                    })
                }(e, r))), i.sort("last-update" === t.orderBy ? h : l)
            }

            function R() {
                return (0, r.useContext)(N)
            }

            function L() {
                return R() ? ? (0, n.OU)("LiveblocksProvider is missing from the React tree.")
            }

            function D(e) {
                return ! function(e) {
                    let t = R();
                    if (!e ? .allowNesting && null !== t) throw Error("You cannot nest multiple LiveblocksProvider instances in the same React tree.")
                }(e), r.createElement(N.Provider, {
                    value: e.client
                }, e.children)
            }
            var M = class extends Error {
                    constructor(e, t) {
                        super("Create thread failed."), this.cause = e, this.context = t, this.name = "CreateThreadError"
                    }
                },
                Q = class extends Error {
                    constructor(e, t) {
                        super("Delete thread failed."), this.cause = e, this.context = t, this.name = "DeleteThreadError"
                    }
                },
                q = class extends Error {
                    constructor(e, t) {
                        super("Edit thread metadata failed."), this.cause = e, this.context = t, this.name = "EditThreadMetadataError"
                    }
                },
                W = class extends Error {
                    constructor(e, t) {
                        super("Mark thread as resolved failed."), this.cause = e, this.context = t, this.name = "MarkThreadAsResolvedError"
                    }
                },
                j = class extends Error {
                    constructor(e, t) {
                        super("Mark thread as unresolved failed."), this.cause = e, this.context = t, this.name = "MarkThreadAsUnresolvedError"
                    }
                },
                V = class extends Error {
                    constructor(e, t) {
                        super("Create comment failed."), this.cause = e, this.context = t, this.name = "CreateCommentError"
                    }
                },
                P = class extends Error {
                    constructor(e, t) {
                        super("Edit comment failed."), this.cause = e, this.context = t, this.name = "EditCommentError"
                    }
                },
                F = class extends Error {
                    constructor(e, t) {
                        super("Delete comment failed."), this.cause = e, this.context = t, this.name = "DeleteCommentError"
                    }
                },
                $ = class extends Error {
                    constructor(e, t) {
                        super("Add reaction failed."), this.cause = e, this.context = t, this.name = "AddReactionError"
                    }
                },
                X = class extends Error {
                    constructor(e, t) {
                        super("Remove reaction failed."), this.cause = e, this.context = t, this.name = "RemoveReactionError"
                    }
                },
                K = class extends Error {
                    constructor(e, t) {
                        super("Mark inbox notification as read failed."), this.cause = e, this.context = t, this.name = "MarkInboxNotificationAsReadError"
                    }
                },
                z = class extends Error {
                    constructor(e, t) {
                        super("Update notification settings failed."), this.cause = e, this.context = t, this.name = "UpdateNotificationSettingsError"
                    }
                };

            function H(e, t) {
                r.useEffect(() => {
                    ! function(e, t) {
                        if (!1 === e || !t.threads || !("undefined" != typeof window)) return;
                        let i = window.location.hash.slice(1);
                        if (!i.startsWith("cm_")) return;
                        let r = document.getElementById(i);
                        null !== r && t.threads.flatMap(e => e.comments).some(e => e.id === i) && r.scrollIntoView()
                    }(e, t)
                }, [t.isLoading])
            }
            var Y = () => {},
                G = e => e;

            function Z(e, t, i) {
                return (0, o.useSyncExternalStoreWithSelector)(e, t, i, G)
            }
            var J = Object.freeze([]);

            function ee() {
                return J
            }

            function et() {
                return null
            }

            function ei(e) {
                return e.map(e => e.connectionId)
            }

            function er(e) {
                let t = e.getSelf();
                return null === t || void 0 === t.id ? "anonymous" : t.id
            }

            function en(e) {
                let t = `Request failed with status ${e.status}: ${e.message}`;
                if (e.details ? .error === "FORBIDDEN") {
                    let i = [t, e.details.suggestion, e.details.docs].filter(Boolean).join("\n");
                    n.iV.error(i)
                }
                return Error(t)
            }
            var es = new WeakMap,
                eo = new WeakMap;

            function ea(e) {
                let t = es.get(e);
                return t || (t = function(e) {
                    let t;
                    let i = ((t = _.get(e)) || (t = new A, _.set(e, t)), t),
                        r = new Map,
                        s = new Map,
                        o = new Map,
                        a = new Map,
                        d = (0, n.x3)(u);
                    async function u() {
                        let t = [];
                        e[n.W_].getRoomIds().map(i => {
                            let r = e.getRoom(i);
                            null !== r && t.push(c(r.id))
                        }), await Promise.allSettled(t)
                    }
                    async function c(t) {
                        let n = e.getRoom(t);
                        if (null === n) return;
                        let s = r.get(n.id);
                        if (void 0 !== s && !0 !== (o.get(n.id) ? ? !1)) try {
                            o.set(n.id, !0);
                            let e = await n.getThreadsSince({
                                since: s
                            });
                            setTimeout(() => {
                                o.set(n.id, !1)
                            }, 2e3), i.updateThreadsAndNotifications(e.threads.updated, e.inboxNotifications.updated, e.threads.deleted, e.inboxNotifications.deleted), r.set(n.id, e.requestedAt)
                        } catch (e) {
                            o.set(n.id, !1);
                            return
                        }
                    }
                    async function l(e, {
                        retryCount: t
                    } = {
                        retryCount: 0
                    }) {
                        let r = x(e.id),
                            o = s.get(r);
                        if (void 0 !== o) return o;
                        let a = e[n.W_].listTextVersions();
                        s.set(r, a), i.setQuery4Loading(r);
                        try {
                            let t = await a,
                                n = (await t.json()).versions.map(({
                                    createdAt: e,
                                    ...t
                                }) => ({
                                    createdAt: new Date(e),
                                    ...t
                                }));
                            i.updateRoomVersions(e.id, n, r), s.delete(r)
                        } catch (n) {
                            s.delete(r), m(() => {
                                l(e, {
                                    retryCount: t + 1
                                })
                            }, t), i.setQuery4Error(r, n)
                        }
                    }
                    async function h(e, t, n, {
                        retryCount: o
                    } = {
                        retryCount: 0
                    }) {
                        let a = s.get(t);
                        if (void 0 !== a) return a;
                        let u = e.getThreads(n);
                        s.set(t, u), i.setQuery2Loading(t);
                        try {
                            let n = await u;
                            i.batch(() => {
                                i.updateThreadsAndNotifications(n.threads, n.inboxNotifications, [], []), i.setQuery2OK(t)
                            });
                            let s = r.get(e.id);
                            (void 0 === s || s > n.requestedAt) && r.set(e.id, n.requestedAt), d.start(3e5)
                        } catch (r) {
                            s.delete(t), m(() => {
                                h(e, t, n, {
                                    retryCount: o + 1
                                })
                            }, o), i.setQuery2Error(t, r)
                        }
                    }
                    async function f(e, {
                        retryCount: t
                    } = {
                        retryCount: 0
                    }) {
                        let r = E(e.id),
                            n = s.get(r);
                        if (void 0 !== n) return n;
                        try {
                            let t = e.getNotificationSettings();
                            s.set(r, t), i.setQuery3Loading(r);
                            let n = await t;
                            i.updateRoomInboxNotificationSettings(e.id, n, r)
                        } catch (n) {
                            s.delete(r), m(() => {
                                f(e, {
                                    retryCount: t + 1
                                })
                            }, t), i.setQuery3Error(r, n)
                        }
                    }
                    let b = (0, n.Zb)();
                    return {
                        store: i,
                        incrementQuerySubscribers: function(e) {
                            let t = a.get(e) ? ? 0;
                            return a.set(e, t + 1), d.start(3e5), () => {
                                let t = a.get(e);
                                if (void 0 === t || t <= 0) {
                                    n.iV.warn(`Internal unexpected behavior. Cannot decrease subscriber count for query "${e}"`);
                                    return
                                }
                                a.set(e, t - 1);
                                let i = 0;
                                for (let e of a.values()) i += e;
                                i <= 0 && d.stop()
                            }
                        },
                        commentsErrorEventSource: b,
                        getThreadsUpdates: c,
                        getThreadsAndInboxNotifications: h,
                        getInboxNotificationSettings: f,
                        getRoomVersions: l,
                        onMutationFailure: function(e, t, r) {
                            if (i.removeOptimisticUpdate(t), e instanceof n.iz) {
                                let t = en(e);
                                b.notify(r(t));
                                return
                            }
                            if (e instanceof n.VB) {
                                en(e);
                                return
                            }
                            throw e
                        }
                    }
                }(e), es.set(e, t)), t
            }

            function ed(e) {
                let t = L(),
                    [i] = r.useState(() => new Map),
                    n = r.useCallback((e, r) => {
                        let n = i.get(e);
                        if (n) return n;
                        let s = t.enterRoom(e, r),
                            o = s.leave;
                        return s.leave = () => {
                            o(), i.delete(e)
                        }, i.set(e, s), s
                    }, [t, i]);
                return r.createElement(eu, { ...e,
                    stableEnterRoom: n
                })
            }

            function eu(e) {
                let t = L(),
                    {
                        id: i,
                        stableEnterRoom: s
                    } = e,
                    o = g({
                        initialPresence: e.initialPresence,
                        initialStorage: e.initialStorage,
                        unstable_batchedUpdates: e.unstable_batchedUpdates,
                        autoConnect: e.autoConnect ? ? "undefined" != typeof window
                    }),
                    [{
                        room: a
                    }, u] = r.useState(() => s(i, { ...o,
                        autoConnect: !1
                    }));
                return r.useEffect(() => {
                    let {
                        store: e
                    } = ea(t);
                    async function i(t) {
                        if (t.type === n.yO.THREAD_DELETED) {
                            e.deleteThread(t.threadId, null);
                            return
                        }
                        let i = await a.getThread(t.threadId);
                        if (!i.thread) {
                            e.deleteThread(t.threadId, null);
                            return
                        }
                        let {
                            thread: r,
                            inboxNotification: s
                        } = i, o = e.getFullState().threadsById[t.threadId];
                        switch (t.type) {
                            case n.yO.COMMENT_EDITED:
                            case n.yO.THREAD_METADATA_UPDATED:
                            case n.yO.THREAD_UPDATED:
                            case n.yO.COMMENT_REACTION_ADDED:
                            case n.yO.COMMENT_REACTION_REMOVED:
                            case n.yO.COMMENT_DELETED:
                                if (!o) break;
                                e.updateThreadAndNotification(r, s);
                                break;
                            case n.yO.COMMENT_CREATED:
                                e.updateThreadAndNotification(r, s)
                        }
                    }
                    return a.events.comments.subscribe(e => void i(e))
                }, [t, a]), r.useEffect(() => {
                    let {
                        getThreadsUpdates: e
                    } = ea(t);
                    e(a.id)
                }, [t, a.id]), r.useEffect(() => {
                    function e() {
                        let {
                            getThreadsUpdates: e
                        } = ea(t);
                        e(a.id)
                    }
                    return window.addEventListener("online", e), () => {
                        window.removeEventListener("online", e)
                    }
                }, [t, a.id]), r.useEffect(() => {
                    let e = s(i, o);
                    u(e);
                    let {
                        room: t,
                        leave: r
                    } = e;
                    return o.autoConnect && t.connect(), () => {
                        r()
                    }
                }, [i, o, s]), r.createElement(d.Provider, {
                    value: a
                }, e.children)
            }

            function ec() {
                let e = u();
                if (null === e) throw Error("RoomProvider is missing from the React tree.");
                return e
            }

            function el() {
                let e = ec();
                return Z(e.events.status.subscribe, e.getStatus, e.getStatus)
            }

            function eh(e) {
                return g(e ? .smooth ? ? !1) ? function() {
                    let e = ec(),
                        [t, i] = r.useState(e.getStorageStatus),
                        n = p(e.getStorageStatus());
                    return r.useEffect(() => {
                        let t;
                        let r = e.events.storageStatus.subscribe(e => {
                            "synchronizing" === n.current && "synchronized" === e ? t = setTimeout(() => i(e), 1e3) : (clearTimeout(t), i(e))
                        });
                        return () => {
                            clearTimeout(t), r()
                        }
                    }, [e, n]), t
                }() : function() {
                    let e = ec();
                    return Z(e.events.storageStatus.subscribe, e.getStorageStatus, e.getStorageStatus)
                }()
            }

            function ef() {
                return ec().batch
            }

            function em() {
                let e = ec();
                return r.useCallback((t, i = {
                    shouldQueueEventIfNotReady: !1
                }) => {
                    e.broadcastEvent(t, i)
                }, [e])
            }

            function eb(e) {
                let t = ec(),
                    i = p(e);
                r.useEffect(() => t.events.others.subscribe(e => i.current(e)), [t, i])
            }

            function ep(e) {
                let t = ec(),
                    i = p(e);
                r.useEffect(() => t.events.lostConnection.subscribe(e => i.current(e)), [t, i])
            }

            function ey(e) {
                let t = ec(),
                    i = p(e);
                r.useEffect(() => t.events.error.subscribe(e => i.current(e)), [t, i])
            }

            function eg(e) {
                let t = ec(),
                    i = p(e);
                r.useEffect(() => t.events.customEvent.subscribe(e => {
                    i.current(e)
                }), [t, i])
            }

            function ev() {
                return ec().history
            }

            function eI() {
                return ev().undo
            }

            function eS() {
                return ev().redo
            }

            function eE() {
                let e = ec(),
                    t = e.events.history.subscribe,
                    i = e.history.canUndo;
                return Z(t, i, i)
            }

            function ex() {
                let e = ec(),
                    t = e.events.history.subscribe,
                    i = e.history.canRedo;
                return Z(t, i, i)
            }

            function eA(e, t) {
                let i = ec(),
                    n = i.events.self.subscribe,
                    s = i.getSelf,
                    a = e ? ? G,
                    d = r.useCallback(e => null !== e ? a(e) : null, [a]);
                return (0, o.useSyncExternalStoreWithSelector)(n, s, et, d, t)
            }

            function ew() {
                let e = ec(),
                    t = e.events.myPresence.subscribe,
                    i = e.getPresence;
                return [Z(t, i, i), e.updatePresence]
            }

            function eT() {
                return ec().updatePresence
            }

            function ek(e, t) {
                let i = ec(),
                    r = i.events.others.subscribe,
                    n = i.getOthers;
                return (0, o.useSyncExternalStoreWithSelector)(r, n, ee, e ? ? G, t)
            }

            function eC(e, t) {
                return ek(r.useCallback(t => t.map(t => [t.connectionId, e(t)]), [e]), r.useCallback((e, i) => {
                    let r = t ? ? Object.is;
                    return e.length === i.length && e.every((e, t) => {
                        let n = i[t];
                        return e[0] === n[0] && r(e[1], n[1])
                    })
                }, [t]))
            }

            function eN() {
                return ek(ei, n.Xd)
            }
            var eO = Symbol();

            function eB(e, t, i) {
                let n = ek(r.useCallback(i => {
                    let r = i.find(t => t.connectionId === e);
                    return void 0 !== r ? t(r) : eO
                }, [e, t]), r.useCallback((e, t) => e === eO || t === eO ? e === t : (i ? ? Object.is)(e, t), [i]));
                if (n === eO) throw Error(`No such other user with connection id ${e} exists`);
                return n
            }

            function e_() {
                let e = ec();
                return Z(e.events.storageDidLoad.subscribeOnce, e.getStorageSnapshot, et)
            }

            function eU() {
                return [e_()]
            }

            function eR(e, t) {
                let i = ec(),
                    n = e_(),
                    s = r.useCallback(t => null !== t ? e(t) : null, [e]),
                    a = r.useCallback(e => null !== n ? i.subscribe(n, e, {
                        isDeep: !0
                    }) : Y, [i, n]),
                    d = r.useCallback(() => null === n ? null : n.toImmutable(), [n]);
                return (0, o.useSyncExternalStoreWithSelector)(a, d, et, s, t)
            }

            function eL(e, t) {
                let i = ec();
                return r.useMemo(() => (...t) => i.batch(() => e(function(e) {
                    let t = "This mutation cannot be used until",
                        i = `${t} connected to the Liveblocks room`,
                        r = `${t} storage has been loaded`;
                    return {
                        get storage() {
                            let t = e.getStorageSnapshot();
                            if (null === t) throw Error(r);
                            return t
                        },
                        get self() {
                            let t = e.getSelf();
                            if (null === t) throw Error(i);
                            return t
                        },
                        get others() {
                            let t = e.getOthers();
                            if (null === e.getSelf()) throw Error(i);
                            return t
                        },
                        setMyPresence: e.updatePresence
                    }
                }(i), ...t)), [i, ...t])
            }

            function eD(e = {
                query: {
                    metadata: {}
                }
            }) {
                let {
                    scrollOnLoad: t = !0
                } = e, i = L(), n = ec(), s = r.useMemo(() => ta(n.id, e.query), [n, e]), {
                    store: a,
                    getThreadsAndInboxNotifications: d,
                    incrementQuerySubscribers: u
                } = ea(i);
                r.useEffect(() => (d(n, s, e), u(s)), [n, s]);
                let c = r.useCallback(() => a.getThreadsAsync(s), [a, s]),
                    l = r.useCallback(t => t.fullState ? {
                        isLoading: !1,
                        threads: U(t.fullState, {
                            roomId: n.id,
                            query: e.query,
                            orderBy: "age"
                        })
                    } : t, [n.id, s]),
                    h = (0, o.useSyncExternalStoreWithSelector)(a.subscribeThreads, c, c, l, b);
                return H(t, h), h
            }

            function eM(e) {
                let t = L(),
                    i = p(e),
                    {
                        commentsErrorEventSource: n
                    } = ea(t);
                r.useEffect(() => n.subscribe(i.current), [i, n])
            }

            function eQ() {
                let e = L(),
                    t = ec();
                return r.useCallback(i => {
                    let r = i.body,
                        s = i.metadata ? ? {},
                        o = i.attachments,
                        a = (0, n.iK)(),
                        d = (0, n.F0)(),
                        u = new Date,
                        c = {
                            id: d,
                            threadId: a,
                            roomId: t.id,
                            createdAt: u,
                            type: "comment",
                            userId: er(t),
                            body: r,
                            reactions: [],
                            attachments: o ? ? []
                        },
                        l = {
                            id: a,
                            type: "thread",
                            createdAt: u,
                            updatedAt: u,
                            roomId: t.id,
                            metadata: s,
                            comments: [c],
                            resolved: !1
                        },
                        {
                            store: h,
                            onMutationFailure: f
                        } = ea(e),
                        m = h.addOptimisticUpdate({
                            type: "create-thread",
                            thread: l,
                            roomId: t.id
                        }),
                        b = o ? .map(e => e.id);
                    return t.createThread({
                        threadId: a,
                        commentId: d,
                        body: r,
                        metadata: s,
                        attachmentIds: b
                    }).then(e => {
                        h.createThread(m, e)
                    }, e => f(e, m, e => new M(e, {
                        roomId: t.id,
                        threadId: a,
                        commentId: d,
                        body: r,
                        metadata: s
                    }))), l
                }, [e, t])
            }

            function eq() {
                let e = L(),
                    t = ec();
                return r.useCallback(i => {
                    let {
                        store: r,
                        onMutationFailure: n
                    } = ea(e), s = r.getFullState().threadsById[i], o = er(t);
                    if (s ? .comments ? .[0] ? .userId !== o) throw Error("Only the thread creator can delete the thread");
                    let a = r.addOptimisticUpdate({
                        type: "delete-thread",
                        roomId: t.id,
                        threadId: i,
                        deletedAt: new Date
                    });
                    t.deleteThread(i).then(() => {
                        r.deleteThread(i, a)
                    }, e => n(e, a, e => new Q(e, {
                        roomId: t.id,
                        threadId: i
                    })))
                }, [e, t])
            }

            function eW() {
                let e = L(),
                    t = ec();
                return r.useCallback(i => {
                    if (!i.metadata) return;
                    let r = i.threadId,
                        n = i.metadata,
                        s = new Date,
                        {
                            store: o,
                            onMutationFailure: a
                        } = ea(e),
                        d = o.addOptimisticUpdate({
                            type: "edit-thread-metadata",
                            metadata: n,
                            threadId: r,
                            updatedAt: s
                        });
                    t.editThreadMetadata({
                        threadId: r,
                        metadata: n
                    }).then(e => o.patchThread(r, d, {
                        metadata: e
                    }, s), e => a(e, d, e => new q(e, {
                        roomId: t.id,
                        threadId: r,
                        metadata: n
                    })))
                }, [e, t])
            }

            function ej() {
                let e = L(),
                    t = ec();
                return r.useCallback(({
                    threadId: i,
                    body: r,
                    attachments: s
                }) => {
                    let o = (0, n.F0)(),
                        a = new Date,
                        d = {
                            id: o,
                            threadId: i,
                            roomId: t.id,
                            type: "comment",
                            createdAt: a,
                            userId: er(t),
                            body: r,
                            reactions: [],
                            attachments: s ? ? []
                        },
                        {
                            store: u,
                            onMutationFailure: c
                        } = ea(e),
                        l = u.addOptimisticUpdate({
                            type: "create-comment",
                            comment: d
                        }),
                        h = s ? .map(e => e.id);
                    return t.createComment({
                        threadId: i,
                        commentId: o,
                        body: r,
                        attachmentIds: h
                    }).then(e => {
                        u.createComment(e, l)
                    }, e => c(e, l, e => new V(e, {
                        roomId: t.id,
                        threadId: i,
                        commentId: o,
                        body: r
                    }))), d
                }, [e, t])
            }

            function eV() {
                let e = L(),
                    t = ec();
                return r.useCallback(({
                    threadId: i,
                    commentId: r,
                    body: s,
                    attachments: o
                }) => {
                    let a = new Date,
                        {
                            store: d,
                            onMutationFailure: u
                        } = ea(e),
                        c = d.getFullState().threadsById[i];
                    if (void 0 === c) {
                        n.iV.warn(`Internal unexpected behavior. Cannot edit comment in thread "${i}" because the thread does not exist in the cache.`);
                        return
                    }
                    let l = c.comments.find(e => e.id === r);
                    if (void 0 === l || void 0 !== l.deletedAt) {
                        n.iV.warn(`Internal unexpected behavior. Cannot edit comment "${r}" in thread "${i}" because the comment does not exist in the cache.`);
                        return
                    }
                    let h = d.addOptimisticUpdate({
                            type: "edit-comment",
                            comment: { ...l,
                                editedAt: a,
                                body: s,
                                attachments: o ? ? []
                            }
                        }),
                        f = o ? .map(e => e.id);
                    t.editComment({
                        threadId: i,
                        commentId: r,
                        body: s,
                        attachmentIds: f
                    }).then(e => {
                        d.editComment(i, h, e)
                    }, e => u(e, h, e => new P(e, {
                        roomId: t.id,
                        threadId: i,
                        commentId: r,
                        body: s
                    })))
                }, [e, t])
            }

            function eP() {
                let e = L(),
                    t = ec();
                return r.useCallback(({
                    threadId: i,
                    commentId: r
                }) => {
                    let n = new Date,
                        {
                            store: s,
                            onMutationFailure: o
                        } = ea(e),
                        a = s.addOptimisticUpdate({
                            type: "delete-comment",
                            threadId: i,
                            commentId: r,
                            deletedAt: n,
                            roomId: t.id
                        });
                    t.deleteComment({
                        threadId: i,
                        commentId: r
                    }).then(() => {
                        s.deleteComment(i, a, r, n)
                    }, e => o(e, a, e => new F(e, {
                        roomId: t.id,
                        threadId: i,
                        commentId: r
                    })))
                }, [e, t])
            }

            function eF() {
                let e = L(),
                    t = ec();
                return r.useCallback(({
                    threadId: i,
                    commentId: r,
                    emoji: n
                }) => {
                    let s = new Date,
                        o = er(t),
                        {
                            store: a,
                            onMutationFailure: d
                        } = ea(e),
                        u = a.addOptimisticUpdate({
                            type: "add-reaction",
                            threadId: i,
                            commentId: r,
                            reaction: {
                                emoji: n,
                                userId: o,
                                createdAt: s
                            }
                        });
                    t.addReaction({
                        threadId: i,
                        commentId: r,
                        emoji: n
                    }).then(e => {
                        a.addReaction(i, u, r, e, s)
                    }, e => d(e, u, e => new $(e, {
                        roomId: t.id,
                        threadId: i,
                        commentId: r,
                        emoji: n
                    })))
                }, [e, t])
            }

            function e$() {
                let e = L(),
                    t = ec();
                return r.useCallback(({
                    threadId: i,
                    commentId: r,
                    emoji: n
                }) => {
                    let s = er(t),
                        o = new Date,
                        {
                            store: a,
                            onMutationFailure: d
                        } = ea(e),
                        u = a.addOptimisticUpdate({
                            type: "remove-reaction",
                            threadId: i,
                            commentId: r,
                            emoji: n,
                            userId: s,
                            removedAt: o
                        });
                    t.removeReaction({
                        threadId: i,
                        commentId: r,
                        emoji: n
                    }).then(() => {
                        a.removeReaction(i, u, r, n, s, o)
                    }, e => d(e, u, e => new X(e, {
                        roomId: t.id,
                        threadId: i,
                        commentId: r,
                        emoji: n
                    })))
                }, [e, t])
            }

            function eX() {
                let e = L(),
                    t = ec();
                return r.useCallback(i => {
                    let {
                        store: r,
                        onMutationFailure: n
                    } = ea(e), s = Object.values(r.getFullState().inboxNotificationsById).find(e => "thread" === e.kind && e.threadId === i);
                    if (!s) return;
                    let o = new Date,
                        a = r.addOptimisticUpdate({
                            type: "mark-inbox-notification-as-read",
                            inboxNotificationId: s.id,
                            readAt: o
                        });
                    t.markInboxNotificationAsRead(s.id).then(() => {
                        r.updateInboxNotification(s.id, a, e => ({ ...e,
                            readAt: o
                        }))
                    }, e => {
                        n(e, a, e => new K(e, {
                            inboxNotificationId: s.id
                        }))
                    })
                }, [e, t])
            }

            function eK() {
                let e = L(),
                    t = ec();
                return r.useCallback(i => {
                    let r = new Date,
                        {
                            store: n,
                            onMutationFailure: s
                        } = ea(e),
                        o = n.addOptimisticUpdate({
                            type: "mark-thread-as-resolved",
                            threadId: i,
                            updatedAt: r
                        });
                    t.markThreadAsResolved(i).then(() => {
                        n.patchThread(i, o, {
                            resolved: !0
                        }, r)
                    }, e => s(e, o, e => new W(e, {
                        roomId: t.id,
                        threadId: i
                    })))
                }, [e, t])
            }

            function ez() {
                let e = L(),
                    t = ec();
                return r.useCallback(i => {
                    let r = new Date,
                        {
                            store: n,
                            onMutationFailure: s
                        } = ea(e),
                        o = n.addOptimisticUpdate({
                            type: "mark-thread-as-unresolved",
                            threadId: i,
                            updatedAt: r
                        });
                    t.markThreadAsUnresolved(i).then(() => {
                        n.patchThread(i, o, {
                            resolved: !1
                        }, r)
                    }, e => s(e, o, e => new j(e, {
                        roomId: t.id,
                        threadId: i
                    })))
                }, [e, t])
            }

            function eH(e) {
                let {
                    store: t
                } = ea(L()), i = r.useCallback(t => {
                    let i = t.inboxNotifications.find(t => "thread" === t.kind && t.threadId === e),
                        r = t.threadsById[e];
                    return void 0 === i || void 0 === r ? {
                        status: "not-subscribed"
                    } : {
                        status: "subscribed",
                        unreadSince: i.readAt
                    }
                }, [e]);
                return (0, o.useSyncExternalStoreWithSelector)(t.subscribeThreads, t.getFullState, t.getFullState, i)
            }

            function eY() {
                let e = e1(),
                    t = L(),
                    i = ec(),
                    {
                        store: s
                    } = ea(t),
                    a = r.useCallback(() => s.getNotificationSettingsAsync(i.id), [s, i.id]);
                r.useEffect(() => {
                    let {
                        getInboxNotificationSettings: e
                    } = ea(t);
                    e(i)
                }, [t, i]);
                let d = (0, o.useSyncExternalStoreWithSelector)(s.subscribeNotificationSettings, a, a, G, n.Xd);
                return r.useMemo(() => [d, e], [d, e])
            }

            function eG() {
                let e = e1(),
                    t = L(),
                    i = ec(),
                    {
                        store: s
                    } = ea(t),
                    a = r.useCallback(() => s.getNotificationSettingsAsync(i.id), [s, i.id]),
                    d = (0, o.useSyncExternalStoreWithSelector)(s.subscribeNotificationSettings, a, a, G, n.Xd);
                if (d.isLoading) {
                    let {
                        getInboxNotificationSettings: e
                    } = ea(t);
                    throw e(i)
                }
                if (d.error) throw d.error;
                return r.useMemo(() => [d, e], [d, e])
            }

            function eZ(e) {
                let [t, i] = r.useState({
                    isLoading: !0
                }), s = ec();
                return r.useEffect(() => {
                    i({
                        isLoading: !0
                    }), (async () => {
                        try {
                            let t = await s[n.W_].getTextVersion(e),
                                r = await t.arrayBuffer(),
                                o = new Uint8Array(r);
                            i({
                                isLoading: !1,
                                data: o
                            })
                        } catch (e) {
                            i({
                                isLoading: !1,
                                error: e instanceof Error ? e : Error("An unknown error occurred while loading this version")
                            })
                        }
                    })()
                }, [s, e]), t
            }

            function eJ() {
                let e = L(),
                    t = ec(),
                    {
                        store: i,
                        getRoomVersions: s
                    } = ea(e),
                    a = r.useCallback(() => i.getVersionsAsync(t.id), [i, t.id]);
                return r.useEffect(() => {
                    s(t)
                }, [t]), (0, o.useSyncExternalStoreWithSelector)(i.subscribeVersions, a, a, G, n.Xd)
            }

            function e0() {
                let e = L(),
                    t = ec(),
                    {
                        store: i
                    } = ea(e),
                    s = r.useCallback(() => i.getVersionsAsync(t.id), [i, t.id]),
                    a = (0, o.useSyncExternalStoreWithSelector)(i.subscribeVersions, s, s, G, n.Xd);
                if (a.isLoading) {
                    let {
                        getRoomVersions: i
                    } = ea(e);
                    throw i(t)
                }
                if (a.error) throw a.error;
                return a
            }

            function e1() {
                let e = L(),
                    t = ec();
                return r.useCallback(i => {
                    let {
                        store: r,
                        onMutationFailure: n
                    } = ea(e), s = r.addOptimisticUpdate({
                        type: "update-notification-settings",
                        roomId: t.id,
                        settings: i
                    });
                    t.updateNotificationSettings(i).then(e => {
                        r.updateRoomInboxNotificationSettings2(t.id, s, e)
                    }, e => n(e, s, e => new z(e, {
                        roomId: t.id
                    })))
                }, [e, t])
            }

            function e4() {
                if ("undefined" == typeof window) throw Error("You cannot use the Suspense version of this hook on the server side. Make sure to only call them on the client side.\nFor tips, see https://liveblocks.io/docs/api-reference/liveblocks-react#suspense-avoid-ssr")
            }

            function e2() {
                e4(), v(ec().waitUntilPresenceReady())
            }

            function e3(e, t) {
                return e2(), eA(e, t)
            }

            function e7(e, t) {
                return e2(), ek(e, t)
            }

            function e9() {
                return e2(), eN()
            }

            function e5(e, t) {
                return e2(), eC(e, t)
            }

            function e6(e, t, i) {
                return e2(), eB(e, t, i)
            }

            function e8() {
                e4(), v(ec().waitUntilStorageReady())
            }

            function te(e, t) {
                return e8(), eR(e, t)
            }

            function tt(e) {
                return e8(), eh(e)
            }

            function ti(e = {
                query: {
                    metadata: {}
                }
            }) {
                let {
                    scrollOnLoad: t = !0
                } = e, i = L(), n = ec(), s = r.useMemo(() => ta(n.id, e.query), [n, e]), {
                    store: a,
                    getThreadsAndInboxNotifications: d
                } = ea(i), u = a.getFullState().queries2[s];
                if (void 0 === u || u.isLoading) throw d(n, s, e);
                if (u.error) throw u.error;
                let c = r.useCallback(t => ({
                    threads: U(t, {
                        roomId: n.id,
                        query: e.query,
                        orderBy: "age"
                    }),
                    isLoading: !1
                }), [n, s]);
                r.useEffect(() => {
                    let {
                        incrementQuerySubscribers: e
                    } = ea(i);
                    return e(s)
                }, [i, s]);
                let l = (0, o.useSyncExternalStoreWithSelector)(a.subscribeThreads, a.getFullState, a.getFullState, c);
                return H(t, l), l
            }

            function tr(e) {
                return void 0 === e || e ? .isLoading ? e ? ? {
                    isLoading: !0
                } : e.error ? e : ((0, n.hu)(void 0 !== e.data, "Unexpected missing attachment URL"), {
                    isLoading: !1,
                    url: e.data
                })
            }

            function tn(e) {
                let {
                    attachmentUrlsStore: t
                } = ec()[n.W_], i = r.useCallback(() => t.getState(e), [t, e]);
                return r.useEffect(() => {
                    t.get(e)
                }, [t, e]), (0, o.useSyncExternalStoreWithSelector)(t.subscribe, i, i, tr, n.Xd)
            }

            function ts(e) {
                let {
                    attachmentUrlsStore: t
                } = ec()[n.W_], i = r.useCallback(() => t.getState(e), [t, e]), s = i();
                if (!s || s.isLoading) throw t.get(e);
                if (s.error) throw s.error;
                let o = Z(t.subscribe, i, i);
                return (0, n.hu)(void 0 !== o, "Unexpected missing state"), (0, n.hu)(!o.isLoading, "Unexpected loading state"), (0, n.hu)(!o.error, "Unexpected error state"), {
                    isLoading: !1,
                    url: o.data,
                    error: void 0
                }
            }

            function to(e) {
                let t;
                return (t = eo.get(e)) || (t = function(e) {
                    function t(t) {
                        return r.createElement(D, {
                            client: e,
                            allowNesting: !0
                        }, r.createElement(ed, { ...t
                        }))
                    }
                    let i = function(e) {
                        let t = () => e;
                        return {
                            classic: {
                                useClient: t,
                                useUser: t => (function(e, t) {
                                    let i = e[n.W_].usersStore,
                                        s = (0, r.useCallback)(() => i.getState(t), [i, t]);
                                    (0, r.useEffect)(() => {
                                        i.get(t)
                                    }, [i, t]);
                                    let a = (0, r.useCallback)(e => void 0 === e || e ? .isLoading ? e ? ? {
                                        isLoading: !0
                                    } : e.error ? e : e.data ? {
                                        isLoading: !1,
                                        user: e.data
                                    } : {
                                        isLoading: !1,
                                        error: O(t)
                                    }, [t]);
                                    return (0, o.useSyncExternalStoreWithSelector)(i.subscribe, s, s, a, n.Xd)
                                })(e, t),
                                useRoomInfo: t => (function(e, t) {
                                    let i = e[n.W_].roomsInfoStore,
                                        s = (0, r.useCallback)(() => i.getState(t), [i, t]),
                                        a = (0, r.useCallback)(e => void 0 === e || e ? .isLoading ? e ? ? {
                                            isLoading: !0
                                        } : e.error ? e : e.data ? {
                                            isLoading: !1,
                                            info: e.data
                                        } : {
                                            isLoading: !1,
                                            error: B(t)
                                        }, [t]);
                                    return (0, r.useEffect)(() => {
                                        i.get(t)
                                    }, [i, t]), (0, o.useSyncExternalStoreWithSelector)(i.subscribe, s, s, a, n.Xd)
                                })(e, t),
                                useIsInsideRoom: c
                            },
                            suspense: {
                                useClient: t,
                                useUser: t => (function(e, t) {
                                    let i = e[n.W_].usersStore,
                                        o = (0, r.useCallback)(() => i.getState(t), [i, t]),
                                        a = o();
                                    if (!a || a.isLoading) throw i.get(t);
                                    if (a.error) throw a.error;
                                    if (!a.data) throw O(t);
                                    let d = (0, s.useSyncExternalStore)(i.subscribe, o, o);
                                    return (0, n.hu)(void 0 !== d, "Unexpected missing state"), (0, n.hu)(!d.isLoading, "Unexpected loading state"), (0, n.hu)(!d.error, "Unexpected error state"), {
                                        isLoading: !1,
                                        user: d.data,
                                        error: void 0
                                    }
                                })(e, t),
                                useRoomInfo: t => (function(e, t) {
                                    let i = e[n.W_].roomsInfoStore,
                                        o = (0, r.useCallback)(() => i.getState(t), [i, t]),
                                        a = o();
                                    if (!a || a.isLoading) throw i.get(t);
                                    if (a.error) throw a.error;
                                    if (!a.data) throw B(t);
                                    let d = (0, s.useSyncExternalStore)(i.subscribe, o, o);
                                    return (0, n.hu)(void 0 !== d, "Unexpected missing state"), (0, n.hu)(!d.isLoading, "Unexpected loading state"), (0, n.hu)(!d.error, "Unexpected error state"), (0, n.hu)(void 0 !== d.data, "Unexpected missing room info data"), {
                                        isLoading: !1,
                                        info: d.data,
                                        error: void 0
                                    }
                                })(e, t),
                                useIsInsideRoom: c
                            }
                        }
                    }(e);
                    return Object.defineProperty({
                        RoomContext: d,
                        RoomProvider: t,
                        useRoom: ec,
                        useStatus: el,
                        useStorageStatus: eh,
                        useBatch: ef,
                        useBroadcastEvent: em,
                        useOthersListener: eb,
                        useLostConnectionListener: ep,
                        useErrorListener: ey,
                        useEventListener: eg,
                        useHistory: ev,
                        useUndo: eI,
                        useRedo: eS,
                        useCanRedo: ex,
                        useCanUndo: eE,
                        useStorageRoot: eU,
                        useStorage: eR,
                        useSelf: eA,
                        useMyPresence: ew,
                        useUpdateMyPresence: eT,
                        useOthers: ek,
                        useOthersMapped: eC,
                        useOthersConnectionIds: eN,
                        useOther: eB,
                        useMutation: eL,
                        useThreads: eD,
                        useCreateThread: eQ,
                        useDeleteThread: eq,
                        useEditThreadMetadata: eW,
                        useMarkThreadAsResolved: eK,
                        useMarkThreadAsUnresolved: ez,
                        useCreateComment: ej,
                        useEditComment: eV,
                        useDeleteComment: eP,
                        useAddReaction: eF,
                        useRemoveReaction: e$,
                        useMarkThreadAsRead: eX,
                        useThreadSubscription: eH,
                        useAttachmentUrl: tn,
                        useHistoryVersions: eJ,
                        useHistoryVersionData: eZ,
                        useRoomNotificationSettings: eY,
                        useUpdateRoomNotificationSettings: e1,
                        ...i.classic,
                        suspense: {
                            RoomContext: d,
                            RoomProvider: t,
                            useRoom: ec,
                            useStatus: el,
                            useStorageStatus: tt,
                            useBatch: ef,
                            useBroadcastEvent: em,
                            useOthersListener: eb,
                            useLostConnectionListener: ep,
                            useErrorListener: ey,
                            useEventListener: eg,
                            useHistory: ev,
                            useUndo: eI,
                            useRedo: eS,
                            useCanRedo: ex,
                            useCanUndo: eE,
                            useStorageRoot: eU,
                            useStorage: te,
                            useSelf: e3,
                            useMyPresence: ew,
                            useUpdateMyPresence: eT,
                            useOthers: e7,
                            useOthersMapped: e5,
                            useOthersConnectionIds: e9,
                            useOther: e6,
                            useMutation: eL,
                            useThreads: ti,
                            useCreateThread: eQ,
                            useDeleteThread: eq,
                            useEditThreadMetadata: eW,
                            useMarkThreadAsResolved: eK,
                            useMarkThreadAsUnresolved: ez,
                            useCreateComment: ej,
                            useEditComment: eV,
                            useDeleteComment: eP,
                            useAddReaction: eF,
                            useRemoveReaction: e$,
                            useMarkThreadAsRead: eX,
                            useThreadSubscription: eH,
                            useAttachmentUrl: ts,
                            useHistoryVersions: e0,
                            useRoomNotificationSettings: eG,
                            useUpdateRoomNotificationSettings: e1,
                            ...i.suspense
                        },
                        useCommentsErrorListener: eM
                    }, n.W_, {
                        enumerable: !1
                    })
                }(e), eo.set(e, t)), t
            }

            function ta(e, t) {
                return `${e}-${(0,n.Pz)(t??{})}`
            }
        }
    }
]);