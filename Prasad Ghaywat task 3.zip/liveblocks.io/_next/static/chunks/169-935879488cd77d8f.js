"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [169], {
        15190: function(e, a, o) {
            o.d(a, {
                l: function() {
                    return t
                }
            });
            let t = {
                GUIDES: {
                    slug: "guides",
                    title: "Guides",
                    color: "brand"
                },
                CUSTOMER_STORIES: {
                    slug: "customer-stories",
                    title: "Customer stories",
                    color: "yellow"
                },
                INSIDE_LIVEBLOCKS: {
                    slug: "inside-liveblocks",
                    title: "Inside Liveblocks",
                    color: "brand"
                },
                PRODUCT_UPDATES: {
                    slug: "product-updates",
                    title: "Product updates",
                    color: "pink"
                },
                LAUNCH_WEEK: {
                    slug: "launch-week",
                    title: "Launch week",
                    color: "brand"
                }
            }
        },
        60169: function(e, a, o) {
            o.d(a, {
                D: function() {
                    return m
                }
            });
            let t = {
                    avatar: "/images/people/steven-fabre.jpg",
                    name: "Steven Fabre",
                    title: "CEO, Liveblocks",
                    xHandle: "stevenfabre"
                },
                i = {
                    avatar: "/images/people/guillaume-salles.jpg",
                    name: "Guillaume Salles",
                    title: "CTO, Liveblocks",
                    xHandle: "guillaume_slls"
                },
                s = {
                    avatar: "/images/people/olivier-foucherot.jpg",
                    name: "Olivier Foucherot",
                    title: "Software Engineer, Liveblocks",
                    xHandle: "ofoucherot"
                },
                n = {
                    avatar: "/images/people/chris-nicholas.jpg",
                    name: "Chris Nicholas",
                    title: "Developer Experience, Liveblocks",
                    xHandle: "ctnicholasdev"
                },
                l = {
                    avatar: "/images/people/vincent-driessen.jpg",
                    name: "Vincent Driessen",
                    title: "Software Engineer, Liveblocks",
                    xHandle: "nvie"
                },
                r = {
                    avatar: "/images/people/adrien-gaudon.jpg",
                    name: "Adrien Gaudon",
                    title: "Product Manager, Liveblocks",
                    xHandle: "adigau31"
                },
                c = {
                    avatar: "/images/people/emmanuel-ernest.jpg",
                    name: "Emmanuel Ernest",
                    title: "Developer Experience, Liveblocks",
                    xHandle: "captaindev404"
                },
                g = {
                    avatar: "/images/people/taylor-whipp.jpg",
                    name: "Taylor Whipp",
                    title: "Developer Experience, Liveblocks",
                    xHandle: "taylorwhippdev"
                };
            var d = o(15190);
            let m = {
                "2021_07_29": {
                    title: "Introducing Liveblocks",
                    description: "Build amazing realtime collaborative experiences in minutes with easy‑to‑use APIs and tools.",
                    date: new Date(2021, 6, 29),
                    image: "/images/blog/introducing-liveblocks.jpg",
                    href: "/blog/introducing-liveblocks",
                    category: d.l.INSIDE_LIVEBLOCKS,
                    authors: [t],
                    youtubeVideoId: "0k8bwiSEhlE"
                },
                "2021_09_16": {
                    title: "Liveblocks raises $1.4M in pre-seed funding",
                    description: "Liveblocks has raised $1.4M in pre-seed funding led by Boldstart and Seedcamp — funds that have backed startups such as Snyk, Superhuman, Wise, and many more.",
                    date: new Date(2021, 8, 16),
                    image: "/images/blog/liveblocks-raises-1.4M.jpg",
                    href: "/blog/liveblocks-raises-$1.4M",
                    category: d.l.INSIDE_LIVEBLOCKS,
                    authors: [t]
                },
                "2021_10_06": {
                    title: "Client-side only mode now available in Liveblocks",
                    description: "Create collaborative experiences without setting up your own authentication endpoint.",
                    date: new Date(2021, 9, 6),
                    image: "/images/blog/public-key.jpg",
                    href: "/blog/client-side-only-mode-with-public-key",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [s]
                },
                "2021_11_07": {
                    title: "Clover made their product multiplayer in less than a day using Liveblocks",
                    description: "As more people started using the product, Clover needed to become multiplayer to encourage guest collaboration and drive organic user growth.",
                    date: new Date(2021, 10, 7),
                    image: "/images/blog/clover-customer-story.jpg",
                    href: "/blog/clover-made-their-product-multiplayer-in-less-than-a-day-using-liveblocks",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [t]
                },
                "2021_11_10": {
                    title: "How to add a live avatar stack to your product with React, Firebase, and Liveblocks",
                    description: "Learn how you can create and add a live avatar stack to your product using React, Firebase, and Liveblocks.",
                    date: new Date(2021, 10, 10),
                    image: "/images/blog/avatar-stack-tutorial-cover.jpg",
                    href: "/blog/how-to-add-a-live-avatar-stack-to-your-product-with-react-firebase-liveblocks",
                    category: d.l.GUIDES,
                    authors: [{
                        avatar: "/images/people/ikeh-akinyemi.jpg",
                        name: "Ikeh Akinyemi",
                        title: "Software Engineer",
                        xHandle: "IkehAkinyemi"
                    }]
                },
                "2022_02_04": {
                    title: "How to set up end-to-end tests for multiplayer apps using Puppeteer and Jest",
                    description: "Learn how to set up end-to-end tests with multiple browser windows using Puppeteer and Jest.",
                    date: new Date(2022, 1, 4),
                    image: "/images/blog/puppeteer-jest.jpg",
                    href: "/blog/e2e-tests-with-puppeteer-and-jest-for-multiplayer-apps",
                    category: d.l.GUIDES,
                    authors: [i]
                },
                "2022_03_10": {
                    title: "Motionbox made their product multiplayer without making tradeoffs on data governance",
                    description: "Motionbox is a browser-based video editor. They used Liveblocks to add realtime collaboration to their product while keeping the document’s data on their database.",
                    date: new Date(2022, 2, 10),
                    image: "/images/blog/motionbox-customer-story.jpg",
                    href: "/blog/motionbox-made-their-product-multiplayer-without-making-tradeoffs-on-data-governance",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [c],
                    youtubeVideoId: "AsxWYSpJZw0"
                },
                "2022_03_16": {
                    title: "Liveblocks raises $5M in seed funding from Boldstart, Atlassian, Seedcamp and more",
                    description: "Today, a year into our journey, I’m thrilled to announce that we have raised a $5M seed round from Boldstart, our lead investor, as well as Atlassian, Kima Ventures, Seedcamp and more.",
                    date: new Date(2022, 2, 16),
                    image: "/images/blog/liveblocks-raises-5M.jpg",
                    href: "/blog/liveblocks-raises-$5M-in-seed-funding-from-boldstart-atlassian-seedcamp-and-more",
                    category: d.l.INSIDE_LIVEBLOCKS,
                    authors: [t],
                    youtubeVideoId: "ejJT4XhmFPU"
                },
                "2022_03_23": {
                    title: "Tldraw became viral by converting its product to multiplayer with Liveblocks",
                    description: "Tldraw is a drawing application created by Steve Ruiz. With Liveblocks, they were able to convert their product to multiplayer in a matter of days to enable it to spread virally.",
                    date: new Date(2022, 2, 23),
                    image: "/images/blog/tldraw-customer-story.jpg",
                    href: "/blog/tldraw-became-viral-by-converting-its-product-to-multiplayer-using-liveblocks",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [c],
                    youtubeVideoId: "ZBc3UJ4OtTM"
                },
                "2022_05_04": {
                    title: "How Liveblocks enables Sprout’s multiplayer collaboration, allowing users to play together swiftly",
                    description: "Sprout is an engaging virtual space designed to allow you to chat live, present, hang out, and share ideas. Liveblocks enables this multiplayer functionality, consequently unburdening developers and allowing them to focus on new ideas.",
                    date: new Date(2022, 4, 4),
                    image: "/images/blog/sprout-customer-story.jpg",
                    href: "/blog/how-liveblocks-enables-sprout-multiplayer-collaboration",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [t],
                    youtubeVideoId: "ZjWbGZGOaG4"
                },
                "2022_05_23": {
                    title: "PopStage built all kinds of collaborative experiences with tailored permissions for their users using Liveblocks",
                    description: "PopStage is specifically built for facilitators to design and host engaging and interactive training sessions as effortlessly as possible. See how this small startup wasted zero time in development and how Liveblocks catalyzed them straight into the product space.",
                    date: new Date(2022, 4, 23),
                    image: "/images/blog/popstage-customer-story.jpg",
                    href: "/blog/popstage-built-all-kinds-of-collaborative-experiences-with-tailored-permissions-for-their-users-using-liveblocks",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [t]
                },
                "2022_06_09": {
                    title: "How to build undo/redo in a multiplayer environment",
                    description: "Notoriously tough to build, undo/redo in a multiplayer environment is even more fraught with difficulty. In this article, we will take you on a behind-the-scenes exclusive, explaining one of the most complex developer issues for multiplayer apps.",
                    date: new Date(2022, 5, 9),
                    image: "/images/blog/multiplayer-undo-redo.jpg",
                    href: "/blog/how-to-build-undo-redo-in-a-multiplayer-environment",
                    category: d.l.GUIDES,
                    authors: [i, {
                        avatar: "/images/people/marc-bouchenoire.jpg",
                        name: "Marc Bouchenoire",
                        title: "Design Engineer, Liveblocks",
                        xHandle: "marcbouchenoire"
                    }, t]
                },
                "2022_06_27": {
                    title: "What’s new in v0.17",
                    description: "This new release brings better TypeScript integration, React Native support, improved LiveList conflict resolution, and new API endpoints to fetch rooms and users within rooms.",
                    date: new Date(2022, 5, 28),
                    image: "/images/blog/whats-new-in-v0-17.jpg",
                    socialImage: "/images/blog/social-images/whats-new-in-v0-17.png",
                    href: "/blog/whats-new-in-v0-17",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [i, l]
                },
                "2022_07_05": {
                    title: "How to animate multiplayer cursors",
                    description: "Smoothly rendering live cursors is more difficult than it sounds when real‑world conditions are taken into account—here’s a quick introduction to a few different methods, plus some React snippets.",
                    date: new Date(2022, 6, 5),
                    image: "/images/blog/how-to-animate-multiplayer-cursors.jpg",
                    href: "/blog/how-to-animate-multiplayer-cursors",
                    category: d.l.GUIDES,
                    authors: [n]
                },
                "2022_08_23": {
                    title: "Launch week 1: wrap up",
                    description: "Last week, we announced our new showcase and examples gallery pages. We also introduced more open‑source examples to help you get started with Liveblocks. Let’s recap.",
                    date: new Date(2022, 7, 23),
                    image: "/images/blog/from-collaborative-spreadsheets-to-text-editors-make-your-product-multiplayer-with-liveblocks.jpg",
                    href: "/blog/from-collaborative-spreadsheets-to-text-editors-make-your-product-multiplayer-with-liveblocks",
                    category: d.l.LAUNCH_WEEK,
                    authors: [r]
                },
                "2022_09_20": {
                    title: "What’s new in v0.18",
                    description: "This release brings you powerful React hooks that return immutable data, React selector APIs, React Suspense support, improved core performance, and specialized React hooks for optimized use cases.",
                    date: new Date(2022, 8, 20),
                    image: "/images/blog/whats-new-in-v0-18.jpg",
                    socialImage: "/images/blog/social-images/whats-new-in-v0-18.png",
                    href: "/blog/whats-new-in-v0-18",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [l]
                },
                "2022_09_22": {
                    title: "Introducing REST APIs to build share dialogs, filterable overview pages, and a whole lot more",
                    description: "We’ve added new API endpoints that enable you to build core parts of multiplayer products such as share dialogs with permissions, filterable overview pages, groups with permissions, and more.",
                    date: new Date(2022, 8, 22),
                    image: "/images/blog/rest-apis-to-build-share-dialogs-filterable-overview-pages.jpg",
                    href: "/blog/rest-apis-to-build-share-dialogs-filterable-overview-pages",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [s]
                },
                "2022_11_10": {
                    title: "What’s new in v0.19",
                    description: "In this release we’re adding support for Zustand v4 to Liveblocks, enabling us to improve the quality of our TypeScript, fully aligning it with the standard of our React package.",
                    date: new Date(2022, 10, 10),
                    image: "/images/blog/whats-new-in-v0-19.jpg",
                    socialImage: "/images/blog/social-images/whats-new-in-v0-19.png",
                    href: "/blog/whats-new-in-v0-19",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [l]
                },
                "2022_11_17": {
                    title: "Manage multiple projects and easily roll new API keys",
                    description: "We’ve improved our dashboard enabling you to manage your Liveblocks app more efficiently—you can now create multiple projects and easily roll new API keys!",
                    date: new Date(2022, 10, 17),
                    image: "/images/blog/dashboard-improvements-nov-2022/dashboard-improvements-banner.jpg",
                    href: "/blog/manage-multiple-projects-and-easily-roll-new-api-keys",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [{
                        avatar: "/images/people/vinod-santharam.jpg",
                        name: "Vinod Santharam",
                        title: "Software Engineer, Liveblocks",
                        xHandle: "vinod_santharam"
                    }]
                },
                "2022_11_21": {
                    title: "Liveblocks at React Brussels!",
                    description: "Last month, Liveblocks attendended React Brussels. Steven Fabre, our CEO, gave a presentation on building multiplayer undo/redo. The recording’s now available online!",
                    image: "/images/blog/liveblocks-at-react-brussels.jpg",
                    date: new Date(2022, 10, 21),
                    href: "/blog/liveblocks-at-react-brussels",
                    category: d.l.INSIDE_LIVEBLOCKS,
                    authors: [r],
                    youtubeVideoId: "pMnVhTPfDwE"
                },
                "2023_01_10": {
                    title: "Facet.ai rolled out a brand‑new collaborative product within a few weeks",
                    description: "By trusting Liveblocks to build its collaborative infrastructure, Facet.ai can focus on the unique and differentiating aspects of their products.",
                    image: "/images/blog/facet-ai-rolled-out-a-brand-new-multiplayer-product-within-a-few-weeks.jpg",
                    date: new Date(2023, 0, 10),
                    href: "/blog/facet-ai-rolled-out-a-brand-new-multiplayer-product-within-a-few-weeks",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [r],
                    youtubeVideoId: "1_96k33mHqg"
                },
                "2023_02_06": {
                    title: "Liveblocks 1.0: collaborative experiences in days, not months",
                    description: "Today, nearly two years into our journey, I’m thrilled to introduce Liveblocks 1.0: a fully hosted solution and complete toolkit to modularly embed collaborative experiences into your product remarkably fast.",
                    image: "/images/blog/liveblocks-1/liveblocks-collaborative-experiences-in-days-not-months.png",
                    socialImage: "/images/blog/social-images/liveblocks-collaborative-experiences-in-days-not-months.png",
                    date: new Date(2023, 1, 6),
                    href: "/blog/liveblocks-collaborative-experiences-in-days-not-months",
                    category: d.l.INSIDE_LIVEBLOCKS,
                    authors: [t],
                    youtubeVideoId: "T5eoM9d2WU8"
                },
                "2023_02_07": {
                    title: "Launch week 2: wrap up",
                    description: "Last week was Liveblocks launch week. Here’s a summary of everything we announced each day of the week to make it even easier to build scalable collaborative products with Liveblocks.",
                    image: "/images/blog/launch-week-wrap-up-feb-23/a-complete-toolkit-for-collaborative-infrastructure.png",
                    socialImage: "/images/blog/social-images/launch-week-wrap-up-feb-23.png",
                    date: new Date(2023, 1, 13),
                    href: "/blog/launch-week-2-wrap-up",
                    category: d.l.LAUNCH_WEEK,
                    authors: [r]
                },
                "2023_02_16": {
                    title: "Dialogue made their EMR collaborative to decrease members’ waiting time",
                    description: "The Liveblocks API helped Dialogue, Canada’s premier health and wellness virtual healthcare platform, ensure that its medical team could focus on what matters the most: member experience.",
                    date: new Date(2023, 1, 16),
                    image: "/images/blog/dialogue/dialogue.png",
                    href: "/blog/dialogue-made-their-emr-collaborative-to-decrease-members-waiting-time",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [r]
                },
                "2023_02_23": {
                    title: "Propeller used Liveblocks to make their 3D maps collaborative in just days",
                    description: "With Liveblocks, Propeller was able to quickly add realtime collaboration to their 3D maps, enabling them to ship this experiment in production to learn quickly from their customers.",
                    image: "/images/blog/propeller/propeller-used-liveblocks-to-quickly-roll-out-a-collaborative-3d-map-experiment.jpg",
                    socialImage: "/images/blog/social-images/propeller-customer-story.jpg",
                    date: new Date(2023, 1, 23),
                    href: "/blog/propeller-used-liveblocks-to-make-their-3d-maps-collaborative-in-just-days",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [r],
                    youtubeVideoId: "0ICAwYDNnTo"
                },
                "2023_03_02": {
                    title: "Gomada makes teams feel connected through collaborative experiences",
                    description: "By relying on Liveblocks to handle their collaboration infrastructure, Gomada can focus on their unique expertise: building truly engaged remote teams.",
                    image: "/images/blog/gomada/gomada-makes-teams-feel-connected-through-collaborative-experiences.jpg",
                    socialImage: "/images/blog/social-images/goamada-customer-story-social.jpg",
                    date: new Date(2023, 2, 2),
                    href: "/blog/gomada-makes-teams-feel-connected-through-collaborative-experiences",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [r]
                },
                "2023_03_14": {
                    title: "Dashboard updates: a faster way to navigate rooms, monitor usage, and more",
                    description: "Dashboard improvements include new analytics metrics and improved room navigation features, resulting in a faster and more intuitive user experience for managing your rooms.",
                    image: "/images/blog/dashboard-improvements-mar-2023/dashboard-improvements-banner.jpg",
                    socialImage: "/images/blog/social-images/dashboard-improvements-mar-23.jpg",
                    date: new Date(2023, 2, 14),
                    href: "/blog/dashboard-updates-a-faster-way-to-navigate-rooms-monitor-usage-and-more",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [g]
                },
                "2023_03_28": {
                    title: "How Arcol used Liveblocks to create a collaborative BIM tool for the AEC industry",
                    description: "Learn how Arcol, a browser-based building design and documentation tool for the AEC (Architecture, Engineering, and Construction) industry, overcame technical challenges and partnered with Liveblocks to create a collaborative, Figma-like experience for Building Information Modeling (BIM).",
                    date: new Date(2023, 2, 28),
                    image: "/images/blog/arcol/revolutionizing-the-aec-industry-how-arcol-used-liveblocks-to-create-a-figma-like-experience-for-bim.jpg",
                    socialImage: "/images/blog/social-images/arcol-customer-story.jpg",
                    href: "/blog/revolutionizing-the-aec-industry-how-arcol-used-liveblocks-to-create-a-figma-like-experience-for-bim",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [r],
                    youtubeVideoId: "lsS93BKRK9o"
                },
                "2023_04_05": {
                    title: "How to add Google authentication to your Next.js + Liveblocks app with NextAuth.js",
                    description: "Learn how to use NextAuth.js to integrate  Google authentication with your Next.js + Liveblocks application—enabling personalization with users' names, photos, and more throughout your product.",
                    image: "/images/blog/google-sso/google-authentication-liveblocks-nextjs-nextauthjs.jpg",
                    socialImage: "/images/blog/social-images/google-authentication-liveblocks-nextjs-nextauthjs.jpg",
                    date: new Date(2023, 3, 5),
                    href: "/blog/how-to-add-google-authentication-to-your-nextjs-liveblocks-app-with-nextauthjs",
                    category: d.l.GUIDES,
                    authors: [g]
                },
                "2023_04_20": {
                    title: "How Rayon replaced their own WebSocket infrastructure with Liveblocks to power realtime collaboration",
                    description: "By providing a cloud-based software solution, Liveblocks removed the burden of maintaining and scaling a realtime collaboration infrastructure for Rayon, allowing them to enhance their core offering and provide a better user experience for their customers.",
                    image: "/images/blog/rayon/how-rayon-replaced-their-own-websocket-infrastructure-with-liveblocks-to-power-real‑time-collaboration.jpg",
                    socialImage: "/images/blog/social-images/rayon-customer-story-social.jpg",
                    date: new Date(2023, 3, 20),
                    href: "/blog/how-rayon-replaced-their-own-websocket-infrastructure-with-liveblocks-to-power-real-time-collaboration",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [r],
                    youtubeVideoId: "N-w9gaXHE3E"
                },
                "2023_04_28": {
                    title: "Initialize your Liveblocks configuration file with a single command",
                    description: "You can now use a single command to initialize your Liveblocks configuration file, enabling you to start building collaborative experiences quicker than ever.",
                    image: "/images/blog/initialize-config-command/initialize-liveblocks-config-file-command.png",
                    date: new Date(2023, 3, 28),
                    href: "/blog/initialize-your-liveblocks-config-file-with-a-single-command",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2023_06_01": {
                    title: "How Fermat enabled realtime collaboration in their AI-powered whiteboard",
                    description: "Learn how Fermat, a collaborative canvas to augment creativity with AI, used Liveblocks to turn their core product into an easily customizable and extendable tool that teams can use for brainstorming, ideation, and convergent thinking.",
                    image: "/images/blog/fermat/how-fermat-revolutionized-the-power-of-collaborative-whiteboarding-with-liveblocks-and-AI.jpg",
                    socialImage: "/images/blog/social-images/fermat-customer-story-social.jpg",
                    date: new Date(2023, 5, 1),
                    href: "/blog/how-fermat-enabled-real-time-collaboration-in-their-ai-powered-whiteboard",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [g],
                    youtubeVideoId: "nCp3veOuJLU"
                },
                "2023_06_15": {
                    title: "How Vercel used live reactions to improve engagement on their Vercel Ship livestream",
                    description: "Learn how Vercel used Liveblocks to make their product launch livestream more engaging, social, and fun through emoji reactions—enabling them to drive thousands of visitors to their site.",
                    image: "/images/blog/vercel/vercel-ship-live-emoji-reactions.jpg",
                    socialImage: "/images/blog/social-images/vercel-ship-live-emoji-reactions-social.jpg",
                    date: new Date(2023, 5, 15),
                    href: "/blog/how-vercel-used-live-reactions-to-improve-engagement-on-their-vercel-ship-livestream",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [t],
                    youtubeVideoId: "C3_hQEdMo_0"
                },
                "2023_06_19": {
                    title: "What’s new in v1.1",
                    description: "With this release, we’ve enhanced stability and improved the room connection engine, enabling you to easily show the connection status to your users with a simple API.",
                    date: new Date(2023, 5, 19),
                    image: "/images/blog/whats-new-in-v1-1/whats-new-in-v1-1.jpg",
                    socialImage: "/images/blog/social-images/whats-new-in-v1-1.png",
                    href: "/blog/whats-new-in-v1-1",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [l]
                },
                "2023_06_27": {
                    title: "Introducing the brand new Liveblocks docs",
                    description: "Today, we’re thrilled to introduce the brand new Liveblocks docs which includes new how-to guides and content, quickstart instructions, an interactive tutorial, ⌘K search, and more!",
                    date: new Date(2023, 5, 27),
                    image: "/images/blog/brand-new-docs/liveblocks-brand-new-docs.png",
                    socialImage: "/images/blog/social-images/liveblocks-brand-new-docs.png",
                    href: "/blog/introducing-the-brand-new-liveblocks-docs",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n],
                    youtubeVideoId: "NSyEfyLoWXU"
                },
                "2023_08_02": {
                    title: "What’s new in v1.2",
                    description: "With this release, we’re introducing new flexible authentication methods to handle permissions for your collaborative application, leading to improved performance and developer experience.",
                    date: new Date(2023, 7, 2),
                    image: "/images/blog/whats-new-in-v1-2/whats-new-in-v1-2.jpg",
                    socialImage: "/images/blog/social-images/whats-new-in-v1-2.png",
                    href: "/blog/whats-new-in-v1-2",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [l, s]
                },
                "2023_09_05": {
                    title: "Introducing Liveblocks Yjs",
                    description: "Today, we’re excited to announce Liveblocks Yjs, a fully managed, highly scalable realtime data store for Yjs documents. Powered by Yjs, it’s optimized for building collaborative text editors such as Google Docs.",
                    date: new Date(2023, 8, 5),
                    image: "/images/blog/introducing-yjs/yjs.png",
                    socialImage: "/images/blog/social-images/introducing-yjs.png",
                    href: "/blog/introducing-liveblocks-yjs",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [t],
                    youtubeVideoId: "C5eD0LzgAr0"
                },
                "2023_09_07": {
                    title: "Extend the capabilities of Yjs using our REST API and webhooks",
                    description: "Today, we’ll dive into the different ways Liveblocks enables developers to extend Yjs, allowing you to integrate your document data seamlessly into existing systems with our REST API and webhooks.",
                    date: new Date(2023, 8, 7),
                    image: "/images/blog/extend-yjs/extend-yjs.png",
                    socialImage: "/images/blog/social-images/extend-yjs.png",
                    href: "/blog/extend-the-capabilities-of-yjs-using-our-rest-api-and-webhooks",
                    category: d.l.GUIDES,
                    authors: [n]
                },
                "2023_10_03": {
                    title: "Liveblocks 1.4: Introducing Yjs DevTools and API improvements",
                    description: "With this release, we’ve added Yjs to our DevTools extension, enabling you to inspect your Yjs application as you build. We’ve also improved the events API, and our Node.js package now supports edge environments.",
                    date: new Date(2023, 9, 3),
                    image: "/images/blog/whats-new-in-v1-4/whats-new-in-v1-4.jpg",
                    socialImage: "/images/blog/social-images/whats-new-in-v1-4.png",
                    href: "/blog/liveblocks-1-4-introducing-yjs-devtools-and-api-improvements",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2023_10_12": {
                    title: "Liveblocks is SOC 2 compliant",
                    description: "Today we are proud to announce our SOC 2 Type I certification. Following a thorough audit of our processes, and how we manage customer data, this achievement underscores our commitment to security in the Liveblocks platform.",
                    date: new Date(2023, 9, 12),
                    image: "/images/blog/liveblocks-is-soc2-compliant/liveblocks-is-soc2-compliant.png",
                    socialImage: "/images/blog/social-images/liveblocks-is-soc2-compliant.png",
                    href: "/blog/liveblocks-is-soc2-compliant",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [i]
                },
                "2023_10_24": {
                    title: "Liveblocks 1.5: Foundational API improvements",
                    description: "With Liveblocks 1.5, we’re introducing many foundational API improvements, enabling you to automatically disconnect background connections, use multiple room instances per page, easily clone Storage data, and more.",
                    date: new Date(2023, 9, 24),
                    image: "/images/blog/whats-new-in-v1-5/whats-new-in-v1-5.png",
                    socialImage: "/images/blog/social-images/whats-new-in-v1-5.png",
                    href: "/blog/liveblocks-1-5-foundational-api-improvements",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [l]
                },
                "2023_10_31": {
                    title: "Liveblocks 1.6: Introducing Yjs subdocuments support",
                    description: "Today, we’re excited to announce Yjs subdocuments support on Liveblocks, two months after introducing Liveblocks Yjs. This new feature brings a more dynamic and efficient way to manage collaborative editing and data handling of Yjs documents.",
                    date: new Date(2023, 9, 31),
                    image: "/images/blog/yjs-subdocuments/yjs-subdocuments-support.png",
                    socialImage: "/images/blog/social-images/yjs-subdocuments-support.png",
                    href: "/blog/liveblocks-1-6-introducing-yjs-subdocuments-support",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [{
                        avatar: "/images/people/jonathan-rowny.jpg",
                        name: "Jonathan Rowny",
                        title: "Software Engineer, Liveblocks",
                        xHandle: "Jrowny"
                    }]
                },
                "2023_11_02": {
                    title: "Liveblocks Comments is available for everyone",
                    description: "Earlier this year, we announced that Liveblocks Comments was entering private beta and have since collaborated with dozens of design partners to help shape the best product possible. Today, we’re excited to open up Liveblocks Comments to everyone as a public beta.",
                    date: new Date(2023, 10, 2),
                    image: "/images/blog/liveblocks-comments/liveblocks-comments.png",
                    socialImage: "/images/blog/social-images/liveblocks-comments.png",
                    href: "/blog/liveblocks-comments-is-available-for-everyone",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [t]
                },
                "2023_11_22": {
                    title: "Liveblocks 1.8: Typed REST APIs and easy Comments notifications",
                    description: "Today we’re introducing new typed REST API methods, making integrating Liveblocks into your back end easier than ever. We’re also adding functions to help you transform comments, and create email notifications more easily.",
                    date: new Date(2023, 10, 22),
                    image: "/images/blog/liveblocks-1-8/whats-new-in-v1-8.png",
                    socialImage: "/images/blog/social-images/whats-new-in-v1-8.png",
                    href: "/blog/liveblocks-1-8-typed-rest-apis-and-easy-comments-notifications",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2023_12_18": {
                    title: "Liveblocks 1.9: Comments improvements that enable AI agents, chat moderation, thread filtering, and more",
                    description: "Today we’re introducing a way to programmatically create and modify comments, enabling AI agents, chat moderation, and more. We’re also adding a new option to filter threads by metadata.",
                    date: new Date(2023, 11, 18),
                    image: "/images/blog/liveblocks-1-9/whats-new-in-v1-9.png",
                    socialImage: "/images/blog/social-images/whats-new-in-v1-9.png",
                    href: "/blog/liveblocks-1-9-comments-improvements-that-enable-ai-agents-chat-moderation-thread-filtering-and-more",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_01_12": {
                    title: "Dashboard refinements and a free plan for Comments",
                    description: "Today we’re announcing various refinements to our dashboard, improving usability. We’re also releasing a free plan for Liveblocks comments, allowing up to 1,000 comments per month.",
                    date: new Date(2024, 0, 12),
                    image: "/images/blog/dashboard-improvements-jan-2024/dashboard-improvements-jan-2024.jpg",
                    socialImage: "/images/blog/social-images/dashboard-improvements-jan-2024.jpg",
                    href: "/blog/dashboard-refinements-and-a-free-plan-for-comments",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_02_14": {
                    title: "Liveblocks 1.10: Notifications support for Comments",
                    description: "Today, we’re adding Notifications support for Comments. As part of this update, we shipped pre-built React components and hooks to add a notifications inbox to your app, a brand new notification system, as well as a new webhook event to send perfectly timed email notifications.",
                    date: new Date(2024, 1, 21),
                    image: "/images/blog/liveblocks-1-10/liveblocks-1-10.jpg",
                    socialImage: "/images/blog/social-images/liveblocks-1-10.jpg",
                    href: "/blog/liveblocks-1-10-notifications-for-comments",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [t]
                },
                "2024_03_21": {
                    title: "Liveblocks 1.11: Authentication updates and Comments improvements",
                    description: "Today, we’re updating our authentication recommendations and making various Comments improvements. We’re also making improvements to Yjs subdocuments and introducing a way to rename your room IDs.",
                    date: new Date(2024, 2, 21),
                    image: "/images/blog/liveblocks-1-11/liveblocks-1-11.jpg",
                    socialImage: "/images/blog/social-images/liveblocks-1-11.jpg",
                    href: "/blog/liveblocks-1-11-authentication-updates-and-comments-improvements",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_04_22": {
                    title: "Liveblocks 1.12: Advanced filtering and custom notifications",
                    description: "Liveblocks 1.12 introduces advanced filtering to threads and rooms,  custom notifications in alpha, a new inbox notification thread hook, a new example, and an upgraded Next.js Starter Kit.",
                    date: new Date(2024, 4, 2),
                    image: "/images/blog/liveblocks-1-12/liveblocks-1-12.jpg",
                    socialImage: "/images/blog/social-images/liveblocks-1-12.jpg",
                    href: "/blog/liveblocks-1-12-advanced-filtering-and-custom-notifications",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_06_03": {
                    title: "What’s new in Liveblocks: May edition",
                    description: "We’ve made a number of changes to our website, providing you with insight into our updates, your users, and your usage. We’ve also improved our onboarding and documentation.",
                    date: new Date(2024, 5, 3),
                    image: "/images/blog/updates/may-2024.jpg",
                    socialImage: "/images/blog/social-images/updates/may-2024.jpg",
                    href: "/blog/whats-new-in-liveblocks-may-edition-2024",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_06_12": {
                    title: "Introducing Liveblocks 2.0",
                    description: "Today, I’m thrilled to introduce Liveblocks 2.0, the platform for adding collaborative editing, comments, and notifications into your application in days, not months.",
                    date: new Date(2024, 5, 12),
                    image: "/images/blog/liveblocks-2-0/liveblocks-2-0.jpg",
                    socialImage: "/images/blog/social-images/liveblocks-2-0.jpg",
                    href: "/blog/introducing-liveblocks-2-0",
                    category: d.l.INSIDE_LIVEBLOCKS,
                    authors: [t]
                },
                "2024_06_18": {
                    title: "How Zapier added collaborative features to their Canvas product in just a couple of weeks",
                    description: "Learn how Zapier used Liveblocks to add table stakes collaborative features like realtime multiplayer editing, comments, and notifications to Canvas in just a couple of weeks.",
                    image: "/images/blog/zapier/zapier-canvas.jpg",
                    socialImage: "/images/blog/social-images/zapier-canvas.jpg",
                    date: new Date(2024, 5, 18),
                    href: "/blog/how-zapier-added-collaborative-features-to-their-canvas-product-in-just-a-couple-of-weeks",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [t]
                },
                "2024_06_25": {
                    title: "Introducing the Liveblocks Collaboration Kit for Figma",
                    description: "Today, we’re releasing the Liveblocks Collaboration Kit for Figma, a set of UI elements to help you visualize what a collaborative version of your product would look and feel like.",
                    date: new Date(2024, 5, 25),
                    image: "/images/blog/liveblocks-collaboration-kit-for-figma/liveblocks-collaboration-kit-for-figma.jpg",
                    socialImage: "/images/blog/social-images/liveblocks-collaboration-kit-for-figma.jpg",
                    href: "/blog/introducing-liveblocks-collaboration-kit-for-figma",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [t, {
                        avatar: "/images/people/pierre-levaillant.jpg",
                        name: "Pierre Le Vaillant",
                        title: "Design Engineer, Liveblocks",
                        xHandle: "levaillantp"
                    }]
                },
                "2024_07_02": {
                    title: "How Hashnode added collaboration to their text editor to sell to larger organizations",
                    description: "Learn how Hashnode used Liveblocks to add all the table stakes collaborative features to their text editor to sell their platform to larger teams.",
                    date: new Date(2024, 6, 2),
                    image: "/images/blog/hashnode/hashnode.jpg",
                    socialImage: "/images/blog/social-images/hashnode.jpg",
                    href: "/blog/how-hashnode-added-collaboration-to-their-text-editor-to-sell-to-larger-organizations",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [t]
                },
                "2024_07_08": {
                    title: "What’s new in Liveblocks: June edition",
                    description: "We’ve released Liveblocks 2.0 and our new core products, one of which includes new text editor packages for Lexical. We’ve also added some new React hooks, and created lots of new content.",
                    date: new Date(2024, 6, 8),
                    image: "/images/blog/updates/june-2024.jpg",
                    socialImage: "/images/blog/social-images/updates/june-2024.jpg",
                    href: "/blog/whats-new-in-liveblocks-june-edition-2024",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_08_02": {
                    title: "How Agility CMS leveraged collaboration to grow their customer base",
                    description: "Discover how Agility CMS enhanced collaboration in their product by integrating Liveblocks, expanding their user base through new comments and notifications features.",
                    date: new Date(2024, 7, 2),
                    image: "/images/blog/agility-cms/agility-cms.jpg",
                    socialImage: "/images/blog/social-images/agility-cms.jpg",
                    href: "/blog/how-agility-cms-leveraged-collaboration-to-grow-their-customer-base",
                    category: d.l.CUSTOMER_STORIES,
                    authors: [n]
                },
                "2024_08_07": {
                    title: "What’s new in Liveblocks: July edition",
                    description: "We’ve released improvements in many areas of our products including an improved dashboard, new Text Editor components, JavaScript support for Comments & Notifications, and a number of other small additions.",
                    date: new Date(2024, 7, 7),
                    image: "/images/blog/updates/july-2024.jpg",
                    socialImage: "/images/blog/social-images/updates/july-2024.jpg",
                    href: "/blog/whats-new-in-liveblocks-july-edition-2024",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_09_03": {
                    title: "Dashboard enhancements to improve observability and developer experience",
                    description: "Introducing new dashboard features including room state visualizations, custom event broadcasting, and improved user monitoring, elevating developer experience and observability.",
                    date: new Date(2024, 8, 3),
                    image: "/images/blog/dashboard-enhancements-2024/dashboard-enhancements-2024.jpg",
                    socialImage: "/images/blog/social-images/dashboard-enhancements-2024.jpg",
                    href: "/blog/dashboard-enhancements-to-improve-observability-and-developer-experience",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_09_05": {
                    title: "What’s new in Liveblocks: August edition",
                    description: "We’ve significantly enhanced our dashboard, alongside other changes, such as conditionally rendering Liveblocks hooks, fetching unread notifications, a better search dialog, and improved Comments examples.",
                    date: new Date(2024, 8, 5),
                    image: "/images/blog/updates/august-2024.jpg",
                    socialImage: "/images/blog/social-images/updates/august-2024.jpg",
                    href: "/blog/whats-new-in-liveblocks-august-edition-2024",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_09_23": {
                    title: "Next.js Template Week recap",
                    description: "Next.js Template Week has just ended, a three-day virtual event showcasing Next.js templates inspired by world‑class collaborative products. Here’s a recap of our new templates.",
                    date: new Date(2024, 8, 23),
                    image: "/images/blog/nextjs-template-week/nextjs-template-week-recap.jpg",
                    socialImage: "/images/blog/social-images/nextjs-template-week-recap.jpg",
                    href: "/blog/nextjs-template-week-recap",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_10_03": {
                    title: "Introducing attachments for Comments",
                    description: "Introducing attachments for Comments and Text Editor, an update to our React components which allows users to share files with one another. We’ve also added new primitives to support custom components.",
                    date: new Date(2024, 9, 3),
                    image: "/images/blog/introducing-attachments/introducing-attachments-for-comments.jpg",
                    socialImage: "/images/blog/social-images/introducing-attachments-for-comments.jpg",
                    href: "/blog/introducing-attachments-for-comments",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_10_08": {
                    title: "What’s new in Liveblocks: September edition",
                    description: "We’ve released a number of new product-inspired templates, built some interesting projects in our company hackathon, and made many small bug fixes.",
                    date: new Date(2024, 9, 8),
                    image: "/images/blog/updates/september-2024.jpg",
                    socialImage: "/images/blog/social-images/updates/september-2024.jpg",
                    href: "/blog/whats-new-in-liveblocks-september-edition-2024",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                },
                "2024_11_05": {
                    title: "What’s new in Liveblocks: October edition",
                    description: "We’ve released pagination for Comments & Notifications, a way to revalidate user & room data, added further support for attachments, and are now offering new discounts for startups.",
                    date: new Date(2024, 10, 5),
                    image: "/images/blog/updates/october-2024.jpg",
                    socialImage: "/images/blog/social-images/updates/october-2024.jpg",
                    href: "/blog/whats-new-in-liveblocks-october-edition-2024",
                    category: d.l.PRODUCT_UPDATES,
                    authors: [n]
                }
            }
        }
    }
]);