"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2760], {
        2131: function(e, a, t) {
            t.d(a, {
                Q: function() {
                    return p
                }
            });
            var o = t(85893),
                r = t(59688),
                s = t(69230),
                i = t(4635),
                n = t(99704),
                l = t(39350),
                m = t(36605),
                c = t(60169);
            let p = {
                MAX_STOIBER: {
                    type: "x",
                    quote: "The next generation of SaaS products are all going to be realtime collaborative. But building one is waaaay to hard!\n\nLiveblocks makes it so much simpler it's unreal: https://liveblocks.io \uD83D\uDD25\n            \nPumped to be an investor!",
                    author: {
                        name: "Max Stoiber",
                        avatarUrl: "/images/people/max-stoiber.jpg",
                        companyAvatarUrl: "/images/companies/avatars/stellate.png",
                        title: "Co-founder",
                        companyName: "Stellate"
                    },
                    href: "https://x.com/mxstbr/status/1399778885504540678"
                },
                KYLE_SCHAEFFER: {
                    type: "case-study",
                    quote: "When we discovered Liveblocks, it was as if someone answered all of our questions and gave us exactly what we were looking for. Everything became much easier. We were able to free ourselves to focus on what mattered to us: make image generation exciting through AI and machine learning.",
                    author: {
                        name: "Kyle Schaeffer",
                        title: "Engineering Manager",
                        avatarUrl: "/images/people/kyle-schaeffer.jpg",
                        companyLogo: (0, o.jsx)(n.Z, {}),
                        companyAvatarUrl: "/images/companies/avatars/facetai.jpg",
                        companyName: "Facet.ai"
                    },
                    href: c.D["2023_01_10"].href
                },
                JYE_LEWIS: {
                    type: "case-study",
                    quote: (0, o.jsxs)(o.Fragment, {
                        children: ["A super underrated and unexpected victory with Liveblocks is not maintaining infrastructure.", " ", (0, o.jsx)("em", {
                            children: "We can just focus on the front end and have the collaboration infrastructure handled by Liveblocks"
                        }), "."]
                    }),
                    author: {
                        name: "Jye Lewis",
                        title: "Engineering Manager",
                        avatarUrl: "/images/people/jye-lewis.jpg",
                        companyLogo: (0, o.jsx)(m.Z, {}),
                        companyAvatarUrl: "/images/companies/avatars/propeller.png",
                        companyName: "Propeller Aero"
                    },
                    href: c.D["2023_01_10"].href
                },
                OSCAR_CUATRECASA: {
                    type: "case-study",
                    quote: "We were able to seamlessly integrate Liveblocks in just one week. It was impressive to see how quickly we were able to convert our existing product into a collaborative one.",
                    author: {
                        name: "Oscar Cuatrecasa",
                        title: "Co-Founder and CTO",
                        avatarUrl: "/images/people/oscar-cuatrecasas-aragay.jpg",
                        companyAvatarUrl: "/images/companies/avatars/fermat.jpg",
                        companyName: "FERMAT"
                    },
                    href: c.D["2023_06_01"].href
                },
                TOM_GIANNATTASIO: {
                    type: "case-study",
                    quote: (0, o.jsxs)(o.Fragment, {
                        children: ["Liveblocks enabled us to add realtime presence to our application in hours instead of weeks and we don’t have to worry about maintenance.", (0, o.jsx)("em", {
                            children: "This is a no‑brainer for anyone building collaborative experiences"
                        }), "."]
                    }),
                    author: {
                        name: "Tom Giannattasio",
                        avatarUrl: "/images/people/tom-giannattasio.jpg",
                        companyLogo: (0, o.jsx)(s.Z, {}),
                        companyAvatarUrl: "/images/companies/avatars/clover.jpg",
                        title: "CEO",
                        companyName: "Clover"
                    },
                    href: c.D["2021_11_07"].href
                },
                ALEXIS_SMIRNOV: {
                    type: "case-study",
                    quote: (0, o.jsxs)(o.Fragment, {
                        children: ["One of our team used Liveblocks during a hackathon. When they presented their demo, everyone was blown away.", " ", (0, o.jsx)("em", {
                            children: "Within two short days, they were able to increase efficiency of our care team"
                        }), ", solve a significant pain point and make our internal tool more delightful and faster to use.", " ", (0, o.jsx)("em", {
                            children: "The best part? It was production ready"
                        }), ". The outcome is fantastic, our care team gets more time to focus on their most important task: taking care of our members."]
                    }),
                    author: {
                        name: "Alexis Smirnov",
                        title: "CTO",
                        avatarUrl: "/images/people/alexis-smirnov.jpg",
                        companyLogo: (0, o.jsx)(i.Z, {}),
                        companyAvatarUrl: "/images/companies/avatars/dialogue.png",
                        companyName: "Dialogue"
                    }
                },
                BRIAN_LOVIN: {
                    type: "x",
                    quote: "Finally got my hands on the @liveblocks beta this weekend and I added realtime multiplayer to my personal website. Realtime-experiences-as-a-service = magical ✨\n\nCheck it out: https://brianlovin.com",
                    author: {
                        name: "Brian Lovin",
                        avatarUrl: "/images/people/brian-lovin.jpg",
                        title: "Founder",
                        companyName: "Campsite"
                    },
                    href: "https://x.com/brian_lovin/status/1389307612043251714"
                },
                MICHAEL_AUBRY: {
                    type: "case-study",
                    quote: (0, o.jsxs)(o.Fragment, {
                        children: ["Liveblocks is our temporary frontline data store for realtime collaboration. The persisted data is synced on our database to have full control over the security. With Liveblocks, the app is fast and really smooth.", " ", (0, o.jsx)("em", {
                            children: "When we released Liveblocks multiplayer we got more conversions that’we ever gotten in any given week"
                        }), "."]
                    }),
                    author: {
                        name: "Michael Aubry",
                        avatarUrl: "/images/people/michael-aubry.jpg",
                        companyLogo: (0, o.jsx)(l.Z, {}),
                        companyAvatarUrl: "/images/companies/avatars/motionbox.jpg",
                        title: "CEO",
                        companyName: "Motionbox"
                    },
                    href: c.D["2022_03_10"].href
                },
                MICHAEL_AUBRY_2: {
                    type: "x",
                    quote: "Shoutout to @liveblocks for making collaboration possible.",
                    author: {
                        name: "Michael Aubry",
                        avatarUrl: "/images/people/michael-aubry.jpg",
                        companyAvatarUrl: "/images/companies/avatars/motionbox.jpg",
                        title: "CEO",
                        companyName: "Motionbox"
                    },
                    href: "https://x.com/michaelaubry/status/1592613873403965440"
                },
                RADAMES_AJNA: {
                    type: "x",
                    quote: "We've been working on a multiplayer experiment for #StableDiffusion powered by @huggingface GPU Space and multiplayer API by @liveblocks, inspired by @lkwq007 SD infinity project \n\ncoming soon -",
                    author: {
                        name: "Radam\xe9s Ajna",
                        avatarUrl: "/images/people/radames-ajna.jpg",
                        companyAvatarUrl: "/images/companies/avatars/hugging-face.png",
                        title: "Engineering at Hugging Face",
                        companyName: "Hugging Face"
                    },
                    href: "https://x.com/radamar/status/1585775004196556800"
                },
                CALI_CASTLE: {
                    type: "x",
                    quote: "@liveblocks APIs are always such a breeze and delight to work with",
                    author: {
                        name: "Cali Castle",
                        avatarUrl: "/images/people/cali-castle.jpg",
                        companyAvatarUrl: "/images/companies/avatars/zolplay.png",
                        title: "Founder",
                        companyName: "Zolplay"
                    },
                    href: "https://x.com/thecalicastle/status/1583643473953292289"
                },
                KASPER_MIKIEWICZ: {
                    type: "x",
                    quote: "I love how they stuffed all that complex undo/redo logic into a few lines of code \uD83E\uDD2F",
                    author: {
                        name: "Kasper Mikiewicz",
                        avatarUrl: "/images/people/kasper-mikiewicz.jpg",
                        companyAvatarUrl: "/images/companies/avatars/glimpse.png",
                        title: "Developer",
                        companyName: "Glimpse"
                    },
                    href: "https://x.com/Idered/status/1580948672501514243"
                },
                STEVE_RUIZ: {
                    type: "x",
                    quote: "The team at @liveblocks is killing it with their undo/redo API. I feel seen \uD83D\uDE0C",
                    author: {
                        name: "Steve Ruiz",
                        avatarUrl: "/images/people/steve-ruiz.jpg",
                        companyAvatarUrl: "/images/companies/avatars/tldraw.jpg",
                        title: "Founder",
                        companyName: "Tldraw"
                    },
                    href: "https://x.com/steveruizok/status/1459628166675324931"
                },
                STEVE_RUIZ_2: {
                    type: "x",
                    quote: "Tldraw’s ability to spread virally exists just because of the multiplayer. There is no login, you just share a link and you’re there with someone else collaborating. Liveblocks has made a big difference in terms of how people are introduced to the product and how it spreads. This wouldn’t have been possible without Liveblocks technology.",
                    author: {
                        name: "Steve Ruiz",
                        avatarUrl: "/images/people/steve-ruiz.jpg",
                        companyAvatarUrl: "/images/companies/avatars/tldraw.jpg",
                        title: "Founder",
                        companyName: "Tldraw"
                    },
                    href: c.D["2022_03_23"].href
                },
                GRANT_FORREST: {
                    type: "case-study",
                    quote: "I think a big impact for us as a very small startup is the ability to pivot quickly between some different ideas until we found this one that we’re really excited about. Just having the opportunity to basically pick up off-the-shelf live, realtime data integration is huge. As a small team that needs to move fast and focus on a lot of different things, it’s an accelerator to get us into this product space that we normally might not have been able to access, because we would have been too bogged down on the technical work of making the real time data work in it.",
                    author: {
                        name: "Grant Forrest",
                        avatarUrl: "/images/people/grant-forrest.jpg",
                        companyAvatarUrl: "/images/companies/avatars/popstage.png",
                        title: "Founding Engineer",
                        companyName: "PopStage"
                    },
                    href: c.D["2022_05_23"].href
                },
                STEVEN_TEY: {
                    type: "x",
                    quote: "This is a gamechanger \uD83E\uDD29\n\nUntil today, the infra behind live collaboration used to be something that could only be built by massive engineering teams at Google, Figma etc.\n          \nBut with @Liveblocks, _any_ engineer can build a world-class realtime tool in just a few lines of code ✨",
                    author: {
                        name: "Steven Tey",
                        avatarUrl: "/images/people/steven-tey.jpg",
                        title: "Developer Advocate",
                        companyAvatarUrl: "/images/companies/avatars/vercel.png",
                        companyName: "Vercel"
                    },
                    href: "https://x.com/steventey/status/1420880996325462018"
                },
                CHRIS_LAUGHLIN: {
                    type: "twitch",
                    quote: "This Liveblocks tool is cool! I tried the exact same thing with Firebase and after four hours, I got so angry that I gave up!",
                    author: {
                        name: "Chris Laughlin",
                        avatarUrl: "/images/people/chris-laughlin.jpg",
                        title: "@thedyslexicdeveloper"
                    },
                    image: {
                        url: "/images/testimonials/chris-laughlin-video-twitch.png",
                        width: 1012,
                        height: 506
                    },
                    href: "https://youtu.be/TeGvJ3ieLJQ?t=4046"
                },
                IAN_STORM_TAYLOR: {
                    type: "x",
                    quote: "Liveblocks is such a good idea! I've written collaborative editing logic and I'd much rather never have to write it again \uD83D\uDE04 definitely going to use this next time.",
                    author: {
                        name: "Ian Storm Taylor",
                        avatarUrl: "/images/people/ian-storm-taylor.png",
                        title: "Co-founder",
                        companyAvatarUrl: "/images/companies/avatars/segment.png",
                        companyName: "Segment"
                    },
                    href: "https://x.com/ianstormtaylor/status/1420884313827016708"
                },
                JONATHAN_CAI: {
                    type: "x",
                    quote: "holy shit @liveblocks is magic",
                    author: {
                        name: "Jonathan Cai",
                        avatarUrl: "/images/people/jonathan-cai.jpg",
                        companyAvatarUrl: "/images/companies/avatars/meta.png",
                        companyName: "Meta",
                        title: "Engineer"
                    },
                    href: "https://x.com/jonathanmcai/status/1444463110404722688"
                },
                GABE_RAGLAND: {
                    type: "x",
                    quote: "Add multiplayer functionality to your app with a couple lines of code. Even has built-in React hooks \uD83E\uDD2F http://liveblocks.io\n\nLove what you're building @stevenfabre @guillaume_slls",
                    author: {
                        name: "Gabe Ragland",
                        avatarUrl: "/images/people/gabe-ragland.png",
                        title: "@gabe_ragland"
                    },
                    href: "https://x.com/gabe_ragland/status/1420768361735094276"
                },
                RENE_PIER: {
                    type: "x",
                    quote: "I want to say a huge thank you to the team over at @liveblocks for having helped me during integration and for helping the entire Fari community with opportunity to have the best online TTRPG experience there is.",
                    author: {
                        name: "Ren\xe9-Pier",
                        avatarUrl: "/images/people/rene-pier.jpg",
                        title: "@RPDeshaies"
                    },
                    href: "https://x.com/RPDeshaies/status/1495819782041616387"
                },
                CHRIS_NICHOLAS: {
                    type: "x",
                    quote: "I’m so impressed with @liveblocks; when @stevenfabre suggested the idea of a demo that lets you play music together, I was feeling quite sceptical. What about the delay? I went ahead, built the demo, and amazingly, Liveblocks is so quick you can actually make music together \uD83D\uDC4C",
                    author: {
                        name: "Chris Nicholas",
                        avatarUrl: "/images/people/chris-nicholas.jpg",
                        title: "@ctnicholasdev"
                    },
                    href: "https://x.com/ctnicholasdev/status/1485643821228699652"
                },
                GRANT_CUSTER: {
                    type: "case-study",
                    quote: "I’ve often been reluctant to rely on outside services, but Liveblocks’ team has been super helpful in terms of tracking stuff down that’s going wrong or offering some advice on how to structure things. They helped us with that transition over to the API, which took about a month.",
                    author: {
                        name: "Grant Custer",
                        avatarUrl: "/images/people/grant-custer.jpg",
                        companyAvatarUrl: "/images/companies/avatars/sprout.jpg",
                        title: "Software Developer",
                        companyName: "Sprout"
                    },
                    href: c.D["2021_11_07"].href
                },
                SHREEKANT_PAWAR: {
                    type: "x",
                    quote: "We are in the process of integrating @liveblocks on @SketchnoteCo\n      \nSo far the entire process has been seamless and @stevenfabre is absolute rockstar, hats off to him and his team for building such an amazing product!",
                    author: {
                        name: "Shreekant Pawar",
                        avatarUrl: "/images/people/shreekant-pawar.jpg",
                        companyAvatarUrl: "/images/companies/avatars/sketchnote.jpg",
                        title: "Co-founder at Sketchnote",
                        companyName: "Sketchnote"
                    },
                    href: "https://x.com/FreakShreek/status/1642907254625284096"
                },
                JOHN_PHAM: {
                    type: "x",
                    quote: "Our @vercel ship livestream saw a total of 340,157 reactions.\n\nThe craziest part?\n\nWe went from idea → production in 2 days—thanks to our friends at @liveblocks!",
                    author: {
                        name: "John Pham",
                        title: "Design Engineer",
                        avatarUrl: "/images/people/john-pham.jpg",
                        companyAvatarUrl: "/images/companies/avatars/vercel.png",
                        companyName: "Vercel"
                    },
                    image: {
                        url: "/images/testimonials/john-pham-video-live-reactions-vercel.png",
                        width: 746,
                        height: 415
                    },
                    href: "https://x.com/JohnPhamous/status/1654534403245375488"
                },
                GUILLERMO_RAUCH: {
                    type: "x",
                    quote: "realtime powered by @liveblocks \uD83D\uDD25\uD83C\uDDEB\uD83C\uDDF7",
                    author: {
                        name: "Guillermo Rauch",
                        title: "CEO",
                        avatarUrl: "/images/people/guillermo-rauch.jpg",
                        companyAvatarUrl: "/images/companies/avatars/vercel.png",
                        companyName: "Vercel"
                    },
                    href: "https://x.com/rauchg/status/1654142177746747395"
                },
                PAUL_OCARROLL: {
                    type: "case-study",
                    quote: (0, o.jsxs)(o.Fragment, {
                        children: ["We researched the best realtime collaborative architecture provider. We decided to go with Liveblocks and rely on everything with them, partly because we met the team and enjoyed working with them and partly because", " ", (0, o.jsx)("em", {
                            children: "Liveblocks is stable and amazing"
                        }), "."]
                    }),
                    author: {
                        name: "Paul O’Carroll",
                        title: "CEO",
                        avatarUrl: "/images/people/paul-ocarroll.jpeg",
                        companyLogo: (0, o.jsx)(r.Z, {}),
                        companyAvatarUrl: "/images/companies/avatars/arcol.jpeg",
                        companyName: "Arcol"
                    },
                    href: c.D["2023_03_28"].href
                },
                ROB_HAYES: {
                    type: "x",
                    quote: "This was a full year of development at Voiceflow to enable:\n    - realtime cursors\n    - commenting\n    - advanced roles and permissions\n    \nAnd now it can be added out-of-the-box \uD83E\uDD2F",
                    author: {
                        name: "Rob Hayes",
                        title: "Head of Growth at Voicefow",
                        avatarUrl: "/images/people/rob-hayes.jpg",
                        companyAvatarUrl: "/images/companies/avatars/voiceflow.jpg",
                        companyName: "Voiceflow"
                    },
                    href: "https://x.com/TheRobHayes/status/1743276292533793186"
                },
                JASPER_KENSE: {
                    type: "x",
                    quote: "Just added #collaboration features to Qanda with @liveblocks. What a great experience so far!\n    \nYou can now use Qanda with your team to work on transcriptions together!",
                    author: {
                        name: "Jasper Kense",
                        title: "@JasperKense",
                        avatarUrl: "/images/people/jasper-kense.png",
                        companyAvatarUrl: "/images/companies/avatars/qanda.png",
                        companyName: "Qanda"
                    },
                    href: "https://twitter.com/JasperKense/status/1743995518911447402"
                },
                LUKE_THOMAS: {
                    type: "case-study",
                    quote: (0, o.jsxs)(o.Fragment, {
                        children: ["Liveblocks has enabled us to test and validate collaborative use‑cases without needing to invest several months of dev time into a solution that might work.", " ", (0, o.jsx)("strong", {
                            children: "It helps us de-risk our roadmap meaningfully, especially for a small team"
                        }), "."]
                    }),
                    author: {
                        name: "Luke Thomas",
                        title: "Director of New Products",
                        avatarUrl: "/images/people/luke-thomas.jpg",
                        companyAvatarUrl: "/images/companies/avatars/zapier.jpg",
                        companyName: "Zapier"
                    }
                },
                JOEL_VARTY: {
                    type: "case-study",
                    quote: (0, o.jsxs)(o.Fragment, {
                        children: [(0, o.jsx)("strong", {
                            children: "Liveblocks took us from 0-100 really fast"
                        }), ". Instead of having to micromanage all the implementation details of the collaborative functionality, we could focus more on how we wanted that to work for our customers."]
                    }),
                    author: {
                        name: "Joel Varty",
                        title: "CTO",
                        avatarUrl: "/images/people/joel-varty.jpg",
                        companyAvatarUrl: "/images/companies/avatars/agility-cms.png",
                        companyName: "Agility CMS"
                    }
                },
                DEV_SHEKHAWAT: {
                    type: "case-study",
                    quote: (0, o.jsxs)(o.Fragment, {
                        children: ["The biggest impact Liveblocks had on our business is faster time-to-market. ", (0, o.jsx)("strong", {
                            children: "We could go to market in record time"
                        }), " ", "and provide our enterprise customers with realtime collaboration and commenting features."]
                    }),
                    author: {
                        name: "Dev Shekhawat",
                        title: "Software Engineer",
                        avatarUrl: "/images/people/dev-shekhawat.jpg",
                        companyAvatarUrl: "/images/companies/avatars/hashnode.jpg",
                        companyName: "Hashnode"
                    }
                }
            }
        },
        38122: function(e, a, t) {
            t.d(a, {
                S: function() {
                    return l
                }
            });
            var o = t(85893),
                r = t(41664),
                s = t.n(r);
            t(67294);
            var i = t(87527),
                n = t(20402);
            let l = Object.assign(e => {
                var a, t, r, s, i, l;
                let {
                    children: m,
                    columns: c,
                    rows: p,
                    hasEqualHeightRows: g
                } = e, d = null !== (a = c.md) && void 0 !== a ? a : c.sm, u = null !== (t = c.lg) && void 0 !== t ? t : d, h = null !== (s = null !== (r = null == p ? void 0 : p.md) && void 0 !== r ? r : null == p ? void 0 : p.sm) && void 0 !== s ? s : void 0, v = null !== (i = null == p ? void 0 : p.lg) && void 0 !== i ? i : h;
                return (0, o.jsx)("div", {
                    style: {
                        "--grid-sm-cols": c.sm,
                        "--grid-md-cols": null != d ? d : void 0,
                        "--grid-lg-cols": null != u ? u : void 0,
                        "--grid-sm-rows": null !== (l = null == p ? void 0 : p.sm) && void 0 !== l ? l : void 0,
                        "--grid-md-rows": null != h ? h : void 0,
                        "--grid-lg-rows": null != v ? v : void 0
                    },
                    className: (0, n.cn)("grid", "gap-px", "grid-cols-[repeat(var(--grid-sm-cols),minmax(0,1fr))]", "[&>div]:col-[--grid-col-sm-span] [&>div]:overflow-hidden [&>div]:shadow-[0_0_0_1px_var(--border-color)] [&>div]:md:col-[--grid-col-md-span] [&>div]:lg:col-[--grid-col-lg-span]", {
                        "md:grid-cols-[repeat(var(--grid-md-cols),minmax(0,1fr))]": c.md,
                        "lg:grid-cols-[repeat(var(--grid-lg-cols),minmax(0,1fr))]": c.lg,
                        "sm:grid-rows-[repeat(var(--grid-sm-rows),minmax(0,1fr))] md:grid-rows-[repeat(var(--md-rows),minmax(0,1fr))] lg:grid-rows-[repeat(var(--lg-rows),minmax(0,1fr))]": p && g,
                        "sm:grid-rows-[repeat(var(--grid-sm-rows),auto)] md:grid-rows-[repeat(var(--md-rows),auto)] lg:grid-rows-[repeat(var(--lg-rows),auto)]": p && !g
                    }),
                    children: m
                })
            }, {
                System: e => {
                    let {
                        children: a,
                        className: t
                    } = e;
                    return (0, o.jsx)("div", {
                        className: (0, n.cn)(t, "[--border-color:var(--lb-marketing-color-border-divider-bold-opaque)]", "overflow-hidden rounded md:rounded-md lg:rounded-lg", "divide-y divide-[--border-color]", "ring-1 ring-[--border-color]"),
                        children: a
                    })
                },
                Cell: e => {
                    var a, t, r, s;
                    let {
                        className: i,
                        children: l,
                        column: m = {
                            sm: 1
                        },
                        row: c = {
                            sm: 1
                        },
                        noPadding: p
                    } = e, g = null !== (a = m.md) && void 0 !== a ? a : m.sm, d = null !== (t = m.lg) && void 0 !== t ? t : g, u = null !== (r = c.md) && void 0 !== r ? r : c.sm, h = null !== (s = c.lg) && void 0 !== s ? s : u;
                    return (0, o.jsx)("div", {
                        style: {
                            "--grid-col-sm-span": "span ".concat(m.sm, " / span ").concat(m.sm),
                            "--grid-col-md-span": "span ".concat(g, " / span ").concat(g),
                            "--grid-col-lg-span": "span ".concat(d, " / span ").concat(d),
                            "--grid-row-sm-span": "span ".concat(c.sm, " / span ").concat(c.sm),
                            "--grid-row-md-span": "span ".concat(u, " / span ").concat(u),
                            "--grid-row-lg-span": "span ".concat(h, " / span ").concat(h)
                        },
                        className: (0, n.cn)(i, "relative", {
                            "p-[--inner-gutter]": !p,
                            "row-[--grid-row-sm-span] sm:row-[--grid-row-md-span] lg:row-[--grid-row-lg-span]": c
                        }),
                        children: l
                    })
                },
                CellLink: e => {
                    let {
                        children: a,
                        href: t
                    } = e;
                    return (0, o.jsxs)(s(), {
                        className: "group/cell-link flex items-center gap-1.5 before:absolute before:inset-0",
                        href: t,
                        children: [a, (0, o.jsx)(i.Z, {
                            className: "h-4 w-auto fill-marketing md:h-5 md:opacity-0 md:transition-opacity md:duration-150 md:ease-out md:group-hover/cell-link:opacity-100"
                        })]
                    })
                }
            })
        },
        82925: function(e, a, t) {
            t.d(a, {
                x: function() {
                    return s
                }
            });
            var o = t(85893);
            t(67294);
            var r = t(20402);
            let s = Object.assign(e => {
                let {
                    children: a,
                    className: t,
                    ...s
                } = e;
                return (0, o.jsx)("div", {
                    className: (0, r.cn)(t, "text-marketing-subtler [&>h2]:font-medium [&>h2]:text-marketing [&>p>code]:text-marketing [&>p>em]:font-medium [&>p>em]:not-italic [&>p>em]:text-marketing [&>p>strong]:font-medium [&>p>strong]:text-marketing"),
                    ...s,
                    children: a
                })
            }, {
                WordWithIcon: e => {
                    let {
                        size: a = "md",
                        icon: t,
                        children: s
                    } = e;
                    return (0, o.jsxs)("span", {
                        className: (0, r.cn)("relative whitespace-nowrap", {
                            "pl-5 sm:pl-6": "sm" === a,
                            "pl-6 sm:pl-7": "md" === a,
                            "pl-7 sm:pl-8": "lg" === a
                        }),
                        children: [(0, o.jsx)("span", {
                            "aria-hidden": "true",
                            className: (0, r.cn)("absolute left-0 top-1/2 inline-flex -translate-y-1/2 items-center justify-center overflow-hidden", {
                                "size-3 sm:size-4 [&>svg]:max-h-3 [&>svg]:max-w-3 sm:[&>svg]:max-h-4 sm:[&>svg]:max-w-4": "sm" === a,
                                "size-4 sm:size-5 [&>svg]:max-h-4 [&>svg]:max-w-4 sm:[&>svg]:max-h-5 sm:[&>svg]:max-w-5": "md" === a,
                                "size-5 sm:size-6 [&>svg]:max-h-5 [&>svg]:max-w-5 sm:[&>svg]:max-h-6 sm:[&>svg]:max-w-6": "lg" === a
                            }),
                            children: t
                        }), s]
                    })
                }
            })
        },
        22132: function(e, a, t) {
            t.d(a, {
                Z: function() {
                    return n
                }
            });
            var o = t(85893),
                r = t(20402),
                s = t(67294);
            let i = e => {
                let {
                    text: a,
                    duration: t = 100,
                    className: r
                } = e, [i, n] = (0, s.useState)(""), l = (0, s.useCallback)(() => {
                    let e = 0,
                        o = setInterval(() => {
                            e < a.length ? (n(a.slice(0, e + 1)), e++) : clearInterval(o)
                        }, t);
                    return () => clearInterval(o)
                }, [a, t]);
                return (0, s.useEffect)(() => l(), [l]), (0, o.jsx)("span", {
                    className: r,
                    children: i
                })
            };

            function n(e) {
                let {
                    heading: a,
                    headingAs: t = "h2",
                    size: s = "md",
                    subheading: n,
                    description: l,
                    actions: m,
                    isLeftAligned: c,
                    className: p,
                    matchingSize: g,
                    animateSubheading: d
                } = e;
                return (0, o.jsxs)("div", {
                    className: (0, r.cn)(p, "flex flex-col", {
                        "items-start": c,
                        "items-center text-center": !c
                    }),
                    children: [(0, o.jsxs)(t, {
                        children: [n && (0, o.jsxs)("div", {
                            className: (0, r.cn)("relative inline-flex text-marketing-subtler", {
                                "f-marketing-label-xs mb-3 lg:mb-4": g && ("md" === s || "lg" === s),
                                "f-marketing-label-2xs mb-2 lg:mb-3": g && "sm" === s,
                                "f-marketing-label-sm": !g,
                                "mb-2 lg:mb-3.5": !g && "sm" === s,
                                "mb-3 lg:mb-4": !g && ("md" === s || "lg" === s)
                            }),
                            children: [d ? (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsx)(i, {
                                    text: n,
                                    duration: 50
                                }), (0, o.jsx)("span", {
                                    className: "animate-blink",
                                    children: "|"
                                })]
                            }) : n, (0, o.jsx)("span", {
                                className: "sr-only",
                                children: " - "
                            })]
                        }), a && (0, o.jsx)("div", {
                            className: (0, r.cn)("text-balance", {
                                "max-w-md sm:max-w-2xl lg:max-w-3xl xl:max-w-4xl": !g,
                                "f-marketing-display-sm": !g && "sm" === s,
                                "f-marketing-display-md": !g && "md" === s,
                                "f-marketing-display-lg": !g && "lg" === s,
                                "mb-2 lg:mb-3": !g && l && "sm" === s,
                                "mb-3 lg:mb-4": !g && l && "md" === s,
                                "mb-4 lg:mb-5": !g && l && "lg" === s,
                                "max-w-md sm:max-w-xl lg:max-w-2xl xl:max-w-3xl": g,
                                "f-marketing-body-sm font-medium": g && "sm" === s,
                                "f-marketing-body-md font-medium": g && "md" === s,
                                "f-marketing-body-lg font-medium": g && "lg" === s
                            }),
                            children: a
                        })]
                    }), l && (0, o.jsx)("p", {
                        className: (0, r.cn)("max-w-sm text-balance text-marketing-subtler sm:max-w-md md:max-w-lg [&>a]:underline [&>a]:decoration-marketing-divider-bold [&>a]:decoration-1 [&>a]:underline-offset-4 [&>a]:transition-colors [&>a]:duration-150 [&>a]:ease-out [&>a]:hover:decoration-marketing-divider-boldest [&>a]:focus:decoration-marketing-divider-boldest [&>code]:text-marketing [&>em]:font-medium [&>em]:not-italic [&>em]:text-marketing", {
                            "f-marketing-body-sm lg:max-w-xl": "sm" === s,
                            "f-marketing-body-md lg:max-w-2xl": "md" === s,
                            "f-marketing-body-lg lg:max-w-3xl": "lg" === s
                        }),
                        children: l
                    }), m && (0, o.jsx)("div", {
                        className: (0, r.cn)("inline-flex items-center gap-2 sm:gap-3", {
                            "mt-4 lg:mt-5": !g && "sm" === s,
                            "mt-5 lg:mt-6": !g && "md" === s,
                            "mt-6 lg:mt-8": !g && "lg" === s,
                            "mt-[calc(var(--inner-gutter)*0.75)]": g
                        }),
                        children: m
                    })]
                })
            }
        }
    }
]);