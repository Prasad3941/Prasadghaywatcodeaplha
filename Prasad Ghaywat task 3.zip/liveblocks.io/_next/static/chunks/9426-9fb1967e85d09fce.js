(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9426], {
        58571: function(e, t, n) {
            "use strict";
            var r, a = n(67294);

            function l() {
                return (l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            t.Z = function(e) {
                return a.createElement("svg", l({
                    "aria-hidden": "true",
                    focusable: "false",
                    width: 16,
                    height: 16,
                    viewBox: "0 0 16 16",
                    fill: "currentColor",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), r || (r = a.createElement("path", {
                    d: "M13 2h-2V1h-1v1H6V1H5v1H3c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h10c.55 0 1-.45 1-1V3c0-.55-.45-1-1-1Zm0 11H3V6h10v7Zm0-8H3V3h2v1h1V3h4v1h1V3h2v2Z"
                })))
            }
        },
        87527: function(e, t, n) {
            "use strict";
            var r, a = n(67294);

            function l() {
                return (l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            t.Z = function(e) {
                return a.createElement("svg", l({
                    "aria-hidden": "true",
                    focusable: "false",
                    width: 16,
                    height: 16,
                    viewBox: "0 0 16 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), r || (r = a.createElement("path", {
                    d: "m9.013 13-.962-.954 3.34-3.35H2V7.304h9.392L8.05 3.96 9.013 3 14 8l-4.987 5Z",
                    fill: "currentFill"
                })))
            }
        },
        76235: function(e, t, n) {
            "use strict";
            var r, a = n(67294);

            function l() {
                return (l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            t.Z = function(e) {
                return a.createElement("svg", l({
                    "aria-hidden": "true",
                    focusable: "false",
                    width: 16,
                    height: 16,
                    viewBox: "0 0 16 16",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), r || (r = a.createElement("path", {
                    d: "M13 7h-1v1h1a1.502 1.502 0 0 1 1.5 1.5v2h1v-2A2.503 2.503 0 0 0 13 7ZM12 2a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm0-1a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM11.5 15h-1v-1A1.502 1.502 0 0 0 9 12.5H7A1.502 1.502 0 0 0 5.5 14v1h-1v-1A2.503 2.503 0 0 1 7 11.5h2a2.503 2.503 0 0 1 2.5 2.5v1ZM8 6.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm0-1a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM4 7H3A2.503 2.503 0 0 0 .5 9.5v2h1v-2A1.502 1.502 0 0 1 3 8h1V7ZM4 2a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm0-1a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Z"
                })))
            }
        },
        12191: function(e, t, n) {
            "use strict";
            n.d(t, {
                xr: function() {
                    return u
                }
            });
            var r = n(85893),
                a = n(70699),
                l = n(93967),
                i = n.n(l),
                s = n(67294),
                o = n(34337),
                c = n.n(o);
            let u = (0, s.forwardRef)((e, t) => {
                    let {
                        children: n,
                        orientation: a = "both",
                        viewportRef: l,
                        ...i
                    } = e;
                    return (0, r.jsxs)(h, { ...i,
                        ref: t,
                        children: [(0, r.jsx)(d, {
                            ref: l,
                            children: n
                        }), ("vertical" === a || "both" === a) && (0, r.jsx)(f, {
                            orientation: "vertical",
                            children: (0, r.jsx)(m, {})
                        }), ("horizontal" === a || "both" === a) && (0, r.jsx)(f, {
                            orientation: "horizontal",
                            children: (0, r.jsx)(m, {})
                        })]
                    })
                }),
                h = (0, s.forwardRef)((e, t) => {
                    let {
                        children: n,
                        style: l,
                        ...i
                    } = e;
                    return (0, r.jsx)(a.fC, { ...i,
                        ref: t,
                        style: { ...l,
                            overflow: "hidden"
                        },
                        children: n
                    })
                }),
                d = (0, s.forwardRef)((e, t) => {
                    let {
                        children: n,
                        className: l,
                        ...s
                    } = e;
                    return (0, r.jsx)(a.l_, { ...s,
                        ref: t,
                        className: i()(l, c().viewport),
                        children: n
                    })
                }),
                f = (0, s.forwardRef)((e, t) => {
                    let {
                        children: n,
                        className: l,
                        ...s
                    } = e;
                    return (0, r.jsx)(a.LW, { ...s,
                        ref: t,
                        className: i()(l, c().scrollbar, "z-20"),
                        children: n
                    })
                }),
                m = (0, s.forwardRef)((e, t) => {
                    let {
                        className: n,
                        ...l
                    } = e;
                    return (0, r.jsx)(a.bU, { ...l,
                        ref: t,
                        className: i()(n, c().thumb)
                    })
                })
        },
        61205: function(e, t, n) {
            "use strict";
            n.d(t, {
                xr: function() {
                    return r.xr
                }
            });
            var r = n(12191)
        },
        12009: function(e, t, n) {
            "use strict";
            n.d(t, {
                IH: function() {
                    return a
                },
                _d: function() {
                    return i
                },
                bk: function() {
                    return l
                }
            });
            var r = n(29724);

            function a(e) {
                return "var(--".concat(r.VARIABLE_PREFIX, "-").concat(e.replaceAll(".", "-"), ")")
            }

            function l(e) {
                return "var(--".concat(r.VARIABLE_PREFIX, "-marketing-").concat(e.replaceAll(".", "-"), ")")
            }

            function i(e) {
                return "var(--".concat(r.VARIABLE_PREFIX, "-product-").concat(e.replaceAll(".", "-"), ")")
            }
        },
        29724: function(e) {
            "use strict";
            let t = "DEFAULT";

            function n() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return t.filter(e => e).join("-")
            }

            function r(e, t, n, r) {
                var a, l;
                for (let [i, s] of Object.entries(null !== (l = null == e ? void 0 : null === (a = e[t]) || void 0 === a ? void 0 : a[n]) && void 0 !== l ? l : {})) ! function e(t, n) {
                    let a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
                    if (function(e) {
                            let t = Object.keys(null != e ? e : {}),
                                n = 1 === t.length && (e.light || e.dark),
                                r = 2 === t.length && e.light && e.dark;
                            return n || r
                        }(n)) r([...a, t], n.light, n.dark);
                    else
                        for (let [r, l] of Object.entries(null != n ? n : {})) e(r, l, [...a, t])
                }(i, s)
            }

            function a(e) {
                return Array.isArray(e) ? n(...e.filter((n, r) => r !== e.length - 1 || n !== t)) : e
            }

            function l(e, t, r, l) {
                let i = "--".concat(n("lb", e, t, r));
                return n(i, a(l))
            }
            e.exports = {
                VARIABLE_PREFIX: "lb",
                DEFAULT_TOKEN: t,
                generateCSSVariables: function(e, t, n) {
                    let a = {},
                        i = {};
                    return r(e, t, n, (r, s, o) => {
                        let c = l(e.domain, t, n, r);
                        s && (a[c] = s), o && (i[c] = o)
                    }), {
                        light: a,
                        dark: i
                    }
                },
                generateTailwindValues: function(e, t, i) {
                    let s = {};
                    return r(e, t, i, r => {
                        let o = n(e.domain, a(r)),
                            c = l(e.domain, t, i, r);
                        s[o] = "var(".concat(c, ")")
                    }), s
                }
            }
        },
        35710: function(e, t, n) {
            "use strict";

            function r(e, t, n) {
                return isNaN(e) && (e = 0), Math.min(Math.max(e, t), n)
            }
            n.d(t, {
                u: function() {
                    return r
                }
            })
        },
        92690: function(e, t, n) {
            "use strict";
            async function r(e) {
                if (!navigator.clipboard) return function(e) {
                    let t = document.createElement("textarea");
                    t.value = e, t.style.top = "0", t.style.left = "0", t.style.position = "fixed", document.body.appendChild(t), t.focus(), t.select();
                    try {
                        return document.execCommand("copy"), document.body.removeChild(t), !0
                    } catch (e) {
                        return document.body.removeChild(t), !1
                    }
                }(e);
                try {
                    return await navigator.clipboard.writeText(e), !0
                } catch (e) {
                    return !1
                }
            }
            n.d(t, {
                Z: function() {
                    return r
                }
            })
        },
        24973: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return Z
                }
            });
            var r, a = n(85893),
                l = n(13114),
                i = n(51818),
                s = n(25675),
                o = n.n(s),
                c = n(67294),
                u = n(58571),
                h = n(20634),
                d = n(87527);

            function f() {
                return (f = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            var m = function(e) {
                    return c.createElement("svg", f({
                        "aria-hidden": "true",
                        focusable: "false",
                        width: 32,
                        height: 32,
                        viewBox: "0 0 32 32",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, e), r || (r = c.createElement("path", {
                        d: "M16 7C16.5071 7.00016 17.0128 7.05041 17.51 7.15C19.081 7.45087 20.5257 8.21576 21.6576 9.34589C22.7895 10.476 23.5567 11.9195 23.86 13.49L24.12 14.84L25.47 15.08C26.8335 15.3145 28.0586 16.0543 28.9009 17.1519C29.7433 18.2495 30.141 19.6242 30.0149 21.002C29.8887 22.3798 29.2479 23.6594 28.2202 24.5857C27.1925 25.5121 25.8535 26.017 24.47 26H7.50001C6.11656 26.017 4.77751 25.5121 3.74983 24.5857C2.72215 23.6594 2.08134 22.3798 1.95517 21.002C1.829 19.6242 2.22674 18.2495 3.06908 17.1519C3.91142 16.0543 5.13648 15.3145 6.50001 15.08L7.84001 14.84L8.10001 13.49C8.45243 11.6563 9.43517 10.0036 10.878 8.81835C12.3208 7.63305 14.1328 6.98979 16 7ZM16 5C13.6726 4.99807 11.4175 5.80799 9.62309 7.29022C7.82873 8.77244 6.60756 10.8341 6.17001 13.12C4.32835 13.4534 2.6779 14.4634 1.54284 15.9516C0.407776 17.4397 -0.129863 19.2985 0.0355171 21.1627C0.200897 23.027 1.05735 24.7621 2.43664 26.0272C3.81594 27.2923 5.61841 27.996 7.49001 28H24.49C26.3616 27.996 28.1641 27.2923 29.5434 26.0272C30.9227 24.7621 31.7791 23.027 31.9445 21.1627C32.1099 19.2985 31.5722 17.4397 30.4372 15.9516C29.3021 14.4634 27.6517 13.4534 25.81 13.12C25.4334 11.1538 24.4752 9.34594 23.0597 7.93035C21.6441 6.51477 19.8362 5.55665 17.87 5.18C17.2535 5.06316 16.6275 5.00291 16 5Z",
                        fill: "currentFill"
                    })))
                },
                x = n(76235),
                p = n(5198),
                v = n(4635),
                g = n(70957),
                j = n(18141),
                w = n(2131),
                y = n(33613),
                b = n(35710),
                C = n(82925);
            let N = [{
                author: {
                    name: "Michael Sholty",
                    title: "Senior Software Engineer",
                    avatarUrl: "/images/people/michael-sholty.jpg",
                    companyAvatarUrl: "/images/companies/avatars/zapier.jpg",
                    companyName: "Zapier"
                },
                quote: (0, a.jsxs)(a.Fragment, {
                    children: ["I have fallen in love with Liveblocks. It was a miracle,", " ", (0, a.jsx)("em", {
                        children: "we found your solution and it just worked"
                    }), "."]
                }),
                companyInfo: {
                    logo: (0, a.jsx)(j.Z, {
                        className: "h-full w-auto"
                    })
                }
            }, {
                author: w.Q.JOEL_VARTY.author,
                quote: (0, a.jsxs)(a.Fragment, {
                    children: ["Not only has Liveblocks helped us bring on new customers,", " ", (0, a.jsx)("em", {
                        children: "it also enabled us to expand current accounts to more users"
                    }), "."]
                }),
                companyInfo: {
                    logo: (0, a.jsx)(p.Z, {
                        className: "h-full w-auto"
                    })
                }
            }, {
                author: w.Q.ALEXIS_SMIRNOV.author,
                quote: (0, a.jsxs)(a.Fragment, {
                    children: ["Within two short days of engineering work, we were able to", " ", (0, a.jsx)("em", {
                        children: "increase efficiency of our care team"
                    }), "."]
                }),
                companyInfo: {
                    logo: (0, a.jsx)(v.Z, {
                        className: "h-full w-auto"
                    })
                }
            }, {
                author: {
                    name: "Sandeep Panda",
                    title: "CTO",
                    avatarUrl: "/images/people/sandeep-panda.jpg",
                    companyAvatarUrl: "/images/companies/avatars/hashnode.jpg",
                    companyName: "Hashnode"
                },
                quote: (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)("em", {
                        children: "Choosing Liveblocks was a no-brainer"
                    }), "; their expertise in collaborative editing and realtime infrastructure is unmatched."]
                }),
                companyInfo: {
                    logo: (0, a.jsx)(g.Z, {
                        className: "h-full w-auto"
                    })
                }
            }];

            function Z(e) {
                var t;
                let {
                    testimonials: n = N
                } = e, [r, s] = (0, c.useState)(0), f = () => {
                    let e = r + 1;
                    e > n.length - 1 && (e = 0), s(e = (0, b.u)(e, 0, n.length - 1))
                }, p = () => {
                    let e = r - 1;
                    e < 0 && (e = n.length - 1), s(e = (0, b.u)(e, 0, n.length - 1))
                }, v = n[r];
                return v ? (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [(0, a.jsx)(l.M, {
                            mode: "wait",
                            children: (0, a.jsx)(i.E.div, {
                                className: "h-9",
                                initial: {
                                    opacity: 0
                                },
                                animate: {
                                    opacity: 1
                                },
                                exit: {
                                    opacity: 0
                                },
                                children: v.companyInfo.logo
                            }, r)
                        }), (0, a.jsxs)("div", {
                            className: "flex items-center justify-between gap-1.5",
                            children: [(0, a.jsxs)(y.z, {
                                square: !0,
                                onClick: () => {
                                    p()
                                },
                                children: [(0, a.jsx)("span", {
                                    className: "sr-only",
                                    children: "Previous"
                                }), (0, a.jsx)(h.Z, {
                                    className: "fill-current"
                                })]
                            }), (0, a.jsxs)(y.z, {
                                square: !0,
                                onClick: () => {
                                    f()
                                },
                                children: [(0, a.jsx)("span", {
                                    className: "sr-only",
                                    children: "Next"
                                }), (0, a.jsx)(d.Z, {
                                    className: "fill-current"
                                })]
                            })]
                        })]
                    }), (0, a.jsx)(l.M, {
                        mode: "wait",
                        children: (0, a.jsx)(i.E.figure, {
                            className: "relative mt-auto",
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            children: (0, a.jsxs)("blockquote", {
                                children: [(0, a.jsx)(C.x, {
                                    className: "f-marketing-body-md max-w-sm leading-snug sm:max-w-lg md:max-w-xl lg:max-w-2xl",
                                    children: (0, a.jsxs)("p", {
                                        children: [(0, a.jsx)("span", {
                                            "aria-hidden": !0,
                                            className: "absolute -ml-[0.5em]",
                                            children: "“"
                                        }), v.quote, (0, a.jsx)("span", {
                                            "aria-hidden": !0,
                                            children: "”"
                                        })]
                                    })
                                }), (0, a.jsxs)("div", {
                                    className: "mt-4 flex flex-col justify-between gap-5 md:mt-6 md:flex-row md:items-center md:gap-9",
                                    children: [(0, a.jsxs)("figcaption", {
                                        className: "flex items-center gap-4 text-marketing-subtler",
                                        children: [(0, a.jsx)(o(), {
                                            width: 36,
                                            height: 36,
                                            className: "size-9 rounded-full",
                                            src: v.author.avatarUrl,
                                            alt: v.author.name
                                        }), (0, a.jsxs)("span", {
                                            className: "flex flex-col text-xs sm:text-sm",
                                            children: [(0, a.jsx)("span", {
                                                className: "font-medium text-marketing",
                                                children: v.author.name
                                            }), (0, a.jsxs)("span", {
                                                children: [v.author.title, " at", " ", v.author.companyName]
                                            })]
                                        })]
                                    }), (0, a.jsxs)("div", {
                                        className: "flex shrink-0 flex-wrap gap-1 sm:flex-nowrap",
                                        children: [v.companyInfo.industry ? (0, a.jsx)(A, {
                                            icon: (0, a.jsx)(m, {
                                                className: "size-4 fill-current opacity-90"
                                            }),
                                            fact: v.companyInfo.industry
                                        }) : null, v.companyInfo.yearFounded ? (0, a.jsx)(A, {
                                            icon: (0, a.jsx)(u.Z, {
                                                className: "size-4 fill-current opacity-90"
                                            }),
                                            fact: "Founded ".concat(v.companyInfo.yearFounded.toString())
                                        }) : null, v.companyInfo.teamSize ? (0, a.jsx)(A, {
                                            icon: (0, a.jsx)(x.Z, {
                                                className: "size-4 fill-current opacity-90"
                                            }),
                                            fact: (t = v.companyInfo.teamSize) <= 10 ? "1-10" : t <= 20 ? "11-20" : t <= 50 ? "21-50" : t <= 100 ? "51-100" : t <= 200 ? "101-200" : t <= 500 ? "201-500" : t <= 1e3 ? "501-1,000" : t <= 2e3 ? "1,001-2,000" : t > 2e3 ? "2,000+" : t.toString()
                                        }) : null]
                                    })]
                                })]
                            })
                        }, r)
                    })]
                }) : null
            }

            function A(e) {
                let {
                    icon: t,
                    fact: n
                } = e;
                return (0, a.jsxs)("div", {
                    className: "inline-flex items-center gap-1.5 rounded-full border border-marketing-divider-subtle py-1 pl-2.5 pr-3 text-marketing-subtler",
                    children: [t, (0, a.jsx)("span", {
                        className: "text-xs sm:text-sm",
                        children: n
                    })]
                })
            }
        },
        34337: function(e) {
            e.exports = {
                viewport: "ScrollArea_viewport__RrP1h",
                scrollbar: "ScrollArea_scrollbar__LNuRt",
                thumb: "ScrollArea_thumb__RMi_2"
            }
        }
    }
]);