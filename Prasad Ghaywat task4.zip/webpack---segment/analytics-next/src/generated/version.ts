// This file is generated.
export const version = '1.72.1'
