// Copyright 2022 Heroic Labs.
// All rights reserved.
//
// NOTICE: All information contained herein is, and remains the property of Heroic
// Labs. and its suppliers, if any. The intellectual and technical concepts
// contained herein are proprietary to Heroic Labs. and its suppliers and may be
// covered by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law. Dissemination of this information or reproduction
// of this material is strictly forbidden unless prior written permission is
// obtained from Heroic Labs.

;
(() => {
    window.getById = function(e) {
        return document.getElementById(e)
    };
    window.getByClass = function(e) {
        return document.getElementsByClassName(e)
    };
    window.addClass = function(e, t) {
        e && e.classList.add(t)
    };
    window.removeClass = function(e, t) {
        e && e.classList.remove(t)
    };
    window.query = function(e, t) {
        return t ? e.querySelectorAll(t) : typeof e == "string" ? document.querySelectorAll(e) : [e]
    };
    window.hide = function(e, t) {
        query(e, t).forEach(s => {
            addClass(s, "hidden")
        })
    };
    window.show = function(e, t) {
        query(e, t).forEach(s => {
            removeClass(s, "hidden")
        })
    };
    var u = getById("header"),
        r = getById("hero"),
        l = getById("not-header"),
        c = getById("www-menu"),
        d = getById("www-menu-open"),
        o = getById("www-menu-close");
    d && d.addEventListener("click", e => {
        hide(r), hide(l), show(c), addClass(document.body, "h-screen")
    });
    o && o.addEventListener("click", e => {
        hide(c), removeClass(document.body, "h-screen"), show(l), show(r)
    });
    window.newsletter = function(e, t, n) {
        n = n || [], n.push("newsletter");
        var s = new XMLHttpRequest;
        s.open("POST", e, !0), s.setRequestHeader("Content-Type", "application/json"), s.onreadystatechange = function() {
            this.readyState === XMLHttpRequest.DONE && this.status === 200 ? (getById("email") && (getById("email").value = ""), getById("newsletter") && (getById("newsletter").value = ""), alert("Thank you! You've joined the list. We'll be in touch soon.")) : this.readyState === XMLHttpRequest.DONE && this.status >= 400 && alert("Error joining the list.")
        }, s.send(JSON.stringify({
            email: t,
            newsletter: !0,
            tags: n
        }))
    };
    window.newsletter_signup = function(e, t) {
        var n = "https://cloud.heroiclabs.com/v2/nakama-newsletter/subscribe";
        t = t || [];
        var s = window.location.pathname;
        s.includes("/satori") ? (n = "https://cloud.heroiclabs.com/v2/satori-newsletter/subscribe", t.push("satori_early_access")) : s.includes("/hiro") ? t.push("gdk_early_access") : s.includes("/heroic-cloud") && t.push("hc_newsletter"), window.newsletter(n, e, t)
    };
    var i = null;
    window.t_click = function(e) {
        if (i) {
            let n = getById("b_" + i);
            removeClass(n.children[0], "hidden"), addClass(n.children[1], "hidden"), addClass(getById("c_" + i), "hidden")
        }
        i = e;
        let t = getById("b_" + i);
        addClass(t.children[0], "hidden"), removeClass(t.children[1], "hidden"), removeClass(getById("c_" + i), "hidden")
    };
    var a = getById("b_paradox");
    a && t_click("paradox");
})();