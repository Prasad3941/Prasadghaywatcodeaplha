var CS_CONF = {
    "isSMB": false,
    "projectId": 79808,
    "status": 1,
    "hostnames": ["size.co.uk", "sizeofficial.de", "sizeofficial.es", "sizeofficial.ie", "sizeofficial.fr", "sizeofficial.nl", "sizeofficial.it"],
    "crossDomainTracking": 0,
    "crossDomainSingleIframeTracking": 0,
    "consentRequired": 0,
    "allowSubdomains": 1,
    "visitorCookieTimeout": 34164000000,
    "sampleRate": 100,
    "replayRecordingRate": 100,
    "validationRate": 10,
    "lastTrackingDraw": 1718976180,
    "trackerDomain": "c.az.contentsquare.net",
    "recordingDomain": "r.contentsquare.net",
    "useMalkaPipeline": 1,
    "ed": "l.contentsquare.net/log/web",
    "eMerchandisingEnabled": 0,
    "mouseMoveHeatmapEnabled": 1,
    "autoInsightsEnabled": 0,
    "jsErrorsEnabled": 1,
    "customErrorsEnabled": 1,
    "jsCustomErrorsEnabled": 0,
    "apiErrorsEnabled": 1,
    "customHashIdEnabled": 0,
    "recordingEncryptionEnabled": 0,
    "recordingEncryptionPublicKey": null,
    "recordingEncryptionPublicKeyId": 0,
    "secureCookiesEnabled": 0,
    "triggerSessionReplayEnabled": 0,
    "triggerSessionReplayRegex": null,
    "dynamicIdRegex": "carousel-.+,\\w{24},pr-.+,Group_.+,Path_.+,.+\\..+",
    "whitelistedAttributes": null,
    "replayRecordingUnmaskedUrlRegex": null,
    "replayRecordingUnmaskedUrlRegexRules": [],
    "replayRecordingMaskedUrlRegexRules": [{
        "operator": "contain",
        "value": "myaccount",
        "ignoreQueryParams": 1,
        "ignoreURIFragments": 0,
        "ignoreCaseSensitivity": 1
    }, {
        "operator": "contain",
        "value": "checkout",
        "ignoreQueryParams": 1,
        "ignoreURIFragments": 0,
        "ignoreCaseSensitivity": 1
    }],
    "replayRecordingMaskedUrlRegex": null,
    "anonymisationMethod": "replayRecordingMaskedUrlRegexRules",
    "tagDeploymentMode": "CONTENTSQUARE",
    "experimental": null,
    "iframesTracking": 0,
    "textVisibilityEnabled": 1,
    "cookielessTrackingEnabled": 0,
    "malkaUrlEnabled": 0,
    "malkaEtrEnabled": 0,
    "pathComputationRules": {
        "reliableSelectors": [],
        "uniqueAttributes": [],
        "uniqueCssSelectors": [".sizeday-banner"]
    },
    "asyncSerializerEnabled": 1,
    "pendingInactivityTimeout": 5000,
    "accessibilityEnabled": 0,
    "uxaDomain": "app.contentsquare.com",
    "webviewsTrackingEnabled": 0,
    "useStaticResourceManager": 1,
    "performanceTimingOptions": {
        "withResource": false,
        "withNavigation": false
    },
    "replayConsentRequiredForSession": 0,
    "eventsApiEnabled": 0,
    "clickedElementTextEnabled": 0,
    "apiErrors": {
        "validCustomHeaders": [],
        "plainCustomHeaders": [],
        "validUrls": [],
        "configurableApiErrorRules": [],
        "collectStandardHeaders": 1,
        "collectQueryParam": 0,
        "collectRequestBody": 0,
        "collectResponseBody": 0,
        "collectionRules": [{
            "bodyAttributePaths": [],
            "collectQueryParam": 0,
            "collectRequestBody": 0,
            "collectResponseBody": 0,
            "customHeaders": []
        }]
    },
    "customErrors": {
        "consoleMessageLogLevels": []
    },
    "displayAdOptions": null,
    "taskSchedulerOptions": {
        "enabled": 1
    },
    "malkaQuotaServiceDomain": "q-eu1.az.contentsquare.net",
    "malkaRecordingDomain": "k-eu1.az.contentsquare.net",
    "staticResourceManagerDomain": "srm.aa.contentsquare.net",
    "voc": {
        "siteId": null,
        "enabled": 0
    },
    "implementations": [{
        "template": {
            "name": "PiiMasking",
            "args": {
                "cssSelectors": ["#addressPredictLook-results,div.App > div[class*='StyledBox'] > div[class*='StyledBox']:first-child span[style*='text-transform']"],
                "attributes": []
            }
        },
        "triggers": [{
            "name": "PageState",
            "args": {
                "state": "Any"
            }
        }]
    }, {
        "template": {
            "name": "ElementUnmasking",
            "args": {
                "selector": "h3,[class*='error'],[id*='error'],div.invalid span,#popupMessage,button,header,div.App > div[class*='StyledBox'] > div[class*='StyledBox']:first-child"
            }
        },
        "triggers": [{
            "name": "PageState",
            "args": {
                "state": "Any"
            },
            "condition": {
                "operator": "AND",
                "args": [{
                    "operator": "contains",
                    "args": ["${window.location.href}", "checkout.size.co.uk"]
                }]
            }
        }]
    }, {
        "template": {
            "name": "PageEvent",
            "args": {
                "iterable": null,
                "eventName": "'Looking for something similar' shown"
            }
        },
        "triggers": [{
            "name": "ElementVisibility",
            "args": {
                "selector": "button.reo-dropdown-button"
            },
            "condition": {
                "operator": "AND",
                "args": [{
                    "operator": "contains",
                    "args": ["${window.location.href}", "/product/"]
                }]
            }
        }]
    }, {
        "template": {
            "name": "PageEvent",
            "args": {
                "iterable": null,
                "eventName": "Apple Pay button shown"
            }
        },
        "triggers": [{
            "name": "ElementVisibility",
            "args": {
                "selector": "button[class*='checkout__applepay']"
            },
            "condition": {
                "operator": "AND",
                "args": [{
                    "operator": "contains",
                    "args": ["${window.location.href}", "checkout.size.co.uk"]
                }]
            }
        }]
    }, {
        "template": {
            "name": "PageEvent",
            "args": {
                "iterable": null,
                "eventName": "Apple Pay button clicked"
            }
        },
        "triggers": [{
            "name": "ElementClick",
            "args": {
                "selector": "button[class*='checkout__applepay']"
            },
            "condition": {
                "operator": "AND",
                "args": [{
                    "operator": "contains",
                    "args": ["${window.location.href}", "checkout.size.co.uk"]
                }]
            }
        }]
    }, {
        "template": {
            "name": "PageEvent",
            "args": {
                "iterable": null,
                "eventName": "Quick Buy clicked"
            }
        },
        "triggers": [{
            "name": "ElementClick",
            "args": {
                "selector": "span.quickBuyOption,span.quickBuy"
            }
        }]
    }, {
        "template": {
            "name": "PageEvent",
            "args": {
                "iterable": null,
                "eventName": "Styled layer visible"
            }
        },
        "triggers": [{
            "name": "ElementVisibility",
            "args": {
                "selector": "[class*='StyledLayer']"
            }
        }]
    }, {
        "template": {
            "name": "PageEvent",
            "args": {
                "iterable": null,
                "eventName": "Live search results visible"
            }
        },
        "triggers": [{
            "name": "ElementVisibility",
            "args": {
                "selector": "#liveSearchResultsContent"
            }
        }]
    }, {
        "template": {
            "name": "PageEvent",
            "args": {
                "iterable": null,
                "eventName": "Page not found"
            }
        },
        "triggers": [{
            "name": "ElementVisibility",
            "args": {
                "selector": "div.pageNotFound"
            }
        }]
    }]
};;;;
(() => {
    "use strict";
    var t = {
            d: (s, e) => {
                for (var i in e) t.o(e, i) && !t.o(s, i) && Object.defineProperty(s, i, {
                    enumerable: !0,
                    get: e[i]
                })
            },
            o: (t, s) => Object.prototype.hasOwnProperty.call(t, s),
            r: t => {
                "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                    value: "Module"
                }), Object.defineProperty(t, "__esModule", {
                    value: !0
                })
            }
        },
        s = {};

    function e(t, s) {
        let e;
        return window.Zone && "function" == typeof window.Zone.__symbol__ && (e = t[window.Zone.__symbol__(s)]), e || (e = t[s]), e
    }
    t.r(s), t.d(s, {
        getRequestParameters: () => dc
    });
    const i = "cs-native-frame",
        n = {
            navigatorProperties: [{
                propertyName: "sendBeacon",
                binding: navigator
            }],
            nodeProperties: ["childNodes", "parentNode", "nextSibling", "firstChild"],
            elementProperties: ["shadowRoot"],
            elementPropertiesValues: ["matches", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector", "webkitMatchesSelector"],
            eventProperties: ["target"],
            imageProperties: ["src"],
            constructors: {
                Date: "csDate",
                JSON: "csJSON",
                Array: "csArray",
                String: "csString",
                URL: "csURL",
                MutationObserver: "csMutationObserver",
                screen: "csScreen",
                RegExp: "csRegExp"
            }
        };

    function r(t, s, e) {
        const i = function(t, s) {
            let e, i = t;
            for (; i && !(e = Object.getOwnPropertyDescriptor(i, s));) i = Object.getPrototypeOf(i);
            return e
        }(t, s);
        if (!i) return function() {
            return this[s]
        };
        switch (e) {
            case "get":
                return i.get;
            case "set":
                return i.set;
            case "value":
                return i.value
        }
    }

    function o(t) {
        var s, i;
        Object.keys(n.constructors).forEach((s => {
                window[n.constructors[s]] = t[s] instanceof Function && null == t[s].prototype ? t[s].bind(window) : t[s]
            })),
            function(t) {
                window.csquerySelector = {
                    1: t.Element.prototype.querySelector,
                    9: t.Document.prototype.querySelector,
                    11: t.DocumentFragment.prototype.querySelector
                }, window.csquerySelectorAll = {
                    1: t.Element.prototype.querySelectorAll,
                    9: t.Document.prototype.querySelectorAll,
                    11: t.DocumentFragment.prototype.querySelectorAll
                }
            }(t), ("Prototype" in window || /^((?!chrome|android).)*safari/i.test(navigator.userAgent)) && (window.csMutationObserver = null !== (i = null !== (s = e(window, "MutationObserver")) && void 0 !== s ? s : window.WebKitMutationObserver) && void 0 !== i ? i : window.MutationObserver), h("csNode", n.nodeProperties, t.Node.prototype, "get"), h("csElement", n.elementProperties, t.Element.prototype, "get"), h("csElement", n.elementPropertiesValues, t.Element.prototype, "value", !1), h("csHTMLImageElement", n.imageProperties, t.HTMLImageElement.prototype, "set"), h("csEvent", n.eventProperties, t.Event.prototype, "get"), h("csNavigator", n.navigatorProperties, t.navigator, "value")
    }

    function h(t, s, e, i, n = !0) {
        s.forEach((s => {
            const o = "string" != typeof s && "binding" in s,
                h = o ? s.propertyName : s;
            (n || h in e) && (window[`${t+h}`] = r(e, h, i), o && (window[`${t+h}`] = window[`${t+h}`].bind(s.binding)))
        }))
    }

    function c(t, s) {
        window.CSProtectnativeFunctionsLogs = window.CSProtectnativeFunctionsLogs || {}, window.CSProtectnativeFunctionsLogs[t] = s
    }
    if (window.csSetTimeout = e(window, "setTimeout"), window.csQueueMicrotask = e(window, "queueMicrotask"), window.csClearTimeout = e(window, "clearTimeout"), window.csSetInterval = e(window, "setInterval"), window.csClearInterval = e(window, "clearInterval"), (() => {
            var t;
            let s = 0;

            function e(t) {
                return "$$" + t + ++s
            }
            e.for = e, window.csSymbol = null !== (t = window.Symbol) && void 0 !== t ? t : e
        })(), ! function() {
            try {
                const t = function() {
                    const t = document.createElement("iframe");
                    t.id = i, t.setAttribute("hidden", ""), t.setAttribute("title", "Intentionally blank"), t.setAttribute("sandbox", "allow-same-origin");
                    const s = document.createElement("cs-native-frame-holder");
                    if (s.setAttribute("hidden", ""), document.body.appendChild(s), Boolean(Element.prototype.attachShadow)) {
                        const e = s.attachShadow({
                            mode: "closed"
                        });
                        return e.innerHTML = t.outerHTML, e.firstElementChild.contentWindow
                    }
                    return s.innerHTML = t.outerHTML, s.firstElementChild.contentWindow
                }();
                return !!t && (window.CSPureWindow = t, o(window.CSPureWindow), !0)
            } catch (t) {
                return c("Warning", `failed to copy references from pure iframe: ${t.message}`), !1
            }
        }()) try {
        o(window)
    } catch (eh) {
        c("Critical", `failed to copy references from window: ${eh.message}`)
    }

    function a(t) {
        return u(csString.prototype.toLowerCase.call(t.localName))
    }

    function u(t) {
        return csString.prototype.replace.call(t, /([#;&,.+*~':"!^$[\]()<=>|/%?@`{}\\ ])/g, "\\$1")
    }

    function l(t) {
        return 1 === t.nodeType
    }

    function d(t) {
        return 3 === t.nodeType
    }

    function f(t) {
        return l(t) && "link" === t.localName
    }

    function p(t) {
        return l(t) && "a" === t.localName
    }

    function m(t) {
        return f(t) && -1 !== csString.prototype.indexOf.call(t.rel, "stylesheet")
    }

    function v(t) {
        return l(t) && "style" === t.localName
    }

    function g(t) {
        return l(t) && "input" === t.localName
    }

    function y(t) {
        return l(t) && "textarea" === t.localName
    }

    function w(t) {
        return l(t) && "script" === t.localName
    }

    function E(t) {
        return l(t) && "ownerSVGElement" in t
    }

    function A(t) {
        return l(t) && "select" === t.localName
    }

    function _(t) {
        switch (t.nodeType) {
            case 9:
            case 11:
            case 1:
                return !0;
            default:
                return !1
        }
    }

    function S(t) {
        return 9 === t.nodeType
    }

    function R(t) {
        return function(t) {
            switch (t.nodeType) {
                case 9:
                case 11:
                    return !0;
                default:
                    return !1
            }
        }(t) && "host" in t && "mode" in t
    }

    function T(t) {
        return l(t) && !!csElementshadowRoot.apply(t) && R(csElementshadowRoot.apply(t))
    }
    const I = ["annotation-xml", "color-profile", "font-face", "font-face-src", "font-face-uri", "font-face-format", "font-face-name", "missing-glyph"];
    const b = "detached";

    function P(t) {
        let s = t;
        const e = [s];
        for (; null !== csNodeparentNode.apply(s);) s = csNodeparentNode.apply(s), csArray.prototype.push.call(e, s);
        return V(s) && csArray.prototype.push.call(e, b), {
            ancestors: e,
            selectionRoot: s
        }
    }

    function V(t) {
        return F.isValidElement(t)
    }
    const C = window.csElementmatches || window.csElementmatchesSelector || window.csElementmozMatchesSelector || window.csElementmsMatchesSelector || window.csElementoMatchesSelector || window.csElementwebkitMatchesSelector;

    function k(t, s) {
        return !!s && csArray.prototype.some.call(s, (s => C.call(t, s)))
    }
    const O = [/\d{4}/, /^ember\d+$/],
        N = "data-cs-override-id",
        x = "data-cs-dynamic-id";

    function $(t, s, e, i) {
        const n = i.dynamicIdRegex || null,
            r = i.dynamicElementNameRegex;
        let o = a(t);
        if (r) {
            r.test(t.localName) && (o = csString.prototype.replace.call(o, r, "$1@"))
        }
        if (function(t, s) {
                const e = L(t);
                return e && csString.prototype.match.call(e, /^[\w-]+$/) && M(N, e, s)
            }(t, e)) {
            const s = L(t);
            return {
                hasUniqueIdentifier: !0,
                elementSelector: `${o}[${N}="${s}"]`
            }
        }
        const h = function(t, s, e) {
            if (!e.uniqueAttributes) return {
                success: !1
            };
            for (const i of e.uniqueAttributes) {
                const e = t.getAttribute(i);
                if (null !== e) {
                    if (M(i, e, s)) return {
                        attributeName: i,
                        attributeValue: e,
                        success: !0
                    }
                }
            }
            return {
                success: !1
            }
        }(t, e, i);
        if (h.success) return {
            hasUniqueIdentifier: !0,
            elementSelector: `${o}#UA[${h.attributeName}="${h.attributeValue}"]`
        };
        const c = function(t, s, e) {
            if (!e.uniqueCssSelectors) return;
            for (const i of e.uniqueCssSelectors)
                if (C.call(t, i) && D(i, s)) return i;
            return
        }(t, e, i);
        if (c) return {
            hasUniqueIdentifier: !0,
            elementSelector: `${o}#UCS[${c}]`
        };
        const l = function(t) {
            const s = t.getAttribute("id");
            return s ? u(s) : s
        }(t);
        if (function(t, s, e, i) {
                return s && ! function(t) {
                    return null !== L(t)
                }(t) && ! function(t, s, e) {
                    return t.hasAttribute(x) || function(t, s) {
                        let e = !1;
                        t && s && (e = s.test(t));
                        return t && (csArray.prototype.some.call(O, (s => s.test(t))) || e)
                    }(s, e)
                }(t, s, i) && function(t, s) {
                    return t && M("id", t, s)
                }(s, e)
            }(t, l, e, n)) return {
            hasUniqueIdentifier: !0,
            elementSelector: `${o}#${l}`
        };
        const d = function(t, s) {
            if (!s.reliableSelectors) return;
            for (const e of s.reliableSelectors)
                if (C.call(t, e)) return e;
            return
        }(t, i);
        if (d) {
            const e = function(t, s, e) {
                if (t === b || 9 === t.nodeType) return 0;
                let i = 0,
                    n = s.previousElementSibling;
                for (; n;) C.call(n, e) && (i += 1), n = n.previousElementSibling;
                return i
            }(s, t, d);
            return {
                hasUniqueIdentifier: !1,
                elementSelector: `${o}[${d}](${e})`
            }
        }
        const f = function(t, s, e) {
            if (t === b || 9 === t.nodeType) return 0;
            const i = e.dynamicElementNameRegex,
                n = !!(null == i ? void 0 : i.test(s.localName)),
                r = a(s);
            let o = 0,
                h = s.previousElementSibling;
            for (; h;)(a(h) === r || n && (null == i ? void 0 : i.test(h.localName))) && !k(h, e.reliableSelectors) && (o += 1), h = h.previousElementSibling;
            return o
        }(s, t, i);
        return {
            hasUniqueIdentifier: !1,
            elementSelector: `${o}:eq(${f})`
        }
    }

    function L(t) {
        return t.getAttribute(N)
    }

    function M(t, s, e) {
        try {
            return 1 === window.csquerySelectorAll[e.nodeType].call(e, `[${t}="${s}"]`).length
        } catch (t) {
            if ("SyntaxError" !== t.name) throw t
        }
        return !1
    }

    function D(t, s) {
        try {
            return 1 === window.csquerySelectorAll[s.nodeType].call(s, t).length
        } catch (t) {
            if ("SyntaxError" !== t.name) throw t
        }
        return !1
    }

    function U(t, s, e) {
        const i = csArray.prototype.shift.call(t);
        if (0 === t.length) return q(i, e);
        const n = i,
            r = t[0],
            {
                elementSelector: o,
                hasUniqueIdentifier: h
            } = $(n, r, s, e);
        if (!e.fullPath && h) {
            return `${q(t[t.length-1],e)}${o}`
        }
        const c = U(t, s, e);
        return `${c?`${c}>`:""}${o}`
    }

    function q(t, s) {
        if (t === b) return "|detached|";
        if (t.host) {
            const {
                ancestors: e,
                selectionRoot: i
            } = P(t.host);
            return `${U(e,i,s)}|shadow-root|`
        }
        return 11 === t.nodeType ? "|fragment|" : ""
    }
    var F;
    ! function(t) {
        function s(t) {
            return !!t && "localName" in t && "getAttribute" in t && "hasAttribute" in t && "parentNode" in t
        }

        function e(t) {
            return t && "jquery" in t && 1 === t.length ? t[0] : t
        }
        t.INVALID_ELEMENT = "INVALID_ELEMENT", t.isValidElement = s, t.getElementPath = function(i, n = {
            fullPath: !1,
            dynamicIdRegex: null
        }) {
            const r = e(i);
            if (r === document) return "";
            if (!s(r)) return t.INVALID_ELEMENT;
            const {
                ancestors: o,
                selectionRoot: h
            } = P(r);
            return U(o, h, n)
        }, t.getElementPathAndFirstAnchorParent = function(i, n = {
            fullPath: !1,
            dynamicIdRegex: null
        }) {
            const r = e(i);
            if (r === document) return {
                path: "",
                firstAnchorParent: null
            };
            if (!s(r)) return {
                path: t.INVALID_ELEMENT,
                firstAnchorParent: null
            };
            const {
                firstAnchorParent: o,
                ancestors: h,
                selectionRoot: c
            } = function(t) {
                let s = t;
                const e = [s];
                let i = null;
                for (; null !== csNodeparentNode.apply(s);) null === i && p(s) && (i = s), csArray.prototype.push.call(e, csNodeparentNode.apply(s)), s = csNodeparentNode.apply(s);
                return V(s) && csArray.prototype.push.call(e, b), {
                    firstAnchorParent: i,
                    ancestors: e,
                    selectionRoot: s
                }
            }(r);
            return {
                path: U(h, c, n),
                firstAnchorParent: o
            }
        }
    }(F || (F = {})), window.CSPathComputation = window.CSPathComputation || F;
    const H = Number.MAX_SAFE_INTEGER || 9007199254740991;

    function B() {}

    function j(t, s) {
        return 0 === csString.prototype.lastIndexOf.call(t, s, 0)
    }
    const z = 34164e6,
        G = {
            percentage: () => Math.floor(1e4 * Math.random()) / 100,
            boolean(t) {
                return this.percentage() < t
            },
            integer: (t = H) => Math.floor(Math.random() * t)
        },
        Z = csSymbol("cachedJson");
    const W = void 0 !== window.Symbol ? function(t) {
        if (t[Z]) return t[Z];
        if (csArray.isArray(t)) {
            if (0 === t.length) return "[]";
            let s = "[" + W(t[0]);
            for (let e = 1; e < t.length; e++) s += "," + W(t[e]);
            return s += "]"
        }
        return t[Z] = csJSON.stringify(t)
    } : csJSON.stringify;
    class Q {
        constructor(t) {
            var s, e, i, n;
            this.isSMB = null !== (s = t.isSMB) && void 0 !== s && s, this.trackerDomain = t.trackerDomain, this.dynamicConfDomain = t.dynamicConfDomain, this.loggerDomain = t.ed, this.minLogLevel = t.logLevel, this.projectId = t.projectId, this.smbConfig = t.smbConfig, this.status = t.status, this.hostnames = t.hostnames, this.iframesTracking = !!t.iframesTracking, this.crossDomainTracking = !!t.crossDomainTracking, this.crossDomainSingleIframeTracking = !!t.crossDomainSingleIframeTracking, this.consentRequired = !!t.consentRequired, this.allowSubdomains = !!t.allowSubdomains, this.visitorCookieTimeout = t.visitorCookieTimeout || z, this.sampleRate = t.sampleRate, this.replayRecordingRate = t.replayRecordingRate, this.validationRate = t.validationRate, this.lastTrackingDraw = t.lastTrackingDraw || 1, this.useHttps = !0, this.eMerchandisingEnabled = t.eMerchandisingEnabled, this.mouseMoveHeatmapEnabled = t.mouseMoveHeatmapEnabled, this.jsErrorsEnabled = t.jsErrorsEnabled, this.apiErrors = {
                enabled: null !== (e = t.apiErrorsEnabled) && void 0 !== e ? e : 0,
                ...t.apiErrors
            }, this.customErrors = {
                enabled: null !== (i = t.customErrorsEnabled) && void 0 !== i ? i : 0,
                ...t.customErrors
            }, this.jsCustomErrorsEnabled = t.jsCustomErrorsEnabled, this.triggerSessionReplayEnabled = t.triggerSessionReplayEnabled, this.triggerSessionReplayRegex = this.t(t.triggerSessionReplayRegex), this.dynamicIdRegex = t.dynamicIdRegex ? new csRegExp(t.dynamicIdRegex) : null, this.whitelistedAttributes = t.whitelistedAttributes || [], this.replayRecordingUnmaskedUrlRegex = this.t(t.replayRecordingUnmaskedUrlRegex), this.replayRecordingMaskedUrlRegex = this.t(t.replayRecordingMaskedUrlRegex), this.replayRecordingMaskedUrlRegexRules = t.replayRecordingMaskedUrlRegexRules || null, this.replayRecordingUnmaskedUrlRegexRules = t.replayRecordingUnmaskedUrlRegexRules || null, this.anonymisationMethod = t.anonymisationMethod || null, this.tagDeploymentMode = t.tagDeploymentMode, this.dualCollectionTagDomain = t.dualCollectionTagDomain || null, this.ptcDomain = t.ptcDomain || null, this.ptcGuid = t.ptcGuid || null, this.secureCookiesEnabled = !!t.secureCookiesEnabled, this.ptcSha512 = t.ptcSha512 || null, this.ptcSnapshotPath = t.ptcSnapshotPath || null, this.emitDebugEvents = !1, this.malkaQuotaServiceDomain = t.malkaQuotaServiceDomain || null, this.staticResourceManagerDomain = t.staticResourceManagerDomain || null, this.malkaRecordingDomain = t.malkaRecordingDomain || null, this.textVisibilityEnabled = t.textVisibilityEnabled, this.experimental = t.experimental || {}, this.malkaEtrEnabled = !!t.malkaEtrEnabled, this.malkaUrlEnabled = !!t.malkaUrlEnabled, this.cookielessTrackingEnabled = t.cookielessTrackingEnabled, this.customHashIdEnabled = !!t.customHashIdEnabled, this.encryptionEnabled = !!t.recordingEncryptionEnabled, this.encryptionPublicKey = t.recordingEncryptionPublicKey || null, this.pathComputationRules = t.pathComputationRules || {}, t.pathComputationRules && "" === t.pathComputationRules.dynamicElementNameRegex && (this.pathComputationRules.dynamicElementNameRegex = null), t.pathComputationRules && t.pathComputationRules.dynamicElementNameRegex && (this.pathComputationRules.dynamicElementNameRegex = new csRegExp(t.pathComputationRules.dynamicElementNameRegex)), this.asyncSerializerEnabled = !!t.asyncSerializerEnabled, this.encryptionPublicKeyId = t.recordingEncryptionPublicKeyId, this.pendingInactivityTimeout = t.pendingInactivityTimeout || 5e3, this.accessibilityEnabled = !!t.accessibilityEnabled, this.useStaticResourceManager = !!t.useStaticResourceManager, t.taskSchedulerOptions && (this.taskSchedulerOptions = { ...t.taskSchedulerOptions,
                enabled: !!t.taskSchedulerOptions.enabled
            }), this.uxaDomain = t.uxaDomain, this.performanceTimingOptions = t.performanceTimingOptions, this.replayConsentRequiredForSession = !!t.replayConsentRequiredForSession, this.isWebView = !1, t.displayAdOptions && t.displayAdOptions.length && (this.displayAdOptions = t.displayAdOptions), t.voc && (this.voc = { ...t.voc,
                enabled: !!t.voc.enabled
            }), t.heapEnvironment && (this.heapEnvironment = t.heapEnvironment), t.implementations && t.implementations.length && (this.implementations = t.implementations), this.eventsApiEnabled = !!t.eventsApiEnabled, this.anonymizeDigits = null !== (n = t.anonymizeDigits) && void 0 !== n ? n : null, this.isHeapPresent = void 0 !== window.heap, this.clickedElementTextEnabled = !!t.clickedElementTextEnabled
        }
        getTrackerUri() {
            return `${this.i()}://${this.trackerDomain}`
        }
        getRecordingUri() {
            return `${this.i()}://${this.malkaRecordingDomain}`
        }
        getLegacyQuotaUri() {
            return `${this.i()}://${this.malkaQuotaServiceDomain}`
        }
        getLoggerUri() {
            return `${this.i()}://${this.loggerDomain}`
        }
        getStaticResourceManagerUri() {
            return `${this.i()}://${this.staticResourceManagerDomain}`
        }
        getQuotaUri() {
            return `${this.i()}://${this.dynamicConfDomain}/${this.projectId}.json`
        }
        isQuotaEnabled() {
            return this.isSMB && !!this.dynamicConfDomain
        }
        i() {
            return this.useHttps ? "https" : "http"
        }
        isProjectActive() {
            return 1 === this.status
        }
        processOptionOverrides(t) {
            t && t.forEach && t.forEach((([t, ...s]) => {
                if ("setOption" === t) {
                    const [t, e] = s;
                    this.h(t, e)
                }
            }))
        }
        h(t, s) {
            "trackerDomain" === t && (this.trackerDomain = s), "loggerDomain" === t && (this.loggerDomain = s), "malkaRecordingDomain" === t && (this.malkaRecordingDomain = s), "malkaQuotaServiceDomain" === t && (this.malkaQuotaServiceDomain = s), "staticResourceManagerDomain" === t && (this.staticResourceManagerDomain = s), "minLogLevel" === t && (this.minLogLevel = s), "useHttps" === t && (this.useHttps = !!s), "isWebView" === t && (this.isWebView = s)
        }
        t(t) {
            return t ? this.u(t) : null
        }
        getRequestParameters() {
            return {
                pid: `${this.projectId}`
            }
        }
        updateDynamicFields(t, s) {
            "emitDebugEvents" === t && (this.emitDebugEvents = s), "minLogLevel" === t && (this.minLogLevel = s)
        }
        u(t) {
            try {
                const s = /^\/(.*)\/([gim]*)$/.exec(t);
                if (s) {
                    const [, t, e] = s;
                    return new csRegExp(`^${t}$`, e)
                }
                return new csRegExp(`^${t}$`)
            } catch (t) {
                return null
            }
        }
        isHeaderCollectionActive() {
            var t, s;
            return this.apiErrors.collectStandardHeaders || !!(null === (t = this.apiErrors.validCustomHeaders) || void 0 === t ? void 0 : t.length) || !!(null === (s = this.apiErrors.plainCustomHeaders) || void 0 === s ? void 0 : s.length)
        }
        isCsSideloadingHeap() {
            var t;
            return "cs_sideloads_heap" === (null === (t = this.heapEnvironment) || void 0 === t ? void 0 : t.heap_tag_status) && !this.isHeapPresent
        }
        isHeapSideloadsCsV5() {
            var t, s;
            const e = "function" == typeof(null === (t = window.heap) || void 0 === t ? void 0 : t.getUserId);
            return "heap_sideloads_cs" === (null === (s = this.heapEnvironment) || void 0 === s ? void 0 : s.heap_tag_status) && e
        }
        isCsCrosswritingHeap() {
            var t;
            return "cs_crosswrites_heap" === (null === (t = this.heapEnvironment) || void 0 === t ? void 0 : t.heap_tag_status)
        }
        isClickedElementTextEnabled() {
            return this.isSMB || this.clickedElementTextEnabled
        }
        isNetworkDetailsEnabled() {
            return !!this.performanceTimingOptions && (this.performanceTimingOptions.withResource || this.performanceTimingOptions.withNavigation)
        }
    }
    class J {
        constructor(t, s) {
            this.A = t, this.S = s
        }
        init() {
            this.R = this.A !== this.A.top, this.T = this.S.isWebView && this.A === this.A.top, this.S.iframesTracking && this.R || this.T ? this.I = !1 : this.I = !0
        }
        isInIframeContext() {
            return this.R
        }
        isTopWindowTracker() {
            return this.I
        }
        isInWebViewContext() {
            return this.T
        }
    }
    var K, Y;
    ! function(t) {
        t.debug = "debug", t.warn = "warn", t.error = "error", t.critical = "critical"
    }(K || (K = {})),
    function(t) {
        t.toQuery = function(t) {
            return csArray.prototype.join.call(csArray.prototype.map.call(Object.keys(t), (s => `${encodeURIComponent(s)}=${encodeURIComponent(t[s])}`)), "&")
        }
    }(Y || (Y = {}));
    class X {
        constructor(t, s) {
            this.domainUri = t, this.path = s, this.beforeRequestCallbacks = [], this.afterRequestCallbacks = []
        }
        setRequestParametersProviders(...t) {
            this.requestParametersProviders = t
        }
        before(t) {
            csArray.prototype.push.call(this.beforeRequestCallbacks, t)
        }
        after(t) {
            csArray.prototype.push.call(this.afterRequestCallbacks, t)
        }
        retrieveParameters() {
            return this.requestParametersProviders ? csArray.prototype.reduce.call(csArray.prototype.map.call(this.requestParametersProviders, (t => t.getRequestParameters())), ((t, s) => ({ ...t,
                ...s
            }))) : {}
        }
    }
    class tt extends X {
        constructor(t, s) {
            super(t, s)
        }
        send() {
            csArray.prototype.forEach.call(this.beforeRequestCallbacks, (t => t()));
            const t = this.retrieveParameters();
            this.P(t);
            const s = Y.toQuery(t);
            this.V(s), csArray.prototype.forEach.call(this.afterRequestCallbacks, (t => t()))
        }
        V(t) {
            const s = new window.Image(1, 1);
            s.onload = B, s.onerror = B, csHTMLImageElementsrc.call(s, `${this.domainUri}${this.path?`/${this.path}`:""}?${t}`)
        }
        P(t) {
            t.r = csString.prototype.slice.call(`${Math.random()}`, 2, 8)
        }
    }
    class st {
        constructor(t, s) {
            this.C = t, this.O = s
        }
        init() {
            this.N = new tt(this.C.getLoggerUri()), this.N.setRequestParametersProviders(this, this.O)
        }
        send(t) {
            this.L = t, this.N.send()
        }
        getRequestParameters() {
            return {
                a: this.L.app,
                l: this.L.level,
                m: this.L.message,
                s: this.L.stacktrace
            }
        }
    }
    const et = /[a-zA-Z0-9._%+-]+(?:@|%40|%2540)[a-zA-Z0-9.%-_]+((?:\.|%2[eE])[a-zA-Z0-9-]+)+/g,
        it = /[a-zA-Z0-9+_-](?:@|%40|%2540)/,
        nt = "([-A-Za-z0-9+/=_]|=[^=]|={3,})+",
        rt = new csRegExp(`(ey${nt}\\.ey${nt}\\.${nt})`, "g"),
        ot = /[0-9]{4}/,
        ht = /(^|[^a-zA-Z0-9*.,-])([45*][0-9*]{3}([ -]?)[0-9*]{4}\3[0-9*]{4}\3[0-9*]{4})($|[^a-zA-Z0-9*.,-])/g,
        ct = /\d/g,
        at = /([+(]{0,2}\d[-_ ()/]{0,4}){9,}/,
        ut = /(?:\d{1,3}\.){3}\d{1,3}/,
        lt = /(?:[A-F0-9]{1,4}:){7}[A-F0-9]{1,4}/;
    var dt;
    ! function(t) {
        t.replaceEmail = function(t) {
            return csString.prototype.replace.call(t, et, "CS_ANONYMIZED_EMAIL")
        }, t.replaceJWT = function(t) {
            return csString.prototype.replace.call(t, rt, "CS_ANONYMIZED_JWT")
        }, t.replaceCreditCardNumber = function(t, s) {
            return csString.prototype.replace.call(t, ht, s)
        }, t.replaceDigits = function(t) {
            return csString.prototype.replace.call(t, ct, "•")
        }, t.mayHaveIPAddress = function(t) {
            return ut.test(t) || lt.test(t)
        }, t.mayHaveNumberSequence = function(t) {
            return at.test(t)
        }, t.mayHaveCreditCardNumber = function(t) {
            return ot.test(t)
        }, t.mayHaveEmail = function(t) {
            return it.test(t)
        }
    }(dt || (dt = {}));
    class ft {
        hasPII(t, s) {
            return t !== this.checkAndAnonymizePII(t, s)
        }
        checkAndAnonymizePII(t, s) {
            let e = this.anonymizeCreditCard(this.anonymizeEmail(t));
            return !0 === s ? e = this.anonymizeAllDigits(e) : !1 === s && (e = this.anonymizeNumberSequence(e)), e
        }
        anonymizePII(t) {
            return "string" == typeof t && (t = this.anonymizeEmail(t)), t
        }
        anonymizeEmail(t) {
            return dt.mayHaveEmail(t) ? dt.replaceEmail(t) : t
        }
        anonymizeAllDigits(t) {
            return dt.replaceDigits(t)
        }
        anonymizeNumberSequence(t) {
            return dt.mayHaveNumberSequence(t) ? dt.replaceDigits(t) : t
        }
        anonymizeCreditCard(t) {
            return dt.mayHaveCreditCardNumber(t) ? dt.replaceCreditCardNumber(t, ((t, s, e, i, n) => {
                if (-1 === csString.prototype.indexOf.call(e, "*")) {
                    const s = i.length ? csArray.prototype.join.call(csString.prototype.split.call(e, i), "") : e;
                    if (!this.M(s)) return t
                }
                return `${s}CS_ANONYMIZED_PII${n}`
            })) : t
        }
        M(t) {
            const s = parseInt(t[t.length - 1]);
            let e = 0;
            for (let s = t.length - 2; s >= 0; s--) {
                let i = parseInt(t[s]);
                s % 2 == 0 && (i *= 2), e += Math.floor(i / 10) + i % 10
            }
            return 10 - e % 10 === s
        }
        anonymizeJwt(t) {
            return dt.replaceJWT(t)
        }
        anonymizeFields(t, s) {
            return csArray.prototype.forEach.call(s, (s => {
                t[s] = this.anonymizeEmail(t[s])
            })), t
        }
    }
    const pt = "15.28.0";

    function mt() {
        return {
            v: pt
        }
    }

    function vt(t) {
        return Et(t) && ("number" == typeof t || t instanceof Number) && !isNaN(t)
    }

    function gt(t) {
        return t === parseInt(t, 10)
    }

    function yt(t) {
        return Et(t) && ("string" == typeof t || t instanceof csString)
    }

    function wt(t) {
        return "object" == typeof t
    }

    function Et(t) {
        return void 0 !== t
    }

    function At(t) {
        return Et(t) && null !== t
    }

    function _t(t) {
        return "function" == typeof t
    }

    function St(t) {
        return t instanceof Element
    }

    function Rt(t) {
        return t instanceof Error
    }

    function Tt(t) {
        const s = t.length;
        for (let e = 0; e < s; e++) switch (csString.prototype.charCodeAt.call(t, e)) {
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 32:
            case 160:
                continue;
            default:
                return !1
        }
        return !0
    }
    const It = "undefined" != typeof performance && performance.now,
        bt = It ? () => performance.now() : csDate.now,
        Pt = It ? performance.timing.navigationStart : 0,
        Vt = {
            now: () => Math.round(bt() + Pt),
            elapsed: () => bt()
        };

    function Ct() {
        return Math.floor(Vt.now() / 1e3)
    }

    function kt() {
        return "function" == typeof window.Promise
    }

    function Ot() {
        var t, s;
        return "function" == typeof(null === (t = window.navigation) || void 0 === t ? void 0 : t.addEventListener) && "function" == typeof(null === (s = window.navigation) || void 0 === s ? void 0 : s.removeEventListener)
    }

    function Nt(t, s) {
        return 0 === csString.prototype.lastIndexOf.call(t, s, 0)
    }

    function xt(t, s) {
        return -1 !== csString.prototype.indexOf.call(t, s, t.length - s.length)
    }
    class $t {
        constructor(t, s) {
            this.D = t, this.U = s
        }
        getRequestParameters() {
            return {
                d: `${Vt.now()}`,
                p: this.U.anonymizePII(window.location.href),
                ...this.D.getRequestParameters(),
                ...mt()
            }
        }
    }
    const Lt = "snippet-",
        Mt = "implementation-snippet-";
    var Dt, Ut;
    ! function(t) {
        t.IMPLEMENTATION = "implementation", t.DYNAMIC = "dynamic"
    }(Dt || (Dt = {})),
    function(t) {
        t[t.debug = 0] = "debug", t[t.warn = 1] = "warn", t[t.error = 2] = "error", t[t.critical = 3] = "critical"
    }(Ut || (Ut = {}));
    class qt {
        constructor(t, s, e) {
            this.q = s, this.U = new ft, this.F = Ut[K.warn], this.F = Ut[t.minLogLevel || K.warn], this.N = e || new st(t, new $t(t, this.U)), this.H = {
                [K.debug]: [],
                [K.warn]: [],
                [K.error]: [],
                [K.critical]: []
            }, this.B = {
                implementation: {},
                dynamic: {}
            }, this.N.init()
        }
        send(t, s = "", e = K.warn) {
            if (!this.j(e, s)) return;
            csArray.prototype.push.call(this.H[e], s || "");
            const i = {
                message: this.G(t, s),
                stacktrace: this.Z(t),
                app: "uxa",
                level: e
            };
            this.N.send(i)
        }
        G(t, s) {
            let e = Rt(t) ? this.U.anonymizePII(t.message || t.toString()) : t;
            return s && (e += ` ErrorCode: ${s}`), e
        }
        Z(t) {
            return Rt(t) ? `${t.stack||"No stacktrace"} ${this.W()}` : this.W()
        }
        W() {
            const t = this.q.getVisitorService(),
                s = null == t ? void 0 : t.getVisitor();
            if (!s) return "No context";
            const e = this.q.getSessionService(),
                i = e && e.getSession(),
                n = {
                    userId: s.id,
                    sessionNumber: s.visitsCount,
                    pageNumber: i && i.pageNumber
                };
            return csJSON.stringify(n)
        }
        j(t, s) {
            if (Ut[t] < this.F) return !1;
            if (0 === (null == s ? void 0 : csString.prototype.indexOf.call(s, Mt, 0))) return this.J(s, Dt.IMPLEMENTATION);
            if (0 === (null == s ? void 0 : csString.prototype.indexOf.call(s, Lt, 0))) return this.J(s, Dt.DYNAMIC);
            const e = this.H[t];
            return !(e.length >= 5) && (!s || !csArray.prototype.some.call(e, (t => t === s)))
        }
        J(t, s) {
            return t in this.B[s] ? !(this.B[s][t] >= 5) && (this.B[s][t] += 1, !0) : (this.B[s][t] = 1, !0)
        }
    }
    const Ft = "undefined" == typeof window,
        Ht = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : process;
    const Bt = !Ft && document.createElement("a"),
        jt = /(:443|:80)$/;

    function zt(t) {
        return Bt ? (Bt.href = t, Bt.href) : ""
    }

    function Gt(t) {
        const s = Qt(t);
        return null === s ? "" : decodeURIComponent(s.hostname)
    }

    function Zt(t, s) {
        return csArray.prototype.some.call(s, (s => xt(t, `.${s}`) || t === s || "" === s))
    }

    function Wt(t) {
        return csString.prototype.replace.call(t, jt, "")
    }

    function Qt(t) {
        return Bt && (Nt(t, "http://") || Nt(t, "https://")) ? (Bt.href = t, {
            hash: Bt.hash,
            host: Wt(Bt.host),
            hostname: Bt.hostname,
            href: Bt.href,
            origin: Bt.origin ? Bt.origin : Wt(`${Bt.protocol}//${Bt.host}`),
            pathname: (s = Bt.pathname, "/" === s[0] ? s : `/${s}`),
            port: Bt.port,
            protocol: Bt.protocol,
            search: Bt.search
        }) : null;
        var s
    }
    const Jt = "CS_IFRAME_MESSAGE";
    var Kt, Yt, Xt, ts;
    ! function(t) {
        t.AfterPageView = "afterPageView", t.GetSessionKey = "getSessionKey"
    }(Kt || (Kt = {})),
    function(t) {
        t.Parent = "parent", t.Child = "child"
    }(Yt || (Yt = {})),
    function(t) {
        t.Discovery = "discovery", t.Stop = "stop", t.RecordingContext = "recordingContext", t.SensitiveStatus = "sensitiveStatus", t.RecordingEvent = "recordingEvent", t.EndOfBufferedMessages = "endOfBufferedMessages", t.ChildLogMessage = "childLogMessage", t.AnalysisEvent = "analysisEvent", t.JavascriptError = "javascriptError", t.ApiError = "apiError", t.Assets = "assets", t.DetailedApiError = "detailedApiError", t.EmerchandisingMessage = "emerchandisingMessage", t.Commands = "commands", t.IntegrationCallback = "integrationCallback", t.StaticResource = "staticResource", t.TrackingContextResultMessage = "trackingContextResultMessage", t.TrackingContextRequestMessage = "trackingContextRequestMessage", t.CustomError = "customError"
    }(Xt || (Xt = {})),
    function(t) {
        t.buildBaseMessage = function(t, s, e, i) {
            const n = {
                type: t,
                from: s,
                pid: e,
                signature: Jt
            };
            return void 0 !== i && i >= 0 && (n.id = i), n
        }, t.isMessageValid = function(t, s, e, i) {
            const n = Gt(t.origin);
            return !!t.data && !!t.data.type && t.data.signature === Jt && t.data.from === s && t.data.pid === e && Zt(n, i)
        }, t.sendPostMessage = function(t, s, e, i) {
            i ? t.postMessage(e, s, i) : t.postMessage(e, s)
        }, t.getNewChannelMessage = function() {
            return new MessageChannel
        }, t.sendChannelMessage = function(t, s) {
            t.postMessage(s)
        }, t.closeChannelPort = function(t) {
            t.close()
        }
    }(ts || (ts = {}));
    class ss {
        constructor(t) {
            this.D = t
        }
        send(t, s = "", e = K.warn) {
            const i = {
                    message: t,
                    errorCode: s,
                    level: e
                },
                n = ts.buildBaseMessage(Xt.ChildLogMessage, Yt.Child, this.D.projectId);
            n.content = i, ts.sendPostMessage(window.parent, "*", n)
        }
    }
    class es {
        setContext(t, s) {
            this.K = t, this.Y = s
        }
        getVisitorService() {
            return this.K
        }
        getSessionService() {
            return this.Y
        }
    }
    const is = ["t.contentsquare.net", "clicktale"];
    window.addEventListener("error", (t => {
        "string" != typeof t.filename || !csArray.prototype.some.call(is, (s => csString.prototype.indexOf.call(t.filename, s) > -1)) || csString.prototype.indexOf.call(t.filename, "blob") > -1 && (null == t.message ? void 0 : csString.prototype.indexOf.call(t.message, "importScripts")) > -1 || ns.critical(`Uncaught jsError: filename: ${t.filename} - lineno: ${t.lineno} - colno: ${t.colno} - message: ${t.message} `)
    }));
    class ns {
        constructor() {}
        static whiteListFilename(t) {
            csArray.prototype.push.call(is, t)
        }
        static setStrategy(t) {
            ns.X = t
        }
        static computeIsActive(t) {
            ns.tt = G.boolean(t), ns.tt ? ns.st = G.boolean(10) : ns.st = !1
        }
        static isLoggingActive() {
            return ns.tt
        }
        static getStrategy() {
            return ns.X
        }
        static debug(t, s = "") {
            ns.tt && this.X.send(t, s, K.debug)
        }
        static warn(t, s = !0, e = "") {
            var i;
            ns.tt && s && this.X.send(t, e, K.warn), null === (i = window.UXAnalytics.Console) || void 0 === i || i.warn(t)
        }
        static error(t, s = "") {
            var e;
            ns.tt && this.X.send(t, s, K.error), null === (e = window.UXAnalytics.Console) || void 0 === e || e.error(t)
        }
        static critical(t, s = "") {
            this.X.send(t, s, K.critical)
        }
        static tryToExecute(t, s) {
            return (...e) => {
                try {
                    const i = s(...e);
                    return Et(window.Promise) && i instanceof window.Promise ? i.then((t => t), (s => this.error(s, t))) : i
                } catch (s) {
                    try {
                        this.error(s, t)
                    } catch {}
                }
            }
        }
        static isPerfLoggingActive() {
            return ns.st
        }
    }
    ns.tt = !1, ns.st = !1;
    let rs = {
        debug(...t) {},
        warn(...t) {},
        error(...t) {},
        critical(...t) {},
        isPerfLoggingActive: () => !1
    };
    const os = t => (s, e, i) => {
        const n = (null == e ? void 0 : e.toString()) || "",
            r = t || `${s.constructor&&s.constructor.name}.${n}`;
        if (i) {
            const t = i.value;
            i.value = function(...s) {
                return hs(r, t.bind(this))(...s)
            }
        }
    };

    function hs(t, s) {
        return (...e) => {
            try {
                const i = s(...e);
                return Et(window.Promise) && i instanceof window.Promise ? i.then((t => t), (s => rs.error(s, t))) : i
            } catch (s) {
                try {
                    rs.error(s, t)
                } catch {}
            }
        }
    }
    let cs = !1;

    function as() {
        return (t, s, e) => {
            const i = e.value;
            e.value = function(t, s) {
                !1 === (null == t ? void 0 : t.isTrusted) && cs || i.call(this, t, s)
            }
        }
    }
    class us {
        constructor() {
            this.et = 0
        }
        get length() {
            return this.et
        }
        get isEmpty() {
            return !this.it
        }
        pushAll(t) {
            for (let s = 0; s < t.length; s++) this.push(t[s])
        }
        push(t) {
            this.et++, this.nt ? this.nt = this.nt[1] = [t, void 0] : this.nt = this.it = [t, void 0]
        }
        pop() {
            if (!this.it) return null;
            this.et--;
            const t = this.it[0];
            return this.it = this.it[1], this.it || (this.nt = void 0), t
        }
        forEach(t) {
            let s = this.it;
            for (; null == s ? void 0 : s.length;) t(s[0]), s = s[1]
        }
        clear() {
            this.et = 0, this.it = this.nt = void 0
        }
    }
    let ls = 50,
        ds = .1;
    let fs = !1;
    const ps = new us;
    const ms = [];
    let vs = [];

    function gs(t) {
        csArray.prototype.push.call(ms, t), performance.mark(`${t}-start`)
    }

    function ys(t) {
        const s = performance.measure(t, `${t}-start`);
        if (!s) return;
        const e = s.duration;
        e >= ds && csArray.prototype.push.call(vs, {
            mName: t,
            mDuration: +e.toFixed(2)
        }), csArray.prototype.pop.call(ms), 0 === ms.length && (e > ls && ps.push(vs), vs = [])
    }

    function ws(t, s) {
        return function(...e) {
            if (!fs) return t.apply(this, e);
            gs(s);
            const i = t.apply(this, e);
            return ys(s), i
        }
    }
    const Es = function(t) {
        return function(s, e, i) {
            const n = i.value;
            i.value = function() {
                if (!fs) return i.value = n, n.apply(this, arguments);
                gs(t);
                const s = n.apply(this, arguments);
                return ys(t), s
            }
        }
    };

    function As(t, s, e, i) {
        var n, r = arguments.length,
            o = r < 3 ? s : null === i ? i = Object.getOwnPropertyDescriptor(s, e) : i;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(t, s, e, i);
        else
            for (var h = t.length - 1; h >= 0; h--)(n = t[h]) && (o = (r < 3 ? n(o) : r > 3 ? n(s, e, o) : n(s, e)) || o);
        return r > 3 && o && Object.defineProperty(s, e, o), o
    }
    Object.create;
    Object.create;
    "function" == typeof SuppressedError && SuppressedError;
    var _s, Ss, Rs, Ts;
    ! function(t) {
        function s(t) {
            const s = new csRegExp(`(^|;)[ ]*${t}=([^;]*)`).exec(document.cookie);
            return s ? decodeURIComponent(s[2]) : null
        }

        function e(s, e, n, r, o, h) {
            const c = encodeURIComponent(`${e}`),
                a = n === t.CURRENT_DOMAIN ? void 0 : n,
                u = i(r);
            let l = `${s}=${c}${u?`;expires=${u.toUTCString()}`:""};path=/${At(a)?`;domain=${a}`:""}`;
            return Et(o) && o !== Rs.NotSet && (l = `${l};SameSite=${o}`), Et(h) && h === Ts.Yes && (l = `${l};Secure`), document.cookie = l, !0
        }

        function i(t) {
            return vt(t) ? new csDate(Vt.now() + t) : t
        }

        function n(t, i) {
            s(t) && e(t, "", i, new csDate(0)), s(t) && e(t, "", i, new csDate(0), Rs.None, Ts.Yes)
        }
        t.CURRENT_DOMAIN = "CURRENT_DOMAIN", t.get = s, t.set = e, t.toExpireDate = i, t.remove = n, t.isCookiePresent = function() {
            return document.cookie.length > 0
        }, t.getRootDomain = function(t, i) {
            const r = "_cs_root-domain";
            let o = s(r);
            if (null !== o && "1" !== o) return o;
            const h = csString.prototype.split.call(window.location.hostname, ".");
            let c = csArray.prototype.pop.call(h);
            for (; h.length && (null === o || "1" === o);) c = csArray.prototype.join.call([csArray.prototype.pop.call(h), c], "."), e(r, c, c, void 0, t, i), o = s(r);
            return n(r, c), c
        }
    }(_s || (_s = {})),
    function(t) {
        t.browserIsSafariV12 = function() {
            return window.navigator.vendor && csString.prototype.indexOf.call(window.navigator.vendor, "Apple") > -1 && window.navigator.appVersion && csString.prototype.indexOf.call(window.navigator.appVersion, "Version/12.") > -1
        }
    }(Ss || (Ss = {})),
    function(t) {
        t.None = "None", t.Lax = "Lax", t.NotSet = "X"
    }(Rs || (Rs = {})),
    function(t) {
        t[t.Yes = 1] = "Yes", t[t.No = 0] = "No"
    }(Ts || (Ts = {}));
    class Is {
        constructor(t, s, e) {
            this.D = t, this.ot = s, this.ht = e, this.ut = !1, this.lt = Rs.NotSet, this.ft = Ts.No
        }
        getSameSiteFlag() {
            return this.lt
        }
        getSecureFlag() {
            return this.ft
        }
        getDomain() {
            return this.vt
        }
        getRootDomain() {
            return this.gt
        }
        init() {
            if (this.D.cookielessTrackingEnabled) return;
            const t = this.yt(),
                s = this.wt();
            this.ut = this.Et(t, s), this.ut ? (this.lt = t, this.ft = s) : this.D.secureCookiesEnabled && "https:" === this.ot.getUrlProtocol() && (this.ft = Ts.Yes), this.gt = this.At(), this.vt = this._t(this.gt)
        }
        Et(t, s) {
            return !Ss.browserIsSafariV12() && (_s.set(Is.COOKIE_TEST_FOR_SAME_SITE, "Test same site", Is.CURRENT_DOMAIN, void 0, t, s), !!_s.get(Is.COOKIE_TEST_FOR_SAME_SITE) && (_s.remove(Is.COOKIE_TEST_FOR_SAME_SITE, Is.CURRENT_DOMAIN), !0))
        }
        yt() {
            return "http:" === this.ot.getUrlProtocol() ? Rs.Lax : this.ht.isSameSiteNoneSecureNeeded() || this.D.crossDomainTracking ? Rs.None : Rs.Lax
        }
        wt() {
            return "http:" === this.ot.getUrlProtocol() ? Ts.No : this.D.secureCookiesEnabled || this.D.crossDomainTracking || this.ht.isSameSiteNoneSecureNeeded() ? Ts.Yes : Ts.No
        }
        isSameSiteSupported() {
            return this.ut
        }
        set(t, s, e) {
            const i = _s.toExpireDate(e);
            _s.set(t, s, this.vt, i, this.getSameSiteFlag(), this.getSecureFlag())
        }
        get(t) {
            const s = new csRegExp(`(^|;)[ ]*${t}=([^;]*)`).exec(document.cookie);
            return s ? decodeURIComponent(s[2]) : null
        }
        delete(t, s) {
            const e = s || this.vt;
            _s.remove(t, e)
        }
        At() {
            const t = this.ht.isSameSiteNoneSecureNeeded() && this.isSameSiteSupported(),
                s = t ? Rs.None : void 0,
                e = t ? Ts.Yes : void 0;
            return _s.getRootDomain(s, e)
        }
        _t(t) {
            return this.D.allowSubdomains ? t : _s.CURRENT_DOMAIN
        }
    }
    Is.CURRENT_DOMAIN = "CURRENT_DOMAIN", Is.COOKIE_TEST_FOR_SAME_SITE = "_cs_same_site";
    const bs = "_cs_t";
    class Ps {
        constructor(t, s) {
            this.St = t, this.D = s, this.Rt = !1, this.Tt = !1
        }
        init() {
            if (!this.D.cookielessTrackingEnabled && this.St.isTopWindowTracker() && "cookie" in document) {
                if (!this.St.isInIframeContext() && _s.isCookiePresent()) return this.Rt = !0, void(this.Tt = !1);
                if (_s.set(bs, "1", _s.CURRENT_DOMAIN), null !== _s.get(bs)) return this.Rt = !0, this.Tt = !1, void _s.remove(bs, _s.CURRENT_DOMAIN);
                _s.set(bs, "1", _s.CURRENT_DOMAIN, void 0, Rs.None, Ts.Yes), null !== _s.get(bs) && (this.Rt = !0, this.Tt = !0, _s.remove(bs, _s.CURRENT_DOMAIN))
            }
        }
        areCookiesEnabled() {
            return this.Rt
        }
        isSameSiteNoneSecureNeeded() {
            return this.Tt
        }
    }
    class Vs {
        constructor(t, s) {
            this.D = t, this.ht = s
        }
        canTrack() {
            return this.D.isProjectActive() && this.It() && this.bt() && this.Pt()
        }
        canTrackInChild() {
            return this.D.isProjectActive() && this.Vt() && (this.bt() || this.Ct())
        }
        Pt() {
            return this.D.cookielessTrackingEnabled ? function() {
                const t = "CSSessionStorageTest";
                try {
                    return sessionStorage.setItem(t, t), sessionStorage.getItem(t) === t && (sessionStorage.removeItem(t), !0)
                } catch {
                    return !1
                }
            }() : this.ht.areCookiesEnabled()
        }
        bt() {
            return Zt(window.location.hostname, this.D.hostnames)
        }
        It() {
            return !this.kt() && this.Ot()
        }
        Vt() {
            return !this.kt() && this.Nt()
        }
        Ct() {
            return j(window.location.href, "about:srcdoc") && "about:" === window.location.protocol && "" === window.location.hostname
        }
        kt() {
            return "visibilityState" in document && "prerender" === document.visibilityState
        }
        Ot() {
            return this.xt() && this.$t()
        }
        Nt() {
            return this.xt()
        }
        $t() {
            try {
                return !!window.localStorage
            } catch {
                return !1
            }
        }
        xt() {
            return "pageXOffset" in window && "pageYOffset" in window && "onpagehide" in window && "JSON" in window && "parse" in window.csJSON && "stringify" in window.csJSON && "addEventListener" in window && "removeEventListener" in window && "Node" in window && "filter" in csArray.prototype && "forEach" in csArray.prototype && "querySelectorAll" in document && "now" in csDate && "keys" in Object && "performance" in window && "Map" in window && "Set" in window
        }
    }
    class Cs {
        constructor(t) {
            this.Lt = !1, this.Mt = new Map, this.Dt = new Map, this.Ut = new Map, this.qt = "CS_WORKER_SIGNATURE";
            const s = `\n    const algorithm = ${t.algorithm};\n    const compressor = (${t.getCompressorSourceCode()})();\n    (()=>{"use strict";var e;!function(e){e.UNCOMPRESSED="0",e.GZIP="2"}(e||(e={}));let t={debug(...e){},warn(...e){},error(...e){},critical(...e){},isPerfLoggingActive:()=>!1};class s{constructor(e){var t;this.queryParams={},this.headers={},this.handleRecoveredRequests=e=>{for(const t of e){const{metadata:e,events:s}=t;this.send(s,e)}},this.endpoint=e.endpoint,this.compressionOpts=e.compressionOpts,this.recoveryStorage=e.recoveryStorage,this.mandatoryParameters=null!==(t=e.mandatoryParameters)&&void 0!==t?t:[],this.worker=!!e.worker,this.recoveryStorage&&this.recoveryStorage.recover(this.handleRecoveredRequests)}setQueryParams(e){Object.keys(e).forEach((t=>{this.queryParams[t]=e[t]}))}removeQueryParams(e){e?e.forEach((e=>{delete this.queryParams[e]})):this.queryParams={}}send(s,r){const a=r||{...this.queryParams},o=!("ct"in a),i="string"!=typeof s&&!this.isArrayBuffer(s);"ct"in a||(this.compressionOpts&&o?a.ct=this.compressionOpts.compressionType:a.ct=e.UNCOMPRESSED);const n=i?JSON.stringify(s):s,h=Object.keys(a).map((e=>\`\${encodeURIComponent(e)}=\${encodeURIComponent(a[e])}\`)).join("&"),c=\`\${this.endpoint}?\${h}\`;!function(e,t){const s=e.length;for(let r=0;r<s;r++)if(t(e[r],r))return!0;return!1}(this.mandatoryParameters,(e=>null==a[e]))?this.compressionOpts&&o&&"string"==typeof n?this.compressionOpts.compressor(n,this.compressionOpts.compressionOutputType,(e=>this.doSend(c,a,e))):this.doSend(c,a,n):t.warn(\`[\${this.worker?"WORKER":"MAIN"}] All mandatory parameters are not present on \${c}\`)}onLoad(e){this.onLoadCallback=e}onError(e){this.onErrorCallback=e}onTimeout(e,t){this.onTimeoutCallback=e,this.timeout=t}abort(){this.abortCurrentXhrCall&&this.abortCurrentXhrCall()}setRequestHeader(e,t){this.headers[e]=t}getQueryParams(){return this.queryParams}isArrayBuffer(e){return e&&void 0!==e.byteLength}doSend(e,t,s){const r=new XMLHttpRequest,a=Object.keys(t).map((e=>\`\${encodeURIComponent(e)}=\${encodeURIComponent(t[e])}\`)).join("&");r.open("POST",e),r.onload=()=>{if(this.recoveryStorage&&this.recoveryStorage.recover(this.handleRecoveredRequests),this.onLoadCallback){const e={params:t,responseText:r.responseText,status:r.status};this.onLoadCallback(e)}},r.onerror=()=>{this.recoveryStorage&&this.recoveryStorage.save({key:a,metadata:t,events:s}),this.onErrorCallback&&this.onErrorCallback({params:t})},this.timeout&&this.onTimeoutCallback&&(r.timeout=this.timeout,r.ontimeout=()=>{this.onTimeoutCallback()}),this.abortCurrentXhrCall=()=>r.abort(),Object.keys(this.headers).forEach((e=>{r.setRequestHeader(e,this.headers[e])})),r.send(s)}}class r{constructor(e){this.maxStoredBytes=e,this.storageBytesUsed=0}addString(e){this.storageBytesUsed+=2*e.length}addArrayBuffer(e){this.storageBytesUsed+=e.byteLength}isThresholdReached(){return this.storageBytesUsed>this.maxStoredBytes}reset(){this.storageBytesUsed=0}}class a{constructor(e){this.ramStorage={},this.byteSizeCounter=new r(e)}save({key:e,metadata:t,events:s}){this.byteSizeCounter.isThresholdReached()||(this.byteSizeCounter.addString(e),"string"==typeof s?this.byteSizeCounter.addString(s):this.byteSizeCounter.addArrayBuffer(s),this.byteSizeCounter.isThresholdReached()||(this.ramStorage[e]={metadata:t,events:s}))}recover(e){const t=[];this.getStorageKeys().forEach((e=>{const s=this.ramStorage[e];void 0!==s&&(delete s.metadata.datatype,t.push(s),this.removeItem(e))})),0!==t.length&&(e(t),this.byteSizeCounter.reset())}getStorageKeys(){return Object.keys(this.ramStorage)}removeItem(e){delete this.ramStorage[e]}}var o;!function(e){e[e.NOT_STARTED=0]="NOT_STARTED",e[e.OPEN_IN_PROGRESS=1]="OPEN_IN_PROGRESS",e[e.OPEN_FAILED=2]="OPEN_FAILED",e[e.READY=3]="READY"}(o||(o={}));class i{constructor(e,t,s){this.storageName=e,this.onOpenError=s,this.cacheState=o.NOT_STARTED,this.toBeSavedBuffer=[],this.recoveryInProgress=0,this.origin=self.origin,this.context="object"==typeof window?"":"worker-",this.byteSizeCounter=new r(t),this.init()}async init(){await this.openCache(),this.cacheState===o.READY?this.flushToBeSavedBuffer():this.onOpenError(this.toBeSavedBuffer)}flushToBeSavedBuffer(){this.toBeSavedBuffer.forEach((e=>{this.save(e)})),this.toBeSavedBuffer=[]}async save(e){try{if(this.cacheState===o.OPEN_IN_PROGRESS)return void this.toBeSavedBuffer.push(e);if(this.cacheState!==o.READY)return;if(this.byteSizeCounter.isThresholdReached())return;const{key:t,metadata:s,events:r}=e;if(this.byteSizeCounter.addString(t),"string"==typeof r?this.byteSizeCounter.addString(r):this.byteSizeCounter.addArrayBuffer(r),this.byteSizeCounter.isThresholdReached())return;await this.cache.put(\`\${this.origin}/\${t}\`,new Response(r,{headers:s}))}catch{}}async recover(e){(this.cache||(await this.openCache(),this.cacheState===o.READY))&&this.doRecover(e)}async openCache(){try{this.cacheState=o.OPEN_IN_PROGRESS,this.cache=await self.caches.open(\`\${this.context}\${this.storageName}\`),this.cacheState=o.READY}catch{this.cacheState=o.OPEN_FAILED}}async doRecover(e){try{if(this.recoveryInProgress++,this.recoveryInProgress>1)return;const t=await this.cache.keys();if(0===t.length)return;const s=(await this.cache.matchAll()).map((e=>{const t={};e.headers.forEach(((e,s)=>{t[s]=e})),delete t["content-type"];const s=t.datatype;return delete t.datatype,"json"===s||"base64"===s?e.text().then((e=>({metadata:t,events:e}))):e.arrayBuffer().then((e=>({metadata:t,events:e})))})),r=await Promise.all(s);await Promise.all(t.map((e=>this.cache.delete(e)))),e(r),this.byteSizeCounter.reset()}catch{}finally{this.recoveryInProgress--}}}class n{constructor(e){try{this.initializeStorageStrategy(e)}catch(e){this.setRamStorageStrategy()}}initializeStorageStrategy(e){self.caches?this.setCachesStrategy(e):this.setRamStorageStrategy()}save(e){this.storageStrategy.save(e)}recover(e){this.storageStrategy.recover(e)}setCachesStrategy(e){this.storageStrategy=new i(e,n.MAX_SIZE,(e=>{this.setRamStorageStrategy(e)}))}setRamStorageStrategy(e){this.storageStrategy=new a(n.MAX_SIZE),e&&e.forEach((e=>{this.storageStrategy.save(e)}))}}n.MAX_SIZE=16777216,function(){const e="CS_WORKER_SIGNATURE",t=new Map,r=new n("csPersisted");function a(a){var o;if((o=a)&&o.WORKER_SIGNATURE===e)switch(a.type){case"CreatePostRequest":{const{endpoint:o,compressionOutputType:i,useRetry:n,mandatoryParameters:h}=a,c={endpoint:o,mandatoryParameters:h,worker:!0};i&&(c.compressionOpts={compressor,compressionOutputType:i,compressionType:algorithm}),n&&(c.recoveryStorage=r);const d=new s(c);t.set(o,d),d.onLoad((t=>{const s={type:"onLoad",endpoint:o,response:t,WORKER_SIGNATURE:e};self.postMessage(s)})),d.onError((t=>{const s={type:"onError",endpoint:o,response:t,WORKER_SIGNATURE:e};self.postMessage(s)}))}break;case"SetQueryParams":{const{endpoint:e,queryParams:s}=a,r=t.get(e);r&&r.setQueryParams(s)}break;case"RemoveQueryParams":{const{endpoint:e,queryParams:s}=a,r=t.get(e);r&&r.removeQueryParams(s)}break;case"Send":{const{endpoint:e,payload:s,queryParams:r}=a,o=t.get(e);o&&o.send(s,r)}break;case"Abort":{const{endpoint:e}=a,s=t.get(e);s&&s.abort()}break;case"SetHeader":{const{endpoint:e,headerName:s,headerValue:r}=a,o=t.get(e);o&&o.setRequestHeader(s,r)}break;case"SetTimeout":{const{endpoint:s,timeout:r}=a,o=t.get(s);o&&o.onTimeout((()=>{const t={type:"onTimeout",endpoint:s,WORKER_SIGNATURE:e};self.postMessage(t)}),r)}break;default:throw new Error(JSON.stringify(a))}}self.addEventListener("message",(function(e){e.data.getReader?async function(e,t){const s=e.getReader();for(;;){const{done:e,value:r}=await s.read();if(e)break;t(r)}}(e.data,a):a(e.data)}))}()})();`;
            try {
                this.Ft = this.Ht(s), this.Lt = !0, this.Bt() && (this.jt = new ReadableStream({
                    start: t => {
                        this.zt = t
                    }
                }), this.Ft.postMessage(this.jt, [this.jt]), this.postMessage = this.postMessageAsTransferable)
            } catch (t) {
                this.Lt = !1
            }
        }
        postMessage(t) {
            t.WORKER_SIGNATURE = this.qt, this.Ft.postMessage(t)
        }
        postMessageAsTransferable(t) {
            t.WORKER_SIGNATURE = this.qt, this.zt.enqueue(t)
        }
        Ht(t) {
            const s = window.csURL || window.webkitURL,
                e = window.Blob,
                i = window.Worker,
                n = new e([t], {
                    type: "application/javascript"
                }),
                r = s.createObjectURL(n);
            ns.whiteListFilename(r);
            const o = new i(r);
            return o.onmessage = t => {
                const {
                    type: s,
                    endpoint: e,
                    WORKER_SIGNATURE: i
                } = t.data;
                if (i === this.qt)
                    if ("onLoad" === s) {
                        const {
                            response: s
                        } = t.data, i = this.Mt.get(e);
                        i && i(s)
                    } else if ("onError" === s) {
                    const {
                        response: s
                    } = t.data, i = this.Dt.get(e);
                    i && i(s)
                } else if ("onTimeout" === s) {
                    const t = this.Ut.get(e);
                    t && t()
                }
            }, o
        }
        registerOnLoadCallback(t, s) {
            this.Mt.set(t, s)
        }
        registerOnErrorCallback(t, s) {
            this.Dt.set(t, s)
        }
        registerOnTimeoutCallback(t, s) {
            this.Ut.set(t, s)
        }
        isSupported() {
            return this.Lt
        }
        Bt() {
            try {
                const t = new ReadableStream;
                return structuredClone(t, {
                    transfer: [t]
                }), !0
            } catch {
                return !1
            }
        }
    }
    class ks {
        constructor(t) {
            var s;
            this.Gt = {}, this.Zt = t.endpoint, this.Wt = t.networkWorker, this.Qt = t.compressionOutputType, this.Jt = t.useRetry, this.Wt.postMessage({
                type: "CreatePostRequest",
                endpoint: this.Zt,
                compressionOutputType: this.Qt,
                useRetry: this.Jt,
                mandatoryParameters: null !== (s = t.mandatoryParameters) && void 0 !== s ? s : []
            })
        }
        setQueryParams(t) {
            this.Wt.postMessage({
                type: "SetQueryParams",
                endpoint: this.Zt,
                queryParams: t
            }), csArray.prototype.forEach.call(Object.keys(t), (s => {
                this.Gt[s] = t[s]
            }))
        }
        getQueryParams() {
            return this.Gt
        }
        removeQueryParams(t) {
            this.Wt.postMessage({
                type: "RemoveQueryParams",
                endpoint: this.Zt,
                queryParams: t
            }), t && csArray.prototype.forEach.call(t, (t => {
                delete this.Gt[t]
            }))
        }
        send(t, s) {
            this.Wt.postMessage({
                type: "Send",
                endpoint: this.Zt,
                payload: t,
                queryParams: s
            })
        }
        abort() {
            this.Wt.postMessage({
                type: "Abort",
                endpoint: this.Zt
            })
        }
        onLoad(t) {
            this.Wt.registerOnLoadCallback(this.Zt, t)
        }
        onError(t) {
            this.Wt.registerOnErrorCallback(this.Zt, t)
        }
        setRequestHeader(t, s) {
            this.Wt.postMessage({
                type: "SetHeader",
                endpoint: this.Zt,
                headerName: t,
                headerValue: s
            })
        }
        onTimeout(t, s) {
            this.Wt.registerOnTimeoutCallback(this.Zt, t), this.Wt.postMessage({
                type: "SetTimeout",
                endpoint: this.Zt,
                timeout: s
            })
        }
    }
    var Os;
    ! function(t) {
        t.UNCOMPRESSED = "0", t.GZIP = "2"
    }(Os || (Os = {}));
    class Ns {
        constructor(t) {
            this.onError = t
        }
    }

    function xs(t) {
        var s;
        const e = null !== (s = t.length) && void 0 !== s ? s : 0,
            i = new csArray(e);
        for (let s = 0; s < e; s += 1) i[s] = t[s];
        return i
    }

    function $s(t, s) {
        const e = t.length,
            i = new csArray(e);
        for (let n = 0; n < e; n += 1) i[n] = s(t[n]);
        return i
    }

    function Ls(t, s) {
        const e = [];
        return function(t, s, e) {
            let i = 0;
            for (let n = 0; n < t.length; n += 1) {
                const r = s(t[n]);
                for (let t = 0; t < r.length; t++) e(r[t], i++)
            }
        }(t, s, (t => csArray.prototype.push.call(e, t))), e
    }

    function Ms(t, s) {
        if (t.length >= 0) {
            const e = t.length;
            for (let i = 0; i < e; i++) s(t[i], i)
        } else {
            let e = 0,
                i = t.next();
            for (; !i.done;) s(i.value, e++), i = t.next()
        }
    }

    function Ds(t, s) {
        const e = t.length;
        for (let i = 0; i < e; i++)
            if (s(t[i], i)) return t[i]
    }

    function Us(t, s) {
        const e = t.length;
        for (let i = 0; i < e; i++)
            if (s(t[i], i)) return !0;
        return !1
    }

    function qs(t, s) {
        const e = t.length,
            i = [];
        for (let n = 0; n < e; n += 1) {
            const e = t[n];
            s(e) && csArray.prototype.push.call(i, e)
        }
        return i
    }

    function Fs(t, s) {
        for (let e = 0; e < t.length; e++) csArray.prototype.push.call(s, t[e])
    }

    function Hs(t) {
        const s = t instanceof Map,
            e = [];
        return t.forEach(((t, i) => csArray.prototype.push.call(e, s ? [i, t] : t))), e
    }
    class Bs {
        constructor(t) {
            var s;
            this.Gt = {}, this.Kt = {}, this.Yt = t => {
                for (const s of t) {
                    const {
                        metadata: t,
                        events: e
                    } = s;
                    this.send(e, t)
                }
            }, this.Zt = t.endpoint, this.Xt = t.compressionOpts, this.ss = t.recoveryStorage, this.mandatoryParameters = null !== (s = t.mandatoryParameters) && void 0 !== s ? s : [], this.worker = !!t.worker, this.ss && this.ss.recover(this.Yt)
        }
        setQueryParams(t) {
            Object.keys(t).forEach((s => {
                this.Gt[s] = t[s]
            }))
        }
        removeQueryParams(t) {
            t ? t.forEach((t => {
                delete this.Gt[t]
            })) : this.Gt = {}
        }
        send(t, s) {
            const e = s || { ...this.Gt
                },
                i = !("ct" in e),
                n = "string" != typeof t && !this.es(t);
            "ct" in e || (this.Xt && i ? e.ct = this.Xt.compressionType : e.ct = Os.UNCOMPRESSED);
            const r = n ? JSON.stringify(t) : t,
                o = Object.keys(e).map((t => `${encodeURIComponent(t)}=${encodeURIComponent(e[t])}`)).join("&"),
                h = `${this.Zt}?${o}`;
            Us(this.mandatoryParameters, (t => null == e[t])) ? rs.warn(`[${this.worker?"WORKER":"MAIN"}] All mandatory parameters are not present on ${h}`) : this.Xt && i && "string" == typeof r ? this.Xt.compressor(r, this.Xt.compressionOutputType, (t => this.ns(h, e, t))) : this.ns(h, e, r)
        }
        onLoad(t) {
            this.rs = t
        }
        onError(t) {
            this.hs = t
        }
        onTimeout(t, s) {
            this.cs = t, this.us = s
        }
        abort() {
            this.ls && this.ls()
        }
        setRequestHeader(t, s) {
            this.Kt[t] = s
        }
        getQueryParams() {
            return this.Gt
        }
        es(t) {
            return t && void 0 !== t.byteLength
        }
        ns(t, s, e) {
            const i = new XMLHttpRequest,
                n = Object.keys(s).map((t => `${encodeURIComponent(t)}=${encodeURIComponent(s[t])}`)).join("&");
            i.open("POST", t), i.onload = () => {
                if (this.ss && this.ss.recover(this.Yt), this.rs) {
                    const t = {
                        params: s,
                        responseText: i.responseText,
                        status: i.status
                    };
                    this.rs(t)
                }
            }, i.onerror = () => {
                this.ss && this.ss.save({
                    key: n,
                    metadata: s,
                    events: e
                }), this.hs && this.hs({
                    params: s
                })
            }, this.us && this.cs && (i.timeout = this.us, i.ontimeout = () => {
                this.cs()
            }), this.ls = () => i.abort(), Object.keys(this.Kt).forEach((t => {
                i.setRequestHeader(t, this.Kt[t])
            })), i.send(e)
        }
    }
    class js {
        constructor(t) {
            this.ds = t, this.Wt = new Cs(this.ds)
        }
        create(t, s, e, i, n = []) {
            if (this.Wt.isSupported() && s) return new ks({
                networkWorker: this.Wt,
                endpoint: t,
                compressionOutputType: e,
                useRetry: !!i,
                mandatoryParameters: n
            }); {
                const s = e ? {
                    compressor: this.ds.compress,
                    compressionOutputType: e,
                    compressionType: this.ds.algorithm
                } : void 0;
                return new Bs({
                    endpoint: t,
                    compressionOpts: s,
                    recoveryStorage: i
                })
            }
        }
    }
    class zs {
        constructor(t, s, e, i, n) {
            this.K = t, this.Y = s, this.fs = e, this.ps = i, this.D = n
        }
        get() {
            return {
                exclusion: this.fs.getAppliedTrackingDraw(),
                visitor: this.K.getVisitor(),
                session: this.Y.getSession(),
                cvars: this.ps.getCustomVariablesSession()
            }
        }
        apply(t) {
            t && (t.exclusion ? this.exclude() : this.include(t))
        }
        exclude() {
            this.fs.exclude(this.D), this.K.removeVisitor(), this.Y.removeSession(), this.ps.removeCustomVariablesSession()
        }
        include(t) {
            this.fs.removeExclusion(), this.K.setVisitor(t.visitor), t.session ? this.Y.setSession(t.session) : this.Y.removeSession(), t.cvars ? this.ps.setCustomVariableSession(t.cvars) : this.ps.removeCustomVariablesSession()
        }
    }

    function Gs(t, s, e, i) {
        var n, r = arguments.length,
            o = r < 3 ? s : null === i ? i = Object.getOwnPropertyDescriptor(s, e) : i;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(t, s, e, i);
        else
            for (var h = t.length - 1; h >= 0; h--)(n = t[h]) && (o = (r < 3 ? n(o) : r > 3 ? n(s, e, o) : n(s, e)) || o);
        return r > 3 && o && Object.defineProperty(s, e, o), o
    }
    Object.create;
    Object.create;
    "function" == typeof SuppressedError && SuppressedError;
    var Zs, Ws;

    function Qs(t, s = Ys.SHOW_ALL) {
        const e = s | Ys.SHOW_ELEMENT,
            i = [document.createTreeWalker(t, e, null, !1)];
        let n = Js(t);
        n && csArray.prototype.push.call(i, document.createTreeWalker(n, e, null, !1));
        let r = null;
        return {
            root: t,
            nextNode() {
                if (n) {
                    const t = n;
                    return n = null, t
                }
                for (; i.length > 0;) {
                    if (r) {
                        const t = r;
                        return r = null, t
                    }
                    const t = i[i.length - 1].nextNode();
                    if (!t) {
                        csArray.prototype.pop.call(i);
                        continue
                    }
                    const n = Js(t);
                    if (s & Ys.SHOW_DOCUMENT_FRAGMENT && n && (r = n), n && csArray.prototype.push.call(i, document.createTreeWalker(n, e, null, !1)), Xs[t.nodeType] & s) return t
                }
                return null
            },
            visitAll(e) {
                Xs[t.nodeType] & s && e(t);
                let i = this.nextNode();
                for (; i;) Xs[i.nodeType] & s ? (e(i), i = this.nextNode()) : i = this.nextNode()
            },
            collectAll(t) {
                const s = [];
                return this.visitAll((e => csArray.prototype.push.call(s, t ? t(e) : e))), s
            }
        }
    }

    function Js(t) {
        return t && T(t) ? t.shadowRoot : null
    }
    const Ks = null !== (Zs = Ht.Node) && void 0 !== Zs ? Zs : {},
        Ys = null !== (Ws = Ht.NodeFilter) && void 0 !== Ws ? Ws : {},
        Xs = {
            2: Ys.SHOW_ATTRIBUTE,
            4: Ys.SHOW_CDATA_SECTION,
            8: Ys.SHOW_COMMENT,
            11: Ys.SHOW_DOCUMENT_FRAGMENT,
            9: Ys.SHOW_DOCUMENT,
            10: Ys.SHOW_DOCUMENT_TYPE,
            1: Ys.SHOW_ELEMENT,
            [Ks.ENTITY_NODE]: Ys.SHOW_ENTITY,
            [Ks.ENTITY_REFERENCE_NODE]: Ys.SHOW_ENTITY_REFERENCE,
            [Ks.NOTATION_NODE]: Ys.SHOW_NOTATION,
            7: Ys.SHOW_PROCESSING_INSTRUCTION,
            3: Ys.SHOW_TEXT
        };

    function te() {
        const t = new Error;
        let s = t.stack ? csArray.prototype.filter.call(csString.prototype.split.call(t.stack, "\n"), (t => "Error" !== t && -1 === csString.prototype.indexOf.call(csString.prototype.toLowerCase.call(t), "promise ") && -1 === csString.prototype.indexOf.call(t, "[native code]"))) : [];
        if (0 === s.length) return "";
        const e = function(t) {
            return t.length > 0 ? se(t[0]) : ""
        }(s);
        return "" === e ? "" : (s = function(t, s) {
            return csArray.prototype.filter.call(t, (t => -1 === csString.prototype.indexOf.call(t, s)))
        }(s, e), 0 === s.length ? "" : se(s[0]))
    }

    function se(t) {
        let s, e = "";
        var i;
        i = t, s = -1 !== csString.prototype.indexOf.call(i, "@") ? new csRegExp("@(.+):(\\d+):(\\d+)$") : new csRegExp("\\((.+):(\\d+):(\\d+)\\)");
        const n = s.exec(t);
        return n && (e = n[1]), e
    }
    const ee = t => t;

    function ie({
        target: t,
        methodName: s,
        hook: e,
        hookPrepareArgs: i = ee,
        options: n
    }) {
        var r;
        if (!(null === (r = Object.getOwnPropertyDescriptor(t, s)) || void 0 === r ? void 0 : r.writable)) return rs.warn(`Cannot intercept read only function '${csString(s)}' of object '${t}'`), null;
        let o = !1;
        const h = t[s];
        if ("function" == typeof h) {
            const r = function() {
                const t = i(arguments),
                    s = h.apply(this, arguments);
                if (o) {
                    let i;
                    n && n.withCallerName && (i = te());
                    try {
                        e({
                            result: s,
                            context: this,
                            args: t,
                            callerName: i
                        })
                    } catch (t) {
                        rs.error(t)
                    }
                }
                return s
            };
            a = h, (c = r).prototype = a.prototype, Object.defineProperty(c, "toString", {
                value: () => a.toString()
            }), t[s] = r
        }
        var c, a;
        return {
            activate: () => o = !0,
            deactivate: () => o = !1
        }
    }

    function ne(t, s, e) {
        let i = !1;
        const n = Object.getOwnPropertyDescriptor(t, s);
        if (n) {
            if (!n.configurable) return rs.warn(`Cannot intercept read only property '${csString(s)}' of object '${t}'`), null;
            const r = function() {
                const t = arguments,
                    r = this[s],
                    o = n.set.apply(this, t);
                if (i) try {
                    e(this, t[0], r)
                } catch (t) {
                    rs.error(t)
                }
                return o
            };
            Object.defineProperty(t, s, {
                set: r
            })
        }
        return {
            activate: () => i = !0,
            deactivate: () => i = !1
        }
    }
    var re, oe;
    ! function(t) {
        t.isSupported = function() {
            return !!Element.prototype.attachShadow
        }, t.getShadowRoot = function(t) {
            return t && T(t) ? t.shadowRoot : null
        }, t.getAllShadowHosts = ws((function(t) {
            return Qs(t, NodeFilter.SHOW_DOCUMENT_FRAGMENT).collectAll((t => t.host))
        }), "getAllShadowHosts")
    }(re || (re = {}));
    class he {
        static vs(t) {
            this.gs.forEach((s => {
                t(s, "initial")
            }))
        }
        static ys(t) {
            if (csArray.prototype.push.call(this.ws, t), !this.Es) {
                this.Es = !0, this.As.observe(document, this._s);
                for (const t of re.getAllShadowHosts(document)) {
                    const s = csElementshadowRoot.apply(t);
                    this.gs.add(s), this.As.observe(s, this._s)
                }
                this.Ss || (this.Ss = ie({
                    target: Element.prototype,
                    methodName: "attachShadow",
                    hook: t => t.result.isConnected && this.Rs(t.result)
                })), this.Ss.activate()
            }
            this.vs(t)
        }
        static Ts(t) {
            var s;
            this.ws = csArray.prototype.filter.call(this.ws, (s => s !== t)), 0 === this.ws.length && (this.ws = [], this.Es = !1, this.As.disconnect(), null === (s = this.Ss) || void 0 === s || s.deactivate(), this.gs.clear())
        }
        constructor(t) {
            this.Is = t, this.Is = hs("DocumentShadowRootObserver:callback", ((s, e) => t(s, e)))
        }
        get shadowRoots() {
            return Hs(oe.gs)
        }
        takeRecords() {
            var t, s;
            return null !== (s = null === (t = oe.As) || void 0 === t ? void 0 : t.takeRecords()) && void 0 !== s ? s : []
        }
        observe() {
            re.isSupported() && oe.ys(this.Is)
        }
        disconnect() {
            re.isSupported() && oe.Ts(this.Is)
        }
    }
    oe = he, he.ws = [], he.gs = new Set, he.Es = !1, he._s = {
        childList: !0,
        subtree: !0
    }, he.As = new csMutationObserver((t => {
        for (const s of t) s.target.isConnected && Ms(s.addedNodes, oe.bs), Ms(s.removedNodes, oe.Ps)
    })), he.Rs = t => {
        oe.gs.has(t) || (oe.As.observe(t, oe._s), oe.gs.add(t), Ms(oe.ws, (s => s(t, "added"))))
    }, he.bs = t => {
        Qs(t, NodeFilter.SHOW_DOCUMENT_FRAGMENT).visitAll(oe.Rs)
    }, he.Ps = t => {
        t.isConnected || Qs(t, NodeFilter.SHOW_DOCUMENT_FRAGMENT).visitAll((t => {
            oe.gs.has(t) && (oe.gs.delete(t), Ms(oe.ws, (s => s(t, "removed"))))
        }))
    }, Gs([os()], he.prototype, "observe", null), Gs([os()], he.prototype, "disconnect", null);

    function ce(t, s = true) {
        t.boundElement.addEventListener(t.type, t.listener, s)
    }

    function ae(t, s = true) {
        t.boundElement.removeEventListener(t.type, t.listener, s)
    }

    function ue(t, s = 0) {
        const e = Math.pow(10, s);
        return Math.round(t * e) / e
    }

    function le(t, s) {
        "number" == typeof s && (s = {
            wait: s
        });
        const e = s.wait;
        if (s.ignoreThrottledCalls) {
            let s = 0;
            return function(...i) {
                const n = Vt.now();
                if (n - s > e) return s = n, t.apply(this, i)
            }
        }
        let i, n, r = [],
            o = null,
            h = 0;
        const c = () => {
                h = Vt.now(), o = null, n = t.apply(i, r)
            },
            a = function(...s) {
                const a = Vt.now(),
                    u = e - (a - h);
                return i = null != this ? this : window, r = [...s], u <= 0 || u > e ? (h = a, n = t.apply(i, r), o ? (window.csClearTimeout(o), o = null) : r = []) : o || (o = window.csSetTimeout(c, u)), n
            };
        return a.cancel = () => {
            o && (window.csClearTimeout(o), h = 0, o = null, r = [])
        }, a.flushPending = () => {
            o && (window.csClearTimeout(o), c())
        }, a
    }
    const de = t => (s, e, i) => {
        i.value = le(i.value, t)
    };
    var fe, pe, me, ve, ge, ye;

    function we(t) {
        const s = csEventtarget.apply(t);
        return s && l(s) && csElementshadowRoot.apply(s) && t.composedPath ? t.__csOriginalTarget || t.composedPath()[0] : s
    }! function(t) {
        t[t.MUTATION_INSERT = 1] = "MUTATION_INSERT", t[t.MUTATION_REMOVE = 2] = "MUTATION_REMOVE", t[t.MUTATION_ATTRIBUTE = 3] = "MUTATION_ATTRIBUTE", t[t.MUTATION_CHARACTER_DATA = 4] = "MUTATION_CHARACTER_DATA", t[t.INITIAL_DOM = 5] = "INITIAL_DOM", t[t.SCROLL = 6] = "SCROLL", t[t.CLICK = 8] = "CLICK", t[t.RESIZE = 9] = "RESIZE", t[t.INPUT_CHECKABLE = 10] = "INPUT_CHECKABLE", t[t.INPUT_SELECT = 11] = "INPUT_SELECT", t[t.INPUT_TEXT = 12] = "INPUT_TEXT", t[t.HASH_CHANGE = 13] = "HASH_CHANGE", t[t.UNANONYMIZED_CONSENT_GRANTED = 14] = "UNANONYMIZED_CONSENT_GRANTED", t[t.UNANONYMIZED_CONSENT_WITHDRAWN = 15] = "UNANONYMIZED_CONSENT_WITHDRAWN", t[t.MOUSE_OVER = 16] = "MOUSE_OVER", t[t.VISIBILITY_CHANGE = 17] = "VISIBILITY_CHANGE", t[t.STYLESHEET_RULE_INSERT = 18] = "STYLESHEET_RULE_INSERT", t[t.STATIC_RESOURCE_URL = 19] = "STATIC_RESOURCE_URL", t[t.PERFORMANCE_TIMINGS = 20] = "PERFORMANCE_TIMINGS", t[t.ATTACH_SHADOW = 22] = "ATTACH_SHADOW", t[t.STYLESHEET_CSS_TEXT_UPDATE = 23] = "STYLESHEET_CSS_TEXT_UPDATE", t[t.JAVASCRIPT_ERROR = 26] = "JAVASCRIPT_ERROR", t[t.PAGE_EVENT = 27] = "PAGE_EVENT", t[t.API_ERROR = 28] = "API_ERROR", t[t.TEXT_VISIBILITY = 29] = "TEXT_VISIBILITY", t[t.MUTATION_ENCRYPTED_CHARACTER_DATA = 30] = "MUTATION_ENCRYPTED_CHARACTER_DATA", t[t.INPUT_ENCRYPTED_TEXT = 31] = "INPUT_ENCRYPTED_TEXT", t[t.KEY_DOWN = 32] = "KEY_DOWN", t[t.KEY_UP = 33] = "KEY_UP", t[t.CLIPBOARD_COMMAND = 34] = "CLIPBOARD_COMMAND", t[t.STYLESHEET_RULE_DELETE = 37] = "STYLESHEET_RULE_DELETE", t[t.USER_IDENTIFIER = 38] = "USER_IDENTIFIER", t[t.TOUCH_START = 41] = "TOUCH_START", t[t.TOUCH_MOVE = 42] = "TOUCH_MOVE", t[t.TOUCH_END = 43] = "TOUCH_END", t[t.GESTURE_RECOGNITION = 44] = "GESTURE_RECOGNITION", t[t.POINTER_DOWN = 47] = "POINTER_DOWN", t[t.POINTER_MOVE = 48] = "POINTER_MOVE", t[t.POINTER_UP = 49] = "POINTER_UP", t[t.CUSTOM_ERROR = 50] = "CUSTOM_ERROR", t[t.CUSTOM_ELEMENT_REGISTRATION = 54] = "CUSTOM_ELEMENT_REGISTRATION", t[t.REGISTER_ADOPTED_STYLE_SHEET = 60] = "REGISTER_ADOPTED_STYLE_SHEET", t[t.SET_ADOPTED_STYLE_SHEETS = 61] = "SET_ADOPTED_STYLE_SHEETS", t[t.ADOPTED_STYLESHEET_RULE_INSERT = 62] = "ADOPTED_STYLESHEET_RULE_INSERT", t[t.ADOPTED_STYLESHEET_RULE_DELETE = 63] = "ADOPTED_STYLESHEET_RULE_DELETE", t[t.SCREEN_RESIZE = 65] = "SCREEN_RESIZE", t[t.RESOURCE_HASHES = 66] = "RESOURCE_HASHES", t[t.PERFORMANCE_NAVIGATION_TIMING = 67] = "PERFORMANCE_NAVIGATION_TIMING", t[t.PERFORMANCE_RESOURCE_TIMING = 68] = "PERFORMANCE_RESOURCE_TIMING", t[t.RECORDING_INFO_EVENT = 72] = "RECORDING_INFO_EVENT", t[t.TEXT_REF = 73] = "TEXT_REF", t[t.TOUCH_CANCEL = 74] = "TOUCH_CANCEL", t[t.MUTATION_MOVE = 75] = "MUTATION_MOVE", t[t.STYLESHEET_RULE_UPDATE = 76] = "STYLESHEET_RULE_UPDATE", t[t.ADOPTED_STYLESHEET_RULE_UPDATE = 77] = "ADOPTED_STYLESHEET_RULE_UPDATE", t[t.VIDEO_PLAY = 78] = "VIDEO_PLAY", t[t.VIDEO_PAUSE = 79] = "VIDEO_PAUSE", t[t.VIDEO_SEEK = 80] = "VIDEO_SEEK", t[t.DEBUG = 999] = "DEBUG"
    }(fe || (fe = {})),
    function(t) {
        t[t.RECORDING_CONSENT_FOR_SESSION_GRANTED = 1] = "RECORDING_CONSENT_FOR_SESSION_GRANTED", t[t.RECORDING_CONSENT_FOR_SESSION_WITHDRAWN = 2] = "RECORDING_CONSENT_FOR_SESSION_WITHDRAWN"
    }(pe || (pe = {})),
    function(t) {
        t[t.Left = 0] = "Left", t[t.Middle = 1] = "Middle", t[t.Right = 2] = "Right", t[t.Fourth = 3] = "Fourth", t[t.Fifth = 4] = "Fifth"
    }(me || (me = {})),
    function(t) {
        t[t.SWIPE = 0] = "SWIPE", t[t.PINCH_IN = 1] = "PINCH_IN", t[t.PINCH_OUT = 2] = "PINCH_OUT", t[t.LONG_PRESS = 3] = "LONG_PRESS", t[t.TAP = 4] = "TAP", t[t.DOUBLE_TAP = 5] = "DOUBLE_TAP"
    }(ve || (ve = {})),
    function(t) {
        t[t.SPACE = 0] = "SPACE", t[t.ENTER = 1] = "ENTER", t[t.BACKSPACE = 2] = "BACKSPACE", t[t.DELETE = 3] = "DELETE", t[t.ARROWUP = 4] = "ARROWUP", t[t.ARROWDOWN = 5] = "ARROWDOWN", t[t.ARROWLEFT = 6] = "ARROWLEFT", t[t.ARROWRIGHT = 7] = "ARROWRIGHT", t[t.CAPSLOCK = 8] = "CAPSLOCK", t[t.SHIFT = 9] = "SHIFT", t[t.TAB = 10] = "TAB", t[t.ALPHANUMERICAL = 11] = "ALPHANUMERICAL", t[t.ESCAPE = 12] = "ESCAPE", t[t.END = 13] = "END", t[t.ALT = 14] = "ALT", t[t.CTRL = 15] = "CTRL", t[t.META = 16] = "META"
    }(ge || (ge = {})),
    function(t) {
        t[t.COPY = 0] = "COPY", t[t.CUT = 1] = "CUT", t[t.PASTE = 2] = "PASTE"
    }(ye || (ye = {}));
    const Ee = !!window.chrome,
        Ae = "data-cs-scroll-container";
    var _e;
    ! function(t) {
        t.isEventOnScrollContainer = function(t) {
            return !!(At(t) && function(t) {
                try {
                    if (At(csEventtarget.apply(t))) return !0
                } catch {}
                return !1
            }(t) && St(csEventtarget.apply(t)) && null !== csEventtarget.apply(t).getAttribute(Ae))
        }, t.getScrollContainer = function() {
            return window.csquerySelector[document.nodeType].call(document, `[${Ae}]`)
        }
    }(_e || (_e = {}));
    const Se = function() {
        const t = csSymbol.for("propStore");
        return {
            getStore: s => s[t],
            get(s, e) {
                const i = s[t];
                return null == i ? void 0 : i[e]
            },
            set(s, e, i) {
                let n = s[t];
                n || (n = {}, s[t] = n), n[e] = i
            }
        }
    }();
    var Re;
    ! function(t) {
        function s(t, e, i) {
            let n = !1;
            if (i(t, e, (() => n = !0)), n) return;
            const r = t.shadowRoot;
            r && s(r, t, i);
            const o = t.children;
            if (null == o ? void 0 : o.length)
                for (const e of o)
                    if (e && (s(e, t, i), n)) break
        }
        t.setProperty = function(t, s, e) {
            var i;
            t instanceof Node ? Se.set(t, s, e) : (null !== (i = t.props) && void 0 !== i || (t.props = {}), t.props[s] = e)
        }, t.getProperty = function(t, s) {
            var e;
            return t instanceof Node ? Se.get(t, s) : null === (e = t.props) || void 0 === e ? void 0 : e[s]
        }, t.getProperties = function(t) {
            return t instanceof Node ? Se.getStore(t) : t.props
        }, t.traverse = function(t, e) {
            s(t, void 0, e)
        }
    }(Re || (Re = {}));
    let Te = 1,
        Ie = csSymbol("nodeIdentifier");

    function be(t) {
        const s = Re.getProperty(t, Ie);
        return null != s ? s : (Re.setProperty(t, Ie, Te++), Re.getProperty(t, Ie))
    }
    var Pe;
    const Ve = null !== (Pe = Ht.Element) && void 0 !== Pe ? Pe : {
            prototype: {}
        },
        Ce = window.csElementmatches || window.csElementmatchesSelector || window.csElementmozMatchesSelector || window.csElementmsMatchesSelector || window.csElementoMatchesSelector || window.csElementwebkitMatchesSelector,
        ke = Ve.prototype.closest,
        Oe = document.createElement("div");

    function Ne(t) {
        if (!(!!t && yt(t))) return rs.warn(`isValidSelector: invalid selector provided '${t}'`), !1;
        try {
            return Ce.call(Oe, t), !0
        } catch {
            return rs.warn(`isValidSelector: invalid selector provided '${t}'`), !1
        }
    }

    function xe(t, s) {
        if (ke) return ke.call(t, s);
        let e = t;
        do {
            if (Ce.call(e, s)) return e;
            e = null == e ? void 0 : e.parentElement
        } while (null !== e && 1 === e.nodeType);
        return null
    }
    var $e;
    ! function(t) {
        let s;
        ! function(t) {
            t[t.NotMasked = 0] = "NotMasked", t[t.Parent = 1] = "Parent", t[t.Child = 2] = "Child"
        }(s = t.MaskedElementState || (t.MaskedElementState = {})), t.maskedProp = "masked", t.maskedAttributeProp = "maskedAttribute", t.isSelectorUserInput = function(t) {
            return !!(wt(t) && "Attributes" in t && "PIISelectors" in t) && (t.Attributes instanceof Array && t.PIISelectors instanceof Array)
        }, t.sanitizeSelectorUserInput = function(t) {
            return wt(t) && null !== t ? ("Attributes" in t || (t.Attributes = []), "PIISelectors" in t || (t.PIISelectors = []), t) : (rs.warn(`setPIISelectors called with invalid input of type ${typeof t}: ${csJSON.stringify(t)}`, !1), {
                Attributes: [],
                PIISelectors: []
            })
        }, t.getMaskedElementDetails = function(e) {
            var i;
            return null !== (i = Re.getProperty(e, t.maskedProp)) && void 0 !== i ? i : {
                state: s.NotMasked
            }
        }, t.getMaskedAttributeDetails = function(s) {
            var e;
            return null !== (e = Re.getProperty(s, t.maskedAttributeProp)) && void 0 !== e ? e : {
                attributes: []
            }
        }, t.isMaskedElement = function(e) {
            const i = Re.getProperty(e, t.maskedProp);
            return (null == i ? void 0 : i.state) === s.Parent
        }, t.isMaskedElementChild = function(e) {
            const i = Re.getProperty(e, t.maskedProp);
            return (null == i ? void 0 : i.state) === s.Child
        }, t.isMaskedAttribute = function(s, e) {
            const i = Re.getProperty(s, t.maskedAttributeProp);
            return (null == (null == i ? void 0 : i.attributes) ? void 0 : csArray.prototype.indexOf.call(null == i ? void 0 : i.attributes, e)) > -1
        }, t.setMaskedElementProperty = function(s, e) {
            Re.setProperty(s, t.maskedProp, e)
        }, t.unsetMaskedElementProperty = function(s) {
            Re.setProperty(s, t.maskedProp, void 0)
        }, t.setMaskedAttributeProperty = function(s, e) {
            Re.setProperty(s, t.maskedAttributeProp, e)
        }, t.getComputedSelectorSettings = function(t, s) {
            const e = csArray.prototype.filter.call(t.PIISelectors, (t => Ne(t)));
            s.elementSelector.length > 0 && csArray.prototype.push.call(e, ...csString.prototype.split.call(s.elementSelector, ","));
            const i = function(t) {
                    if (t.length <= 1) return t;
                    const s = [];
                    for (const e of t) {
                        const t = csString.prototype.split.call(e, ",");
                        for (const e of t) - 1 === csArray.prototype.indexOf.call(s, e) && csArray.prototype.push.call(s, e)
                    }
                    return s
                }([...e]),
                n = {
                    elementSelector: csArray.prototype.join.call(i, ","),
                    attrSelector: s.attrSelector,
                    attrSelectors: s.attrSelectors
                };
            return csArray.prototype.forEach.call(t.Attributes, (t => {
                (null == t ? void 0 : t.attrName) && (null == t ? void 0 : t.selector) && Ne(t.selector) && ! function(t, s) {
                    return csArray.prototype.some.call(t, (t => t.selector === s.selector && t.attrName === s.attrName))
                }(n.attrSelectors, t) && csArray.prototype.push.call(n.attrSelectors, t)
            })), n.attrSelector = function(t) {
                let s = "";
                return csArray.prototype.forEach.call(t, (t => {
                    const e = csString.prototype.split.call(t.selector, ",");
                    csArray.prototype.forEach.call(e, (t => {
                        Ne(t) && (s && (s += ","), s += t)
                    }))
                })), s
            }(n.attrSelectors), n
        }
    }($e || ($e = {}));
    class Le {
        constructor() {
            this.Vs = [], this.Cs = [{
                type: "pointerup",
                listener: t => this.pointerUpListener(t),
                boundElement: document
            }, {
                type: "pointermove",
                listener: t => this.pointerMoveListener(t),
                boundElement: document
            }, {
                type: "pointerdown",
                listener: t => this.pointerDownListener(t),
                boundElement: document
            }], this.ks = [{
                type: "touchstart",
                listener: t => this.touchStartListener(t),
                boundElement: document
            }, {
                type: "touchmove",
                listener: t => this.touchMoveListener(t),
                boundElement: document
            }, {
                type: "touchend",
                listener: t => this.touchEndCancelListener(t),
                boundElement: document
            }, {
                type: "touchcancel",
                listener: t => this.touchEndCancelListener(t),
                boundElement: document
            }], this.Os = [{
                type: "click",
                listener: t => this.clickListener(t),
                boundElement: document
            }, {
                type: "keyup",
                listener: t => this.keyUpListener(t),
                boundElement: document
            }, {
                type: "keydown",
                listener: t => this.keyDownListener(t),
                boundElement: document
            }, {
                type: "copy",
                listener: t => this.copyListener(t),
                boundElement: document
            }, {
                type: "cut",
                listener: t => this.cutListener(t),
                boundElement: document
            }, {
                type: "paste",
                listener: t => this.pasteListener(t),
                boundElement: document
            }, {
                type: "scroll",
                listener: t => this.scrollListener(csEventtarget.apply(t)),
                boundElement: document
            }, {
                type: "mouseover",
                listener: t => this.mouseOverListener(t),
                boundElement: document
            }], this.Ns = [{
                type: "scroll",
                listener: t => this.scrollListener(csEventtarget.apply(t))
            }];
            const t = function(t) {
                if (!yt(t)) return null;
                const s = /iP(ad|hone|od).+Version\/(\d+)\..*Safari/i.exec(t);
                return s ? Number(s[2]) : null
            }(window.navigator.userAgent);
            (null === t || t && t >= 16) && csArray.prototype.push.call(this.Ns, {
                type: "mouseover",
                listener: t => this.mouseOverListener(t)
            }), this.xs = new he(((t, s) => {
                switch (s) {
                    case "initial":
                    case "added":
                        this.$s(t);
                        break;
                    case "removed":
                        this.Ls(t)
                }
            }))
        }
        init() {
            this.Ms(), this.Ds(), this.Us()
        }
        onEvent(t) {
            csArray.prototype.push.call(this.Vs, t)
        }
        qs(t, s = !1) {
            csArray.prototype.forEach.call(this.Vs, (e => e(t, s)))
        }
        start() {
            this.Fs(), this.$s(document), this.xs.observe()
        }
        stop() {
            this.Ls(document), this.xs.disconnect()
        }
        Ds() {
            this.Hs() && csArray.prototype.push.call(this.Os, ...this.Cs)
        }
        Ms() {
            this.Bs() && csArray.prototype.push.call(this.Os, ...this.ks)
        }
        $s(t) {
            S(t) ? csArray.prototype.forEach.call(this.Os, (t => ce(t))) : csArray.prototype.forEach.call(this.Ns, (s => {
                ce({
                    type: s.type,
                    listener: s.listener,
                    boundElement: t
                })
            }))
        }
        Ls(t) {
            S(t) ? csArray.prototype.forEach.call(this.Os, (t => ae(t))) : csArray.prototype.forEach.call(this.Ns, (s => {
                ae({
                    type: s.type,
                    listener: s.listener,
                    boundElement: t
                })
            }))
        }
        Hs() {
            return "PointerEvent" in window && "function" == typeof window.PointerEvent
        }
        Bs() {
            return "TouchEvent" in window && "function" == typeof window.TouchEvent
        }
        Fs() {
            this.js()
        }
        js() {
            const t = _e.getScrollContainer() || document,
                s = be(t),
                e = this.zs(t);
            if (0 !== e.top || 0 !== e.left) {
                const t = {
                    type: fe.SCROLL,
                    args: [s, e.left, e.top],
                    date: Vt.now()
                };
                this.qs(t, !0)
            }
        }
        zs(t) {
            return t === document ? {
                top: window.pageYOffset,
                left: window.pageXOffset
            } : {
                top: t.scrollTop,
                left: t.scrollLeft
            }
        }
        scrollListener(t) {
            if ($e.isMaskedElement(t) || $e.isMaskedElementChild(t)) return;
            const s = be(t),
                e = this.zs(t),
                i = {
                    type: fe.SCROLL,
                    args: [s, e.left, e.top],
                    date: Vt.now()
                };
            this.qs(i)
        }
        mouseOverListener(t) {
            if ($e.isMaskedElementChild(t.target)) return;
            const s = be(t.target),
                e = {
                    type: fe.MOUSE_OVER,
                    args: [s],
                    date: Vt.now()
                };
            this.qs(e)
        }
        clickListener(t) {
            const s = we(t);
            if ($e.isMaskedElementChild(s)) return;
            const e = be(s),
                i = {
                    type: fe.CLICK,
                    args: [e],
                    date: Vt.now()
                };
            this.qs(i)
        }
        keyUpListener(t) {
            const s = we(t);
            if ($e.isMaskedElementChild(s)) return;
            const e = be(s),
                i = this.Gs[t.key];
            if (void 0 === i) return;
            const n = {
                type: fe.KEY_UP,
                args: [e, i],
                date: Vt.now()
            };
            this.qs(n)
        }
        keyDownListener(t) {
            const s = we(t);
            if ($e.isMaskedElementChild(s)) return;
            const e = be(s),
                i = this.Gs[t.key];
            if (void 0 === i) return;
            const n = {
                type: fe.KEY_DOWN,
                args: [e, i],
                date: Vt.now()
            };
            this.qs(n)
        }
        copyListener(t) {
            const s = we(t);
            if ($e.isMaskedElementChild(s)) return;
            const e = be(s),
                i = {
                    type: fe.CLIPBOARD_COMMAND,
                    args: [e, ye.COPY],
                    date: Vt.now()
                };
            this.qs(i)
        }
        cutListener(t) {
            const s = we(t);
            if ($e.isMaskedElementChild(s)) return;
            const e = be(s),
                i = {
                    type: fe.CLIPBOARD_COMMAND,
                    args: [e, ye.CUT],
                    date: Vt.now()
                };
            this.qs(i)
        }
        pasteListener(t) {
            const s = we(t);
            if ($e.isMaskedElementChild(s)) return;
            const e = be(s),
                i = {
                    type: fe.CLIPBOARD_COMMAND,
                    args: [e, ye.PASTE],
                    date: Vt.now()
                };
            this.qs(i)
        }
        pointerUpListener(t) {
            const s = we(t);
            if ($e.isMaskedElementChild(s)) return;
            const e = be(s),
                i = {
                    type: fe.POINTER_UP,
                    args: [t.pointerId, t.pointerType, ue(t.clientX, 1), ue(t.clientY, 1), e, t.button],
                    date: Vt.now()
                };
            this.qs(i)
        }
        pointerMoveListener(t) {
            const s = {
                type: fe.POINTER_MOVE,
                args: [t.pointerId, t.pointerType, ue(t.clientX, 1), ue(t.clientY, 1)],
                date: Vt.now()
            };
            this.qs(s)
        }
        pointerDownListener(t) {
            const s = we(t);
            if ($e.isMaskedElementChild(s)) return;
            const e = be(s),
                i = {
                    type: fe.POINTER_DOWN,
                    args: [t.pointerId, t.pointerType, ue(t.clientX, 1), ue(t.clientY, 1), e, t.button, {
                        pageX: ue(t.pageX, 1),
                        pageY: ue(t.pageY, 1)
                    }],
                    date: Vt.now()
                };
            this.qs(i)
        }
        touchStartListener(t) {
            if (!t.changedTouches) return;
            const {
                changedTouches: s
            } = t;
            for (let t = 0; t < s.length; t += 1) {
                const e = s[t],
                    i = {
                        type: fe.TOUCH_START,
                        args: [e.identifier, ue(e.clientX, 1), ue(e.clientY, 1)],
                        date: Vt.now()
                    };
                this.qs(i)
            }
        }
        touchMoveListener(t) {
            if (!t.changedTouches) return;
            const {
                changedTouches: s
            } = t;
            for (let t = 0; t < s.length; t += 1) {
                const e = s[t],
                    i = {
                        type: fe.TOUCH_MOVE,
                        args: [e.identifier, ue(e.clientX, 1), ue(e.clientY, 1)],
                        date: Vt.now()
                    };
                this.qs(i)
            }
        }
        touchEndCancelListener(t) {
            if (!t.changedTouches) return;
            const {
                changedTouches: s
            } = t;
            for (let e = 0; e < s.length; e += 1) {
                const i = s[e],
                    n = {
                        type: "touchend" === t.type ? fe.TOUCH_END : fe.TOUCH_CANCEL,
                        args: [i.identifier, ue(i.clientX, 1), ue(i.clientY, 1)],
                        date: Vt.now()
                    };
                this.qs(n)
            }
        }
        Us() {
            this.Gs = {}, this.Gs[" "] = ge.SPACE, this.Gs.Spacebar = ge.SPACE, this.Gs.Backspace = ge.BACKSPACE, this.Gs.Enter = ge.ENTER, this.Gs.Delete = ge.DELETE, this.Gs.ArrowUp = ge.ARROWUP, this.Gs.ArrowDown = ge.ARROWDOWN, this.Gs.ArrowLeft = ge.ARROWLEFT, this.Gs.ArrowRight = ge.ARROWRIGHT, this.Gs.Up = ge.ARROWUP, this.Gs.Down = ge.ARROWDOWN, this.Gs.Left = ge.ARROWLEFT, this.Gs.Right = ge.ARROWRIGHT, this.Gs.CapsLock = ge.CAPSLOCK, this.Gs.Shift = ge.SHIFT, this.Gs.Tab = ge.TAB, this.Gs.Escape = ge.ESCAPE, this.Gs.Esc = ge.ESCAPE, this.Gs.End = ge.END, this.Gs.Alt = ge.ALT, this.Gs.Control = ge.CTRL, this.Gs.Meta = ge.META
        }
    }
    As([Es("RecordingPageEvents.start")], Le.prototype, "start", null), As([os("scroll")], Le.prototype, "scrollListener", null), As([os("mouseOver"), as(), (t, s, e) => {
        const i = e.value;
        return i && (e.value = function(t) {
            if (we(t) === csEventtarget.apply(t)) return i.call(this, t)
        }), e
    }], Le.prototype, "mouseOverListener", null), As([os("click"), as()], Le.prototype, "clickListener", null), As([os("Event handler type: keyup")], Le.prototype, "keyUpListener", null), As([os("Event handler type: keydown")], Le.prototype, "keyDownListener", null), As([os("Event handler type: copy")], Le.prototype, "copyListener", null), As([os("Event handler type: cut")], Le.prototype, "cutListener", null), As([os("Event handler type: paste")], Le.prototype, "pasteListener", null), As([os("Event handler type: pointerup"), as()], Le.prototype, "pointerUpListener", null), As([os("Event handler type: pointermove"), as(), de({
        wait: 33,
        ignoreThrottledCalls: !1
    })], Le.prototype, "pointerMoveListener", null), As([os("Event handler type: pointerdown"), as()], Le.prototype, "pointerDownListener", null), As([os("Event handler type: touchstart"), as()], Le.prototype, "touchStartListener", null), As([os("Event handler type: touchmove"), as()], Le.prototype, "touchMoveListener", null), As([os("Event handler type: touchend-cancel"), as()], Le.prototype, "touchEndCancelListener", null);
    class Me {
        constructor(t) {
            this.Zs = t, this.Ws = 0
        }
        addString(t) {
            this.Ws += 2 * t.length
        }
        addArrayBuffer(t) {
            this.Ws += t.byteLength
        }
        isThresholdReached() {
            return this.Ws > this.Zs
        }
        reset() {
            this.Ws = 0
        }
    }
    class De {
        constructor(t = [], s = 2048e3) {
            this.Qs = t, this.Js = new Me(s)
        }
        addEvent(t) {
            this.Js.addString(W(t)), csArray.prototype.push.call(this.Qs, t)
        }
        addEventByTimestamp(t) {
            let s = 0;
            for (; s < this.Qs.length; s += 1) {
                if (this.Qs[s].date >= t.date) break
            }
            csArray.prototype.splice.call(this.Qs, s, 0, t)
        }
        eventsCount() {
            return this.Qs.length
        }
        clearEvents() {
            this.Js.reset(), this.Qs = []
        }
        isFull() {
            return this.eventsCount() >= 200
        }
        isThresholdReached() {
            return this.Js.isThresholdReached()
        }
        getEvents() {
            return this.Qs
        }
        extractEvents(...t) {
            const s = [],
                e = [];
            return csArray.prototype.forEach.call(this.Qs, (i => {
                -1 !== csArray.prototype.indexOf.call(t, i.type) ? csArray.prototype.push.call(s, i) : csArray.prototype.push.call(e, i)
            })), this.Qs = e, s
        }
        stringifyEvents() {
            return W(this.Qs)
        }
        Ks(t) {
            t.type === fe.INITIAL_DOM && (window.CSDomSerialized = window.CSDomSerialized ? window.CSDomSerialized + 1 : 1)
        }
    }
    As([Es("RecordingBatch.addEvent")], De.prototype, "addEvent", null);
    class Ue {
        constructor() {
            this.Ys = 1
        }
        getCurrentIndex() {
            return this.Ys
        }
        increment() {
            this.Ys += 1
        }
        reset() {
            this.Ys = 1
        }
        getRequestParameters() {
            return {
                ri: `${this.Ys}`
            }
        }
    }
    class qe {
        emit(t, s, e, i = document) {
            const n = `${void 0!==e?`${e}`:`${qe.Xs}`}${t}`,
                r = qe.createEvent(n, {
                    detail: s
                });
            null !== r && i.dispatchEvent(r)
        }
        static createEvent(t, s = {}) {
            if ("function" == typeof CustomEvent) return new CustomEvent(t, s);
            const e = this.te();
            if (null === e) return null;
            const {
                bubbles: i = !1,
                cancelable: n = !1,
                detail: r
            } = s;
            return e.initCustomEvent(t, i, n, r), e
        }
        static te() {
            try {
                return document.createEvent("CustomEvent")
            } catch {
                return null
            }
        }
    }
    qe.Xs = "cs.tracking.";
    class Fe {
        constructor() {
            this._isStarted = !1
        }
        get isStarted() {
            return this._isStarted
        }
        start(...t) {
            this._isStarted || (this._isStarted = !0, this.onStart(...t))
        }
        stop() {
            this._isStarted && (this._isStarted = !1, this.onStop())
        }
        restart() {
            this.stop(), this.start()
        }
    }
    var He, Be, je, ze, Ge, Ze;
    ! function(t) {
        t.QUOTA_REACHED = "X", t.RECORDING_RULES_TARGETING = "8", t.ANALYTICS_ONLY = "0", t.RECORDING_GLOBAL_SAMPLING = "5", t.RECORDING_TEMPORARILY = "T", t.RECORDING_URL_SAMPLING = "6", t.RECORDING_ETR_SAMPLING = "7", t.RECORDING_BLOCKED_BY_CONSENT_NOT_EXPRESSED = "B", t.RECORDING_BLOCKED_BY_CONSENT_WITHDRAWN = "W"
    }(He || (He = {})),
    function(t) {
        t.ETR_OFF = "0", t.ETR_ON = "1"
    }(Be || (Be = {})),
    function(t) {
        t.ETR_LEGACY = "0", t.ETR_SESSION = "1", t.ETR_PAGE = "2"
    }(je || (je = {})),
    function(t) {
        t.ETR_DISABLED = "0", t.ETR_PENDING = "1", t.ETR_SAVED_PAGE = "2", t.ETR_SAVED_SESSION = "3", t.ETR_NOT_SAVED_SESSION = "9"
    }(ze || (ze = {})),
    function(t) {
        t.Visible = "visible", t.Hidden = "hidden", t.Blur = "blur", t.PagehideVisible = "pagehideVisible", t.PagehideHidden = "pagehideHidden", t.ExitPageByNavigate = "exitPageByNavigate"
    }(Ge || (Ge = {}));
    class We {
        constructor() {
            this.se = !1, this.ee = t => {
                try {
                    switch (t.type) {
                        case "visibilitychange":
                            if ("hidden" === document.visibilityState) return this.ie(Ge.Hidden);
                            break;
                        case "pagehide":
                            return "hidden" === document.visibilityState ? this.ie(Ge.PagehideHidden) : this.ie(Ge.PagehideVisible);
                        case "blur":
                            return this.ie(Ge.Blur);
                        case "navigate":
                            return this.ne(t) ? this.ie(Ge.ExitPageByNavigate) : void 0;
                        default:
                            return
                    }
                } catch {}
            }
        }
        start() {
            this.se || (this.se = !0, this.re(), this.oe(), this.he(), Ot() && this.ce())
        }
        stop() {
            this.se && (this.se = !1, this.ae(), this.ue(), this.le(), Ot() && this.de())
        }
        onEvent(t) {
            this.ie = t
        }
        ce() {
            window.navigation.addEventListener("navigate", this.ee)
        }
        de() {
            window.navigation.removeEventListener("navigate", this.ee)
        }
        re() {
            document.addEventListener("visibilitychange", this.ee)
        }
        ae() {
            document.removeEventListener("visibilitychange", this.ee)
        }
        oe() {
            window.addEventListener("pagehide", this.ee)
        }
        ue() {
            window.removeEventListener("pagehide", this.ee)
        }
        he() {
            window.addEventListener("blur", this.ee)
        }
        le() {
            window.removeEventListener("blur", this.ee)
        }
        ne(t) {
            return t instanceof NavigateEvent != !1 && (!t.hashChange && !t.downloadRequest && !t.formData)
        }
    }
    let Qe = "null",
        Je = null;
    const Ke = [];

    function Ye(t) {
        null == Je || Je.postMessage(t)
    }!!(null === (Ze = document.body) || void 0 === Ze ? void 0 : Ze.getAttribute("data-cs-tag-extension")) && (window._uxa ? _uxa.push(["debugEvents", !0]) : window._uxa = [
        ["debugEvents", !0]
    ], Je = new BroadcastChannel("cs-tag"), document.addEventListener("cs.tracking.recordingEvent", (t => {
        Ye({
            type: "UXA_EVENT",
            event: t.detail
        })
    })), Je.addEventListener("message", (t => {
        if ("CONNECT" === t.data.type) {
            if (t.data.sessionId === Qe) return;
            Qe = t.data.sessionId, csArray.prototype.forEach.call(Ke, (t => t())), null == Je || Je.postMessage({
                type: "CONNECTED",
                sessionId: Qe
            })
        }
    })));
    class Xe {
        constructor(t, s = "") {
            this.name = t, this.format = s
        }
    }
    class ti extends Xe {
        constructor(t) {
            super(t, "Value: {count}"), this.count = 0
        }
        increase(t = 1) {
            this.count += t
        }
        decrease() {
            this.count > 0 && this.count--
        }
        clear() {
            this.count = 0
        }
        getData() {
            return {
                count: this.count
            }
        }
    }
    class si extends Xe {
        constructor(t, s) {
            super(t, "Value: {count}"), this.fe = s
        }
        getData() {
            return {
                count: this.fe()
            }
        }
    }
    class ei extends Xe {
        constructor(t) {
            super(t, "Living intances: {instances}<br/>Added: {added}<br/>Removed: {removed}"), this.added = 0, this.removed = 0
        }
        get value() {
            return this.added - this.removed
        }
        increase() {
            this.added++
        }
        decrease() {
            this.removed++
        }
        getData() {
            return {
                added: this.added,
                removed: this.removed,
                instances: this.added - this.removed
            }
        }
    }
    class ii extends Xe {
        constructor(t) {
            super(t, "Count: {count}<br/>Average: {average}ms<br/>Total: {total}ms"), this.total = 0, this.count = 0
        }
        get average() {
            return this.count ? this.total / this.count : 0
        }
        measure(t) {
            const s = Vt.elapsed();
            t(), this.count++, this.total += Vt.elapsed() - s
        }
        asyncMeasure() {
            const t = Vt.elapsed();
            return () => {
                this.count++, this.total += Vt.elapsed() - t
            }
        }
        getData() {
            return {
                total: this.total,
                count: this.count,
                average: this.average
            }
        }
    }
    let ni = 0;
    const ri = {
        general: {
            category: "General",
            nbEvents: new ti("Nb of Events"),
            pendingTasks: new ti("Pending Tasks"),
            pendingEvents: new ti("Pending Tasks"),
            nbOfMutationObservers: new ei("Nb of Mutation Observers"),
            push(t) {
                this["perf" + ni++] = t
            }
        },
        mutations: {
            category: "Mutations",
            initialDOM: new ii("Initial DOM"),
            pendingMutations: new ti("Nb of Mutations scheduled"),
            serializedMutations: new ii("Serialized Mutations"),
            count: new ti("Mutation Count"),
            elementMutationObserved: new ei("Nb of Elements Observed by MutationObserver"),
            unobserveGarbageCollection: new ii("Unobserve GC")
        },
        visibilityObserver: {
            category: "Visibility Observer",
            hiddenElements: new ti("Nb of Hidden Elements "),
            nbElements: new ti("Nb of  Elements")
        }
    };
    var oi, hi;
    oi = () => {
            const t = t => Object.keys(t),
                s = csArray.prototype.map.call(t(ri), (t => ri[t])),
                e = csArray.prototype.map.call(s, (s => csArray.prototype.filter.call(csArray.prototype.map.call(t(s), (t => s[t])), (t => t instanceof Xe)))),
                i = csArray.prototype.map.call(s, ((t, s) => ({
                    category: t.category,
                    performanceCounters: csArray.prototype.map.call(e[s], (t => ({
                        name: t.name,
                        format: t.format
                    })))
                })));
            Ye({
                type: "UXA_PERFORMANCE_COUNTER_SCHEMA",
                event: i
            }), csSetInterval((() => {
                const t = Ls($s(e, (t => $s(t, (t => t.getData())))), (t => t));
                Ye({
                    type: "UXA_PERFORMANCE_COUNTER",
                    event: t
                })
            }), 1e3)
        }, null !== Qe && oi(), csArray.prototype.push.call(Ke, oi),
        function(t) {
            t[t.Active = 0] = "Active", t[t.Paused = 1] = "Paused", t[t.Stopped = 2] = "Stopped"
        }(hi || (hi = {}));
    class ci {
        constructor(t, s, e = []) {
            this.pe = t, this.ve = s, this.ge = e, this.ye = null, this.we = hi.Active, this.Ee = []
        }
        reset() {
            this.ye = null, this.Ee = [], this.we = hi.Active
        }
        disconnect() {
            this.we = hi.Stopped
        }
        Ae() {
            this.ve(hi.Paused), this.we = hi.Paused, csSetTimeout((() => {
                this.we === hi.Paused && this._e()
            }), ci.STOP_TIMEOUT)
        }
        Se() {
            this.ve(hi.Active), this.we = hi.Active, Ms(this.Ee, this.pe), this.Ee = []
        }
        _e() {
            this.Ee = [], this.ve(hi.Stopped), this.we = hi.Stopped
        }
        pushEvent(t, s) {
            if (s.isUserEvent && (this.ye = t.date, this.we !== hi.Active)) return this.Se(), void this.pe(t);
            if (this.Re(t)) this.pe(t);
            else switch (this.we) {
                case hi.Active:
                    if (this.Te(t, s)) return this.Ae(), void csArray.prototype.push.call(this.Ee, t);
                    this.pe(t);
                    break;
                case hi.Paused:
                    csArray.prototype.push.call(this.Ee, t);
                case hi.Stopped:
            }
        }
        Te(t, s) {
            return !s.isUserEvent && null !== this.ye && t.date - this.ye > ci.INACTIVITY_TIMEOUT
        }
        Re(t) {
            return csArray.prototype.indexOf.call(this.ge, t.type) > -1
        }
    }
    ci.INACTIVITY_TIMEOUT = 5e3, ci.STOP_TIMEOUT = 5e3;

    function ai(t, s, e, i) {
        var n, r = arguments.length,
            o = r < 3 ? s : null === i ? i = Object.getOwnPropertyDescriptor(s, e) : i;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(t, s, e, i);
        else
            for (var h = t.length - 1; h >= 0; h--)(n = t[h]) && (o = (r < 3 ? n(o) : r > 3 ? n(s, e, o) : n(s, e)) || o);
        return r > 3 && o && Object.defineProperty(s, e, o), o
    }
    Object.create;
    Object.create;

    function ui(t) {
        return Nt(t, "data:")
    }

    function li(t) {
        return Nt(t, "#")
    }

    function di(t) {
        return !!t && xt(t, ".css")
    }

    function fi(t) {
        const s = csString.prototype.trim.call(t);
        if ("" === t) return [];
        let [e, i] = (n = s, csString.prototype.split.call(n, /\s(.+)/));
        var n;
        return i ? (xt(e, ",") || (i = function(t) {
            return csString.prototype.split.call(t, /,(.+)/)[1] || ""
        }(i)), [pi(e), ...fi(i)]) : [pi(e)]
    }

    function pi(t) {
        return csString.prototype.split.call(t, /,$/)[0]
    }
    const mi = /(@import\s*("([^"]+)"|'([^']+)'))|(url\s*\(\s*((("([^"\]]+)"|'([^'\]]+)')\s*)|([^)\]]+))\))/g;

    function vi(t, s) {
        const e = csString.prototype.replace.call(t, mi, ((...t) => {
            const e = t[3] || t[4],
                i = t[9] || t[10] || t[11],
                n = function(t) {
                    const s = /(\\)*\\(?:([a-fA-F0-9]{1,6})|(.))[\n\t\x20]?/g;
                    return csString.prototype.replace.call(t, s, ((t, s, e, i) => {
                        if ("\\" === s) return csString.prototype.slice.call(t, 1);
                        if (i) return i;
                        const n = parseInt(e, 16);
                        return 55296 <= n && n <= 57343 || 0 === n || n > 1114111 ? "�" : csString.fromCodePoint(n)
                    }))
                }((e || i).trim());
            return `${e?"@import ":""}url(${function(t){if(-1===csString.prototype.indexOf.call(t,'"'))return`"${t}"`;if(-1===csString.prototype.indexOf.call(t,"'"))return`'${t}'`;return t}(s(n)||n)})`
        }));
        return e
    }

    function gi(t) {
        const s = new Set;
        return vi(t, (t => {
            var e, i;
            return s.add(null !== (i = null === (e = csString.prototype.match.call(t, /^["|'](.*)?["|']$/)) || void 0 === e ? void 0 : e[1]) && void 0 !== i ? i : t), t
        })), Hs(s)
    }
    const yi = new Map,
        wi = !Ft && document.implementation.createHTMLDocument("");

    function Ei(t) {
        if (!v(t)) return null;
        const s = Ai(t);
        if (null === s || 0 === s.length) return null;
        let e = "";
        if (Tt(t.textContent)) Ms(s, (t => e += t.cssText));
        else {
            const i = function(t) {
                if (!wi) return 0;
                let s = yi.get(t.textContent);
                if (s) return s;
                const e = t.cloneNode(!0);
                e.textContent = t.textContent, wi.head.appendChild(e);
                const i = Ai(e);
                return s = i ? i.length : 0, yi.set(t.textContent, s), wi.head.removeChild(e), s
            }(t);
            if (i === s.length) return null;
            const n = new csArray(s.length - i);
            for (let t = i, e = 0; t < s.length; t += 1, e += 1) n[e] = s[t];
            Ms(n, (t => e += t.cssText))
        }
        return e
    }

    function Ai(t) {
        try {
            if (t.disabled) return null;
            const s = t.sheet;
            return s ? s.cssRules || s.rules : null
        } catch (t) {
            if ("SecurityError" !== t.name && "InvalidAccessError" !== t.name) throw t;
            return null
        }
    }
    const _i = t => t instanceof HTMLFormElement ? "form" : t.localName;
    class Si {
        constructor(t) {
            this.csId = be(t), this.props = Se.getStore(t)
        }
    }
    class Ri extends Si {
        constructor(t) {
            super(t), this.nodeType = 3, this.data = t.data
        }
    }
    class Ti extends Si {
        constructor(t) {
            var s;
            super(t), this.attributes = [], this.nodeType = 1, this.localName = _i(t), this.namespaceURI = null !== (s = t.namespaceURI) && void 0 !== s ? s : void 0, this.children = [];
            const e = Ei(t);
            if (e) {
                this.children = new csArray(csNodechildNodes.apply(t).length);
                const s = document.createTextNode(e),
                    i = new Ri(s);
                csArray.prototype.push.call(this.children, i)
            }
            E(t) && Re.setProperty(this, "SVG", !0)
        }
        static isElement(t) {
            return 1 === t.nodeType
        }
        static getAttribute(t, s) {
            return Ds(t.attributes, (t => t.name === s))
        }
        static getAttributeValue(t, s) {
            var e;
            return null === (e = this.getAttribute(t, s)) || void 0 === e ? void 0 : e.value
        }
    }
    class Ii {
        constructor(t) {
            this.type = "asyncEvent", this.Ie = !1, t && t((t => this.resolve(t)))
        }
        resolve(t) {
            if (this.Ie) throw new Error("AsyncEvent already resolve.");
            null == t.timestamp && (t = { ...t,
                timestamp: this.timestamp
            }), this.be = t, this.Ie = !0, this.Is && this.Is(this.be)
        }
        complete(t) {
            this.Ie && t(this.be), this.Is = t
        }
        wait() {
            return new Promise((t => this.complete(t)))
        }
    }
    let bi = (Pi = "queueMicrotask", Vi = csSetTimeout, void 0 !== Ht[Pi] ? Ht[Pi] : Vi);
    var Pi, Vi;
    "object" == typeof window && _t(window.csQueueMicrotask) && (bi = window.csQueueMicrotask);
    const Ci = new us,
        ki = new us;
    let Oi = 1;

    function Ni(t, s = "high") {
        const e = Oi;
        Ci.isEmpty && ki.isEmpty && xi((() => {
            if (Oi !== e) return;
            const t = ws((() => {
                for (; !ki.isEmpty;) {
                    ki.pop()()
                }
                for (; !Ci.isEmpty;) {
                    Ci.pop()()
                }
                ki.isEmpty || t()
            }), "groupMicrotask.run");
            t()
        }));
        const i = hs(`groupMicrotask:${s}:${t.name||t.toString()}`, t);
        "high" === s ? ki.push(i) : Ci.push(i)
    }

    function xi(t, s = 10) {
        bi(0 === s ? t : () => xi(t, s - 1))
    }
    async function $i(t = 1) {
        for (let s = 0; s < t; s++) await new Promise((t => Ni(t)))
    }
    const Li = (t, s = 0) => csSetTimeout(function(t) {
        return function() {
            try {
                t.apply(window, arguments)
            } catch (t) {
                rs.critical(t)
            }
        }
    }(t), s);
    var Mi, Di;
    ! function(t) {
        function s() {
            const t = [i()];
            return document.documentElement && csArray.prototype.push.call(t, document.documentElement.scrollHeight, document.documentElement.offsetHeight, document.documentElement.clientHeight), document.body && csArray.prototype.push.call(t, document.body.scrollHeight, document.body.offsetHeight), Math.max(...t)
        }

        function e() {
            return document.documentElement.scrollWidth
        }

        function i() {
            return window.innerHeight
        }

        function n() {
            return window.innerWidth
        }

        function r() {
            const t = window.csScreen.width;
            return gt(t) && t > 0 ? t : window.screen.width
        }

        function o() {
            const t = window.csScreen.height;
            return gt(t) && t > 0 ? t : window.screen.height
        }
        t.documentHeight = s, t.documentWidth = e, t.windowHeight = i, t.windowWidth = n, t.screenWidth = r, t.screenHeight = o, t.windowOffsetX = function() {
            return window.pageXOffset
        }, t.windowOffsetY = function() {
            return window.pageYOffset
        }, t.getRequestParameters = function() {
            return {
                dw: `${e()}`,
                dh: `${s()}`,
                ww: `${n()}`,
                wh: `${i()}`,
                sw: `${r()}`,
                sh: `${o()}`
            }
        }
    }(Mi || (Mi = {}));
    const Ui = null !== (Di = Ht.Node) && void 0 !== Di ? Di : Object;
    var qi;

    function Fi() {
        const t = new Set;
        return {
            add(s) {
                t.add(s), 1 === t.size && csSetTimeout((() => {
                    t.clear()
                }))
            },
            has: s => t.has(s),
            del(s) {
                t.delete(s)
            },
            clear() {
                t.clear()
            },
            values: () => Hs(t),
            get count() {
                return t.size
            }
        }
    }

    function Hi(t, s = !1) {
        const e = Fi();
        return {
            push(i) {
                if (0 === e.count) {
                    (s ? Ni : csSetTimeout)((() => {
                        t(e.values()), e.clear()
                    }))
                }
                e.add(i)
            }
        }
    }! function(t) {
        const s = "isConnected" in Ui.prototype ? t => t.isConnected : t => !(t.ownerDocument && t.ownerDocument.compareDocumentPosition(t) & t.DOCUMENT_POSITION_DISCONNECTED);
        t.forEachChild = function(t, s) {
            for (let e = t; e; e = csNodenextSibling.apply(e)) s(t)
        }, t.isConnected = function(t) {
            return s(t)
        }, t.getAncestors = function(t, s) {
            const e = [];
            for (const n of i(t, s)) csArray.prototype.push.call(e, n);
            return e
        };
        const e = (t, s) => {
            var e;
            return null !== (e = csNodeparentNode.apply(t)) && void 0 !== e ? e : s && R(t) ? t.host : null
        };

        function* i(t, s = !1) {
            let i = t;
            for (; i;) {
                yield i;
                const t = e(i, s);
                if (!t || t === i) break;
                i = t
            }
        }

        function n(s) {
            var e;
            return s.parentElement ? s.parentElement : t.getRootNode(s) ? null === (e = t.getRootNode(s)) || void 0 === e ? void 0 : e.host : null
        }

        function r(t) {
            var s, e;
            if (!1 === (null === (s = t.checkVisibility) || void 0 === s ? void 0 : s.call(t, {
                    checkOpacity: !0,
                    checkVisibilityCSS: !0
                }))) return !0;
            if (!t.offsetParent) {
                if (!t.getBoundingClientRect) return rs.warn(`SUP-11432: Element doesn't have getBoundingClientRect. Node: ${t instanceof Ui} Ctor: ${null===(e=null==t?void 0:t.constructor)||void 0===e?void 0:e.name}`), !1;
                const s = t.getBoundingClientRect();
                if (0 == s.width && 0 == s.height) return !0
            }
            const i = window.getComputedStyle(t);
            if (!i) return !0;
            var n;
            return "none" === i.display || "hidden" === i.visibility || "collapse" === i.visibility || "0" === i.opacity || "opacity(0)" === i.filter || "0px" === i.width && "0px" === i.height || ("transparent" === (n = i.color) || /^(rgba|hsla)\(\d+, \d+%?, \d+%?, 0\)$/.test(n))
        }

        function o(t) {
            const s = t.getBoundingClientRect(),
                e = s.left + .5 * s.width,
                i = s.top + .5 * s.height;
            return h(document, e, i)
        }

        function h(s, e, i) {
            const n = s.elementFromPoint(e, i);
            if (!n) return null;
            const r = re.getShadowRoot(n);
            return r && r != t.getRootNode(document.body) && r !== s ? h(r, e, i) : n
        }

        function c(t) {
            const s = o(t);
            return null !== s && (t === s || t.contains(s))
        }
        t.findAncestor = function(t, s, i = !1) {
            let n = t;
            for (; n;) {
                if (s(n)) return n;
                const t = e(n, i);
                if (!t || t === n) break;
                n = t
            }
            return null
        }, t.walkUp = i, t.isDescendantOf = function s(e, i) {
            if (e === i || i.contains(e)) return !0;
            const n = t.getParentElement(e);
            return !(!n || n === e) && s(n, i)
        }, t.getParentElement = n, t.findAllElements = function(t, s = document) {
            const e = xs(window.csquerySelectorAll[s.nodeType].call(s, t)),
                i = re.getAllShadowHosts(s);
            for (const s of i) {
                const i = re.getShadowRoot(s);
                if (!i) continue;
                const n = xs(window.csquerySelectorAll[i.nodeType].call(i, t));
                csArray.prototype.push.call(e, ...n)
            }
            return e
        }, t.getRootNode = (() => {
            if ("getRootNode" in Ui.prototype) return (t, s) => t.getRootNode(s);

            function t(e) {
                const i = s(e);
                return R(i) ? t(i.host) : i
            }

            function s(t) {
                return null != csNodeparentNode.apply(t) ? s(csNodeparentNode.apply(t)) : t
            }
            return (e, i) => "object" == typeof i && Boolean(i.composed) ? t(e) : s(e)
        })(), t.isHiddenByCSS = r, t.areAncestorsHiddenByCSS = function t(s) {
            if (r(s)) return !0;
            const e = n(s);
            return null != e && t(e)
        }, t.getTopAncestorHiddenByCSS = function(t) {
            let s = null,
                e = t;
            do {
                if (!r(e)) break;
                s = e
            } while (e = n(e));
            return s
        }, t.getTopElement = o, t.getElementOnTop = function(s) {
            if (!s.getBoundingClientRect) return null;
            const e = s.getBoundingClientRect(),
                i = e.x + e.width / 2,
                n = e.y + e.height / 2;
            return t.getTopElementFromPoint(document, i, n)
        }, t.getTopElementFromPoint = h, t.isVisibleInDocument = function(t) {
            return ! function(t) {
                const s = t.getBoundingClientRect();
                return s.right + Mi.windowOffsetX() < 0 || s.bottom + Mi.windowOffsetY() < 0
            }(t) && !r(t) && ! function(t) {
                const s = o(t);
                return null !== s && !t.contains(s)
            }(t)
        }, t.isVisibleInViewportInForeground = function(t) {
            return !r(t) && c(t)
        }, t.isInViewPort = c, t.getAttributeNS = function(t, s, e) {
            const i = t.getAttributeNS(s, e);
            return "" === i ? t.hasAttributeNS(s, e) ? i : null : i
        }, t.isElementFocusable = function(t) {
            return !!t.hasAttribute("tabIndex") || ("true" === t.getAttribute("contentEditable") || (!(!p(t) || !t.hasAttribute("href")) || (!(!(A(t) || y(t) || g(t) || (s = t, l(s) && "button" === s.localName)) || t.hasAttribute("disabled")) || !(! function(t) {
                return l(t) && "details" === t.localName
            }(t) && ! function(t) {
                return l(t) && "summary" === t.localName
            }(t)))));
            var s
        }
    }(qi || (qi = {}));
    const Bi = csSymbol();
    class ji {
        constructor(t) {
            var s, e, i, n, r, o, h, c;
            this.Is = t, this.Pe = null, this.Ve = null, this.Ce = null, this.ke = null, this.Oe = Hi((t => this.processUpdateRulesInATick(t))), this.Is = s => Ni((() => t(s))), "function" == typeof(null === (e = null === (s = window.CSSStyleSheet) || void 0 === s ? void 0 : s.prototype) || void 0 === e ? void 0 : e.insertRule) && (this.Pe = ie({
                target: window.CSSStyleSheet.prototype,
                methodName: "insertRule",
                hook: ({
                    context: t,
                    args: s
                }) => {
                    this.processInsertRule(t, s)
                }
            })), "function" == typeof(null === (n = null === (i = window.CSSStyleSheet) || void 0 === i ? void 0 : i.prototype) || void 0 === n ? void 0 : n.deleteRule) && (this.Ve = ie({
                target: window.CSSStyleSheet.prototype,
                methodName: "deleteRule",
                hook: ({
                    context: t,
                    args: s
                }) => {
                    this.processDeleteRule(t, s)
                }
            })), "function" == typeof(null === (o = null === (r = window.CSSGroupingRule) || void 0 === r ? void 0 : r.prototype) || void 0 === o ? void 0 : o.insertRule) && (this.Ce = ie({
                target: window.CSSGroupingRule.prototype,
                methodName: "insertRule",
                hook: ({
                    context: t
                }) => this.processUpdateRule(t)
            })), "function" == typeof(null === (c = null === (h = window.CSSGroupingRule) || void 0 === h ? void 0 : h.prototype) || void 0 === c ? void 0 : c.deleteRule) && (this.ke = ie({
                target: window.CSSGroupingRule.prototype,
                methodName: "deleteRule",
                hook: ({
                    context: t
                }) => this.processUpdateRule(t)
            }))
        }
        observe() {
            var t, s, e, i;
            null === (t = this.Pe) || void 0 === t || t.activate(), null === (s = this.Ve) || void 0 === s || s.activate(), null === (e = this.Ce) || void 0 === e || e.activate(), null === (i = this.ke) || void 0 === i || i.activate()
        }
        disconnect() {
            var t, s, e, i;
            null === (t = this.Pe) || void 0 === t || t.deactivate(), null === (s = this.Ve) || void 0 === s || s.deactivate(), null === (e = this.Ce) || void 0 === e || e.deactivate(), null === (i = this.ke) || void 0 === i || i.deactivate()
        }
        processInsertRule(t, [s, e]) {
            if (null == t[Bi] && !t.ownerNode) return;
            const i = {
                type: "cssRuleInserted",
                sheet: t,
                rule: s,
                index: e
            };
            this.Is(i)
        }
        processUpdateRule(t) {
            let s = t;
            for (; null !== s.parentRule;) s = s.parentRule;
            null !== s.parentStyleSheet && this.Oe.push(s)
        }
        processUpdateRulesInATick(t) {
            for (const s of t) {
                if (null === s.parentStyleSheet) return;
                const t = s.parentStyleSheet,
                    e = csArray.prototype.indexOf.call(xs(t.cssRules), s);
                if (-1 === e) return;
                const i = {
                    type: "cssRuleUpdated",
                    sheet: t,
                    rule: s.cssText,
                    index: e
                };
                this.Is(i)
            }
        }
        processDeleteRule(t, [s]) {
            if (null == t[Bi] && !t.ownerNode) return;
            const e = {
                type: "cssRuleDeleted",
                sheet: t,
                index: s
            };
            this.Is(e)
        }
    }
    Gs([os()], ji.prototype, "observe", null), Gs([os()], ji.prototype, "disconnect", null), Gs([os()], ji.prototype, "processInsertRule", null), Gs([os()], ji.prototype, "processUpdateRule", null), Gs([os()], ji.prototype, "processUpdateRulesInATick", null), Gs([os()], ji.prototype, "processDeleteRule", null);
    class zi {
        constructor(t) {
            this.Ne = 1, this.xe = new Set, this.$e = null, this.Le = null, this.Me = (t, s) => {
                "initial" !== s && "added" !== s || this.setStyleSheets(t, t.adoptedStyleSheets)
            }, this.De = t => {
                const s = t.sheet;
                if (this.xe.has(s))
                    if ("cssRuleInserted" === t.type) {
                        const e = {
                            type: "adoptedStyleSheetRuleInserted",
                            sheetId: s[Bi],
                            rule: t.rule,
                            index: t.index
                        };
                        this.Is(e)
                    } else if ("cssRuleDeleted" === t.type) {
                    const e = {
                        type: "adoptedStyleSheetRuleDeleted",
                        sheetId: s[Bi],
                        index: t.index
                    };
                    this.Is(e)
                } else if ("cssRuleUpdated" === t.type) {
                    const e = {
                        type: "adoptedStyleSheetRuleUpdated",
                        sheetId: s[Bi],
                        rule: t.rule,
                        index: t.index
                    };
                    this.Is(e)
                }
            }, this.Is = s => Ni((async () => {
                await $i(2), t(s)
            })), this.xs = new he(this.Me), "adoptedStyleSheets" in Document.prototype && (this.$e = ne(window.Document.prototype, "adoptedStyleSheets", ((t, s) => {
                this.setStyleSheets(t, s)
            }))), "ShadowRoot" in window && "adoptedStyleSheets" in window.ShadowRoot.prototype && (this.Le = ne(window.ShadowRoot.prototype, "adoptedStyleSheets", ((t, s) => {
                this.setStyleSheets(t, s)
            }))), this.Ue = new ji(this.De)
        }
        observe() {
            var t, s;
            this.setStyleSheets(document, document.adoptedStyleSheets), this.xs.observe(), null === (t = this.$e) || void 0 === t || t.activate(), null === (s = this.Le) || void 0 === s || s.activate(), this.Ue.observe()
        }
        disconnect() {
            var t, s;
            this.xe.clear(), this.xs.disconnect(), null === (t = this.$e) || void 0 === t || t.deactivate(), null === (s = this.Le) || void 0 === s || s.deactivate(), this.Ue.disconnect()
        }
        setStyleSheets(t, s) {
            if (!s.length) return;
            this.qe(s);
            const e = {
                type: "adoptedStyleSheetsSet",
                target: t,
                sheetsIds: $s(s, (t => t[Bi]))
            };
            this.Is(e)
        }
        qe(t) {
            Ms(t, (t => {
                if (this.xe.has(t)) return;
                const s = this.Ne++;
                t[Bi] = s, this.xe.add(t);
                const e = {
                    type: "adoptedStyleSheetRegistered",
                    sheetId: s,
                    cssRules: this.Fe(t)
                };
                this.Is(e)
            }))
        }
        Fe(t) {
            let s = [];
            try {
                s = $s(t.cssRules, (t => t.cssText))
            } catch {}
            return s
        }
    }
    Gs([os()], zi.prototype, "observe", null), Gs([os()], zi.prototype, "disconnect", null), Gs([os()], zi.prototype, "setStyleSheets", null);
    const Gi = ws((function(t) {
        const s = [],
            e = function(t) {
                const s = new Map,
                    e = t => {
                        let e = s.get(t);
                        return e || s.set(t, e = []), e
                    },
                    i = (t, s) => {
                        const i = e(t);
                        i.length && "insert" !== i[0].operation && "remove" !== i[0].operation && (i.length = 0), csArray.prototype.push.call(i, s)
                    };
                for (const s of t) switch (s.type) {
                    case "attributes":
                        {
                            const t = e(s.target);
                            if (t.length && "attribute" !== t[0].operation) continue;
                            const i = csArray.prototype.findIndex.call(t, (t => "attributes" === t.mutation.type && t.mutation.attributeName === s.attributeName)),
                                n = {
                                    operation: "attribute",
                                    mutation: s
                                };i >= 0 ? t[i] = n : csArray.prototype.push.call(t, n)
                        }
                        break;
                    case "characterData":
                        {
                            const t = e(s.target);
                            if (t.length && "characterData" !== t[0].operation) continue;t[0] = {
                                operation: "characterData",
                                mutation: s
                            }
                        }
                        break;
                    case "childList":
                        Ms(s.removedNodes, (t => i(t, {
                            operation: "remove",
                            mutation: s
                        }))), Ms(s.addedNodes, (t => i(t, {
                            operation: "insert",
                            mutation: s
                        })))
                }
                return s
            }(t = function(t) {
                const s = t => {
                        switch (t.type) {
                            case "attributes":
                                return t.target.getAttribute(t.attributeName);
                            case "characterData":
                                return t.target.data
                        }
                        throw new Error("not supported type")
                    },
                    e = csSymbol(),
                    i = csSymbol(),
                    n = t => {
                        let s;
                        for (const n of qi.walkUp(t)) {
                            if (n[e] || n[i]) return n;
                            s = t
                        }
                        return s
                    },
                    r = [];
                for (const o of t) {
                    if ("childList" === o.type) {
                        Ms(o.addedNodes, (t => t[e] = !0)), csArray.prototype.push.call(r, o);
                        continue
                    }
                    if (s(o) === o.oldValue) continue;
                    if ("attributes" === o.type && Qi(o.target, "attributes", o.attributeName)) continue;
                    if ("characterData" === o.type && Qi(o.target, "characterData")) continue;
                    const t = n(o.target);
                    (null == t ? void 0 : t[e]) || (csNodeparentNode.apply(o.target) && (csNodeparentNode.apply(o.target)[i] = !0), csArray.prototype.push.call(r, o))
                }
                return r
            }(t));
        for (const i of t) switch (i.type) {
            case "attributes":
            case "characterData":
                csArray.prototype.push.call(s, i);
                break;
            case "childList":
                csArray.prototype.push.call(s, ...Ji(i, e))
        }
        return qs(s, (t => ! function(t, s) {
            if ("attributes" === t.type || "characterData" === t.type) {
                return !Us(s.get(t.target), (s => s.mutation === t))
            }
            if (t.addedNodes.length) {
                if (t.target === document.body) return !1;
                const e = t => {
                    var e;
                    return "insert" === (null === (e = s.get(t)) || void 0 === e ? void 0 : e[0].operation)
                };
                if (e(t.target)) return !0;
                return null !== qi.findAncestor(t.target, e, !0)
            }
            return !1
        }(t, e)))
    }), "optimizeMutations");
    var Zi;
    ! function(t) {
        t.Move = "remove-insert", t.Remove = "remove-remove", t.NoOp = "insert-remove", t.Insert = "insert-insert", t.None = "none"
    }(Zi || (Zi = {}));
    const Wi = 30;

    function Qi(t, s, e) {
        const i = csSymbol.for(e ? `${s}:${e}` : s),
            n = Vt.now(),
            r = t[i];
        return !!(r && n < r) || (t[i] = n + Wi, !1)
    }

    function Ji(t, s) {
        var e, i;
        if (t.addedNodes.length && !t.removedNodes.length && !Us(t.addedNodes, qi.isConnected)) return [];
        if (!qi.isConnected(t.target)) return [];
        if (!(t => Us(t.addedNodes, (t => s.get(t).length > 1)) || Us(t.removedNodes, (t => s.get(t).length > 1)))(t)) {
            const s = Yi(t),
                e = Xi(t);
            if (e || s !== t.nextSibling) {
                const i = [];
                return csArray.prototype.push.call(i, {
                    nextSibling: s,
                    previousSibling: e,
                    target: t.target,
                    type: "childList",
                    addedNodes: t.addedNodes,
                    removedNodes: t.removedNodes
                }), i
            }
            return [t]
        }
        const n = function(t, s) {
                return qs(t.addedNodes, (e => {
                    const i = tn(e, s),
                        n = qs(s.get(e), (t => "insert" === t.operation));
                    switch (i) {
                        case Zi.Insert:
                            return t === n[n.length - 1].mutation;
                        case Zi.None:
                            return !0;
                        case Zi.Move:
                        case Zi.Remove:
                        case Zi.NoOp:
                            return !1
                    }
                }))
            }(t, s),
            r = function(t, s) {
                return qs(t.removedNodes, (e => {
                    const i = tn(e, s),
                        n = qs(s.get(e), (t => "remove" === t.operation));
                    switch (i) {
                        case Zi.Remove:
                            return t === n[n.length - 1].mutation;
                        case Zi.None:
                            return !0;
                        case Zi.Move:
                        case Zi.Insert:
                        case Zi.NoOp:
                            return !1
                    }
                }))
            }(t, s),
            o = function(t, s) {
                return qs(t.addedNodes, (e => {
                    const i = qs(s.get(e), (t => "insert" === t.operation));
                    return tn(e, s) === Zi.Move && t === i[i.length - 1].mutation
                }))
            }(t, s),
            h = Ki(n),
            c = Ki(o),
            a = [];
        if (h.length > 1 || c.length > 1) {
            const s = function(t, s, e, i) {
                const n = [];
                let r = !0;
                return Ms(t, (t => {
                        0 !== t.length && (csArray.prototype.push.call(n, {
                            nextSibling: csNodenextSibling.apply(t[t.length - 1]),
                            previousSibling: t[0].previousSibling,
                            target: e.target,
                            type: "childList",
                            addedNodes: t,
                            removedNodes: r ? i : []
                        }), r = !1)
                    })), Ms(s, (t => {
                        0 !== t.length && csArray.prototype.push.call(n, {
                            nextSibling: csNodenextSibling.apply(t[t.length - 1]),
                            previousSibling: t[0].previousSibling,
                            target: e.target,
                            movedNodes: t,
                            addedNodes: [],
                            removedNodes: [],
                            type: "childList"
                        })
                    })),
                    function(t, s) {
                        const e = t => {
                                var s;
                                return (null === (s = t.movedNodes) || void 0 === s ? void 0 : s.length) ? t.movedNodes[0] : t.addedNodes[0]
                            },
                            i = s => function(t, s) {
                                const e = t.length;
                                for (let i = 0; i < e; i++)
                                    if (s(t[i], i)) return i;
                                return -1
                            }(t.addedNodes, (t => t === e(s)));
                        csArray.prototype.sort.call(s, ((t, s) => i(t) - i(s)))
                    }(e, n), n
            }(h, c, t, r);
            return csArray.prototype.push.call(a, ...s), a
        }
        return (n.length > 0 || r.length > 0) && csArray.prototype.push.call(a, {
            nextSibling: null !== (e = Yi(t)) && void 0 !== e ? e : t.nextSibling,
            previousSibling: null !== (i = Xi(t)) && void 0 !== i ? i : t.previousSibling,
            target: t.target,
            type: "childList",
            addedNodes: n,
            removedNodes: r
        }), o.length && csArray.prototype.push.call(a, {
            nextSibling: csNodenextSibling.apply(o[0]),
            previousSibling: o[0].previousSibling,
            target: t.target,
            movedNodes: o,
            addedNodes: [],
            removedNodes: [],
            type: "childList"
        }), a
    }

    function Ki(t) {
        if (t.length <= 1) return [t];
        const s = [];
        let e = 0;
        for (let i = 0; i < t.length - 1; i += 1) csNodenextSibling.apply(t[i]) !== t[i + 1] && (csArray.prototype.push.call(s, csArray.prototype.slice.call(t, e, i + 1)), e = i + 1);
        return e > 0 && csArray.prototype.push.call(s, csArray.prototype.slice.call(t, e, t.length)), s
    }

    function Yi(t) {
        if (t.nextSibling && !qi.isConnected(t.nextSibling)) {
            if (t.addedNodes.length) return csNodenextSibling.apply(t.addedNodes[t.addedNodes.length - 1]);
            if (t.removedNodes.length) return csNodenextSibling.apply(t.removedNodes[t.removedNodes.length - 1])
        } else if (t.nextSibling && t.addedNodes.length && csNodenextSibling.apply(t.addedNodes[t.addedNodes.length - 1]) !== t.nextSibling) return null;
        return t.nextSibling
    }

    function Xi(t) {
        if (t.previousSibling && !qi.isConnected(t.previousSibling)) {
            if (t.addedNodes.length) return t.addedNodes[0].previousSibling;
            if (t.removedNodes.length) return t.removedNodes[0].previousSibling
        }
        return null
    }

    function tn(t, s) {
        var e, i;
        const n = s.get(t);
        return !n || n.length <= 1 ? Zi.None : `${null===(e=n[0])||void 0===e?void 0:e.operation}-${null===(i=n[n.length-1])||void 0===i?void 0:i.operation}`
    }
    var sn;
    const en = {
        childList: !0,
        subtree: !0,
        attributes: !0,
        characterData: !0,
        characterDataOldValue: !0,
        attributeOldValue: !0
    };
    class nn {
        static setShadowRootFilter(t) {
            csArray.prototype.push.call(sn.shadowRootFilters, t)
        }
        static He(t) {
            if (sn.shadowRootFilters.length > 0 && R(t))
                for (let s = 0; s < sn.shadowRootFilters.length; s++) {
                    if ((0, sn.shadowRootFilters[s])(t)) return
                }
            this.observedTargets.add(t), this.mutationObserver.observe(t, en)
        }
        static disconnectShadowRoot(t) {
            this.observedTargets.has(t) && (this.observedTargets.delete(t), this.isRefreshing || (this.isRefreshing = !0, Ni((() => {
                this.isRefreshing = !1;
                const t = this.mutationObserver.takeRecords();
                t.length && sn.mutationCallback(t), this.mutationObserver.disconnect(), this.observedTargets.forEach((t => {
                    this.mutationObserver.observe(t, en)
                }))
            }))))
        }
        static observe(t, s) {
            csArray.prototype.push.call(this.callbacks, t), s && csArray.prototype.push.call(this.shadowRootCallbacks, s), this.started ? s && csArray.prototype.forEach.call(re.getAllShadowHosts(document), (t => s(csElementshadowRoot.apply(t), "initial"))) : (this.mutationObserver = new csMutationObserver(this.mutationCallback), this.He(document), this.shadowRootObserver = new he(this.onShadowRoot), this.shadowRootObserver.observe(), this.started = !0, Ms(this.shadowRootObserver.shadowRoots, (t => {
                this.He(t)
            })))
        }
        static disconnect(t, s) {
            var e, i;
            this.callbacks = csArray.prototype.filter.call(this.callbacks, (s => s !== t)), s && (this.shadowRootCallbacks = csArray.prototype.filter.call(this.shadowRootCallbacks, (t => t !== s))), 0 === this.callbacks.length && (this.callbacks = [], this.shadowRootCallbacks = [], sn.shadowRootFilters = [], null === (e = this.shadowRootObserver) || void 0 === e || e.disconnect(), null === (i = this.mutationObserver) || void 0 === i || i.disconnect(), this.observedTargets.clear(), this.started = !1)
        }
        constructor(t, s) {
            this.Is = t, this.Be = s;
            const e = Hi((s => t(s, this)), !0);
            this.Is = hs("DocumentMutationObserver:callback", (t => {
                Ms(t, (t => e.push(t)))
            }))
        }
        get shadowRoots() {
            var t, s;
            return null !== (s = null === (t = sn.shadowRootObserver) || void 0 === t ? void 0 : t.shadowRoots) && void 0 !== s ? s : []
        }
        takeRecords() {
            var t;
            const s = null === (t = sn.mutationObserver) || void 0 === t ? void 0 : t.takeRecords(),
                e = sn.shadowRootObserver.takeRecords();
            return (null == s ? void 0 : s.length) && e.length ? function(t, s, e) {
                const i = t.length + s.length + ((null == e ? void 0 : e.length) || 0),
                    n = new csArray(i);
                let r = 0;
                for (let s = 0; s < t.length; s++) n[r++] = t[s];
                for (let t = 0; t < s.length; t++) n[r++] = s[t];
                if (!e) return n;
                for (let t = 0; t < e.length; t++) n[r++] = e[t];
                return n
            }(s, e) : null != s ? s : e
        }
        observe() {
            sn.observe(this.Is, this.Be)
        }
        disconnect() {
            sn.disconnect(this.Is, this.Be)
        }
    }
    sn = nn, nn.callbacks = [], nn.shadowRootCallbacks = [], nn.started = !1, nn.observedTargets = new Set, nn.shadowRootFilters = [], nn.mutationCallback = t => {
        ri.mutations.count.increase(t.length), csArray.prototype.forEach.call(sn.callbacks, (s => s(t, sn.mutationObserver)))
    }, nn.onShadowRoot = (t, s) => {
        Ms(sn.shadowRootCallbacks, (e => e(t, s))), "removed" !== s ? sn.He(t) : sn.disconnectShadowRoot(t)
    }, nn.isRefreshing = !1, Gs([os()], nn.prototype, "observe", null), Gs([os()], nn.prototype, "disconnect", null);
    class rn {
        constructor(t) {
            this.Is = t, this.je = t => {
                t.sheet.ownerNode && ("cssRuleInserted" === t.type ? this.Is({
                    type: t.type,
                    target: t.sheet.ownerNode,
                    rule: t.rule,
                    index: t.index
                }) : "cssRuleDeleted" === t.type ? this.Is({
                    type: t.type,
                    target: t.sheet.ownerNode,
                    index: t.index
                }) : "cssRuleUpdated" === t.type && this.Is({
                    type: t.type,
                    target: t.sheet.ownerNode,
                    rule: t.rule,
                    index: t.index
                }))
            }, this.Is = s => Ni((() => t(s))), this.ze = new ji((t => Ni((async () => {
                await $i(), this.je(t)
            })))), "adoptedStyleSheets" in Document.prototype && (this.Ge = new zi(t))
        }
        observe() {
            var t;
            this.As = new nn((t => this.Ze(t)), ((t, s) => {
                "added" === s && this.We(t)
            })), this.As.observe(), this.ze.observe(), null === (t = this.Ge) || void 0 === t || t.observe()
        }
        disconnect() {
            var t, s;
            null === (t = this.As) || void 0 === t || t.disconnect(), this.ze.disconnect(), null === (s = this.Ge) || void 0 === s || s.disconnect()
        }
        Ze(t) {
            const s = Gi(t);
            for (let t = 0; t < s.length; t++) {
                const e = s[t];
                if (e) switch (e.type) {
                    case "attributes":
                        this.processAttributeChanged(e);
                        break;
                    case "characterData":
                        this.processCharacterDataChanged(e);
                        break;
                    case "childList":
                        this.processChildListChanged(e);
                        break;
                    default:
                        rs.error(`processRawMutations: unknown record type '${e.type}'`)
                } else rs.error("processRawMutations: empty record")
            }
        }
        processAttributeChanged(t) {
            const s = {
                type: "attributeChanged",
                target: t.target,
                attribute: t.attributeName,
                namespace: t.attributeNamespace,
                oldValue: t.oldValue,
                newValue: qi.getAttributeNS(t.target, t.attributeNamespace, t.attributeName)
            };
            this.Is(s)
        }
        processCharacterDataChanged(t) {
            const s = {
                type: "characterDataChanged",
                target: t.target,
                oldValue: t.oldValue,
                newValue: t.target.data
            };
            this.Is(s)
        }
        processChildListChanged(t) {
            var s, e, i;
            if (null === (s = t.removedNodes) || void 0 === s ? void 0 : s.length) {
                const s = {
                    type: "nodesRemoved",
                    target: t.target,
                    nodes: $s(t.removedNodes, (t => t))
                };
                this.Is(s)
            }
            if (null === (e = t.movedNodes) || void 0 === e ? void 0 : e.length) {
                const s = {
                    type: "nodesMoved",
                    target: t.target,
                    nodes: t.movedNodes,
                    previousSibling: t.movedNodes[0].previousSibling || void 0,
                    nextSibling: csNodenextSibling.apply(t.movedNodes[t.movedNodes.length - 1]) || void 0
                };
                this.Is(s)
            }
            if (null === (i = t.addedNodes) || void 0 === i ? void 0 : i.length) {
                const s = [];
                if (Ms(t.addedNodes, (t => {
                        csArray.prototype.push.call(s, t)
                    })), 0 === s.length) return;
                const e = {
                    type: "nodesAdded",
                    target: t.target,
                    previousSibling: t.previousSibling,
                    nextSibling: t.nextSibling,
                    nodes: s
                };
                this.Is(e)
            }
        }
        We(t) {
            const s = {
                type: "shadowRootAttached",
                target: t.host,
                shadowRoot: t
            };
            this.Is(s)
        }
    }
    Gs([os()], rn.prototype, "processAttributeChanged", null), Gs([os()], rn.prototype, "processCharacterDataChanged", null), Gs([os()], rn.prototype, "processChildListChanged", null);
    class on extends Si {
        constructor(t) {
            super(t), this.nodeType = 4, this.data = t.data
        }
    }
    class hn extends Si {
        constructor(t) {
            super(t), this.nodeType = 8, this.data = t.data
        }
    }
    class cn extends Si {
        constructor(t) {
            super(t), this.nodeType = 10, this.name = t.name, this.publicId = t.publicId, this.systemId = t.systemId
        }
    }
    class an extends Si {
        constructor(t) {
            super(t), this.nodeType = 9, this.baseURI = an.getBaseURI(t), this.children = []
        }
        static getBaseURI(t) {
            let s = t.baseURI;
            if (null == s) {
                const e = t.getElementsByTagName("base");
                s = 0 !== e.length ? e[0].href : t.URL
            }
            return s
        }
    }
    class un extends Si {
        constructor(t) {
            super(t), this.nodeType = 11, this.mode = t.mode, this.children = []
        }
    }
    class ln {
        constructor(t, s, e) {
            var i;
            "string" == typeof t ? (this.name = t, this.value = s, this.namespaceURI = null != e ? e : "") : (this.name = t.name, this.value = t.value, this.namespaceURI = null !== (i = t.namespaceURI) && void 0 !== i ? i : "")
        }
        static create(t) {
            var s, e;
            const i = t.attributes,
                n = new csArray(i.length);
            for (let r = 0; r < n.length; r++) {
                const o = i[r];
                n[r] = new ln(o.name, o.value, o.namespaceURI), "href" === o.name && m(t) && (n[r].value = null !== (e = null === (s = t.sheet) || void 0 === s ? void 0 : s.href) && void 0 !== e ? e : o.value)
            }
            return n
        }
    }
    const dn = {
        workTime: 40,
        async: !0,
        initialDOM: !0
    };
    pn();
    let fn = csSymbol("InitialDom");

    function pn(t = dn) {
        return function(s, e) {
            var i;
            null !== (i = t.workTime) && void 0 !== i || (t.workTime = dn.workTime);
            const n = hs("serialize:callback", (t => e(t))),
                r = new us,
                o = (s, e) => {
                    s.hasChildNodes() && r.push({
                        node: s,
                        serializedNode: e
                    });
                    const i = s instanceof Element && csElementshadowRoot.apply(s);
                    if (i) {
                        const s = e.shadowRoot = vn(i);
                        t.async && t.initialDOM && Re.setProperty(i, fn, !0), o(i, s)
                    }
                };
            let h, c = !0,
                a = 8;
            const u = hs("work", (() => {
                var i;
                if (c) h = vn(s), t.async && t.initialDOM && Re.setProperty(s, fn, !0), o(s, h), c = !1;
                else if (r.isEmpty) return;
                const l = function(t) {
                    if (t < 1) throw new Error("Precision should be >= 1");
                    let s = 0,
                        e = performance.now();
                    return {
                        started: e,
                        elapsed() {
                            return ++s % t == 0 && (e = performance.now()), e - this.started
                        }
                    }
                }(100);
                for (; !r.isEmpty;) {
                    if (t.async && l.elapsed() >= t.workTime) return void(--a <= 0 && csSetTimeout(u));
                    const {
                        node: s,
                        serializedNode: e
                    } = r.pop(), n = null !== (i = e.children) && void 0 !== i ? i : [];
                    if (w(s)) continue;
                    let h = 0;
                    for (let e = csNodefirstChild.apply(s); e; e = csNodenextSibling.apply(e)) {
                        const s = vn(e);
                        t.async && t.initialDOM && Re.setProperty(e, fn, !0), n[h++] = s, o(e, s)
                    }
                }
                t.async ? csSetTimeout((() => n(h))) : e(h)
            }));
            if (t.async)
                for (let t = 0; t < a; t++) csSetTimeout(u, 1);
            else t.workTime = 1 / 0, u()
        }
    }
    const mn = ws((function(t) {
        const s = vn(t),
            e = s;
        let i = 0;
        for (let s = csNodefirstChild.apply(t); s; s = csNodenextSibling.apply(s)) e.children[i++] = mn(s);
        const n = t.shadowRoot;
        return n && (e.shadowRoot = mn(n)), s
    }), "serializeSync");

    function vn(t) {
        let s, e;
        switch (t.nodeType) {
            case 1:
                e = s = new Ti(t), s.attributes = function(t) {
                    if (w(t)) return [];
                    return ln.create(t)
                }(t);
                break;
            case 3:
                e = new Ri(t);
                break;
            case 4:
                e = new on(t);
                break;
            case 8:
                e = new hn(t);
                break;
            case 10:
                e = new cn(t);
                break;
            case 9:
                e = new an(t);
                break;
            case 11:
                e = new un(t);
                break;
            default:
                throw new Error("Node type not supported: " + t.nodeType)
        }
        return e
    }
    class gn {
        constructor() {
            this.Qe = [], this.isStarted = !1
        }
        produceEvent(t) {
            this.isStarted && (t.timestamp = Vt.now(), csArray.prototype.forEach.call(this.Qe, (s => s(t))))
        }
        onStop() {}
        start() {
            this.isStarted || (this.isStarted = !0, this.onStart())
        }
        stop() {
            this.isStarted && (this.isStarted = !1, this.onStop(), this.Qe = [])
        }
        subscribe(t) {
            return csArray.prototype.push.call(this.Qe, t), () => {
                const s = csArray.prototype.indexOf.call(this.Qe, t);
                csArray.prototype.splice.call(this.Qe, s, 1)
            }
        }
    }
    const yn = pn();
    class wn extends gn {
        constructor() {
            super(...arguments), this.Je = !1
        }
        onStart() {
            this.Je = !0, this.Is = function(t, s) {
                let e = !1;
                const i = function() {
                    if (!e) return t.apply(s, arguments)
                };
                return i.cancel = () => e = !0, i
            }(this.Ke, this), this.Ye = new rn(this.Is), this.Ye.observe();
            const t = () => {
                this.Je = !1, fn = csSymbol("InitialDom");
                ri.mutations.initialDOM.asyncMeasure()()
            };
            this.produceEvent(new Ii((s => yn(document, (e => {
                t(), s({
                    type: "DomEvent",
                    domEvent: "initialDOM",
                    initialDOM: e
                })
            })))))
        }
        stopForInactivity() {
            this.isStarted && (this.isStarted = !1, this.onStop())
        }
        onStop() {
            var t, s;
            this.Je = !1, null === (t = this.Is) || void 0 === t || t.cancel(), null === (s = this.Ye) || void 0 === s || s.disconnect()
        }
        Xe(t, s) {
            const e = {
                type: "DomEvent",
                domEvent: s.type,
                target: 0,
                targetProps: {}
            };
            return "target" in s && (e.target = be(s.target), e.targetProps = Re.getProperties(s.target)), [s, e]
        }
        Ke(t) {
            if (!this.ti(t)) switch (t.type) {
                case "attributeChanged":
                    {
                        const [s, e] = this.Xe(t.type, t);e.attribute = s.attribute,
                        e.isSvg = E(s.target),
                        e.namespace = s.namespace,
                        e.newValue = s.newValue,
                        e.oldValue = s.oldValue,
                        e.localName = _i(s.target),
                        e.linkRel = f(s.target) ? s.target.rel : null,
                        e.parentLocalName = s.target.parentElement ? _i(s.target.parentElement) : void 0,
                        "input" === e.localName && (e.inputType = s.target.getAttribute("type")),
                        this.produceEvent(e)
                    }
                    break;
                case "characterDataChanged":
                    {
                        const [s, e] = this.Xe(t.type, t);e.newValue = s.newValue,
                        e.oldValue = s.oldValue,
                        e.targetNodeType = s.target.nodeType,
                        e.parentLocalName = s.target.parentElement ? _i(s.target.parentElement) : null,
                        e.parentProps = s.target.parentElement ? Re.getProperties(s.target.parentElement) : void 0,
                        this.produceEvent(e)
                    }
                    break;
                case "nodesAdded":
                    {
                        const [s, e] = this.Xe(t.type, t);e.targetLocalName = l(s.target) ? _i(s.target) : null,
                        e.nextSibling = s.nextSibling ? be(s.nextSibling) : null,
                        e.previousSibling = s.previousSibling ? be(s.previousSibling) : null;
                        const i = ri.mutations.serializedMutations.asyncMeasure(),
                            n = new Ii;csSetTimeout((() => {
                            e.nodes = $s(s.nodes, mn), i(), n.resolve(e)
                        })),
                        this.produceEvent(n);
                        break
                    }
                case "nodesMoved":
                    {
                        const [s, e] = this.Xe(t.type, t);e.previousSibling = s.previousSibling ? be(s.previousSibling) : null,
                        e.nextSibling = s.nextSibling ? be(s.nextSibling) : null,
                        e.nodesIds = $s(s.nodes, be),
                        this.produceEvent(e);
                        break
                    }
                case "nodesRemoved":
                    {
                        const [s, e] = this.Xe(t.type, t);e.nodesIds = $s(s.nodes, be),
                        this.produceEvent(e);
                        break
                    }
                case "shadowRootAttached":
                    {
                        const [s, e] = this.Xe(t.type, t);e.shadowRoot = vn(s.shadowRoot),
                        this.produceEvent(e);
                        break
                    }
                case "cssRuleInserted":
                    {
                        const [s, e] = this.Xe(t.type, t);e.index = s.index,
                        e.rule = s.rule,
                        this.produceEvent(e);
                        break
                    }
                case "cssRuleDeleted":
                    {
                        const [s, e] = this.Xe(t.type, t);e.index = s.index,
                        this.produceEvent(e);
                        break
                    }
                case "cssRuleUpdated":
                    {
                        const [s, e] = this.Xe(t.type, t);e.rule = s.rule,
                        e.index = s.index,
                        this.produceEvent(e);
                        break
                    }
                case "adoptedStyleSheetRegistered":
                    {
                        const [s, e] = this.Xe(t.type, t);e.sheetId = s.sheetId,
                        e.cssRules = s.cssRules,
                        this.produceEvent(e);
                        break
                    }
                case "adoptedStyleSheetsSet":
                    {
                        const [s, e] = this.Xe(t.type, t);e.sheetsIds = s.sheetsIds,
                        this.produceEvent(e);
                        break
                    }
                case "adoptedStyleSheetRuleInserted":
                    {
                        const [s, e] = this.Xe(t.type, t);e.sheetId = s.sheetId,
                        e.rule = s.rule,
                        e.index = s.index,
                        this.produceEvent(e);
                        break
                    }
                case "adoptedStyleSheetRuleDeleted":
                    {
                        const [s, e] = this.Xe(t.type, t);e.sheetId = s.sheetId,
                        e.index = s.index,
                        this.produceEvent(e);
                        break
                    }
                case "adoptedStyleSheetRuleUpdated":
                    {
                        const [s, e] = this.Xe(t.type, t);e.sheetId = s.sheetId,
                        e.rule = s.rule,
                        e.index = s.index,
                        this.produceEvent(e);
                        break
                    }
            }
        }
        si(t) {
            return this.Je && !Re.getProperty(t, fn)
        }
        ti(t) {
            switch (t.type) {
                case "nodesAdded":
                case "nodesMoved":
                case "nodesRemoved":
                case "shadowRootAttached":
                    return this.si(t.target) || $e.isMaskedElement(t.target) || $e.isMaskedElementChild(t.target);
                case "characterDataChanged":
                    {
                        const s = t.target.parentElement;
                        return null !== s && (this.si(s) || $e.isMaskedElement(s) || $e.isMaskedElementChild(s))
                    }
                case "attributeChanged":
                    return this.si(t.target) || $e.isMaskedElementChild(t.target) || $e.isMaskedAttribute(t.target, t.attribute);
                case "cssRuleInserted":
                case "cssRuleDeleted":
                case "cssRuleUpdated":
                    return this.si(t.target) || $e.isMaskedElementChild(t.target);
                default:
                    return !1
            }
        }
    }
    var En, An;
    ! function(t) {
        t.isDOMEvent = function(t) {
            return "DomEvent" === t.type
        }
    }(En || (En = {}));
    class _n {
        constructor() {
            this.Qe = []
        }
        start() {}
        stop() {
            this.Qe.length = 0, this.Qe = []
        }
        pushEvent(t) {
            if (_n.pendingEvents++, this.isListening(t)) {
                const s = this.Qe;
                csSetTimeout((() => {
                    const e = hs("Processor:processEvent", (t => this.processEvent(t))),
                        i = e(t);
                    null != i && csArray.prototype.forEach.call(s, (t => t(i))), _n.pendingEvents--
                }))
            } else csSetTimeout((() => {
                csArray.prototype.forEach.call(this.Qe, (s => s(t)))
            }))
        }
        subscribe(t) {
            return csArray.prototype.push.call(this.Qe, t), () => {
                this.Qe = csArray.prototype.filter.call(this.Qe, (s => s !== t))
            }
        }
        emitEvent(t) {
            Ni((() => csArray.prototype.forEach.call(this.Qe, (s => s(t)))))
        }
    }

    function Sn(t) {
        const s = new ArrayBuffer(t.length),
            e = new Uint8Array(s);
        for (let s = 0, i = t.length; s < i; s += 1) e[s] = csString.prototype.charCodeAt.call(t, s);
        return s
    }

    function Rn(t) {
        const s = new Uint8Array(t);
        let e = "";
        for (let t = 0; t < s.byteLength; t += 1) e += csString.fromCodePoint(s[t]);
        return e
    }

    function Tn(t) {
        return Sn(self.atob(t))
    }

    function In(t) {
        const s = csArray.from(new Uint8Array(t));
        return csArray.prototype.join.call(csArray.prototype.map.call(s, (t => csString.prototype.padStart.call(t.toString(16), 2, "0"))), "")
    }

    function bn(t) {
        const s = -1 !== csString.prototype.indexOf.call(t, ";base64,"),
            e = csString.prototype.indexOf.call(t, ","),
            i = s ? [csString.prototype.substring.call(t, 0, e - 7), csString.prototype.substring.call(t, e + 1)] : [csString.prototype.substring.call(t, 0, e), csString.prototype.substring.call(t, e + 1)];
        if (!s && /^%3Csvg/i.test(i[1])) try {
            i[1] = decodeURIComponent(i[1])
        } catch (t) {
            rs.warn(`${t}, calling decodeURIComponent on: ${i[1]}`)
        }
        const n = s ? Tn(i[1]) : Sn(i[1]);
        return new Blob([n], {
            type: csString.prototype.replace.call(i[0], "data:", "")
        })
    }
    _n.pendingEvents = 0,
        function(t) {
            const s = "replaceAll" in csString.prototype;
            t.ELLIPSIS = "…", t.stringReplaceAll = function(t, e, i) {
                if (s) return csString.prototype.replaceAll.call(t, e, i);
                const n = new csRegExp((r = e, csString.prototype.replace.call(r, /[.*+?^${}()|[\]\\]/g, "\\$&")), "g");
                var r;
                return csString.prototype.replace.call(t, n, i)
            }, t.truncate = function(t, s, e = "") {
                return t.length <= s ? t : csString.prototype.slice.call(t, 0, s - e.length) + e
            }
        }(An || (An = {}));
    class Pn {
        static async toStaticResourceEvent(t, s, e) {
            const i = await Pn.ei(t);
            if (!i) return null;
            const n = await Pn.ii(i),
                r = ui(t) ? void 0 : t,
                o = {
                    type: "StaticResourceManagerEvent",
                    timestamp: e,
                    resourceId: s,
                    resource: {
                        hash: n,
                        data: i
                    }
                };
            return r && (o.originalResourceName = r), o
        }
        static async toCSSStaticResourceEvent(t, s, e, i) {
            const n = await Pn.ni(t, i),
                r = zt(t),
                o = n.get(r);
            if (!o) return null;
            const h = {
                type: "StaticResourceManagerEvent",
                timestamp: e,
                resourceId: s,
                resource: {
                    hash: o.hash,
                    data: o.data
                }
            };
            return n.delete(r), n.size && (h.nestedResources = [], n.forEach((t => {
                t && csArray.prototype.push.call(h.nestedResources, {
                    hash: t.hash,
                    data: t.data
                })
            }))), h
        }
        static async ii(t) {
            const s = await t.arrayBuffer();
            return In(await crypto.subtle.digest(this.oi, s))
        }
        static async ei(t) {
            let s;
            if (ui(t)) {
                const e = bn(t);
                if (!e) return null;
                s = e
            } else {
                const e = await window.fetch(t);
                s = await e.blob()
            }
            return s
        }
        static async ni(t, s) {
            const e = new Map,
                i = [{
                    resourceRawPath: t,
                    resourceAbsolutePath: zt(t)
                }];
            for (; i.length > 0;) {
                const t = csArray.prototype.pop.call(i);
                if (!s && null !== t.resourceAbsolutePath && !ui(t.resourceAbsolutePath)) e.set(t.resourceAbsolutePath, null);
                else if (void 0 === e.get(t.resourceAbsolutePath)) try {
                    if (null === t.resourceRawPath || csString.prototype.indexOf.call(t.resourceRawPath, ".css") > 0) {
                        if (!t.data) {
                            const s = await fetch(t.resourceAbsolutePath);
                            t.data = await s.text()
                        }
                        t.nestedResources || (t.nestedResources = gi(t.data));
                        let s = !1,
                            o = !1;
                        for (const h of t.nestedResources) {
                            const c = ui(h) ? h : t.resourceAbsolutePath ? (n = h, r = t.resourceAbsolutePath, new csURL(n, r).href) : zt(h),
                                a = e.get(c);
                            if (void 0 !== a) {
                                if (null !== a) {
                                    const s = Pn.hi(a, h);
                                    t.data = An.stringReplaceAll(t.data, h, s)
                                }
                                continue
                            }
                            const u = void 0 !== Ds(i, (t => t.resourceAbsolutePath === c));
                            u || (s = !0, o || (csArray.prototype.push.call(i, t), o = !0), csArray.prototype.push.call(i, {
                                resourceRawPath: h,
                                resourceAbsolutePath: c
                            }))
                        }
                        if (!s) {
                            const s = await Pn.ci(t.data);
                            e.set(t.resourceAbsolutePath, {
                                hash: s.hash,
                                data: s.data
                            })
                        }
                    } else {
                        let s;
                        if (ui(t.resourceAbsolutePath)) {
                            const i = bn(t.resourceAbsolutePath);
                            if (!i) {
                                e.set(t.resourceAbsolutePath, null);
                                continue
                            }
                            s = i
                        } else {
                            const e = await fetch(t.resourceAbsolutePath);
                            s = await e.blob()
                        }
                        const i = await Pn.ii(s);
                        e.set(t.resourceAbsolutePath, {
                            hash: i,
                            data: s
                        })
                    }
                } catch {
                    e.set(t.resourceAbsolutePath, null)
                }
            }
            var n, r;
            return e
        }
        static hi(t, s) {
            let e = `cs://resources/${t.hash}`;
            return ui(s) || (e += `?${Pn.ai}=${s}`), e
        }
        static async ci(t) {
            const s = new Blob([t], {
                    type: "text/css"
                }),
                e = await s.arrayBuffer();
            return {
                data: s,
                hash: In(await crypto.subtle.digest(Pn.oi, e))
            }
        }
    }
    Pn.oi = "SHA-256", Pn.ai = "original-resource-name";
    class Vn extends _n {
        constructor() {
            super(), this.ui = "cssrm://", this.li = 0, this.fi = !1
        }
        isListening(t) {
            return !!Vn.isSupported() && (!!En.isDOMEvent(t) && ("initialDOM" === t.domEvent || "nodesAdded" === t.domEvent || "attributeChanged" === t.domEvent || "characterDataChanged" === t.domEvent))
        }
        processEvent(t) {
            switch (t.domEvent) {
                case "initialDOM":
                case "nodesAdded":
                    this.pi(t);
                    break;
                case "attributeChanged":
                    this.mi(t);
                    break;
                case "characterDataChanged":
                    this.gi(t)
            }
            return t
        }
        disableOnlineAssets() {
            this.fi = !1
        }
        enableOnlineAssets() {
            this.fi = !0
        }
        isOnlineAssetsActivated() {
            return this.fi
        }
        pi(t) {
            const s = "initialDOM" === t.domEvent ? [t.initialDOM] : t.nodes;
            for (const t of s) Re.traverse(t, ((t, s) => {
                if (3 === t.nodeType && s) return void this.yi(t, s.localName);
                if (!Ti.isElement(t)) return;
                const e = Ds(t.attributes, (t => "style" === t.name));
                if (e && (e.value = this.wi(e.value)), this.Ei(t) || this.Ai(t, s)) {
                    const s = Ds(t.attributes, (t => "src" === t.name));
                    s && s.value && (s.value = this._i(s.value));
                    const e = Ds(t.attributes, (t => "srcset" === t.name));
                    if (e) return void(e.value = this.Si(e.value))
                }
                if (this.Ri(t) && this.fi) {
                    const s = Ds(t.attributes, (t => "href" === t.name));
                    if (!s || !s.value) return;
                    this.li++, this.Ti(zt(s.value), this.li, !0), this.Ii(t, s, this.li)
                }
            }))
        }
        Ii(t, s, e) {
            csArray.prototype.push.call(t.attributes, {
                name: "data-cs-original-href",
                namespaceURI: "",
                value: s.value
            }), s.value = this.ui + e
        }
        yi(t, s) {
            if (!t || "style" !== s) return;
            const e = this.wi(t.data);
            null !== e && (t.data = e)
        }
        gi(t) {
            if ("style" !== t.parentLocalName || !t.newValue) return;
            const s = this.wi(t.newValue);
            null !== s && (t.newValue = s)
        }
        mi(t) {
            if (!t.newValue || t.newValue === t.oldValue) return;
            const s = "src" === t.attribute,
                e = "srcset" === t.attribute;
            if ("style" === t.attribute) return void(t.newValue = this.wi(t.newValue));
            if (!s && !e) return;
            const i = "img" === t.localName,
                n = "source" === t.localName && t.parentLocalName && "picture" === t.parentLocalName;
            (i || n) && (s && (t.newValue = this._i(t.newValue)), e && (t.newValue = this.Si(t.newValue)))
        }
        _i(t) {
            return ui(t) || this.fi ? (this.li++, this.Ti(t, this.li, !1, Vt.now()), this.ui + this.li) : t
        }
        Si(t) {
            if (!this.fi) return t;
            let s = t;
            const e = fi(t),
                i = Vt.now();
            for (const t of e) this.li++, this.Ti(zt(t), this.li, !1, i), s = csString.prototype.replace.call(s, t, this.ui + this.li);
            return s
        }
        wi(t) {
            const s = gi(t);
            let e = t;
            const i = Vt.now();
            for (const t of s) {
                const s = ui(t);
                if (!s && !this.fi) continue;
                if (this.bi(t)) continue;
                this.li++, e = csString.prototype.replace.call(e, t, this.ui + this.li);
                const n = di(t);
                s ? this.Ti(t, this.li, !1, i) : this.fi && (n ? this.Ti(t, this.li, !0, i) : this.Ti(zt(t), this.li, !1, i))
            }
            return e
        }
        Ti(t, s, e, i = Vt.now()) {
            const n = e ? Pn.toCSSStaticResourceEvent : Pn.toStaticResourceEvent,
                r = new Ii((async e => {
                    try {
                        const r = await n(t, s, i, this.fi);
                        e(r || {
                            type: "warning",
                            message: `Failed to process static resource: ${t}`
                        })
                    } catch (t) {
                        e({
                            type: "warning",
                            message: t
                        })
                    }
                }));
            this.emitEvent(r)
        }
        Ei(t) {
            return "img" === t.localName
        }
        Ai(t, s) {
            return "source" === t.localName && !!s && "picture" === s.localName
        }
        Ri(t) {
            return "link" === t.localName && csArray.prototype.some.call(t.attributes, (t => "rel" === t.name && "stylesheet" === t.value))
        }
        static isSupported() {
            return kt() && function() {
                var t;
                return "undefined" != typeof crypto && _t(null === (t = crypto.subtle) || void 0 === t ? void 0 : t.digest)
            }() && !!csArray.from
        }
        bi(t) {
            return 0 === csString.prototype.replace.call(t, /['"]+/g, "").length
        }
    }
    ai([Es("StaticResourceManagerProcessor.processEvent")], Vn.prototype, "processEvent", null);
    class Cn extends Fe {
        constructor(t, s, e, i, n, r, o, h, c, a, u, l, d, f, p, m = [], v, g, y, w, E, A) {
            super(), this.D = t, this.Pi = s, this.Vi = e, this.Ci = i, this.ki = n, this.Oi = r, this.Y = o, this.Ni = h, this.xi = c, this.$i = a, this.Li = u, this.Mi = l, this.Di = d, this.Ui = f, this.qi = p, this.Fi = m, this.Hi = v, this.Bi = g, this.ji = y, this.zi = w, this.Gi = E, this.Zi = A, this.Wi = 0, this.Qi = new qe, this.Ji = {
                allowFromQuotaService: !0,
                allowFromSerialization: !0
            }, this.Ki = le((() => {
                this.Pi.eventsCount() > 0 && this.Yi()
            }), 2e3), this.Xi = t => this.processBrowserEvent(t), this.tn = t => this.en(t), this.nn = 0, this.rn = 0, this.hn = new We, this.cn = !1, this.an = 51200, this.un = !1, this.ln = !1, this.dn = [], this.fn = new ci((t => this.mn(t)), (t => {
                switch (t) {
                    case hi.Active:
                        this.Hi.start(), this.Bi.start();
                        break;
                    case hi.Stopped:
                        this.Hi.stopForInactivity(), this.Bi.stop()
                }
            }), [fe.RESOURCE_HASHES]), this.vn = t => {
                this.Di.removeBatchInProgress(`${t.params.sn}.${t.params.pn}.${t.params.ri}`)
            }
        }
        init() {
            this.gn(), this.Mi.onLoad(this.vn), this.Mi.onError(this.vn)
        }
        gn() {
            var t, s, e;
            this.qi.onEvent(this.Xi, this.tn), this.ki.onEvent(this.tn), null === (t = this.Li) || void 0 === t || t.onInputNodeToEncrypt(this.tn), null === (s = this.Li) || void 0 === s || s.onApiErrorToEncrypt((t => {
                this.yn(t)
            })), null === (e = this.Li) || void 0 === e || e.onUserIdentifierToEncrypt(this.Xi), this.hn.onEvent((t => t === Ge.Blur ? this.wn() : this.cn ? void 0 : (this.cn = !0, csSetTimeout((() => {
                this.cn = !1
            })), t === Ge.Hidden ? this.wn() : this.En())))
        }
        isRecording() {
            return this.Y.hasValidSession() && this.isStarted
        }
        wn() {
            if (!this.canSendEvents()) return;
            this.qi.flush(), this.Di.saveBatchesInProgress(), Ms(this.Fi, (t => {
                var s, e;
                return Ms(null !== (e = null === (s = t.getPendingEvents) || void 0 === s ? void 0 : s.call(t)) && void 0 !== e ? e : [], (t => this.Pi.addEvent(t)))
            }));
            const t = this.Pi.getEvents();
            if (0 === t.length) return;
            this.Pi.addEvent({
                date: Vt.now(),
                type: fe.RECORDING_INFO_EVENT,
                args: ["pendingEvents", this.qi.pendingEvents]
            });
            const s = this.Mi.getQueryParams();
            s.rst = this.getRecordingStartTimestamp(), s.let = this.getRecordingLastEventTimestamp();
            const e = this.Ci.getCurrentIndex();
            s.ri = e.toString(), this.Ui.removeQueryParams(), this.Ui.setQueryParams(s), this.rn = t[t.length - 1].date;
            const i = this.Pi.stringifyEvents();
            if (i.length > this.an) {
                const t = this.An();
                if (t.length > 0) {
                    const e = W(t);
                    this.Ui.send(e) || this.Di.save({
                        key: `${s.sn}.${s.pn}.${s.ri}.last`,
                        metadata: { ...s,
                            datatype: "json"
                        },
                        events: e
                    }), this.Ci.increment()
                }
                if (this.Pi.eventsCount() > 0) {
                    s.ri = this.Ci.getCurrentIndex().toString();
                    const t = this.Pi.stringifyEvents();
                    this.Di.save({
                        key: `${s.sn}.${s.pn}.${s.ri}.last`,
                        metadata: { ...s,
                            datatype: "json"
                        },
                        events: t
                    }), this.Ci.increment()
                }
            } else {
                this.Ui.send(i) || this.Di.save({
                    key: `${s.sn}.${s.pn}.${s.ri}.last`,
                    metadata: { ...s,
                        datatype: "json"
                    },
                    events: i
                }), this.Ci.increment()
            }
            this.Ui.removeQueryParams(), this.Pi.clearEvents()
        }
        En() {
            if (!this.canSendEvents()) return;
            this.qi.flush();
            const t = this.Mi.getQueryParams();
            this.Di.saveBatchesInProgress(), t.rst = this.getRecordingStartTimestamp(), delete t.ri, t.hlm = "true", this.Ui.removeQueryParams(), Ms(this.Fi, (t => {
                var s, e;
                return Ms(null !== (e = null === (s = t.getPendingEvents) || void 0 === s ? void 0 : s.call(t)) && void 0 !== e ? e : [], (t => this.Pi.addEvent(t)))
            }));
            const s = this.Pi.getEvents();
            if (0 === s.length) return delete t.let, delete t.rst, this.Ui.setQueryParams(t), this.Ui.send(), void this.Ui.removeQueryParams();
            this.Pi.addEvent({
                date: Vt.now(),
                type: fe.RECORDING_INFO_EVENT,
                args: ["pendingEvents", this.qi.pendingEvents]
            }), this.rn = s[s.length - 1].date, t.let = this.getRecordingLastEventTimestamp(), this.Ui.setQueryParams(t);
            const e = this.Pi.stringifyEvents();
            if (e.length > this.an) {
                const s = this.An();
                if (s.length > 0) {
                    const e = W(s);
                    this.Ui.send(e) || this.Di.save({
                        key: `${t.sn}.${t.pn}.last`,
                        metadata: { ...t,
                            datatype: "json"
                        },
                        events: e
                    })
                } else delete t.let, delete t.rst, delete t.ri, this.Ui.removeQueryParams(), this.Ui.setQueryParams(t), this.Ui.send(), this.Ui.removeQueryParams();
                if (this.Pi.eventsCount() > 0) {
                    t.rst = this.getRecordingStartTimestamp(), t.let = this.getRecordingLastEventTimestamp();
                    const s = this.Ci.getCurrentIndex();
                    t.ri = s.toString();
                    const e = this.Pi.stringifyEvents();
                    this.Di.save({
                        key: `${t.sn}.${t.pn}.${t.ri}.last`,
                        metadata: { ...t,
                            datatype: "json"
                        },
                        events: e
                    }), this.Ci.increment()
                }
            } else {
                this.Ui.send(e) || (this.Di.save({
                    key: `${t.sn}.${t.pn}.${t.ri}.last`,
                    metadata: { ...t,
                        datatype: "json"
                    },
                    events: e
                }), this.Ci.increment())
            }
            this.Ui.removeQueryParams(), this.Pi.clearEvents()
        }
        blockSendingEventsFromQuotaService() {
            this.Ji.allowFromQuotaService = !1
        }
        allowSendingEventsFromQuotaService() {
            this.Ji.allowFromQuotaService = !0
        }
        blockSendingEventsFromSerialization() {
            this.Ji.allowFromSerialization = !1
        }
        allowSendingEventsFromSerialization() {
            this.Ji.allowFromSerialization = !0
        }
        canSendEvents() {
            return this.Ji.allowFromQuotaService && this.Ji.allowFromSerialization
        }
        onIframeJavascriptError(t) {
            var s;
            if (this.Ni && this.Gi) {
                null === (s = this.Ni) || void 0 === s || s.anonymize(t);
                const e = this.Gi.translate({
                    message: t.message,
                    colno: t.colno,
                    lineno: t.lineno,
                    filename: t.filename,
                    timestamp: Vt.now(),
                    type: "JSError"
                });
                e && this.Xi(e)
            }
        }
        onIframeCustomError(t) {
            if (this.Zi) {
                const s = this.Zi.translate({ ...t,
                    timestamp: Vt.now(),
                    type: "CustomError"
                });
                s && this.Xi(s)
            }
        }
        onIframeDetailedApiError(t) {
            this._n(t)
        }
        onIframeRecordingUserEvent(t) {
            for (const s of t) this.en(s)
        }
        onIframeRecordingBrowserEvent(t) {
            if (this.isStarted)
                for (const s of t) this.processBrowserEvent(s)
        }
        processBrowserEvent(t) {
            this.Oi.isCurrentPageviewValid() && this.fn.pushEvent(t, {
                isUserEvent: !1
            })
        }
        en(t) {
            this.Oi.refreshSession(), this.Oi.isSessionValid() && this.fn.pushEvent(t, {
                isUserEvent: !0
            })
        }
        mn(t) {
            ri.general.nbEvents.increase(), this.Pi.addEvent(t);
            this.Pi.isThresholdReached() ? this.pushEvents() : this.Pi.isFull() && this.Ki(), this.Sn(t)
        }
        Sn(t) {
            this.D.emitDebugEvents && this.Qi.emit("recordingEvent", { ...t,
                typeName: fe[t.type]
            })
        }
        onStart() {
            this.fn.reset(), this.hn.start(), this.initStates(), this.qi.start(), this.xi && this.$i && this.xi.subscribe(Cn.Rn, (t => this._n(t)), {
                detailedEvent: !0
            }), this.D.emitDebugEvents && this.Qi.emit("replayRecordingStarted"), csArray.prototype.forEach.call(this.dn, (t => this.Tn(t))), this.dn = []
        }
        onStop() {
            var t;
            this.fn.disconnect(), this.hn.stop(), this.ki.stop(), this.xi && this.xi.unsubscribe(Cn.Rn), this.qi.stop(), this.ln = !1, null === (t = this.ji) || void 0 === t || t.disableOnlineAssets()
        }
        clearStates() {
            this.qi.flush(), this.Ki.cancel(), this.pushEvents(), this.Mi.removeQueryParams()
        }
        initStates() {
            this.nn = Vt.now(), this.Ci.reset(), this.Wi = 0, this.Mi.setQueryParams(this.Vi.getRequestParameters())
        }
        pushEvents() {
            Ms(this.Fi, (t => {
                var s;
                return null === (s = t.flushEvents) || void 0 === s ? void 0 : s.call(t)
            })), this.Pi.eventsCount() > 0 && (this.isStarted ? this.Yi() : this.Pi.clearEvents())
        }
        Yi() {
            if (!this.canSendEvents()) return;
            const t = this.Pi.getEvents();
            this.rn = t[t.length - 1].date;
            const s = this.Ci.getCurrentIndex();
            this.Mi.setQueryParams({
                ri: s.toString(),
                rst: this.getRecordingStartTimestamp(),
                let: this.getRecordingLastEventTimestamp()
            });
            const e = this.Mi.getQueryParams();
            this.Di.addBatchInProgress(`${e.sn}.${e.pn}.${s}`, this.Mi.getQueryParams(), t), this.Mi.send(t), this.Ci.increment(), this.Pi.clearEvents(), this.In && this.In()
        }
        addInitialDom(t) {
            this.Pi.addEventByTimestamp(t), this.Sn(t)
        }
        _n(t) {
            if (this.zi && (t.plainCustomRequestHeaders || t.plainCustomResponseHeaders || t.requestBodyAttributes || t.responseBodyAttributes || t.customRequestHeaders || t.customResponseHeaders || t.queryParameters || t.requestBody || t.responseBody)) {
                if (this.zi.truncate(t), this.Li) return void this.Li.registerApiErrorToEncrypt(t);
                t.customRequestHeaders = "", t.customResponseHeaders = "", t.requestBodyAttributes = "", t.responseBodyAttributes = "", t.queryParameters = "", t.requestBody = "", t.responseBody = ""
            }
            this.yn(t)
        }
        yn(t) {
            if (this.Wi < Cn.bn) {
                const s = {
                    type: fe.API_ERROR,
                    date: Vt.now(),
                    args: [this.$i.anonymize(t)]
                };
                this.Xi(s), this.Wi = this.Wi + 1
            }
        }
        Pn(t) {
            t === je.ETR_SESSION ? this.Mi.setQueryParams({
                [Cn.Vn]: Cn.Cn
            }) : t === je.ETR_PAGE && this.Mi.setQueryParams({
                [Cn.kn]: Cn.Cn
            })
        }
        clearEvents() {
            this.Pi.clearEvents()
        }
        onCustomJavaScriptErrorEvent(t) {
            var s;
            const e = null === (s = this.Gi) || void 0 === s ? void 0 : s.translate({
                type: "JSError",
                timestamp: Vt.now(),
                message: t.message,
                colno: t.colno,
                lineno: t.lineno,
                filename: t.filename
            });
            e && this.Xi(e)
        }
        onCustomErrorEvent(t) {
            var s;
            const e = null === (s = this.Zi) || void 0 === s ? void 0 : s.translate({
                type: "CustomError",
                timestamp: Vt.now(),
                message: t.message,
                attributes: t.attributes
            });
            e && this.Xi(e)
        }
        onPageEvent(t) {
            this.On(t)
        }
        onUserIdentifierEvent(t) {
            var s;
            const e = {
                userIdentifier: t,
                date: Vt.now(),
                keyId: this.D.encryptionPublicKeyId
            };
            null === (s = this.Li) || void 0 === s || s.registerUserIdentifierToEncrypt(e)
        }
        onEventTriggerRecording(t, s) {
            this.isStarted ? this.Tn({
                eventName: t,
                eventType: s
            }) : csArray.prototype.push.call(this.dn, {
                eventName: t,
                eventType: s
            })
        }
        Tn(t) {
            this.Pn(t.eventType), this.On(t.eventName), this.pushEvents()
        }
        On(t) {
            const s = {
                type: fe.PAGE_EVENT,
                date: Vt.now(),
                args: [{
                    eventName: csString.prototype.slice.call(t, 0, Cn.Nn)
                }]
            };
            this.Pi.addEvent(s)
        }
        triggerUnanonymizationConsentGranted() {
            const t = {
                date: Vt.now(),
                type: fe.UNANONYMIZED_CONSENT_GRANTED
            };
            this.Pi.addEvent(t)
        }
        triggerUnanonymizationConsentWithdrawn() {
            const t = {
                date: Vt.now(),
                type: fe.UNANONYMIZED_CONSENT_WITHDRAWN
            };
            this.Pi.addEvent(t)
        }
        triggerRecordingForSessionGranted() {
            const t = {
                date: Vt.now(),
                type: fe.RECORDING_INFO_EVENT,
                args: [pe.RECORDING_CONSENT_FOR_SESSION_GRANTED]
            };
            this.Pi.addEvent(t)
        }
        triggerRecordingForSessionWithdrawn() {
            const t = {
                date: Vt.now(),
                type: fe.RECORDING_INFO_EVENT,
                args: [pe.RECORDING_CONSENT_FOR_SESSION_WITHDRAWN]
            };
            this.Pi.addEvent(t)
        }
        activateOnlineAssetsOnNextPageview() {
            this.un = !0, this.ln = !0
        }
        getStaticResourceManagerStatus() {
            return this.ji ? {
                isStarted: this.D.useStaticResourceManager && Vn.isSupported(),
                onlineAssets: {
                    activated: this.ji.isOnlineAssetsActivated(),
                    enabledOnNextPageview: this.un,
                    enabledForChildrenOnNextStart: this.ln
                }
            } : null
        }
        updateStaticResourceManagerOnlineAssets() {
            this.ji && this.un && (this.ji.enableOnlineAssets(), this.ln = !0, this.un = !1)
        }
        onRecordingRequestSent(t) {
            this.In = t
        }
        getRecordingStartTimestamp() {
            return this.nn.toString()
        }
        getRecordingLastEventTimestamp() {
            return this.rn.toString()
        }
        onOptOut() {
            Ms(this.Fi, (t => {
                var s;
                return null === (s = t.releaseResources) || void 0 === s ? void 0 : s.call(t)
            }))
        }
        An() {
            return this.Pi.extractEvents(fe.API_ERROR, fe.JAVASCRIPT_ERROR, fe.CUSTOM_ERROR, fe.TEXT_VISIBILITY, fe.POINTER_DOWN)
        }
    }
    Cn.Rn = "RecordingService", Cn.Nn = 255, Cn.bn = 20, Cn.kn = "etrp", Cn.Vn = "etrs", Cn.Cn = "1", As([Es("addInitialDom")], Cn.prototype, "addInitialDom", null);
    class kn extends Fe {
        constructor(t, s, e) {
            super(), this.ss = t, this.Ui = s, this.Mi = e, this.xn = !1, this.$n = {}, this.Ln = t => {
                if (0 !== t.length)
                    for (const s of t) {
                        const {
                            metadata: t,
                            events: e
                        } = s;
                        this.Mn(t.rt) && this.Mi.send(e, t)
                    }
            }, window.addEventListener("focus", (() => {
                this.recover()
            }))
        }
        onStart() {
            this.$n = {}
        }
        onStop() {}
        recover() {
            this.ss.recover(this.Ln)
        }
        addBatchInProgress(t, s, e) {
            this.$n[t] = {
                metadata: { ...s
                },
                events: e
            }
        }
        removeBatchInProgress(t) {
            delete this.$n[t]
        }
        blockSendingLastMessage() {
            this.xn = !1
        }
        allowSendingLastMessage() {
            this.xn = !0
        }
        sendLastMessageBeacon() {
            if (this.xn) {
                const {
                    ri: t,
                    rst: s,
                    let: e,
                    ...i
                } = this.Mi.getQueryParams();
                i.hlm = "true", this.Ui.setQueryParams(i), this.Ui.send()
            }
        }
        Mn(t) {
            return !!t && -1 === csString.prototype.indexOf.call(t, He.RECORDING_TEMPORARILY)
        }
        saveBatchesInProgress() {
            csArray.prototype.forEach.call(Object.keys(this.$n), (t => {
                const {
                    metadata: s,
                    events: e
                } = this.$n[t];
                this.ss.save({
                    key: `${s.sn}.${s.pn}.${s.ri}`,
                    metadata: { ...s,
                        datatype: "json"
                    },
                    events: csJSON.stringify(e)
                })
            }))
        }
        save(t) {
            this.ss.save(t)
        }
    }
    As([os("RecordingRecovery")], kn.prototype, "recover", null);
    class On {
        constructor(...t) {
            this.Dn = t
        }
        addProvider(t) {
            csArray.prototype.push.call(this.Dn, t)
        }
        getRequestParameters() {
            return csArray.prototype.reduce.call(this.Dn, ((t, s) => ({ ...s.getRequestParameters(),
                ...t
            })), {})
        }
    }
    class Nn {
        constructor(t, s) {
            this.Un = t, this.U = s, this.qn = [{
                boundElement: window,
                type: "hashchange",
                listener: () => this.hashChangeListener()
            }, {
                boundElement: document,
                type: "visibilitychange",
                listener: () => this.visibilityChangeListener()
            }]
        }
        onEvent(t) {
            this.Fn = t
        }
        start() {
            this.$s(), this.triggerInitialEvents()
        }
        stop() {
            this.Ls()
        }
        $s() {
            csArray.prototype.forEach.call(this.qn, (t => ce(t)))
        }
        Ls() {
            csArray.prototype.forEach.call(this.qn, (t => ae(t)))
        }
        triggerInitialEvents() {
            this.hashChangeListener()
        }
        hashChangeListener() {
            const t = {
                type: fe.HASH_CHANGE,
                args: [this.U.anonymizePII(this.Un.href)],
                date: Vt.now()
            };
            this.Fn(t)
        }
        visibilityChangeListener() {
            const t = {
                type: fe.VISIBILITY_CHANGE,
                args: [document.visibilityState],
                date: Vt.now()
            };
            this.Fn(t)
        }
    }
    As([os("hashChange")], Nn.prototype, "hashChangeListener", null), As([os("visibilityChange")], Nn.prototype, "visibilityChangeListener", null);
    var xn;
    class $n {
        constructor(t) {
            this.Is = t
        }
        observe() {
            if (this.Hn = xn.Bn.subscribe((t => this.Is(t))), !xn.jn) {
                xn.jn = !0, xn.zn.observe();
                Qs(document, NodeFilter.SHOW_ELEMENT).visitAll((t => {
                    xn.Gn.add(t), xn.Bn.next(t)
                }))
            }
        }
        disconnect() {
            xn.jn && (this.Hn(), xn.Bn.hasObservers() || (xn.jn = !1, xn.zn.disconnect(), xn.Bn.clear(), xn.Gn.clear()))
        }
    }
    xn = $n, $n.Gn = Fi(), $n.Bn = new class {
        constructor(t = Number.POSITIVE_INFINITY) {
            this.Zn = [], this.Ee = [], this.Wn = t
        }
        next(t) {
            this.Ee.length === this.Wn && csArray.prototype.shift.call(this.Ee), csArray.prototype.push.call(this.Ee, t), 1 === this.Ee.length && csSetTimeout((() => this.clear()));
            for (const s of this.Zn) s(t)
        }
        subscribe(t) {
            if (Ds(this.Zn, (s => t === s))) return () => {
                this.Zn = csArray.prototype.filter.call(this.Zn, (s => s !== t))
            };
            csArray.prototype.push.call(this.Zn, t);
            for (const s of this.Ee) t(s);
            return () => {
                this.Zn = csArray.prototype.filter.call(this.Zn, (s => s !== t))
            }
        }
        clear() {
            this.Ee = []
        }
        hasObservers() {
            return this.Zn.length > 0
        }
    }, $n.Qn = ws((t => {
        Ni((() => {
            for (const s of t) "childList" === s.type && Ms(s.addedNodes, (t => {
                Qs(t, NodeFilter.SHOW_ELEMENT).visitAll((t => {
                    xn.Gn.has(t) || (xn.Gn.add(t), xn.Bn.next(t))
                }))
            }))
        }))
    }), "ElementObserver.findAllElements"), $n.jn = !1, $n.zn = new nn(xn.Qn), Gs([os()], $n.prototype, "observe", null), Gs([os()], $n.prototype, "disconnect", null);
    class Ln {
        constructor(t, s = 30, e = 0) {
            this.Jn = t, this.Kn = s, this.Yn = e, this.Xn = new us, this.tt = !1, this.tr = 0, this.er = () => {
                for (this.tr = 0; this.Xn.length;) {
                    if (this.tr >= this.Kn) return void csSetTimeout(this.er, this.Yn);
                    const t = Vt.elapsed(),
                        s = this.Xn.pop();
                    if (!s) break;
                    this.runTask(s);
                    const e = Vt.elapsed() - t;
                    this.tr += e
                }
                this.tt = !1
            }
        }
        schedule(t, s = !1) {
            this.Jn && !s ? (ri.general.pendingTasks.increase(), this.Xn.push(t), this.ir()) : t()
        }
        ir() {
            this.tt || (this.tt = !0, csSetTimeout((() => {
                this.er()
            })))
        }
        runTask(t) {
            ri.general.pendingTasks.decrease(), t()
        }
        runPendingTasks() {
            this.Xn.forEach((t => {
                this.runTask(t)
            })), this.Xn.clear()
        }
        clearQueue() {
            ri.general.pendingTasks.clear(), ri.mutations.pendingMutations.clear(), this.Xn.clear()
        }
        isEmpty() {
            return 0 === this.Xn.length
        }
    }
    As([os("TaskScheduler"), Es("runTask")], Ln.prototype, "runTask", null), As([Es("runPendingTasks")], Ln.prototype, "runPendingTasks", null);
    const Mn = {
        async: !0
    };
    class Dn {
        constructor(t = Mn) {
            this.nr = t, this.Es = !1, this.rr = new ji((t => "cssRuleInserted" === t.type && this.onStyleSheetChange(t))), this.hr = Hi((t => {
                this.Es && Ms(t, (t => this.cr.schedule((() => this.ar(t)))))
            })), this.ur = new $n((t => this.lr(t))), this.As = new nn((t => this.pr(t))), t.async && (this.cr = new Ln(!0, 30, 0))
        }
        onStyleSheetChange(t) {
            t.rule && this.Es && this.mr(t.rule)
        }
        start() {
            this.Es || (this.Es = !0, this.rr.observe(), this.ur.observe(), this.As.observe())
        }
        stop() {
            this.Es && (this.rr.disconnect(), this.ur.disconnect(), this.As.disconnect(), this.Es = !1)
        }
        onEvent(t) {
            this.Fn = t
        }
        onAsset(t) {
            this.vr = t
        }
        onStyleSheetFound(t) {
            this.gr = t
        }
        yr(t) {
            d(t) && csNodeparentNode.apply(t) && v(csNodeparentNode.apply(t)) && this.mr(t.data)
        }
        mr(t) {
            this.wr(gi(t))
        }
        lr(t) {
            this.Es && $e.getMaskedElementDetails(t).state === $e.MaskedElementState.NotMasked && (this.nr.async ? this.hr.push(t) : this.ar(t))
        }
        ar(t, s) {
            $e.getMaskedElementDetails(t).state !== $e.MaskedElementState.NotMasked || s && $e.isMaskedAttribute(t, s) || (v(t) ? this.Er(t) : this.Ar(t, s) || (this._r(t, s), this.Sr(t, s), this.Rr(t, s)))
        }
        Ar(t, s) {
            var e, i, n;
            if (m(t) && (!s || "href" === s) && t.href) {
                const s = (null === (e = t.sheet) || void 0 === e ? void 0 : e.href) || t.href,
                    r = {
                        assetId: s,
                        assetBasePath: window.location.href,
                        assetRawPath: t.getAttribute("href")
                    };
                return null === (i = this.gr) || void 0 === i || i.call(this, r), null === (n = this.vr) || void 0 === n || n.call(this, r), this.Tr(s), !0
            }
            return !1
        }
        Er(t) {
            var s;
            const e = new Set;
            for (let s = 0; s < csNodechildNodes.apply(t).length; s++) {
                const i = csNodechildNodes.apply(t)[s];
                if (3 === i.nodeType)
                    for (const t of gi(i.data)) e.add(t)
            }
            let i;
            try {
                i = null === (s = t.sheet) || void 0 === s ? void 0 : s.cssRules
            } catch (t) {
                "SecurityError" === t.name || "InvalidAccessError" === t.name || ns.error(t.message)
            }
            if (i)
                for (let t = 0; t < i.length; t++) {
                    const s = i.item(t).cssText;
                    for (const t of gi(s)) e.add(t)
                }
            this.wr(Hs(e))
        }
        Ir(t) {
            return !this.br(t) && !ui(t) && !li(t)
        }
        _r(t, s) {
            var e, i;
            if (l(i = t) && "img" === i.localName) {
                if (!s || "src" === s) {
                    const s = t.getAttribute("src");
                    s && this.Ir(s) && (this.Tr(t.src), null === (e = this.vr) || void 0 === e || e.call(this, {
                        assetId: t.src,
                        assetRawPath: s,
                        assetBasePath: window.location.href
                    }))
                }
                s && "srcset" !== s || !t.srcset || this.Pr(t.srcset)
            }
        }
        Sr(t, s) {
            if (1 === t.nodeType) {
                if (t.hasAttribute && (!s || "style" === s) && t.hasAttribute("style")) {
                    const s = t.getAttribute("style");
                    if ("string" != typeof s) throw new Error("Unexpected style: " + t.outerHTML);
                    this.mr(s)
                }
            } else rs.warn(`StaticResourceUrlTracker: Wrong element nodeType: ${null==t?void 0:t.nodeName}/${t.nodeType}`)
        }
        Pr(t) {
            this.wr(fi(t))
        }
        Rr(t, s) {
            var e, i;
            if ((E(i = t) && "image" === i.localName || function(t) {
                    return E(t) && "use" === t.localName
                }(t) || function(t) {
                    return E(t) && "feImage" === t.localName
                }(t)) && (!s || "href" === s || "xlink:href" === s)) {
                const s = t.getAttribute("href") || t.getAttribute("xlink:href");
                if (s && this.Ir(s)) {
                    const t = zt(s);
                    this.Tr(t), null === (e = this.vr) || void 0 === e || e.call(this, {
                        assetId: t,
                        assetRawPath: s,
                        assetBasePath: window.location.href
                    })
                }
            }
        }
        wr(t) {
            return csArray.prototype.forEach.call(csArray.prototype.map.call(csArray.prototype.filter.call(csArray.prototype.filter.call(csArray.prototype.filter.call(t, (t => !this.br(t))), (t => !ui(t))), (t => !li(t))), (t => ({
                rawUrl: t,
                absoluteUrl: zt(t)
            }))), (t => {
                var s;
                this.Fn && this.Tr(t.absoluteUrl), null === (s = this.vr) || void 0 === s || s.call(this, {
                    assetId: t.absoluteUrl,
                    assetBasePath: window.location.href,
                    assetRawPath: t.rawUrl
                })
            }))
        }
        pr(t) {
            const s = this.nr.async ? csSetTimeout : t => t();
            s((() => {
                for (const s of t) switch (s.type) {
                    case "attributes":
                        this.ar(s.target, s.attributeName);
                        break;
                    case "characterData":
                        this.yr(s.target)
                }
            }))
        }
        Tr(t) {
            var s;
            const e = {
                date: Vt.now(),
                type: fe.STATIC_RESOURCE_URL,
                args: [t]
            };
            null === (s = this.Fn) || void 0 === s || s.call(this, e)
        }
        br(t) {
            return /^https:\/\/\w+:\w+@/.test(t)
        }
    }
    class Un {
        constructor(t) {
            this.Vr = [], this.Cr = [], this.Gt = {}, this.Zt = t
        }
        setQueryParams(t) {
            csArray.prototype.forEach.call(Object.keys(t), (s => {
                this.Gt[s] = t[s]
            }))
        }
        removeQueryParams(t) {
            t ? csArray.prototype.forEach.call(t, (t => {
                delete this.Gt[t]
            })) : this.Gt = {}
        }
        onBeaconSuccess(t) {
            csArray.prototype.push.call(this.Vr, t)
        }
        onBeaconFailure(t) {
            csArray.prototype.push.call(this.Cr, t)
        }
        send(t) {
            const s = Y.toQuery({ ...this.Gt,
                    ct: Os.UNCOMPRESSED
                }),
                e = this.kr(s, t);
            return e ? csArray.prototype.forEach.call(this.Vr, (t => t())) : csArray.prototype.forEach.call(this.Cr, (t => t(this.Gt))), e
        }
        kr(t, s) {
            try {
                if ("function" != typeof csNavigatorsendBeacon) return !1;
                const e = csNavigatorsendBeacon(`${this.Zt}?${t}`, s || "");
                if (e) return e
            } catch {}
            return "function" == typeof navigator.sendBeacon && navigator.sendBeacon(`${this.Zt}?${t}`, s || "")
        }
    }
    class qn {
        constructor(t) {
            this.Or = {}, this.Nr = new Me(t)
        }
        save({
            key: t,
            metadata: s,
            events: e
        }) {
            this.Nr.isThresholdReached() || (this.Nr.addString(t), "string" == typeof e ? this.Nr.addString(e) : this.Nr.addArrayBuffer(e), this.Nr.isThresholdReached() || (this.Or[t] = {
                metadata: s,
                events: e
            }))
        }
        recover(t) {
            const s = [];
            csArray.prototype.forEach.call(this.$r(), (t => {
                const e = this.Or[t];
                void 0 !== e && (delete e.metadata.datatype, csArray.prototype.push.call(s, e), this.Lr(t))
            })), 0 !== s.length && (t(s), this.Nr.reset())
        }
        $r() {
            return Object.keys(this.Or)
        }
        Lr(t) {
            delete this.Or[t]
        }
    }
    var Fn;
    ! function(t) {
        t[t.NOT_STARTED = 0] = "NOT_STARTED", t[t.OPEN_IN_PROGRESS = 1] = "OPEN_IN_PROGRESS", t[t.OPEN_FAILED = 2] = "OPEN_FAILED", t[t.READY = 3] = "READY"
    }(Fn || (Fn = {}));
    class Hn {
        constructor(t, s, e) {
            this.Mr = t, this.Dr = e, this.Ur = Fn.NOT_STARTED, this.qr = [], this.Fr = 0, this.Hr = self.origin, this.Br = "object" == typeof window ? "" : "worker-", this.Nr = new Me(s), this.jr()
        }
        async jr() {
            await this.zr(), this.Ur === Fn.READY ? this.Gr() : this.Dr(this.qr)
        }
        Gr() {
            csArray.prototype.forEach.call(this.qr, (t => {
                this.save(t)
            })), this.qr = []
        }
        async save(t) {
            try {
                if (this.Ur === Fn.OPEN_IN_PROGRESS) return void csArray.prototype.push.call(this.qr, t);
                if (this.Ur !== Fn.READY) return;
                if (this.Nr.isThresholdReached()) return;
                const {
                    key: s,
                    metadata: e,
                    events: i
                } = t;
                if (this.Nr.addString(s), "string" == typeof i ? this.Nr.addString(i) : this.Nr.addArrayBuffer(i), this.Nr.isThresholdReached()) return;
                await this.Zr.put(`${this.Hr}/${s}`, new Response(i, {
                    headers: e
                }))
            } catch {}
        }
        async recover(t) {
            (this.Zr || (await this.zr(), this.Ur === Fn.READY)) && this.Wr(t)
        }
        async zr() {
            try {
                this.Ur = Fn.OPEN_IN_PROGRESS, this.Zr = await self.caches.open(`${this.Br}${this.Mr}`), this.Ur = Fn.READY
            } catch {
                this.Ur = Fn.OPEN_FAILED
            }
        }
        async Wr(t) {
            try {
                if (this.Fr++, this.Fr > 1) return;
                const s = await this.Zr.keys();
                if (0 === s.length) return;
                const e = await this.Zr.matchAll(),
                    i = csArray.prototype.map.call(e, (t => {
                        const s = {};
                        t.headers.forEach(((t, e) => {
                            s[e] = t
                        })), delete s["content-type"];
                        const e = s.datatype;
                        return delete s.datatype, "json" === e || "base64" === e ? t.text().then((t => ({
                            metadata: s,
                            events: t
                        }))) : t.arrayBuffer().then((t => ({
                            metadata: s,
                            events: t
                        })))
                    })),
                    n = await Promise.all(i);
                await Promise.all(csArray.prototype.map.call(s, (t => this.Zr.delete(t)))), t(n), this.Nr.reset()
            } catch {} finally {
                this.Fr--
            }
        }
    }
    class Bn {
        constructor(t) {
            try {
                this.Qr(t)
            } catch (t) {
                this.Jr()
            }
        }
        Qr(t) {
            self.caches ? this.Kr(t) : this.Jr()
        }
        save(t) {
            this.Yr.save(t)
        }
        recover(t) {
            this.Yr.recover(t)
        }
        Kr(t) {
            this.Yr = new Hn(t, Bn.Xr, (t => {
                this.Jr(t)
            }))
        }
        Jr(t) {
            this.Yr = new qn(Bn.Xr), t && csArray.prototype.forEach.call(t, (t => {
                this.Yr.save(t)
            }))
        }
    }
    Bn.Xr = 16777216;
    class jn extends _n {
        isListening(t) {
            return En.isDOMEvent(t) && ("initialDOM" === t.domEvent || "nodesAdded" === t.domEvent)
        }
        processEvent(t) {
            const s = "initialDOM" === t.domEvent ? [t.initialDOM] : t.nodes;
            for (const e of s) {
                if (e instanceof Ti) {
                    const t = $e.getMaskedAttributeDetails(e);
                    e.attributes = this.so(e, t)
                }
                if ($e.getMaskedElementDetails(e).state !== $e.MaskedElementState.Child) Re.traverse(e, (t => {
                    if (t instanceof Ti) {
                        const s = $e.getMaskedAttributeDetails(t);
                        t.attributes = this.so(t, s);
                        const e = $e.getMaskedElementDetails(t);
                        e.state === $e.MaskedElementState.Parent && this.eo(t, e)
                    }
                }));
                else {
                    if ("initialDOM" === t.domEvent) return null;
                    t.nodes = csArray.prototype.filter.call(t.nodes, (t => t !== e))
                }
            }
            return t
        }
        so(t, s) {
            return 0 === s.attributes.length ? t.attributes : csArray.prototype.filter.call(t.attributes, (t => -1 === csArray.prototype.indexOf.call(s.attributes, t.name)))
        }
        eo(t, s) {
            const e = `width: ${s.width}px !important; height: ${s.height}px !important;`;
            t.children = [], csArray.prototype.push.call(t.attributes, {
                name: "style",
                value: e,
                namespaceURI: ""
            }), Ti.getAttribute(t, "data-cs-mask") || csArray.prototype.push.call(t.attributes, {
                name: "data-cs-mask",
                value: "",
                namespaceURI: ""
            })
        }
    }
    ai([Es("MaskedElementProcessor.processEvent")], jn.prototype, "processEvent", null);
    const zn = /[\u4E00-\u9FFF]|[\u3000-\u303F]|[\u3040-\u309F]|[\u30A0-\u30FF]|[\uFF00-\uFFEF]/g,
        Gn = /[^ａ\s]/g;

    function Zn(t) {
        const s = csString.prototype.replace.call(t, zn, "ａ");
        return csString.prototype.replace.call(s, Gn, "a")
    }
    csArray.prototype.reduce.call(["a", "e", "i", "o", "mi", "id", "ex", "ut", "eu", "ac", "in", "et", "sit", "vel", "sed", "leo", "amet", "elit", "orci", "erat", "quam", "odio", "eget", "lorem", "ipsum", "dolor", "nulla", "vitae", "purus", "proin", "neque", "porta", "augue", "velit", "lacus", "justo", "magna", "mollis", "nullam", "turpis", "tortor", "lectus", "luctus", "dictum", "integer", "aliquam", "viverra", "rhoncus", "posuere", "egestas", "laoreet", "vivamus", "euismod", "sagittis", "molestie", "faucibus", "pulvinar", "ultrices", "volutpat", "ultricies", "venenatis", "vulputate", "convallis", "phasellus", "adipiscing", "vestibulum", "consectetur", "ullamcorper", "sollicitudin"], ((t, s) => {
        var e;
        return t.set(s.length, [...null !== (e = t.get(s.length)) && void 0 !== e ? e : [], s]), t
    }), new Map);
    class Wn {
        get selectors() {
            return "" === this.io ? null : this.io
        }
        constructor(t, s = {
            closest: !1
        }) {
            this.Is = t, this.no = s, this.io = "", this.ro = Fi(), this.pr = ws((t => {
                if ("" === this.io) return;
                const s = [];
                for (const e of Ls(t, (t => t.addedNodes))) {
                    if (!(_(e) || this.no.closest && d(e))) continue;
                    Fs(this.no.closest ? this.oo(e, this.io) : this.findMatchingElements(e, this.io), s)
                }
                s.length && this.Is(s, "added")
            }), "SelectorObserver.processMutations"), this.ho = (t, s) => {
                if ("" === this.io || "added" !== s) return;
                const e = this.findMatchingElements(t, this.io);
                e.length && this.Is(e, "added")
            }, this.Ye = new nn(this.pr, this.ho)
        }
        observe(t) {
            "" === this.io ? this.Ye.observe() : this.io += ",", this.io += t;
            const s = this.findMatchingElements(document, t);
            for (const e of this.Ye.shadowRoots) {
                Fs(this.findMatchingElements(e, t), s)
            }
            s.length && (Ms(s, (t => {
                this.ro.add(t)
            })), this.Is(s, "initial"))
        }
        processPendingMutations() {
            this.pr(this.Ye.takeRecords())
        }
        disconnect() {
            this.Ye.disconnect(), this.ro.clear(), this.io = ""
        }
        oo(t, s) {
            const e = [];
            if (d(t)) {
                if (t.parentElement) {
                    const i = xe(t.parentElement, s);
                    i && csArray.prototype.push.call(e, i)
                }
                return csArray.prototype.filter.call(e, (t => !1 === this.ro.has(t)))
            }
            if (St(t)) {
                const i = xe(t, s);
                if (i) return csArray.prototype.push.call(e, i), csArray.prototype.filter.call(e, (t => !1 === this.ro.has(t)))
            }
            return this.findMatchingElements(t, s)
        }
        findMatchingElements(t, s) {
            const e = xs(window.csquerySelectorAll[t.nodeType].call(t, s));
            return l(t) && Ce.call(t, s) && csArray.prototype.push.call(e, t), csArray.prototype.filter.call(e, (t => !1 === this.ro.has(t)))
        }
    }
    var Qn, Jn;
    Gs([os()], Wn.prototype, "observe", null), Gs([os()], Wn.prototype, "disconnect", null), Gs([Es("SelectorObserver.findMatchingElements")], Wn.prototype, "findMatchingElements", null),
        function(t) {
            let s, e;
            t.ANONYMIZED_TEXT_STATUS_PROP = "anonymizationStatus", t.CS_CAPTURE_ATTRIBUTE = "data-cs-capture", t.WHITELISTED_STATUS = "whitelisted", t.start = function() {
                s || (s = new Wn((s => function(s) {
                    Ms(s, (s => {
                        Qs(s).visitAll((s => function(s) {
                            Re.setProperty(s, t.ANONYMIZED_TEXT_STATUS_PROP, t.WHITELISTED_STATUS)
                        }(s)))
                    }))
                }(s))));
                const i = e ? `[${t.CS_CAPTURE_ATTRIBUTE}], ${e}` : `[${t.CS_CAPTURE_ATTRIBUTE}]`;
                s.observe(i)
            }, t.stop = function() {
                s && s.disconnect()
            }, t.setWhitelistedElementsSelector = function(t) {
                e = t
            }, t.getWhitelistedElementsSelector = function() {
                return e
            }, t.isWhitelisted = function(s) {
                return Re.getProperty(s, t.ANONYMIZED_TEXT_STATUS_PROP) === t.WHITELISTED_STATUS
            }
        }(Qn || (Qn = {}));
    class Kn {
        static create(t, s) {
            if (!Kn.isSupported()) throw new Error("IntersectionObserver is not supported");
            if (s && s.delay && s.delay < 100) throw new Error("Visibility delay should be > 100ms");
            return (null == s ? void 0 : s.trackVisibility) && (t = Kn.co(t)), new IntersectionObserver(t, s)
        }
        static isSupported() {
            return !!window.IntersectionObserver && !!window.IntersectionObserverEntry
        }
        static co(t) {
            return (s, e) => t($s(s, Yn), e)
        }
    }

    function Yn(t) {
        return t.isVisible || !qi.isVisibleInViewportInForeground(t.target) ? t : {
            boundingClientRect: t.boundingClientRect,
            intersectionRatio: t.intersectionRatio,
            intersectionRect: t.intersectionRect,
            isIntersecting: t.isIntersecting,
            rootBounds: t.rootBounds,
            target: t.target,
            time: t.time,
            isVisible: !0
        }
    }
    const Xn = () => (t, s, e) => {
            e.value = function(t) {
                const s = csSymbol("oncePerTickSymbol");
                let e = null;
                const i = {},
                    n = function() {
                        var n;
                        const r = null !== (n = this) && void 0 !== n ? n : i;
                        if (e = arguments, r[s]) return;
                        r[s] = !0;
                        tr((() => {
                            r[s] = !1, t.apply(r, e)
                        }))
                    };
                return n.oncePerTickSymbol = s, n
            }(e.value)
        },
        tr = null !== (Jn = window.csQueueMicrotask) && void 0 !== Jn ? Jn : csSetTimeout;
    Xn.isScheduled = (t, s) => t[s.oncePerTickSymbol];
    class sr {
        constructor(t) {
            this.Is = t, this.ao = new Map, this.uo = t => {
                const s = t.target;
                if (this.ao.has(s)) return !0;
                let e = !1;
                return this.ao.forEach(((t, i) => {
                    !e && this.ao.get(i).subtree && (e = i.contains(s))
                })), e
            }, ri.general.nbOfMutationObservers.increase(), this.As = new csMutationObserver((s => {
                Xn.isScheduled(this, this.garbageCollect) && (s = qs(s, this.uo)), s.length && Ni((() => t(s, this)))
            }))
        }
        disconnect() {
            ri.general.nbOfMutationObservers.decrease(), this.As.disconnect(), this.ao = new Map
        }
        takeRecords() {
            return this.As.takeRecords()
        }
        observe(t, s) {
            return ri.mutations.elementMutationObserved.increase(), this.ao.set(t, s), this.As.observe(t, s)
        }
        unobserve(t) {
            this.ao.has(t) && (ri.mutations.elementMutationObserved.decrease(), this.ao.delete(t), this.garbageCollect())
        }
        garbageCollect() {
            ri.mutations.unobserveGarbageCollection.measure((() => {
                const t = qs(this.takeRecords(), this.uo);
                t.length && this.Is(t, this), this.As.disconnect(), this.ao.forEach(((t, s) => this.As.observe(s, t)))
            }))
        }
    }
    Gs([Xn()], sr.prototype, "garbageCollect", null);
    class er {
        constructor(t) {
            this.Is = t, this.lo = [], this.do = new Set
        }
        observe(t, s) {
            if (!qi.getRootNode(t)) throw new Error("Node has no root node");
            if (this.do.has(t)) return;
            this.do.add(t);
            const e = !!(null == s ? void 0 : s.subtree),
                i = () => this.Is(t),
                n = t.parentElement || qi.getRootNode(t),
                r = qi.getAncestors(t, e),
                o = new Set(r);
            ri.general.nbOfMutationObservers.increase();
            const h = hs("NodeDisconnectedObserver:MutationCallback", (s => {
                    for (const e of s)
                        if (o.has(e.target) && Us(e.removedNodes, (t => o.has(t)))) return i(), c.disconnect(), this.do.delete(t), void ri.general.nbOfMutationObservers.decrease()
                })),
                c = new csMutationObserver((t => {
                    csSetTimeout((() => h(t)))
                }));
            if (e)
                for (const t of r) {
                    csArray.prototype.includes.call([11, 9], t.nodeType) && c.observe(t, {
                        childList: !0,
                        subtree: !0
                    })
                } else c.observe(n, {
                    childList: !0
                });
            csArray.prototype.push.call(this.lo, (() => {
                c.disconnect()
            }))
        }
        disconnect() {
            Ms(this.lo, (t => t())), this.lo = [], this.do.clear()
        }
    }
    Gs([os()], er.prototype, "observe", null), Gs([os()], er.prototype, "disconnect", null);
    class ir {
        constructor(t) {
            this.fo = new Set, this.po = new er((t => this.mo(t))), this.Es = !1, this.no = t ? { ...rr,
                ...t
            } : rr
        }
        stop() {
            var t, s;
            this.Es = !1, null === (t = this.vo) || void 0 === t || t.disconnect(), null === (s = this.As) || void 0 === s || s.disconnect()
        }
        start(t) {
            if (this.Es) throw new Error("VisibilityObserver is already started");
            this.Is = hs("VisibilityObserver:callback", ((s, e) => t(s, e)));
            const s = {
                root: null,
                rootMargin: "0px",
                threshold: .5,
                trackVisibility: !0,
                delay: 300
            };
            this.vo = Kn.create((t => this.handleIntersection(t)), s), this.As = new sr((t => csSetTimeout((() => {
                Ms(t, (t => this.mo(t.target)))
            })))), this.jr(), this.Es = !0
        }
        observe(t) {
            if (!this.Es) throw new Error("Observer is stopped.");
            !1 === this.no.reobserve && t[this.yo] || (ri.visibilityObserver.nbElements.increase(), t[this.yo] = !0, this.watchIntersection(t))
        }
        jr() {
            this.wo = csSymbol("isVisible"), this.yo = csSymbol("ObservedElement"), this.Eo = csSymbol("LinkedElement"), this.Ao = csSymbol("Tracked")
        }
        mo(t) {
            this.fo.add(t);
            for (const s of this._o(t)) this.fo.add(s);
            this.recheckCssVisibilityAll()
        }
        recheckCssVisibilityAll() {
            Ms(this.fo.keys(), (t => {
                t.isConnected && !qi.areAncestorsHiddenByCSS(t) && t[this.yo] && this.watchIntersection(t)
            })), this.fo.clear()
        }
        watchIntersection(t) {
            this.As.unobserve(t), this.vo.unobserve(t);
            const s = qi.getTopAncestorHiddenByCSS(t);
            s ? (s !== t && (this.So(s, t), this.watchMutation(s)), this.watchMutation(t)) : this.vo.observe(t)
        }
        watchMutation(t, s = !0) {
            s && delete t[this.wo], this.vo.unobserve(t);
            this.As.observe(t, {
                attributeFilter: ["style", "class", "hidden"]
            })
        }
        handleIntersection(t) {
            for (const s of t) {
                const t = s.target;
                if (!s.isVisible) {
                    qi.isVisibleInDocument(t) || this.Ro(t);
                    continue
                }
                const e = !s.target[this.wo];
                s.target[this.wo] = !0, e && !this.no.delay && this.onVisibilityChanged(s.target, nr.VisibleInViewPort)
            }
            this.no.delay && csSetTimeout((() => {
                for (const s of t) {
                    const t = s.isIntersecting && s.isVisible;
                    s.target[this.wo] && t && this.onVisibilityChanged(s.target, nr.VisibleInViewPort)
                }
            }), this.no.delay)
        }
        Ro(t) {
            ri.visibilityObserver.hiddenElements.increase();
            const s = qi.getTopElement(t);
            this.watchMutation(t), s && (this.po.observe(s), this.So(s, t), this.watchMutation(s, !1))
        }
        So(t, s) {
            var e;
            (t[this.Eo] = null !== (e = t[this.Eo]) && void 0 !== e ? e : new Set).add(s)
        }
        _o(t) {
            var s, e;
            const i = [];
            return Ms(null !== (e = null === (s = t[this.Eo]) || void 0 === s ? void 0 : s.values()) && void 0 !== e ? e : [], (t => csArray.prototype.push.call(i, t))), i
        }
        onVisibilityChanged(t, s) {
            if (s === nr.VisibleInViewPort && this.no.trackOnce) {
                if (this.vo.unobserve(t), this.As.unobserve(t), t[this.Ao]) return;
                t[this.Ao] = !0
            }
            this.Is(t, s)
        }
        static isSupported() {
            return Kn.isSupported()
        }
    }
    var nr;
    Gs([os()], ir.prototype, "observe", null), Gs([de({
            wait: 50
        }), os(), Es("recheckCssVisibilityAll")], ir.prototype, "recheckCssVisibilityAll", null), Gs([os()], ir.prototype, "watchIntersection", null), Gs([os()], ir.prototype, "watchMutation", null), Gs([os(), Es("VisibilityObserver.handleIntersection")], ir.prototype, "handleIntersection", null), Gs([os()], ir.prototype, "onVisibilityChanged", null),
        function(t) {
            t.VisibleInViewPort = "VisibleInViewPort", t.HiddenByAnother = "HiddenByAnother", t.Hidden = "Hidden"
        }(nr || (nr = {}));
    const rr = {
        delay: 1e3,
        trackOnce: !0,
        reobserve: !1
    };
    class or {
        constructor(t) {
            this.Is = t, this.Gn = Fi(), this.To = t => {
                Ni((() => {
                    for (const s of t) "childList" === s.type && Ms(s.addedNodes, (t => {
                        Qs(t, NodeFilter.SHOW_TEXT).visitAll((t => {
                            this.Gn.has(t) || (this.Gn.add(t), this.Is(t))
                        }))
                    }))
                }))
            }, this.zn = new nn(this.To)
        }
        observe() {
            this.zn.observe();
            Qs(document, NodeFilter.SHOW_TEXT).visitAll((t => {
                this.Gn.add(t), this.Is(t)
            }))
        }
        disconnect() {
            this.Gn.clear(), this.zn.disconnect()
        }
    }
    var hr, cr;
    ! function(t) {
        let s;

        function e(s) {
            Ms(s, (s => {
                Qs(s).visitAll((s => Re.setProperty(s, t.nodeProp, !0)))
            }))
        }
        t.nodeProp = "toEncrypt", t.stop = function() {
            null == s || s.disconnect(), s = null
        }, t.addSelector = function(t) {
            Ne(t) && (null == s && (s = new Wn(e)), s.observe(t))
        }, t.shouldEncrypt = function(s) {
            return !0 === Re.getProperty(s, t.nodeProp)
        }, t.getSelectors = function() {
            return null == s ? void 0 : s.selectors
        }
    }(hr || (hr = {}));
    class ar extends gn {
        constructor(t) {
            super(), this.Io = new Set, this.bo = new Set, this.Po = !1, this.Vo = new Set, this.Co = !1, this.ko = new ir(t), this.Oo = new or((t => {
                const s = qi.getParentElement(t);
                !s || !s.isConnected || $e.isMaskedElement(s) || $e.isMaskedElementChild(s) || v(s) || w(s) || Tt(t.data) || (this.Io.add(s), this.xo())
            }))
        }
        onStart() {
            ir.isSupported() && (this.ko.start(((t, s) => this.onVisibilityChanged(t, s))), this.Oo.observe())
        }
        onStop() {
            ir.isSupported() && (this.ko.stop(), this.Oo.disconnect(), this.Io.clear(), this.bo.clear(), this.Vo.clear(), this.Po = !1)
        }
        setAnonymization(t) {
            this.Co = t
        }
        xo() {
            this.Po || (this.Po = !0, Li((() => {
                if (!this.isStarted) return;
                this.Po = !1;
                const t = this.Io;
                this.Io = new Set;
                for (const s of Hs(t)) s.isConnected && !this.bo.has(s) && (this.bo.add(s), Us(csNodechildNodes.apply(s), (t => 3 === t.nodeType)) && this.ko.observe(s))
            }), 1001))
        }
        onVisibilityChanged(t, s) {
            if (s !== nr.VisibleInViewPort) return;
            const e = Us(csNodechildNodes.apply(t), (t => 3 === t.nodeType));
            e && hr.shouldEncrypt(t) ? rs.critical("[PII LEAK] Encrypted element.") : y(t) ? rs.critical("[PII LEAK] Textarea element.") : Ms(csNodechildNodes.apply(t), (e => {
                if (3 !== e.nodeType) return;
                if (this.Co && !Qn.isWhitelisted(t)) return;
                const i = e.data;
                this.Vo.has(i) || (this.Vo.add(i), this.produceEvent({
                    type: "TextVisibility",
                    text: i,
                    state: s
                }))
            }))
        }
    }
    ai([os()], ar.prototype, "onVisibilityChanged", null),
        function(t) {
            t.isTextVisibilityEvent = function(t) {
                return "TextVisibility" === t.type
            }
        }(cr || (cr = {}));
    class ur extends _n {
        constructor(t, s, e) {
            super(), this.Co = t, this.$o = s, this.Lo = e, this.FAST_LOOKUP_EMAIL_REGEX = /[a-zA-Z0-9+_-](?:@|%40|%2540)/
        }
        setAnonymization(t) {
            this.Co = t
        }
        isListening(t) {
            return cr.isTextVisibilityEvent(t) || En.isDOMEvent(t) && ("initialDOM" === t.domEvent || "nodesAdded" === t.domEvent || "attributeChanged" === t.domEvent || "characterDataChanged" === t.domEvent)
        }
        processEvent(t) {
            if (cr.isTextVisibilityEvent(t)) {
                const s = t.text;
                if (t.text = this.Lo(t.text), s !== t.text) {
                    const t = this.FAST_LOOKUP_EMAIL_REGEX.test(s);
                    rs.critical("[PII LEAK] Text visibility element: " + (t ? "Email" : "CC"))
                }
                return t
            }
            switch (t.domEvent) {
                case "initialDOM":
                case "nodesAdded":
                    this.Mo(t);
                    break;
                case "attributeChanged":
                    this.Do(t);
                    break;
                case "characterDataChanged":
                    this.Uo(t)
            }
            return t
        }
        Mo(t) {
            const s = "initialDOM" === t.domEvent ? [t.initialDOM] : t.nodes;
            for (const t of s) Re.traverse(t, ((t, s) => {
                if (t.anonymized = this.Co, 3 === t.nodeType) {
                    let e = this.Co;
                    return s && ("style" === s.localName || Qn.isWhitelisted(s)) && (e = !1), t.anonymized = e, void(t.data = this.qo(e, t.data, null == s ? void 0 : s.localName, s ? Re.getProperties(s) : void 0))
                }
                if (Ti.isElement(t)) return this.Fo(t);
                4 !== t.nodeType || (t.data = this.Co ? Zn(t.data) : this.Lo(t.data))
            }))
        }
        Fo(t) {
            if (Re.getProperty(t, "SVG")) return;
            const s = csArray.prototype.some.call(t.attributes, (t => "type" === t.name && ("submit" === t.value || "button" === t.value)));
            t.attributes = csArray.prototype.map.call(t.attributes, (e => (e.anonymized = this.Co, e.value = this.Ho(t.localName, this.Co, e.name, e.value, s), e)))
        }
        Do(t) {
            if (t.isSvg) return;
            const s = "submit" === t.inputType || "button" === t.inputType;
            t.newValue = this.Ho(t.localName, this.Co, t.attribute, t.newValue, s)
        }
        Ho(t, s, e, i, n) {
            return this.Bo(e) && !this.jo(e, i) || "svg" === t || "slot" === t ? i : "value" === e && "input" === t && s && n ? Zn(i) : s ? "" : this.Lo(i)
        }
        Bo(t) {
            return this.$o.allWhitelistedAttributes.has(t)
        }
        jo(t, s) {
            return !(!this.$o.attributesCheckers || !_t(this.$o.attributesCheckers[t])) && this.$o.attributesCheckers[t](s)
        }
        Uo(t) {
            t.newValue = this.qo(this.Co, t.newValue, t.parentLocalName, t.parentProps)
        }
        qo(t, s, e, i) {
            if (e) {
                if ("style" === e) return s;
                if (t && i && i[Qn.ANONYMIZED_TEXT_STATUS_PROP] === Qn.WHITELISTED_STATUS) return this.Lo(s)
            }
            return t ? Zn(s) : this.Lo(s)
        }
    }
    ai([Es("AnonymizedTextProcessor.processEvent")], ur.prototype, "processEvent", null);
    const lr = "textarea";
    class dr extends _n {
        isListening(t) {
            return En.isDOMEvent(t) && ("initialDOM" === t.domEvent || "nodesAdded" === t.domEvent || "characterDataChanged" === t.domEvent)
        }
        processEvent(t) {
            switch (t.domEvent) {
                case "initialDOM":
                    this.zo(t);
                    break;
                case "nodesAdded":
                    this.Go(t);
                    break;
                case "characterDataChanged":
                    this.Zo(t)
            }
            return t
        }
        zo(t) {
            Re.traverse(t.initialDOM, ((t, s) => {
                this.Wo(t, s) && (t.data = this.Qo(t.data))
            }))
        }
        Go(t) {
            for (const s of t.nodes) Re.traverse(s, ((s, e) => {
                this.Jo(s, e, t) && (s.data = this.Qo(s.data))
            }))
        }
        Zo(t) {
            t.parentLocalName === lr && (t.newValue = this.Qo(t.newValue))
        }
        Qo(t) {
            return csString.prototype.replace.call(t, /\S/g, "•")
        }
        Jo(t, s, e) {
            return this.Ko(t, e) || this.Wo(t, s)
        }
        Ko(t, s) {
            return 3 === t.nodeType && s.targetLocalName === lr
        }
        Wo(t, s) {
            return 3 === t.nodeType && Et(s) && s.localName === lr
        }
    }
    ai([Es("AnonymizedTextAreaProcessor.processEvent")], dr.prototype, "processEvent", null);
    class fr {
        static shouldProcessElement(t) {
            return "VIDEO" === t.tagName && qi.isConnected(t) && !$e.isMaskedElement(t) && !$e.isMaskedElementChild(t)
        }
        static isPlaying(t) {
            return !t.paused && !t.ended
        }
    }
    class pr extends gn {
        constructor() {
            super(), this.Yo = t => this.Xo(t), this.xs = new he(((t, s) => {
                switch (s) {
                    case "initial":
                    case "added":
                        this.th(t);
                        break;
                    case "removed":
                        this.eh(t)
                }
            })), this.ih = new Wn(((t, s) => {
                "initial" !== s && "added" !== s || this.nh(t)
            }))
        }
        onStart() {
            this.th(document), this.xs.observe(), this.ih.observe("video")
        }
        onStop() {
            this.eh(document), this.xs.disconnect(), this.ih.disconnect()
        }
        Xo(t) {
            if (!this.isStarted) return;
            const s = we(t);
            if (!s) return;
            const e = be(s);
            if (fr.shouldProcessElement(s)) switch (t.type) {
                case "play":
                    this.produceEvent({
                        type: "VideoEvent",
                        videoEventType: "play",
                        nodeId: e
                    });
                    break;
                case "pause":
                    this.produceEvent({
                        type: "VideoEvent",
                        videoEventType: "pause",
                        nodeId: e
                    });
                    break;
                case "seeked":
                    this.produceEvent({
                        type: "VideoEvent",
                        videoEventType: "seeked",
                        nodeId: e,
                        newTimePositionInSec: s.currentTime
                    })
            }
        }
        th(t) {
            ce({
                type: "play",
                listener: this.Yo,
                boundElement: t
            }), ce({
                type: "pause",
                listener: this.Yo,
                boundElement: t
            }), ce({
                type: "seeked",
                listener: this.Yo,
                boundElement: t
            })
        }
        eh(t) {
            ae({
                type: "play",
                listener: this.Yo,
                boundElement: t
            }), ae({
                type: "pause",
                listener: this.Yo,
                boundElement: t
            }), ae({
                type: "seeked",
                listener: this.Yo,
                boundElement: t
            })
        }
        nh(t) {
            for (const s of t) {
                if (!fr.shouldProcessElement(s)) continue;
                const t = be(s);
                this.produceEvent({
                    type: "VideoEvent",
                    videoEventType: "seeked",
                    newTimePositionInSec: s.currentTime,
                    nodeId: t
                }), fr.isPlaying(s) && this.produceEvent({
                    type: "VideoEvent",
                    videoEventType: "play",
                    nodeId: t
                })
            }
        }
    }
    class mr extends gn {
        constructor(t) {
            super(), this.rh = t
        }
        onStart() {
            this.produceEvent({
                type: "Debug",
                key: "debugInfo",
                value: this.rh
            })
        }
    }
    class vr {
        constructor(t) {
            this.Is = t, this.oh = {
                boundElement: window,
                type: "resize",
                listener: () => this.resizeListener()
            }, this.Is = t
        }
        observe() {
            ce(this.oh), this.Fs()
        }
        Fs() {
            this.resizeListener()
        }
        disconnect() {
            ae(this.oh)
        }
        resizeListener() {
            const t = {
                width: Mi.windowWidth(),
                height: Mi.windowHeight()
            };
            this.Is(t)
        }
    }
    var gr, yr, wr, Er, Ar, _r, Sr;
    Gs([os("resize")], vr.prototype, "resizeListener", null),
        function(t) {
            t.PORTRAIT = "Portrait", t.LANDSCAPE = "Landscape"
        }(gr || (gr = {})),
        function(t) {
            t.PORTRAIT_PRIMARY = "portrait-primary", t.PORTRAIT_SECONDARY = "portrait-secondary", t.LANDSCAPE_PRIMARY = "landscape-primary", t.LANDSCAPE_SECONDARY = "landscape-secondary"
        }(yr || (yr = {})),
        function(t) {
            t[t.PORTRAIT = 0] = "PORTRAIT", t[t.PORTRAIT_REVERSE = 180] = "PORTRAIT_REVERSE", t[t.LANDSCAPE = -90] = "LANDSCAPE", t[t.LANDSCAPE_REVERSE = 90] = "LANDSCAPE_REVERSE"
        }(wr || (wr = {})),
        function(t) {
            function s() {
                return "orientation" in window.csScreen
            }

            function e() {
                return "orientation" in window
            }
            t.isScreenOrientationApiSupported = s, t.isDeprecatedScreenOrientationApiSupported = e;
            const i = s() ? function() {
                switch (window.csScreen.orientation.type) {
                    case yr.PORTRAIT_PRIMARY:
                    case yr.PORTRAIT_SECONDARY:
                        return gr.PORTRAIT;
                    case yr.LANDSCAPE_PRIMARY:
                    case yr.LANDSCAPE_SECONDARY:
                        return gr.LANDSCAPE;
                    default:
                        return gr.PORTRAIT
                }
            } : e() ? function() {
                switch (window.orientation) {
                    case wr.PORTRAIT:
                    case wr.PORTRAIT_REVERSE:
                        return gr.PORTRAIT;
                    case wr.LANDSCAPE:
                    case wr.LANDSCAPE_REVERSE:
                        return gr.LANDSCAPE;
                    default:
                        return gr.PORTRAIT
                }
            } : function() {
                return gr.LANDSCAPE
            };
            t.getCurrentOrientation = function() {
                return i()
            }
        }(Er || (Er = {}));
    class Rr extends gn {
        constructor() {
            super(...arguments), this.hh = null, this.ah = null, this.uh = new vr((t => {
                this.produceEvent({ ...t,
                    type: "viewportResize"
                }), this.onScreenPotentiallyChanged()
            }))
        }
        onScreenPotentiallyChanged() {
            const t = Er.getCurrentOrientation(),
                {
                    screenWidth: s,
                    screenHeight: e
                } = this.fh(t);
            if (s !== this.hh || e !== this.ah) {
                this.hh = s, this.ah = e;
                const t = {
                    type: "screenResize",
                    width: s,
                    height: e
                };
                this.produceEvent(t)
            }
        }
        fh(t) {
            let s, e;
            const i = Mi.screenWidth(),
                n = Mi.screenHeight();
            return t === gr.PORTRAIT ? (s = i, e = n) : (s = Math.max(i, n), e = Math.min(i, n)), {
                screenWidth: s,
                screenHeight: e
            }
        }
        onStart() {
            this.uh.observe()
        }
        onStop() {
            this.hh = null, this.ah = null, this.uh.disconnect()
        }
    }
    class Tr extends gn {
        constructor() {
            super(), this.ph = "object" == typeof window.customElements && "function" == typeof window.customElements.whenDefined && "function" == typeof window.Promise, this.mh = hs("CustomElementRegistrationProducer:onElementsFound", (t => {
                for (const e of t) $e.isMaskedElement(e) || $e.isMaskedElementChild(e) || l(s = e) && csString.prototype.indexOf.call(s.tagName, "-") > 0 && -1 === csString.prototype.indexOf.call(s.tagName, ":") && -1 === csString.prototype.indexOf.call(s.tagName, '"') && -1 === csString.prototype.indexOf.call(s.tagName, ",") && csArray.prototype.indexOf.call(I, csString.prototype.toLocaleLowerCase.call(s.tagName)) < 0 && this.register(csString.prototype.toLowerCase.call(e.tagName));
                var s
            }));
            const t = Hi(this.mh);
            this.ur = new $n((s => t.push(s))), this.Io = new Set
        }
        onStart() {
            this.ph && this.ur.observe()
        }
        onStop() {
            this.Io.clear(), this.ur.disconnect()
        }
        async register(t) {
            this.Io.has(t) || (this.Io.add(t), await window.customElements.whenDefined(t), this.produceEvent({
                type: "CustomElementRegistration",
                tagName: csString.prototype.toLowerCase.call(t)
            }))
        }
    }
    ai([os()], Tr.prototype, "register", null),
        function(t) {
            t.isNavigationTimingObserverSupported = function() {
                var t, s;
                return (null == (null === (t = window.PerformanceObserver) || void 0 === t ? void 0 : t.supportedEntryTypes) ? void 0 : csArray.prototype.indexOf.call(null === (s = window.PerformanceObserver) || void 0 === s ? void 0 : s.supportedEntryTypes, "navigation")) >= 0
            }, t.getTimeOrigin = function() {
                return window.performance.timeOrigin
            }
        }(Ar || (Ar = {}));
    class Ir {
        static gh() {
            return new window.PerformanceObserver((t => Ir.yh(t)))
        }
        static yh(t) {
            const s = t.getEntriesByType("navigation")[0];
            s && (this.Eh = s, Ir.Ah(s))
        }
        static ys(t) {
            Ir._h(t), Ir.Eh && t(Ir.Eh), Ir.Sh || Ir.Rh()
        }
        static _h(t) {
            Ir.Th.add(t)
        }
        static Ih(t) {
            Ir.Th.delete(t)
        }
        static Rh() {
            if (!Ir.bh) return Ir.Eh || (Ir.Eh = {
                requestStart: window.performance.timing.requestStart,
                domInteractive: window.performance.timing.domInteractive
            }), void Ir.Ah(Ir.Eh);
            Ir.bh.observe({
                type: "navigation",
                buffered: !0
            }), Ir.Sh = !0
        }
        static Ah(t) {
            Ir.Th.forEach((s => {
                s(t)
            }))
        }
        static Ts(t) {
            Ir.Ih(t), 0 === Ir.Th.size && Ir.Ph()
        }
        static Ph() {
            var t;
            Ir.Sh && (null === (t = Ir.bh) || void 0 === t || t.disconnect(), Ir.Sh = !1, Ir.Eh = null, Ir.bh = this.gh())
        }
        constructor(t) {
            this.Is = t
        }
        observe() {
            Ir.ys(this.Is)
        }
        disconnect() {
            Ir.Ts(this.Is)
        }
    }
    Ir.bh = Ar.isNavigationTimingObserverSupported() ? Ir.gh() : null, Ir.Sh = !1, Ir.Th = new Set, Ir.Eh = null;
    class br extends gn {
        constructor() {
            super(...arguments), this.Vh = null, this.Ch = new Ir((t => {
                if (this.Vh) return;
                const s = this.kh(t);
                s && (this.Vh = s, this.produceEvent(s))
            }))
        }
        onStart() {
            this.Vh ? this.produceEvent(this.Vh) : this.Ch.observe()
        }
        onStop() {
            this.Ch.disconnect()
        }
        kh(t) {
            const s = Ar.getTimeOrigin();
            return {
                type: "PerformanceTiming",
                timings: {
                    timeOrigin: s,
                    requestStart: Math.floor(s + t.requestStart),
                    domInteractive: Math.floor(s + t.domInteractive)
                },
                timestamp: Vt.now()
            }
        }
    }! function(t) {
        t[t.TAP = 0] = "TAP", t[t.LONG_PRESS = 1] = "LONG_PRESS", t[t.DRAG = 2] = "DRAG", t[t.FLICK = 3] = "FLICK", t[t.PINCH_IN = 4] = "PINCH_IN", t[t.PINCH_OUT = 5] = "PINCH_OUT"
    }(_r || (_r = {})),
    function(t) {
        t[t.UP = 1] = "UP", t[t.DOWN = 2] = "DOWN", t[t.LEFT = 3] = "LEFT", t[t.RIGHT = 4] = "RIGHT"
    }(Sr || (Sr = {}));
    class Pr {
        compute(t, s) {
            const e = this.Oh(s.x) - this.Oh(t.x),
                i = this.Oh(s.y) - this.Oh(t.y),
                n = s.time - t.time;
            return {
                duration: n,
                distance: this.Nh(e, i),
                direction: this.xh(e, i),
                velocity: this.$h(e, i, n)
            }
        }
        computePinchMetrics(t, s) {
            const e = this.Oh(s.x) - this.Oh(t.x),
                i = this.Oh(s.y) - this.Oh(t.y);
            return {
                duration: s.time - t.time,
                distance: this.Nh(e, i)
            }
        }
        getScale(t, s) {
            return Math.abs(s / t - 1)
        }
        Oh(t) {
            return t / window.devicePixelRatio
        }
        Nh(t, s) {
            return Math.round(Math.sqrt(t * t + s * s))
        }
        $h(t, s, e) {
            const i = e / 1e3,
                n = t / i,
                r = s / i;
            return Math.round(Math.abs(n) + Math.abs(r))
        }
        xh(t, s) {
            return Math.abs(t) > Math.abs(s) ? t > 0 ? Sr.RIGHT : Sr.LEFT : s > 0 ? Sr.DOWN : Sr.UP
        }
    }
    class Vr {
        constructor() {
            this.Lh = {}, this.Mh = () => {}, this.Dh = new Pr, this.Uh()
        }
        static isGestureDetectionSupported() {
            return void 0 !== window.devicePixelRatio
        }
        onGesture(t) {
            this.Mh = t
        }
        isValidTouchEvent(t) {
            return "touches" in t && "changedTouches" in t
        }
        processActionDown(t) {
            if (!this.qh(t)) return;
            this.Fh(t) && this.Uh();
            const s = {
                x: t.touches[0].clientX,
                y: t.touches[0].clientY,
                time: Vt.now()
            };
            if (1 === t.touches.length) this.Lh.startPinchTime = s.time, this.Lh.firstTouch = s;
            else if (2 === t.touches.length && (this.Lh.secondTouch = {
                    x: t.touches[1].clientX,
                    y: t.touches[1].clientY,
                    time: Vt.now()
                }, this.Lh.firstTouch && this.Lh.secondTouch)) {
                const t = this.Dh.computePinchMetrics(this.Lh.firstTouch, this.Lh.secondTouch);
                this.Hh = t.distance
            }
            csArray.prototype.push.call(this.Bh, s), this.jh = we(t)
        }
        processActionMove() {
            this.zh = !0
        }
        processActionUp(t) {
            if (this.Gh(t)) {
                if (csArray.prototype.push.call(this.Bh, {
                        x: t.changedTouches[0].clientX,
                        y: t.changedTouches[0].clientY,
                        time: Vt.now()
                    }), this.Zh(t) && this.Lh.startPinchTime) {
                    const s = {
                            x: t.touches[0].clientX,
                            y: t.touches[0].clientY,
                            time: this.Lh.startPinchTime
                        },
                        e = {
                            x: t.changedTouches[0].clientX,
                            y: t.changedTouches[0].clientY,
                            time: Vt.now()
                        };
                    this.Lh.firstTouch && (this.Lh.firstTouch = s, this.Lh.secondTouch = e), this.Wh(t)
                }
                this.Hh || this.Qh() && this.Jh(t)
            }
        }
        Uh() {
            this.Bh = [], this.jh = null, this.zh = !1, this.Hh = null, this.Kh = !0
        }
        Jh(t) {
            const s = this.Dh.compute(this.Bh[0], this.Bh[1]);
            this.Kh = t.isTrusted;
            const e = this.zh ? this.Yh(s) : this.Xh(s);
            if (this.tc(e.type, t.changedTouches)) {
                const s = t.changedTouches[0];
                e.pageX = ue(s.pageX, 1), e.pageY = ue(s.pageY, 1)
            }
            this.Mh(e, t)
        }
        Wh(t) {
            if (!this.Lh.firstTouch || !this.Lh.secondTouch) return;
            const s = this.Dh.computePinchMetrics(this.Lh.firstTouch, this.Lh.secondTouch);
            this.Kh = t.isTrusted;
            const e = this.sc(s);
            e && this.Mh(e, t)
        }
        sc(t) {
            if (!this.Hh) return;
            if (this.Dh.getScale(this.Hh, t.distance) < .1) return;
            return {
                type: this.Hh > t.distance ? _r.PINCH_IN : _r.PINCH_OUT,
                target: this.jh,
                distance: t.distance,
                isTrusted: this.Kh
            }
        }
        Yh(t) {
            return {
                type: t.velocity < 100 ? _r.DRAG : _r.FLICK,
                target: this.jh,
                velocity: t.velocity,
                distance: t.distance,
                direction: t.direction,
                isTrusted: this.Kh
            }
        }
        Xh(t) {
            return {
                type: t.duration < 1e3 ? _r.TAP : _r.LONG_PRESS,
                target: this.jh,
                isTrusted: this.Kh
            }
        }
        tc(t, s) {
            return t === _r.TAP && s && 1 === s.length
        }
        Fh(t) {
            return 1 === t.touches.length
        }
        Qh() {
            return 2 === this.Bh.length
        }
        qh(t) {
            return t.touches.length > 0
        }
        Gh(t) {
            return t.changedTouches.length > 0
        }
        Zh(t) {
            return this.zh && !!this.Hh && 1 === t.changedTouches.length && 1 === t.touches.length
        }
    }
    class Cr {
        constructor(t) {
            this.Is = t
        }
        observe() {
            Cr.ec && Cr.nc(this.Is)
        }
        disconnect() {
            Cr.ec && Cr.rc(this.Is)
        }
        static oc(t, s) {
            Cr.Th.forEach((e => e(t, s)))
        }
        static nc(t) {
            Cr.Th.has(t) || (Cr.Th.add(t), 1 === Cr.Th.size && (Cr.hc.onGesture(Cr.oc), csArray.prototype.forEach.call(Cr.qn, (t => ce(t)))))
        }
        static rc(t) {
            Cr.Th.delete(t), 0 === Cr.Th.size && csArray.prototype.forEach.call(Cr.qn, (t => ae(t)))
        }
        static cc(t) {
            if (Cr.hc.isValidTouchEvent(t)) switch (t.type) {
                case "touchstart":
                    Cr.hc.processActionDown(t);
                    break;
                case "touchmove":
                    Cr.hc.processActionMove();
                    break;
                case "touchend":
                    Cr.hc.processActionUp(t)
            }
        }
    }
    Cr.qn = [{
        boundElement: document,
        type: "touchstart",
        listener: t => Cr.cc(t)
    }, {
        boundElement: document,
        type: "touchmove",
        listener: t => Cr.cc(t)
    }, {
        boundElement: document,
        type: "touchend",
        listener: t => Cr.cc(t)
    }], Cr.ec = Vr.isGestureDetectionSupported(), Cr.Th = new Set, Cr.hc = new Vr;
    class kr extends gn {
        constructor() {
            super(), this.ac = new Cr(this.lc.bind(this))
        }
        onStart() {
            this.ac.observe()
        }
        onStop() {
            this.ac.disconnect()
        }
        lc(t) {
            const s = this.fc(t);
            s && this.produceEvent(s)
        }
        fc(t) {
            if (!this.mc(t)) return null;
            const s = (e = t.target, Re.getProperty(e, Ie));
            var e;
            return s ? {
                type: "Gesture",
                targetId: s,
                data: {
                    type: t.type,
                    direction: t.direction,
                    distance: t.distance,
                    velocity: t.velocity,
                    pageX: t.pageX,
                    pageY: t.pageY
                }
            } : null
        }
        mc(t) {
            return null !== t.target && !(l(t.target) && $e.isMaskedElementChild(t.target))
        }
    }

    function Or(t) {
        return "INPUT" === t.nodeName
    }

    function Nr(t) {
        return Or(t) && "number" === t.type
    }

    function xr(t) {
        return Or(t) && ("checkbox" === t.type || "radio" === t.type)
    }
    class $r extends gn {
        constructor(t) {
            super(), this.Li = t, this.vc = Fi(), this.gc = t => this.inputHandler(t), this.yc = [], this.wc(), this.Ec(), this.ih = new Wn((t => {
                for (const s of t) this.Ac(s) && Ni((() => {
                    this._c(s, be(s))
                }))
            })), this.xs = new he(((t, s) => {
                switch (s) {
                    case "initial":
                    case "added":
                        ce({
                            type: "change",
                            listener: this.gc,
                            boundElement: t
                        });
                        break;
                    case "removed":
                        ae({
                            type: "change",
                            boundElement: t,
                            listener: this.gc
                        })
                }
            }))
        }
        onStart() {
            ce({
                type: "keyup",
                boundElement: document,
                listener: this.gc
            }), ce({
                type: "change",
                boundElement: document,
                listener: this.gc
            }), Ms(this.yc, (t => t.activate())), this.ih.observe(csArray.prototype.join.call($r.Sc, ",")), this.xs.observe()
        }
        onStop() {
            ae({
                type: "keyup",
                boundElement: document,
                listener: this.gc
            }), ae({
                type: "change",
                boundElement: document,
                listener: this.gc
            }), Ms(this.yc, (t => t.deactivate())), this.ih.disconnect(), this.xs.disconnect(), this.vc.clear()
        }
        _c(t, s) {
            var e, i, n;
            if (this.vc.has(t)) return;
            if (this.vc.add(t), function(t) {
                    return "SELECT" === t.nodeName
                }(t)) {
                const s = {
                    type: "InputEvent",
                    inputType: "select",
                    target: be(t),
                    selectedIndex: t.selectedIndex,
                    timestamp: Vt.now()
                };
                return void this.produceEvent(s)
            }
            if (xr(t)) {
                const s = {
                    type: "InputEvent",
                    inputType: "checkable",
                    target: be(t),
                    checked: t.checked,
                    timestamp: Vt.now()
                };
                return void this.produceEvent(s)
            }
            const r = function(t) {
                    return "TEXTAREA" === t.nodeName || Or(t) && !Nr(t) && !xr(t)
                }(t),
                o = Nr(t);
            if (r || o) {
                const r = null !== (e = t.value) && void 0 !== e ? e : "";
                if (null === (i = this.Li) || void 0 === i ? void 0 : i.shouldEncrypt(t)) return void(null === (n = this.Li) || void 0 === n || n.registerInputNodeToEncrypt({
                    targetId: s,
                    targetValue: r,
                    date: Vt.now()
                }));
                const h = o ? "0" : "•",
                    c = {
                        type: "InputEvent",
                        inputType: "text",
                        target: be(t),
                        value: csString.prototype.replace.call(r, /\S/g, h),
                        timestamp: Vt.now()
                    };
                this.produceEvent(c)
            }
        }
        inputHandler(t) {
            if (!this.isStarted) return;
            const s = we(t),
                e = be(s);
            e && this.Ac(s) && qi.isConnected(s) && Ni((() => {
                this._c(s, e)
            }))
        }
        wc() {
            this.trackChanges(HTMLInputElement, "checked"), this.trackChanges(HTMLInputElement, "value"), this.trackChanges(HTMLTextAreaElement, "value")
        }
        Ec() {
            this.trackChanges(HTMLSelectElement, "selectedIndex"), this.trackChanges(HTMLSelectElement, "value"), this.trackChanges(HTMLOptionElement, "selected", !0)
        }
        trackChanges(t, s, e = !1) {
            const i = ne(t.prototype, s, ((t, s, i) => {
                if (i !== s && qi.isConnected(t)) {
                    const s = e ? t.parentElement : t;
                    this.Rc(s)
                }
            }));
            i && csArray.prototype.push.call(this.yc, i)
        }
        Ac(t) {
            return !$e.isMaskedElement(t) && !$e.isMaskedElementChild(t) && (g(t) || A(t) || y(t))
        }
        Rc(t) {
            if (this.isStarted && qi.isConnected(t)) {
                const s = be(t);
                s && this.Ac(t) && Ni((() => {
                    this._c(t, s)
                }))
            }
        }
    }
    $r.Sc = ["textarea", "input:not([type])", 'input[type="text"]', 'input[type="email"]', 'input[type="search"]', 'input[type="tel"]', 'input[type="url"]', 'input[type="password"]', 'input[type="number"]', 'input[type="checkbox"]', 'input[type="radio"]', "select"], ai([as()], $r.prototype, "inputHandler", null), ai([os()], $r.prototype, "trackChanges", null);
    class Lr {
        constructor(t) {
            this.Is = t, this.Tc = !1, this.oh = {
                boundElement: window,
                type: "error",
                listener: t => this.Ic(t)
            }
        }
        observe() {
            ce(this.oh, this.Tc)
        }
        disconnect() {
            ae(this.oh, this.Tc)
        }
        Ic(t) {
            this.Is(t)
        }
    }
    class Mr extends gn {
        constructor() {
            super(...arguments), this.bc = new Lr((t => this.Pc(t)))
        }
        Pc({
            message: t,
            filename: s,
            lineno: e,
            colno: i
        }) {
            t = null != t ? t : "[NO ERROR MESSAGE]", this.produceEvent({
                type: "JSError",
                message: t,
                filename: s,
                lineno: e,
                colno: i
            })
        }
        onStart() {
            this.bc.observe()
        }
        onStop() {
            this.bc.disconnect()
        }
    }
    class Dr extends _n {
        constructor(t) {
            super(), this.Vc = t, this.Cc = 1024
        }
        isListening(t) {
            return "JSError" === t.type
        }
        processEvent(t) {
            return t.message = An.truncate(t.message, this.Cc, An.ELLIPSIS), this.Vc(t)
        }
    }
    let Ur = [],
        qr = !1;
    const Fr = ws((function() {
        const t = csDate.now();
        for (let s = 0; s < Ur.length; s++)
            if (Ur[s](), csDate.now() - t >= 35) return Ur = csArray.prototype.slice.call(Ur, s + 1), void csSetTimeout(Fr);
        Ur = [], qr = !1
    }), "executeTasks");
    var Hr;
    ! function(t) {
        t[t.Started = 0] = "Started", t[t.Stopped = 1] = "Stopped", t[t.Processing = 2] = "Processing", t[t.Completed = 3] = "Completed"
    }(Hr || (Hr = {}));
    class Br {
        constructor() {
            this.kc = new us, this.we = Hr.Stopped, this.Is = null, this.Oc = t => {
                this.we !== Hr.Stopped && t && (this.Is(t), this.Nc())
            }
        }
        get queueLength() {
            return this.kc.length
        }
        start(t) {
            if (this.Is) throw new Error("callback already set");
            this.we = Hr.Started, this.Is = t
        }
        push(t) {
            this.kc.push(t), this.xc()
        }
        stop() {
            this.Is = null, this.we = Hr.Stopped, this.kc.clear()
        }
        static pipe(t, s) {
            let e = t;
            const i = new csArray;
            for (const t of s) {
                const s = new Br;
                s.start((s => {
                    t.pushEvent(s)
                })), csArray.prototype.push.call(i, s), Ms(e, (t => t.subscribe((t => s.push(t))))), e = [t]
            }
            const n = new jr(i);
            return Ms(e, (t => t.subscribe((t => n.push(t))))), n
        }
        $c() {
            return this.we === Hr.Stopped
        }
        Lc() {
            return this.we === Hr.Processing
        }
        Nc() {
            this.$c() || (this.kc.isEmpty ? this.we = Hr.Completed : (this.we = Hr.Processing, function(t) {
                if (csArray.prototype.push.call(Ur, t), !qr) {
                    for (let t = 0; t < 3; t++) csSetTimeout(Fr);
                    qr = !0
                }
            }((() => {
                const t = this.kc.pop();
                t instanceof Ii ? t.complete(this.Oc) : this.Oc(t)
            }))))
        }
        xc() {
            this.$c() || this.Lc() || this.Nc()
        }
    }
    class jr extends Br {
        constructor(t) {
            super(), this.Mc = t
        }
        get queueLength() {
            return csArray.prototype.reduce.call(this.Mc, ((t, s) => t + s.queueLength), 0)
        }
        stop() {
            super.stop(), Ms(this.Mc, (t => t.stop()))
        }
    }
    class zr {
        constructor(t, s = []) {
            this.producers = t, this.processors = s, this.Es = !1, this.Th = []
        }
        get pendingEvents() {
            return this.kc.queueLength
        }
        start() {
            if (this.Es) throw new Error("Recording is already started.");
            const t = this.Th;
            this.kc = Br.pipe(this.producers, this.processors), this.kc.start((s => csArray.prototype.forEach.call(t, (t => t(s))))), Ms(this.producers, (t => t.start())), Ms(this.processors, (t => t.start())), this.Es = !0
        }
        stop() {
            this.kc.stop(), this.Th.length = 0;
            for (const t of this.producers) t.stop();
            for (const t of this.processors) t.stop();
            this.Es = !1, this.Th = []
        }
        subscribe(t) {
            if (this.Es) throw new Error("Recording is already started.");
            return csArray.prototype.push.call(this.Th, t), () => this.Th = csArray.prototype.filter.call(this.Th, (s => s !== t))
        }
    }
    class Gr extends gn {
        constructor(t) {
            super(), this.Fi = t
        }
        subscribe(t) {
            return super.subscribe(t)
        }
        onStart() {
            Ms(this.Fi, (t => {
                t.onEvent((t => this.pe(t)))
            })), Ms(this.Fi, (t => {
                var s;
                null === (s = t.start) || void 0 === s || s.call(t)
            }))
        }
        onStop() {
            Ms(this.Fi, (t => {
                var s;
                return null === (s = t.stop) || void 0 === s ? void 0 : s.call(t)
            }))
        }
        pe(t) {
            this.produceEvent({
                timestamp: Vt.now(),
                type: "Legacy",
                originalEvent: t
            })
        }
    }

    function Zr(t) {
        const s = function(t) {
            const s = {
                type: Wr(t.type)
            };
            for (const e in t) {
                const i = t[e];
                void 0 !== i && "type" !== e && (s[e] = i)
            }
            return s
        }(t.data);
        return {
            type: fe.GESTURE_RECOGNITION,
            args: [t.targetId, s],
            date: t.timestamp
        }
    }

    function Wr(t) {
        switch (t) {
            case _r.DRAG:
            case _r.FLICK:
                return ve.SWIPE;
            case _r.LONG_PRESS:
                return ve.LONG_PRESS;
            case _r.TAP:
                return ve.TAP;
            case _r.PINCH_IN:
                return ve.PINCH_IN;
            case _r.PINCH_OUT:
                return ve.PINCH_OUT
        }
    }

    function Qr(t) {
        return function(t, s) {
            let e = [];
            return {
                push(t) {
                    csArray.prototype.push.call(e, t), e.length === s.batchSize && this.flush()
                },
                flush() {
                    if (!e.length) return;
                    const s = e;
                    e = [], t(s)
                }
            }
        }((s => {
            const e = {
                    visibleInViewPort: s
                },
                i = {
                    type: fe.TEXT_VISIBILITY,
                    date: Vt.now(),
                    args: [e]
                };
            t(i)
        }), {
            batchSize: 20
        })
    }
    var Jr;
    ! function(t) {
        t.REQUEST_START = "requestStart", t.DOM_INTERACTIVE = "domInteractive", t.TIME_ORIGIN = "timeOrigin"
    }(Jr || (Jr = {}));
    let Kr = 0;
    class Yr {
        get pendingEvents() {
            return this.Dc.pendingEvents
        }
        constructor(t, s, e, i, n) {
            this.Dc = t, this.Uc = s, this.qc = e, this.Gi = i, this.Zi = n, this.Fc = () => {}, this.Hc = () => {}, this.Bc = Qr((t => this.Fc(t)))
        }
        start() {
            var t, s;
            this.jc = {
                processEvent(t, s) {
                    if (t.originalEvent.type === fe.PERFORMANCE_RESOURCE_TIMING) return Kr >= 500 ? null : (Kr += 1, s({ ...t.originalEvent,
                        date: t.timestamp
                    }));
                    s(t.originalEvent)
                },
                reset() {
                    Kr = 0
                }
            }, this.Dc.subscribe((t => {
                var s, e, i, n, r;
                const o = t,
                    {
                        timestamp: h
                    } = o;
                switch (o.type) {
                    case "Legacy":
                        this.jc.processEvent(o, this.Fc);
                        break;
                    case "CustomElementRegistration":
                        this.Fc({
                            type: fe.CUSTOM_ELEMENT_REGISTRATION,
                            date: h,
                            args: [o.tagName]
                        });
                        break;
                    case "DomEvent":
                        ! function(t, s, e) {
                            const {
                                timestamp: i
                            } = t;
                            switch (t.domEvent) {
                                case "initialDOM":
                                    {
                                        const {
                                            initialDOM: s
                                        } = t,
                                        n = {
                                            type: fe.INITIAL_DOM,
                                            date: i,
                                            args: [s]
                                        };e.emitInitialDomDone(n);
                                        break
                                    }
                                case "nodesAdded":
                                    csArray.prototype.forEach.call(t.nodes, (e => {
                                        s({
                                            type: fe.MUTATION_INSERT,
                                            date: i,
                                            args: [t.target, t.nextSibling, e]
                                        })
                                    }));
                                    break;
                                case "nodesMoved":
                                    for (const e of t.nodesIds) s({
                                        type: fe.MUTATION_MOVE,
                                        date: i,
                                        args: [e, t.nextSibling, t.target]
                                    });
                                    break;
                                case "nodesRemoved":
                                    csArray.prototype.forEach.call(t.nodesIds, (t => {
                                        s({
                                            type: fe.MUTATION_REMOVE,
                                            date: i,
                                            args: [t]
                                        })
                                    }));
                                    break;
                                case "attributeChanged":
                                    {
                                        const {
                                            target: e,
                                            namespace: n,
                                            attribute: r,
                                            newValue: o
                                        } = t;s({
                                            type: fe.MUTATION_ATTRIBUTE,
                                            date: i,
                                            args: [e, n, r, o]
                                        });
                                        break
                                    }
                                case "characterDataChanged":
                                    {
                                        const {
                                            target: e,
                                            newValue: n
                                        } = t;s({
                                            type: fe.MUTATION_CHARACTER_DATA,
                                            date: i,
                                            args: [e, n]
                                        });
                                        break
                                    }
                                case "cssRuleInserted":
                                    {
                                        const {
                                            target: e,
                                            rule: n,
                                            index: r
                                        } = t,
                                        o = Et(r) ? [e, n, r] : [e, n];s({
                                            type: fe.STYLESHEET_RULE_INSERT,
                                            date: i,
                                            args: o
                                        });
                                        break
                                    }
                                case "cssRuleDeleted":
                                    {
                                        const {
                                            target: e,
                                            index: n
                                        } = t;s({
                                            type: fe.STYLESHEET_RULE_DELETE,
                                            date: i,
                                            args: [e, n]
                                        });
                                        break
                                    }
                                case "cssRuleUpdated":
                                    {
                                        const {
                                            target: e,
                                            rule: n,
                                            index: r
                                        } = t;s({
                                            type: fe.STYLESHEET_RULE_UPDATE,
                                            date: i,
                                            args: [e, n, r]
                                        });
                                        break
                                    }
                                case "shadowRootAttached":
                                    {
                                        const {
                                            target: e,
                                            shadowRoot: n
                                        } = t;s({
                                            type: fe.ATTACH_SHADOW,
                                            date: i,
                                            args: [e, n]
                                        });
                                        break
                                    }
                                case "adoptedStyleSheetRegistered":
                                    {
                                        const {
                                            sheetId: e,
                                            cssRules: n
                                        } = t;s({
                                            type: fe.REGISTER_ADOPTED_STYLE_SHEET,
                                            date: i,
                                            args: [e, {
                                                cssRules: n
                                            }]
                                        });
                                        break
                                    }
                                case "adoptedStyleSheetsSet":
                                    {
                                        const {
                                            target: e,
                                            sheetsIds: n
                                        } = t;s({
                                            type: fe.SET_ADOPTED_STYLE_SHEETS,
                                            date: i,
                                            args: [e, n]
                                        });
                                        break
                                    }
                                case "adoptedStyleSheetRuleInserted":
                                    {
                                        const {
                                            sheetId: e,
                                            rule: n,
                                            index: r
                                        } = t,
                                        o = Et(r) ? [e, n, r] : [e, n];s({
                                            type: fe.ADOPTED_STYLESHEET_RULE_INSERT,
                                            date: i,
                                            args: o
                                        });
                                        break
                                    }
                                case "adoptedStyleSheetRuleDeleted":
                                    {
                                        const {
                                            sheetId: e,
                                            index: n
                                        } = t;s({
                                            type: fe.ADOPTED_STYLESHEET_RULE_DELETE,
                                            date: i,
                                            args: [e, n]
                                        });
                                        break
                                    }
                                case "adoptedStyleSheetRuleUpdated":
                                    {
                                        const {
                                            sheetId: e,
                                            rule: n,
                                            index: r
                                        } = t,
                                        o = [e, n, r];s({
                                            type: fe.ADOPTED_STYLESHEET_RULE_UPDATE,
                                            date: i,
                                            args: o
                                        });
                                        break
                                    }
                                default:
                                    ns.error("translateDOMEvent: DOMEvent not supported")
                            }
                        }(o, this.Fc, this.Uc);
                        break;
                    case "InputEvent":
                        {
                            const t = function(t) {
                                switch (t.inputType) {
                                    case "text":
                                        return {
                                            type: fe.INPUT_TEXT,
                                            args: [t.target, t.value],
                                            date: t.timestamp
                                        };
                                    case "select":
                                        return {
                                            type: fe.INPUT_SELECT,
                                            args: [t.target, t.selectedIndex],
                                            date: t.timestamp
                                        };
                                    case "checkable":
                                        return {
                                            type: fe.INPUT_CHECKABLE,
                                            args: [t.target, t.checked],
                                            date: t.timestamp
                                        }
                                }
                            }(o);null === (s = this.Hc) || void 0 === s || s.call(this, t);
                            break
                        }
                    case "encryptedCharacterDataChanged":
                        {
                            const {
                                target: t,
                                rawData: s,
                                encryptedData: e,
                                encryptionMetadata: i
                            } = o;this.Fc({
                                type: fe.MUTATION_ENCRYPTED_CHARACTER_DATA,
                                date: h,
                                args: [t, s, e, i]
                            });
                            break
                        }
                    case "StaticResource":
                        {
                            const {
                                url: t
                            } = o;this.Fc({
                                type: fe.STATIC_RESOURCE_URL,
                                date: h,
                                args: [t]
                            });
                            break
                        }
                    case "ResizeMaskedElement":
                        {
                            const {
                                target: t,
                                width: s,
                                height: e
                            } = o;this.Fc({
                                type: fe.MUTATION_ATTRIBUTE,
                                date: h,
                                args: [t, "", "style", `width:${s}px !important;height:${e}px !important;`]
                            });
                            break
                        }
                    case "Gesture":
                        {
                            const s = Zr(t);null === (e = this.Hc) || void 0 === e || e.call(this, s);
                            break
                        }
                    case "TextVisibility":
                        this.Bc.push(o.text);
                        break;
                    case "StaticResourceManagerEvent":
                        null === (i = this.qc) || void 0 === i || i.processEvent(o);
                        break;
                    case "screenResize":
                        {
                            const {
                                width: t,
                                height: s
                            } = o,
                            e = {
                                type: fe.SCREEN_RESIZE,
                                date: h,
                                args: [t, s]
                            };this.Fc(e);
                            break
                        }
                    case "viewportResize":
                        {
                            const {
                                width: t,
                                height: s
                            } = o,
                            e = {
                                type: fe.RESIZE,
                                date: h,
                                args: [t, s]
                            };this.Fc(e);
                            break
                        }
                    case "PerformanceTiming":
                        this.Fc(function(t) {
                            return {
                                type: fe.PERFORMANCE_TIMINGS,
                                args: [{
                                    performanceTiming: Jr.REQUEST_START,
                                    timestamp: t.timings.requestStart
                                }, {
                                    performanceTiming: Jr.DOM_INTERACTIVE,
                                    timestamp: t.timings.domInteractive
                                }, {
                                    performanceTiming: Jr.TIME_ORIGIN,
                                    timestamp: t.timings.timeOrigin
                                }],
                                date: t.timestamp
                            }
                        }(o));
                        break;
                    case "CustomError":
                        {
                            const t = null === (n = this.Zi) || void 0 === n ? void 0 : n.translate(o);t && this.Fc(t);
                            break
                        }
                    case "JSError":
                        {
                            const t = null === (r = this.Gi) || void 0 === r ? void 0 : r.translate(o);t && this.Fc(t);
                            break
                        }
                    case "VideoEvent":
                        {
                            const t = function(t) {
                                switch (t.videoEventType) {
                                    case "play":
                                        return {
                                            type: fe.VIDEO_PLAY,
                                            args: [t.nodeId],
                                            date: t.timestamp
                                        };
                                    case "pause":
                                        return {
                                            type: fe.VIDEO_PAUSE,
                                            args: [t.nodeId],
                                            date: t.timestamp
                                        };
                                    case "seeked":
                                        {
                                            const s = t;
                                            return {
                                                type: fe.VIDEO_SEEK,
                                                args: [s.nodeId, s.newTimePositionInSec],
                                                date: t.timestamp
                                            }
                                        }
                                    default:
                                        return null
                                }
                            }(o);t && this.Fc(t);
                            break
                        }
                    case "Debug":
                        this.Fc({
                            type: fe.DEBUG,
                            date: h,
                            args: [o.key, o.value]
                        });
                        break;
                    case "warning":
                        ns.warn(o.message);
                        break;
                    default:
                        ns.error(`WebRecorderEventTranslator: Event not supported (${o.type})`)
                }
            })), this.Uc.emitInitialDomStart(), null === (t = this.Gi) || void 0 === t || t.start(), null === (s = this.Zi) || void 0 === s || s.start(), this.Dc.start()
        }
        stop() {
            var t, s, e;
            this.reset(), this.flush(), this.Dc.stop(), null === (t = this.qc) || void 0 === t || t.flushEvents(), null === (s = this.Gi) || void 0 === s || s.stop(), null === (e = this.Zi) || void 0 === e || e.stop()
        }
        flush() {
            this.Bc.flush()
        }
        onEvent(t, s) {
            var e;
            this.Fc = t, this.Hc = s, null === (e = this.qc) || void 0 === e || e.onEvent((t => this.Fc(t)))
        }
        reset() {
            this.jc.reset()
        }
    }
    class Xr {
        constructor(t = 100) {
            this.zc = t, this.Gc = {}, this.Zc = null, this.ai = "original-resource-name"
        }
        onEvent(t) {
            this.Wc = t
        }
        processEvent(t) {
            this.Qc(t.resourceId, t.resource.hash, t.originalResourceName), this.Jc(t)
        }
        flushEvents() {
            this.Zc && csClearTimeout(this.Zc), this.Kc()
        }
        onSendStaticResource(t) {
            this.Jc = t
        }
        Kc() {
            if (!Object.keys(this.Gc).length) return;
            const t = {
                type: fe.RESOURCE_HASHES,
                date: Vt.now(),
                args: [this.Gc]
            };
            this.Zc = null, this.Gc = {}, this.Wc(t)
        }
        Qc(t, s, e) {
            let i = s;
            e && (i += `?${this.ai}=${e}`), this.Gc[t] = i, this.Zc || (this.Zc = window.csSetTimeout((() => this.Kc()), this.zc))
        }
    }
    class to {
        constructor(t, s, e) {
            this.Uc = t, this.Y = s, this.Yc = e, this.Xc = ze.ETR_DISABLED, this.ta = ze.ETR_PENDING, this.sa = !0
        }
        getEtrStatus() {
            const t = this.Y.getSession(),
                s = null == t ? void 0 : t.etrStatus;
            return this.ea() && s === ze.ETR_SAVED_SESSION ? s : this.Xc
        }
        onEventTriggerRecording(t, s) {
            switch (s) {
                case je.ETR_PAGE:
                    this.ia(ze.ETR_SAVED_PAGE);
                    break;
                case je.ETR_LEGACY:
                case je.ETR_SESSION:
                    this.ia(ze.ETR_SAVED_SESSION)
            }
        }
        handleCollectStateChange(t) {
            this.sa = !1, t ? this.na(this.ta) : this.na(ze.ETR_DISABLED)
        }
        handleArtificialPageview() {
            this.Yc ? (this.sa = !0, this.na(ze.ETR_DISABLED)) : this.ea() && this.na(ze.ETR_PENDING)
        }
        handleSessionRenewal() {
            this.sa = !0, this.na(ze.ETR_DISABLED)
        }
        na(t) {
            this.Xc = t, this.ta = ze.ETR_PENDING, this.ra(t), this.Uc.emitRecordingContextChange()
        }
        ia(t) {
            this.sa ? Number(t) > Number(this.ta) && (this.ta = t) : this.ea() && Number(t) > Number(this.Xc) && (this.Xc = t, this.ra(t), this.Uc.emitRecordingContextChange())
        }
        ra(t) {
            const s = this.Y.getSession();
            null !== s && s.etrStatus === ze.ETR_NOT_SAVED_SESSION && t === ze.ETR_SAVED_SESSION && (s.etrStatus = t, this.Y.setSession(s))
        }
        ea() {
            return this.Xc !== ze.ETR_DISABLED
        }
    }

    function so(t, s) {
        let e, i, n, r, o = null;
        const h = c => {
                const a = Vt.elapsed();
                if (!c && null !== o) {
                    const t = s - (a - o);
                    if (t > 0) return void(i = window.csSetTimeout(h, t))
                }
                const u = a - n;
                i = null, o = null, n = null, r = t(u, ...e)
            },
            c = (...t) => {
                if (e = [...t], !n) return n = Vt.elapsed(), i = window.csSetTimeout(h, s), r;
                o = Vt.elapsed()
            };
        return c.flushPending = () => {
            i && (window.csClearTimeout(i), h(!0))
        }, c.cancel = () => {
            o = null, n = null, i && (window.csClearTimeout(i), i = null)
        }, c
    }

    function eo(t = 0) {
        return (s, e, i) => {
            const n = i.value;
            let r = !1;
            i.value = function(...s) {
                r || (r = !0, csSetTimeout((() => {
                    r = !1, n.apply(this, s)
                }), t))
            }
        }
    }
    var io;
    ! function(t) {
        t[t.NOT_EXIST = 2] = "NOT_EXIST"
    }(io || (io = {}));
    class no extends Fe {
        constructor(t, s, e) {
            super(), this.qc = t, this.oa = s, this.ha = e, this.ca = {}, this.aa = new Set, this.Lc = !1
        }
        initState() {
            kt() && (this.ua = this.ha.getRequestParameters(), this.da = `${this.oa}/exist?${Y.toQuery(this.ua)}`, this.fa = `${this.oa}/putTag?${Y.toQuery(this.ua)}`, this.pa = so((async () => {
                if (this.Lc) this.pa();
                else {
                    this.Lc = !0;
                    try {
                        await this.ma()
                    } finally {
                        this.Lc = !1
                    }
                }
            }), 300), this.qc.onSendStaticResource((t => {
                this.va(t)
            })))
        }
        onStart() {}
        onStop() {}
        onIframeStaticResource(t) {
            this.va(t)
        }
        va(t) {
            this.ga(t.resource.hash, t.resource.data), t.nestedResources && t.nestedResources.length > 0 && csArray.prototype.forEach.call(t.nestedResources, (t => {
                this.ga(t.hash, t.data)
            }))
        }
        ga(t, s) {
            this.aa.has(t) || (this.aa.add(t), this.ca[t] = s, this.pa())
        }
        async ma() {
            const t = this.ca;
            this.ca = {};
            const s = await this.ya(t);
            if (!s.length) return;
            const e = this.wa(s);
            await Promise.all(csArray.prototype.map.call(e, (t => window.fetch(this.fa, {
                method: "POST",
                body: t
            }))))
        }
        async Ea(t) {
            try {
                const s = Object.keys(t);
                if (!s.length) return [];
                const e = {
                        projectId: this.ua.pid,
                        filter: io.NOT_EXIST,
                        hashes: s,
                        touch: !0
                    },
                    i = await window.fetch(this.da, {
                        method: "POST",
                        body: csJSON.stringify(e)
                    });
                return await i.json()
            } catch (t) {
                return []
            }
        }
        async ya(t) {
            const s = [],
                e = await this.Ea(t);
            return csArray.prototype.forEach.call(e, (e => {
                const i = t[e];
                i ? csArray.prototype.push.call(s, {
                    hash: e,
                    data: i
                }) : ns.warn("SRM: received unknown hash: " + e)
            })), s
        }
        wa(t) {
            let s = 0;
            const e = [new FormData];
            for (const i of t) {
                const {
                    data: t,
                    hash: n
                } = i, r = e.length - 1;
                if (s += t.size, s < 8388608) e[r].append("", t, n);
                else {
                    const i = new FormData;
                    i.append("", t, n), s = t.size, csArray.prototype.push.call(e, i)
                }
            }
            return e
        }
    }
    class ro {
        constructor(t) {
            this.Aa = t, this._a = 20, this.Sa = 0, this.se = !1
        }
        translate(t) {
            if (this.Sa >= this._a) return this.Aa.stop(), null;
            this.Sa += 1;
            const {
                filename: s,
                message: e,
                lineno: i,
                colno: n,
                timestamp: r
            } = t;
            return {
                type: fe.JAVASCRIPT_ERROR,
                date: r,
                args: [{
                    errorType: "jsError",
                    message: e,
                    filename: s,
                    lineno: i,
                    colno: n
                }]
            }
        }
        start() {
            this.se || (this.Sa = 0, this.se = !0)
        }
        stop() {
            this.se = !1
        }
    }
    class oo {
        constructor() {
            this._a = 20, this.Ra = 0, this.se = !1
        }
        translate(t) {
            if (this.Ra >= this._a) return null;
            this.Ra += 1;
            const {
                message: s,
                attributes: e,
                timestamp: i
            } = t;
            return {
                type: fe.CUSTOM_ERROR,
                date: i,
                args: [{
                    errorType: "customError",
                    message: s,
                    attributes: e
                }]
            }
        }
        start() {
            this.se || (this.Ra = 0, this.se = !0)
        }
        stop() {
            this.se = !1
        }
    }
    const ho = ["id", "class", "style", "src", "srcset", "sizes", "href", "rel", "type", "width", "height", "media", "align", "dir", "bgcolor", "color", "border", "colspan", "rowspan", "cols", "rows", "size", "start", "slot", N],
        co = t => !ui(t) && !di(t),
        ao = "v2/recording",
        uo = ["setCapturedElementsSelector"],
        lo = ["setEncryptionSelectors"],
        fo = ["isRecording"],
        po = ["replay:resourceManager:enableForOnlineResource:nextPageviewOnly", "cssrm:onlineAssets:activateForNextPageview"],
        mo = ["replay:resourceManager:getStatus", "cssrm:getStatus"];
    class vo {
        constructor(t, s, e, i, n, r, o, h, c, a, u, l, d, f, p, m, v, g, y, w) {
            this.Ta = t, this.Y = s, this.D = e, this.ua = i, this.Ia = n, this.U = r, this.Oi = o, this.ba = h, this.Ni = c, this.xi = a, this.$i = u, this.Pa = l, this.Uc = d, this.Va = f, this.Ca = p, this.ka = m, this.Oa = v, this.Na = g, this.zi = y, this.xa = w
        }
        init() {
            var t;
            const s = [],
                e = [];
            csArray.prototype.push.call(e, new jn), this.$a = new ur(this.xa.shouldUseAnonymization(), (t => {
                const s = new Set;
                csArray.prototype.forEach.call(ho, (t => {
                    s.add(t)
                })), csArray.prototype.forEach.call(t.whitelistedAttributes, (t => {
                    s.add(t)
                }));
                const e = t.isSMB ? {
                    href: co
                } : void 0;
                return {
                    allWhitelistedAttributes: s,
                    attributesCheckers: e
                }
            })(this.D), (t => this.U.checkAndAnonymizePII(t, this.D.anonymizeDigits))), this.La();
            const i = new Bn("csPersisted");
            this.Ma(i);
            const n = new Ue;
            this.Pi = new De;
            const r = new Dn;
            csArray.prototype.push.call(s, r), this.D.useStaticResourceManager && Vn.isSupported() && (this.ji = new Vn, this.qc = new Xr, this.Da = new no(this.qc, this.D.getStaticResourceManagerUri(), this.ua), this.Ca.addListener(this.Da), csArray.prototype.push.call(e, this.ji));
            const o = new On(n, this.ua, {
                    getRequestParameters: () => ({
                        let: this.recordingService.getRecordingLastEventTimestamp()
                    })
                }, {
                    getRequestParameters: () => ({
                        rst: this.recordingService.getRecordingStartTimestamp()
                    })
                }, {
                    getRequestParameters: () => ({
                        rt: csArray.prototype.join.call(this.Y.getCollectStates(), ",")
                    })
                }),
                h = new Un(`${this.D.getRecordingUri()}/${ao}`);
            csArray.prototype.push.call(e, this.$a), csArray.prototype.push.call(e, new dr), this.ki = new Le, this.ki.init(), this.Di = new kn(i, h, this.Mi), csArray.prototype.push.call(s, new Nn(window.location, this.U));
            const c = new wn,
                a = new pr,
                u = [new mr({
                    version: "15.28.0",
                    visibilityState: document.visibilityState
                }), this.ba, c, new Gr(csArray.prototype.filter.call(s, (t => t))), new Rr, new Tr, new br, new kr, new $r(this.Li), a];
            this.D.textVisibilityEnabled && ir.isSupported() && (this.Ua = new ar, csArray.prototype.push.call(u, this.Ua)), this.D.jsErrorsEnabled && (this.Aa = new Mr, this.qa = new Dr((t => this.Ni.anonymize(t))), this.Gi = new ro(this.Aa), csArray.prototype.push.call(u, this.Aa), csArray.prototype.push.call(e, this.qa)), (null === (t = this.D.customErrors) || void 0 === t ? void 0 : t.enabled) && (this.Zi = new oo);
            const l = new zr(u, e);
            ri.general.push(new si("Pending Events", (() => l.pendingEvents)));
            const d = new Yr(l, this.Uc, this.qc, this.Gi, this.Zi);
            this.recordingService = new Cn(this.D, this.Pi, o, n, this.ki, this.Oi, this.Y, this.Ni, this.xi, this.$i, this.Li, this.Mi, this.Di, h, d, s, c, a, this.ji, this.zi, this.Gi, this.Zi), this.Va.addListener(this.recordingService), this.Ca.addListener(this.recordingService), this.recordingService.init(), this.Ia.register(fo, (() => this.Y.isReplayRecorded() && !this.ka.isUrlExcludedForSessionReplay())), this.Ia.register(po, (() => {
                this.recordingService.activateOnlineAssetsOnNextPageview(), this.Uc.emitRecordingContextChange()
            })), this.Ia.register(mo, (() => this.recordingService.getStaticResourceManagerStatus())), this.Fa = new to(this.Uc, this.Y, this.D.malkaUrlEnabled), this.Va.addListener(this.Fa), this.Ta.enableRecordingContext(this.recordingService, this.Y, this.Li, this.Fa)
        }
        onAfterNaturalPageView() {
            var t;
            null === (t = this.Da) || void 0 === t || t.initState()
        }
        onStartTracking() {
            this.Di.recover(), this.La(), this.Y.isReplayRecorded() && !this.ka.isUrlExcludedForSessionReplay() && (this.Y.isTemporarilyRecorded() && this.recordingService.blockSendingEventsFromQuotaService(), this.Ha())
        }
        onArtificialPageViewEnd() {
            !this.Y.isReplayRecorded() || this.ka.isUrlExcludedForSessionReplay() || this.Y.isTemporarilyRecorded() || this.Di.sendLastMessageBeacon(), this.recordingService.clearStates()
        }
        onBeforeArtificialPageView() {
            this.Fa.handleArtificialPageview()
        }
        onAfterArtificialPageView() {
            this.La(), this.Y.isReplayRecorded() && !this.ka.isUrlExcludedForSessionReplay() ? (this.Y.isTemporarilyRecorded() && this.recordingService.blockSendingEventsFromQuotaService(), this.Ba()) : this.ja()
        }
        onBeforeSessionRenewal() {
            this.Fa.handleSessionRenewal(), this.recordingService.clearStates(), this.ja()
        }
        onOptout() {
            this.ja(), this.recordingService.onOptOut()
        }
        onReplayUnanonymizationConsentGranted() {
            this.La(), this.recordingService.triggerUnanonymizationConsentGranted(), this.Uc.emitRecordingContextChange()
        }
        onReplayUnanonymizationConsentWithdrawn() {
            this.La(), this.recordingService.triggerUnanonymizationConsentWithdrawn(), this.Uc.emitRecordingContextChange()
        }
        onCollectStateChange(t, s) {
            if (t === He.QUOTA_REACHED || t === He.ANALYTICS_ONLY && s === Be.ETR_OFF) this.recordingService.clearEvents(), this.ja();
            else {
                this.Mi.setQueryParams({
                    rt: csArray.prototype.join.call(this.Y.getCollectStates(), ",")
                }), this.recordingService.allowSendingEventsFromQuotaService(), this.recordingService.pushEvents();
                const e = t === He.ANALYTICS_ONLY && s === Be.ETR_ON;
                this.Fa.handleCollectStateChange(e)
            }
        }
        onInitialDomStart() {
            this.recordingService.blockSendingEventsFromSerialization(), this.Di.blockSendingLastMessage()
        }
        onInitialDomDone(t) {
            this.recordingService.allowSendingEventsFromSerialization(), this.recordingService.addInitialDom(t), this.Di.allowSendingLastMessage(), this.ki.start(), this.recordingService.pushEvents()
        }
        onAfterReplayRecordingConsentGranted() {
            this.Y.isReplayRecorded() && !this.ka.isUrlExcludedForSessionReplay() && (this.Y.isTemporarilyRecorded() && this.recordingService.blockSendingEventsFromQuotaService(), this.Ha(), this.recordingService.triggerRecordingForSessionGranted())
        }
        onAfterReplayRecordingConsentWithdrawn() {
            this.recordingService.isRecording() && (this.recordingService.triggerRecordingForSessionWithdrawn(), this.recordingService.clearStates(), this.ja())
        }
        za() {
            var t, s, e, i;
            if (null === (s = null === (t = this.D.experimental.sessionReplay) || void 0 === t ? void 0 : t.shadowRoot) || void 0 === s ? void 0 : s.filterByHostSelector) {
                Ms(null === (i = null === (e = this.D.experimental.sessionReplay) || void 0 === e ? void 0 : e.shadowRoot) || void 0 === i ? void 0 : i.filterByHostSelector, (t => {
                    Ne(t) && nn.setShadowRootFilter((s => {
                        try {
                            return Ce.call(s.host, t)
                        } catch {
                            return !1
                        }
                    }))
                }))
            }
        }
        Ha() {
            this.za(), this.recordingService.updateStaticResourceManagerOnlineAssets(), this.recordingService.start(), this.Di.start(), this.Uc.emitRecordingContextChange()
        }
        ja() {
            ! function(t = !1) {
                t && (Te = 1), Ie = csSymbol("nodeIdentifier")
            }(), this.recordingService.stop(), this.Di.stop(), this.Uc.emitRecordingContextChange()
        }
        Ba() {
            this.ja(), this.Ha()
        }
        Ma(t) {
            this.Mi = this.Oa.create(`${this.D.getRecordingUri()}/${ao}`, !0, "byteArray", t, ["rt", "v", "pid", "pn", "sn", "uu"])
        }
        La() {
            var t;
            const s = this.xa.shouldUseAnonymization();
            this.$a.setAnonymization(s), null === (t = this.Ua) || void 0 === t || t.setAnonymization(s)
        }
    }
    var go, yo;
    As([Es("Recording.onStartTracking")], vo.prototype, "onStartTracking", null), As([Es("onInitialDomDone")], vo.prototype, "onInitialDomDone", null),
        function(t) {
            t[t.NOT_NEEDED = 1] = "NOT_NEEDED", t[t.NOT_EXPRESSED = 2] = "NOT_EXPRESSED", t[t.WITHDRAWN = 3] = "WITHDRAWN", t[t.GRANTED = 4] = "GRANTED"
        }(go || (go = {})),
        function(t) {
            t.isReplayConsentNeeded = function(t) {
                return t.replayConsentRequiredForSession
            }, t.isRecordingBlockedByConsent = function(t) {
                return t.collectState === He.RECORDING_BLOCKED_BY_CONSENT_NOT_EXPRESSED || t.collectState === He.RECORDING_BLOCKED_BY_CONSENT_WITHDRAWN
            }, t.isRecordingWithDrawn = function(t) {
                return t.collectState === He.RECORDING_BLOCKED_BY_CONSENT_WITHDRAWN
            }
        }(yo || (yo = {}));
    class wo {
        constructor(t, s, e, i) {
            this.K = t, this.Y = s, this.D = e, this.Ga = i, this.Za = !1
        }
        isNaturalPageViewSent() {
            return this.Za
        }
        setNaturalPageViewSent(t) {
            this.Za = t
        }
        getTrackingContext() {
            const t = this.Y.getSession();
            if (!t) return null;
            const s = this.getSessionKey();
            if (!s) return null;
            const e = this.D.projectId,
                i = this.D.uxaDomain;
            return {
                projectId: e,
                sessionKey: s,
                pageNumber: t.pageNumber,
                pageViewType: this.Ga.getPageViewType(),
                isRecording: this.Y.isReplayRecorded(),
                uxaDomain: i,
                recordingConsentState: this.Wa(t),
                ...this.D.smbConfig
            }
        }
        getSessionKey() {
            const t = this.K.getVisitor();
            return t ? `${t.id}.${t.visitsCount}` : null
        }
        Wa(t) {
            return yo.isReplayConsentNeeded(this.D) ? t.collectState === He.RECORDING_BLOCKED_BY_CONSENT_NOT_EXPRESSED ? go.NOT_EXPRESSED : t.collectState === He.RECORDING_BLOCKED_BY_CONSENT_WITHDRAWN ? go.WITHDRAWN : go.GRANTED : go.NOT_NEEDED
        }
    }
    class Eo {
        constructor(t) {
            this.Qa = t, this.Ja = []
        }
        handleCommand(t) {
            if (_t(t) && (this.Ka(t), this.Qa.isNaturalPageViewSent())) {
                const s = this.Qa.getTrackingContext();
                null !== s && this.Ya(t, s)
            }
        }
        Ka(t) {
            csArray.prototype.push.call(this.Ja, t)
        }
        executeRegisteredCallbacks() {
            const t = this.Qa.getTrackingContext();
            null !== t && csArray.prototype.map.call(this.Ja, (s => this.Ya(s, t)))
        }
        Ya(t, s) {
            csSetTimeout((() => {
                t(s)
            }))
        }
    }
    class Ao {
        constructor(t) {
            this.Qa = t, this.Xa = []
        }
        handleCommand(t) {
            return this.Qa.isNaturalPageViewSent() ? this.tu(t) : void this.su(t)
        }
        tu(t) {
            const s = this.Qa.getSessionKey();
            return this.eu(t) && null !== s && this.Ya(t.callback, s), s
        }
        su(t) {
            this.eu(t) && csArray.prototype.push.call(this.Xa, t.callback)
        }
        flushPendingCallbacks() {
            const t = this.Qa.getSessionKey();
            null !== t && csArray.prototype.forEach.call(this.Xa, (s => {
                this.Ya(s, t)
            })), this.Xa = []
        }
        eu(t) {
            return t && "function" == typeof t.callback
        }
        Ya(t, s) {
            csSetTimeout((() => {
                t(s)
            }))
        }
    }
    class _o {
        constructor(t, s) {
            this.iu = t, this.Qa = s
        }
        onTrackingContextRequestCallback(t) {
            const s = this.Qa.getTrackingContext();
            null !== s && this.iu.sendToChildren(Xt.TrackingContextResultMessage, { ...t,
                trackingContext: s
            })
        }
        onIframeIntegrationCallback(t) {
            if (!this.Qa.isNaturalPageViewSent()) return;
            const s = this.Qa.getTrackingContext();
            null !== s && (t.trackingContext = s, this.iu.sendToChildren(Xt.IntegrationCallback, t))
        }
        sendAfterPageViewCallbackToChildren() {
            const t = this.Qa.getTrackingContext();
            if (null === t) return;
            const s = {
                trackingContext: t,
                initiator: Kt.AfterPageView
            };
            this.iu.sendToChildren(Xt.IntegrationCallback, s)
        }
    }
    class So {
        constructor(t) {
            this.Qa = t
        }
        handleCommand(t, s) {
            wt(t) && _t(s) && this.Ya(t, s)
        }
        Ya(t, s) {
            csSetTimeout((() => {
                const e = this.Qa.getTrackingContext();
                if (e) {
                    const i = function(t, s) {
                        const {
                            isRecording: e,
                            pageNumber: i,
                            projectId: n,
                            siteId: r,
                            uxaDomain: o,
                            csLiteDomain: h
                        } = t, c = /^(.+)\.(\d+)$/.exec(t.sessionKey);
                        let a;
                        if (e && c) {
                            const [, t, e] = c;
                            a = r ? `${h}/sites/${r}/player?uu=${t}&sn=${e}&pn=${i}&` : `${o}/quick-playback/index.html?pid=${n}&uu=${t}&sn=${e}&pvid=${i}&recordingType=cs`, s.withTimestamp && (a += "&t=" + (Vt.now() - s.recordingStartTimestamp))
                        }
                        return {
                            replayLink: a,
                            isRecording: e
                        }
                    }(e, t);
                    s(i)
                }
            }))
        }
    }
    class Ro {
        constructor() {
            this.Ja = new Set
        }
        handleCommand(t, s) {
            return _t(t) ? this.Ja.has(t) ? null : (this.Ja.add(t), s && (this.Br = s, this.nu(t, s)), () => this.Ja.delete(t)) : null
        }
        executeCallbacks(t) {
            this.ru(t) && (this.Br = t, this.Ja.forEach((s => this.nu(s, t))))
        }
        nu(t, s) {
            csSetTimeout((() => {
                try {
                    t(s)
                } catch (t) {}
            }))
        }
        ru(t) {
            const {
                isRecording: s,
                recordingStartTimestamp: e,
                etrState: i,
                etrStatus: n
            } = t;
            return this.Br && (this.Br.isRecording !== s || this.Br.recordingStartTimestamp !== e || this.Br.etrState !== i || this.Br.etrStatus !== n)
        }
    }
    const To = ["afterPageView"],
        Io = ["getSessionKey"],
        bo = ["onRecordingContextChange", "onRecordingStateChange"],
        Po = ["replay:link:generate"];
    class Vo {
        constructor(t, s, e, i, n, r, o, h) {
            this.K = t, this.Y = s, this.Ia = e, this.ou = i, this.iu = n, this.D = r, this.Ga = o, this.Ta = h
        }
        init() {
            this.Qa = new wo(this.K, this.Y, this.D, this.Ga), this.hu = new Eo(this.Qa), this.au = new Ao(this.Qa), this.lu = new Ro, this.du = new So(this.Qa), this.fu = new _o(this.iu, this.Qa), this.ou.addListener(this.fu), this.Ia.register(Io, (t => this.au.handleCommand(t))), this.Ia.register(To, (t => this.hu.handleCommand(t))), this.Ia.register(bo, (t => {
                this.lu.handleCommand(t, this.Ta.getRecordingContext())
            })), this.Ia.register(Po, ((t, s) => {
                this.pu && this.du.handleCommand({ ...t,
                    recordingStartTimestamp: this.Ta.getRecordingContext().recordingStartTimestamp
                }, s)
            }))
        }
        onAfterNaturalPageView() {
            this.Qa.setNaturalPageViewSent(!0), this.au.flushPendingCallbacks(), this.hu.executeRegisteredCallbacks(), this.fu.sendAfterPageViewCallbackToChildren()
        }
        onAfterArtificialPageView() {
            this.hu.executeRegisteredCallbacks(), this.fu.sendAfterPageViewCallbackToChildren()
        }
        onCollectStateChange() {
            this.executeRecordingContextChangeCallbacks()
        }
        onRecordingContextChange() {
            this.executeRecordingContextChangeCallbacks()
        }
        executeRecordingContextChangeCallbacks() {
            this.lu.executeCallbacks(this.Ta.getRecordingContext())
        }
        setRecordingService(t) {
            this.pu = t
        }
    }
    As([eo()], Vo.prototype, "executeRecordingContextChangeCallbacks", null);
    class Co {
        constructor(t, s) {
            this.key = csString.prototype.slice.call(t, 0, 512), this.value = yt(s) ? csString.prototype.slice.call(s, 0, 255) : s
        }
        static isValid(t, s) {
            return yt(t) && (yt(s) || gt(s))
        }
    }
    class ko extends Fe {
        constructor(t, s) {
            super(), this.mu = t, this.U = s, this.vu = []
        }
        onStart() {
            csArray.prototype.forEach.call(this.vu, (t => this.trackDynamicVariable(t.key, t.value))), this.vu = []
        }
        onStop() {}
        trackDynamicVariable(t, s) {
            this.isStarted ? Co.isValid(t, s) && this.mu.add(new Co(this.U.anonymizePII(t), this.U.anonymizePII(s))) : csArray.prototype.push.call(this.vu, {
                key: t,
                value: s
            })
        }
    }
    class Oo {
        constructor(t) {
            this.gu = t, this.mu = []
        }
        add(t) {
            csArray.prototype.push.call(this.mu, t), this.setBatchReadyCall()
        }
        clear() {
            this.mu = []
        }
        onBatchReady(t) {
            this.yu = t
        }
        getRequestParameters() {
            const t = {};
            for (const s of this.mu) t[s.key] = s.value;
            return {
                dv: this.gu.compressSync(csJSON.stringify(t), "base64"),
                ct: this.gu.algorithm
            }
        }
        setBatchReadyCall() {
            this.yu()
        }
    }
    As([eo(), os("dynamicVariablesBatchReady")], Oo.prototype, "setBatchReadyCall", null);
    const No = ["trackDynamicVariable"];
    class xo {
        constructor(t, s, e, i, n, r) {
            this.Ia = t, this.Y = s, this.D = e, this.ua = i, this.gu = n, this.U = r, this.N = new tt(this.D.getTrackerUri(), "dvar"), this.mu = new Oo(this.gu), this.wu = new ko(this.mu, this.U)
        }
        init() {
            this.N.setRequestParametersProviders(this.ua, this.mu), this.Y.setDynamicVariablesService(this.wu), this.mu.onBatchReady((() => this.N.send())), this.N.after((() => this.mu.clear())), this.Ia.register(No, (({
                key: t,
                value: s
            } = {}) => {
                this.wu.trackDynamicVariable(t, s)
            }))
        }
        onStartTracking() {
            this.wu.start()
        }
    }
    class $o {
        constructor(t, s) {
            this.id = t, this.revenue = s
        }
        static from(t) {
            const s = new $o(t.id, parseFloat(t.revenue));
            return isNaN(parseFloat(t.tax)) || (s.tax = parseFloat(t.tax)), isNaN(parseFloat(t.shipping)) || (s.shipping = parseFloat(t.shipping)), yt(t.currency) && t.currency.length <= 10 && (s.currency = t.currency), s
        }
        hasValidRevenue() {
            return !isNaN(this.revenue) && this.revenue >= 0
        }
        static isValid(t) {
            return At(t) && vt(t.revenue) && yt(t.currency) && t.currency.length <= 10 && (!At(t.id) || yt(t.id))
        }
    }
    class Lo {
        constructor(t, s, e, i) {
            this.id = t, this.name = s, this.price = e, this.quantity = i
        }
        static from(t) {
            if (!Lo.Eu(t)) return null;
            const s = new Lo(t.id, t.name, parseFloat(t.price), parseInt(t.quantity, 10));
            return Et(t.sku) && (s.sku = t.sku), Et(t.category) && (s.category = t.category), Et(t.merchant) && t.merchant.length > 0 && (s.merchant = t.merchant.slice(0, 100)), s
        }
        static Eu(t) {
            return At(t) && yt(t.id) && yt(t.name) && vt(parseFloat(t.price)) && gt(parseInt(t.quantity, 10)) && (!Et(t.sku) || yt(t.sku)) && (!Et(t.category) || yt(t.category)) && (!Et(t.merchant) || yt(t.merchant))
        }
    }
    class Mo extends Fe {
        constructor(t, s, e) {
            super(), this.U = t, this.Au = s, this.Oi = e, this._u = [], this.clear()
        }
        onStart() {
            csArray.prototype.forEach.call(this._u, (t => {
                this.Su = t.transaction, this.Ru = t.transactionItems, this.sendTransaction()
            })), this._u = []
        }
        onStop() {}
        addTransaction(t) {
            const s = this.U.anonymizeFields(t, ["id"]);
            this.Su = $o.from(s)
        }
        getTransaction() {
            return this.Su
        }
        sendTransaction() {
            if (!this.isStarted) return csArray.prototype.push.call(this._u, {
                transaction: this.Su,
                transactionItems: [...this.Ru]
            }), void this.clear();
            null !== this.Au && null !== this.Oi && (this.Oi.refreshSession(), this.Oi.isSessionValid() && (this.Su.hasValidRevenue() ? this.Au.send() : ns.warn("Transaction Service: unable to send transaction with invalid parameters")))
        }
        addItem(t) {
            if (_t(t)) return;
            const s = this.U.anonymizeFields(t, ["id", "name", "sku", "category"]),
                e = Lo.from(s);
            null !== e && csArray.prototype.push.call(this.Ru, e)
        }
        getItems() {
            return this.Ru
        }
        clear() {
            this.Su = $o.from({
                revenue: NaN
            }), this.Ru = []
        }
        getRequestParameters() {
            const t = {
                id: this.Su.id ? `${this.Su.id}` : "",
                revenue: `${this.Su.revenue}`
            };
            return Et(this.Su.tax) && (t.tax = `${this.Su.tax}`), Et(this.Su.shipping) && (t.shipping = `${this.Su.shipping}`), Et(this.Su.currency) && (t.cu = `${this.Su.currency}`), t.items = window.csJSON.stringify(this.Ru), t
        }
    }
    class Do extends Fe {
        constructor(t, s) {
            super(), this.Tu = t, this.Oi = s, this.Iu = null, this.bu = []
        }
        onStart() {
            csArray.prototype.forEach.call(this.bu, (t => {
                this.Iu = t, this.Pu()
            })), this.bu = []
        }
        onStop() {}
        addToCart(t) {
            const s = {};
            yt(t.sku) && (s.sku = csString.prototype.slice.call(t.sku, 0, 100)), yt(t.merchant) && (s.merchant = csString.prototype.slice.call(t.merchant, 0, 100)), (s.sku || s.merchant) && (this.Iu = s, this.Pu())
        }
        getCartItem() {
            return this.Iu
        }
        Pu() {
            if (!this.isStarted && null !== this.Iu) return csArray.prototype.push.call(this.bu, this.Iu), void this.clear();
            this.Oi.refreshSession(), this.Oi.isSessionValid() && this.Tu.send()
        }
        clear() {
            this.Iu = null
        }
        getRequestParameters() {
            if (!this.Iu) return {};
            const t = {};
            return yt(this.Iu.sku) && this.Iu.sku.length > 0 && (t.sku = this.Iu.sku), yt(this.Iu.merchant) && this.Iu.merchant.length > 0 && (t.me = this.Iu.merchant), t
        }
    }
    const Uo = ["ecommerce:addToCart", "ec:cart:add"],
        qo = ["ecommerce:addTransaction", "ec:transaction:create"],
        Fo = ["ecommerce:addItem", "ec:transaction:items:add"],
        Ho = ["ecommerce:send", "ec:transaction:send"];
    class Bo {
        constructor(t, s, e, i, n, r, o) {
            this.D = t, this.ha = s, this.K = e, this.Ia = i, this.U = n, this.Oi = r, this.ot = o
        }
        init() {
            const t = new tt(this.D.getTrackerUri(), "transaction"),
                s = new tt(this.D.getTrackerUri(), "addtocart");
            this.Vu = new Mo(this.U, t, this.Oi), this.Cu = new Do(s, this.Oi);
            const e = new On(this.ha, this.K, this.ot, this.Vu);
            t.setRequestParametersProviders(e), t.after((() => {
                this.Vu.clear()
            }));
            const i = new On(this.ha, this.K, this.ot, this.Cu);
            s.setRequestParametersProviders(i), s.after((() => {
                this.Cu.clear()
            })), this.Ia.register(qo, (t => {
                this.Vu.addTransaction(t)
            })), this.Ia.register(Fo, (t => this.Vu.addItem(t))), this.Ia.register(Ho, (() => this.Vu.sendTransaction())), this.Ia.register(Uo, (t => {
                this.Cu.addToCart(t)
            }))
        }
        onStartTracking() {
            this.Vu.start(), this.Cu.start()
        }
    }
    class jo {
        constructor(t) {
            this.ku = t.performance
        }
        getRequestParameters() {
            if (this.Ou()) return {};
            const t = this.Nu();
            return {
                str: t.startRender,
                di: t.domInteractive,
                dc: t.domComplete,
                fl: t.fullyLoaded
            }
        }
        Nu() {
            const t = this.ku.timing;
            return {
                startRender: "" + (t.domLoading - t.requestStart),
                domInteractive: "" + (t.domInteractive - t.requestStart),
                domComplete: "" + (t.domComplete - t.requestStart),
                fullyLoaded: "" + (t.loadEventEnd - t.requestStart)
            }
        }
        Ou() {
            return !(this.ku && this.ku.timing && this.ku.timing.loadEventEnd > 0)
        }
    }
    var zo, Go;

    function Zo(t) {
        return void 0 !== t.tgt
    }! function(t) {
        t[t.RESIZE = 0] = "RESIZE", t[t.SCROLL = 1] = "SCROLL", t[t.MOUSEMOVE = 2] = "MOUSEMOVE", t[t.MOUSEDOWN = 3] = "MOUSEDOWN", t[t.MOUSEUP = 4] = "MOUSEUP", t[t.CLICK = 5] = "CLICK", t[t.MOUSEOVER = 6] = "MOUSEOVER", t[t.MOUSEOUT = 7] = "MOUSEOUT", t[t.CHANGE = 10] = "CHANGE", t[t.FOCUSIN = 11] = "FOCUSIN", t[t.FOCUSOUT = 12] = "FOCUSOUT", t[t.TAP = 14] = "TAP", t[t.KEYDOWN = 15] = "KEYDOWN", t[t.KEYUP = 16] = "KEYUP", t[t.COMMAND = 17] = "COMMAND", t[t.SUBMIT = 18] = "SUBMIT", t[t.PERFORMANCE = 19] = "PERFORMANCE", t[t.DRAG = 20] = "DRAG", t[t.FLICK = 21] = "FLICK", t[t.KEYBOARD_NAVIGATION = 22] = "KEYBOARD_NAVIGATION", t[t.ZOOM = 23] = "ZOOM", t[t.VIEWPORT_SCALE = 24] = "VIEWPORT_SCALE", t[t.TEXT_HIGHLIGHT = 25] = "TEXT_HIGHLIGHT", t[t.DEAD_CLICK = 30] = "DEAD_CLICK", t[t.DEAD_ZOOM = 31] = "DEAD_ZOOM", t[t.PAGE_RELOAD = 32] = "PAGE_RELOAD", t[t.THRASHED_CURSOR = 33] = "THRASHED_CURSOR", t[t.BLANK_PAGE = 34] = "BLANK_PAGE", t[t.EXTERNAL_EVENT = 35] = "EXTERNAL_EVENT"
    }(zo || (zo = {})),
    function(t) {
        t.SUCCESS = "success", t.FAILURE = "failure", t.ATTEMPT = "attempt"
    }(Go || (Go = {}));
    class Wo {
        static build(t, s, e) {
            return csArray.prototype.reduce.call(e, ((s, e) => e.enhanceAnalysisEvent(t, s)), s)
        }
    }
    class Qo {
        constructor(t, s, e) {
            this.xu = t, this.$u = s, this.no = e
        }
        processGesture(t, s) {
            switch (t.type) {
                case _r.TAP:
                    this.Lu(s);
                    break;
                case _r.FLICK:
                    this.Mu(t, s);
                    break;
                case _r.DRAG:
                    this.Du(t, s)
            }
        }
        Lu(t) {
            const s = {
                    type: zo.TAP,
                    ts: 0,
                    x: 0,
                    y: 0,
                    tgt: ""
                },
                e = Wo.build(t, s, this.xu);
            e.tgt !== F.INVALID_ELEMENT && this.Fn(e)
        }
        Du(t, s) {
            var e, i;
            const n = {
                type: zo.DRAG,
                ts: 0,
                fd: t.direction,
                tgt: ""
            };
            (null === (e = this.no) || void 0 === e ? void 0 : e.collectGestureDistance) && (n.distance = t.distance), (null === (i = this.no) || void 0 === i ? void 0 : i.collectGestureVelocity) && (n.velocity = t.velocity);
            const r = Wo.build(s, n, this.xu);
            r.tgt !== F.INVALID_ELEMENT && this.Fn(r)
        }
        Mu(t, s) {
            var e, i;
            const n = {
                type: zo.FLICK,
                ts: 0,
                fd: t.direction,
                tgt: ""
            };
            (null === (e = this.no) || void 0 === e ? void 0 : e.collectGestureDistance) && (n.distance = t.distance), (null === (i = this.no) || void 0 === i ? void 0 : i.collectGestureVelocity) && (n.velocity = t.velocity);
            const r = Wo.build(s, n, this.xu);
            r.tgt !== F.INVALID_ELEMENT && this.Fn(r)
        }
        onEvent(t) {
            this.Fn = t
        }
        start() {
            this.$u.subscribe(Qo.Uu, ((t, s) => this.processGesture(t, s)))
        }
        stop() {
            this.$u.unsubscribe(Qo.Uu)
        }
    }
    Qo.Uu = "AnalysisGestureTracker", As([as()], Qo.prototype, "processGesture", null);
    class Jo {
        constructor(t, s, e) {
            this.xu = t, this.qu = s, this.Fu = e, this.Hu = "select, select *, input, textarea", this.Bu = "select, select *, input, textarea", this.ju = "a, a *, button, button *, select, select *, input, textarea", this.zu = "input, select, textarea", this.Gu = 150, this.Zu = 400, this.Wu = !1, this.Qu = so(((t, s) => this.scrollListener(t, s)), this.Gu), this.Ju = so((t => this.resizeListener(t)), this.Gu), this.Ku = le((t => this.mouseMoveListener(t)), this.Zu), this.Yu = [{
                boundElement: window,
                type: "resize",
                listener: () => this.Ju()
            }, {
                boundElement: document,
                type: "scroll",
                listener: t => this.Qu(t)
            }, {
                boundElement: window,
                type: "mousemove",
                listener: t => {
                    this.Ku(function(t) {
                        return t.composedPath && Object.defineProperty(t, "__csOriginalTarget", {
                            value: t.composedPath()[0],
                            writable: !1,
                            enumerable: !1
                        }), t
                    }(t))
                }
            }, {
                boundElement: document,
                type: "mousedown",
                listener: t => this.mouseDownListener(t)
            }, {
                boundElement: document,
                type: "mouseup",
                listener: t => this.mouseUpListener(t)
            }, {
                boundElement: document,
                type: "click",
                listener: t => this.clickListener(t)
            }], this.Xu = [{
                type: "change",
                listener: this.Fu.on(this.Bu, (t => this.changeListener(t)))
            }], this.tl = [{
                boundElement: document,
                type: "mouseover",
                listener: this.Fu.on(this.ju, (t => this.mouseOverListener(t)))
            }, {
                boundElement: document,
                type: "mouseout",
                listener: this.Fu.on(this.ju, (t => this.mouseOutListener(t)))
            }, {
                boundElement: document,
                type: "focusin",
                listener: this.Fu.on(this.Hu, (t => this.focusInListener(t)))
            }, {
                boundElement: document,
                type: "focusout",
                listener: this.Fu.on(this.Hu, (t => this.focusOutListener(t)))
            }, {
                boundElement: document,
                type: "keyup",
                listener: this.Fu.on(this.zu, (t => this.keyUpListener(t)))
            }, {
                boundElement: document,
                type: "keydown",
                listener: this.Fu.on(this.zu, (t => this.keyDownListener(t)))
            }, {
                boundElement: document,
                type: "copy",
                listener: this.Fu.on(this.zu, (t => this.copyListener(t)))
            }, {
                boundElement: document,
                type: "cut",
                listener: this.Fu.on(this.zu, (t => this.cutListener(t)))
            }, {
                boundElement: document,
                type: "paste",
                listener: this.Fu.on(this.zu, (t => this.pasteListener(t)))
            }, ...csArray.prototype.map.call(this.Xu, (t => ({ ...t,
                boundElement: document
            })))], this.Gs = {}, this.Me = (t, s) => {
                switch (s) {
                    case "initial":
                    case "added":
                        this.$s(t);
                        break;
                    case "removed":
                        this.Ls(t)
                }
            }, this.xs = new he(this.Me), this.Us()
        }
        $s(t) {
            if (S(t)) {
                const t = this.sl();
                csArray.prototype.forEach.call(t, (t => ce(t)))
            } else {
                const s = this.el();
                csArray.prototype.forEach.call(s, (s => {
                    ce({ ...s,
                        boundElement: t
                    })
                }))
            }
        }
        Ls(t) {
            if (S(t)) {
                const t = this.sl();
                csArray.prototype.forEach.call(t, (t => ae(t)))
            } else {
                const s = this.el();
                csArray.prototype.forEach.call(s, (s => {
                    ae({ ...s,
                        boundElement: t
                    })
                }))
            }
        }
        onEvent(t) {
            this.Fn = t
        }
        start() {
            this.xs.observe(), this.$s(document), this.resizeListener()
        }
        stop() {
            this.Ls(document), this.xs.disconnect()
        }
        flushPendingDebouncedListeners() {
            this.Qu.flushPending(), this.Ju.flushPending()
        }
        el() {
            return this.Fu.isMatchesSelectorSupported() ? this.Xu : (ns.warn("Element.matches is not implemented yet"), [])
        }
        sl() {
            return this.Fu.isMatchesSelectorSupported() ? [...this.Yu, ...this.tl] : (ns.warn("Element.matches is not implemented yet"), this.Yu)
        }
        resizeListener(t) {
            const s = _e.getScrollContainer(),
                e = St(s);
            e && (this.Wu = !0);
            const i = {
                type: zo.RESIZE,
                ts: 0,
                x: e ? s.clientWidth : Mi.windowWidth(),
                y: e ? s.clientHeight : Mi.windowHeight()
            };
            void 0 !== t && (i.d = t), this.Fn(i)
        }
        scrollListener(t, s) {
            const e = _e.isEventOnScrollContainer(s);
            !this.Wu && e && this.resizeListener();
            const i = {
                    type: zo.SCROLL,
                    ts: 0,
                    x: e ? csEventtarget.apply(s).scrollLeft : Mi.windowOffsetX(),
                    y: e ? csEventtarget.apply(s).scrollTop : Mi.windowOffsetY(),
                    d: t
                },
                n = Wo.build(s, i, this.xu);
            this.Fn(n)
        }
        mouseMoveListener(t) {
            const s = {
                    type: zo.MOUSEMOVE,
                    ts: 0,
                    x: t.pageX,
                    y: t.pageY
                },
                e = Wo.build(t, s, this.xu);
            this.Fn(e)
        }
        mouseDownListener(t) {
            const s = {
                    type: zo.MOUSEDOWN,
                    ts: 0,
                    x: t.pageX,
                    y: t.pageY,
                    tgt: ""
                },
                e = Wo.build(t, s, this.xu);
            this.il(e)
        }
        mouseUpListener(t) {
            const s = {
                    type: zo.MOUSEUP,
                    ts: 0,
                    x: t.pageX,
                    y: t.pageY,
                    tgt: ""
                },
                e = Wo.build(t, s, this.xu);
            this.il(e)
        }
        clickListener(t) {
            const s = {
                    type: zo.CLICK,
                    ts: 0,
                    x: t.pageX,
                    y: t.pageY,
                    tgt: ""
                },
                e = Wo.build(t, s, this.xu);
            this.il(e)
        }
        mouseOverListener(t) {
            const s = {
                    type: zo.MOUSEOVER,
                    ts: 0,
                    x: t.pageX,
                    y: t.pageY,
                    tgt: ""
                },
                e = Wo.build(t, s, this.xu);
            this.il(e)
        }
        mouseOutListener(t) {
            const s = {
                    type: zo.MOUSEOUT,
                    ts: 0,
                    x: t.pageX,
                    y: t.pageY,
                    tgt: this.qu.getEventTargetPath(t)
                },
                e = Wo.build(t, s, this.xu);
            this.il(e)
        }
        focusInListener(t) {
            const s = {
                    type: zo.FOCUSIN,
                    ts: 0,
                    tgt: this.qu.getEventTargetPath(t)
                },
                e = Wo.build(t, s, this.xu);
            this.il(e)
        }
        focusOutListener(t) {
            const s = {
                    type: zo.FOCUSOUT,
                    ts: 0,
                    tgt: this.qu.getEventTargetPath(t)
                },
                e = Wo.build(t, s, this.xu);
            this.il(e)
        }
        changeListener(t) {
            const s = {
                    type: zo.CHANGE,
                    ts: 0,
                    tgt: this.qu.getEventTargetPath(t)
                },
                e = Wo.build(t, s, this.xu);
            this.il(e)
        }
        copyListener(t) {
            const s = {
                type: zo.COMMAND,
                ts: 0,
                tgt: this.qu.getEventTargetPath(t),
                key: ye.COPY
            };
            this.il(s)
        }
        cutListener(t) {
            const s = {
                type: zo.COMMAND,
                ts: 0,
                tgt: this.qu.getEventTargetPath(t),
                key: ye.CUT
            };
            this.il(s)
        }
        pasteListener(t) {
            const s = {
                type: zo.COMMAND,
                ts: 0,
                tgt: this.qu.getEventTargetPath(t),
                key: ye.PASTE
            };
            this.il(s)
        }
        keyUpListener(t) {
            const s = {
                type: zo.KEYUP,
                ts: 0,
                tgt: this.qu.getEventTargetPath(t),
                key: this.nl(t)
            };
            this.il(s)
        }
        keyDownListener(t) {
            const s = {
                type: zo.KEYDOWN,
                ts: 0,
                tgt: this.qu.getEventTargetPath(t),
                key: this.nl(t)
            };
            this.il(s)
        }
        nl(t) {
            const s = this.Gs[t.key];
            return void 0 === s ? ge.ALPHANUMERICAL : s
        }
        il(t) {
            Zo(t) && t.tgt !== F.INVALID_ELEMENT && this.Fn(t)
        }
        Us() {
            this.Gs[" "] = ge.SPACE, this.Gs.Spacebar = ge.SPACE, this.Gs.Enter = ge.ENTER, this.Gs.Backspace = ge.BACKSPACE, this.Gs.Delete = ge.DELETE, this.Gs.ArrowUp = ge.ARROWUP, this.Gs.ArrowDown = ge.ARROWDOWN, this.Gs.ArrowLeft = ge.ARROWLEFT, this.Gs.ArrowRight = ge.ARROWRIGHT, this.Gs.Up = ge.ARROWUP, this.Gs.Down = ge.ARROWDOWN, this.Gs.Left = ge.ARROWLEFT, this.Gs.Right = ge.ARROWRIGHT, this.Gs.CapsLock = ge.CAPSLOCK, this.Gs.Shift = ge.SHIFT, this.Gs.Tab = ge.TAB
        }
    }
    As([os("Event handler type: resize")], Jo.prototype, "resizeListener", null), As([os("Event handler type: scroll")], Jo.prototype, "scrollListener", null), As([os("Event handler type: mouseMove"), as()], Jo.prototype, "mouseMoveListener", null), As([os("Event handler type: mouseDown"), as()], Jo.prototype, "mouseDownListener", null), As([os("Event handler type: mouseUp"), as()], Jo.prototype, "mouseUpListener", null), As([os("Event handler type: click"), as()], Jo.prototype, "clickListener", null), As([os("Event handler type: mouseOver"), as()], Jo.prototype, "mouseOverListener", null), As([os("Event handler type: mouseOut"), as()], Jo.prototype, "mouseOutListener", null), As([os("Event handler type: focusIn")], Jo.prototype, "focusInListener", null), As([os("Event handler type: focusOut")], Jo.prototype, "focusOutListener", null), As([os("Event handler type: change")], Jo.prototype, "changeListener", null), As([os("Event handler type: copy")], Jo.prototype, "copyListener", null), As([os("Event handler type: cut")], Jo.prototype, "cutListener", null), As([os("Event handler type: paste")], Jo.prototype, "pasteListener", null), As([os("Event handler type: keyup")], Jo.prototype, "keyUpListener", null), As([os("Event handler type: keydown")], Jo.prototype, "keyDownListener", null);
    class Ko {
        constructor() {
            this.rl = 100, this.ol = 0, this.hl = Mi.documentHeight(), this.cl = {
                boundElement: document,
                type: "scroll",
                listener: t => this.maxScrollRateListener(t)
            }, this.ol = this.al(_e.getScrollContainer()).maxScrollRate
        }
        onEvent(t) {
            this.Fn = t
        }
        start() {
            ce(this.cl)
        }
        stop() {
            ae(this.cl)
        }
        reset() {
            const t = _e.getScrollContainer(),
                {
                    maxScrollRate: s,
                    maxDocumentHeight: e
                } = this.al(t);
            this.hl = e, this.ol = s, this.Fn()
        }
        al(t) {
            let s = 0,
                e = 0;
            if (null === t) e = Mi.documentHeight(), s = this.ul(e);
            else {
                const i = this.ll(t);
                e = this.dl(t, i), s = this.pl(t, i)
            }
            return {
                maxScrollRate: s,
                maxDocumentHeight: e
            }
        }
        maxScrollRateListener(t) {
            let s = null;
            _e.isEventOnScrollContainer(t) && (s = csEventtarget.apply(t));
            const {
                maxScrollRate: e,
                maxDocumentHeight: i
            } = this.al(s);
            (e > this.ol || i > this.hl) && (this.ol = e, i > this.hl && (this.hl = i), this.Fn())
        }
        ul(t) {
            const s = Math.round(this.ml() / t * 100);
            return Math.min(s, this.rl)
        }
        ml() {
            const t = Mi.windowHeight();
            return Mi.windowOffsetY() + t
        }
        pl(t, s) {
            const e = t.scrollTop + t.clientHeight + t.getBoundingClientRect().top + s,
                i = this.dl(t, s),
                n = Math.round(e / i * 100);
            return Math.min(n, this.rl)
        }
        ll(t) {
            const s = window.getComputedStyle(t).paddingTop || "0px";
            return parseInt(s, 10)
        }
        dl(t, s) {
            return t.scrollHeight + t.getBoundingClientRect().top + s
        }
        getRequestParameters() {
            return {
                sr: `${this.ol}`,
                mdh: `${this.hl}`
            }
        }
    }
    As([os("MaxScrollRate handler")], Ko.prototype, "maxScrollRateListener", null);
    class Yo {
        constructor(t, s, e, i, n, r, o, h, c, a, u, l, d, f, p, m, v, g, y, w, E) {
            this.D = t, this.vl = s, this.$u = e, this.gl = i, this.yl = n, this.wl = r, this.El = o, this.Al = h, this.Oi = c, this.ss = a, this._l = u, this.Sl = l, this.hn = d, this.Mi = f, this.Rl = p, this.Tl = m, this.Il = v, this.bl = g, this.Pl = y, this.Vl = w, this.Cl = E, this.Qi = new qe, this.kl = !1
        }
        init() {
            var t, s, e, i, n, r, o;
            this.vl.onEvent((t => this.en(t))), this.$u.onEvent((t => this.en(t))), this.gl.onEvent((() => {
                const t = this.gl.getRequestParameters();
                this.Mi.setQueryParams(t), this.El.setQueryParams(t)
            })), this.Sl.onEvent((t => this.Ol(t))), this.Nl(), null === (t = this.Rl) || void 0 === t || t.onEvent((t => this.en(t))), null === (s = this.Pl) || void 0 === s || s.onEvent((t => this.en(t))), null === (e = this.Tl) || void 0 === e || e.onEvent((t => this.en(t))), null === (i = this.Il) || void 0 === i || i.onEvent((t => this.en(t))), this.xl(), null === (n = this.bl) || void 0 === n || n.onEvent((t => this.Ol(t))), null === (r = this.Vl) || void 0 === r || r.onEvent((t => this.Ol(t))), null === (o = this.Cl) || void 0 === o || o.onEvent((t => this.Ol(t)))
        }
        xl() {
            this.El.onBeaconSuccess((() => {
                this.wl.clearEvents()
            })), this.El.onBeaconFailure((t => {
                this.$l(t)
            }))
        }
        initStates() {
            const t = this.Al.getRequestParameters(),
                s = this.yl.getRequestParameters(),
                e = this.gl.getRequestParameters();
            this.Mi.setQueryParams(t), this.Mi.setQueryParams(s), this.Mi.setQueryParams(e), this.El.setQueryParams(t), this.El.setQueryParams(s), this.El.setQueryParams(e), this.Ll()
        }
        clearStates(t) {
            var s, e;
            this.vl.flushPendingDebouncedListeners(), null === (s = this.Tl) || void 0 === s || s.flushPendingKeyboardNavigationEvent(), null === (e = this.Il) || void 0 === e || e.flushPendingTextHighlightEvent(), t ? (this.Ml(), this.sendLastMessageBeacon()) : this.sendEvents(), this.gl.reset(), this.Sl.stop(), this.Mi.removeQueryParams()
        }
        start(t) {
            var s, e, i, n, r, o, h;
            t || null === (s = this.bl) || void 0 === s || s.start(), this.hn.start(), this.vl.start(), this.gl.start(), this.$u.start(), null === (e = this.Rl) || void 0 === e || e.start(), null === (i = this.Il) || void 0 === i || i.start(), t || this.Sl.start(), null === (n = this.Tl) || void 0 === n || n.start(), null === (r = this.Pl) || void 0 === r || r.start(), null === (o = this.Vl) || void 0 === o || o.start(), null === (h = this.Cl) || void 0 === h || h.start()
        }
        collectInitialEvents() {
            var t;
            null === (t = this.Rl) || void 0 === t || t.collectInitialEvents()
        }
        onIframeAnalysisBrowserEvent(t) {
            this.Ol(t)
        }
        onIframeAnalysisUserEvent(t) {
            this.en(t)
        }
        onExternalEvent(t) {
            this.mn(t)
        }
        Ol(t) {
            this.Oi.isCurrentPageviewValid() && this.mn(t)
        }
        en(t) {
            this.Oi.refreshSession(), this.Oi.isSessionValid() && this.mn(t)
        }
        mn(t) {
            this.wl.addEvent(this.Dl(t)), this.wl.isFull() && this.sendEvents(), this.D.emitDebugEvents && this.Qi.emit("analysisEvent", { ...t,
                typeName: zo[t.type]
            })
        }
        Dl(t) {
            return t.ts = this.Ul(), t
        }
        Ml() {
            this.El.setQueryParams({
                hlm: "true"
            }), this.kl = !0
        }
        sendLastMessageBeacon() {
            this.El.setQueryParams(this.yl.getRequestParameters()), this.El.send(this.wl.stringifyEvents()), this.El.removeQueryParams(["hlm"]), this.kl = !1
        }
        sendEvents() {
            this.wl.isEmpty() || (this.Mi.setQueryParams(this.Al.getRequestParameters()), this.Mi.setQueryParams(this.yl.getRequestParameters()), this.Mi.send(this.wl.getEvents()), this.wl.clearEvents())
        }
        stop() {
            var t, s, e, i, n, r, o;
            this.hn.stop(), this.vl.stop(), this.gl.stop(), this.$u.stop(), this.Sl.stop(), null === (t = this.Rl) || void 0 === t || t.stop(), null === (s = this.Tl) || void 0 === s || s.stop(), null === (e = this.Il) || void 0 === e || e.stop(), null === (i = this.Pl) || void 0 === i || i.stop(), this.wl.empty(), null === (n = this.bl) || void 0 === n || n.stop(), null === (r = this.Vl) || void 0 === r || r.stop(), null === (o = this.Cl) || void 0 === o || o.stop()
        }
        Ll() {
            this.ql = Vt.now()
        }
        Ul() {
            return Vt.now() - this.ql
        }
        Nl() {
            this.hn.onEvent((t => {
                var s, e;
                null === (s = this.Tl) || void 0 === s || s.flushPendingKeyboardNavigationEvent(), null === (e = this.Il) || void 0 === e || e.flushPendingTextHighlightEvent(), t === Ge.PagehideVisible ? this.Ml() : t === Ge.PagehideHidden ? (this.Ml(), this.sendLastMessageBeacon()) : this.wl.isEmpty() && !this.kl || this.sendLastMessageBeacon()
            }))
        }
        $l(t) {
            try {
                this.wl.isEmpty() && !this.kl || this.ss.save({
                    requestParameters: t,
                    events: this.wl.getEvents()
                })
            } catch {}
        }
        pushSubmitEvent(t, s) {
            if (! function(t) {
                    return t === Go.SUCCESS || t === Go.FAILURE || t === Go.ATTEMPT
                }(t)) return void ns.warn(`AnalysisEvents Service: invalid submit status: ${t}`);
            if (!St(s)) return void ns.warn(`AnalysisEvents Service: invalid element: ${s}`);
            const e = {
                status: t,
                type: zo.SUBMIT,
                ts: 0,
                tgt: this._l.getElementPath(s)
            };
            e.tgt !== F.INVALID_ELEMENT && this.Ol(e)
        }
    }
    class Xo {
        constructor(t, s) {
            this.ss = t, this.Mi = s, this.Fl = () => {
                "visible" === document.visibilityState && this.Hl()
            }
        }
        start() {
            this.Hl(), this.re()
        }
        stop() {
            this.ae()
        }
        getRecoveryStorage() {
            return this.ss
        }
        Hl() {
            const t = this.ss.recover();
            if (null !== t) {
                const {
                    requestParameters: s,
                    events: e
                } = t;
                this.Mi.send(e, s)
            }
        }
        re() {
            document.addEventListener("visibilitychange", this.Fl)
        }
        ae() {
            document.removeEventListener("visibilitychange", this.Fl)
        }
    }
    class th {
        constructor(t) {
            this.Mr = t
        }
        save(t) {
            localStorage.setItem(this.Mr, csJSON.stringify(t))
        }
        clear() {
            localStorage.removeItem(this.Mr)
        }
        recover() {
            const t = localStorage.getItem(this.Mr);
            if (null === t) return null;
            let s = null;
            try {
                s = csJSON.parse(t)
            } catch {
                ns.error(`Invalid item in localStorage.\n         (key:${this.Mr}; value:${t})`)
            } finally {
                this.clear()
            }
            return s
        }
    }
    class sh {
        constructor(t) {
            this.Bl = t, this.jl = t => this.processMetric(t), this.se = !1
        }
        onEvent(t) {
            this.Fn = t
        }
        start() {
            this.se || (this.se = !0, this.Bl.onFCP(this.jl), this.Bl.onCLS(this.jl), this.Bl.onFID(this.jl), this.Bl.onLCP(this.jl), this.Bl.onTTFB(this.jl), this.Bl.onINP(this.jl))
        }
        stop() {
            this.se = !1
        }
        processMetric(t) {
            if (!this.se) return;
            const s = {
                type: zo.PERFORMANCE,
                name: t.name,
                val: t.value,
                ts: 0
            };
            this.Fn(s)
        }
    }
    As([os("Performance metric handler")], sh.prototype, "processMetric", null);
    var eh, ih, nh, rh, oh, hh = -1,
        ch = function(t) {
            addEventListener("pageshow", (function(s) {
                s.persisted && (hh = s.timeStamp, t(s))
            }), !0)
        },
        ah = function() {
            return window.performance && performance.getEntriesByType && performance.getEntriesByType("navigation")[0]
        },
        uh = function() {
            var t = ah();
            return t && t.activationStart || 0
        },
        lh = function(t, s) {
            var e = ah(),
                i = "navigate";
            return hh >= 0 ? i = "back-forward-cache" : e && (document.prerendering || uh() > 0 ? i = "prerender" : document.wasDiscarded ? i = "restore" : e.type && (i = e.type.replace(/_/g, "-"))), {
                name: t,
                value: void 0 === s ? -1 : s,
                rating: "good",
                delta: 0,
                entries: [],
                id: "v3-".concat(Date.now(), "-").concat(Math.floor(8999999999999 * Math.random()) + 1e12),
                navigationType: i
            }
        },
        dh = function(t, s, e) {
            try {
                if (PerformanceObserver.supportedEntryTypes.includes(t)) {
                    var i = new PerformanceObserver((function(t) {
                        Promise.resolve().then((function() {
                            s(t.getEntries())
                        }))
                    }));
                    return i.observe(Object.assign({
                        type: t,
                        buffered: !0
                    }, e || {})), i
                }
            } catch (t) {}
        },
        fh = function(t, s, e, i) {
            var n, r;
            return function(o) {
                s.value >= 0 && (o || i) && ((r = s.value - (n || 0)) || void 0 === n) && (n = s.value, s.delta = r, s.rating = function(t, s) {
                    return t > s[1] ? "poor" : t > s[0] ? "needs-improvement" : "good"
                }(s.value, e), t(s))
            }
        },
        ph = function(t) {
            requestAnimationFrame((function() {
                return requestAnimationFrame((function() {
                    return t()
                }))
            }))
        },
        mh = function(t) {
            var s = function(s) {
                "pagehide" !== s.type && "hidden" !== document.visibilityState || t(s)
            };
            addEventListener("visibilitychange", s, !0), addEventListener("pagehide", s, !0)
        },
        vh = function(t) {
            var s = !1;
            return function(e) {
                s || (t(e), s = !0)
            }
        },
        gh = -1,
        yh = function() {
            return "hidden" !== document.visibilityState || document.prerendering ? 1 / 0 : 0
        },
        wh = function(t) {
            "hidden" === document.visibilityState && gh > -1 && (gh = "visibilitychange" === t.type ? t.timeStamp : 0, Ah())
        },
        Eh = function() {
            addEventListener("visibilitychange", wh, !0), addEventListener("prerenderingchange", wh, !0)
        },
        Ah = function() {
            removeEventListener("visibilitychange", wh, !0), removeEventListener("prerenderingchange", wh, !0)
        },
        _h = function() {
            return gh < 0 && (gh = yh(), Eh(), ch((function() {
                setTimeout((function() {
                    gh = yh(), Eh()
                }), 0)
            }))), {
                get firstHiddenTime() {
                    return gh
                }
            }
        },
        Sh = function(t) {
            document.prerendering ? addEventListener("prerenderingchange", (function() {
                return t()
            }), !0) : t()
        },
        Rh = [1800, 3e3],
        Th = function(t, s) {
            s = s || {}, Sh((function() {
                var e, i = _h(),
                    n = lh("FCP"),
                    r = dh("paint", (function(t) {
                        t.forEach((function(t) {
                            "first-contentful-paint" === t.name && (r.disconnect(), t.startTime < i.firstHiddenTime && (n.value = Math.max(t.startTime - uh(), 0), n.entries.push(t), e(!0)))
                        }))
                    }));
                r && (e = fh(t, n, Rh, s.reportAllChanges), ch((function(i) {
                    n = lh("FCP"), e = fh(t, n, Rh, s.reportAllChanges), ph((function() {
                        n.value = performance.now() - i.timeStamp, e(!0)
                    }))
                })))
            }))
        },
        Ih = [.1, .25],
        bh = {
            passive: !0,
            capture: !0
        },
        Ph = new Date,
        Vh = function(t, s) {
            eh || (eh = s, ih = t, nh = new Date, Oh(removeEventListener), Ch())
        },
        Ch = function() {
            if (ih >= 0 && ih < nh - Ph) {
                var t = {
                    entryType: "first-input",
                    name: eh.type,
                    target: eh.target,
                    cancelable: eh.cancelable,
                    startTime: eh.timeStamp,
                    processingStart: eh.timeStamp + ih
                };
                rh.forEach((function(s) {
                    s(t)
                })), rh = []
            }
        },
        kh = function(t) {
            if (t.cancelable) {
                var s = (t.timeStamp > 1e12 ? new Date : performance.now()) - t.timeStamp;
                "pointerdown" == t.type ? function(t, s) {
                    var e = function() {
                            Vh(t, s), n()
                        },
                        i = function() {
                            n()
                        },
                        n = function() {
                            removeEventListener("pointerup", e, bh), removeEventListener("pointercancel", i, bh)
                        };
                    addEventListener("pointerup", e, bh), addEventListener("pointercancel", i, bh)
                }(s, t) : Vh(s, t)
            }
        },
        Oh = function(t) {
            ["mousedown", "keydown", "touchstart", "pointerdown"].forEach((function(s) {
                return t(s, kh, bh)
            }))
        },
        Nh = [100, 300],
        xh = 0,
        $h = 1 / 0,
        Lh = 0,
        Mh = function(t) {
            t.forEach((function(t) {
                t.interactionId && ($h = Math.min($h, t.interactionId), Lh = Math.max(Lh, t.interactionId), xh = Lh ? (Lh - $h) / 7 + 1 : 0)
            }))
        },
        Dh = function() {
            return oh ? xh : performance.interactionCount || 0
        },
        Uh = function() {
            "interactionCount" in performance || oh || (oh = dh("event", Mh, {
                type: "event",
                buffered: !0,
                durationThreshold: 0
            }))
        },
        qh = [200, 500],
        Fh = 0,
        Hh = function() {
            return Dh() - Fh
        },
        Bh = [],
        jh = {},
        zh = function(t) {
            var s = Bh[Bh.length - 1],
                e = jh[t.interactionId];
            if (e || Bh.length < 10 || t.duration > s.latency) {
                if (e) e.entries.push(t), e.latency = Math.max(e.latency, t.duration);
                else {
                    var i = {
                        id: t.interactionId,
                        latency: t.duration,
                        entries: [t]
                    };
                    jh[i.id] = i, Bh.push(i)
                }
                Bh.sort((function(t, s) {
                    return s.latency - t.latency
                })), Bh.splice(10).forEach((function(t) {
                    delete jh[t.id]
                }))
            }
        },
        Gh = [2500, 4e3],
        Zh = {},
        Wh = [800, 1800],
        Qh = function t(s) {
            document.prerendering ? Sh((function() {
                return t(s)
            })) : "complete" !== document.readyState ? addEventListener("load", (function() {
                return t(s)
            }), !0) : setTimeout(s, 0)
        },
        Jh = function(t, s) {
            s = s || {};
            var e = lh("TTFB"),
                i = fh(t, e, Wh, s.reportAllChanges);
            Qh((function() {
                var n = ah();
                if (n) {
                    var r = n.responseStart;
                    if (r <= 0 || r > performance.now()) return;
                    e.value = Math.max(r - uh(), 0), e.entries = [n], i(!0), ch((function() {
                        e = lh("TTFB", 0), (i = fh(t, e, Wh, s.reportAllChanges))(!0)
                    }))
                }
            }))
        };
    class Kh {
        onFCP(t) {
            Th(t, {
                reportAllChanges: !0
            })
        }
        onCLS(t) {
            ! function(t, s) {
                s = s || {}, Th(vh((function() {
                    var e, i = lh("CLS", 0),
                        n = 0,
                        r = [],
                        o = function(t) {
                            t.forEach((function(t) {
                                if (!t.hadRecentInput) {
                                    var s = r[0],
                                        e = r[r.length - 1];
                                    n && t.startTime - e.startTime < 1e3 && t.startTime - s.startTime < 5e3 ? (n += t.value, r.push(t)) : (n = t.value, r = [t])
                                }
                            })), n > i.value && (i.value = n, i.entries = r, e())
                        },
                        h = dh("layout-shift", o);
                    h && (e = fh(t, i, Ih, s.reportAllChanges), mh((function() {
                        o(h.takeRecords()), e(!0)
                    })), ch((function() {
                        n = 0, i = lh("CLS", 0), e = fh(t, i, Ih, s.reportAllChanges), ph((function() {
                            return e()
                        }))
                    })), setTimeout(e, 0))
                })))
            }(t, {
                reportAllChanges: !0
            })
        }
        onFID(t) {
            ! function(t, s) {
                s = s || {}, Sh((function() {
                    var e, i = _h(),
                        n = lh("FID"),
                        r = function(t) {
                            t.startTime < i.firstHiddenTime && (n.value = t.processingStart - t.startTime, n.entries.push(t), e(!0))
                        },
                        o = function(t) {
                            t.forEach(r)
                        },
                        h = dh("first-input", o);
                    e = fh(t, n, Nh, s.reportAllChanges), h && mh(vh((function() {
                        o(h.takeRecords()), h.disconnect()
                    }))), h && ch((function() {
                        var i;
                        n = lh("FID"), e = fh(t, n, Nh, s.reportAllChanges), rh = [], ih = -1, eh = null, Oh(addEventListener), i = r, rh.push(i), Ch()
                    }))
                }))
            }(t, {
                reportAllChanges: !0
            })
        }
        onLCP(t) {
            ! function(t, s) {
                s = s || {}, Sh((function() {
                    var e, i = _h(),
                        n = lh("LCP"),
                        r = function(t) {
                            var s = t[t.length - 1];
                            s && s.startTime < i.firstHiddenTime && (n.value = Math.max(s.startTime - uh(), 0), n.entries = [s], e())
                        },
                        o = dh("largest-contentful-paint", r);
                    if (o) {
                        e = fh(t, n, Gh, s.reportAllChanges);
                        var h = vh((function() {
                            Zh[n.id] || (r(o.takeRecords()), o.disconnect(), Zh[n.id] = !0, e(!0))
                        }));
                        ["keydown", "click"].forEach((function(t) {
                            addEventListener(t, (function() {
                                return setTimeout(h, 0)
                            }), !0)
                        })), mh(h), ch((function(i) {
                            n = lh("LCP"), e = fh(t, n, Gh, s.reportAllChanges), ph((function() {
                                n.value = performance.now() - i.timeStamp, Zh[n.id] = !0, e(!0)
                            }))
                        }))
                    }
                }))
            }(t, {
                reportAllChanges: !0
            })
        }
        onTTFB(t) {
            Jh(t, {
                reportAllChanges: !0
            })
        }
        onINP(t) {
            ! function(t, s) {
                s = s || {}, Sh((function() {
                    var e;
                    Uh();
                    var i, n = lh("INP"),
                        r = function(t) {
                            t.forEach((function(t) {
                                t.interactionId && zh(t), "first-input" === t.entryType && !Bh.some((function(s) {
                                    return s.entries.some((function(s) {
                                        return t.duration === s.duration && t.startTime === s.startTime
                                    }))
                                })) && zh(t)
                            }));
                            var s, e = (s = Math.min(Bh.length - 1, Math.floor(Hh() / 50)), Bh[s]);
                            e && e.latency !== n.value && (n.value = e.latency, n.entries = e.entries, i())
                        },
                        o = dh("event", r, {
                            durationThreshold: null !== (e = s.durationThreshold) && void 0 !== e ? e : 40
                        });
                    i = fh(t, n, qh, s.reportAllChanges), o && ("PerformanceEventTiming" in window && "interactionId" in PerformanceEventTiming.prototype && o.observe({
                        type: "first-input",
                        buffered: !0
                    }), mh((function() {
                        r(o.takeRecords()), n.value < 0 && Hh() > 0 && (n.value = 0, n.entries = []), i(!0)
                    })), ch((function() {
                        Bh = [], Fh = Dh(), n = lh("INP"), i = fh(t, n, qh, s.reportAllChanges)
                    })))
                }))
            }(t, {
                reportAllChanges: !0
            })
        }
    }
    class Yh {
        constructor(t = []) {
            this.Qs = t
        }
        stringifyEvents() {
            return csJSON.stringify(this.Qs)
        }
        addEvent(t) {
            csArray.prototype.push.call(this.Qs, t)
        }
        eventsCount() {
            return this.Qs.length
        }
        clearEvents() {
            this.Qs = []
        }
        empty() {
            this.clearEvents()
        }
        isFull() {
            return this.eventsCount() >= 50
        }
        isEmpty() {
            return 0 === this.Qs.length
        }
        getEvents() {
            return this.Qs
        }
    }
    class Xh {
        isEventTypeSupported(t) {
            return -1 !== csArray.prototype.indexOf.call(this.supportedEventTypes, t)
        }
        enhanceAnalysisEvent(t, s) {
            return this.isEventTypeSupported(s.type) ? this.baseEnhanceAnalysisEvent(t, s) : s
        }
    }
    class tc extends Xh {
        constructor() {
            super(...arguments), this.supportedEventTypes = [zo.CHANGE], this.zl = ["text", "email", "number", "search", "tel", "url", "password"]
        }
        baseEnhanceAnalysisEvent(t, s) {
            const e = we(t);
            return g(e) && csArray.prototype.indexOf.call(this.zl, e.type) >= 0 && (s.isBlank = "" === e.value), s
        }
    }
    class sc extends Xh {
        constructor(t) {
            super(), this.qu = t, this.supportedEventTypes = [zo.MOUSEDOWN, zo.MOUSEUP, zo.CLICK, zo.MOUSEOVER, zo.TAP, zo.DRAG, zo.FLICK]
        }
        baseEnhanceAnalysisEvent(t, s) {
            return s.tgt || (s.tgt = this.qu.getEventTargetPath(t)), s
        }
    }
    var ec, ic;
    ! function(t) {
        t.getRelativePosition = function(t) {
            const s = we(t);
            if (!(s && l(s) && _t(s.getBoundingClientRect) && At(t.pageX) && At(t.pageY))) return {
                xRel: -1,
                yRel: -1,
                valid: !1
            };
            const e = s.getBoundingClientRect();
            let i = t.pageX - e.left - Mi.windowOffsetX(),
                n = t.pageY - e.top - Mi.windowOffsetY();
            s !== document.documentElement && (i += s.scrollLeft, n += s.scrollTop);
            const r = Math.max(s.scrollWidth, e.width),
                o = Math.max(s.scrollHeight, e.height);
            return {
                xRel: Math.round(i / r * 65535),
                yRel: Math.round(n / o * 65535),
                valid: !0
            }
        }
    }(ec || (ec = {}));
    class nc extends Xh {
        constructor(t, s) {
            super(), this.C = t, this.qu = s, this.supportedEventTypes = [zo.MOUSEMOVE, zo.CLICK], this.Gl = ""
        }
        baseEnhanceAnalysisEvent(t, s) {
            const {
                valid: e,
                xRel: i,
                yRel: n
            } = ec.getRelativePosition(t);
            if (e) {
                const e = this.qu.getEventTargetPath(t);
                e !== F.INVALID_ELEMENT && (s.xRel = i, s.yRel = n, s.type === zo.MOUSEMOVE && (e !== this.Gl || this.C.iframesTracking ? (this.Gl = e, s.tgtHM = e) : s.tgtHM = ""))
            } else s.type === zo.MOUSEMOVE && (this.Gl = "");
            return s
        }
    }! function(t) {
        t[t.ANONYMIZED = 0] = "ANONYMIZED", t[t.CAPTURED = 1] = "CAPTURED", t[t.MASKED = 2] = "MASKED"
    }(ic || (ic = {}));
    class rc extends Xh {
        constructor(t, s, e) {
            super(), this.D = t, this.Zl = s, this.U = e, this.supportedEventTypes = [zo.TAP, zo.CLICK]
        }
        Wl(t) {
            let s = "";
            const e = document.createTreeWalker(t, NodeFilter.SHOW_TEXT);
            let i = e.nextNode();
            for (; i;) {
                if (s += i.textContent, this.Zl.getElementSensitiveStatus(i.parentElement) !== ic.CAPTURED) return !0;
                if (csString.prototype.trim.call(s).length >= 100) break;
                i = e.nextNode()
            }
            return !1
        }
        baseEnhanceAnalysisEvent(t, s) {
            if (St(csEventtarget.apply(t))) {
                const e = xe(csEventtarget.apply(t), "button,a");
                if (e && yt(e.textContent) && !this.Wl(e) && !this.U.hasPII(e.textContent, this.D.anonymizeDigits)) {
                    const t = An.truncate(csString.prototype.trim.call(e.textContent), 100);
                    t.length > 0 && (s.text = t)
                }
            }
            return s
        }
    }
    const oc = "v2/events",
        hc = ["submit"];
    class cc {
        constructor(t, s, e, i, n, r, o, h, c, a, u, l) {
            this.D = t, this.ha = s, this.K = e, this._l = i, this.Fu = n, this.Ia = r, this.Oi = o, this.$u = h, this.ou = c, this.Oa = a, this.Va = u, this.Zl = l
        }
        init() {
            const t = new Yh,
                s = this.Oa.create(`${this.D.getTrackerUri()}/${oc}`, !0, "base64");
            this.Ql = this.Jl(s), this.Kl = this.Yl(t, this.Ql.getRecoveryStorage(), s), this.Kl.init(), this.Va.addListener(this.Kl), this.ou.addListener(this.Kl), this.Ia.register(hc, ((t, s) => {
                this.Kl.pushSubmitEvent(t, s)
            }))
        }
        onStartTracking(t) {
            this.Ql.start(), this.Kl.start(t)
        }
        onAfterNaturalPageView() {
            this.Kl.initStates()
        }
        onAfterArtificialPageView() {
            this.Kl.initStates(), this.Kl.collectInitialEvents()
        }
        onArtificialPageViewEnd() {
            this.Kl.clearStates(!0)
        }
        onBeforeSessionRenewal() {
            this.Kl.clearStates(), this.Kl.stop(), this.Ql.stop()
        }
        onOptout() {
            this.Kl.stop(), this.Ql.stop()
        }
        Yl(t, s, e) {
            const i = new jo(window),
                n = new Ko,
                r = function(t, s, e) {
                    const i = [];
                    return t.mouseMoveHeatmapEnabled && csArray.prototype.push.call(i, new nc(t, s)), t.isClickedElementTextEnabled() && csArray.prototype.push.call(i, new rc(t, e, new ft)), csArray.prototype.push.call(i, new tc, new sc(s)), i
                }(this.D, this._l, this.Zl),
                o = new Jo(r, this._l, this.Fu),
                h = function(t, s, e) {
                    const i = [];
                    return t.isClickedElementTextEnabled() && csArray.prototype.push.call(i, new rc(t, e, new ft)), csArray.prototype.push.call(i, new sc(s)), i
                }(this.D, this._l, this.Zl),
                c = new Qo(h, this.$u),
                a = new sh(new Kh),
                u = new We;
            const l = new Un(`${this.D.getTrackerUri()}/${oc}`),
                d = new On(this.ha, this.K);
            return new Yo(this.D, o, c, n, i, t, l, d, this.Oi, s, this._l, a, u, e, undefined, undefined, undefined, undefined, undefined, undefined, undefined)
        }
        Jl(t) {
            return new Xo(new th("csAnalysisEventsPersisted"), t)
        }
    }
    var ac;
    ! function(t) {
        t.Artificial = "a", t.Renewal = "r", t.Natural = "n"
    }(ac || (ac = {}));
    class uc extends Fe {
        constructor(t, s, e, i) {
            super(), this.Uc = t, this.Xl = s, this.ot = e, this.Ga = i
        }
        init() {
            this.td()
        }
        onStart(t) {
            t ? this.sd() : this.nd()
        }
        onStop() {}
        triggerArtificialPageView(t, s) {
            this.isStarted ? this.rd(t, s) : At(t) && this.ot.overridePath(t, s)
        }
        nd() {
            this.Ga.setPageViewType(ac.Natural), this.Uc.emitBeforeNaturalPageView(), this.Xl.send(), this.ot.cleanupOverrideLifespan(), this.Uc.emitAfterNaturalPageView()
        }
        sd() {
            this.Ga.setPageViewType(ac.Renewal), this.Uc.emitBeforeNaturalPageView(), this.Xl.send(), this.Uc.emitAfterNaturalPageView()
        }
        rd(t, s) {
            this.Ga.setPageViewType(ac.Artificial), this.Uc.emitArtificialPageViewEnd(), At(t) && this.ot.overridePath(t, s), this.Uc.emitBeforeArtificialPageView(), this.Xl.send(), this.ot.cleanupOverrideLifespan(), this.Uc.emitAfterArtificialPageView()
        }
        td() {
            window.addEventListener("pageshow", (t => {
                this.isStarted && t.persisted && this.rd()
            }))
        }
    }
    const lc = window.navigator.language || window.navigator.userLanguage || window.navigator.browserLanguage || window.navigator.systemLanguage || "unknown";

    function dc() {
        return {
            la: lc
        }
    }
    class fc {
        constructor(t, s) {
            this.Na = t, this.Pa = s, this.od = !1
        }
        getRequestParameters() {
            return {
                dr: this.ad()
            }
        }
        addUrlMaskingPattern(t) {
            this.Pa.addUrlMaskingPattern(t)
        }
        enableRemoveQueryString() {
            this.od = !0
        }
        disableRemoveQueryString() {
            this.od = !1
        }
        ad() {
            const t = this.od ? this.Na.removeQueryString(this.ud()) : this.ud();
            return this.Na.anonymizeUrl(t, this.Pa.getUrlMaskingPatterns())
        }
        ud() {
            let t = "";
            try {
                t = window.top.document.referrer
            } catch (s) {
                if (window.parent) try {
                    t = window.parent.document.referrer
                } catch {
                    t = ""
                }
            }
            return "" === t && (t = document.referrer), "string" != typeof t && (t = ""), t
        }
    }
    class pc {
        constructor(t) {
            this.Y = t, this.ld = this.dd() && "currentScript" in document
        }
        pd() {
            const t = window.CSCurrentScript;
            if (!t) return null;
            const s = window.performance.getEntriesByName(t.src, "resource")[0];
            return !s || this.md(s) ? null : Math.round(s.responseEnd - s.fetchStart)
        }
        md(t) {
            const s = t.transferSize;
            return void 0 !== s ? 0 === s || 300 === s || s < t.encodedBodySize : t.connectStart === t.domainLookupEnd
        }
        getRequestParameters() {
            if (!this.ld || 1 !== this.vd()) return {};
            const t = this.pd();
            return null === t ? {} : {
                dt: `${Math.min(t,99999)}`
            }
        }
        vd() {
            var t;
            return (null === (t = this.Y.getSession()) || void 0 === t ? void 0 : t.pageNumber) || null
        }
        dd() {
            return "object" == typeof window.performance && "function" == typeof window.performance.getEntriesByName
        }
    }

    function mc(t) {
        const s = [],
            e = function(t) {
                let s = t;
                j(t, "/") && (s = csString.prototype.substring.call(s, 1));
                xt(t, "/") && (s = csString.prototype.slice.call(s, 0, -1));
                return s
            }(t),
            i = csString.prototype.split.call(e, "/");
        for (const t of i) j(t, ":") ? csArray.prototype.push.call(s, {
            key: t,
            value: `CS_ANONYMIZED_${csString.prototype.toUpperCase.call(csString.prototype.slice.call(t,1))}`
        }) : csArray.prototype.push.call(s, {
            key: t,
            value: null
        });
        return s
    }
    class vc {
        constructor() {
            this.gd = new Set, this.yd = [], this.wd = new Set, this.Ed = []
        }
        addUrlMaskingPattern(t) {
            if (this.gd.has(t)) return;
            this.gd.add(t);
            const s = mc(t);
            csArray.prototype.push.call(this.yd, s)
        }
        getUrlMaskingPatterns() {
            return this.yd
        }
        resetPartialUrlMaskingPatterns() {
            this.wd.clear(), this.Ed = []
        }
        addPartialUrlMaskingPattern(t) {
            if (this.wd.has(t)) return;
            this.wd.add(t);
            const s = mc(t);
            csArray.prototype.push.call(this.Ed, s)
        }
        getPartialUrlMaskingPatterns() {
            return this.Ed
        }
    }
    const gc = ["trackPageview"],
        yc = ["setPath"],
        wc = ["setQuery"],
        Ec = ["referrer:maskUrl"],
        Ac = ["referrer:removeQueryString"],
        _c = ["referrer:keepQueryString"];
    class Sc {
        constructor(t, s, e, i, n, r, o, h, c, a, u, l, d) {
            this.D = t, this.Ia = s, this.Uc = e, this.ua = i, this.K = n, this.Y = r, this.Ad = o, this.ps = h, this.Na = c, this.ot = a, this.ka = u, this.Ga = l, this._d = d
        }
        init() {
            var t;
            const e = new tt(this.D.getTrackerUri(), "pageview");
            this.Sd = new uc(this.Uc, e, this.ot, this.Ga);
            const i = new fc(this.Na, new vc);
            this.Sd.init();
            const n = new On(this.ua, this.K, Mi, i, this.ot, this.Ad, s, this.ps, this.Ga, new pc(this.Y), this.ka);
            if (this._d) {
                n.addProvider(this._d);
                const s = null === (t = this.D.heapEnvironment) || void 0 === t ? void 0 : t.env_id;
                n.addProvider({
                    getRequestParameters() {
                        const t = {
                            cw: "1"
                        };
                        return s && (t.happid = s), t
                    }
                })
            }
            e.setRequestParametersProviders(n), this.Ia.register(gc, ((t, s) => {
                yt(t) ? this.Rd(s) ? this.Sd.triggerArtificialPageView(t, s) : this.Sd.triggerArtificialPageView(t) : this.Sd.triggerArtificialPageView()
            })), this.Ia.register(yc, ((t, s) => {
                yt(t) && (this.Rd(s) ? this.ot.overridePath(t, s) : this.ot.overridePath(t))
            })), this.Ia.register(wc, ((t, s) => {
                yt(t) && (this.Rd(s) ? this.ot.overrideQuery(t, s) : this.ot.overrideQuery(t))
            })), this.Ia.register(Ec, (t => {
                yt(t) && i.addUrlMaskingPattern(t)
            })), this.Ia.register(Ac, (() => i.enableRemoveQueryString())), this.Ia.register(_c, (() => i.disableRemoveQueryString()))
        }
        start(t) {
            this.Sd.start(t)
        }
        onBeforeSessionRenewal() {
            this.Sd.stop()
        }
        Rd(t) {
            return wt(t) && null !== t
        }
    }
    class Rc {
        constructor(t) {
            this.qu = t
        }
        on(t, s) {
            return e => {
                this.qu.hasValidEventTarget(e) && this.Td(e, t) && s(e)
            }
        }
        Td(t, s) {
            const e = we(t);
            return C.call(e, s)
        }
        isMatchesSelectorSupported() {
            return !!C
        }
    }
    class Tc {
        constructor() {}
        onLoad(t) {
            this.rs = t
        }
        onLoadCallbackExecute() {
            this.rs()
        }
        start() {
            const t = this.onLoadCallbackExecute.bind(this);
            this.Id(t)
        }
        Id(t) {
            function s() {
                document.removeEventListener("DOMContentLoaded", s), window.removeEventListener("load", s), t()
            }
            "complete" === document.readyState || "loading" !== document.readyState && !document.documentElement.doScroll ? csSetTimeout(t) : (document.addEventListener("DOMContentLoaded", s), window.addEventListener("load", s))
        }
    }
    As([os("onLoad")], Tc.prototype, "onLoadCallbackExecute", null);
    class Ic {
        constructor(t, s, e) {
            this.D = t, this.K = s, this.Y = e, this.ql = Vt.now()
        }
        resetStartTime() {
            this.ql = Vt.now()
        }
        getSessionData() {
            const {
                projectId: t
            } = this.D, s = this.K.getVisitor();
            null == s && ns.warn("Visitor is null. This happens when a snippet tries to get Session Data before the tag was initialized.");
            const {
                id: e,
                visitsCount: i
            } = null != s ? s : {}, n = this.Y.getSession();
            null === n && ns.warn("Session is null. This happens when a snippet tries to get Session Data before the tag was initialized.");
            const {
                pageNumber: r
            } = null != n ? n : {};
            return {
                projectId: t,
                userId: e,
                sessionNumber: i,
                pageNumber: r,
                relativeTimestamp: Vt.now() - this.ql
            }
        }
    }
    const bc = ["clearSession"],
        Pc = ["extendSession"],
        Vc = ["getSessionData"],
        Cc = ["session:start:newVisitor"],
        kc = ["session:clear:visitor"];
    class Oc {
        constructor(t, s, e, i) {
            this.D = t, this.K = s, this.Y = e, this.Ia = i
        }
        init() {
            this.bd = new Ic(this.D, this.K, this.Y), this.Ia.register(bc, (() => this.Y.removeSession())), this.Ia.register(Pc, (() => this.Y.extendSessionPeriodically()), {
                disableApplyPending: !0
            }), this.Ia.register(Vc, (() => this.bd.getSessionData()), {
                disableApplyPending: !0
            }), this.Ia.register(Cc, (() => this.K.renewVisitor())), this.Ia.register(kc, (() => {
                this.K.resetVisitor()
            }), {
                disableApplyImmediate: !0
            })
        }
        onBeforeNaturalPageView() {
            this.K.createOrUpdateVisitor(), this.Y.createOrUpdateSession()
        }
        onBeforeArtificialPageView() {
            this.Y.abortQuotaServiceRequest(), this.K.createOrUpdateVisitor(), this.Y.createOrUpdateSession()
        }
        onAfterNaturalPageView() {
            this.bd.resetStartTime()
        }
        onAfterArtificialPageView() {
            this.bd.resetStartTime()
        }
        onOptout() {
            this.K.removeVisitor(), this.Y.removeSession()
        }
        onCollectStateChange(t, s) {
            this.Y.updateCollectState(t, s)
        }
    }
    class Nc {
        constructor(t, s) {
            this.Y = t, this.K = s, this.Pd = !1, this.Vd = le((() => this.Y.refreshSession()), 3e4)
        }
        onSessionExpired(t) {
            this.Cd = t
        }
        isSessionValid() {
            return !!this.Pd || !!this.Y.hasValidSession() && (!this.Y.pollCacheRefreshEvent() || !this.K.isSessionRenewed())
        }
        isCurrentPageviewValid() {
            const t = this.Y.hasValidSession();
            return this.Y.pollCacheRefreshEvent(!1) ? !this.K.isSessionRenewed() : t
        }
        refreshSession() {
            this.isSessionValid() ? this.Vd() : this.kd() && (this.Od = Vt.now(), this.renewSession())
        }
        renewSession() {
            this.Pd = !0, this.Cd(), this.Pd = !1
        }
        kd() {
            return !Et(this.Od) || Vt.now() - this.Od > 6e4
        }
    }
    var xc, $c;

    function Lc(t) {
        return t.tagDeploymentMode === xc.DualCollectionReview || t.tagDeploymentMode === xc.DualCollection
    }! function(t) {
        t.ContentSquare = "CONTENTSQUARE", t.LoadedByClicktale = "LOADED_BY_CLICKTALE", t.LoadClicktalePtc = "LOAD_CLICKTALE_PTC", t.DualCollectionReview = "DUAL_COLLECTION_REVIEW", t.DualCollection = "DUAL_COLLECTION", t.ContentSquareTagClickTaleEndpoints = "CONTENTSQUARE_TAG_CLICKTALE_ENDPOINTS"
    }(xc || (xc = {})),
    function(t) {
        t.isRecording = function() {
            return window.ClickTaleIsRecording && window.ClickTaleIsRecording()
        }, t.stopRecording = function() {
            window.ClickTaleStop && window.ClickTaleStop()
        }, t.triggerLogicalPageView = function(t) {
            window.ClickTaleLogicalWithUploadPage && window.ClickTaleLogicalWithUploadPage(t)
        }, t.sendPageEvent = function(t) {
            window.ClickTaleEvent && window.ClickTaleEvent(t)
        }, t.sendEventTriggerRecording = function(t) {
            window.ClickTaleEventTrigger && window.ClickTaleEventTrigger(t)
        }
    }($c || ($c = {}));
    const Mc = "RSA-OAEP",
        Dc = "AES-CTR";
    var Uc;
    ! function(t) {
        var s;
        let e, i = !1,
            n = null;
        const r = window.TextEncoder ? new window.TextEncoder : null;
        let o;

        function h() {
            var t, s;
            return null != (null === (s = null === (t = window.self.crypto) || void 0 === t ? void 0 : t.subtle) || void 0 === s ? void 0 : s.encrypt) && null != window.self.CryptoKey
        }
        async function c(s) {
            if (!h() || i) return null;
            await e;
            let r = Sn(s);
            r.byteLength > 190 && (r = r.slice(0, 190));
            try {
                return Rn(await t.crypto.encrypt({
                    name: Mc
                }, n, r))
            } catch {
                return null
            }
        }
        t.crypto = null === (s = window.crypto) || void 0 === s ? void 0 : s.subtle, t.prop = "toEncrypt", t.MAX_DIGEST_INPUT_SIZE = 100, t.isKeyImported = function() {
            return !i
        }, t.getCryptoKey = function() {
            return n
        }, t.isSupported = h, t.importKey = async function(s) {
            e = t.crypto.importKey("spki", Tn(s), {
                name: Mc,
                hash: "SHA-256"
            }, !1, ["encrypt"]).catch((() => (i = !0, null))), n = await e, e = void 0, n || rs.warn(`Fail to import public key '${s}'`)
        }, t.asymmetricEncrypt = c, t.symmetricEncrypt = async function(s, e) {
            if (!h() || i) return null;
            const n = {
                    counter: e.initializationVector,
                    name: Dc,
                    length: 64
                },
                o = r.encode(s);
            try {
                return Rn(await t.crypto.encrypt(n, e.cryptoKey, o))
            } catch {
                return null
            }
        }, t.encryptSecret = async function(s) {
            const e = await async function(s) {
                var e;
                if (!h()) return null;
                try {
                    return null !== (e = (await t.crypto.exportKey("jwk", s)).k) && void 0 !== e ? e : null
                } catch {
                    return null
                }
            }(s);
            if (!e) throw new Error("Export secret failed");
            const i = await c(e);
            if (!i) throw new Error("Encrypt secret failed");
            return i
        }, t.generateSymmetricKey = async function() {
            if (!h() || i) return null;
            try {
                return {
                    cryptoKey: await t.crypto.generateKey({
                        name: Dc,
                        length: 128
                    }, !0, ["encrypt", "decrypt"]),
                    initializationVector: window.crypto.getRandomValues(new Uint8Array(16))
                }
            } catch {
                return null
            }
        }, t.setDigestSalt = function(t) {
            o = t
        }, t.digest = async function(s) {
            s = csString.prototype.toLocaleLowerCase.call(csString.prototype.trim.call(s)), o && (s = `${s}:${o}`);
            const e = r.encode(s);
            try {
                return In(await t.crypto.digest("SHA-1", e))
            } catch {
                return null
            }
        }, t.generateKeyPair = function() {
            return window.crypto.subtle.generateKey({
                name: "RSA-OAEP",
                modulusLength: 2048,
                publicExponent: new Uint8Array([1, 0, 1]),
                hash: "SHA-256"
            }, !0, ["encrypt", "decrypt"])
        }
    }(Uc || (Uc = {}));
    const qc = "@user-identifier@";
    class Fc extends Fe {
        constructor(t, s, e, i) {
            super(), this.D = t, this.Nd = s, this.gu = e, this.xd = i, this.$d = [], this.dn = []
        }
        onStart() {
            csArray.prototype.forEach.call(this.$d, (t => this.trackPageEvent(t))), this.$d = [], csArray.prototype.forEach.call(this.dn, (t => this.trackEventTriggerRecording(t))), this.dn = []
        }
        onStop() {}
        trackPageEvent(t) {
            this.isStarted ? Fc.Ld(t) && (this.Md(t) ? Uc.isSupported() && this.Dd(t) : this.Ud(t)) : csArray.prototype.push.call(this.$d, t)
        }
        Md(t) {
            return j(t, qc)
        }
        async Dd(t) {
            if (!this.D.customHashIdEnabled) return;
            const s = csString.prototype.slice.call(t, 17);
            if (s.length > Uc.MAX_DIGEST_INPUT_SIZE) return void ns.warn("UserIdentifier event: invalid user identifier");
            const e = await Uc.digest(s);
            e ? (this.qd = {
                eventName: e,
                isETR: !1,
                isCustomHashId: !0
            }, this.Fd()) : ns.warn("Page event: unable to compute customHashId"), this.D.encryptionEnabled && this.xd.emitUserIdentifierEvent(s)
        }
        Ud(t) {
            this.xd.emitPageEvent(t), this.qd = {
                eventName: t,
                isETR: !1,
                isCustomHashId: !1
            }, this.Fd(), this.D.tagDeploymentMode === xc.LoadClicktalePtc && $c.sendPageEvent(t)
        }
        trackEventTriggerRecording(t) {
            this.isStarted ? Fc.Ld(t) && (this.D.malkaEtrEnabled ? this.Hd(t) : this.Bd(t)) : csArray.prototype.push.call(this.dn, t)
        }
        Hd(t) {
            j(t, "@ETP@") ? this.xd.emitEventTriggerRecording(t, je.ETR_PAGE) : this.xd.emitEventTriggerRecording(t, je.ETR_SESSION), this.qd = {
                eventName: t,
                isETR: !0,
                isCustomHashId: !1
            }, this.Fd()
        }
        Bd(t) {
            var s;
            (Lc(s = this.D) || s.tagDeploymentMode === xc.LoadClicktalePtc) && (this.xd.emitEventTriggerRecording(t, je.ETR_LEGACY), this.qd = {
                eventName: t,
                isETR: !0,
                isCustomHashId: !1
            }, this.Fd(), this.D.tagDeploymentMode === xc.LoadClicktalePtc && $c.sendEventTriggerRecording(t))
        }
        getRequestParameters() {
            return {
                value: this.gu.compressSync(this.qd.eventName, "base64"),
                ct: this.gu.algorithm,
                isETR: `${this.qd.isETR}`,
                isCustomHashId: `${this.qd.isCustomHashId}`
            }
        }
        Fd() {
            this.Nd.send()
        }
        static Ld(t) {
            return yt(t) && !!csString.prototype.trim.call(t)
        }
    }
    const Hc = ["trackPageEvent"],
        Bc = ["trackEventTriggerRecording"];
    class jc {
        constructor(t, s, e, i, n) {
            this.D = t, this.Ia = s, this.gu = e, this.ua = i, this.xd = n
        }
        init() {
            const t = new tt(this.D.getTrackerUri(), "pageEvent");
            this.jd = new Fc(this.D, t, this.gu, this.xd), t.setRequestParametersProviders(this.jd, this.ua), this.Ia.register(Hc, (t => {
                this.jd.trackPageEvent(t)
            })), this.Ia.register(Bc, (t => {
                this.jd.trackEventTriggerRecording(t)
            }))
        }
        onStartTracking() {
            this.jd.start()
        }
    }
    class zc {
        constructor() {
            this.subscriptions = {}
        }
        subscribe(t, s) {
            this.subscriptions[t] = s, 1 === Object.keys(this.subscriptions).length && this.onStartTracking()
        }
        unsubscribe(t) {
            delete this.subscriptions[t], 0 === Object.keys(this.subscriptions).length && this.onStopTracking()
        }
    }
    class Gc extends zc {
        constructor() {
            super(), this.Ye = new Lr((t => this.errorListener(t)))
        }
        onStartTracking() {
            this.Ye.observe()
        }
        onStopTracking() {
            this.Ye.disconnect()
        }
        errorListener(t) {
            const s = this.zd(t);
            for (const t in this.subscriptions) {
                (0, this.subscriptions[t])(s)
            }
        }
        Gd(t) {
            return t = null != t ? t : "[NO ERROR MESSAGE]", An.truncate(t, Gc.Cc, An.ELLIPSIS)
        }
        zd(t) {
            return {
                errorType: "jsError",
                message: this.Gd(t.message),
                filename: t.filename,
                lineno: t.lineno,
                colno: t.colno
            }
        }
    }
    Gc.Cc = 1024, As([os("Event handler type: error")], Gc.prototype, "errorListener", null);
    const Zc = ["[data-cs-mask]", "#c1_card_info_id"];
    class Wc {
        constructor(t) {
            this.D = t, this.Zd = [...Zc], this.Wd = [{
                selector: "input:not([type=button]):not([type=submit])",
                attrName: "value"
            }], this.Qd = {
                PIISelectors: [".ctHidden,textarea", ...Zc],
                Attributes: [{
                    selector: ".ctHidden,input:not([type=button]):not([type=submit])",
                    attrName: "value"
                }]
            }, this.Jd = {
                elementSelector: "",
                attrSelector: "",
                attrSelectors: []
            };
            const s = {
                PIISelectors: [],
                Attributes: []
            };
            Lc(this.D) || (csArray.prototype.push.call(s.PIISelectors, ...this.Zd), csArray.prototype.push.call(s.Attributes, ...this.Wd)), this.Jd = $e.getComputedSelectorSettings(s, this.Jd)
        }
        setMaskedElementSettingsFromCommand(t) {
            t = $e.sanitizeSelectorUserInput(t), $e.isSelectorUserInput(t) && this.Kd(t)
        }
        setMaskedElementSettingsFromParent(t) {
            const s = {
                PIISelectors: csString.prototype.split.call(t.elementSelector, ","),
                Attributes: t.attrSelectors
            };
            this.Kd(s)
        }
        getMaskedElementSettings() {
            return this.Jd
        }
        initCTPII() {
            var t, s, e, i, n, r;
            const o = this.Qd;
            (null === (e = null === (s = null === (t = null === window || void 0 === window ? void 0 : window.ClickTaleSettings) || void 0 === t ? void 0 : t.DOM) || void 0 === s ? void 0 : s.PII) || void 0 === e ? void 0 : e.Text) instanceof Array && o.PIISelectors.push(...window.ClickTaleSettings.DOM.PII.Text), (null === (r = null === (n = null === (i = null === window || void 0 === window ? void 0 : window.ClickTaleSettings) || void 0 === i ? void 0 : i.DOM) || void 0 === n ? void 0 : n.PII) || void 0 === r ? void 0 : r.Attributes) instanceof Array && window.ClickTaleSettings.DOM.PII.Attributes.forEach((t => {
                yt(t.attr) && yt(t.rule) && o.Attributes.push({
                    selector: t.rule,
                    attrName: t.attr
                })
            })), this.Kd(o)
        }
        Kd(t) {
            this.Jd = $e.getComputedSelectorSettings(t, this.Jd)
        }
    }
    class Qc {
        constructor(t) {
            this.Ia = t
        }
        init() {
            this.Yd(Qc.Xd, Mt), this.Yd(Qc.tf, Lt)
        }
        Yd(t, s) {
            this.Ia.register([t], ((t, e) => {
                yt(t) && (yt(e) || Rt(e)) && ns.error(e, `${s}${t}`)
            }))
        }
    }
    Qc.tf = "logSnippetError", Qc.Xd = "logImplementationSnippetError";
    class Jc {
        constructor(t, s, e, i, n) {
            this.D = t, this.iu = s, this.Ta = e, this.Zl = i, this.ou = n
        }
        init() {
            this.iu.onChildMessage(((t, s, e) => this.ou.emitIframeEvent(t, s, e))), this.iu.setSentiveStatusCallback((() => this.Zl.getSensitiveStatus())), this.iu.setRecordingContextCallback((() => this.Ta.getRecordingContext()))
        }
        onStartTracking() {
            this.D.iframesTracking && this.iu.start()
        }
        onOptout() {
            this.D.iframesTracking && this.iu.stop()
        }
        onSensitiveStatusChange() {
            if (this.D.iframesTracking) {
                const t = this.Zl.getSensitiveStatus();
                this.iu.onSensitiveStatusChange(t)
            }
        }
        onRecordingContextChange() {
            if (this.D.iframesTracking) {
                const t = this.Ta.getRecordingContext();
                this.iu.onRecordingContextChange(t)
            }
        }
    }
    class Kc extends Fe {
        constructor(t) {
            super(), this.D = t, this.sf = 0, this.ef = new Map, this.if = {
                boundElement: window,
                type: "message",
                listener: t => this.nf(t)
            }
        }
        onChildMessage(t) {
            this.rf = t
        }
        setRecordingContextCallback(t) {
            this.hf = t
        }
        setSentiveStatusCallback(t) {
            this.cf = t
        }
        onSensitiveStatusChange(t) {
            const s = ts.buildBaseMessage(Xt.SensitiveStatus, Yt.Parent, this.D.projectId);
            s.content = t;
            const e = ts.buildBaseMessage(Xt.SensitiveStatus, Yt.Parent, this.D.projectId);
            e.content = { ...t,
                started: !1,
                useAnonymization: !0,
                capturedElementSelector: ""
            }, this.ef.forEach((t => {
                if (t.port) {
                    const i = this.af(t) ? e : s;
                    this.uf(t, i)
                }
            }))
        }
        onRecordingContextChange(t) {
            const s = ts.buildBaseMessage(Xt.RecordingContext, Yt.Parent, this.D.projectId);
            s.content = t, this.ef.forEach((t => {
                !this.af(t) && t.port && this.uf(t, s)
            }))
        }
        sendToChildren(t, s) {
            const e = ts.buildBaseMessage(t, Yt.Parent, this.D.projectId);
            e.content = s, this.lf(e)
        }
        onStart() {
            ce(this.if, !1), this.df()
        }
        onStop() {
            this.ff(), ae(this.if, !1), this.pf()
        }
        df() {
            const t = this.mf();
            this.vf(t), csArray.prototype.forEach.call(t, (t => {
                if (null === this.gf(t)) {
                    const s = {
                        iframe: t
                    };
                    this.ef.set(this.sf, s), this.sf += 1
                }
            })), this.yf()
        }
        mf() {
            return csArray.prototype.filter.call(qi.findAllElements("iframe"), (t => this.wf(t)))
        }
        vf(t) {
            this.ef.forEach(((s, e) => {
                s.iframe && -1 === csArray.prototype.indexOf.call(t, s.iframe) && this.Ef(e, s)
            }))
        }
        Ef(t, s) {
            s.port && ts.closeChannelPort(s.port), this.ef.delete(t)
        }
        pf() {
            this.ef.forEach((t => {
                t.port && ts.closeChannelPort(t.port)
            })), this.ef.clear()
        }
        gf(t) {
            let s = null;
            return this.ef.forEach(((e, i) => {
                null === s && e.iframe === t && (s = i)
            })), s
        }
        wf(t) {
            return t.id !== i && (!t.src || Zt(Gt(t.src), this.D.hostnames))
        }
        lf(t) {
            this.ef.forEach((s => {
                this.uf(s, t)
            }))
        }
        uf(t, s) {
            const e = s.type === Xt.SensitiveStatus || s.type === Xt.RecordingContext;
            !t.port || e && !t.initialStatusSent || ts.sendChannelMessage(t.port, s)
        }
        yf() {
            this.ef.forEach(((t, s) => {
                if (t.iframe.contentWindow) {
                    const e = this.Af(s);
                    ts.sendPostMessage(t.iframe.contentWindow, "*", e)
                }
            }))
        }
        ff() {
            const t = this._f();
            this.ef.forEach((s => {
                s.port ? ts.sendChannelMessage(s.port, t) : s.iframe.contentWindow && ts.sendPostMessage(s.iframe.contentWindow, "*", t)
            }))
        }
        Af(t) {
            return ts.buildBaseMessage(Xt.Discovery, Yt.Parent, this.D.projectId, t)
        }
        _f() {
            return ts.buildBaseMessage(Xt.Stop, Yt.Parent, this.D.projectId)
        }
        Sf(t, s) {
            const e = this.ef.get(t);
            void 0 !== e ? (e.port = s, e.port.onmessage = t => {
                this.Rf(t, e)
            }) : ns.error(`Parent received channel messaging initialization from unknow child id : ${t} (${this.sf})`)
        }
        Tf(t) {
            if (!t.port) return;
            const s = ts.buildBaseMessage(Xt.SensitiveStatus, Yt.Parent, this.D.projectId),
                e = this.cf();
            this.af(t) && (e.started = !1, e.capturedElementSelector = "", e.useAnonymization = !0), s.content = e, ts.sendChannelMessage(t.port, s)
        }
        If(t) {
            if (!t.port) return;
            const s = ts.buildBaseMessage(Xt.RecordingContext, Yt.Parent, this.D.projectId),
                e = this.hf();
            this.af(t) && (e.isRecording = !1, e.isMutationTrackerStarted = !1), s.content = e, ts.sendChannelMessage(t.port, s)
        }
        Rf(t, s) {
            if (void 0 === s) return void ns.error(`Parent received channelMessage from unknown child : ${csJSON.stringify(t.data)}`);
            const e = t.data.type,
                i = t.data.content;
            e === Xt.EndOfBufferedMessages ? (this.Tf(s), this.If(s), s.initialStatusSent = !0) : this.rf(s.iframe, e, i)
        }
        nf(t) {
            if (ts.isMessageValid(t, Yt.Child, this.D.projectId, this.D.hostnames)) switch (t.data.type) {
                case Xt.Discovery:
                    if (void 0 === t.data.id) return void this.df();
                    if (t.ports && 1 === t.ports.length && this.ef.has(t.data.id)) return void this.Sf(t.data.id, t.ports[0]);
                    ns.error(`Parent received wrong channelMessage initialization : (${t.origin}) : ${csJSON.stringify(t.data)}`);
                    break;
                case Xt.ChildLogMessage:
                    this.rf(null, Xt.ChildLogMessage, t.data.content);
                    break;
                default:
                    ns.warn(`Parent received unexpected postMessage type from child (${t.origin}) : ${csJSON.stringify(t.data)}`)
            }
        }
        af(t) {
            return $e.isMaskedElement(t.iframe) || $e.isMaskedElementChild(t.iframe)
        }
    }
    class Yc {
        constructor(t) {
            this.bf = t
        }
        buildApiErrors(t, s) {
            const e = this.bf.collectDataPoints(t, s);
            if (null === e) return null;
            const i = this.Pf(t, e);
            if (s) {
                return {
                    apiError: i,
                    detailedApiError: this.Vf(t, e)
                }
            }
            return {
                apiError: i
            }
        }
        Vf(t, s) {
            const e = this.Cf(t);
            return s.collectQueryParam && t.queryParameters && (e.queryParameters = t.queryParameters), s.collectRequestBody && t.requestBody && (e.requestBody = t.requestBody), s.collectResponseBody && t.requestBody && (e.responseBody = t.responseBody), Object.keys(s.standardRequestHeaders).length > 0 && (e.standardRequestHeaders = s.standardRequestHeaders), Object.keys(s.standardResponseHeaders).length > 0 && (e.standardResponseHeaders = s.standardResponseHeaders), Object.keys(s.customRequestHeaders).length > 0 && (e.customRequestHeaders = csJSON.stringify(s.customRequestHeaders)), Object.keys(s.customResponseHeaders).length > 0 && (e.customResponseHeaders = csJSON.stringify(s.customResponseHeaders)), Object.keys(s.plainCustomRequestHeaders).length > 0 && (e.plainCustomRequestHeaders = s.plainCustomRequestHeaders), Object.keys(s.plainCustomResponseHeaders).length > 0 && (e.plainCustomResponseHeaders = s.plainCustomResponseHeaders), s.plainResponseBodyAttributes && Object.keys(s.plainResponseBodyAttributes).length > 0 && (e.plainResponseBodyAttributes = s.plainResponseBodyAttributes), s.plainRequestBodyAttributes && Object.keys(s.plainRequestBodyAttributes).length > 0 && (e.plainRequestBodyAttributes = s.plainRequestBodyAttributes), Object.keys(s.responseBodyAttributes).length > 0 && (e.responseBodyAttributes = csJSON.stringify(s.responseBodyAttributes)), Object.keys(s.requestBodyAttributes).length > 0 && (e.requestBodyAttributes = csJSON.stringify(s.requestBodyAttributes)), e
        }
        Cf(t) {
            return {
                errorType: "apiError",
                url: t.url,
                method: t.method,
                requestTime: t.requestTime,
                responseTime: t.responseTime,
                statusCode: t.statusCode,
                library: t.library
            }
        }
        Pf(t, s) {
            const e = this.Cf(t);
            return s.matchingBodyContents.length > 0 && (e.matchingBodyContents = s.matchingBodyContents), Object.keys(s.plainResponseBodyAttributes).length > 0 && (e.plainBodyResponseAttributes = s.plainResponseBodyAttributes), e
        }
    }
    class Xc extends zc {
        constructor(t, s, e) {
            super(), this.kf = t, this.Of = s, this.Nf = e, this.xf = 0, this.$f = new Yc(e)
        }
        subscribe(t, s, e) {
            (null == e ? void 0 : e.detailedEvent) && (Object.defineProperty(s, "detailedEvent", {
                value: e.detailedEvent
            }), this.xf++), super.subscribe(t, s)
        }
        unsubscribe(t) {
            var s;
            (null === (s = this.subscriptions[t]) || void 0 === s ? void 0 : s.hasOwnProperty("detailedEvent")) && this.xf--, super.unsubscribe(t)
        }
        init() {
            const t = this.Nf.computeApiErrorCollectionOptions();
            this.kf.setCollectionOptions(t), this.kf.onEvent((t => this.Lf(t))), this.Of.setCollectionOptions(t), this.Of.onEvent((t => this.Lf(t)))
        }
        onStartTracking() {
            this.kf.start(), this.Of.start()
        }
        onStopTracking() {
            this.kf.stop(), this.Of.stop()
        }
        Lf(t) {
            const s = this.$f.buildApiErrors(t, 0 !== this.xf);
            if (s)
                for (const t in this.subscriptions) {
                    const e = this.subscriptions[t];
                    e.hasOwnProperty("detailedEvent") ? s.detailedApiError && e(s.detailedApiError) : e(s.apiError)
                }
        }
    }
    class ta {
        constructor(t, s) {
            this.Pa = t, this.Na = s
        }
        addUrlMaskingPattern(t) {
            this.Pa.addUrlMaskingPattern(t)
        }
        anonymize(t) {
            const s = this.Na.removeQueryString(t.url);
            return { ...t,
                url: this.Na.anonymizeUrl(s, this.Pa.getUrlMaskingPatterns(), this.Pa.getPartialUrlMaskingPatterns()),
                library: t.library ? this.Na.anonymizeUrl(t.library, this.Pa.getUrlMaskingPatterns(), this.Pa.getPartialUrlMaskingPatterns()) : void 0
            }
        }
    }
    class sa {
        constructor(t, s) {
            this.U = t, this.ot = s
        }
        anonymize(t) {
            return yt(t.message) && (t.message = this.Mf(t.message), t.message = this.U.anonymizePII(t.message)), yt(t.filename) && (t.filename = this.ot.computeOverriddenUrl(t.filename)), t
        }
        Mf(t) {
            return csString.prototype.replace.call(t, /(value\s*=\s*".*"|value\s*=\s*'.*')/, "value='CS_ANONYMIZED_VALUE'")
        }
    }
    class ea extends zc {
        constructor(t) {
            super(), this.Df = t, this.qn = [{
                boundElement: document,
                type: "touchstart",
                listener: t => this.mn(t)
            }, {
                boundElement: document,
                type: "touchmove",
                listener: t => this.mn(t)
            }, {
                boundElement: document,
                type: "touchend",
                listener: t => this.mn(t)
            }], this.Uf = new Vr, this.Uf.onGesture(((t, s) => this.lc(t, s)))
        }
        lc(t, s) {
            for (const e in this.subscriptions) {
                (0, this.subscriptions[e])(t, s)
            }
        }
        onStartTracking() {
            this.canDetectGesture() && csArray.prototype.forEach.call(this.qn, (t => ce(t)))
        }
        onStopTracking() {
            this.canDetectGesture() && csArray.prototype.forEach.call(this.qn, (t => ae(t)))
        }
        canDetectGesture() {
            return void 0 !== window.devicePixelRatio
        }
        mn(t) {
            this.Df.tryToExecute("process gesture event", (() => {
                if (this.Uf.isValidTouchEvent(t)) switch (t.type) {
                    case "touchstart":
                        this.Uf.processActionDown(t);
                        break;
                    case "touchmove":
                        this.Uf.processActionMove();
                        break;
                    case "touchend":
                        this.Uf.processActionUp(t)
                }
            }))()
        }
        static isSwipe(t) {
            return t.type === _r.FLICK || t.type === _r.DRAG
        }
    }
    class ia extends Fe {
        constructor(t, s) {
            super(), this.Mi = t, this.qf = s, this.Ff = 0
        }
        onStart() {
            ns.isPerfLoggingActive() && (this.Hf = window.csSetInterval((() => this.Bf()), ia.jf))
        }
        onStop() {
            ns.isPerfLoggingActive() && (this.Bf(), csClearInterval(this.Hf))
        }
        Bf() {
            if (ps.isEmpty || this.Ff >= ia.zf) return;
            this.Ff++;
            const t = {
                    a: ia.Gf,
                    l: ia.Zf,
                    ...this.qf.getRequestParameters()
                },
                s = [];
            ps.forEach((e => {
                csArray.prototype.forEach.call(e, (e => {
                    csArray.prototype.push.call(s, { ...e,
                        ...t
                    })
                }))
            })), this.Mi.send(s), ps.clear()
        }
    }
    ia.Gf = "uxa", ia.Zf = "perf", ia.jf = 5e3, ia.zf = 5;
    class na {
        constructor(t, s, e) {
            this.D = t, this.qf = s, this.Oa = e
        }
        init() {
            this.Wf = new ia(this.Oa.create(this.D.getLoggerUri(), !0), this.qf)
        }
        onStartTracking() {
            this.Wf.start()
        }
        onOptout() {
            this.Wf.stop()
        }
    }
    class ra {
        constructor(t) {
            this.Zl = t, this.Qf = !1
        }
        enableRecordingContext(t, s, e, i) {
            this.Qf = !0, this.pu = t, this.Y = s, this.Li = e, this.Fa = i
        }
        getRecordingContext() {
            var t, s;
            if (!this.Qf) return {
                isRecording: !1,
                recordingStartTimestamp: 0,
                etrState: Be.ETR_OFF,
                etrStatus: ze.ETR_DISABLED
            };
            const e = this.Zl.getSensitiveStatus();
            return {
                isRecording: this.pu.isRecording(),
                isMutationTrackerStarted: this.pu.isStarted,
                useAnonymization: e.useAnonymization,
                encryptionSelectors: null === (t = this.Li) || void 0 === t ? void 0 : t.getEncryptionSelectors(),
                activateOnlineAssetsOnNextStart: null === (s = this.pu.getStaticResourceManagerStatus()) || void 0 === s ? void 0 : s.onlineAssets.enabledForChildrenOnNextStart,
                recordingStartTimestamp: parseInt(this.pu.getRecordingStartTimestamp(), 10),
                etrState: this.Y.getEtrState(),
                etrStatus: this.Fa.getEtrStatus()
            }
        }
    }
    class oa {
        static isRecordingSupported() {
            return "MutationObserver" in window && "visibilityState" in document
        }
        static isAsyncSerializationSupported() {
            return "Promise" in window && "findIndex" in csArray.prototype
        }
    }
    class ha extends Fe {
        constructor(t, s, e, i) {
            super(), this.xi = t, this.Jf = s, this.ha = e, this.$i = i, this.Kf = [], this.Wi = 0
        }
        init() {
            this.xi.init()
        }
        initStates() {
            this.Yf(), this.Kf = [], this.Wi = 0, this.Ll()
        }
        Ll() {
            this.ql = Vt.now()
        }
        Ul() {
            return Vt.now() - this.ql
        }
        onStart() {
            this.xi.subscribe(ha.Rn, (t => this.mn(t)))
        }
        onStop() {
            this.xi.unsubscribe(ha.Rn)
        }
        onIframeApiError(t) {
            this.mn(t)
        }
        mn(t) {
            this.isStarted && this.Wi < ha._a && (t.relativeTime = this.Ul(), csArray.prototype.push.call(this.Kf, this.$i.anonymize(t)), this.Xf())
        }
        Yf() {
            this.Jf.removeQueryParams(), this.Jf.setQueryParams(this.ha.getRequestParameters())
        }
        Xf() {
            this.Jf.send({
                errors: this.Kf
            }), this.Kf = [], this.Wi += 1
        }
    }
    ha.Rn = "ApiErrorsService", ha._a = 20;
    const ca = ["api-errors:maskUrl"];
    class aa {
        constructor(t, s, e, i, n, r, o) {
            this.xi = t, this.$i = s, this.D = e, this.ha = i, this.ou = n, this.Ia = r, this.Oa = o
        }
        init() {
            const t = this.Oa.create(`${this.D.getTrackerUri()}/api-errors`, !0);
            this.tp = new ha(this.xi, t, this.ha, this.$i), this.tp.init(), this.ou.addListener(this.tp), this.sp()
        }
        sp() {
            this.Ia.register(ca, (t => {
                yt(t) && this.$i.addUrlMaskingPattern(t)
            }))
        }
        onStartTracking() {
            this.tp.start()
        }
        onAfterNaturalPageView() {
            this.tp.initStates()
        }
        onAfterArtificialPageView() {
            this.tp.initStates()
        }
        onBeforeSessionRenewal() {
            this.tp.stop()
        }
        onOptout() {
            this.tp.stop()
        }
    }
    class ua extends Fe {
        constructor(t, s, e, i, n, r) {
            super(), this.ep = t, this.ip = s, this.ha = e, this.Ni = i, this.Va = n, this.ot = r, this.np = [], this.Sa = 0, this.rp = []
        }
        initStates() {
            this.ql = Vt.now(), this.ip.removeQueryParams(), this.ip.setQueryParams(this.ha.getRequestParameters()), this.np = [], this.Sa = 0
        }
        onStart() {
            this.ep.subscribe(ua.Rn, (t => this.mn(t))), this.op()
        }
        onStop() {
            this.ep.unsubscribe(ua.Rn)
        }
        onIframeJavascriptError(t) {
            this.mn(t)
        }
        trackCustomError(t) {
            const s = {
                errorType: "jsError",
                message: `Custom Error: ${t}`,
                lineno: 1,
                colno: 1,
                filename: "https://cserror.com/texterror.js"
            };
            this.hp(s)
        }
        hp(t) {
            if (this.isStarted) {
                const s = this.mn(t);
                s && this.Va.emitCustomJavaScriptErrorEvent(s)
            } else csArray.prototype.push.call(this.rp, t)
        }
        op() {
            this.isStarted && (csArray.prototype.forEach.call(this.rp, (t => this.hp(t))), this.rp = [])
        }
        mn(t) {
            if (this.isStarted && this.Sa < 20) {
                const s = { ...t,
                    pageUrl: this.ot.getAnonymizedUrl(),
                    rt: this.Ul()
                };
                return this.Ni.anonymize(s), csArray.prototype.push.call(this.np, s), this.Xf(), s
            }
            return null
        }
        Ul() {
            return Vt.now() - this.ql
        }
        Xf() {
            this.ip.send({
                errors: this.np
            }), this.np = [], this.Sa += 1
        }
    }
    ua.Rn = "JavaScriptErrorsService";
    const la = ["trackError"];
    class da {
        constructor(t, s, e, i, n, r, o, h, c) {
            this.ep = t, this.Ni = s, this.D = e, this.ha = i, this.ou = n, this.Ia = r, this.Va = o, this.ot = h, this.Oa = c
        }
        init() {
            const t = this.Oa.create(`${this.D.getTrackerUri()}/errors`, !0);
            this.cp = new ua(this.ep, t, this.ha, this.Ni, this.Va, this.ot), this.ou.addListener(this.cp), this.sp()
        }
        sp() {
            this.D.jsCustomErrorsEnabled && !this.D.customErrors.enabled && this.Ia.register(la, (t => {
                this.cp.trackCustomError(t)
            }))
        }
        onStartTracking() {
            this.cp.start()
        }
        onAfterNaturalPageView() {
            this.cp.initStates()
        }
        onAfterArtificialPageView() {
            this.cp.initStates()
        }
        onBeforeSessionRenewal() {
            this.cp.stop()
        }
        onOptout() {
            this.cp.stop()
        }
    }
    var fa;
    ! function(t) {
        t.buildCustomErrorEvent = function(t, s, e = !1) {
            const i = {
                message: An.truncate(t, 300, An.ELLIPSIS),
                errorType: "customError"
            };
            return (e || function(t) {
                const s = Object.keys(t).length;
                return s > 0 && s <= 5
            }(s)) && (! function(t) {
                for (const s in t) {
                    let e = t[s];
                    if (t[s].length > 30 && (e = An.truncate(t[s], 30, An.ELLIPSIS), t[s] = e), s.length > 30) {
                        const i = An.truncate(s, 30, An.ELLIPSIS);
                        delete t[s], t[i] = e
                    }
                }
            }(s), i.attributes = s), i
        }
    }(fa || (fa = {}));
    class pa extends Fe {
        constructor(t, s, e, i, n) {
            super(), this.ap = t, this.ha = s, this.up = e, this.xd = i, this.lp = n, this.dp = [], this.Ra = 0, this.rp = []
        }
        initStates() {
            var t;
            this.Yf(), this.ql = Vt.now(), this.dp = [], this.Ra = 0, null === (t = this.lp) || void 0 === t || t.onEvent((t => this.mn(t)))
        }
        trackCustomError(t, s = {}) {
            if (!yt(t) || !wt(s)) return;
            const e = fa.buildCustomErrorEvent(t, s);
            this.hp(e)
        }
        onIframeCustomError(t) {
            this.mn(t)
        }
        onStart() {
            var t;
            this.op(), null === (t = this.lp) || void 0 === t || t.start()
        }
        onStop() {
            var t;
            null === (t = this.lp) || void 0 === t || t.stop()
        }
        op() {
            this.isStarted && (csArray.prototype.forEach.call(this.rp, (t => this.hp(t))), this.rp = [])
        }
        hp(t) {
            if (this.isStarted) {
                const s = this.mn(t);
                s && this.xd.emitCustomErrorEvent(s)
            } else csArray.prototype.push.call(this.rp, t)
        }
        mn(t) {
            if (this.isStarted && this.Ra < 20) {
                const s = this.fp(t);
                return csArray.prototype.push.call(this.dp, s), this.Xf(), s
            }
            return null
        }
        fp(t) {
            const s = { ...t,
                rt: this.Ul()
            };
            return s.message = this.up.anonymizePII(t.message), s
        }
        Yf() {
            this.ap.removeQueryParams(), this.ap.setQueryParams(this.ha.getRequestParameters())
        }
        Ul() {
            return Vt.now() - this.ql
        }
        Xf() {
            this.ap.send({
                errors: this.dp
            }), this.dp = [], this.Ra += 1
        }
    }
    class ma {
        constructor(t, s, e, i, n, r, o, h) {
            this.up = t, this.D = s, this.ha = e, this.Ia = i, this.Va = n, this.Oa = r, this.ou = o, this.lp = h
        }
        init() {
            const t = this.Oa.create(`${this.D.getTrackerUri()}/custom-errors`, !0);
            this.pp = new pa(t, this.ha, this.up, this.Va, this.lp), this.ou.addListener(this.pp), this.sp()
        }
        sp() {
            this.Ia.register(la, ((t, s) => {
                this.pp.trackCustomError(t, s)
            }))
        }
        onStartTracking() {
            this.pp.start()
        }
        onAfterNaturalPageView() {
            this.pp.initStates()
        }
        onAfterArtificialPageView() {
            this.pp.initStates()
        }
        onBeforeSessionRenewal() {
            this.pp.stop()
        }
        onOptout() {
            this.pp.stop()
        }
    }
    class va {
        constructor() {
            this.mp = ac.Natural
        }
        setPageViewType(t) {
            this.mp = t
        }
        getPageViewType() {
            return this.mp
        }
        getRequestParameters() {
            return {
                pvt: this.mp
            }
        }
    }
    class ga {
        constructor(t) {
            this.Oi = t
        }
        onAfterVisitorRenewal() {
            this.Oi.renewSession()
        }
    }
    var ya, wa;
    ! function(t) {
        t.replayRecordingUnmaskedUrlRegex = "replayRecordingUnmaskedUrlRegex", t.replayRecordingMaskedUrlRegex = "replayRecordingMaskedUrlRegex", t.replayRecordingUnmaskedUrlRegexRules = "replayRecordingUnmaskedUrlRegexRules", t.replayRecordingMaskedUrlRegexRules = "replayRecordingMaskedUrlRegexRules"
    }(ya || (ya = {})),
    function(t) {
        t.START = "start", t.NOT_START = "not-start", t.END = "end", t.NOT_END = "not-end", t.CONTAIN = "contain", t.NOT_CONTAIN = "not-contain", t.EXACT = "exact", t.NOT_EXACT = "not-exact"
    }(wa || (wa = {}));
    class Ea {
        constructor(t, s, e, i) {
            this.Ad = t, this.D = s, this.ot = e, this.vp = i
        }
        init() {
            this.gp()
        }
        shouldUseAnonymization() {
            if (this.Ad.isReplayUnanonymizedAllowedByConsent()) {
                switch (this.D.anonymisationMethod) {
                    case null:
                    case ya.replayRecordingMaskedUrlRegex:
                        return !(!this.D.replayRecordingMaskedUrlRegex || !this.D.replayRecordingMaskedUrlRegex.test(this.ot.getAnonymizedUrl()));
                    case ya.replayRecordingMaskedUrlRegexRules:
                        return this.vp.evaluateUrl(this.ot.getAnonymizedUrl())
                }
                return !1
            }
            switch (this.D.anonymisationMethod) {
                case null:
                case ya.replayRecordingUnmaskedUrlRegex:
                    return !(this.D.replayRecordingUnmaskedUrlRegex && this.D.replayRecordingUnmaskedUrlRegex.test(this.ot.getAnonymizedUrl()));
                case ya.replayRecordingUnmaskedUrlRegexRules:
                    return !this.vp.evaluateUrl(this.ot.getAnonymizedUrl())
            }
            return !0
        }
        gp() {
            this.D.anonymisationMethod === ya.replayRecordingMaskedUrlRegexRules && this.D.replayRecordingMaskedUrlRegexRules ? this.vp.setRegexRules(this.D.replayRecordingMaskedUrlRegexRules) : this.D.anonymisationMethod === ya.replayRecordingUnmaskedUrlRegexRules && this.D.replayRecordingUnmaskedUrlRegexRules && this.vp.setRegexRules(this.D.replayRecordingUnmaskedUrlRegexRules)
        }
    }
    class Aa {
        constructor() {
            this.yp = []
        }
        setRegexRules(t) {
            this.yp = csArray.prototype.map.call(t, (t => this.wp(t)))
        }
        evaluateUrl(t) {
            return csArray.prototype.some.call(this.yp, (s => {
                var e, i;
                const n = this.Ep(t, s);
                return (null == s ? void 0 : s.notOperator) ? !(null === (e = s.regex) || void 0 === e ? void 0 : e.test(n)) : null === (i = s.regex) || void 0 === i ? void 0 : i.test(n)
            }))
        }
        Ep(t, s) {
            const e = Qt(t);
            return e ? s.ignoreQueryParams && s.ignoreURIFragments ? `${e.origin}${e.pathname}` : s.ignoreQueryParams ? `${e.origin}${e.pathname}${e.hash}` : s.ignoreURIFragments ? `${e.origin}${e.pathname}${e.search}` : t : t
        }
        Ap(t) {
            return t.ignoreCaseSensitivity ? "i" : ""
        }
        wp(t) {
            switch (t.operator) {
                case wa.NOT_START:
                    t.notOperator = !0;
                case wa.START:
                    t.regex = new csRegExp(`^${t.value}`, this.Ap(t));
                    break;
                case wa.NOT_END:
                    t.notOperator = !0;
                case wa.END:
                    t.regex = new csRegExp(`${t.value}$`, this.Ap(t));
                    break;
                case wa.NOT_CONTAIN:
                    t.notOperator = !0;
                case wa.CONTAIN:
                    t.regex = new csRegExp(`${t.value}`, this.Ap(t));
                    break;
                case wa.NOT_EXACT:
                    t.notOperator = !0;
                case wa.EXACT:
                    t.regex = new csRegExp(`^${t.value}$`, this.Ap(t));
                    break;
                default:
                    ns.warn(`buildRegexWithRule, unknown type: ${t.operator}`)
            }
            return t
        }
    }
    class _a {
        constructor() {
            this._p = ["application/json", "application/graphql", "application/xml", "text/plain", "text/csv", "text/html", "text/xml", "text/javascript"]
        }
        setCollectionOptions(t) {
            this.Sp = t
        }
        isValidBodyType(t) {
            const s = t["content-type"];
            if (!s) return !1;
            const e = csString.prototype.toLocaleLowerCase.call(s);
            return Us(this._p, (t => j(e, t)))
        }
        canCollect(t, s) {
            return this.Rp(t, s) && this.Tp(s)
        }
        Rp(t, s) {
            return t >= 400 || t >= 200 && t < 300 && this.Sp.statusCodes.has(t) && this.Ip(s)
        }
        Ip(t) {
            return Us(this.Sp.urls, (s => -1 !== csString.prototype.indexOf.call(t, s)))
        }
        Tp(t) {
            return function(t, s) {
                const e = t.length;
                for (let i = 0; i < e; i++)
                    if (!s(t[i], i)) return !1;
                return !0
            }(this.Sp.excludedDomains, (s => -1 === csString.prototype.indexOf.call(t, s)))
        }
    }
    class Sa extends _a {
        constructor() {
            super(), this.bp = csSymbol("ApiCall"), this.se = !1, this.Pp = null, this.Vp = null, this.Cp = null, this.kp = ({
                context: t,
                args: s,
                callerName: e
            }) => this.interceptOpen(t, s, e), this.Op = ({
                context: t,
                args: s
            }) => this.interceptSetRequestHeader(t, s), this.Np = ({
                context: t,
                args: s
            }) => this.interceptSend(t, s)
        }
        onEvent(t) {
            this.Fn = t
        }
        start() {
            this.se || (this.xp(), this.Pp && this.Pp.activate(), this.Vp && this.Vp.activate(), this.Cp && this.Cp.activate(), this.se = !0)
        }
        stop() {
            this.se && (this.Pp && this.Pp.deactivate(), this.Vp && this.Vp.deactivate(), this.se = !1)
        }
        xp() {
            this.Pp || (this.Pp = ie({
                target: XMLHttpRequest.prototype,
                methodName: "open",
                hook: this.kp,
                options: {
                    withCallerName: !0
                }
            })), this.Vp || (this.Vp = ie({
                target: XMLHttpRequest.prototype,
                methodName: "setRequestHeader",
                hook: this.Op
            })), this.Cp || (this.Cp = ie({
                target: XMLHttpRequest.prototype,
                methodName: "send",
                hook: this.Np
            }))
        }
        interceptOpen(t, s, e) {
            if (!s[1] || !yt(s[1])) return;
            const [i, n] = csString.prototype.split.call(s[1], "?");
            t[this.bp] = {
                library: e,
                requestTime: Vt.now(),
                method: s[0],
                url: zt(i),
                queryParameters: n,
                statusCode: 0,
                responseHeaders: {},
                requestHeaders: {},
                responseBody: "",
                requestBody: ""
            }, t.addEventListener("readystatechange", (() => this.readyStateChangeListener(t)))
        }
        readyStateChangeListener(t) {
            t[this.bp] && t.readyState === XMLHttpRequest.DONE && this.canCollect(t.status, t[this.bp].url) && (t[this.bp].responseTime = Vt.now(), t[this.bp].statusCode = t.status, t[this.bp].responseHeaders = this.$p(t.getAllResponseHeaders()), !super.isValidBodyType(t[this.bp].responseHeaders) || "" !== t.responseType && "text" !== t.responseType || (t[this.bp].responseBody = t.responseText), this.Fn(t[this.bp]))
        }
        interceptSetRequestHeader(t, s) {
            if (!t[this.bp]) return;
            let e = s[0],
                i = csString.prototype.valueOf.call(new csString(s[1]));
            "string" == typeof e && 0 !== i.length && (e = csString.prototype.toLowerCase.call(csString.prototype.trim.call(e)), i = csString.prototype.trim.call(i), t[this.bp].requestHeaders[e] ? t[this.bp].requestHeaders[e] += `, ${i}` : t[this.bp].requestHeaders[e] = i)
        }
        interceptSend(t, s) {
            t[this.bp] && super.isValidBodyType(t[this.bp].requestHeaders) && "string" == typeof s[0] && (t[this.bp].requestBody = s[0])
        }
        $p(t) {
            const s = {};
            return csArray.prototype.forEach.call(csString.prototype.split.call(t, /[\r\n]+/), (t => {
                const [e, i] = csString.prototype.split.call(t, /:\s*/);
                i && (s[csString.prototype.toLowerCase.call(e)] = csString.prototype.trim.call(i))
            })), s
        }
    }
    As([os("XhrRequestTracker.interceptOpen")], Sa.prototype, "interceptOpen", null), As([os("XhrRequestTracker.readyStateChangeListener")], Sa.prototype, "readyStateChangeListener", null), As([os("XhrRequestTracker.interceptSetRequestHeader")], Sa.prototype, "interceptSetRequestHeader", null), As([os("XhrRequestTracker.interceptSend")], Sa.prototype, "interceptSend", null);
    class Ra extends _a {
        constructor() {
            super(), this.se = !1, this.Lp = null, this.Mp = ({
                result: t,
                args: s,
                callerName: e
            }) => {
                this.interceptFetch(t, s, e)
            }
        }
        onEvent(t) {
            this.Fn = t
        }
        start() {
            this.se || this.Dp() && (this.qp(), this.Lp && this.Lp.activate(), this.se = !0)
        }
        stop() {
            this.se && (this.Lp && this.Lp.deactivate(), this.se = !1)
        }
        Dp() {
            return !!window.fetch && "function" == typeof window.fetch
        }
        Fp(t) {
            if (t[0] && "function" == typeof t[0].clone) {
                const s = xs(t);
                return s[0] = t[0].clone(), s
            }
            return t
        }
        qp() {
            this.Lp || (this.Lp = ie({
                target: window,
                methodName: "fetch",
                hook: this.Mp,
                hookPrepareArgs: this.Fp,
                options: {
                    withCallerName: !0
                }
            }))
        }
        async interceptFetch(t, s, e) {
            const i = s[0],
                n = s[1],
                r = new Request(i, n);
            if (!yt(r.url)) return;
            const o = Vt.now();
            let h;
            try {
                h = await t
            } catch (t) {
                if (this.Hp(t) || this.Bp(t) || this.jp(t)) return;
                throw t
            }
            const [c, a] = csString.prototype.split.call(r.url, "?"), u = zt(c);
            if (super.canCollect(h.status, u)) {
                const t = {
                    library: e,
                    method: r.method,
                    url: u,
                    queryParameters: a,
                    requestTime: o,
                    responseTime: Vt.now(),
                    statusCode: h.status,
                    requestBody: "",
                    responseBody: "",
                    requestHeaders: this.zp(r.headers),
                    responseHeaders: this.zp(h.headers)
                };
                !h.bodyUsed && super.isValidBodyType(t.responseHeaders) && (t.responseBody = await h.clone().text()), super.isValidBodyType(t.requestHeaders) && (t.requestBody = await r.text()), this.Fn(t)
            }
        }
        Hp(t) {
            return t instanceof TypeError
        }
        Bp(t) {
            return t instanceof DOMException && "AbortError" === t.name
        }
        jp(t) {
            return t instanceof DOMException && csArray.prototype.some.call(Ra.Gp, (s => s === t.name))
        }
        zp(t) {
            const s = {};
            return t.forEach(((t, e) => {
                t && (s[csString.prototype.toLowerCase.call(e)] = csString.prototype.trim.call(t))
            })), s
        }
    }
    Ra.Gp = ["NoModificationAllowedError", "InvalidStateError", "OperationError"], As([os("FetchRequestTracker.interceptFetch")], Ra.prototype, "interceptFetch", null);
    class Ta {
        constructor() {
            this.Zp = 64e3, this.Wp = 5e3, this.Qp = 2e3, this.Jp = 8e3, this.ph = !!self.TextEncoder, this.ph && (this.Kp = new TextEncoder)
        }
        Yp(t) {
            return this.Kp.encode(t).byteLength
        }
        Xp(t, s, e) {
            let i = 0;
            t[s] && (i += this.Yp(t[s]), i > this.Jp && (i = 0, t[s] = An.ELLIPSIS)), t[e] && (i += this.Yp(csJSON.stringify(t[e])), i > this.Jp && (t[e] = Ta.truncatedObjectMarker))
        }
        tm(t) {
            t.queryParameters && this.Yp(t.queryParameters) > this.Qp && (t.queryParameters = An.ELLIPSIS)
        }
        sm(t) {
            t.requestBody && this.Yp(t.requestBody) > this.Zp && (t.requestBody = An.ELLIPSIS), t.responseBody && this.Yp(t.responseBody) > this.Wp && (t.responseBody = An.ELLIPSIS)
        }
        truncate(t) {
            this.ph ? (this.tm(t), this.sm(t), this.Xp(t, "customResponseHeaders", "plainCustomResponseHeaders"), this.Xp(t, "customRequestHeaders", "plainCustomRequestHeaders")) : (t.queryParameters = "", t.requestBody = "", t.responseBody = "", t.customResponseHeaders = "", t.customRequestHeaders = "", t.plainCustomResponseHeaders = {}, t.plainCustomRequestHeaders = {})
        }
    }
    var Ia, ba;
    Ta.truncatedObjectMarker = {
            [An.ELLIPSIS]: An.ELLIPSIS
        },
        function(t) {
            t.isValidJSONPath = function(t) {
                if (!t) return !0;
                if (! function(t) {
                        const s = [];
                        for (let e = 0; e < t.length; ++e)
                            if ("[" === t[e]) csArray.prototype.push.call(s, t[e]);
                            else if ("]" === t[e]) {
                            if (!(csString.prototype.indexOf.call(t, "[") > -1)) return !1;
                            csArray.prototype.pop.call(s)
                        }
                        return 0 === s.length
                    }(t)) return !1;
                const s = csString.prototype.split.call(t, /[\[\]]/);
                return csArray.prototype.every.call(s, (t => {
                    const s = t[0],
                        e = t[t.length - 1];
                    if (("'" === s || '"' === s) && s !== e) return !1;
                    const i = csString.prototype.split.call(t, ".");
                    return 0 === i[0].length && csArray.prototype.shift.call(i), csArray.prototype.every.call(i, (t => {
                        const s = /^\-?\d+$/.exec(t);
                        return s ? parseInt(s[0], 10) >= 0 : "$" === t || /\w+/.test(t)
                    }))
                }))
            }, t.getJSONPathValue = function(t, s) {
                if (!t) return;
                const e = csString.prototype.split.call(t, /[\$\[\]]/),
                    i = [];
                csArray.prototype.forEach.call(e, (t => {
                    "'" !== t[0] && '"' !== t[0] ? csArray.prototype.push.call(i, ...csArray.prototype.filter.call(csString.prototype.split.call(t, "."), (t => t.length > 0))) : csArray.prototype.push.call(i, csString.prototype.substring.call(t, 1, t.length - 1))
                })), "$" === i[0] && csArray.prototype.shift.call(i);
                let n = s;
                for (const t of i) {
                    if (void 0 === n[t]) return;
                    n = n[t]
                }
                return n
            }
        }(Ia || (Ia = {}));
    class Pa {
        constructor() {
            this.im = new Set(["age", "cache-control", "clear-site-data", "expires", "pragma", "warning", "downlink", "ect", "rtt", "last-modified", "connection", "keep-alive", "accept", "accept-encoding", "accept-language", "expect", "access-control-allow-origin", "access-control-allow-credentials", "access-control-allow-headers", "access-control-allow-methods", "access-control-expose-headers", "access-control-max-age", "access-control-request-headers", "access-control-request-method", "origin", "timing-allow-origin", "content-length", "content-type", "content-encoding", "content-language", "via", "host", "referrer-policy", "user-agent", "allow", "server", "accept-ranges", "range", "if-range", "content-range", "cross-origin-embedder-policy", "cross-origin-opener-policy", "cross-origin-resource-policy", "content-security-policy", "content-security-policy-report-only", "expect-ct", "feature-policy", "strict-transport-security", "upgrade-insecure-requests", "x-content-type-options", "x-download-options", "x-frame-options", "x-permitted-cross-domain-policies", "x-powered-by", "x-xss-protection", "sec-fetch-site", "sec-fetch-mode", "sec-fetch-user", "sec-fetch-dest"])
        }
        isValidStandardHeader(t) {
            return this.im.has(t)
        }
    }
    class Va {
        constructor() {
            this.nm = 64e3, this.rm = 100, this.om = {
                collectQueryParam: !1,
                collectRequestBody: !1,
                collectResponseBody: !1,
                matchingBodyContents: [],
                plainResponseBodyAttributes: {},
                plainRequestBodyAttributes: {},
                requestBodyAttributes: {},
                responseBodyAttributes: {},
                standardRequestHeaders: {},
                standardResponseHeaders: {},
                customRequestHeaders: {},
                customResponseHeaders: {},
                plainCustomRequestHeaders: {},
                plainCustomResponseHeaders: {}
            }, this.hm = new Pa
        }
        am(t) {
            return t.length <= this.nm
        }
        um(t) {
            const s = t["content-type"];
            return void 0 !== s && (Nt(s, "application/json") || Nt(s, "application/graphql"))
        }
        lm(t, s) {
            return t && this.am(t) && this.um(s)
        }
        dm(t, s, e, i) {
            let n = "request" === i ? this.fm : this.pm;
            if (void 0 !== n || this.lm(s, e)) {
                if (void 0 === n) try {
                    n = csJSON.parse(s), "request" === i ? this.fm = n : this.pm = n
                } catch {
                    return
                }
                const e = Ia.getJSONPathValue(t, n);
                if (void 0 !== e && (null === e || !wt(e))) {
                    const t = yt(e) ? e : csJSON.stringify(e);
                    return An.truncate(t, this.rm, An.ELLIPSIS)
                }
            }
        }
        isBodyAttributeValueFound(t, s) {
            let e, i;
            return "request-response" !== s.type && "response" !== s.type || (e = this.dm(s.path, t.responseBody, t.responseHeaders, "response")), "request-response" !== s.type && "request" !== s.type || (i = this.dm(s.path, t.requestBody, t.requestHeaders, "request")), Et(e) || Et(i)
        }
        collectBodyAttribute(t, s, e) {
            let i;
            "request-response" !== s.type && "response" !== s.type || (i = this.dm(s.path, t.responseBody, t.responseHeaders, "response"), i && (s.encrypted ? this.om.responseBodyAttributes[s.path] = i : (i = e(i), this.om.plainResponseBodyAttributes[s.path] = i))), "request-response" !== s.type && "request" !== s.type || (i = this.dm(s.path, t.requestBody, t.requestHeaders, "request"), i && (s.encrypted ? i && (this.om.requestBodyAttributes[s.path] = i) : (i = e(i), this.om.plainRequestBodyAttributes[s.path] = i)))
        }
        isBodyContentMatching(t, s) {
            if (!t.responseBody) return !1;
            return !!new csRegExp(s, "i").test(t.responseBody)
        }
        collectBodyContent(t) {
            -1 === csArray.prototype.indexOf.call(this.om.matchingBodyContents, t) && csArray.prototype.push.call(this.om.matchingBodyContents, t)
        }
        collectCustomHeaders(t, s, e) {
            const i = csString.prototype.toLocaleLowerCase.call(s.headerName);
            !t.responseHeaders[i] || "request-response" !== s.type && "response" !== s.type || (s.encrypted ? this.om.customResponseHeaders[i] = t.responseHeaders[i] : this.om.plainCustomResponseHeaders[i] = e(t.responseHeaders[i])), !t.requestHeaders[i] || "request-response" !== s.type && "request" !== s.type || (s.encrypted ? this.om.customRequestHeaders[i] = t.requestHeaders[i] : this.om.plainCustomRequestHeaders[i] = e(t.requestHeaders[i]))
        }
        collectStandardHeaders(t) {
            if (!(Object.keys(this.om.standardRequestHeaders).length > 0 || Object.keys(this.om.standardResponseHeaders).length > 0)) {
                for (const [s, e] of Object.entries(t.requestHeaders)) this.hm.isValidStandardHeader(s) && (this.om.standardRequestHeaders[s] = e);
                for (const [s, e] of Object.entries(t.responseHeaders)) this.hm.isValidStandardHeader(s) && (this.om.standardResponseHeaders[s] = e)
            }
        }
        setCollectQueryParam(t) {
            t && (this.om.collectQueryParam = !0)
        }
        setCollectResponseBody(t) {
            t && (this.om.collectResponseBody = !0)
        }
        setCollectRequestBody(t) {
            t && (this.om.collectRequestBody = !0)
        }
        getCollectedDataPoints() {
            return this.om
        }
    }! function(t) {
        t.CONTENTSQUARE = "contentsquare.net", t.CLICKTALE = "clicktale.net", t.FAKE_TRACKER = "fake-tracker.content-square.fr"
    }(ba || (ba = {}));
    class Ca {
        computeApiErrorCollectionOptions() {
            const t = new Set,
                s = [];
            if (this.rules)
                for (const e of this.rules) void 0 !== e.statusCode && t.add(e.statusCode), void 0 !== e.url && -1 === csArray.prototype.indexOf.call(s, e.url) && csArray.prototype.push.call(s, e.url);
            const e = [ba.CONTENTSQUARE, ba.CLICKTALE];
            return csArray.prototype.push.call(e, ba.FAKE_TRACKER), {
                statusCodes: t,
                urls: s,
                excludedDomains: e
            }
        }
    }
    class ka extends Ca {
        constructor(t, s) {
            super(), this.vm = t, this.U = s, this.rules = t.collectionRules
        }
        collectDataPoints(t, s) {
            this.om = new Va;
            let e = !1;
            if (this.vm.collectionRules)
                for (const i of this.vm.collectionRules) this.gm(i, t) && this.ym(i, t) && this.wm(i, t) && (e = !0, this.Em(t, i, s));
            return e || (e = this.Am(t)), e && s && this.vm.collectStandardHeaders && this.om.collectStandardHeaders(t), e ? this.om.getCollectedDataPoints() : null
        }
        computeApiErrorCollectionOptions() {
            const t = this.vm.collectionRules || [],
                s = new Set,
                e = [];
            for (const i of t) void 0 !== i.statusCode && s.add(i.statusCode), void 0 !== i.url && -1 === csArray.prototype.indexOf.call(e, i.url) && csArray.prototype.push.call(e, i.url);
            const i = [ba.CONTENTSQUARE, ba.CLICKTALE];
            return csArray.prototype.push.call(i, ba.FAKE_TRACKER), {
                statusCodes: s,
                urls: e,
                excludedDomains: i
            }
        }
        gm(t, s) {
            return (!t.statusCode && s.statusCode >= 400 || void 0 !== t.statusCode && t.statusCode === s.statusCode) && (!t.url || -1 !== csString.prototype.indexOf.call(s.url, t.url))
        }
        ym(t, s) {
            return !t.bodyContent || this.om.isBodyContentMatching(s, t.bodyContent)
        }
        wm(t, s) {
            const e = csArray.prototype.find.call(t.bodyAttributePaths, (t => t.primary));
            return void 0 === e || this.om.isBodyAttributeValueFound(s, e)
        }
        Am(t) {
            return t.statusCode >= 400
        }
        Em(t, s, e) {
            s.bodyContent && this.om.collectBodyContent(s.bodyContent);
            const i = Ds(s.bodyAttributePaths, (t => 1 === t.primary));
            if (i && this.om.collectBodyAttribute(t, i, (t => this.U.anonymizePII(t))), e) {
                this.om.setCollectQueryParam(s.collectQueryParam), this.om.setCollectResponseBody(s.collectResponseBody), this.om.setCollectRequestBody(s.collectRequestBody);
                for (const e of s.customHeaders) this.om.collectCustomHeaders(t, e, (t => this.U.anonymizePII(t)));
                const e = qs(s.bodyAttributePaths, (t => !t.primary));
                for (const s of e) this.om.collectBodyAttribute(t, s, (t => this.U.anonymizePII(t)))
            }
        }
    }
    class Oa extends Ca {
        constructor(t, s) {
            super(), this.vm = t, this.U = s, this.rules = t.configurableApiErrorRules
        }
        collectDataPoints(t, s) {
            this.om = new Va;
            const e = this._m(t, this.vm.configurableApiErrorRules);
            return e.isMatching ? (e.matchingBodyContents.length > 0 && this.om.collectBodyContent(e.matchingBodyContents[0]), s && this.Sm(t), this.om.getCollectedDataPoints()) : null
        }
        computeApiErrorCollectionOptions() {
            const t = this.vm.configurableApiErrorRules || [],
                s = new Set,
                e = [];
            for (const i of t) void 0 !== i.statusCode && s.add(i.statusCode), void 0 !== i.url && -1 === csArray.prototype.indexOf.call(e, i.url) && csArray.prototype.push.call(e, i.url);
            const i = [ba.CONTENTSQUARE, ba.CLICKTALE];
            return csArray.prototype.push.call(i, ba.FAKE_TRACKER), {
                statusCodes: s,
                urls: e,
                excludedDomains: i
            }
        }
        _m(t, s) {
            if (t.statusCode >= 400) return {
                isMatching: !0,
                matchingBodyContents: []
            };
            if (s)
                for (const e of s)
                    if (this.Rm(t, e)) return {
                        isMatching: !0,
                        matchingBodyContents: e.bodyContent ? [e.bodyContent] : []
                    };
            return {
                isMatching: !1,
                matchingBodyContents: []
            }
        }
        Rm(t, s) {
            return !(t.statusCode !== s.statusCode || -1 === csString.prototype.indexOf.call(t.url, s.url) || s.bodyContent && !this.om.isBodyContentMatching(t, s.bodyContent))
        }
        Sm(t) {
            this.vm.collectStandardHeaders && this.om.collectStandardHeaders(t), this.vm.validCustomHeaders && this.Tm(t, this.vm.validCustomHeaders, Number(!0)), this.vm.plainCustomHeaders && this.Tm(t, this.vm.plainCustomHeaders, Number(!1)), this.Ip(t.url, this.vm.validUrls) && (this.vm.collectQueryParam && this.om.setCollectQueryParam(Number(this.vm.collectQueryParam)), this.vm.collectResponseBody && this.om.setCollectResponseBody(Number(this.vm.collectResponseBody)), this.vm.collectRequestBody && this.om.setCollectRequestBody(Number(this.vm.collectRequestBody)))
        }
        Tm(t, s, e) {
            for (const i of s) this.om.collectCustomHeaders(t, {
                headerName: i,
                encrypted: e,
                type: "request-response"
            }, (t => this.U.anonymizePII(t)))
        }
        Ip(t, s) {
            return !!s && csArray.prototype.some.call(s, (s => -1 !== csString.prototype.indexOf.call(t, s)))
        }
    }
    class Na extends gn {
        constructor(t) {
            super(), this.ih = null, this.Im = null, this.As = null, this.uh = null, this.bm = 0, this.Pm = ["value", "checked", "src", "data", "alt"], this.Vm = {
                state: $e.MaskedElementState.Child
            }, this.Cm = t => {
                for (const s of t) {
                    if ($e.isMaskedElement(s.target) || $e.isMaskedElementChild(s.target))
                        for (let t = 0; t < s.addedNodes.length; t += 1) {
                            const e = s.addedNodes[t];
                            $e.isMaskedElement(e) || $e.isMaskedElementChild(e) || l(e) && this.km(e)
                        }
                    for (let t = 0; t < s.removedNodes.length; t += 1) {
                        const e = s.removedNodes[t];
                        qi.isConnected(e) || this.Om(e)
                    }
                }
            }, this.Nm = t
        }
        setMaskedElementSettings(t) {
            this.Jd = t
        }
        start() {
            this.bm++, this.isStarted || (this.isStarted = !0, this.onStart())
        }
        stop() {
            this.isStarted && (this.bm--, 0 === this.bm && (this.isStarted = !1, this.onStop()))
        }
        onStart() {
            var t, s, e, i;
            this.Jd || (rs.error("maskedElementSettings not initialized", "MaskedElementIdentifier.start"), this.Jd = {
                elementSelector: "",
                attrSelector: "",
                attrSelectors: []
            });
            const {
                elementSelector: n,
                attrSelector: r,
                attrSelectors: o
            } = this.Jd;
            null !== (t = this.uh) && void 0 !== t || (this.uh = this.xm()), 0 !== n.length && (null !== (s = this.ih) && void 0 !== s || (this.ih = this.$m()), this.ih.observe(n)), 0 !== r.length && (null !== (e = this.Im) && void 0 !== e || (this.Im = this.Lm(o)), this.Im.observe(r)), null !== (i = this.As) && void 0 !== i || (this.As = new nn(this.Cm, ((t, s) => "added" === s && this.Mm(t)))), this.As.observe(), csSetTimeout(this.Nm)
        }
        onStop() {
            var t, s, e;
            this.ih && (this.Om(document), this.ih.disconnect()), null === (t = this.Im) || void 0 === t || t.disconnect(), null === (s = this.As) || void 0 === s || s.disconnect(), null === (e = this.uh) || void 0 === e || e.disconnect()
        }
        xm() {
            return window.ResizeObserver ? new ResizeObserver((t => {
                csArray.prototype.forEach.call(t, (t => {
                    this.resizeObserverCallback(t)
                }))
            })) : null
        }
        $m() {
            return new Wn((t => {
                csArray.prototype.forEach.call(t, (t => {
                    this.Dm(t) ? this.km(t) : (this.Um(t), this.qm(t))
                }))
            }))
        }
        Lm(t) {
            return new Wn((s => {
                csArray.prototype.forEach.call(s, (s => this.Fm(s, t)))
            }))
        }
        resizeObserverCallback(t) {
            const s = t.target.getBoundingClientRect(),
                e = $e.getMaskedElementDetails(t.target);
            if (e.state !== $e.MaskedElementState.Parent) return;
            if (s.width === e.width && s.height === e.height) return;
            const i = {
                state: $e.MaskedElementState.Parent,
                width: s.width,
                height: s.height
            };
            $e.setMaskedElementProperty(t.target, i), this.produceEvent({
                type: "ResizeMaskedElement",
                target: be(t.target),
                width: s.width,
                height: s.height
            })
        }
        qm(t) {
            this.uh && l(t) && !w(t) && this.uh.observe(t)
        }
        Dm(t) {
            const s = csNodeparentNode.apply(t);
            return s ? $e.isMaskedElement(s) || $e.isMaskedElementChild(s) : !!R(t) && ($e.isMaskedElement(t.host) || $e.isMaskedElementChild(t.host))
        }
        Mm(t) {
            ($e.isMaskedElement(t.host) || $e.isMaskedElementChild(t.host)) && $e.setMaskedElementProperty(t, this.Vm)
        }
        Om(t) {
            Qs(t, NodeFilter.SHOW_ELEMENT).visitAll((t => {
                $e.unsetMaskedElementProperty(t)
            }))
        }
        Um(t) {
            const s = t.getBoundingClientRect(),
                e = {
                    state: $e.MaskedElementState.Parent,
                    width: s.width,
                    height: s.height
                };
            $e.setMaskedElementProperty(t, e), this.Hm(t), Qs(t).visitAll((s => s != t && $e.setMaskedElementProperty(s, this.Vm)))
        }
        km(t) {
            $e.setMaskedElementProperty(t, this.Vm), Qs(t).visitAll((s => s != t && $e.setMaskedElementProperty(s, this.Vm)))
        }
        Hm(t) {
            var s;
            const e = null !== (s = Re.getProperty(t, $e.maskedAttributeProp)) && void 0 !== s ? s : {
                attributes: []
            };
            for (let t = 0; t < this.Pm.length; t += 1) {
                const s = this.Pm[t]; - 1 === csArray.prototype.indexOf.call(e.attributes, s) && csArray.prototype.push.call(e.attributes, s)
            }
            0 !== e.attributes.length && $e.setMaskedAttributeProperty(t, e)
        }
        Fm(t, s) {
            var e;
            const i = null !== (e = Re.getProperty(t, $e.maskedAttributeProp)) && void 0 !== e ? e : {
                attributes: []
            };
            for (let e = 0; e < t.attributes.length; e += 1) {
                const n = t.attributes[e].name; - 1 === csArray.prototype.indexOf.call(i.attributes, n) && csArray.prototype.some.call(s, (s => csString.prototype.indexOf.call(s.attrName, n) > -1 && Ce.call(t, s.selector))) && csArray.prototype.push.call(i.attributes, n)
            }
            0 !== i.attributes.length && $e.setMaskedAttributeProperty(t, i)
        }
    }
    ai([os()], Na.prototype, "resizeObserverCallback", null);
    class xa {
        constructor(t, s, e) {
            this.xa = t, this.Bm = s, this.jm = e
        }
        getSensitiveStatus() {
            return {
                started: this.jm.isStarted,
                useAnonymization: this.xa.shouldUseAnonymization(),
                capturedElementSelector: Qn.getWhitelistedElementsSelector(),
                maskedElementSettings: this.Bm.getMaskedElementSettings()
            }
        }
        getElementSensitiveStatus(t) {
            const s = this.jm.isStarted,
                e = this.xa.shouldUseAnonymization();
            return s ? $e.isMaskedElement(t) || $e.isMaskedElementChild(t) ? ic.MASKED : e ? Qn.isWhitelisted(t) ? ic.CAPTURED : ic.ANONYMIZED : ic.CAPTURED : ic.ANONYMIZED
        }
    }
    const $a = ["setPIISelectors"],
        La = ["setCapturedElementsSelector"];
    class Ma {
        constructor(t, s, e, i) {
            this.Uc = t, this.Ia = s, this.Bm = e, this.jm = i
        }
        init() {
            this.sp()
        }
        onStartTracking(t) {
            this.jm.start(), this.Uc.emitSensitiveStatusChange()
        }
        onBeforeArtificialPageView() {
            this.jm.stop(), this.Uc.emitSensitiveStatusChange()
        }
        onAfterArtificialPageView() {
            this.jm.start(), this.Uc.emitSensitiveStatusChange()
        }
        onBeforeSessionRenewal() {
            this.jm.stop(), this.Uc.emitSensitiveStatusChange()
        }
        onOptout() {
            this.jm.stop(), this.Uc.emitSensitiveStatusChange()
        }
        onReplayUnanonymizationConsentGranted() {
            this.Uc.emitSensitiveStatusChange()
        }
        onReplayUnanonymizationConsentWithdrawn() {
            this.Uc.emitSensitiveStatusChange()
        }
        sp() {
            this.Ia.register($a, (t => {
                this.Bm.setMaskedElementSettingsFromCommand(t), this.Uc.emitSensitiveStatusChange()
            })), this.Ia.register(La, (t => {
                Qn.setWhitelistedElementsSelector(t), this.Uc.emitSensitiveStatusChange()
            }))
        }
    }
    class Da extends Fe {
        constructor(t, s) {
            super(), this.ba = t, this.Bm = s
        }
        onStart() {
            Qn.start(), this.ba.setMaskedElementSettings(this.Bm.getMaskedElementSettings()), this.ba.start()
        }
        onStop() {
            Qn.stop(), this.ba.stop()
        }
    }
    const Ua = ["networkRequest:maskUrls"],
        qa = ["networkRequest:maskUrls:reset"];
    class Fa {
        constructor(t, s) {
            this.zm = t, this.Pa = s
        }
        init() {
            this.zm.register(Ua, (t => {
                if (yt(t)) this.Pa.addPartialUrlMaskingPattern(t);
                else if (csArray.isArray(t))
                    for (const s of t) yt(s) && this.Pa.addPartialUrlMaskingPattern(s)
            })), this.zm.register(qa, (() => this.Pa.resetPartialUrlMaskingPatterns()))
        }
    }
    class Ha {
        constructor(t, s, e, i, n, r, o, h, c, a, u, l, d, f, p, m, v, g, y, w, E, A, _, S, R, T, I, b) {
            this.ha = t, this.gu = s, this.K = e, this.Y = i, this.Uc = n, this.Ia = r, this.Gm = o, this.D = h, this.Zm = c, this.Wm = a, this.Qm = u, this.Ad = l, this.U = d, this._l = f, this.Na = p, this.ot = m, this.Jm = v, this.xd = g, this.ou = y, this.ps = w, this.Km = E, this.ka = A, this.Ym = _, this.cr = S, this.Oa = R, this.Xm = T, this.tv = I, this.sv = b, this.ev = (t = !1) => {
                this.iv.start(t), this.nv.start()
            }, this.rv = () => {
                this.Uc.emitBeforeSessionRenewal(), this.ov(!0), this.Uc.emitAfterSessionRenewal()
            }, this.hv = () => {
                this.sv.refreshQuota(), this.sv.onQuotaReady((t => {
                    t !== He.QUOTA_REACHED && (this.Uc.emitBeforeSessionRenewal(), this.ov(!0), this.Uc.emitAfterSessionRenewal())
                }))
            }
        }
        start() {
            if (this.Zm.init(), this.Wm.init(), this.Wm.isActive()) return;
            let t, s, e, i, n, r, o, h, c, a, u, l, d, f, p;
            this.cr.schedule((() => {
                u = new Nc(this.Y, this.K), p = new ga(u), a = new Rc(this._l), l = new Wc(this.D), d = new Na((() => {}));
                const m = new Da(d, l);
                f = new xa(this.cv(), l, m);
                const v = new Ma(this.Uc, this.Ia, l, m);
                v.init(), this.Uc.addListener(v), t = new cc(this.D, this.ha, this.K, this._l, a, this.Ia, u, new ea(ns), this.ou, this.Oa, this.xd, f), s = new xo(this.Ia, this.Y, this.D, this.ha, this.gu, this.U), c = new ra(f);
                const g = new Kc(this.D);
                h = new Jc(this.D, g, c, f, this.ou), h.init();
                const y = new va;
                e = new Vo(this.K, this.Y, this.Ia, this.ou, g, this.D, y, c), i = new Bo(this.D, this.ha, this.K, this.Ia, this.U, u, this.ot), this.iv = new Sc(this.D, this.Ia, this.Uc, this.ha, this.K, this.Y, this.Ad, this.ps, this.Na, this.ot, this.ka, y, this._d), this.av = new Oc(this.D, this.K, this.Y, this.Ia), n = new jc(this.D, this.Ia, this.gu, this.ha, this.xd), r = new Qc(this.Ia), o = new na(this.D, new $t(this.D, this.U), this.Oa), this.nv = new Tc
            })), this.D.apiErrors.enabled && this.cr.schedule((() => {
                this.Pa = new vc, this.uv = new Fa(this.Ia, this.Pa), this.uv.init()
            })), this.D.apiErrors.enabled && this.cr.schedule((() => {
                var t;
                let s;
                s = (null === (t = this.D.apiErrors.collectionRules) || void 0 === t ? void 0 : t.length) ? new ka(this.D.apiErrors, this.U) : new Oa(this.D.apiErrors, this.U), this.xi = new Xc(new Sa, new Ra, s), this.$i = new ta(this.Pa, this.Na), this.zi = new Ta;
                const e = new aa(this.xi, this.$i, this.D, this.ha, this.ou, this.Ia, this.Oa);
                e.init(), this.Uc.addListener(e)
            })), this.D.customErrors.enabled && this.cr.schedule((() => {
                const t = new ma(this.U, this.D, this.ha, this.Ia, this.xd, this.Oa, this.ou, undefined);
                t.init(), this.Uc.addListener(t)
            })), this.D.jsErrorsEnabled && this.cr.schedule((() => {
                this.ep = new Gc, this.Ni = new sa(this.U, this.ot);
                const t = new da(this.ep, this.Ni, this.D, this.ha, this.ou, this.Ia, this.xd, this.ot, this.Oa);
                t.init(), this.Uc.addListener(t)
            })), this.cr.schedule((() => {
                this.Qm.init()
            })), this.cr.schedule((() => {
                e.init()
            })), this.cr.schedule((() => {
                s.init()
            })), this.cr.schedule((() => {
                i.init()
            })), this.cr.schedule((() => {
                this.Km.init()
            })), this.cr.schedule((() => {
                this.iv.init()
            })), this.cr.schedule((() => {
                this.av.init()
            })), this.cr.schedule((() => {
                n.init()
            })), this.cr.schedule((() => {
                this.Jm.init()
            })), this.cr.schedule((() => {
                r.init()
            })), this.cr.schedule((() => {
                o.init()
            })), this.cr.schedule((() => {
                this.Ym.init()
            })), this.cr.schedule((() => {
                this.Uc.addListener(this.av), this.Uc.addListener(this.Gm), this.Uc.addListener(t), this.Uc.addListener(this.Qm), this.Uc.addListener(e), this.Uc.addListener(i), this.Uc.addListener(this.Km), this.Uc.addListener(this.iv), this.Uc.addListener(n), this.Uc.addListener(s), this.Uc.addListener(h), this.Uc.addListener(o), this.Uc.addListener(p)
            })), oa.isRecordingSupported() && this.cr.schedule((() => {
                const t = new vo(c, this.Y, this.D, this.ha, this.Ia, this.U, u, d, this.Ni, this.xi, this.$i, this.Pa, this.Uc, this.xd, this.ou, this.ka, this.Oa, this.Na, this.zi, this.cv());
                t.init(), this.Uc.addListener(t), e.setRecordingService(t.recordingService)
            })), this.cr.schedule((() => {
                t.init()
            })), this.cr.schedule((() => {
                this.D.isQuotaEnabled() ? u.onSessionExpired((() => {
                    this.hv()
                })) : u.onSessionExpired((() => {
                    this.rv()
                })), this.ov()
            }))
        }
        ov(t = !1) {
            this.Ia.start(), this.nv.onLoad((() => {
                this.Uc.emitStartTracking(t)
            })), Lc(this.D) && !t || this.ev(t)
        }
        cv() {
            if (this.xa) return this.xa;
            const t = new Aa;
            return this.xa = new Ea(this.Ad, this.D, this.ot, t), this.xa.init(), this.xa
        }
    }
    class Ba {
        constructor(t, s, e, i, n, r, o, h) {
            this.D = t, this.K = s, this.fs = e, this.lv = i, this.fv = n, this.pv = r, this.mv = o, this.vv = h
        }
        compute(t) {
            var s, e;
            this.D.crossDomainTracking && !this.D.cookielessTrackingEnabled ? this.D.crossDomainSingleIframeTracking ? null === (s = this.mv) || void 0 === s || s.start((() => this.gv(t))) : null === (e = this.pv) || void 0 === e || e.applyUpToDate((() => this.gv(t))) : this.gv(t)
        }
        gv(t) {
            this.fv.handle(), this.lv.clear(), this.yv() ? (this.lv.restoreClearedVisitor(), t(!0)) : (this.fs.exclude(this.D), t(!1))
        }
        yv() {
            const t = G.boolean(this.D.sampleRate);
            return this.vv.isForceIncluded() || !this.fs.isExcluded() && this.K.doesVisitorExist() || !this.fs.isExcluded() && t
        }
    }
    var ja;
    ! function(t) {
        t.generate = function() {
            const t = navigator.userAgent + navigator.language + navigator.platform,
                s = csString.prototype.slice.call(function(t) {
                    let s = 0;
                    for (let e = 0; e < t.length; e += 1) s = csString.prototype.charCodeAt.call(t, e) + (s << 6) + (s << 16) - s;
                    return Math.abs(s)
                }(t).toString(16), -4);
            let e = (new csDate).getTime();
            const i = "xxxxxxxx-hhhh-axxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (t => {
                const s = (e + 16 * Math.random()) % 16 | 0;
                return e = Math.floor(e / 16), ("x" === t ? s : 7 & s | 8).toString(16)
            }));
            return csString.prototype.replace.call(i, "hhhh", s)
        }
    }(ja || (ja = {}));
    class za {
        constructor(t, s, e, i) {
            this.D = t, this.wv = s, this.Y = e, this.Uc = i, this.Ev = 1e4
        }
        createOrUpdateVisitor() {
            let t = this.getVisitor();
            null === t && (t = this.Av(), this.Y.removeSession()), this._v(t), this.setVisitor(t)
        }
        Av() {
            return {
                id: ja.generate(),
                visitsCount: 0,
                appliedTrackingDraw: this.D.lastTrackingDraw,
                creationTimestamp: Ct(),
                lastVisitTimestamp: 0,
                hitTimestamp: 0,
                expires: Vt.now() + this.D.visitorCookieTimeout,
                allowSubdomains: this.D.allowSubdomains
            }
        }
        _v(t) {
            const s = Ct();
            this.Y.doesSessionExist() || (t.visitsCount += 1, t.lastVisitTimestamp = s), t.hitTimestamp = s, t.appliedTrackingDraw = this.D.lastTrackingDraw, this.Sv = t.visitsCount
        }
        getRequestParameters() {
            const t = this.getVisitor();
            return t ? {
                uu: t.id,
                sn: `${t.visitsCount}`,
                hd: `${t.hitTimestamp}`
            } : {}
        }
        getVisitor() {
            return this.wv.get()
        }
        setVisitor(t) {
            this.wv.set(t)
        }
        doesVisitorExist() {
            return null !== this.wv.get()
        }
        resetVisitor() {
            this.Rv(), this.Uc.emitAfterVisitorCleared()
        }
        removeVisitor() {
            this.wv.remove()
        }
        hasAllowSubdomainsChanged() {
            const t = this.getVisitor();
            if (!t) return !1;
            return t.allowSubdomains !== this.D.allowSubdomains
        }
        handleSubdomainChange() {
            this.wv.handleSubdomainChange()
        }
        isSessionRenewed() {
            const t = this.getVisitor();
            return null !== t && void 0 !== this.Sv && t.visitsCount !== this.Sv
        }
        Tv() {
            return !Et(this.Iv) || Vt.now() - this.Iv > this.Ev
        }
        renewVisitor() {
            this.Tv() ? (this.Iv = Vt.now(), this.Rv(), this.Uc.emitAfterVisitorRenewal()) : ns.warn("session:start:newVisitor is trying to renew visitor under time limit")
        }
        Rv() {
            this.Uc.emitBeforeVisitorRenewal(), this.removeVisitor()
        }
    }
    const Ga = "_cs_s",
        Za = 18e5,
        Wa = /^(\d+\.[0135678TBWX](\.[01])?(\.[39])?)(\.\d+)?$/,
        Qa = ".";
    var Ja;
    ! function(t) {
        t[t.NOT_FOUND = 0] = "NOT_FOUND", t[t.EXPIRED = 1] = "EXPIRED", t[t.FOUND = 2] = "FOUND"
    }(Ja || (Ja = {}));
    class Ka {
        constructor(t, s, e) {
            this.D = t, this.Xm = s, this.bv = e, this.Zr = null, this.Pv = !1
        }
        get(t) {
            const s = this.getRawSession(t);
            return this.isValid(s) ? Ka.fromString(s) : null
        }
        getRawSession(t) {
            if (t) {
                const t = this.Vv();
                return Ka.Cv(t)
            }
            const {
                sessionString: s,
                status: e
            } = this.kv(), i = Ka.Cv(s);
            if (e !== Ja.EXPIRED) return i;
            if (this.D.cookielessTrackingEnabled) return null;
            const n = this.Vv();
            if (!n) return null;
            const r = csString.prototype.split.call(n, Qa);
            if (!Ka.Ov(r)) return n;
            const o = r[r.length - 1],
                h = parseInt(o, 10);
            return isNaN(h) || this.Nv(h), i
        }
        onCookieToSet(t) {
            this.xv = t
        }
        onCookieToRemove(t) {
            this.$v = t
        }
        set(t, s = 18e5) {
            var e;
            const i = Vt.now() + s;
            let n = this.toString(t);
            n += `${Qa}${i}`, this.Lv(n, i), this.D.cookielessTrackingEnabled ? this.bv.setItem(Ga, n) : (this.Xm.set(Ga, n, s), null === (e = this.xv) || void 0 === e || e.call(this, Ga, n, s))
        }
        remove() {
            var t;
            this.D.cookielessTrackingEnabled ? this.bv.removeItem(Ga) : (this.Xm.delete(Ga), null === (t = this.$v) || void 0 === t || t.call(this, Ga)), this.Mv()
        }
        handleSubdomainChange() {
            if (this.D.cookielessTrackingEnabled) return;
            const t = this.get(!0);
            t && (this.D.allowSubdomains ? this.Xm.delete(Ga, Is.CURRENT_DOMAIN) : this.Xm.delete(Ga, this.Xm.getRootDomain()), this.set(t))
        }
        isValid(t) {
            return null !== t && Ka.isValidSessionString(t)
        }
        toString(t) {
            return csArray.prototype.join.call([t.pageNumber, t.collectState, t.etrState, t.etrStatus], Qa)
        }
        Lv(t, s) {
            this.Zr = {
                sessionString: t,
                expires: s
            }
        }
        kv() {
            return this.Zr ? this.Zr && Vt.now() <= this.Zr.expires ? {
                sessionString: this.Zr.sessionString,
                status: Ja.FOUND
            } : {
                sessionString: this.Zr.sessionString,
                status: Ja.EXPIRED
            } : {
                sessionString: this.Vv(),
                status: Ja.NOT_FOUND
            }
        }
        Mv() {
            this.Zr = null
        }
        Nv(t) {
            this.Zr && (this.Zr.expires = t, this.Pv = !0)
        }
        isCacheRefreshed() {
            return this.Pv
        }
        resetCacheRefreshed() {
            this.Pv = !1
        }
        Vv() {
            if (this.D.cookielessTrackingEnabled) {
                const t = this.bv.getItem(Ga);
                return !t || this.Dv(t) ? null : t
            }
            const t = this.Xm.get(Ga);
            return !t || this.Dv(t) ? null : t
        }
        Dv(t) {
            const s = csString.prototype.split.call(t, Qa);
            if (!Ka.Ov(s)) return !1;
            const e = parseInt(s[s.length - 1], 10);
            return !isNaN(e) && Vt.now() > e
        }
        static Ov(t) {
            return 13 === t[t.length - 1].length
        }
        static Cv(t) {
            var s;
            if (!t) return null;
            const e = null === (s = csString.prototype.match.call(t, Wa)) || void 0 === s ? void 0 : s[1];
            return null != e ? e : null
        }
        static fromRawString(t) {
            const s = Ka.Cv(t);
            return null !== s ? Ka.fromString(s) : null
        }
        static fromString(t) {
            var s, e;
            const [i, n, r, o] = csString.prototype.split.call(t, Qa);
            return {
                collectState: n,
                etrState: null !== (s = r) && void 0 !== s ? s : Be.ETR_OFF,
                etrStatus: null !== (e = o) && void 0 !== e ? e : ze.ETR_NOT_SAVED_SESSION,
                pageNumber: parseInt(i, 10)
            }
        }
        static isValidSessionString(t) {
            return Wa.test(t)
        }
    }
    var Ya;
    ! function(t) {
        t[t.NO = 0] = "NO", t[t.WITHDRAWN = 1] = "WITHDRAWN", t[t.GRANTED = 2] = "GRANTED"
    }(Ya || (Ya = {}));
    class Xa {
        constructor(t, s) {
            this.Uv = t, this.sv = s, this.qv = null, this.Fv = 0, this.Hv = Ya.NO
        }
        setDynamicVariablesService(t) {
            this.Bv = t
        }
        createOrUpdateSession() {
            this.jv(), this.zv = Vt.now(), this.Fv = 0;
            let t = this.Gv();
            null === t ? (t = this.Zv(), this.Wv(t), this.Qv(t)) : (t = this.sv.sanitizeSessionCollectState(t), this.Wv(t), t.collectState = this.sv.getEligibleCollectState(t)), this.setSession(t)
        }
        grantReplayRecording(t) {
            t.collectState = this.sv.getInitialCollectState(), t.collectState = this.sv.computeInitialCollectStateFromRecordingConsentGranted(t), this.setSession(t)
        }
        grantReplayRecordingBeforeSessionStart() {
            this.Hv = Ya.GRANTED
        }
        withdrawnReplayRecording(t) {
            t.collectState = this.sv.getRecordingConsentWithdrawn(), this.setSession(t)
        }
        withdrawnReplayRecordingBeforeSessionStart() {
            this.Hv = Ya.WITHDRAWN
        }
        Qv(t) {
            this.Hv === Ya.WITHDRAWN ? (t.collectState = this.sv.getRecordingConsentWithdrawn(), this.setSession(t)) : this.Hv === Ya.GRANTED ? t.collectState = this.sv.computeInitialCollectStateFromRecordingConsentGranted(t) : t.collectState = this.sv.computeInitialCollectState(t), this.Hv = Ya.NO
        }
        Zv() {
            return {
                pageNumber: 0,
                collectState: this.sv.getInitialCollectState(),
                etrState: Be.ETR_OFF,
                etrStatus: ze.ETR_NOT_SAVED_SESSION
            }
        }
        Wv(t) {
            t.pageNumber += 1
        }
        isReplayRecorded() {
            const t = this.getSession();
            return !!t && this.sv.isReplayRecorded(t)
        }
        isTemporarilyRecorded() {
            const t = this.getSession();
            return (null == t ? void 0 : t.collectState) === He.RECORDING_TEMPORARILY
        }
        abortQuotaServiceRequest() {
            this.sv.abortQuotaServiceRequest()
        }
        getRequestParameters() {
            const t = {},
                s = this.getSession();
            return null !== s && (t.pn = `${s.pageNumber}`), t
        }
        getSession() {
            return this.Uv.get()
        }
        Gv() {
            return this.Uv.get(!0)
        }
        doesSessionExist() {
            return null !== this.Uv.get()
        }
        setSession(t) {
            this.Uv.set(t)
        }
        refreshSession() {
            const t = this.Gv();
            t && this.setSession(t)
        }
        removeSession() {
            this.Uv.remove()
        }
        getCollectStates() {
            const t = this.getSession(),
                s = [];
            return t && (t.collectState !== He.ANALYTICS_ONLY && csArray.prototype.push.call(s, t.collectState), t.etrState === Be.ETR_ON && csArray.prototype.push.call(s, He.RECORDING_ETR_SAMPLING)), s
        }
        updateCollectState(t, s) {
            const e = this.getSession();
            null !== e && (e.collectState = t, e.etrState = s, this.setSession(e))
        }
        getEtrState() {
            var t;
            const s = this.getSession();
            return null !== (t = null == s ? void 0 : s.etrState) && void 0 !== t ? t : Be.ETR_OFF
        }
        hasValidSession() {
            const t = this.Uv.getRawSession();
            return this.Uv.isValid(t)
        }
        handleSubdomainChange() {
            this.Uv.handleSubdomainChange()
        }
        pollCacheRefreshEvent(t = !0) {
            const s = this.Uv.isCacheRefreshed();
            return s && t && this.Uv.resetCacheRefreshed(), s
        }
        extendSessionPeriodically() {
            this.qv || this.Jv()
        }
        extendSession() {
            const t = this.getSession();
            return null === t ? (ns.warn("extendSession is trying to extend an expired session"), this.jv(), !1) : (this.Uv.set(t, Za), !0)
        }
        Jv() {
            if (this.Kv()) return void this.jv();
            this.extendSession() && (this.Yv(), this.Xv())
        }
        Xv() {
            this.qv = window.csSetTimeout((() => {
                this.Jv()
            }), 174e4)
        }
        Kv() {
            return 1434e4 - (Vt.now() + Za - this.zv) < 0
        }
        jv() {
            this.qv && (window.csClearTimeout(this.qv), this.qv = null)
        }
        Yv() {
            this.Fv += 1, this.Bv.trackDynamicVariable("session_expiry_update", this.Fv)
        }
    }
    class tu {
        constructor(t, s, e) {
            this.D = t, this.K = s, this.fs = e
        }
        clear() {
            this.tg() && (this.sg = this.K.getVisitor(), this.K.removeVisitor()), this.eg() && this.fs.removeExclusion()
        }
        tg() {
            return this.K.doesVisitorExist() && this.K.getVisitor().appliedTrackingDraw !== this.D.lastTrackingDraw
        }
        eg() {
            return this.fs.getAppliedTrackingDraw() !== this.D.lastTrackingDraw
        }
        restoreClearedVisitor() {
            this.sg && this.K.setVisitor(this.sg)
        }
    }
    class su {
        constructor(t, s, e) {
            this.K = t, this.Y = s, this.ig = e
        }
        handle() {
            this.K.hasAllowSubdomainsChanged() && (this.K.handleSubdomainChange(), this.Y.handleSubdomainChange(), this.ig.handleSubdomainChange())
        }
    }
    const eu = "_cs_c";
    var iu;
    ! function(t) {
        t[t.NOT_REQUIRED = 0] = "NOT_REQUIRED", t[t.NOT_EXPRESSED = 1] = "NOT_EXPRESSED", t[t.GRANTED = 2] = "GRANTED", t[t.WITHDRAWN = 3] = "WITHDRAWN"
    }(iu || (iu = {}));
    class nu {
        constructor(t, s, e) {
            this.D = t, this.Xm = s, this.tv = e
        }
        get() {
            let t;
            return t = this.D.cookielessTrackingEnabled ? this.tv.getItem(eu) : this.Xm.get(eu), null === t ? t : Number(t)
        }
        set(t) {
            this.D.cookielessTrackingEnabled ? this.tv.setItem(eu, csString(t)) : this.Xm.set(eu, csString(t), z)
        }
        remove() {
            this.D.cookielessTrackingEnabled ? this.tv.removeItem(eu) : this.Xm.delete(eu)
        }
        handleSubdomainChange() {
            this.D.cookielessTrackingEnabled || (this.D.allowSubdomains ? this.Xm.delete(eu, Is.CURRENT_DOMAIN) : this.Xm.delete(eu, this.Xm.getRootDomain()))
        }
    }
    class ru {
        constructor(t, s, e) {
            this.D = t, this.Y = s, this.Uc = e
        }
        grantReplayConsent() {
            if (!yo.isReplayConsentNeeded(this.D)) return;
            const t = this.Y.getSession();
            t ? yo.isRecordingBlockedByConsent(t) && (this.Y.grantReplayRecording(t), this.Uc.emitAfterReplayRecordingConsentGranted()) : this.Y.grantReplayRecordingBeforeSessionStart()
        }
        withdrawReplayConsent() {
            if (!yo.isReplayConsentNeeded(this.D)) return;
            const t = this.Y.getSession();
            t ? yo.isRecordingWithDrawn(t) || (this.Y.withdrawnReplayRecording(t), this.Uc.emitAfterReplayRecordingConsentWithdrawn()) : this.Y.withdrawnReplayRecordingBeforeSessionStart()
        }
    }
    const ou = ["replay:consent:unanonymized:granted", "trackConsentGranted"],
        hu = ["replay:consent:unanonymized:withdrawn", "trackConsentWithdrawn"],
        cu = ["replay:consent:startForSession:granted"],
        au = ["replay:consent:startForSession:withdrawn"];
    class uu {
        constructor(t, s, e, i, n) {
            this.D = t, this.Ia = s, this.Ad = e, this.Y = i, this.Uc = n
        }
        init() {
            this.ng = new ru(this.D, this.Y, this.Uc), this.Ad.setInitialConsent(), this.sp()
        }
        sp() {
            this.Ia.register(ou, (() => {
                this.Ad.grantReplayAnonymizationConsent()
            })), this.Ia.register(hu, (() => {
                this.Ad.withdrawReplayAnonymizationConsent()
            })), this.Ia.register(cu, (() => {
                this.ng.grantReplayConsent()
            })), this.Ia.register(au, (() => {
                this.ng.withdrawReplayConsent()
            }))
        }
        onOptout() {
            this.Ad.removeAllConsents()
        }
        onBeforeVisitorRenewal() {
            this.Ad.removeAllConsents()
        }
        onAfterVisitorRenewal() {
            this.Ad.setInitialConsent()
        }
        onAfterVisitorCleared() {
            this.Ad.setInitialConsent()
        }
    }
    class lu {
        constructor(t, s, e) {
            this.D = t, this.wv = s, this.Uc = e
        }
        setInitialConsent() {
            const t = this.wv.get();
            (null === t || this.hasConsentRequiredChanged(t)) && this.setDefaultReplayAnonymization()
        }
        hasConsentRequiredChanged(t) {
            const s = this.D.consentRequired;
            return s && t === iu.NOT_REQUIRED || !s && t !== iu.NOT_REQUIRED
        }
        handleSubdomainChange() {
            this.wv.handleSubdomainChange()
        }
        setDefaultReplayAnonymization() {
            const t = this.D.consentRequired ? iu.NOT_EXPRESSED : iu.NOT_REQUIRED;
            this.wv.set(t)
        }
        grantReplayAnonymizationConsent() {
            this.D.consentRequired && (this.wv.set(iu.GRANTED), this.Uc.emitReplayUnanonymizationConsentGranted())
        }
        withdrawReplayAnonymizationConsent() {
            this.D.consentRequired && (this.wv.set(iu.WITHDRAWN), this.Uc.emitReplayUnanonymizationConsentWithdrawn())
        }
        removeAllConsents() {
            this.wv.remove()
        }
        isReplayUnanonymizedAllowedByConsent() {
            return !this.D.consentRequired || this.wv.get() === iu.GRANTED
        }
        getRequestParameters() {
            return {
                uc: `${this.wv.get()}`
            }
        }
    }
    class du {
        constructor(t, s, e, i, n, r, o) {
            this.Uc = t, this.Ia = s, this.Gm = e, this.Zm = i, this.Wm = n, this.rg = r, this.Qm = o
        }
        start() {
            this.Uc.addListener(this.rg), this.Uc.addListener(this.Qm), this.Uc.addListener(this.Gm), this.Qm.init(), this.Zm.init(), this.Wm.init(), this.Wm.isActive() || this.Ia.start()
        }
    }
    const fu = "_cs_ex",
        pu = 2592e6,
        mu = /^[0-9]+$/;
    class vu {
        constructor(t, s, e) {
            this.D = t, this.Xm = s, this.bv = e
        }
        onCookieToSet(t) {
            this.xv = t
        }
        onCookieToRemove(t) {
            this.$v = t
        }
        get() {
            return this.D.cookielessTrackingEnabled ? Number(this.bv.getItem(fu)) : Number(this.Xm.get(fu))
        }
        set(t) {
            var s;
            this.D.cookielessTrackingEnabled ? this.bv.setItem(fu, t) : (this.Xm.set(fu, t, pu), null === (s = this.xv) || void 0 === s || s.call(this, fu, t, pu))
        }
        remove() {
            var t;
            this.D.cookielessTrackingEnabled ? this.bv.removeItem(fu) : (this.Xm.delete(fu), null === (t = this.$v) || void 0 === t || t.call(this, fu))
        }
        static isValidExclusionString(t) {
            return mu.test(t)
        }
    }
    class gu {
        constructor(t, s) {
            this.Un = t, this.wv = s
        }
        exclude(t) {
            this.wv.set(csString(t.lastTrackingDraw))
        }
        removeExclusion() {
            this.wv.remove()
        }
        isExcluded() {
            return this.og() || this.hg()
        }
        og() {
            return 0 !== this.getAppliedTrackingDraw()
        }
        getAppliedTrackingDraw() {
            return this.wv.get()
        }
        hg() {
            return csString.prototype.indexOf.call(this.Un.href, fu) > 0
        }
    }
    class yu {
        constructor(t) {
            this.wu = t
        }
        onOptout() {
            this.wu.removeExclusion()
        }
    }
    var wu;
    ! function(t) {
        t.SessionReplay = "SR", t.None = ""
    }(wu || (wu = {}));
    class Eu {
        constructor(t) {
            this.ot = t, this.cg = new csRegExp(".^")
        }
        setExcludeUrlForSessionReplay(t) {
            this.cg = new csRegExp(t)
        }
        ag() {
            return this.cg.test(this.ot.getAnonymizedUrl()) ? wu.SessionReplay : wu.None
        }
        isUrlExcludedForSessionReplay() {
            return this.ag() === wu.SessionReplay
        }
        getRequestParameters() {
            return {
                ex: this.ag()
            }
        }
    }
    const Au = ["excludeURLforReplay"];
    class _u {
        constructor(t, s) {
            this.wu = t, this.Ia = s
        }
        init() {
            this.Ia.register(Au, (t => {
                yt(t) && this.wu.setExcludeUrlForSessionReplay(t)
            }))
        }
    }
    const Su = "_cs_inc";
    class Ru {
        constructor(t, s) {
            this.Un = t, this.Xm = s
        }
        isForceIncluded() {
            return this.ug() || this.lg()
        }
        isForceReplayRecorded() {
            return this.dg(He.RECORDING_GLOBAL_SAMPLING)
        }
        ug() {
            return null !== this.Xm.get(Su)
        }
        dg(t) {
            return this.Xm.get(Su) === t
        }
        lg() {
            return csString.prototype.indexOf.call(this.Un.href, Su) > 0
        }
    }
    const Tu = "_cs_optout";
    class Iu {
        constructor(t, s, e) {
            this.D = t, this.Xm = s, this.tv = e
        }
        get() {
            return this.D.cookielessTrackingEnabled ? this.tv.getItem(Tu) : this.Xm.get(Tu)
        }
        set(t) {
            this.D.cookielessTrackingEnabled ? this.tv.setItem(Tu, t) : this.Xm.set(Tu, t, z)
        }
    }
    class bu {
        constructor(t, s, e) {
            this.Uc = t, this.Un = s, this.wv = e
        }
        init() {
            !this.isActive() && this.fg() && this.activate()
        }
        isActive() {
            return "1" === this.wv.get()
        }
        activate() {
            this.Uc.emitOptout(), this.wv.set("1")
        }
        fg() {
            return csString.prototype.indexOf.call(this.Un.href, Tu) > 0
        }
    }
    const Pu = ["optout"];
    class Vu {
        constructor(t, s) {
            this.Ia = t, this.Wm = s
        }
        init() {
            this.Ia.register(Pu, (() => {
                this.Wm.activate()
            }))
        }
    }
    class Cu {
        constructor(t, s) {
            this.Ia = t, this.ou = s
        }
        init() {
            this.ou.addListener(this.Ia)
        }
        onOptout() {
            this.Ia.stop()
        }
        onBeforeSessionRenewal() {
            this.Ia.stop()
        }
    }
    var ku, Ou;
    ! function(t) {
        t.UXA = "_uxa", t.WVT = "cs_wvt"
    }(ku || (ku = {}));
    class Nu extends Fe {
        constructor(t) {
            super(), this.pg = t, this.mg = {}
        }
        register(t, s, e) {
            for (const i of t) this.mg[i] = {
                callback: s,
                configuration: e
            }, this.mg
        }
        onStart() {
            this.vg(), this.gg()
        }
        onStop() {
            for (const t of this.pg) window[t] = []
        }
        applyFromIntegration(t, s, e) {
            this.yg(t, s, `Commands.apply.from.integration: ${e}`)
        }
        applyFromImplementation(t, s, e) {
            this.yg(t, s, `Commands.apply.from.implementation: ${e}`)
        }
        onIframeCommands(t) {
            for (const s of t.commands) this.wg(s.name, s.params, t.iframePath)
        }
        yg(t, s, e) {
            this.isStarted ? ns.tryToExecute(e, (() => {
                if (this.mg[t]) return this.mg[t].callback(...s)
            }))() : window._uxa.push([t, ...s])
        }
        wg(t, s, e) {
            ns.tryToExecute(`Commands.apply.from.iframe: ${e}`, (() => {
                if (this.mg[t]) return this.mg[t].callback(...s)
            }))()
        }
        vg() {
            for (const t of this.pg) window[t].forEach((([t, ...s]) => this.Eg(t, s, !1)))
        }
        gg() {
            for (const t of this.pg) window[t] = {
                push: ([t, ...s]) => this.Eg(t, s, !0)
            }
        }
        Eg(t, s, e) {
            var i, n;
            if (this.mg[t]) {
                if ((null === (i = this.mg[t].configuration) || void 0 === i ? void 0 : i.disableApplyPending) && !e || (null === (n = this.mg[t].configuration) || void 0 === n ? void 0 : n.disableApplyImmediate) && e) return;
                try {
                    return this.mg[t].callback(...s)
                } catch (e) {
                    ns.error(`Command ${t} failed - params: ${csJSON.stringify(s)}`, e)
                }
            }
        }
    }
    class xu {
        constructor(t, s, e, i) {
            this.D = t, this.K = s, this.Y = e, this.Ag = i
        }
        getRequestParameters() {
            var t, s, e, i, n;
            const r = { ...mt(),
                    ...this.D.getRequestParameters()
                },
                o = this.Y.getSession();
            o && (r.pn = `${o.pageNumber}`);
            const h = this.K.getVisitor();
            if (h && (r.sn = `${h.visitsCount}`, r.uu = `${h.id}`), (null === (t = this.Ag) || void 0 === t ? void 0 : t.hasSubProjectId()) && (r.subProjectID = `${this.Ag.getSubProjectId()}`), window.heap) try {
                r.happid = window.heap.appid, r.hsid = null === (e = (s = window.heap).getSessionId) || void 0 === e ? void 0 : e.call(s), r.huu = (null === (n = (i = window.heap).getUserId) || void 0 === n ? void 0 : n.call(i)) || window.heap.userId
            } catch {
                delete r.happid, delete r.hsid, delete r.huu
            }
            return r
        }
    }
    class $u {
        constructor(t, s) {
            this.Ia = t, this.C = s
        }
        init() {
            this.Ia.register(["debugEvents"], (t => {
                "boolean" == typeof t && this.C.updateDynamicFields("emitDebugEvents", t)
            }))
        }
    }

    function Lu(t, s, e) {
        if (!Et(s) && !Et(e)) return t.href;
        const i = Et(s) ? Mu(s) : t.pathname,
            n = Et(e) ? function(t) {
                return j(t, "?") || "" === t ? t : `?${t}`
            }(e) : t.search;
        return `${t.protocol}//${t.host}${i}${n}`
    }

    function Mu(t) {
        return j(t, "/") ? t : `/${t}`
    }! function(t) {
        t[t.page = 1] = "page", t[t.onNextPageviewOnly = 2] = "onNextPageviewOnly"
    }(Ou || (Ou = {}));
    class Du {
        constructor(t, s) {
            this.Un = t, this.Na = s, this._g = 10
        }
        overridePath(t, s) {
            if ("" === t) return void(this.Sg = void 0);
            const e = this.Rg(s);
            e && (this.Tg = e), this.Sg = s ? this.Ig(t, s) : t
        }
        overrideQuery(t, s) {
            const e = this.Rg(s);
            e && (this.bg = e), this.Pg = s ? this.Ig(t, s) : t
        }
        computeOverriddenUrl(t) {
            return this.Vg(t) ? this.getAnonymizedUrl() : t
        }
        Cg(t) {
            return ("string" == typeof t || "number" == typeof t) && t in Ou
        }
        Vg(t) {
            const s = this.kg(this.Un.href);
            return this.kg(t) === s
        }
        kg(t) {
            return s = t, e = "/", -1 !== csString.prototype.indexOf.call(s, e, s.length - e.length) ? csString.prototype.slice.call(t, 0, -1) : t;
            var s, e
        }
        Rg(t) {
            return Et(null == t ? void 0 : t.lifespan) && this.Cg(null == t ? void 0 : t.lifespan) ? null == t ? void 0 : t.lifespan : null
        }
        Og() {
            return this.Tg && this.Tg in Ou
        }
        Ng() {
            return this.bg && this.bg in Ou
        }
        cleanupOverrideLifespan() {
            this.Og() && (this.Sg = void 0, this.Tg = void 0), this.Ng() && (this.Pg = void 0, this.bg = void 0)
        }
        getAnonymizedUrl() {
            const t = Lu(this.Un, this.Sg, this.Pg);
            return this.Na.anonymizeUrl(t)
        }
        getAnonymizedPath() {
            const t = Et(this.Sg) ? Mu(this.Sg) : location.pathname;
            return this.Na.anonymizeUrl(t)
        }
        getUrlProtocol() {
            return this.Un.protocol
        }
        getRequestParameters() {
            return {
                url: this.getAnonymizedUrl()
            }
        }
        Ig(t, s) {
            return this.xg(s) ? this.$g(t) : this.Lg(s) ? this.Mg(t) : t
        }
        Lg(t) {
            return Boolean(t.decodeURI)
        }
        Mg(t) {
            return this.Dg(t, 1, !1)
        }
        xg(t) {
            return Boolean(t.decodeURIDeep)
        }
        $g(t) {
            return this.Dg(t, this._g, !0)
        }
        Dg(t, s, e) {
            let i = t;
            for (let t = 0; t < s; t++) try {
                const t = window.decodeURI(i);
                if (t === i) return i;
                i = t
            } catch {
                return i
            }
            return e && ns.warn(`decodeURIDeep limit reached: ${i}`), i
        }
    }
    class Uu {
        constructor() {
            this.listeners = []
        }
        addListener(t) {
            csArray.prototype.push.call(this.listeners, t)
        }
    }
    class qu extends Uu {
        emitPageEvent(t) {
            for (const s of this.listeners) s.onPageEvent && s.onPageEvent(t)
        }
        emitEventTriggerRecording(t, s) {
            for (const e of this.listeners) e.onEventTriggerRecording && e.onEventTriggerRecording(t, s)
        }
        emitCustomJavaScriptErrorEvent(t) {
            for (const s of this.listeners) s.onCustomJavaScriptErrorEvent && s.onCustomJavaScriptErrorEvent(t)
        }
        emitCustomErrorEvent(t) {
            for (const s of this.listeners) s.onCustomErrorEvent && s.onCustomErrorEvent(t)
        }
        emitUserIdentifierEvent(t) {
            for (const s of this.listeners) s.onUserIdentifierEvent && s.onUserIdentifierEvent(t)
        }
        emitExternalEvent(t) {
            for (const s of this.listeners) s.onExternalEvent && s.onExternalEvent({
                type: zo.EXTERNAL_EVENT,
                name: t,
                ts: 0
            })
        }
    }
    const Fu = "|iframe|";
    class Hu extends Uu {
        constructor(t, s, e, i) {
            super(), this.Ug = t, this.qg = s, this.Fg = e, this.Hg = i
        }
        emitIframeEvent(t, s, e) {
            if (this.Bg(s) && null === t) ns.error(`iframeEventEmitter received event ${s} with null iframe, content:${csJSON.stringify(e)}`);
            else switch (s) {
                case Xt.ChildLogMessage:
                    this.jg(e);
                    break;
                case Xt.AnalysisEvent:
                    {
                        const s = e,
                            i = this.Ug.transformEvent(t, s);i.isUserEvent ? this.zg(i.event) : this.Gg(i.event);
                        break
                    }
                case Xt.RecordingEvent:
                    {
                        const s = e,
                            i = this.Hg.transformEvents(t, s);
                        if (0 === i.events.length) return;i.containsUserEvent ? this.Zg(i.events) : this.Wg(i.events);
                        break
                    }
                case Xt.JavascriptError:
                    this.Qg(e);
                    break;
                case Xt.ApiError:
                    this.Jg(e);
                    break;
                case Xt.DetailedApiError:
                    this.Kg(e);
                    break;
                case Xt.CustomError:
                    this.Yg(e);
                    break;
                case Xt.EmerchandisingMessage:
                    {
                        const s = this.Fg.transformEvent(t, e);this.Xg(s);
                        break
                    }
                case Xt.Commands:
                    {
                        const s = this.qg.transformEvent(t, e);this.ty(s);
                        break
                    }
                case Xt.IntegrationCallback:
                    this.sy(e);
                    break;
                case Xt.StaticResource:
                    this.ey(e);
                    break;
                case Xt.TrackingContextRequestMessage:
                    this.iy(e);
                    break;
                default:
                    ns.error(`Parent received unknown data type from iframe : ${csJSON.stringify(e)}`)
            }
        }
        Bg(t) {
            const s = [Xt.AnalysisEvent, Xt.RecordingEvent, Xt.EmerchandisingMessage, Xt.Commands];
            return -1 !== csArray.prototype.indexOf.call(s, t)
        }
        jg(t) {
            const {
                message: s,
                errorCode: e,
                level: i
            } = t;
            switch (i) {
                case K.debug:
                    ns.debug(s, e);
                    break;
                case K.warn:
                    ns.warn(s, !0, e);
                    break;
                case K.error:
                    ns.error(s, e);
                    break;
                case K.critical:
                    ns.critical(s, e)
            }
        }
        zg(t) {
            for (const s of this.listeners) s.onIframeAnalysisUserEvent && s.onIframeAnalysisUserEvent(t)
        }
        Gg(t) {
            for (const s of this.listeners) s.onIframeAnalysisBrowserEvent && s.onIframeAnalysisBrowserEvent(t)
        }
        Zg(t) {
            for (const s of this.listeners) s.onIframeRecordingUserEvent && s.onIframeRecordingUserEvent(t)
        }
        Wg(t) {
            for (const s of this.listeners) s.onIframeRecordingBrowserEvent && s.onIframeRecordingBrowserEvent(t)
        }
        Qg(t) {
            for (const s of this.listeners) s.onIframeJavascriptError && s.onIframeJavascriptError(t)
        }
        Jg(t) {
            for (const s of this.listeners) s.onIframeApiError && s.onIframeApiError(t)
        }
        Kg(t) {
            for (const s of this.listeners) s.onIframeDetailedApiError && s.onIframeDetailedApiError(t)
        }
        Xg(t) {
            for (const s of this.listeners) s.onIframeEmerchandisingMessage && s.onIframeEmerchandisingMessage(t)
        }
        ty(t) {
            for (const s of this.listeners) s.onIframeCommands && s.onIframeCommands(t)
        }
        sy(t) {
            for (const s of this.listeners) s.onIframeIntegrationCallback && s.onIframeIntegrationCallback(t)
        }
        ey(t) {
            for (const s of this.listeners) s.onIframeStaticResource && s.onIframeStaticResource(t)
        }
        iy(t) {
            for (const s of this.listeners) s.onTrackingContextRequestCallback && s.onTrackingContextRequestCallback(t)
        }
        Yg(t) {
            for (const s of this.listeners) s.onIframeCustomError && s.onIframeCustomError(t)
        }
    }
    var Bu;
    ! function(t) {
        t.COMPRESSION_DISABLED = "compressionDisabled"
    }(Bu || (Bu = {}));
    class ju {
        constructor() {}
        static init(t) {
            this.ny && void 0 === t || this.initFlags(t)
        }
        static initFlags(t = document.cookie) {
            var s;
            const e = null === (s = /_cs_debug=((\w|\.|\:|=)+)/g.exec(t)) || void 0 === s ? void 0 : s[1];
            if (this.ny = new Map, e) {
                const t = csString.prototype.split.call(e, ".");
                for (let s = 0; s < t.length; s++) {
                    const [e, i] = csString.prototype.split.call(t[s], "=");
                    this.ny.set(e, i || "true")
                }
            }
        }
        static getBoolean(t) {
            const s = this.getString(t);
            return null != s && "false" !== s && 0 !== parseInt(s)
        }
        static getString(t) {
            var s;
            return this.init(), null === (s = this.ny) || void 0 === s ? void 0 : s.get(t)
        }
        static isCompressionEnabled() {
            return !this.getBoolean(Bu.COMPRESSION_DISABLED)
        }
        static Log(t) {
            return (s, e, i) => {
                var n;
                const r = e.toString(),
                    o = `${null===(n=s.constructor)||void 0===n?void 0:n.name}.${r}`,
                    h = i.value;
                (function(t, s) {
                    var e;
                    if (null == t) return !1;
                    return t === s || !!(null === (e = csString.prototype.match.call(t, new csRegExp("(^|,)(" + s + ")(,|$)"))) || void 0 === e ? void 0 : e.length)
                })(ju.getString("debugLog"), t) && (i.value = function(...t) {
                    return console.log(o, ...t), h.bind(this)(...t)
                })
            }
        }
    }

    function zu() {
        function t(t) {
            let s = t.length;
            for (; --s >= 0;) t[s] = 0
        }
        const s = 256,
            e = 286,
            i = 30,
            n = 15,
            r = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0]),
            o = new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]),
            h = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7]),
            c = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
            a = new Array(576);
        t(a);
        const u = new Array(60);
        t(u);
        const l = new Array(512);
        t(l);
        const d = new Array(256);
        t(d);
        const f = new Array(29);
        t(f);
        const p = new Array(i);

        function m(t, s, e, i, n) {
            this.static_tree = t, this.extra_bits = s, this.extra_base = e, this.elems = i, this.max_length = n, this.has_stree = t && t.length
        }
        let v, g, y;

        function w(t, s) {
            this.dyn_tree = t, this.max_code = 0, this.stat_desc = s
        }
        t(p);
        const E = t => t < 256 ? l[t] : l[256 + (t >>> 7)],
            A = (t, s) => {
                t.pending_buf[t.pending++] = 255 & s, t.pending_buf[t.pending++] = s >>> 8 & 255
            },
            _ = (t, s, e) => {
                t.bi_valid > 16 - e ? (t.bi_buf |= s << t.bi_valid & 65535, A(t, t.bi_buf), t.bi_buf = s >> 16 - t.bi_valid, t.bi_valid += e - 16) : (t.bi_buf |= s << t.bi_valid & 65535, t.bi_valid += e)
            },
            S = (t, s, e) => {
                _(t, e[2 * s], e[2 * s + 1])
            },
            R = (t, s) => {
                let e = 0;
                do {
                    e |= 1 & t, t >>>= 1, e <<= 1
                } while (--s > 0);
                return e >>> 1
            },
            T = (t, s, e) => {
                const i = new Array(16);
                let r, o, h = 0;
                for (r = 1; r <= n; r++) i[r] = h = h + e[r - 1] << 1;
                for (o = 0; o <= s; o++) {
                    let s = t[2 * o + 1];
                    0 !== s && (t[2 * o] = R(i[s]++, s))
                }
            },
            I = t => {
                let s;
                for (s = 0; s < e; s++) t.dyn_ltree[2 * s] = 0;
                for (s = 0; s < i; s++) t.dyn_dtree[2 * s] = 0;
                for (s = 0; s < 19; s++) t.bl_tree[2 * s] = 0;
                t.dyn_ltree[512] = 1, t.opt_len = t.static_len = 0, t.last_lit = t.matches = 0
            },
            b = t => {
                t.bi_valid > 8 ? A(t, t.bi_buf) : t.bi_valid > 0 && (t.pending_buf[t.pending++] = t.bi_buf), t.bi_buf = 0, t.bi_valid = 0
            },
            P = (t, s, e, i) => {
                const n = 2 * s,
                    r = 2 * e;
                return t[n] < t[r] || t[n] === t[r] && i[s] <= i[e]
            },
            V = (t, s, e) => {
                const i = t.heap[e];
                let n = e << 1;
                for (; n <= t.heap_len && (n < t.heap_len && P(s, t.heap[n + 1], t.heap[n], t.depth) && n++, !P(s, i, t.heap[n], t.depth));) t.heap[e] = t.heap[n], e = n, n <<= 1;
                t.heap[e] = i
            },
            C = (t, e, i) => {
                let n, h, c, a, u = 0;
                if (0 !== t.last_lit)
                    do {
                        n = t.pending_buf[t.d_buf + 2 * u] << 8 | t.pending_buf[t.d_buf + 2 * u + 1], h = t.pending_buf[t.l_buf + u], u++, 0 === n ? S(t, h, e) : (c = d[h], S(t, c + s + 1, e), a = r[c], 0 !== a && (h -= f[c], _(t, h, a)), n--, c = E(n), S(t, c, i), a = o[c], 0 !== a && (n -= p[c], _(t, n, a)))
                    } while (u < t.last_lit);
                S(t, 256, e)
            },
            k = (t, s) => {
                const e = s.dyn_tree,
                    i = s.stat_desc.static_tree,
                    r = s.stat_desc.has_stree,
                    o = s.stat_desc.elems;
                let h, c, a, u = -1;
                for (t.heap_len = 0, t.heap_max = 573, h = 0; h < o; h++) 0 !== e[2 * h] ? (t.heap[++t.heap_len] = u = h, t.depth[h] = 0) : e[2 * h + 1] = 0;
                for (; t.heap_len < 2;) a = t.heap[++t.heap_len] = u < 2 ? ++u : 0, e[2 * a] = 1, t.depth[a] = 0, t.opt_len--, r && (t.static_len -= i[2 * a + 1]);
                for (s.max_code = u, h = t.heap_len >> 1; h >= 1; h--) V(t, e, h);
                a = o;
                do {
                    h = t.heap[1], t.heap[1] = t.heap[t.heap_len--], V(t, e, 1), c = t.heap[1], t.heap[--t.heap_max] = h, t.heap[--t.heap_max] = c, e[2 * a] = e[2 * h] + e[2 * c], t.depth[a] = (t.depth[h] >= t.depth[c] ? t.depth[h] : t.depth[c]) + 1, e[2 * h + 1] = e[2 * c + 1] = a, t.heap[1] = a++, V(t, e, 1)
                } while (t.heap_len >= 2);
                t.heap[--t.heap_max] = t.heap[1], ((t, s) => {
                    const e = s.dyn_tree,
                        i = s.max_code,
                        r = s.stat_desc.static_tree,
                        o = s.stat_desc.has_stree,
                        h = s.stat_desc.extra_bits,
                        c = s.stat_desc.extra_base,
                        a = s.stat_desc.max_length;
                    let u, l, d, f, p, m, v = 0;
                    for (f = 0; f <= n; f++) t.bl_count[f] = 0;
                    for (e[2 * t.heap[t.heap_max] + 1] = 0, u = t.heap_max + 1; u < 573; u++) l = t.heap[u], f = e[2 * e[2 * l + 1] + 1] + 1, f > a && (f = a, v++), e[2 * l + 1] = f, l > i || (t.bl_count[f]++, p = 0, l >= c && (p = h[l - c]), m = e[2 * l], t.opt_len += m * (f + p), o && (t.static_len += m * (r[2 * l + 1] + p)));
                    if (0 !== v) {
                        do {
                            for (f = a - 1; 0 === t.bl_count[f];) f--;
                            t.bl_count[f]--, t.bl_count[f + 1] += 2, t.bl_count[a]--, v -= 2
                        } while (v > 0);
                        for (f = a; 0 !== f; f--)
                            for (l = t.bl_count[f]; 0 !== l;) d = t.heap[--u], d > i || (e[2 * d + 1] !== f && (t.opt_len += (f - e[2 * d + 1]) * e[2 * d], e[2 * d + 1] = f), l--)
                    }
                })(t, s), T(e, u, t.bl_count)
            },
            O = (t, s, e) => {
                let i, n, r = -1,
                    o = s[1],
                    h = 0,
                    c = 7,
                    a = 4;
                for (0 === o && (c = 138, a = 3), s[2 * (e + 1) + 1] = 65535, i = 0; i <= e; i++) n = o, o = s[2 * (i + 1) + 1], ++h < c && n === o || (h < a ? t.bl_tree[2 * n] += h : 0 !== n ? (n !== r && t.bl_tree[2 * n]++, t.bl_tree[32]++) : h <= 10 ? t.bl_tree[34]++ : t.bl_tree[36]++, h = 0, r = n, 0 === o ? (c = 138, a = 3) : n === o ? (c = 6, a = 3) : (c = 7, a = 4))
            },
            N = (t, s, e) => {
                let i, n, r = -1,
                    o = s[1],
                    h = 0,
                    c = 7,
                    a = 4;
                for (0 === o && (c = 138, a = 3), i = 0; i <= e; i++)
                    if (n = o, o = s[2 * (i + 1) + 1], !(++h < c && n === o)) {
                        if (h < a)
                            do {
                                S(t, n, t.bl_tree)
                            } while (0 != --h);
                        else 0 !== n ? (n !== r && (S(t, n, t.bl_tree), h--), S(t, 16, t.bl_tree), _(t, h - 3, 2)) : h <= 10 ? (S(t, 17, t.bl_tree), _(t, h - 3, 3)) : (S(t, 18, t.bl_tree), _(t, h - 11, 7));
                        h = 0, r = n, 0 === o ? (c = 138, a = 3) : n === o ? (c = 6, a = 3) : (c = 7, a = 4)
                    }
            };
        let x = !1;
        const $ = (t, s, e, i) => {
            _(t, 0 + (i ? 1 : 0), 3), ((t, s, e, i) => {
                b(t), i && (A(t, e), A(t, ~e)), t.pending_buf.set(t.window.subarray(s, s + e), t.pending), t.pending += e
            })(t, s, e, !0)
        };
        var L = t => {
                x || ((() => {
                    let t, s, c, w, E;
                    const A = new Array(16);
                    for (c = 0, w = 0; w < 28; w++)
                        for (f[w] = c, t = 0; t < 1 << r[w]; t++) d[c++] = w;
                    for (d[c - 1] = w, E = 0, w = 0; w < 16; w++)
                        for (p[w] = E, t = 0; t < 1 << o[w]; t++) l[E++] = w;
                    for (E >>= 7; w < i; w++)
                        for (p[w] = E << 7, t = 0; t < 1 << o[w] - 7; t++) l[256 + E++] = w;
                    for (s = 0; s <= n; s++) A[s] = 0;
                    for (t = 0; t <= 143;) a[2 * t + 1] = 8, t++, A[8]++;
                    for (; t <= 255;) a[2 * t + 1] = 9, t++, A[9]++;
                    for (; t <= 279;) a[2 * t + 1] = 7, t++, A[7]++;
                    for (; t <= 287;) a[2 * t + 1] = 8, t++, A[8]++;
                    for (T(a, 287, A), t = 0; t < i; t++) u[2 * t + 1] = 5, u[2 * t] = R(t, 5);
                    v = new m(a, r, 257, e, n), g = new m(u, o, 0, i, n), y = new m(new Array(0), h, 0, 19, 7)
                })(), x = !0), t.l_desc = new w(t.dyn_ltree, v), t.d_desc = new w(t.dyn_dtree, g), t.bl_desc = new w(t.bl_tree, y), t.bi_buf = 0, t.bi_valid = 0, I(t)
            },
            M = (t, e, i, n) => {
                let r, o, h = 0;
                t.level > 0 ? (2 === t.strm.data_type && (t.strm.data_type = (t => {
                    let e, i = 4093624447;
                    for (e = 0; e <= 31; e++, i >>>= 1)
                        if (1 & i && 0 !== t.dyn_ltree[2 * e]) return 0;
                    if (0 !== t.dyn_ltree[18] || 0 !== t.dyn_ltree[20] || 0 !== t.dyn_ltree[26]) return 1;
                    for (e = 32; e < s; e++)
                        if (0 !== t.dyn_ltree[2 * e]) return 1;
                    return 0
                })(t)), k(t, t.l_desc), k(t, t.d_desc), h = (t => {
                    let s;
                    for (O(t, t.dyn_ltree, t.l_desc.max_code), O(t, t.dyn_dtree, t.d_desc.max_code), k(t, t.bl_desc), s = 18; s >= 3 && 0 === t.bl_tree[2 * c[s] + 1]; s--);
                    return t.opt_len += 3 * (s + 1) + 5 + 5 + 4, s
                })(t), r = t.opt_len + 3 + 7 >>> 3, o = t.static_len + 3 + 7 >>> 3, o <= r && (r = o)) : r = o = i + 5, i + 4 <= r && -1 !== e ? $(t, e, i, n) : 4 === t.strategy || o === r ? (_(t, 2 + (n ? 1 : 0), 3), C(t, a, u)) : (_(t, 4 + (n ? 1 : 0), 3), ((t, s, e, i) => {
                    let n;
                    for (_(t, s - 257, 5), _(t, e - 1, 5), _(t, i - 4, 4), n = 0; n < i; n++) _(t, t.bl_tree[2 * c[n] + 1], 3);
                    N(t, t.dyn_ltree, s - 1), N(t, t.dyn_dtree, e - 1)
                })(t, t.l_desc.max_code + 1, t.d_desc.max_code + 1, h + 1), C(t, t.dyn_ltree, t.dyn_dtree)), I(t), n && b(t)
            },
            D = (t, e, i) => (t.pending_buf[t.d_buf + 2 * t.last_lit] = e >>> 8 & 255, t.pending_buf[t.d_buf + 2 * t.last_lit + 1] = 255 & e, t.pending_buf[t.l_buf + t.last_lit] = 255 & i, t.last_lit++, 0 === e ? t.dyn_ltree[2 * i]++ : (t.matches++, e--, t.dyn_ltree[2 * (d[i] + s + 1)]++, t.dyn_dtree[2 * E(e)]++), t.last_lit === t.lit_bufsize - 1),
            U = t => {
                _(t, 2, 3), S(t, 256, a), (t => {
                    16 === t.bi_valid ? (A(t, t.bi_buf), t.bi_buf = 0, t.bi_valid = 0) : t.bi_valid >= 8 && (t.pending_buf[t.pending++] = 255 & t.bi_buf, t.bi_buf >>= 8, t.bi_valid -= 8)
                })(t)
            },
            q = {
                _tr_init: L,
                _tr_stored_block: $,
                _tr_flush_block: M,
                _tr_tally: D,
                _tr_align: U
            };
        var F = (t, s, e, i) => {
            let n = 65535 & t,
                r = t >>> 16 & 65535,
                o = 0;
            for (; 0 !== e;) {
                o = e > 2e3 ? 2e3 : e, e -= o;
                do {
                    n = n + s[i++] | 0, r = r + n | 0
                } while (--o);
                n %= 65521, r %= 65521
            }
            return n | r << 16
        };
        const H = new Uint32Array((() => {
            let t, s = [];
            for (var e = 0; e < 256; e++) {
                t = e;
                for (var i = 0; i < 8; i++) t = 1 & t ? 3988292384 ^ t >>> 1 : t >>> 1;
                s[e] = t
            }
            return s
        })());
        var B = (t, s, e, i) => {
                const n = H,
                    r = i + e;
                t ^= -1;
                for (let e = i; e < r; e++) t = t >>> 8 ^ n[255 & (t ^ s[e])];
                return ~t
            },
            j = {
                2: "need dictionary",
                1: "stream end",
                0: "",
                "-1": "file error",
                "-2": "stream error",
                "-3": "data error",
                "-4": "insufficient memory",
                "-5": "buffer error",
                "-6": "incompatible version"
            },
            z = {
                Z_NO_FLUSH: 0,
                Z_PARTIAL_FLUSH: 1,
                Z_SYNC_FLUSH: 2,
                Z_FULL_FLUSH: 3,
                Z_FINISH: 4,
                Z_BLOCK: 5,
                Z_TREES: 6,
                Z_OK: 0,
                Z_STREAM_END: 1,
                Z_NEED_DICT: 2,
                Z_ERRNO: -1,
                Z_STREAM_ERROR: -2,
                Z_DATA_ERROR: -3,
                Z_MEM_ERROR: -4,
                Z_BUF_ERROR: -5,
                Z_NO_COMPRESSION: 0,
                Z_BEST_SPEED: 1,
                Z_BEST_COMPRESSION: 9,
                Z_DEFAULT_COMPRESSION: -1,
                Z_FILTERED: 1,
                Z_HUFFMAN_ONLY: 2,
                Z_RLE: 3,
                Z_FIXED: 4,
                Z_DEFAULT_STRATEGY: 0,
                Z_BINARY: 0,
                Z_TEXT: 1,
                Z_UNKNOWN: 2,
                Z_DEFLATED: 8
            };
        const {
            _tr_init: G,
            _tr_stored_block: Z,
            _tr_flush_block: W,
            _tr_tally: Q,
            _tr_align: J
        } = q, {
            Z_NO_FLUSH: K,
            Z_PARTIAL_FLUSH: Y,
            Z_FULL_FLUSH: X,
            Z_FINISH: tt,
            Z_BLOCK: st,
            Z_OK: et,
            Z_STREAM_END: it,
            Z_STREAM_ERROR: nt,
            Z_DATA_ERROR: rt,
            Z_BUF_ERROR: ot,
            Z_DEFAULT_COMPRESSION: ht,
            Z_FILTERED: ct,
            Z_HUFFMAN_ONLY: at,
            Z_RLE: ut,
            Z_FIXED: lt,
            Z_DEFAULT_STRATEGY: dt,
            Z_UNKNOWN: ft,
            Z_DEFLATED: pt
        } = z, mt = 258, vt = 262, gt = 103, yt = 113, wt = 666, Et = (t, s) => (t.msg = j[s], s), At = t => (t << 1) - (t > 4 ? 9 : 0), _t = t => {
            let s = t.length;
            for (; --s >= 0;) t[s] = 0
        };
        let St = (t, s, e) => (s << t.hash_shift ^ e) & t.hash_mask;
        const Rt = t => {
                const s = t.state;
                let e = s.pending;
                e > t.avail_out && (e = t.avail_out), 0 !== e && (t.output.set(s.pending_buf.subarray(s.pending_out, s.pending_out + e), t.next_out), t.next_out += e, s.pending_out += e, t.total_out += e, t.avail_out -= e, s.pending -= e, 0 === s.pending && (s.pending_out = 0))
            },
            Tt = (t, s) => {
                W(t, t.block_start >= 0 ? t.block_start : -1, t.strstart - t.block_start, s), t.block_start = t.strstart, Rt(t.strm)
            },
            It = (t, s) => {
                t.pending_buf[t.pending++] = s
            },
            bt = (t, s) => {
                t.pending_buf[t.pending++] = s >>> 8 & 255, t.pending_buf[t.pending++] = 255 & s
            },
            Pt = (t, s, e, i) => {
                let n = t.avail_in;
                return n > i && (n = i), 0 === n ? 0 : (t.avail_in -= n, s.set(t.input.subarray(t.next_in, t.next_in + n), e), 1 === t.state.wrap ? t.adler = F(t.adler, s, n, e) : 2 === t.state.wrap && (t.adler = B(t.adler, s, n, e)), t.next_in += n, t.total_in += n, n)
            },
            Vt = (t, s) => {
                let e, i, n = t.max_chain_length,
                    r = t.strstart,
                    o = t.prev_length,
                    h = t.nice_match;
                const c = t.strstart > t.w_size - vt ? t.strstart - (t.w_size - vt) : 0,
                    a = t.window,
                    u = t.w_mask,
                    l = t.prev,
                    d = t.strstart + mt;
                let f = a[r + o - 1],
                    p = a[r + o];
                t.prev_length >= t.good_match && (n >>= 2), h > t.lookahead && (h = t.lookahead);
                do {
                    if (e = s, a[e + o] === p && a[e + o - 1] === f && a[e] === a[r] && a[++e] === a[r + 1]) {
                        r += 2, e++;
                        do {} while (a[++r] === a[++e] && a[++r] === a[++e] && a[++r] === a[++e] && a[++r] === a[++e] && a[++r] === a[++e] && a[++r] === a[++e] && a[++r] === a[++e] && a[++r] === a[++e] && r < d);
                        if (i = mt - (d - r), r = d - mt, i > o) {
                            if (t.match_start = s, o = i, i >= h) break;
                            f = a[r + o - 1], p = a[r + o]
                        }
                    }
                } while ((s = l[s & u]) > c && 0 != --n);
                return o <= t.lookahead ? o : t.lookahead
            },
            Ct = t => {
                const s = t.w_size;
                let e, i, n, r, o;
                do {
                    if (r = t.window_size - t.lookahead - t.strstart, t.strstart >= s + (s - vt)) {
                        t.window.set(t.window.subarray(s, s + s), 0), t.match_start -= s, t.strstart -= s, t.block_start -= s, i = t.hash_size, e = i;
                        do {
                            n = t.head[--e], t.head[e] = n >= s ? n - s : 0
                        } while (--i);
                        i = s, e = i;
                        do {
                            n = t.prev[--e], t.prev[e] = n >= s ? n - s : 0
                        } while (--i);
                        r += s
                    }
                    if (0 === t.strm.avail_in) break;
                    if (i = Pt(t.strm, t.window, t.strstart + t.lookahead, r), t.lookahead += i, t.lookahead + t.insert >= 3)
                        for (o = t.strstart - t.insert, t.ins_h = t.window[o], t.ins_h = St(t, t.ins_h, t.window[o + 1]); t.insert && (t.ins_h = St(t, t.ins_h, t.window[o + 3 - 1]), t.prev[o & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = o, o++, t.insert--, !(t.lookahead + t.insert < 3)););
                } while (t.lookahead < vt && 0 !== t.strm.avail_in)
            },
            kt = (t, s) => {
                let e, i;
                for (;;) {
                    if (t.lookahead < vt) {
                        if (Ct(t), t.lookahead < vt && s === K) return 1;
                        if (0 === t.lookahead) break
                    }
                    if (e = 0, t.lookahead >= 3 && (t.ins_h = St(t, t.ins_h, t.window[t.strstart + 3 - 1]), e = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart), 0 !== e && t.strstart - e <= t.w_size - vt && (t.match_length = Vt(t, e)), t.match_length >= 3)
                        if (i = Q(t, t.strstart - t.match_start, t.match_length - 3), t.lookahead -= t.match_length, t.match_length <= t.max_lazy_match && t.lookahead >= 3) {
                            t.match_length--;
                            do {
                                t.strstart++, t.ins_h = St(t, t.ins_h, t.window[t.strstart + 3 - 1]), e = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart
                            } while (0 != --t.match_length);
                            t.strstart++
                        } else t.strstart += t.match_length, t.match_length = 0, t.ins_h = t.window[t.strstart], t.ins_h = St(t, t.ins_h, t.window[t.strstart + 1]);
                    else i = Q(t, 0, t.window[t.strstart]), t.lookahead--, t.strstart++;
                    if (i && (Tt(t, !1), 0 === t.strm.avail_out)) return 1
                }
                return t.insert = t.strstart < 2 ? t.strstart : 2, s === tt ? (Tt(t, !0), 0 === t.strm.avail_out ? 3 : 4) : t.last_lit && (Tt(t, !1), 0 === t.strm.avail_out) ? 1 : 2
            },
            Ot = (t, s) => {
                let e, i, n;
                for (;;) {
                    if (t.lookahead < vt) {
                        if (Ct(t), t.lookahead < vt && s === K) return 1;
                        if (0 === t.lookahead) break
                    }
                    if (e = 0, t.lookahead >= 3 && (t.ins_h = St(t, t.ins_h, t.window[t.strstart + 3 - 1]), e = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart), t.prev_length = t.match_length, t.prev_match = t.match_start, t.match_length = 2, 0 !== e && t.prev_length < t.max_lazy_match && t.strstart - e <= t.w_size - vt && (t.match_length = Vt(t, e), t.match_length <= 5 && (t.strategy === ct || 3 === t.match_length && t.strstart - t.match_start > 4096) && (t.match_length = 2)), t.prev_length >= 3 && t.match_length <= t.prev_length) {
                        n = t.strstart + t.lookahead - 3, i = Q(t, t.strstart - 1 - t.prev_match, t.prev_length - 3), t.lookahead -= t.prev_length - 1, t.prev_length -= 2;
                        do {
                            ++t.strstart <= n && (t.ins_h = St(t, t.ins_h, t.window[t.strstart + 3 - 1]), e = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart)
                        } while (0 != --t.prev_length);
                        if (t.match_available = 0, t.match_length = 2, t.strstart++, i && (Tt(t, !1), 0 === t.strm.avail_out)) return 1
                    } else if (t.match_available) {
                        if (i = Q(t, 0, t.window[t.strstart - 1]), i && Tt(t, !1), t.strstart++, t.lookahead--, 0 === t.strm.avail_out) return 1
                    } else t.match_available = 1, t.strstart++, t.lookahead--
                }
                return t.match_available && (i = Q(t, 0, t.window[t.strstart - 1]), t.match_available = 0), t.insert = t.strstart < 2 ? t.strstart : 2, s === tt ? (Tt(t, !0), 0 === t.strm.avail_out ? 3 : 4) : t.last_lit && (Tt(t, !1), 0 === t.strm.avail_out) ? 1 : 2
            };

        function Nt(t, s, e, i, n) {
            this.good_length = t, this.max_lazy = s, this.nice_length = e, this.max_chain = i, this.func = n
        }
        const xt = [new Nt(0, 0, 0, 0, ((t, s) => {
            let e = 65535;
            for (e > t.pending_buf_size - 5 && (e = t.pending_buf_size - 5);;) {
                if (t.lookahead <= 1) {
                    if (Ct(t), 0 === t.lookahead && s === K) return 1;
                    if (0 === t.lookahead) break
                }
                t.strstart += t.lookahead, t.lookahead = 0;
                const i = t.block_start + e;
                if ((0 === t.strstart || t.strstart >= i) && (t.lookahead = t.strstart - i, t.strstart = i, Tt(t, !1), 0 === t.strm.avail_out)) return 1;
                if (t.strstart - t.block_start >= t.w_size - vt && (Tt(t, !1), 0 === t.strm.avail_out)) return 1
            }
            return t.insert = 0, s === tt ? (Tt(t, !0), 0 === t.strm.avail_out ? 3 : 4) : (t.strstart > t.block_start && (Tt(t, !1), t.strm.avail_out), 1)
        })), new Nt(4, 4, 8, 4, kt), new Nt(4, 5, 16, 8, kt), new Nt(4, 6, 32, 32, kt), new Nt(4, 4, 16, 16, Ot), new Nt(8, 16, 32, 32, Ot), new Nt(8, 16, 128, 128, Ot), new Nt(8, 32, 128, 256, Ot), new Nt(32, 128, 258, 1024, Ot), new Nt(32, 258, 258, 4096, Ot)];

        function $t() {
            this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = pt, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new Uint16Array(1146), this.dyn_dtree = new Uint16Array(122), this.bl_tree = new Uint16Array(78), _t(this.dyn_ltree), _t(this.dyn_dtree), _t(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new Uint16Array(16), this.heap = new Uint16Array(573), _t(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new Uint16Array(573), _t(this.depth), this.l_buf = 0, this.lit_bufsize = 0, this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0
        }
        const Lt = t => {
                if (!t || !t.state) return Et(t, nt);
                t.total_in = t.total_out = 0, t.data_type = ft;
                const s = t.state;
                return s.pending = 0, s.pending_out = 0, s.wrap < 0 && (s.wrap = -s.wrap), s.status = s.wrap ? 42 : yt, t.adler = 2 === s.wrap ? 0 : 1, s.last_flush = K, G(s), et
            },
            Mt = t => {
                const s = Lt(t);
                return s === et && (t => {
                    t.window_size = 2 * t.w_size, _t(t.head), t.max_lazy_match = xt[t.level].max_lazy, t.good_match = xt[t.level].good_length, t.nice_match = xt[t.level].nice_length, t.max_chain_length = xt[t.level].max_chain, t.strstart = 0, t.block_start = 0, t.lookahead = 0, t.insert = 0, t.match_length = t.prev_length = 2, t.match_available = 0, t.ins_h = 0
                })(t.state), s
            },
            Dt = (t, s, e, i, n, r) => {
                if (!t) return nt;
                let o = 1;
                if (s === ht && (s = 6), i < 0 ? (o = 0, i = -i) : i > 15 && (o = 2, i -= 16), n < 1 || n > 9 || e !== pt || i < 8 || i > 15 || s < 0 || s > 9 || r < 0 || r > lt) return Et(t, nt);
                8 === i && (i = 9);
                const h = new $t;
                return t.state = h, h.strm = t, h.wrap = o, h.gzhead = null, h.w_bits = i, h.w_size = 1 << h.w_bits, h.w_mask = h.w_size - 1, h.hash_bits = n + 7, h.hash_size = 1 << h.hash_bits, h.hash_mask = h.hash_size - 1, h.hash_shift = ~~((h.hash_bits + 3 - 1) / 3), h.window = new Uint8Array(2 * h.w_size), h.head = new Uint16Array(h.hash_size), h.prev = new Uint16Array(h.w_size), h.lit_bufsize = 1 << n + 6, h.pending_buf_size = 4 * h.lit_bufsize, h.pending_buf = new Uint8Array(h.pending_buf_size), h.d_buf = 1 * h.lit_bufsize, h.l_buf = 3 * h.lit_bufsize, h.level = s, h.strategy = r, h.method = e, Mt(t)
            };
        var Ut = (t, s) => {
                let e, i;
                if (!t || !t.state || s > st || s < 0) return t ? Et(t, nt) : nt;
                const n = t.state;
                if (!t.output || !t.input && 0 !== t.avail_in || n.status === wt && s !== tt) return Et(t, 0 === t.avail_out ? ot : nt);
                n.strm = t;
                const r = n.last_flush;
                if (n.last_flush = s, 42 === n.status)
                    if (2 === n.wrap) t.adler = 0, It(n, 31), It(n, 139), It(n, 8), n.gzhead ? (It(n, (n.gzhead.text ? 1 : 0) + (n.gzhead.hcrc ? 2 : 0) + (n.gzhead.extra ? 4 : 0) + (n.gzhead.name ? 8 : 0) + (n.gzhead.comment ? 16 : 0)), It(n, 255 & n.gzhead.time), It(n, n.gzhead.time >> 8 & 255), It(n, n.gzhead.time >> 16 & 255), It(n, n.gzhead.time >> 24 & 255), It(n, 9 === n.level ? 2 : n.strategy >= at || n.level < 2 ? 4 : 0), It(n, 255 & n.gzhead.os), n.gzhead.extra && n.gzhead.extra.length && (It(n, 255 & n.gzhead.extra.length), It(n, n.gzhead.extra.length >> 8 & 255)), n.gzhead.hcrc && (t.adler = B(t.adler, n.pending_buf, n.pending, 0)), n.gzindex = 0, n.status = 69) : (It(n, 0), It(n, 0), It(n, 0), It(n, 0), It(n, 0), It(n, 9 === n.level ? 2 : n.strategy >= at || n.level < 2 ? 4 : 0), It(n, 3), n.status = yt);
                    else {
                        let s = pt + (n.w_bits - 8 << 4) << 8,
                            e = -1;
                        e = n.strategy >= at || n.level < 2 ? 0 : n.level < 6 ? 1 : 6 === n.level ? 2 : 3, s |= e << 6, 0 !== n.strstart && (s |= 32), s += 31 - s % 31, n.status = yt, bt(n, s), 0 !== n.strstart && (bt(n, t.adler >>> 16), bt(n, 65535 & t.adler)), t.adler = 1
                    }
                if (69 === n.status)
                    if (n.gzhead.extra) {
                        for (e = n.pending; n.gzindex < (65535 & n.gzhead.extra.length) && (n.pending !== n.pending_buf_size || (n.gzhead.hcrc && n.pending > e && (t.adler = B(t.adler, n.pending_buf, n.pending - e, e)), Rt(t), e = n.pending, n.pending !== n.pending_buf_size));) It(n, 255 & n.gzhead.extra[n.gzindex]), n.gzindex++;
                        n.gzhead.hcrc && n.pending > e && (t.adler = B(t.adler, n.pending_buf, n.pending - e, e)), n.gzindex === n.gzhead.extra.length && (n.gzindex = 0, n.status = 73)
                    } else n.status = 73;
                if (73 === n.status)
                    if (n.gzhead.name) {
                        e = n.pending;
                        do {
                            if (n.pending === n.pending_buf_size && (n.gzhead.hcrc && n.pending > e && (t.adler = B(t.adler, n.pending_buf, n.pending - e, e)), Rt(t), e = n.pending, n.pending === n.pending_buf_size)) {
                                i = 1;
                                break
                            }
                            i = n.gzindex < n.gzhead.name.length ? 255 & n.gzhead.name.charCodeAt(n.gzindex++) : 0, It(n, i)
                        } while (0 !== i);
                        n.gzhead.hcrc && n.pending > e && (t.adler = B(t.adler, n.pending_buf, n.pending - e, e)), 0 === i && (n.gzindex = 0, n.status = 91)
                    } else n.status = 91;
                if (91 === n.status)
                    if (n.gzhead.comment) {
                        e = n.pending;
                        do {
                            if (n.pending === n.pending_buf_size && (n.gzhead.hcrc && n.pending > e && (t.adler = B(t.adler, n.pending_buf, n.pending - e, e)), Rt(t), e = n.pending, n.pending === n.pending_buf_size)) {
                                i = 1;
                                break
                            }
                            i = n.gzindex < n.gzhead.comment.length ? 255 & n.gzhead.comment.charCodeAt(n.gzindex++) : 0, It(n, i)
                        } while (0 !== i);
                        n.gzhead.hcrc && n.pending > e && (t.adler = B(t.adler, n.pending_buf, n.pending - e, e)), 0 === i && (n.status = gt)
                    } else n.status = gt;
                if (n.status === gt && (n.gzhead.hcrc ? (n.pending + 2 > n.pending_buf_size && Rt(t), n.pending + 2 <= n.pending_buf_size && (It(n, 255 & t.adler), It(n, t.adler >> 8 & 255), t.adler = 0, n.status = yt)) : n.status = yt), 0 !== n.pending) {
                    if (Rt(t), 0 === t.avail_out) return n.last_flush = -1, et
                } else if (0 === t.avail_in && At(s) <= At(r) && s !== tt) return Et(t, ot);
                if (n.status === wt && 0 !== t.avail_in) return Et(t, ot);
                if (0 !== t.avail_in || 0 !== n.lookahead || s !== K && n.status !== wt) {
                    let e = n.strategy === at ? ((t, s) => {
                        let e;
                        for (;;) {
                            if (0 === t.lookahead && (Ct(t), 0 === t.lookahead)) {
                                if (s === K) return 1;
                                break
                            }
                            if (t.match_length = 0, e = Q(t, 0, t.window[t.strstart]), t.lookahead--, t.strstart++, e && (Tt(t, !1), 0 === t.strm.avail_out)) return 1
                        }
                        return t.insert = 0, s === tt ? (Tt(t, !0), 0 === t.strm.avail_out ? 3 : 4) : t.last_lit && (Tt(t, !1), 0 === t.strm.avail_out) ? 1 : 2
                    })(n, s) : n.strategy === ut ? ((t, s) => {
                        let e, i, n, r;
                        const o = t.window;
                        for (;;) {
                            if (t.lookahead <= mt) {
                                if (Ct(t), t.lookahead <= mt && s === K) return 1;
                                if (0 === t.lookahead) break
                            }
                            if (t.match_length = 0, t.lookahead >= 3 && t.strstart > 0 && (n = t.strstart - 1, i = o[n], i === o[++n] && i === o[++n] && i === o[++n])) {
                                r = t.strstart + mt;
                                do {} while (i === o[++n] && i === o[++n] && i === o[++n] && i === o[++n] && i === o[++n] && i === o[++n] && i === o[++n] && i === o[++n] && n < r);
                                t.match_length = mt - (r - n), t.match_length > t.lookahead && (t.match_length = t.lookahead)
                            }
                            if (t.match_length >= 3 ? (e = Q(t, 1, t.match_length - 3), t.lookahead -= t.match_length, t.strstart += t.match_length, t.match_length = 0) : (e = Q(t, 0, t.window[t.strstart]), t.lookahead--, t.strstart++), e && (Tt(t, !1), 0 === t.strm.avail_out)) return 1
                        }
                        return t.insert = 0, s === tt ? (Tt(t, !0), 0 === t.strm.avail_out ? 3 : 4) : t.last_lit && (Tt(t, !1), 0 === t.strm.avail_out) ? 1 : 2
                    })(n, s) : xt[n.level].func(n, s);
                    if (3 !== e && 4 !== e || (n.status = wt), 1 === e || 3 === e) return 0 === t.avail_out && (n.last_flush = -1), et;
                    if (2 === e && (s === Y ? J(n) : s !== st && (Z(n, 0, 0, !1), s === X && (_t(n.head), 0 === n.lookahead && (n.strstart = 0, n.block_start = 0, n.insert = 0))), Rt(t), 0 === t.avail_out)) return n.last_flush = -1, et
                }
                return s !== tt ? et : n.wrap <= 0 ? it : (2 === n.wrap ? (It(n, 255 & t.adler), It(n, t.adler >> 8 & 255), It(n, t.adler >> 16 & 255), It(n, t.adler >> 24 & 255), It(n, 255 & t.total_in), It(n, t.total_in >> 8 & 255), It(n, t.total_in >> 16 & 255), It(n, t.total_in >> 24 & 255)) : (bt(n, t.adler >>> 16), bt(n, 65535 & t.adler)), Rt(t), n.wrap > 0 && (n.wrap = -n.wrap), 0 !== n.pending ? et : it)
            },
            qt = (t, s) => {
                let e = s.length;
                if (!t || !t.state) return nt;
                const i = t.state,
                    n = i.wrap;
                if (2 === n || 1 === n && 42 !== i.status || i.lookahead) return nt;
                if (1 === n && (t.adler = F(t.adler, s, e, 0)), i.wrap = 0, e >= i.w_size) {
                    0 === n && (_t(i.head), i.strstart = 0, i.block_start = 0, i.insert = 0);
                    let t = new Uint8Array(i.w_size);
                    t.set(s.subarray(e - i.w_size, e), 0), s = t, e = i.w_size
                }
                const r = t.avail_in,
                    o = t.next_in,
                    h = t.input;
                for (t.avail_in = e, t.next_in = 0, t.input = s, Ct(i); i.lookahead >= 3;) {
                    let t = i.strstart,
                        s = i.lookahead - 2;
                    do {
                        i.ins_h = St(i, i.ins_h, i.window[t + 3 - 1]), i.prev[t & i.w_mask] = i.head[i.ins_h], i.head[i.ins_h] = t, t++
                    } while (--s);
                    i.strstart = t, i.lookahead = 2, Ct(i)
                }
                return i.strstart += i.lookahead, i.block_start = i.strstart, i.insert = i.lookahead, i.lookahead = 0, i.match_length = i.prev_length = 2, i.match_available = 0, t.next_in = o, t.input = h, t.avail_in = r, i.wrap = n, et
            },
            Ft = {
                deflateInit: (t, s) => Dt(t, s, pt, 15, 8, dt),
                deflateInit2: Dt,
                deflateReset: Mt,
                deflateResetKeep: Lt,
                deflateSetHeader: (t, s) => t && t.state ? 2 !== t.state.wrap ? nt : (t.state.gzhead = s, et) : nt,
                deflate: Ut,
                deflateEnd: t => {
                    if (!t || !t.state) return nt;
                    const s = t.state.status;
                    return 42 !== s && 69 !== s && 73 !== s && 91 !== s && s !== gt && s !== yt && s !== wt ? Et(t, nt) : (t.state = null, s === yt ? Et(t, rt) : et)
                },
                deflateSetDictionary: qt,
                deflateInfo: "pako deflate (from Nodeca project)"
            };
        const Ht = (t, s) => Object.prototype.hasOwnProperty.call(t, s);
        var Bt = function(t) {
                const s = Array.prototype.slice.call(arguments, 1);
                for (; s.length;) {
                    const e = s.shift();
                    if (e) {
                        if ("object" != typeof e) throw new TypeError(e + "must be non-object");
                        for (const s in e) Ht(e, s) && (t[s] = e[s])
                    }
                }
                return t
            },
            jt = t => {
                let s = 0;
                for (let e = 0, i = t.length; e < i; e++) s += t[e].length;
                const e = new Uint8Array(s);
                for (let s = 0, i = 0, n = t.length; s < n; s++) {
                    let n = t[s];
                    e.set(n, i), i += n.length
                }
                return e
            };
        let zt = !0;
        try {
            String.fromCharCode.apply(null, new Uint8Array(1))
        } catch (t) {
            zt = !1
        }
        const Gt = new Uint8Array(256);
        for (let t = 0; t < 256; t++) Gt[t] = t >= 252 ? 6 : t >= 248 ? 5 : t >= 240 ? 4 : t >= 224 ? 3 : t >= 192 ? 2 : 1;
        Gt[254] = Gt[254] = 1;
        const Zt = (t, s = t.length) => {
            if (s < 65534 && t.subarray && zt) return String.fromCharCode.apply(null, t.length === s ? t : t.subarray(0, s));
            let e = "";
            for (let i = 0; i < s; i++) e += String.fromCharCode(t[i]);
            return e
        };
        var Wt = t => {
            if ("function" == typeof TextEncoder && TextEncoder.prototype.encode) return (new TextEncoder).encode(t);
            let s, e, i, n, r, o = t.length,
                h = 0;
            for (n = 0; n < o; n++) e = t.charCodeAt(n), 55296 == (64512 & e) && n + 1 < o && (i = t.charCodeAt(n + 1), 56320 == (64512 & i) && (e = 65536 + (e - 55296 << 10) + (i - 56320), n++)), h += e < 128 ? 1 : e < 2048 ? 2 : e < 65536 ? 3 : 4;
            for (s = new Uint8Array(h), r = 0, n = 0; r < h; n++) e = t.charCodeAt(n), 55296 == (64512 & e) && n + 1 < o && (i = t.charCodeAt(n + 1), 56320 == (64512 & i) && (e = 65536 + (e - 55296 << 10) + (i - 56320), n++)), e < 128 ? s[r++] = e : e < 2048 ? (s[r++] = 192 | e >>> 6, s[r++] = 128 | 63 & e) : e < 65536 ? (s[r++] = 224 | e >>> 12, s[r++] = 128 | e >>> 6 & 63, s[r++] = 128 | 63 & e) : (s[r++] = 240 | e >>> 18, s[r++] = 128 | e >>> 12 & 63, s[r++] = 128 | e >>> 6 & 63, s[r++] = 128 | 63 & e);
            return s
        };
        var Qt = function() {
            this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0
        };
        const Jt = Object.prototype.toString,
            {
                Z_NO_FLUSH: Kt,
                Z_SYNC_FLUSH: Yt,
                Z_FULL_FLUSH: Xt,
                Z_FINISH: ts,
                Z_OK: ss,
                Z_STREAM_END: es,
                Z_DEFAULT_COMPRESSION: is,
                Z_DEFAULT_STRATEGY: ns,
                Z_DEFLATED: rs
            } = z;

        function os(t) {
            this.options = Bt({
                level: is,
                method: rs,
                chunkSize: 16384,
                windowBits: 15,
                memLevel: 8,
                strategy: ns
            }, t || {});
            let s = this.options;
            s.raw && s.windowBits > 0 ? s.windowBits = -s.windowBits : s.gzip && s.windowBits > 0 && s.windowBits < 16 && (s.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new Qt, this.strm.avail_out = 0;
            let e = Ft.deflateInit2(this.strm, s.level, s.method, s.windowBits, s.memLevel, s.strategy);
            if (e !== ss) throw new Error(j[e]);
            if (s.header && Ft.deflateSetHeader(this.strm, s.header), s.dictionary) {
                let t;
                if (t = "string" == typeof s.dictionary ? Wt(s.dictionary) : "[object ArrayBuffer]" === Jt.call(s.dictionary) ? new Uint8Array(s.dictionary) : s.dictionary, e = Ft.deflateSetDictionary(this.strm, t), e !== ss) throw new Error(j[e]);
                this._dict_set = !0
            }
        }

        function hs(t, s) {
            return (s = s || {}).gzip = !0,
                function(t, s) {
                    const e = new os(s = s || {});
                    if (e.push(t, !0), e.err) throw e.msg || j[e.err];
                    return e.result
                }(t, s)
        }
        return os.prototype.push = function(t, s) {
            const e = this.strm,
                i = this.options.chunkSize;
            let n, r;
            if (this.ended) return !1;
            for (r = s === ~~s ? s : !0 === s ? ts : Kt, "string" == typeof t ? e.input = Wt(t) : "[object ArrayBuffer]" === Jt.call(t) ? e.input = new Uint8Array(t) : e.input = t, e.next_in = 0, e.avail_in = e.input.length;;)
                if (0 === e.avail_out && (e.output = new Uint8Array(i), e.next_out = 0, e.avail_out = i), (r === Yt || r === Xt) && e.avail_out <= 6) this.onData(e.output.subarray(0, e.next_out)), e.avail_out = 0;
                else {
                    if (n = Ft.deflate(e, r), n === es) return e.next_out > 0 && this.onData(e.output.subarray(0, e.next_out)), n = Ft.deflateEnd(this.strm), this.onEnd(n), this.ended = !0, n === ss;
                    if (0 !== e.avail_out) {
                        if (r > 0 && e.next_out > 0) this.onData(e.output.subarray(0, e.next_out)), e.avail_out = 0;
                        else if (0 === e.avail_in) break
                    } else this.onData(e.output)
                }
            return !0
        }, os.prototype.onData = function(t) {
            this.chunks.push(t)
        }, os.prototype.onEnd = function(t) {
            t === ss && (this.result = jt(this.chunks)), this.chunks = [], this.err = t, this.msg = this.strm.msg
        }, (t, s, e) => {
            let i = hs(t);
            return i = "base64" === s ? btoa(Zt(i)) : i.buffer, e && e(i), i
        }
    }
    class Gu extends Ns {
        constructor(t) {
            super(t), this.algorithm = Os.GZIP, this.oy = zu(), this.hy = (t, s, e) => {
                e(this.oy(t, s))
            }, this.compress = Zu();
            "undefined" != typeof CompressionStream && Ee || (this.compress = this.hy, this.getCompressorSourceCode = () => zu.toString())
        }
        compressSync(t, s) {
            return this.oy(t, s)
        }
        getCompressorSourceCode() {
            return Zu.toString()
        }
    }

    function Zu() {
        return (t, s, e) => {
            const i = new Response(t).body.pipeThrough(new CompressionStream("gzip")),
                n = new Response(i).arrayBuffer();
            "base64" !== s ? n.then((t => e(t))) : n.then((t => {
                return s = t, new Promise((t => {
                    const e = new FileReader;
                    e.onload = s => t(s.target.result.split(",")[1]), e.readAsDataURL(new Blob([s]))
                }));
                var s
            })).then((t => e(t)))
        }
    }
    class Wu extends Ns {
        constructor() {
            super(...arguments), this.algorithm = Os.UNCOMPRESSED
        }
        compress(t, s, e) {
            e(this.compressSync(t, s))
        }
        compressSync(t, s) {
            return t
        }
        getCompressorSourceCode() {
            return function() {
                return (t, s, e) => e(t)
            }.toString()
        }
    }
    class Qu {
        static create(t, s = !0) {
            return this.instance ? this.instance : s && !ju.isCompressionEnabled() ? new Wu(t) : this.instance = new Gu(t)
        }
    }
    class Ju {
        setItem(t, s) {
            window.sessionStorage.setItem(t, s)
        }
        getItem(t) {
            return window.sessionStorage.getItem(t)
        }
        removeItem(t) {
            window.sessionStorage.removeItem(t)
        }
    }
    class Ku {
        setItem(t, s) {
            window.localStorage.setItem(t, s)
        }
        getItem(t) {
            return window.localStorage.getItem(t)
        }
        removeItem(t) {
            window.localStorage.removeItem(t)
        }
    }
    const Yu = "_cs_cvars";
    class Xu {
        constructor(t, s, e) {
            this.D = t, this.Xm = s, this.bv = e
        }
        onCookieToSet(t) {
            this.xv = t
        }
        onCookieToRemove(t) {
            this.$v = t
        }
        get() {
            return this.D.cookielessTrackingEnabled ? this.bv.getItem(Yu) : this.Xm.get(Yu)
        }
        set(t) {
            var s;
            this.D.cookielessTrackingEnabled ? this.bv.setItem(Yu, t) : (this.Xm.set(Yu, t), null === (s = this.xv) || void 0 === s || s.call(this, Yu, t))
        }
        remove() {
            var t;
            this.D.cookielessTrackingEnabled ? this.bv.removeItem(Yu) : (this.Xm.delete(Yu), null === (t = this.$v) || void 0 === t || t.call(this, Yu))
        }
        static isValidCustomVarString(t) {
            return "string" == typeof t
        }
    }
    const tl = ["visit", 2],
        sl = ["page", 3],
        el = ["nextPageOnly", 4];
    class il {
        constructor(t, s) {
            this.U = t, this.wv = s, this.uy = {}, this.ly = {}
        }
        set(t, s, e, i) {
            let n, r;
            if (t > 0 && At(s) && At(e) && !_t(s) && !_t(e)) {
                const o = this.U.anonymizePII(csString(s)),
                    h = this.U.anonymizePII(csString(e));
                if (n = [csString.prototype.slice.call(o, 0, 512), csString.prototype.slice.call(h, 0, 255)], r = "" !== e, !Et(i) || csArray.prototype.indexOf.call(tl, i) >= 0) {
                    const s = this.getCustomVariablesSession();
                    r ? s[t] = n : delete s[t], this.setCustomVariableSession(s)
                }(!Et(i) || csArray.prototype.indexOf.call(sl, i) >= 0) && (r ? this.uy[t] = n : delete this.uy[t]), Et(i) && csArray.prototype.indexOf.call(el, i) >= 0 && (r ? this.ly[t] = n : delete this.ly[t])
            }
        }
        getCustomVariablesSession() {
            const t = this.wv.get();
            if (!t) return {};
            const s = window.csJSON.parse(t);
            return null !== s && wt(s) ? s : {}
        }
        setCustomVariableSession(t) {
            this.wv.set(window.csJSON.stringify(t))
        }
        removeCustomVariablesSession() {
            this.wv.remove()
        }
        removeCustomVariablesPage() {
            this.uy = {}
        }
        getRequestParameters() {
            const t = this.getCustomVariablesSession();
            for (const t in this.ly) this.ly.hasOwnProperty(t) && (this.uy[t] = this.ly[t]);
            for (const s in this.uy) this.uy.hasOwnProperty(s) && (t[s] = this.uy[s]);
            if (window.csJSON.stringify(t).length <= 2) return {};
            const s = {
                cvars: this.py(t)
            };
            return this.uy && window.csJSON.stringify(this.uy).length > 2 && (s.cvarp = this.py(this.uy)), s
        }
        deleteNextPageOnlyCustomVariables() {
            if (Object.keys(this.ly).length > 0)
                for (const t in this.ly) this.ly[t] === this.uy[t] && (delete this.uy[t], delete this.ly[t])
        }
        my(t) {
            for (const n in t)
                if (t.hasOwnProperty(n)) {
                    const r = parseInt(n, 10),
                        o = t[n],
                        h = o[0],
                        c = o[1];
                    e = 1, i = 20, (!(gt(s = r) && s >= e && s <= i) || h.length > 512 || c.length > 255) && delete t[n]
                }
            var s, e, i
        }
        py(t) {
            this.my(t);
            const s = function(t) {
                let s;
                for (s in t) return !1;
                return !0
            }(t) ? [] : t;
            return window.csJSON.stringify(s)
        }
        getAllValidCustomVars() {
            const t = this.getCustomVariablesSession();
            for (const t in this.ly) this.ly.hasOwnProperty(t) && (this.uy[t] = this.ly[t]);
            for (const s in this.uy) this.uy.hasOwnProperty(s) && (t[s] = this.uy[s]);
            return this.my(t), t
        }
    }
    const nl = ["setCustomVariable"];
    class rl {
        constructor(t, s) {
            this.Ia = t, this.ps = s
        }
        init() {
            this.Ia.register(nl, ((t, s, e, i) => {
                this.ps.set(t, s, e, i)
            }))
        }
        onAfterArtificialPageView() {
            this.ps.deleteNextPageOnlyCustomVariables()
        }
        onAfterNaturalPageView() {
            this.ps.deleteNextPageOnlyCustomVariables()
        }
        onOptout() {
            this.ps.removeCustomVariablesSession()
        }
        onBeforeVisitorRenewal() {
            this.ps.removeCustomVariablesSession(), this.ps.removeCustomVariablesPage()
        }
    }
    const ol = "_cs_id",
        hl = /^(([a-z0-9\-])+(\.[0-9]+){6})(\.(None|Lax|X)\.(0|1))?(\.[0-1])?$/;
    class cl {
        constructor(t, s, e) {
            this.D = t, this.Xm = s, this.bv = e
        }
        onCookieToSet(t) {
            this.xv = t
        }
        onCookieToRemove(t) {
            this.$v = t
        }
        get() {
            let t;
            return t = this.D.cookielessTrackingEnabled ? this.bv.getItem(ol) : this.Xm.get(ol), t ? cl.fromString(t) : null
        }
        set(t) {
            var s;
            const e = cl.toString(t);
            if (this.D.cookielessTrackingEnabled) this.bv.setItem(ol, e);
            else {
                const i = new csDate(t.expires);
                this.Xm.set(ol, e, i), null === (s = this.xv) || void 0 === s || s.call(this, ol, e, i)
            }
        }
        remove() {
            var t;
            this.D.cookielessTrackingEnabled ? this.bv.removeItem(ol) : (this.Xm.delete(ol), null === (t = this.$v) || void 0 === t || t.call(this, ol))
        }
        handleSubdomainChange() {
            if (this.D.cookielessTrackingEnabled) return;
            const t = this.get();
            t && (t.allowSubdomains = this.D.allowSubdomains, this.D.allowSubdomains ? this.Xm.delete(ol, Is.CURRENT_DOMAIN) : this.Xm.delete(ol, this.Xm.getRootDomain()), this.set(t))
        }
        static fromString(t) {
            const [s, e, i, n, r, o, h, c] = csString.prototype.split.call(t, ".");
            return {
                id: s,
                creationTimestamp: Number(e),
                visitsCount: Number(i),
                hitTimestamp: Number(n),
                lastVisitTimestamp: Number(r),
                appliedTrackingDraw: Number(o),
                expires: Number(h),
                allowSubdomains: void 0 === c ? void 0 : !!Number(c)
            }
        }
        static toString(t) {
            return csArray.prototype.join.call([t.id, t.creationTimestamp, t.visitsCount, t.hitTimestamp, t.lastVisitTimestamp, t.appliedTrackingDraw, t.expires, t.allowSubdomains ? 1 : 0], ".")
        }
        static isValidVisitorString(t) {
            return hl.test(t)
        }
    }
    class al {
        constructor(t) {
            this.U = t
        }
        anonymizeUrl(t, s = [], e = []) {
            let i = this.U.anonymizePII(t);
            i = this.U.anonymizeJwt(i);
            const n = this.vy(i, s);
            return n !== i ? n : this.gy(i, e)
        }
        removeQueryString(t) {
            const {
                path: s,
                queryString: e
            } = this.yy(t);
            return "" !== e ? `${s}?` : s
        }
        yy(t) {
            const s = csString.prototype.indexOf.call(t, "?");
            let e, i = "";
            return -1 !== s ? (e = csString.prototype.slice.call(t, 0, s), i = csString.prototype.slice.call(t, s, t.length)) : e = t, {
                path: e,
                queryString: i
            }
        }
        vy(t, s) {
            if (0 === s.length) return t;
            const {
                path: e,
                queryString: i
            } = this.yy(t), n = csString.prototype.split.call(e, "/");
            for (const t of s) {
                const s = this.wy(n, t);
                if (null !== s) return `${s}${i}`
            }
            return t
        }
        wy(t, s) {
            if (t.length < s.length) return null;
            const e = [];
            for (let i = 0; i < t.length; i++) {
                const n = t[i];
                if (i >= s.length) {
                    csArray.prototype.push.call(e, n);
                    continue
                }
                const r = s[i].key;
                if (this.Ey(r)) {
                    const t = s[i].value;
                    csArray.prototype.push.call(e, t)
                } else {
                    if (n !== r) return null;
                    csArray.prototype.push.call(e, n)
                }
            }
            return csArray.prototype.join.call(e, "/")
        }
        gy(t, s) {
            if (0 === s.length) return t;
            const {
                path: e,
                queryString: i
            } = this.yy(t);
            let n = csString.prototype.split.call(e, "/");
            for (const t of s) n = this.Ay(n, t);
            return `${csArray.prototype.join.call(n,"/")}${i}`
        }
        Ay(t, s) {
            const e = [];
            let i = 0;
            for (let n = 0; n < t.length; n++) {
                const r = t[n],
                    o = s[i].key;
                if (this.Ey(o) && r.length > 0) {
                    const t = s[i].value;
                    csArray.prototype.push.call(e, t), i++, i === s.length && (i = 0)
                } else if (r !== o) {
                    for (let s = 0; s < i; s++) {
                        const r = n - i + s;
                        e[r] = t[r]
                    }
                    i = 0, csArray.prototype.push.call(e, r)
                } else csArray.prototype.push.call(e, r), i++, i === s.length && (i = 0)
            }
            for (let s = 0; s < i; s++) {
                const n = t.length - i + s;
                e[n] = t[n]
            }
            return e
        }
        Ey(t) {
            return j(t, ":")
        }
    }
    class ul {
        constructor(t, s) {
            this.qu = t, this.D = s
        }
        getEventTargetPath(t) {
            const s = we(t);
            return this.qu.getElementPath(s, {
                dynamicIdRegex: this.D.dynamicIdRegex,
                ...this.D.pathComputationRules
            })
        }
        getEventTargetPathAndTargetLink(t) {
            const s = we(t),
                {
                    path: e,
                    firstAnchorParent: i
                } = this.qu.getElementPathAndFirstAnchorParent(s, {
                    dynamicIdRegex: this.D.dynamicIdRegex,
                    ...this.D.pathComputationRules
                });
            return {
                path: e,
                targetLink: this._y(i) ? i.href : ""
            }
        }
        hasValidEventTarget(t) {
            const s = we(t);
            return this.qu.isValidElement(s)
        }
        getElementPath(t) {
            return this.qu.getElementPath(t, {
                dynamicIdRegex: this.D.dynamicIdRegex,
                ...this.D.pathComputationRules
            })
        }
        _y(t) {
            var s;
            return null !== t && t.hasAttribute("href") && !j(null !== (s = t.getAttribute("href")) && void 0 !== s ? s : "", "#")
        }
    }
    class ll {
        constructor(t) {
            this._l = t
        }
        transformEvent(t, s) {
            this.Sy(t, s.event);
            const e = this._l.getElementPath(t);
            return this.Ry(e, s.event), s
        }
        Sy(t, s) {
            if (function(t) {
                    return void 0 !== t.x && void 0 !== t.y
                }(s)) {
                const e = t.getBoundingClientRect();
                s.x = Math.round(e.left + s.x + Mi.windowOffsetX()), s.y = Math.round(e.top + s.y + Mi.windowOffsetY())
            }
        }
        Ry(t, s) {
            Zo(s) && (s.tgt = `${t}${Fu}${s.tgt}`),
                function(t) {
                    return void 0 !== t.tgtHM
                }(s) && (s.tgtHM = `${t}${Fu}${s.tgtHM}`),
                function(t) {
                    return void 0 !== t.tgtLk
                }(s) && (s.tgtLk = `${t}${Fu}${s.tgtLk}`)
        }
    }
    class dl {
        constructor(t) {
            this._l = t
        }
        transformEvent(t, s) {
            const e = this._l.getElementPath(t);
            return {
                iframePath: s.iframePath ? `${e}${Fu}${s.iframePath}` : e,
                commands: s.commands
            }
        }
    }
    class fl {
        constructor(t) {
            this._l = t
        }
        transformEvent(t, s) {
            if (0 === s.products.length) return s;
            const e = this._l.getElementPath(t),
                i = csArray.prototype.map.call(s.products, (t => ({ ...t,
                    targetPath: `${e}${Fu}${t.targetPath}`
                })));
            return { ...s,
                products: i
            }
        }
    }
    class pl {
        constructor() {
            this.Ty = {
                clientX: 2,
                clientY: 3
            }, this.Iy = {
                clientX: 1,
                clientY: 2
            }, this.by = [fe.POINTER_DOWN, fe.POINTER_MOVE, fe.POINTER_UP], this.Py = [fe.TOUCH_START, fe.TOUCH_MOVE, fe.TOUCH_END]
        }
        transformEvents(t, s) {
            if (!qi.isConnected(t)) return s.events = csArray.prototype.filter.call(s.events, (t => t.type !== fe.VISIBILITY_CHANGE)), 0 === s.events.length || (ns.warn(`IframeRecordingEventsTransformer received event ${Xt.RecordingEvent}\n        from disconnected iframe, content:${csJSON.stringify(s.events)}`), s.events = []), s;
            const e = be(t);
            let i = null;
            csArray.prototype.some.call(s.events, (t => this.Vy(t) || this.Cy(t))) && (i = t.getBoundingClientRect());
            for (const t of s.events) this.Vy(t) ? this.ky(i, t) : this.Cy(t) && this.Oy(i, t), t.context = t.context && t.context.length > 0 ? `${e}/${t.context}` : `${e}`;
            return s
        }
        Oy(t, s) {
            this.Ny(this.Iy, t, s)
        }
        ky(t, s) {
            this.Ny(this.Ty, t, s)
        }
        Ny(t, s, e) {
            e.args && (e.args[t.clientX] = Math.round(s.left + e.args[t.clientX]), e.args[t.clientY] = Math.round(s.top + e.args[t.clientY]))
        }
        Vy(t) {
            return -1 !== csArray.prototype.indexOf.call(this.by, t.type)
        }
        Cy(t) {
            return -1 !== csArray.prototype.indexOf.call(this.Py, t.type)
        }
    }
    class ml {
        constructor(t) {
            this.xy = t
        }
        start() {
            this.xy.onEvent((t => this.mn(t))), this.xy.start()
        }
        stop() {
            this.xy.stop()
        }
        mn(t) {
            const s = `Content Security Policy error. Violated directive: ${t.violatedDirective} - Source file: ${t.sourceFile}`;
            ns.warn(s)
        }
    }
    class vl {
        constructor() {
            this.oh = {
                boundElement: document,
                type: "securitypolicyviolation",
                listener: t => this.securityPolicyViolationListener(t)
            }
        }
        start() {
            ce(this.oh)
        }
        stop() {
            ae(this.oh)
        }
        onEvent(t) {
            this.Fn = t
        }
        $y(t) {
            if (!t) return !1;
            const s = t.disposition;
            return yt(t.sourceFile) && csArray.prototype.some.call(vl.Ly, (s => csString.prototype.indexOf.call(t.sourceFile, s) > 0)) && "report" !== s
        }
        securityPolicyViolationListener(t) {
            this.$y(t) && this.Fn({
                violatedDirective: t.violatedDirective,
                sourceFile: t.sourceFile
            })
        }
    }
    vl.Ly = ["contentsquare", "cdnssl.clicktale.net"], As([os("Event handler type: securitypolicyviolation")], vl.prototype, "securityPolicyViolationListener", null);
    class gl {
        init() {
            this.My = new ml(new vl), this.My.start()
        }
        onOptout() {
            this.My.stop()
        }
    }
    const {
        toString: yl
    } = Object.prototype;
    const wl = t => {
        return "symbol" == typeof t || "object" == typeof t && null != t && "[object Symbol]" === (null == (s = t) ? void 0 === s ? "[object Undefined]" : "[object Null]" : yl.call(s));
        var s
    };

    function El(t) {
        if ("string" == typeof t || wl(t)) return t;
        const s = `${t}`;
        return "number" == typeof t ? "0" === s && 1 / t == -1 / 0 ? "-0" : s : t instanceof Number && "0" === s && 1 / t.valueOf() == -1 / 0 ? "-0" : s
    }
    const Al = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
        _l = /^\w*$/;

    function Sl(t, s) {
        if ("function" != typeof t || null != s && "function" != typeof s) throw new TypeError("Expected a function");
        const e = function(...i) {
            const n = s ? s.apply(this, i) : i[0],
                {
                    cache: r
                } = e;
            if (r.has(n)) return r.get(n);
            const o = t.apply(this, i);
            return e.cache = r.set(n, o) || r, o
        };
        return e.cache = new(Sl.Cache || Map), e
    }
    Sl.Cache = Map;
    const Rl = ".".charCodeAt(0),
        Tl = /\\(\\)?/g,
        Il = csRegExp("[^.[\\]]+|\\[(?:([^\"'][^[]*)|([\"'])((?:(?!\\2)[^\\\\]|\\\\.)*?)\\2)\\]|(?=(?:\\.|\\[\\])(?:\\.|\\[\\]|$))", "g"),
        bl = function(t) {
            const s = Sl(t, (t => {
                const {
                    cache: e
                } = s;
                return 500 === e.size && e.clear(), t
            }));
            return s
        }((t => {
            const s = [];
            return csString.prototype.charCodeAt.call(t, 0) === Rl && csArray.prototype.push.call(s, ""), csString.prototype.replace.call(t, Il, ((t, e, i, n) => {
                let r = t;
                return i ? r = csString.prototype.replace.call(n, Tl, "$1") : e && (r = csString.prototype.trim.call(e)), csArray.prototype.push.call(s, r), t
            })), s
        }));

    function Pl(t, s) {
        return csArray.isArray(t) ? t : function(t, s) {
            return !csArray.isArray(t) && (!("number" != typeof t && "boolean" != typeof t && null != t && !wl(t)) || _l.test(t) || !Al.test(t) || null != s && t in Object(s))
        }(t, s) ? [t] : bl(t)
    }

    function Vl(t, s, e) {
        const i = null == t ? void 0 : function(t, s) {
            const e = Pl(s, t);
            let i = t,
                n = 0;
            const {
                length: r
            } = e;
            for (; null != i && n < r;) i = i[El(e[n])], n += 1;
            return n && n === r ? i : void 0
        }(t, s);
        return void 0 === i ? e : i
    }
    const Cl = /\b__p \+= '';/g,
        kl = /\b(__p \+=) '' \+/g,
        Ol = /(__e\(.*?\)|\b__t\)) \+\n'';/g,
        Nl = /['\n\r\u2028\u2029\\]/g,
        xl = /[&<>"']/g,
        $l = csRegExp(xl.source),
        Ll = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g,
        Ml = /($^)/,
        Dl = {
            "\\": "\\",
            "'": "'",
            "\n": "n",
            "\r": "r",
            "\u2028": "u2028",
            "\u2029": "u2029"
        },
        Ul = /[()=,{}[\]/\s]/,
        ql = /<%=([\s\S]+?)%>/g,
        {
            hasOwnProperty: Fl
        } = Object.prototype;

    function Hl(t) {
        return `\\${Dl[t]}`
    }
    const Bl = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        },
        jl = {
            escape: /<%-([\s\S]+?)%>/g,
            evaluate: /<%([\s\S]+?)%>/g,
            interpolate: ql,
            variable: "",
            imports: {
                _: {
                    template: zl,
                    escape: t => t && $l.test(t) ? csString.prototype.replace.call(t, xl, (t => Bl[t])) : null != t ? t : ""
                }
            }
        };

    function zl(t, s) {
        const e = { ...jl,
                ...s
            },
            i = Object.keys(e.imports || {}),
            n = csArray.prototype.map.call(i, (t => null == e ? void 0 : e.imports[t]));
        let r, o, h = 0;
        const c = e.interpolate || Ml;
        let a = "__p += '";
        const u = csRegExp(`${(e.escape||Ml).source}|${c.source}|${(c===ql?Ll:Ml).source}|${(e.evaluate||Ml).source}|$`, "g"),
            l = `//# sourceURL=${Fl.call(e,"sourceURL")?csString.prototype.replace.call(`${e.sourceURL}`,/\s/g," "):void 0}\n`;
        null == t || csString.prototype.replace.call(t, u, ((s, e, i, n, c, u) => {
            const l = i || n;
            return a += csString.prototype.replace.call(csString.prototype.slice.call(t, h, u), Nl, Hl), e && (r = !0, a += `' +\n__e(${e}) +\n'`), c && (o = !0, a += `';\n${c};\n__p += '`), l && (a += `' +\n((__t = (${l})) == null ? '' : __t) +\n'`), h = u + s.length, s
        })), a += "';\n";
        const d = Fl.call(e, "variable") && e.variable;
        if (d) {
            if (Ul.test(d)) throw new Error("Invalid `variable` option passed into `_.template`")
        } else a = `with (obj) {\n${a}\n}\n`;
        let f;
        a = csString.prototype.replace.call(csString.prototype.replace.call(o ? csString.prototype.replace.call(a, Cl, "") : a, kl, "$1"), Ol, "$1;"), a = `function(${d||"obj"}) {\n${d?"":"obj || (obj = {});\n"}var __t, __p = ''${r?", __e = _.escape":""}${o?", __j = Array.prototype.join;\nfunction print() { __p += __j.call(arguments, '') }\n":";\n"}${a}return __p\n}`;
        try {
            f = Function(...i, `${l}return ${a}`)(...n)
        } catch (t) {
            f = t
        }
        if (f.source = a, f instanceof Error) throw f;
        return f
    }
    const Gl = /^(\s*("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')\s*,?)+$/,
        Zl = /^document\.querySelector\(("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')\)\.textContent$/;

    function Wl(t) {
        if (!Gl.test(t)) throw new Error("whitelisted function is wrongly used")
    }
    const Ql = {
        "window.location.hash.replace(": (t, s) => (Wl(csString.prototype.substring.call(t, 29, t.length - 1)), zl(`\${${t}}`)(s)),
        "window.sessionStorage.getItem(": (t, s) => (Wl(csString.prototype.substring.call(t, 30, t.length - 1)), zl(`\${${t}}`)(s)),
        "document.querySelector(": (t, s) => {
            if (Zl.test(t)) return zl(`\${${t}}`)(s)
        },
        "new Date().getTime()": (t, s) => (new csDate).getTime().toString()
    };
    const Jl = /\$\{(.+?)\}/g,
        Kl = t => (s, e, i) => {
            let n = "";
            return csArray.prototype.forEach.call(csString.prototype.split.call(e, "+"), (s => {
                const e = csString.prototype.trim.call(s);
                let i = Vl(t, e);
                if (void 0 === i)
                    if (Nt(r = e, "'") && xt(r, "'")) i = csString.prototype.substring.call(e, 1, e.length - 1);
                    else {
                        const s = function(t) {
                            const s = Ds(Object.keys(Ql), (s => Nt(t, s)));
                            if (s) return Ql[s]
                        }(e);
                        if (s && (i = s(e, t)), void 0 === i) throw new Error("undefined not allowed")
                    }
                var r;
                n += i
            })), n
        };

    function Yl(t, s) {
        try {
            return csString.prototype.replace.call(t, Jl, Kl(s))
        } catch {
            return null
        }
    }

    function Xl(t, s) {
        const e = {};
        for (const i of Object.keys(t)) {
            const n = t[i];
            if (yt(n)) {
                const t = Yl(n, s);
                if (null === t) return null;
                e[i] = t
            } else e[i] = n
        }
        return e
    }

    function td(t, s) {
        const e = csArray.prototype.join.call(csArray.prototype.filter.call(csArray.prototype.map.call(csString.prototype.split.call(t, ","), (t => Yl(t, s))), (t => null !== t && Ne(t))), ",");
        return Ne(e) ? e : null
    }

    function sd(t, s) {
        try {
            const i = /^values\(([a-zA-Z0-9_$[\].]+)\)\[\?([a-zA-Z0-9_$]+)\]$/.exec(t);
            if (!i) return null;
            const n = i[1],
                r = i[2],
                o = Vl(s, (e = n, csArray.isArray(e) ? csArray.prototype.map.call(e, El) : wl(e) ? [e] : csArray.from(bl(e))));
            if ("object" != typeof o || null === o) return null;
            const h = [];
            return csArray.prototype.forEach.call(Object.keys(o), (t => {
                const s = o[t];
                "object" == typeof s && null !== s && !csArray.isArray(s) && r in s && csArray.prototype.push.call(h, s)
            })), h
        } catch {
            return null
        }
        var e
    }

    function ed(t, s) {
        const e = csString.prototype.split.call(t, "|");
        if (e.length > 2) return null;
        const i = sd(csString.prototype.trim.call(e[0]), s);
        return 2 === e.length ? null === i ? null : function(t, s) {
            const e = /^\[([0-9]+):([0-9+])\]$/.exec(t);
            if (!e) return null;
            const i = parseInt(e[1], 10),
                n = parseInt(e[2], 10);
            return n <= i || n > s.length ? null : csArray.prototype.slice.call(s, i, n)
        }(csString.prototype.trim.call(e[1]), i) : i
    }
    var id, nd;

    function rd(t, s) {
        return function(t, s) {
            switch (t) {
                case nd.EXIST:
                case nd.NOT_EXIST:
                    return function(t, s) {
                        const [e] = s;
                        if (!Ne(e)) return !1;
                        switch (t) {
                            case nd.EXIST:
                                return null !== window.csquerySelector[document.nodeType].call(document, e);
                            case nd.NOT_EXIST:
                                return null === window.csquerySelector[document.nodeType].call(document, e);
                            default:
                                return !1
                        }
                    }(t, s);
                default:
                    return function(t, s) {
                        const [e, i] = s, n = t in id;
                        if (!(n || yt(e) && yt(i))) return !1;
                        switch (t) {
                            case id.AND:
                                return !!csArray.prototype.reduce.call(s, ((t, s) => t && s));
                            case id.OR:
                                return !!csArray.prototype.reduce.call(s, ((t, s) => t || s));
                            case nd.STARTS_WITH:
                                return Nt(e, i);
                            case nd.EQUALS:
                                return e === i;
                            case nd.NOT_EQUALS:
                                return e !== i;
                            case nd.CONTAINS:
                                return csString.prototype.indexOf.call(e, i) > -1;
                            case nd.MATCHES:
                                {
                                    const t = function(t) {
                                        const s = /^\/(.*)\/([gimy]*)$/.exec(t);
                                        let e = null;
                                        if (s) {
                                            const [, t, i] = s;
                                            try {
                                                e = new csRegExp(t, i)
                                            } catch (t) {
                                                e = null
                                            }
                                        }
                                        return e
                                    }(i);
                                    return null !== t && t.test(e)
                                }
                            default:
                                return !1
                        }
                    }(t, s)
            }
        }(t.operator, function(t, s) {
            return csArray.prototype.map.call(t, (t => function(t) {
                return !!(t && t.operator && t.args)
            }(t) ? rd(t, s) : yt(t) ? Yl(t, s) : t))
        }(t.args, s))
    }

    function od(t) {
        switch (t) {
            case "no decoding":
            default:
                return null;
            case "decode once":
                return {
                    decodeURI: !0
                };
            case "decode multiple times":
                return {
                    decodeURIDeep: !0
                }
        }
    }

    function hd(t) {
        return "on next pageview only" === (null == t ? void 0 : t[0]) ? {
            lifespan: "onNextPageviewOnly"
        } : null
    }! function(t) {
        t.AND = "AND", t.OR = "OR"
    }(id || (id = {})),
    function(t) {
        t.STARTS_WITH = "startsWith", t.EQUALS = "equals", t.NOT_EQUALS = "notEquals", t.CONTAINS = "contains", t.MATCHES = "matches", t.EXIST = "exist", t.NOT_EXIST = "notExist"
    }(nd || (nd = {}));
    class cd {
        constructor(t, s) {
            this.commandsService = t, this.args = s
        }
    }
    class ad extends cd {}
    class ud extends cd {
        execute(t) {
            if (t.path) {
                const s = [t.path],
                    e = { ...od(t.decodeURI),
                        ...hd(t.lifespan)
                    };
                Object.keys(e).length && s.push(e), this.Dy(s)
            } else this.Dy([])
        }
        Dy(t) {
            this.commandsService.applyFromImplementation(gc[0], t, "ArtificialPageviewTemplate")
        }
    }
    class ld extends ad {
        execute(t, s) {
            const e = Yl(t.message, s);
            if (null === e) return;
            const i = {};
            for (const e of t.attributes) {
                const t = Yl(e.value, s);
                null !== t && (i[e.key] = t)
            }
            this.commandsService.applyFromImplementation(la[0], [e, i], "CustomErrorTemplate")
        }
    }
    class dd extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(nl[0], [t.index, t.name, t.value, t.scope[0]], "CustomVariableTemplate")
        }
    }
    class fd extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(lo[0], [t.selector], "DataCsEncryptTemplate")
        }
    }
    class pd extends cd {
        execute(t) {
            if (!Ne(t.selector)) return;
            const s = window.csquerySelector[document.nodeType].call(document, t.selector);
            s && s.setAttribute("data-cs-override-id", t.value)
        }
    }
    class md extends ad {
        execute(t, s) {
            const e = Xl(t, s);
            if (null !== e) this.Dy(e);
            else {
                this.Uy(t, s)()
            }
        }
        Uy(t, s) {
            return () => {
                let e = 0,
                    i = window.csSetInterval((() => {
                        e += 1;
                        const n = Xl(t, s);
                        if (null !== n) return window.csClearInterval(i), i = void 0, e = 0, void this.Dy(n);
                        e >= 20 && (window.csClearInterval(i), i = void 0, e = 0)
                    }), 100)
            }
        }
        Dy(t) {
            let s = t.value;
            if ("Integer" === t.type) {
                const e = Number.parseInt(t.value, 10);
                Number.isNaN(e) || (s = e)
            }
            this.commandsService.applyFromImplementation(No[0], [{
                key: t.key,
                value: s
            }], "DynamicVariableTemplate")
        }
    }
    class vd extends cd {
        execute(t) {
            this.qy({
                id: t.transactionId,
                revenue: t.revenue,
                currency: t.currency
            }), this.Fy({
                id: t.transactionId,
                name: t.name,
                sku: t.sku,
                category: t.category,
                price: t.price,
                quantity: t.quantity
            }), this.Hy()
        }
        qy(t) {
            this.commandsService.applyFromImplementation(qo[0], [t], "EcTransactionAllTemplate")
        }
        Fy(t) {
            this.commandsService.applyFromImplementation(Fo[0], [t], "EcTransactionAllTemplate")
        }
        Hy() {
            this.commandsService.applyFromImplementation(Ho[0], [], "EcTransactionAllTemplate")
        }
    }
    class gd extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(qo[0], [t], "EcTransactionCreateTemplate")
        }
    }
    class yd extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(Fo[0], [t], "EcTransactionItemsAddTemplate")
        }
    }
    class wd extends cd {
        execute() {
            this.commandsService.applyFromImplementation(Ho[0], [], "EcTransactionSendTemplate")
        }
    }
    class Ed extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(uo[0], [t.selector], "ElementUnmaskingTemplate")
        }
    }
    class Ad extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(Bc[0], [`@ETP@${t.eventName}`], "EventTriggerRecordingPageTemplate")
        }
    }
    class _d extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(Bc[0], [`@ETS@${t.eventName}`], "EventTriggerRecordingSessionTemplate")
        }
    }
    class Sd extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(Hc[0], [t.eventName], "PageEventTemplate")
        }
    }
    class Rd extends ad {
        execute(t, s) {
            const e = {
                PIISelectors: [...csArray.prototype.filter.call(csArray.prototype.map.call(t.cssSelectors, (t => td(t, s))), (t => !!t))],
                Attributes: [...csArray.prototype.filter.call(csArray.prototype.map.call(t.attributes, (t => ({
                    attrName: Yl(t.attrName, s),
                    selector: td(t.selector, s)
                }))), (t => !!t.attrName && !!t.selector))]
            };
            this.commandsService.applyFromImplementation($a[0], [e], "PIIMaskingTemplate")
        }
    }
    class Td extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(Bc[0], [`${t.eventName}`], "RecordingEventTriggerTemplate")
        }
    }
    class Id extends cd {
        execute(t) {
            const s = [t.path],
                e = { ...od(t.decodeURI),
                    ...hd(t.lifespan)
                };
            Object.keys(e).length && s.push(e), this.commandsService.applyFromImplementation(yc[0], s, "SetPathTemplate")
        }
    }
    class bd extends cd {
        execute(t) {
            const s = [t.query],
                e = { ...od(t.decodeURI),
                    ...hd(t.lifespan)
                };
            Object.keys(e).length && s.push(e), this.commandsService.applyFromImplementation(wc[0], s, "SetQueryTemplate")
        }
    }
    class Pd extends cd {
        execute() {
            this.commandsService.applyFromImplementation(po[0], [], "SrmOnlineAssetsTemplate")
        }
    }
    class Vd extends cd {
        execute(t) {
            if (!Ne(t.selector)) return;
            const s = window.csquerySelector[document.nodeType].call(document, t.selector);
            s && this.commandsService.applyFromImplementation(hc[0], [t.status, s], "SubmitTemplate")
        }
    }
    class Cd {
        onEvent(t) {
            this.onEventCallback = t
        }
        constructor(t, s, e) {
            this.commandsService = t, this.args = s, this.condition = e, this.isStarted = !1, this.By = !1
        }
        start() {
            this.By || (this.onInit(), this.By = !0), this.isStarted || (this.onStart(), this.isStarted = !0)
        }
        stop() {
            this.isStarted && (this.onStop(), this.isStarted = !1)
        }
    }
    As([os()], Cd.prototype, "start", null), As([os()], Cd.prototype, "stop", null);
    class kd extends Cd {
        constructor() {
            super(...arguments), this.jy = !0
        }
        onInit() {
            Ne(this.args.selector) ? (this.zy = !this.args.frequency || "once per pageview" === this.args.frequency, this.Ye = new Wn(((t, s) => this.Is(t, s)))) : this.jy = !1
        }
        onStart() {
            this.jy && this.Ye.observe(this.args.selector)
        }
        onStop() {
            this.jy && (this.Ye.processPendingMutations(), this.Ye.disconnect())
        }
        Is(t, s) {
            "added" === s && (this.zy ? (this.stop(), this.onEventCallback({
                element: t[0]
            })) : new Set(t).forEach((t => this.onEventCallback({
                element: t
            }))))
        }
    }
    class Od extends Cd {
        constructor() {
            super(...arguments), this.jy = !0, this.Gy = !1
        }
        onInit() {
            Ne(this.args.selector) ? this.Ye = new Wn(((t, s) => {
                this.Is(t, s)
            })) : this.jy = !1
        }
        onStart() {
            this.jy && (this.Ye.observe(this.args.selector), this.Gy = !0)
        }
        onStop() {
            this.jy && (this.Ye.processPendingMutations(), this.Ye.disconnect())
        }
        Is(t, s) {
            this.Gy ? "added" === s && new Set(t).forEach((t => this.onEventCallback({
                element: t
            }))) : this.onEventCallback({
                element: t[0]
            })
        }
    }
    class Nd extends Cd {
        constructor() {
            super(...arguments), this.jy = !0
        }
        onInit() {
            Ne(this.args.selector) ? (this.ih = new Wn((t => this.Zy(t))), this.As = new nn((t => this.Wy(t)))) : this.jy = !1
        }
        onStart() {
            this.jy && (this.Qy = csSymbol("MatchingElement"), this.ih.observe(this.args.selector), this.As.observe())
        }
        onStop() {
            this.jy && (this.ih.processPendingMutations(), this.ih.disconnect(), this.As.disconnect())
        }
        Zy(t) {
            new Set(t).forEach((t => this.Jy(t)))
        }
        Wy(t) {
            const s = Ls(t, (t => t.removedNodes)),
                e = [];
            for (const t of s) csArray.prototype.push.call(e, ...this.Ky(t));
            new Set(e).forEach((t => this.onEventCallback({
                element: t
            })))
        }
        Jy(t) {
            t[this.Qy] = !0
        }
        Ky(t) {
            const s = [];
            return Qs(t, NodeFilter.SHOW_ELEMENT).visitAll((t => {
                t[this.Qy] && (qi.isConnected(t) && Ce.call(t, this.args.selector) || delete t[this.Qy], csArray.prototype.push.call(s, t))
            })), s
        }
    }
    var xd;
    class $d {
        static nc(t) {
            this.callbacks.has(t) || (this.callbacks.add(t), 1 === this.callbacks.size && ce(this.eventHandler, !1))
        }
        static rc(t) {
            this.callbacks.delete(t), 0 === this.callbacks.size && ae(this.eventHandler, !1)
        }
        constructor(t) {
            this.Is = t
        }
        observe() {
            xd.nc(this.Is)
        }
        disconnect() {
            xd.rc(this.Is)
        }
    }
    xd = $d, $d.callbacks = new Set, $d.readyStateChangeListener = t => xd.callbacks.forEach((s => s(t))), $d.eventHandler = {
        boundElement: document,
        type: "readystatechange",
        listener: xd.readyStateChangeListener
    };
    class Ld extends Cd {
        onInit() {
            try {
                this.we = this.args.state.toLowerCase()
            } catch {
                this.we = "any", ns.error("Implementations: PageStateTrigger has wrong argument.")
            }
            this.Ye = new $d((() => {
                this.Yy(this.we, document.readyState) && (this.onEventCallback(), this.Ye.disconnect())
            }))
        }
        onStart() {
            this.Yy(this.we, document.readyState) ? this.onEventCallback() : this.Ye.observe()
        }
        onStop() {
            this.Ye.disconnect()
        }
        Yy(t, s) {
            const e = Ld.Xy[s];
            return Ld.Xy[t] <= e
        }
    }
    Ld.Xy = {
        complete: 3,
        interactive: 2,
        loading: 1,
        any: 0
    };
    class Md extends Cd {
        tw() {
            this.isStarted && this.onEventCallback()
        }
        onInit() {
            this.commandsService.applyFromImplementation(To[0], [() => this.tw()], "AfterPageViewTrigger")
        }
        onStart() {}
        onStop() {}
    }
    class Dd extends Cd {
        constructor() {
            super(...arguments), this.jy = !0, this.Tc = !0, this.ew = {
                boundElement: document,
                type: "click",
                listener: t => this.clickListener(t)
            }
        }
        clickListener({
            target: t
        }) {
            At(t) && St(t) && Ce.call(t, this.args.selector) && this.onEventCallback({
                element: t
            })
        }
        onInit() {
            Ne(this.args.selector) || (this.jy = !1)
        }
        onStart() {
            this.jy && ce(this.ew, this.Tc)
        }
        onStop() {
            this.jy && ae(this.ew, this.Tc)
        }
    }
    As([os("clickListener")], Dd.prototype, "clickListener", null);
    class Ud {
        static iw() {
            var t, s, e, i;
            if ("history" in window) {
                const e = Object.getOwnPropertyDescriptors(history);
                if ((null === (t = e.pushState) || void 0 === t ? void 0 : t.writable) && (null === (s = e.replaceState) || void 0 === s ? void 0 : s.writable)) return history
            }
            if (History.prototype) {
                const t = Object.getOwnPropertyDescriptors(History.prototype);
                if ((null === (e = t.pushState) || void 0 === e ? void 0 : e.writable) && (null === (i = t.replaceState) || void 0 === i ? void 0 : i.writable)) return History.prototype
            }
            rs.warn("Unable to override pushState, replaceState", !0, "HistoryChangeObserver")
        }
        static xp() {
            const t = Ud.iw();
            null === Ud.nw && _t(null == t ? void 0 : t.pushState) && (Ud.nw = ie({
                target: t,
                methodName: "pushState",
                hook: ({
                    args: t
                }) => {
                    Ud.rw("pushstate", t)
                }
            })), null === Ud.ow && _t(null == t ? void 0 : t.replaceState) && (Ud.ow = ie({
                target: t,
                methodName: "replaceState",
                hook: ({
                    args: t
                }) => {
                    Ud.rw("replacestate", t)
                }
            }))
        }
        static ys(t) {
            var s, e;
            Ud.ws.add(t), 1 === Ud.ws.size && (null !== Ud.nw && null !== Ud.ow || Ud.xp(), null === (s = Ud.nw) || void 0 === s || s.activate(), null === (e = Ud.ow) || void 0 === e || e.activate(), ce(Ud.hw), ce(Ud.aw))
        }
        static Ts(t) {
            var s, e;
            Ud.ws.delete(t), 0 === Ud.ws.size && (null === (s = Ud.nw) || void 0 === s || s.deactivate(), null === (e = Ud.ow) || void 0 === e || e.deactivate(), ae(Ud.hw), ae(Ud.aw))
        }
        static rw(t, s) {
            const e = {
                type: t,
                state: s[0]
            };
            yt(s[2]) && (e.url = s[2]), Ud.Ah(e)
        }
        static popstateListener(t) {
            Ud.Ah({
                type: "popstate",
                state: t.state
            })
        }
        static hashchangeListener(t) {
            Ud.Ah({
                type: "hashchange",
                state: null,
                url: t.newURL
            })
        }
        static Ah(t) {
            Ud.ws.forEach((s => {
                s(t)
            }))
        }
        constructor(t) {
            this.Is = t
        }
        observe() {
            Ud.ys(this.Is)
        }
        disconnect() {
            Ud.Ts(this.Is)
        }
    }
    Ud.nw = null, Ud.ow = null, Ud.hw = {
        boundElement: window,
        type: "popstate",
        listener: t => Ud.popstateListener(t)
    }, Ud.aw = {
        boundElement: window,
        type: "hashchange",
        listener: t => Ud.hashchangeListener(t)
    }, Ud.ws = new Set, Gs([os("popstateListener")], Ud, "popstateListener", null), Gs([os("hashchangeListener")], Ud, "hashchangeListener", null);
    class qd extends Cd {
        onInit() {
            "yes" === this.args.useDebounce ? this.ie = so((() => {
                this.onEventCallback()
            }), this.args.window) : this.ie = this.onEventCallback, this.Ye = new Ud((t => this.uw(t)))
        }
        lw() {
            return window.location.href
        }
        uw(t) {
            const s = "replacestate" === t.type && -1 === this.args.listeners.indexOf("replaceState"),
                e = "hashchange" === t.type && -1 === this.args.listeners.indexOf("hashchange");
            if (s || e) return;
            const i = this.lw();
            this.fw !== i && (this.fw = i, this.ie())
        }
        onStart() {
            this.fw = this.lw(), this.Ye.observe()
        }
        onStop() {
            this.Ye.disconnect()
        }
    }
    class Fd extends Cd {
        constructor() {
            super(...arguments), this.jy = !0, this.Tc = !0, this.ew = {
                boundElement: document,
                type: "submit",
                listener: t => this.submitListener(t)
            }
        }
        submitListener({
            target: t
        }) {
            At(t) && St(t) && Ce.call(t, this.args.selector) && this.onEventCallback({
                element: t
            })
        }
        onInit() {
            Ne(this.args.selector) || (this.jy = !1)
        }
        onStart() {
            this.jy && ce(this.ew, this.Tc)
        }
        onStop() {
            this.jy && ae(this.ew, this.Tc)
        }
    }
    As([os("submitListener")], Fd.prototype, "submitListener", null);
    class Hd extends Cd {
        constructor() {
            super(...arguments), this.jy = !0, this.pw = {
                boundElement: document,
                type: "mouseover",
                listener: t => this.mouseoverListener(t)
            }, this.mw = {
                boundElement: document,
                type: "mouseleave",
                listener: t => this.mouseleaveListener(t)
            }
        }
        onInit() {
            Ne(this.args.selector) || (this.jy = !1)
        }
        mouseleaveListener({
            target: t
        }) {
            At(t) && St(t) && t[this.gw] && delete t[this.gw]
        }
        mouseoverListener({
            target: t
        }) {
            if (At(t) && St(t)) {
                const s = xe(t, this.args.selector);
                null === s || s[this.gw] || (s[this.gw] = !0, this.onEventCallback({
                    element: s
                }))
            }
        }
        onStart() {
            this.jy && (this.gw = csSymbol("Hovered"), ce(this.mw, !0), ce(this.pw, !0))
        }
        onStop() {
            this.jy && (ae(this.pw), ae(this.mw))
        }
    }
    As([os("mouseleaveListener")], Hd.prototype, "mouseleaveListener", null), As([os("mouseoverListener")], Hd.prototype, "mouseoverListener", null);
    class Bd extends Cd {
        constructor() {
            super(...arguments), this.ew = {
                boundElement: window,
                type: "hashchange",
                listener: t => this.hashChangedListener(t)
            }
        }
        hashChangedListener(t) {
            t.newURL && t.newURL === t.oldURL || this.onEventCallback()
        }
        onInit() {}
        onStart() {
            ce(this.ew)
        }
        onStop() {
            ae(this.ew)
        }
    }
    As([os("hashChangedListener")], Bd.prototype, "hashChangedListener", null);
    class jd extends Cd {
        constructor() {
            super(...arguments), this.yw = !0
        }
        onInit() {
            Ne(this.args.selector) && ir.isSupported() ? (this.ko = new ir({
                delay: 0,
                trackOnce: !0,
                reobserve: !0
            }), this.ih = new Wn((t => this.Ew(t)), {
                closest: !0
            })) : this.yw = !1
        }
        Ew(t) {
            for (const s of t) Qs(s, NodeFilter.SHOW_ELEMENT).visitAll((t => {
                this.ko.observe(t)
            }))
        }
        Aw(t, s) {
            if (this.isStarted && s === nr.VisibleInViewPort) {
                const s = xe(t, this.args.selector);
                s && (this.onEventCallback({
                    element: s
                }), this.stop(), this.yw = !1)
            }
        }
        onStart() {
            this.yw && (this.ko.start(((t, s) => this.Aw(t, s))), this.ih.observe(this.args.selector))
        }
        onStop() {
            this.yw && (this.ko.stop(), this.ih.disconnect())
        }
    }
    class zd extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(ca[0], [t.url], "ApiErrorsMaskUrlTemplate")
        }
    }
    class Gd extends cd {
        execute(t) {
            this.commandsService.applyFromImplementation(Ua[0], [t.maskingPattern], "NetworkRequestMaskUrlTemplate")
        }
    }
    class Zd {
        constructor(t) {
            this.Ia = t, this._w = {
                ApiErrorsMaskUrl: zd,
                NetworkRequestMaskUrls: Gd,
                ArtificialPageview: ud,
                CustomError: ld,
                CustomVariable: dd,
                DataCsEncrypt: fd,
                DataCsOverride: pd,
                DynamicVariable: md,
                EcTransactionAll: vd,
                EcTransactionCreate: gd,
                EcTransactionItemsAdd: yd,
                EcTransactionSend: wd,
                ElementUnmasking: Ed,
                EventTriggerRecordingPage: Ad,
                EventTriggerRecordingSession: _d,
                PageEvent: Sd,
                PiiMasking: Rd,
                RecordingEventTrigger: Td,
                SetPath: Id,
                SetQuery: bd,
                SrmOnlineAssets: Pd,
                Submit: Vd
            }, this.Sw = {
                AfterPageView: Md,
                ElementAdded: kd,
                ElementExist: Od,
                ElementRemoved: Nd,
                ElementVisibility: jd,
                ElementClick: Dd,
                FormSubmit: Fd,
                HashChange: Bd,
                HistoryChange: qd,
                Mouseover: Hd,
                PageState: Ld
            }
        }
        Rw(t) {
            const s = this._w[t.name];
            return s ? new s(this.Ia, t.args) : (ns.error(`Implementations: template ${t.name} does not exist`), null)
        }
        Tw(t) {
            const s = this.Sw[t.name];
            return s ? new s(this.Ia, t.args, t.condition) : (ns.error(`Implementations: trigger ${t.name} does not exist`), null)
        }
        parse(t) {
            const s = [];
            for (const {
                    triggers: e,
                    template: i
                } of t) {
                const t = this.Rw(i);
                if (t)
                    for (const i of e) {
                        const e = this.Tw(i);
                        e && csArray.prototype.push.call(s, {
                            trigger: e,
                            template: t
                        })
                    }
            }
            return s
        }
    }
    class Wd {
        constructor(t, s, e) {
            this.Iw = t, this.cr = e, this.Br = {
                window,
                document,
                location,
                cookies: {}
            }, this.Sw = new Set, this.bw = new Zd(s)
        }
        init() {
            Object.defineProperty(this.Br, "cookies", {
                get: () => this.Pw()
            });
            const t = this.bw.parse(this.Iw);
            for (const {
                    trigger: s,
                    template: e
                } of t) this.Sw.add(s), s.onEvent((t => {
                this.onTriggerEvent(t, e)
            }))
        }
        start(t = !1) {
            this.Sw.forEach((s => {
                if (s.condition) {
                    if (!rd(s.condition, this.Br)) return
                }
                t ? this.cr.schedule((() => {
                    s.start()
                })) : s.start()
            }))
        }
        stop() {
            this.Sw.forEach((t => {
                t.stop()
            }))
        }
        Vw() {
            this.stop(), this.start()
        }
        onTriggerEvent(t, s) {
            const e = { ...this.Br,
                    ...t
                },
                i = [];
            if ("iterable" in s.args && yt(s.args.iterable) && s.args.iterable.length > 0) {
                const t = ed(s.args.iterable, e);
                if (At(t)) {
                    const s = csArray.prototype.map.call(t, (t => ({ ...e,
                        $: t
                    })));
                    csArray.prototype.push.call(i, ...s)
                }
            } else csArray.prototype.push.call(i, e);
            if (s instanceof ad)
                for (const t of i) s.execute(s.args, t);
            else
                for (const t of i) {
                    const e = Xl(s.args, t);
                    e && (s.execute(e), s instanceof ud && this.Vw())
                }
        }
        Pw() {
            let t;
            try {
                t = document.cookie
            } catch (s) {
                t = ""
            }
            return csArray.prototype.reduce.call(csString.prototype.split.call(t, "; "), ((t, s) => {
                const [e, i] = csString.prototype.split.call(s, "=");
                return void 0 !== i && (t[e] = i), t
            }), {})
        }
    }
    As([Es("implementationsService.start")], Wd.prototype, "start", null), As([os()], Wd.prototype, "onTriggerEvent", null);
    class Qd {
        constructor(t, s, e) {
            this.Cw = new Wd(t, s, e)
        }
        init() {
            this.Cw.init()
        }
        onInitTracking() {
            this.Cw.start(!0)
        }
        onOptout() {
            this.Cw.stop()
        }
    }
    class Jd extends X {
        constructor(t, s, e) {
            super(t, s), this.kw = null, this.Ow = (null == e ? void 0 : e.type) || "json", this.Nw = null == e ? void 0 : e.cacheMinutes, this.us = null == e ? void 0 : e.timeout
        }
        onLoad(t) {
            this.rs = t
        }
        onError(t) {
            this.hs = t
        }
        onTimeout(t, s) {
            this.cs = t, this.us = s
        }
        send() {
            csArray.prototype.forEach.call(this.beforeRequestCallbacks, (t => t()));
            const t = this.retrieveParameters();
            this.P(t);
            const s = Y.toQuery(t),
                e = `${this.domainUri}${this.path?`/${this.path}`:""}?${s}`;
            this.ad(e, this.Ow)
        }
        abort() {
            this.kw && (this.kw.abort(), this.kw = null)
        }
        isInProgress() {
            return null !== this.kw
        }
        ad(t, s) {
            var e;
            const i = new XMLHttpRequest;
            i.open("GET", t, !0), i.responseType = s, i.onerror = () => this.hs(i), i.ontimeout = () => this.cs(i), i.onload = () => {
                i.status >= 200 && i.status < 400 ? (this.rs(this.xw(i, s) ? i.response : i.responseText), csArray.prototype.forEach.call(this.afterRequestCallbacks, (t => t()))) : this.hs(i)
            }, i.onloadend = () => {
                this.kw = null
            }, i.timeout = null !== (e = this.us) && void 0 !== e ? e : 5e3, this.kw = i, i.send()
        }
        xw(t, s) {
            const e = t.getResponseHeader("Content-Type");
            return null === e ? "json" === s : csString.prototype.indexOf.call(csString.prototype.toLowerCase.call(e), "json") > 0
        }
        P(t) {
            let s;
            s = this.Nw ? `${(t=>{const s=60*t*1e3;return`${Math.floor(csDate.now()/s)}`})(this.Nw)}` : csString.prototype.slice.call(`${Math.random()}`, 2, 8), t.r = s
        }
    }
    class Kd {
        constructor(t) {
            this.configuration = t
        }
    }
    class Yd extends Kd {
        constructor(t, s, e) {
            super(t), this.configuration = t, this.$w = s, this.Uc = e, this.Lw = He.RECORDING_GLOBAL_SAMPLING
        }
        refreshQuota() {
            this.Mw = void 0, this.Dw()
        }
        onQuotaReady(t) {
            this.Uw = t
        }
        init() {
            this.qw()
        }
        sanitizeSessionCollectState(t) {
            return t
        }
        canCollect(t) {
            return null !== t && t.collectState !== He.QUOTA_REACHED
        }
        computeInitialCollectState(t) {
            return this.Mw ? (this.Uc.emitCollectStateChange(this.Mw, Be.ETR_OFF), this.Mw) : (ns.warn("Quota file error computeInitialCollectState() called before quota answered"), He.QUOTA_REACHED)
        }
        getEligibleCollectState(t) {
            return t.collectState === He.QUOTA_REACHED ? He.QUOTA_REACHED : !oa.isRecordingSupported() && this.isReplayRecorded(t) ? He.ANALYTICS_ONLY : t.collectState === He.RECORDING_RULES_TARGETING ? He.RECORDING_RULES_TARGETING : t.collectState === He.RECORDING_GLOBAL_SAMPLING ? He.RECORDING_GLOBAL_SAMPLING : He.ANALYTICS_ONLY
        }
        abortQuotaServiceRequest() {}
        isReplayRecorded(t) {
            return t.collectState === He.RECORDING_GLOBAL_SAMPLING || t.collectState === He.RECORDING_RULES_TARGETING
        }
        getInitialCollectState() {
            return this.Mw || He.QUOTA_REACHED
        }
        setVisitorService(t) {}
        computeInitialCollectStateFromRecordingConsentGranted(t) {
            return He.ANALYTICS_ONLY
        }
        Fw(t) {
            this.Mw = t, this.Uw && this.Uw(t)
        }
        qw() {
            this.$w.onError((t => this.quotaServiceErrorHandler(`HTTP:${t.status} - fetching quota file for pid: ${this.configuration.projectId}`))), this.$w.onTimeout((() => this.quotaServiceErrorHandler("timeout"))), this.$w.onLoad((t => this.quotaFileHandler(t)))
        }
        Dw() {
            this.$w.isInProgress() || this.$w.send()
        }
        quotaFileHandler(t) {
            var s;
            (null === (s = null == t ? void 0 : t.quotas) || void 0 === s ? void 0 : s.length) ? this.Hw(t): this.quotaServiceErrorHandler("Quota types missing from config file")
        }
        quotaServiceErrorHandler(t) {
            const s = `Quota error - ${t}`;
            ns.warn(s), this.Fw(this.Lw)
        }
        Hw(t) {
            let s = !1,
                e = !1;
            for (const i of t.quotas) "ANALYTICS" === i.quotaType && i.value ? s = !0 : "RECORDING" === i.quotaType && i.value && G.boolean(Math.round(100 * i.value)) && (e = !0);
            !s && e ? this.quotaServiceErrorHandler(`Quota types impossible: replay without analytics - ${csJSON.stringify(t)}`) : s && e ? oa.isRecordingSupported() ? this.Fw(He.RECORDING_GLOBAL_SAMPLING) : this.Fw(He.ANALYTICS_ONLY) : s && !e ? this.Fw(He.ANALYTICS_ONLY) : this.Fw(He.QUOTA_REACHED)
        }
        getRecordingConsentWithdrawn() {
            return He.ANALYTICS_ONLY
        }
    }
    As([os("Quota File: quotaFileHandler")], Yd.prototype, "quotaFileHandler", null), As([os("Quota File: onerror")], Yd.prototype, "quotaServiceErrorHandler", null);
    class Xd extends Kd {
        constructor(t, s, e, i, n) {
            super(t), this.configuration = t, this.Bw = s, this.Uc = e, this.vv = i, this.ot = n, this.jw = []
        }
        refreshQuota() {}
        onQuotaReady(t) {}
        canCollect(t) {
            return !0
        }
        init() {
            this.zw()
        }
        sanitizeSessionCollectState(t) {
            return t.collectState !== He.QUOTA_REACHED && t.collectState !== He.RECORDING_RULES_TARGETING && t.collectState !== He.RECORDING_TEMPORARILY || (t.collectState = He.ANALYTICS_ONLY), t
        }
        computeInitialCollectState(t) {
            return yo.isReplayConsentNeeded(this.configuration) ? He.RECORDING_BLOCKED_BY_CONSENT_NOT_EXPRESSED : this.Qv(t)
        }
        computeInitialCollectStateFromRecordingConsentGranted(t) {
            return this.Qv(t)
        }
        Qv(t) {
            return oa.isRecordingSupported() ? (this.jw = [], G.percentage() < this.configuration.replayRecordingRate || this.vv.isForceReplayRecorded() ? csArray.prototype.push.call(this.jw, He.RECORDING_GLOBAL_SAMPLING) : this.configuration.malkaUrlEnabled && csArray.prototype.push.call(this.jw, He.RECORDING_URL_SAMPLING), this.configuration.malkaEtrEnabled && csArray.prototype.push.call(this.jw, He.RECORDING_ETR_SAMPLING), this.jw.length > 0 ? (this.Dw(t), He.RECORDING_TEMPORARILY) : He.ANALYTICS_ONLY) : He.ANALYTICS_ONLY
        }
        getEligibleCollectState(t) {
            return oa.isRecordingSupported() ? yo.isRecordingBlockedByConsent(t) ? t.collectState === He.RECORDING_BLOCKED_BY_CONSENT_WITHDRAWN ? He.RECORDING_BLOCKED_BY_CONSENT_WITHDRAWN : He.RECORDING_BLOCKED_BY_CONSENT_NOT_EXPRESSED : t.collectState === He.RECORDING_GLOBAL_SAMPLING ? He.RECORDING_GLOBAL_SAMPLING : (this.jw = [], this.configuration.malkaUrlEnabled && (csArray.prototype.push.call(this.jw, He.RECORDING_URL_SAMPLING), this.configuration.malkaEtrEnabled && csArray.prototype.push.call(this.jw, He.RECORDING_ETR_SAMPLING)), this.jw.length > 0 ? (this.Dw(t), He.RECORDING_TEMPORARILY) : (t.etrState === Be.ETR_ON && this.Uc.emitCollectStateChange(He.ANALYTICS_ONLY, Be.ETR_ON), He.ANALYTICS_ONLY)) : He.ANALYTICS_ONLY
        }
        Dw(t) {
            var s;
            const e = null === (s = this.K) || void 0 === s ? void 0 : s.getVisitor();
            this.Bw.send({
                recordingTypes: csArray.prototype.map.call(this.jw, Number),
                url: this.ot.getAnonymizedUrl(),
                projectId: this.configuration.projectId,
                uu: (null == e ? void 0 : e.id) || "",
                sn: (null == e ? void 0 : e.visitsCount) || "",
                pn: (null == t ? void 0 : t.pageNumber) || ""
            })
        }
        abortQuotaServiceRequest() {
            this.Bw.abort()
        }
        isReplayRecorded(t) {
            return !yo.isRecordingBlockedByConsent(t) && (t.collectState === He.RECORDING_TEMPORARILY || t.collectState === He.RECORDING_GLOBAL_SAMPLING || t.collectState === He.RECORDING_URL_SAMPLING || t.etrState === Be.ETR_ON)
        }
        zw() {
            this.Bw.onError((() => this.quotaServiceErrorHandler("NetworkError"))), this.Bw.onTimeout((() => this.quotaServiceTimeoutHandler()), 3e3), this.Bw.onLoad((t => this.quotaServiceLoadHandler(t)))
        }
        quotaServiceErrorHandler(t) {
            this.Gw(`error - ${t}`)
        }
        quotaServiceTimeoutHandler() {
            this.Gw("timeout")
        }
        Gw(t) {
            let s = He.ANALYTICS_ONLY;
            this.Zw(this.jw) ? (s = He.RECORDING_GLOBAL_SAMPLING, ns.warn(`Quota Service: request ${t} - bypassed by GLOBAL_SAMPLING`)) : ns.warn(`Quota Service: request ${t}`), this.Uc.emitCollectStateChange(s, Be.ETR_OFF)
        }
        quotaServiceLoadHandler(t) {
            if (200 !== t.status) return void this.quotaServiceErrorHandler(`Status code: ${t.status}`);
            let s;
            try {
                s = csJSON.parse(t.responseText)
            } catch (s) {
                return void this.quotaServiceErrorHandler(`Unable to parse the quota service response: ${t.responseText}`)
            }
            const e = null == s.allowedRecordingTypes ? void 0 : csArray.prototype.map.call(s.allowedRecordingTypes, csString);
            if (!e) return void this.quotaServiceErrorHandler("recording types missing from quota service response");
            let i = Be.ETR_OFF,
                n = He.ANALYTICS_ONLY;
            this.Zw(e) ? n = He.RECORDING_GLOBAL_SAMPLING : this.Ww(e) && (n = He.RECORDING_URL_SAMPLING), this.Qw(e) && (i = Be.ETR_ON), this.Uc.emitCollectStateChange(n, i)
        }
        Zw(t) {
            return csArray.prototype.some.call(t, (t => t === He.RECORDING_GLOBAL_SAMPLING))
        }
        Ww(t) {
            return csArray.prototype.some.call(t, (t => t === He.RECORDING_URL_SAMPLING))
        }
        Qw(t) {
            return csArray.prototype.some.call(t, (t => t === He.RECORDING_ETR_SAMPLING))
        }
        setVisitorService(t) {
            this.K = t
        }
        getInitialCollectState() {
            return He.ANALYTICS_ONLY
        }
        getRecordingConsentWithdrawn() {
            return He.RECORDING_BLOCKED_BY_CONSENT_WITHDRAWN
        }
    }
    As([os("Quota Service: onerror")], Xd.prototype, "quotaServiceErrorHandler", null), As([os("Quota Service: ontimeout")], Xd.prototype, "quotaServiceTimeoutHandler", null), As([os("Quota Service: onload")], Xd.prototype, "quotaServiceLoadHandler", null);
    class tf {
        constructor(t, s, e, i, n) {
            this.D = t, this.ht = s, this.q = e, this.cr = i, this.Uc = n, this.Jw = () => {
                const t = _s.get(Ga);
                null !== t && Ka.isValidSessionString(t) ? this.sv.canCollect(Ka.fromRawString(t)) && this.init() : (this.sv.onQuotaReady((t => {
                    t !== He.QUOTA_REACHED && this.init()
                })), this.sv.refreshQuota())
            }
        }
        initWithQuota() {
            const t = new Jd(this.D.getQuotaUri(), "", {
                type: "json",
                cacheMinutes: 15
            });
            this.sv = new Yd(this.D, t, this.Uc), this.sv.init(), this.Jw()
        }
        init() {
            let t, s, e, i, n, r, o, h, c, a, u, l, d, f, p, m, v, g, y, w, E, A, _, S, R, T, I, b, P, V, C, k;
            Uc.isSupported() && Uc.setDigestSalt(this.D.projectId.toString()), this.cr.schedule((() => {
                t = new ft, s = new al(t), i = new Du(window.location, s), e = new Is(this.D, i, this.ht), e.init()
            })), this.cr.schedule((() => {
                n = new Ju, r = new Ku, m = new Ru(window.location, e);
                (new gl).init(), v = Qu.create(ns.warn), p = new js(v);
                const t = p.create(`${this.D.getLegacyQuotaUri()}/quota`, !0);
                void 0 === this.sv && (this.sv = new Xd(this.D, t, this.Uc, m, i), this.sv.init())
            })), this.cr.schedule((() => {
                o = new Ka(this.D, e, n), h = new Xa(o, this.sv)
            })), this.cr.schedule((() => {
                c = new cl(this.D, e, n), a = new za(this.D, c, h, this.Uc), this.q.setContext(a, h), this.sv.setVisitorService(a)
            })), this.cr.schedule((() => {
                C = new lu(this.D, new nu(this.D, e, r), this.Uc), u = new su(a, h, C), l = new vu(this.D, e, n), d = new gu(window.location, l), f = new yu(d), g = new tu(this.D, a, d), P = new ul(F, this.D), S = new ll(P), R = new dl(P), T = new fl(P), I = new pl, b = new Hu(S, R, T, I), _ = new Nu([ku.UXA]), y = new Cu(_, b), w = new Eu(i), E = new _u(w, _);
                const s = new Xu(this.D, e, n);
                V = new il(t, s), A = new rl(_, V);
                new zs(a, h, d, V, this.D)
            })), this.cr.schedule((() => {
                const n = new Ba(this.D, a, d, g, u, undefined, undefined, m);
                this.D.implementations && (k = new Qd(this.D.implementations, _, this.cr), k.init(), this.Uc.addListener(k)), n.compute((n => {
                    this.cr.schedule((() => {
                        y.init();
                        const o = new qu,
                            c = new uu(this.D, _, C, h, this.Uc),
                            u = new Iu(this.D, e, r),
                            l = new bu(this.Uc, window.location, u),
                            d = new Vu(_, l),
                            m = new $u(_, this.D);
                        const g = new xu(this.D, a, h, undefined);
                        if (n) {
                            this.Uc.emitInitTracking();
                            new Ha(g, v, a, h, this.Uc, _, y, this.D, d, l, c, C, t, P, s, i, m, o, b, V, A, w, E, this.cr, p, e, r, this.sv).start()
                        } else {
                            new du(this.Uc, _, y, d, l, f, c).start()
                        }
                    }))
                }))
            }))
        }
    }
    var sf, ef;
    ! function(t) {
        let s;
        const e = {
            loadBundle(t) {
                const r = t.source,
                    o = t.data;
                if (i(o)) {
                    const i = () => {
                        const s = function(t, s) {
                            return csString.prototype.replace.call(csString.prototype.replace.call(csString.prototype.replace.call(t, "{version}", s.version), "{token}", s.token), "{domain}", s.domain)
                        }("{domain}/tag/tag.bundle.js?v={version}", o);
                        ! function(t, s) {
                            const e = document.createElement("script");
                            e.type = "text/javascript", e.async = !0, e.src = t, e.onload = s, e.charset = "utf-8", document.head.appendChild(e)
                        }(s, (() => r.postMessage("csBundleLoaded", t.origin)))
                    };
                    s = o.token, c(e.loadBundle), n(t.origin) && i()
                }
            }
        };

        function i(t) {
            return t && "csBundleInjection" === t.type && n(t.domain) && o(t.version) && r(t.token)
        }

        function n(s) {
            return /^https?:\/\/[a-zA-Z0-9\.\-]+\.(content-square\.fr|contentsquare\.com|csq\.io)$/.test(s) || t.hjDomainRegex.test(s)
        }

        function r(t) {
            return /^[a-zA-Z0-9]+$/.test(t)
        }

        function o(t) {
            return /^[a-zA-Z0-9\.]+$/.test(t)
        }

        function h(t) {
            window.addEventListener("message", t, !1)
        }

        function c(t) {
            window.removeEventListener("message", t, !1)
        }
        t.getToken = function() {
            return s
        }, t.isAuthorizedIncomingMessage = i, t.hjDomainRegex = /^https?:\/\/[a-zA-Z0-9\.\-]+\.hotjar\.com$/, t.isAuthorizedDomain = n, t.isAuthorizedToken = r, t.isAuthorizedTagVersion = o, t.isActivable = function() {
            const t = window.opener || window.parent;
            return window !== t && window.addEventListener
        }, t.waitForBundleInjection = function() {
            h(e.loadBundle)
        }, t.listen = h, t.removeListener = c
    }(sf || (sf = {})),
    function(t) {
        const s = window.opener || window.parent,
            e = [/^https:\/\/app\.contentsquare\.com$/, /^https:\/\/dev-app\.contentsquare\.com$/, /^https:\/\/staging-app\.contentsquare\.com$/, /^https:\/\/.*\.test\.contentsquare\.com$/, /^https:\/\/app\.[a-z0-9-]+\.csiab\.[a-z0-9-]+\.csq\.io$/, sf.hjDomainRegex];
        let i, n;
        const r = {
            ping(t) {
                if ("ping" === t.data && o(t.origin)) {
                    const s = sf.hjDomainRegex.test(t.origin);
                    i = s ? "https://app.contentsquare.com" : t.origin, n = s ? t.origin : void 0, a(r.ping), c(r.insertMessageScript), h(`${"utils.js"}?cb=${(new csDate).getTime()}`)
                }
            },
            insertMessageScript: u((t => {
                const s = t.data;
                "string" == typeof s && "ping" !== s && (a(r.insertMessageScript), h(s))
            }))
        };

        function o(t) {
            return csArray.prototype.some.call(e, (s => s.test(t)))
        }

        function h(t, s) {
            const e = document.createElement("script");
            e.type = "text/javascript", e.async = !0;
            const n = csString.prototype.replace.call(i, /^https?:/, "");
            e.src = `${n}/tag/${t}`, e.onload = s, e.charset = "utf-8", document.getElementsByTagName("head")[0].appendChild(e),
                function(t) {
                    csString.prototype.includes.call(t, "&mode=") && sessionStorage.setItem("_hjRetakerMode", csString.prototype.split.call(t, "&mode=")[1])
                }(t)
        }

        function c(t) {
            window.addEventListener("message", t, !1)
        }

        function a(t) {
            window.removeEventListener("message", t, !1)
        }

        function u(t) {
            return function(s) {
                (s.origin === i || n) && t(s)
            }
        }
        t.getToken = function() {
            return sf.getToken()
        }, t.isActivable = function() {
            return window !== s && window.addEventListener
        }, t.isAuthorizedDomain = o, t.waitForConnection = function() {
            c(r.ping), sf.waitForBundleInjection()
        }, t.listen = c, t.removeListener = a, t.secureListener = u, t.post = function(t) {
            n ? s.postMessage(t, n) : i && s.postMessage(t, i)
        }
    }(ef || (ef = {}));
    const nf = window.CSFrameCommunication || ef;
    class rf extends Uu {
        constructor(t) {
            super(), this.cr = t
        }
        emitBeforeNaturalPageView() {
            for (const t of this.listeners) t.onBeforeNaturalPageView && t.onBeforeNaturalPageView()
        }
        emitAfterNaturalPageView() {
            for (const t of this.listeners) t.onAfterNaturalPageView && t.onAfterNaturalPageView()
        }
        emitInitTracking() {
            for (const t of this.listeners) t.onInitTracking && t.onInitTracking()
        }
        emitStartTracking(t) {
            for (const s of this.listeners) s.onStartTracking && this.cr.schedule((() => s.onStartTracking(t)))
        }
        emitArtificialPageViewEnd() {
            for (const t of this.listeners)
                if (t.onArtificialPageViewEnd) try {
                    t.onArtificialPageViewEnd()
                } catch (t) {
                    ns.error(t)
                }
        }
        emitBeforeArtificialPageView() {
            for (const t of this.listeners) t.onBeforeArtificialPageView && t.onBeforeArtificialPageView()
        }
        emitAfterArtificialPageView() {
            for (const t of this.listeners) t.onAfterArtificialPageView && t.onAfterArtificialPageView()
        }
        emitBeforeSessionRenewal() {
            for (const t of this.listeners) t.onBeforeSessionRenewal && t.onBeforeSessionRenewal()
        }
        emitAfterSessionRenewal() {
            for (const t of this.listeners) t.onAfterSessionRenewal && t.onAfterSessionRenewal()
        }
        emitOptout() {
            for (const t of this.listeners) t.onOptout && t.onOptout()
        }
        emitReplayUnanonymizationConsentGranted() {
            for (const t of this.listeners) t.onReplayUnanonymizationConsentGranted && t.onReplayUnanonymizationConsentGranted()
        }
        emitReplayUnanonymizationConsentWithdrawn() {
            for (const t of this.listeners) t.onReplayUnanonymizationConsentWithdrawn && t.onReplayUnanonymizationConsentWithdrawn()
        }
        emitAfterReplayRecordingConsentGranted() {
            for (const t of this.listeners) t.onAfterReplayRecordingConsentGranted && t.onAfterReplayRecordingConsentGranted()
        }
        emitAfterReplayRecordingConsentWithdrawn() {
            for (const t of this.listeners) t.onAfterReplayRecordingConsentWithdrawn && t.onAfterReplayRecordingConsentWithdrawn()
        }
        emitCollectStateChange(t, s) {
            for (const e of this.listeners) e.onCollectStateChange && e.onCollectStateChange(t, s)
        }
        emitInitialDomStart() {
            for (const t of this.listeners) t.onInitialDomStart && t.onInitialDomStart()
        }
        emitInitialDomDone(t) {
            for (const s of this.listeners) s.onInitialDomDone && s.onInitialDomDone(t)
        }
        emitRecordingContextChange() {
            for (const t of this.listeners) t.onRecordingContextChange && t.onRecordingContextChange()
        }
        emitSensitiveStatusChange() {
            var t;
            for (const s of this.listeners) null === (t = s.onSensitiveStatusChange) || void 0 === t || t.call(s)
        }
        emitBeforeVisitorRenewal() {
            for (const t of this.listeners) t.onBeforeVisitorRenewal && t.onBeforeVisitorRenewal()
        }
        emitAfterVisitorCleared() {
            for (const t of this.listeners) t.onAfterVisitorCleared && t.onAfterVisitorCleared()
        }
        emitAfterVisitorRenewal() {
            for (const t of this.listeners) t.onAfterVisitorRenewal && t.onAfterVisitorRenewal()
        }
    }
    As([Es("emitStartTracking")], rf.prototype, "emitStartTracking", null);
    class of {
        constructor(t, s, e) {
            this.D = t, this.St = s, this.q = e
        }
        start() {
            var t, s, e, i, n;
            if (window.UXAnalytics) return;
            window.UXAnalytics = {}, window.CSCurrentScript = document.currentScript;
            const r = new Ln(!!(null === (t = this.D.taskSchedulerOptions) || void 0 === t ? void 0 : t.enabled), null === (s = this.D.taskSchedulerOptions) || void 0 === s ? void 0 : s.maxProcessingTime, null === (e = this.D.taskSchedulerOptions) || void 0 === e ? void 0 : e.waitDuration),
                o = new Ps(this.St, this.D);
            o.init();
            const h = new Vs(this.D, o);
            if (this.St.isTopWindowTracker() && h.canTrack()) {
                if ((null === (i = window.CSProtectnativeFunctionsLogs) || void 0 === i ? void 0 : i.Warning) && ns.warn(`protectNativeFunctions failed: ${window.CSProtectnativeFunctionsLogs.Warning}`), null === (n = window.CSProtectnativeFunctionsLogs) || void 0 === n ? void 0 : n.Critical) return void ns.error(`protectNativeFunctions failed: ${window.CSProtectnativeFunctionsLogs.Critical}`);
                const t = new rf(r),
                    s = new tf(this.D, o, this.q, r, t);
                this.D.isQuotaEnabled() ? s.initWithQuota() : s.init()
            } else 0;
            const c = csString.prototype.indexOf.call(window.location.href, "csDebug=1") > -1;
            window.UXAnalytics = {
                Sensitive: {
                    isNodeSensitive: t => $e.isMaskedElement(t) || $e.isMaskedElementChild(t),
                    isAttributeSensitive: (t, s) => $e.isMaskedAttribute(t, s),
                    getSensitiveAttributes: t => qs(t.attributes, (s => $e.isMaskedAttribute(t, s.name)))
                },
                Console: {
                    warn(t) {
                        c && console.warn("cs.tracking.warning", t)
                    },
                    error(t) {
                        c && console.error("cs.tracking.error", t)
                    }
                }
            }, !window.CSFrameCommunication && nf.isActivable() && (window.CSFrameCommunication = nf, nf.waitForConnection())
        }
    }
    As([Es("main.start"), os("main.start")], of .prototype, "start", null);
    var hf;
    ! function(t) {
        t.isCSJavascriptBridgeDefined = function() {
            return "object" == typeof window.CSJavascriptBridge && "function" == typeof window.CSJavascriptBridge.optIn && "function" == typeof window.CSJavascriptBridge.optOut && "function" == typeof window.CSJavascriptBridge.sendEvent && "function" == typeof window.CSJavascriptBridge.sendDynamicVar && "function" == typeof window.CSJavascriptBridge.sendTransaction
        }, t.getBridgeVersion = function() {
            if ("function" == typeof window.CSJavascriptBridge.getVersion) try {
                const t = window.CSJavascriptBridge.getVersion();
                if (vt(t)) return t
            } catch (t) {
                ns.warn("an error occurred when calling getVersion")
            }
            return null
        }, t.notifyIsReadyForTracking = function() {
            "function" == typeof window.CSJavascriptBridge.onWebviewTrackingReady && window.CSJavascriptBridge.onWebviewTrackingReady()
        }, t.sendAnalysisEvent = function(t) {
            window.CSJavascriptBridge.sendEvent(csJSON.stringify(t))
        }, t.sendSREvent = function(t) {
            if (window.CSJavascriptBridge.sendSREvent)
                for (const s of t.events) window.CSJavascriptBridge.sendSREvent(csJSON.stringify(s))
        }, t.sendLog = function(t) {
            window.CSJavascriptBridge && window.CSJavascriptBridge.sendLog && window.CSJavascriptBridge.sendLog(csJSON.stringify(t))
        }, t.sendOptIn = function() {
            window.CSJavascriptBridge.optIn()
        }, t.sendOptOut = function() {
            window.CSJavascriptBridge.optOut()
        }, t.sendDynamicVariable = function(t, s) {
            window.CSJavascriptBridge.sendDynamicVar(t, s)
        }, t.sendTransaction = function(t, s, e) {
            window.CSJavascriptBridge.sendTransaction(t, s, e)
        }, t.sendAssets = function(t, s) {
            if (window.CSJavascriptBridge.sendAssets) {
                const e = csJSON.stringify(t);
                window.CSJavascriptBridge.sendAssets(e, s || null)
            } else window.CSJavascriptBridge.sendSRAssets && window.CSJavascriptBridge.sendSRAssets(csArray.prototype.map.call(t, (t => t.assetId)))
        }, t.sendNativeSREvent = function(t) {
            window.CSJavascriptBridge && window.CSJavascriptBridge.sendNativeSREvent && window.CSJavascriptBridge.sendNativeSREvent(csJSON.stringify(t))
        }
    }(hf || (hf = {}));
    class cf {
        constructor() {}
        send(t, s, e = K.warn) {
            const i = {
                message: t,
                errorCode: s,
                level: e
            };
            hf.sendLog(i)
        }
    }
    try {
        const t = new Q(window.CS_CONF);
        window._uxa = window._uxa || [], t.processOptionOverrides(window._uxa);
        const s = new J(window, t);
        s.init();
        const e = new es;
        if (rs = ns, cs = !0, ns.computeIsActive(t.validationRate), s.isTopWindowTracker()) {
            const s = new qt(t, e);
            ns.setStrategy(s)
        } else if (s.isInIframeContext()) {
            const s = new ss(t);
            ns.setStrategy(s)
        } else if (s.isInWebViewContext()) {
            const t = new cf;
            ns.setStrategy(t)
        }! function(t = 50, s = .1) {
            fs = rs.isPerfLoggingActive() && function() {
                var t;
                if (!(null === (t = window.performance) || void 0 === t ? void 0 : t.mark)) return !1;
                const s = "isPerformanceMeasureSupported",
                    e = `${s}_a`;
                return performance.mark(e), void 0 !== performance.measure(s, e)
            }(), fs && (ls = t, ds = s)
        }();
        new of (t, s, e).start()
    } catch {}
})();