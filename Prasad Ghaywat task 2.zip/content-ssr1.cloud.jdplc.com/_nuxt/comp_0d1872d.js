(window.webpackJsonp = window.webpackJsonp || []).push([
    [16], {
        173: function(t, e, o) {},
        174: function(t, e, o) {},
        175: function(t, e, o) {},
        271: function(t, e, o) {
            "use strict";
            o(173)
        },
        272: function(t, e, o) {
            "use strict";
            o(174)
        },
        273: function(t, e, o) {
            "use strict";
            o(175)
        },
        353: function(t, e, o) {
            "use strict";
            o.r(e);
            var l = o(6),
                n = o.n(l),
                r = o(73),
                c = o(69),
                d = o(70),
                m = {
                    name: "SpotCarousel",
                    components: {
                        CarouselCE: r.default,
                        Picture: c.default
                    },
                    mixins: [d.a],
                    props: {
                        title: {
                            type: Object,
                            default: function() {
                                return {
                                    show: !0,
                                    text: "LATEST FOOTWEAR"
                                }
                            }
                        },
                        titleFontSize: {
                            type: Object,
                            default: function() {
                                return {
                                    selectBox: {
                                        current: "large",
                                        options: "spot_carousel.message.font_size"
                                    }
                                }
                            }
                        },
                        theme: {
                            type: Object,
                            default: function() {
                                return {
                                    selectBox: {
                                        current: "default",
                                        options: "spot_carousel.theme"
                                    }
                                }
                            }
                        },
                        margins: {
                            type: Boolean,
                            default: !0
                        },
                        fullWidth: {
                            type: Boolean,
                            default: !0
                        },
                        tabs: {
                            type: Array,
                            default: function() {
                                return [{
                                    tabTitle: "Tab One",
                                    tabImage: "https://jdsports-client-resources.co.uk/jdsports-client-resources/page/worldcup/img/BR.159075d1.png",
                                    spots: [{
                                        images: {
                                            desktop: "https://i1.adis.ws/i/jpl/232x322_4-6e99da160d4d92961574f12fa5632783",
                                            mobile: "https://i1.adis.ws/i/jpl/232x322_4-6e99da160d4d92961574f12fa5632783"
                                        },
                                        spotUrl: {
                                            desktop: "/desktop-spot-link",
                                            mobile: "/mobile-spot-link"
                                        },
                                        headline: "Spot",
                                        ctas: [{
                                            text: "SHOP NOW",
                                            url: {
                                                desktop: "/desktop-cta-link",
                                                mobile: "/mobile-cta-link"
                                            }
                                        }, {
                                            text: "SHOP NOW",
                                            url: {
                                                desktop: "/desktop-cta-link",
                                                mobile: "/mobile-cta-link"
                                            }
                                        }]
                                    }, {
                                        images: {
                                            desktop: "https://i1.adis.ws/i/jpl/232x322_1-4d046e20d6b6ba120e491a0a1f402485",
                                            mobile: "https://i1.adis.ws/i/jpl/232x322_1-4d046e20d6b6ba120e491a0a1f402485"
                                        },
                                        spotUrl: {
                                            desktop: "/desktop-spot-link",
                                            mobile: "/mobile-spot-link"
                                        },
                                        headline: "ADIDAS ORIGINALS NMD",
                                        ctas: [{
                                            text: "SHOP NOW",
                                            url: {
                                                desktop: "/desktop-cta-link",
                                                mobile: "/mobile-cta-link"
                                            }
                                        }]
                                    }, {
                                        images: {
                                            desktop: "https://i1.adis.ws/i/jpl/232x322_1-4d046e20d6b6ba120e491a0a1f402485",
                                            mobile: "https://i1.adis.ws/i/jpl/232x322_1-4d046e20d6b6ba120e491a0a1f402485"
                                        },
                                        spotUrl: {
                                            desktop: "/desktop-spot-link",
                                            mobile: "/mobile-spot-link"
                                        },
                                        headline: "ADIDAS ORIGINALS NMD",
                                        ctas: [{
                                            text: "SHOP NOW",
                                            url: {
                                                desktop: "/desktop-cta-link",
                                                mobile: "/mobile-cta-link"
                                            }
                                        }]
                                    }]
                                }, {
                                    tabTitle: "Tab Two",
                                    tabImage: "https://jdsports-client-resources.co.uk/jdsports-client-resources/page/worldcup/img/BR.159075d1.png",
                                    spots: [{
                                        images: {
                                            desktop: "https://i1.adis.ws/i/jpl/232x322_4-f7495bfda5102839e566a53fc8c8e377",
                                            mobile: "https://i1.adis.ws/i/jpl/232x322_4-f7495bfda5102839e566a53fc8c8e377"
                                        },
                                        spotUrl: {
                                            desktop: "/desktop-spot-link",
                                            mobile: "/mobile-spot-link"
                                        },
                                        headline: "",
                                        ctas: [{
                                            text: "SHOP NOW",
                                            url: {
                                                desktop: "/desktop-cta-link",
                                                mobile: "/mobile-cta-link"
                                            }
                                        }]
                                    }, {
                                        images: {
                                            desktop: "https://i1.adis.ws/i/jpl/232x322_4-f7495bfda5102839e566a53fc8c8e377",
                                            mobile: "https://i1.adis.ws/i/jpl/232x322_4-f7495bfda5102839e566a53fc8c8e377"
                                        },
                                        spotUrl: {
                                            desktop: "/desktop-spot-link",
                                            mobile: "/mobile-spot-link"
                                        },
                                        headline: "ADIDAS ORIGINALS NMD",
                                        ctas: [{
                                            text: "SHOP NOW",
                                            url: {
                                                desktop: "/desktop-cta-link",
                                                mobile: "/mobile-cta-link"
                                            }
                                        }]
                                    }]
                                }]
                            }
                        },
                        aspectRatio: {
                            type: Object,
                            default: function() {
                                return {
                                    desktop: "232:322",
                                    mobile: "232:322"
                                }
                            }
                        },
                        textUnderImage: {
                            type: Boolean,
                            default: !1
                        },
                        arrowOptions: {
                            type: Object,
                            default: function() {
                                return {
                                    buttons: {
                                        prev: "&#8249;",
                                        next: "&#8250;"
                                    },
                                    fontColor: "black",
                                    showBackground: !1,
                                    backgroundColor: "rgba(150, 150, 150, .5)",
                                    fontSize: {
                                        selectBox: {
                                            current: "2rem",
                                            options: "spot_carousel.carousel.arrows.font_size"
                                        }
                                    },
                                    position: {
                                        horizontal: "0",
                                        vertical: "0"
                                    },
                                    hideMobile: !1
                                }
                            }
                        },
                        carouselActive: {
                            type: Object,
                            default: function() {
                                return {
                                    selectBox: {
                                        current: "enabled",
                                        options: "spot_carousel.carousel.active"
                                    }
                                }
                            }
                        },
                        swiperOptions: {
                            type: Object,
                            default: function() {
                                return {
                                    slidesPerView: 3,
                                    slidesPerGroup: 1,
                                    pagination: !1,
                                    freeMode: !1,
                                    loop: !1,
                                    breakpoints: {
                                        480: {
                                            slidesPerView: 1,
                                            slidesPerGroup: 1
                                        },
                                        768: {
                                            slidesPerView: 1,
                                            slidesPerGroup: 1
                                        }
                                    }
                                }
                            }
                        },
                        hideBottomCta: {
                            type: Boolean,
                            default: !1
                        },
                        bottomCta: {
                            type: Array,
                            default: function() {
                                return [{
                                    url: "",
                                    text: "Bottom CTA",
                                    fontSize: {
                                        selectBox: {
                                            current: "16px",
                                            options: "spot_carousel.cta.font_size"
                                        }
                                    }
                                }]
                            }
                        }
                    },
                    data: function() {
                        return {
                            inViewport: !1,
                            rerender: !1,
                            swiper: !1,
                            screenWidth: 0,
                            reInitCarouselOnClick: !1,
                            hover: !1,
                            buttonHover: !1,
                            activeTab: 0
                        }
                    },
                    computed: {
                        totalSlides: function() {
                            return this.spotCarouselSpots ? this.spotCarouselSpots.length : 0
                        },
                        fullWidthSize: function() {
                            return this.fullWidth
                        },
                        carouselActiveStatus: function() {
                            var t = {
                                disabled: !0,
                                disabledMobile: !0,
                                disabledDesktop: !0
                            };
                            switch (this.carouselActive.selectBox.current) {
                                case "enabled":
                                    t = {
                                        disabled: !1,
                                        disabledMobile: !1,
                                        disabledDesktop: !1
                                    };
                                    break;
                                case "mobile-only":
                                    t = {
                                        disabled: !1,
                                        disabledMobile: !1,
                                        disabledDesktop: !0
                                    };
                                    break;
                                case "desktop-only":
                                    t = {
                                        disabled: !1,
                                        disabledMobile: !0,
                                        disabledDesktop: !1
                                    };
                                    break;
                                default:
                                    t = {
                                        disabled: !0,
                                        disabledMobile: !0,
                                        disabledDesktop: !0
                                    }
                            }
                            return t
                        }
                    },
                    mounted: function() {
                        this.screenWidth = window.innerWidth, window.addEventListener("resize", this.windowResize), this.component && (this.inViewport = !0)
                    },
                    methods: {
                        getSpotUrl: function(t) {
                            var e = "desktop";
                            return "mobile" === this.windowSize.device && (e = this.windowSize.device), "object" === n()(t.spotUrl) ? t.spotUrl[e] : t.spotUrl
                        },
                        spotCtaUrl: function(t, e) {
                            var o = "desktop";
                            return "mobile" === this.windowSize.device && (o = this.windowSize.device), "object" === n()(t.url) ? "" !== t.url[o] && " " !== t.url[o] ? t.url[o] : e.spotUrl[o] : "" !== t.url && " " !== t.url ? t.url : e.spotUrl.url
                        }
                    }
                },
                _ = (o(271), o(272), o(273), o(10)),
                component = Object(_.a)(m, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "spot-carousel__container",
                        class: [t.theme.selectBox.current, {
                            "restricted-width": !t.fullWidth
                        }],
                        attrs: {
                            id: "SpotCarousel"
                        }
                    }, [t.title.show ? o("div", {
                        staticClass: "message__container"
                    }, [o("h2", {
                        staticClass: "messageTitle",
                        class: t.titleFontSize.selectBox.current
                    }, [t._v("\n      " + t._s(t.title.text) + "\n    ")])]) : t._e(), t._v(" "), o("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.tabs.length > 1,
                            expression: "tabs.length > 1"
                        }],
                        staticClass: "tab-container"
                    }, t._l(t.tabs, (function(e, l) {
                        return o("div", {
                            key: l,
                            staticClass: "tab",
                            on: {
                                click: function(e) {
                                    t.activeTab = l
                                }
                            }
                        }, [e.tabImage ? o("img", {
                            staticClass: "tab-image",
                            class: [{
                                active: t.activeTab === l
                            }],
                            attrs: {
                                src: e.tabImage,
                                alt: ""
                            }
                        }) : t._e(), t._v(" "), "" !== e.tabImage || " " !== e.tabImage ? o("h3", {
                            class: [{
                                active: t.activeTab === l
                            }]
                        }, [t._v("\n        " + t._s(e.tabTitle) + "\n      ")]) : t._e()])
                    })), 0), t._v(" "), o("CarouselCE", {
                        attrs: {
                            component_id: t.$attrs.component_id + "__tab-" + t.tabs[t.activeTab].tabTitle.replace(/ /g, "-") + "__carousel",
                            component_index: t.$attrs.component_index + "__tab-" + t.tabs[t.activeTab].tabTitle.replace(/ /g, "-") + "__carousel",
                            options: t.swiperOptions,
                            arrows: t.arrowOptions,
                            disabled: t.carouselActiveStatus.disabled,
                            "disabled-mobile": t.carouselActiveStatus.disabledMobile,
                            "disabled-desktop": t.carouselActiveStatus.disabledDesktop
                        }
                    }, t._l(t.tabs[t.activeTab].spots, (function(e, l) {
                        return o("div", {
                            key: l,
                            class: ["spot-carousel-slide", "swiper-slide"]
                        }, [o("a", {
                            class: ["ga-ip", {
                                "no-click": "imagesOnly" === t.theme.selectBox.current
                            }],
                            attrs: {
                                "data-ip-position": t.$attrs.component_index + "__tab-" + t.tabs[t.activeTab].tabTitle.replace(/ /g, "-") + "__spot-" + (l + 1),
                                "data-ip-name": e.headline,
                                href: t.getSpotUrl(e)
                            }
                        }, [o("div", {
                            class: ["spot-container", {
                                "margin-true": t.margins
                            }]
                        }, [o("Picture", {
                            attrs: {
                                component_id: t.$attrs.component_id + "__tab-" + t.tabs[t.activeTab].tabTitle.replace(/ /g, "-") + "__picture",
                                component_index: t.$attrs.component_index + "__tab-" + t.tabs[t.activeTab].tabTitle.replace(/ /g, "-") + "__picture",
                                image: e.images,
                                "aspect-ratio": t.aspectRatio.desktop,
                                "aspect-ratio-mobile": t.aspectRatio.mobile
                            }
                        }), t._v(" "), o("div", {
                            class: {
                                spotOverlay: !t.textUnderImage, underImage: t.textUnderImage
                            }
                        }, [o("span", {
                            staticClass: "spot_cta_title"
                        }, [t._v("\n              " + t._s(e.headline) + "\n            ")]), t._v(" "), t._l(e.ctas, (function(n, r) {
                            return o("span", {
                                key: r,
                                staticClass: "spot_cta"
                            }, [o("a", {
                                staticClass: "cta-text ga-ip",
                                attrs: {
                                    "data-ip-position": t.$attrs.component_index + "__tab-" + t.tabs[t.activeTab].tabTitle.replace(/ /g, "-") + "__spot-" + (l + 1) + "__cta-" + (r + 1),
                                    "data-ip-name": n.text,
                                    href: t.spotCtaUrl(n, e)
                                }
                            }, [t._v("\n                " + t._s(n.text) + "\n              ")])])
                        }))], 2)], 1)])])
                    })), 0), t._v(" "), t._l(t.bottomCta, (function(e, l) {
                        return o("div", {
                            key: l,
                            class: ["bottom-cta-container", {
                                hideBottomCta: t.hideBottomCta
                            }]
                        }, [o("a", {
                            staticClass: "bottom-cta ga-ip",
                            style: {
                                fontSize: e.fontSize.selectBox.current
                            },
                            attrs: {
                                "data-ip-position": t.$attrs.component_index + "__tab-" + t.tabs[t.activeTab].tabTitle.replace(/ /g, "-") + "__cta-" + (l + 1),
                                "data-ip-name": e.text,
                                href: e.url
                            }
                        }, [t._v("\n      " + t._s(e.text) + "\n    ")])])
                    }))], 2)
                }), [], !1, null, "5ccfb048", null);
            e.default = component.exports
        }
    }
]);