(window.webpackJsonp = window.webpackJsonp || []).push([
    [65], {
        130: function(t, e, o) {},
        229: function(t, e, o) {
            "use strict";
            o(130)
        },
        321: function(t, e, o) {
            "use strict";
            o.r(e);
            var n = o(6),
                r = o.n(n),
                c = o(13),
                l = o.n(c),
                d = o(70),
                _ = o(73),
                f = o(69),
                h = {
                    name: "Blog",
                    components: {
                        CarouselCE: _.default,
                        Picture: f.default
                    },
                    mixins: [d.a],
                    props: {
                        apiLink: {
                            type: String,
                            default: "https://blog.footpatrol.com/wp-json/wp/v2/posts?_embed&per_page=12"
                        },
                        header: {
                            type: Object,
                            default: function() {
                                return {
                                    text: {
                                        html: {
                                            value: "Blog Header"
                                        }
                                    },
                                    link: "/blog-link",
                                    fontSize: {
                                        selectBox: {
                                            current: "1.2rem",
                                            options: "blog.header.font_size"
                                        }
                                    },
                                    color: "black"
                                }
                            }
                        },
                        cta: {
                            type: Object,
                            default: function() {
                                return {
                                    text: "Post",
                                    fontSize: {
                                        selectBox: {
                                            current: "1rem",
                                            options: "blog.cta.font_size"
                                        }
                                    },
                                    color: "",
                                    margin: ".5rem 0 0 0"
                                }
                            }
                        },
                        post: {
                            type: Object,
                            default: function() {
                                return {
                                    title: {
                                        fontSize: {
                                            selectBox: {
                                                current: "1.2rem",
                                                options: "blog.post.title.font_size"
                                            }
                                        },
                                        color: ""
                                    },
                                    subtitle: {
                                        fontSize: {
                                            selectBox: {
                                                current: "1.1rem",
                                                options: "blog.post.subtitle.font_size"
                                            }
                                        },
                                        color: ""
                                    }
                                }
                            }
                        },
                        dataToShow: {
                            type: Object,
                            default: function() {
                                return {
                                    author: !1,
                                    excerpt: !1
                                }
                            }
                        },
                        aspectRatio: {
                            type: String,
                            default: "308:104"
                        },
                        theme: {
                            type: Object,
                            default: function() {
                                return {
                                    selectBox: {
                                        current: "default",
                                        options: "blog.theme"
                                    }
                                }
                            }
                        },
                        carousel: {
                            type: Object,
                            default: function() {
                                return {
                                    options: {
                                        slidesPerView: 3,
                                        slidesPerGroup: 3,
                                        spaceBetween: 50,
                                        watchOverflow: !0,
                                        breakpoints: {
                                            767: {
                                                slidesPerView: 1,
                                                slidesPerGroup: 1
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        arrowOptions: {
                            type: Object,
                            default: function() {
                                return {
                                    buttons: {
                                        prev: "&#8249;",
                                        next: "&#8250;"
                                    },
                                    fontColor: "black",
                                    showBackground: !1,
                                    backgroundColor: "rgba(150, 150, 150, .5)",
                                    fontSize: {
                                        selectBox: {
                                            current: "2rem",
                                            options: "blog.carousel.arrows.font_size"
                                        }
                                    },
                                    position: {
                                        horizontal: "0",
                                        vertical: "0"
                                    },
                                    hideMobile: !1
                                }
                            }
                        }
                    },
                    data: function() {
                        return {
                            apiContent: [],
                            blogContent: {
                                posts: [],
                                images: []
                            }
                        }
                    },
                    computed: {
                        blogHeader: function() {
                            return "object" === r()(this.header.text) && this.header.text.html ? this.header.text.html.value : this.header.text
                        }
                    },
                    watch: {
                        apiLink: {
                            immediate: !0,
                            handler: function(t) {
                                this.getAPI(t)
                            }
                        }
                    },
                    methods: {
                        getAPI: function(link) {
                            var t = this;
                            l.a.get(link).then((function(e) {
                                t.getBlogContent(e.data)
                            })).catch((function(e) {
                                t.blogContent.posts.push("Could not retrieve data from API.: ".concat(e))
                            }))
                        },
                        getBlogContent: function(t) {
                            var e = this;
                            this.apiContent = t, t.forEach((function(t) {
                                var o = {
                                    title: e.convertHTMLEntities(t.title.rendered),
                                    url: t.link,
                                    images: {
                                        desktop: t._embedded["wp:featuredmedia"][0].source_url,
                                        mobile: t._embedded["wp:featuredmedia"][0].source_url
                                    },
                                    ctas: [{
                                        cta_text: e.cta.text,
                                        cta_url: t.link
                                    }],
                                    author: t._embedded.author[0].name,
                                    excerpt: t.excerpt.rendered
                                };
                                e.blogContent.posts.push(o)
                            }))
                        },
                        convertHTMLEntities: function(html) {
                            var t = document.createElement("textarea");
                            return t.innerHTML = html, t.value
                        }
                    }
                },
                m = (o(229), o(10)),
                component = Object(m.a)(h, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        class: [t.windowSize, "blog__container", "theme--" + t.theme.selectBox.current]
                    }, [t.header.text && " " !== t.header.text ? o("div", {
                        staticClass: "header__container"
                    }, [o("a", {
                        staticClass: "header__link ga-ip",
                        style: {
                            fontSize: t.header.fontSize.selectBox.current,
                            color: t.header.color,
                            borderColor: t.header.color
                        },
                        attrs: {
                            href: t.header.link,
                            "data-ip-position": t.$attrs.component_index + "__header",
                            "data-ip-name": t.header.text
                        },
                        domProps: {
                            innerHTML: t._s(t.blogHeader)
                        }
                    })]) : t._e(), t._v(" "), t.blogContent.posts.length >= 1 ? o("div", {
                        staticClass: "posts__container"
                    }, [t.apiContent.length ? o("CarouselCE", {
                        staticClass: "blog__carousel",
                        attrs: {
                            component_id: t.$attrs.component_id + "__carousel-ce",
                            component_index: t.$attrs.component_index + "__carousel-ce",
                            options: t.carousel.options,
                            pagination: {
                                show: !1
                            },
                            arrows: t.arrowOptions
                        }
                    }, t._l(t.blogContent.posts, (function(e, n) {
                        return o("a", {
                            key: n,
                            class: ["blog-post", "swiper-slide", "ga-ip"],
                            attrs: {
                                href: e.url,
                                "data-ip-position": t.$attrs.component_index + "__post-" + (n + 1),
                                "data-ip-name": e.title
                            }
                        }, [e.images ? o("Picture", {
                            class: "blog-post__image",
                            attrs: {
                                component_id: t.$attrs.component_id + "__post-" + (n + 1) + "__picture",
                                component_index: t.$attrs.component_index + "__post-" + (n + 1) + "__picture",
                                image: e.images,
                                "aspect-ratio": t.aspectRatio
                            }
                        }) : t._e(), t._v(" "), o("div", {
                            staticClass: "info__container"
                        }, [e.title ? o("p", {
                            staticClass: "blog-text blog-title",
                            style: {
                                fontSize: t.post.title.fontSize.selectBox.current,
                                color: t.post.title.color
                            }
                        }, [t._v("\n            " + t._s(e.title) + "\n          ")]) : t._e(), t._v(" "), e.subtitle ? o("p", {
                            staticClass: "blog-text blog-subtitle",
                            style: {
                                fontSize: t.post.subtitle.fontSize.selectBox.current,
                                color: t.post.subtitle.color
                            }
                        }, [t._v("\n            " + t._s(e.subtitle) + "\n          ")]) : t._e(), t._v(" "), t.dataToShow.author ? o("p", {
                            staticClass: "blog-author"
                        }, [t._v("\n            " + t._s(e.author) + "\n          ")]) : t._e(), t._v(" "), t.dataToShow.excerpt ? o("div", {
                            staticClass: "blog-excerpt",
                            domProps: {
                                innerHTML: t._s(e.excerpt)
                            }
                        }) : t._e(), t._v(" "), o("div", {
                            staticClass: "ctas__container"
                        }, t._l(e.ctas, (function(e, r) {
                            return o("a", {
                                key: r,
                                staticClass: "cta__link ga-ip",
                                attrs: {
                                    href: e.cta_url,
                                    "data-ip-position": t.$attrs.component_index + "__post-" + (n + 1) + "__cta-" + (r + 1),
                                    "data-ip-name": t.cta.text,
                                    "data-ip-id": e.cta_url
                                }
                            }, [t.cta.text ? o("p", {
                                staticClass: "blog-text cta-text",
                                style: {
                                    fontSize: t.cta.fontSize.selectBox.current,
                                    color: t.cta.color,
                                    margin: t.cta.margin
                                }
                            }, [t._v("\n                " + t._s(t.cta.text) + "\n              ")]) : t._e()])
                        })), 0)])], 1)
                    })), 0) : t._e()], 1) : t._e()])
                }), [], !1, null, null, null);
            e.default = component.exports
        }
    }
]);