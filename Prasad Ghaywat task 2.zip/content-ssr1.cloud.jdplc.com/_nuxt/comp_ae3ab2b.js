(window.webpackJsonp = window.webpackJsonp || []).push([
    [21, 52], {
        151: function(t, e, n) {},
        250: function(t, e, n) {
            "use strict";
            n(151)
        },
        336: function(t, e, n) {
            "use strict";
            n.r(e);
            var o = n(6),
                r = n.n(o),
                l = n(69),
                c = n(81),
                d = n(70),
                m = {
                    inject: {
                        name: {
                            default: void 0
                        }
                    },
                    components: {
                        Picture: l.default,
                        TextDisplay: c.default
                    },
                    mixins: [d.a],
                    props: {
                        icons: {
                            type: Array,
                            default: function() {
                                return [{
                                    image: "",
                                    url: ""
                                }]
                            }
                        },
                        text: {
                            type: Object,
                            default: function() {
                                return {
                                    title: "",
                                    subtitle: ""
                                }
                            }
                        },
                        fontSize: {
                            type: Object,
                            default: function() {
                                return {
                                    title: {
                                        selectBox: {
                                            current: "medium",
                                            options: "main_banner.font_size.title"
                                        }
                                    },
                                    subtitle: {
                                        selectBox: {
                                            current: "medium",
                                            options: "main_banner.font_size.subtitle"
                                        }
                                    }
                                }
                            }
                        },
                        invertText: {
                            type: Boolean,
                            default: !1
                        },
                        images: {
                            type: [Object, String],
                            default: function() {
                                return {
                                    desktop: "https://i8.amplience.net/i/jpl/desktop-full-width-banner-5ae6ee48744631768f037a839b822614?qlt=80",
                                    mobile: "https://i8.amplience.net/i/jpl/mobile-banner-a9eb5c29e210129819c67402fd7379a9?qlt=80",
                                    alt: "Description of the image"
                                }
                            }
                        },
                        overlay: {
                            type: Object,
                            default: function() {
                                return {
                                    showOverlay: !1,
                                    width: 20,
                                    position: {
                                        desktop: {
                                            horizontal: 70,
                                            vertical: 66
                                        },
                                        mobile: {
                                            horizontal: 16,
                                            vertical: 77.7
                                        }
                                    },
                                    images: {
                                        desktop: "https://mesh-uploads-production.s3.amazonaws.com/mesh-uploads/scottsmenswear/2019/10/1e7d9228-af34-496c-9246-f9efdad3d07b_Slice_1.png",
                                        mobile: "https://i8.amplience.net/i/jpl/take-the-stage-136def18da1d7369f9b016b29594a790",
                                        alt: "Description of the image"
                                    },
                                    aspectRatio: {
                                        desktop: "304:81",
                                        mobile: "304:81"
                                    },
                                    ctas: [{
                                        images: {
                                            desktop: "https://mesh-uploads-production.s3.amazonaws.com/mesh-uploads/scottsmenswear/2019/10/c755dd3e-6bd2-42b9-a4da-f3ba12a05548_Slice_2.png",
                                            mobile: ""
                                        },
                                        aspectRatio: {
                                            desktop: "304:81",
                                            mobile: "304:81"
                                        },
                                        url: "/nike"
                                    }, {
                                        images: {
                                            desktop: "https://mesh-uploads-legacy.s3.amazonaws.com/mesh-control/eaf6b18b5dea4e9ea170d120437127c3_read-more.png",
                                            mobile: ""
                                        },
                                        aspectRatio: {
                                            desktop: "304:81",
                                            mobile: "304:81"
                                        },
                                        url: "/nike"
                                    }]
                                }
                            }
                        },
                        buttons: {
                            type: Array,
                            default: function() {
                                return [{
                                    text: "CTA",
                                    id: "example_id_1",
                                    url: {
                                        desktop: "/desktop-cta-link",
                                        mobile: "/mobile-cta-link"
                                    },
                                    invert: !1,
                                    images: {
                                        desktop: "https://via.placeholder.com/30x30",
                                        mobile: " "
                                    },
                                    color: {
                                        background: "#ffffff",
                                        text: "#000000"
                                    },
                                    categories: [{
                                        name: "Example Category",
                                        value: "jdplc_exampleCat"
                                    }],
                                    subCategories: [{
                                        text: "Men's Footwear",
                                        id: "example-sub-category_id",
                                        categories: [{
                                            name: "Men's",
                                            value: "jdplc_mens"
                                        }, {
                                            name: "Footwear",
                                            value: "jdplc_mens_mensfootwear"
                                        }],
                                        images: {
                                            desktop: "https://via.placeholder.com/30x30/0000ff/ffffff",
                                            mobile: "https://via.placeholder.com/30x30/ff0000/ffffff"
                                        },
                                        url: {
                                            desktop: "/can-be-left-blank",
                                            mobile: "/blank"
                                        },
                                        color: {
                                            background: "#ffffff",
                                            text: "#000000"
                                        }
                                    }]
                                }, {
                                    text: "CTA",
                                    id: "example_id_2",
                                    url: {
                                        desktop: "/desktop-cta-link",
                                        mobile: "/mobile-cta-link"
                                    },
                                    invert: !1,
                                    images: {
                                        desktop: "https://via.placeholder.com/30x30",
                                        mobile: " "
                                    },
                                    color: {
                                        background: "#ffffff",
                                        text: "#000000"
                                    }
                                }]
                            }
                        },
                        buttonAlignment: {
                            type: String,
                            default: "center"
                        },
                        roundedButtons: {
                            type: Boolean,
                            default: !1
                        },
                        mainLink: {
                            type: [String, Boolean, Object],
                            default: function() {
                                return {
                                    desktop: "/desktop-link",
                                    mobile: "/mobile-link"
                                }
                            }
                        },
                        aspectRatio: {
                            type: Object,
                            default: function() {
                                return {
                                    desktop: {
                                        width: 1920,
                                        height: 594
                                    },
                                    mobile: {
                                        width: 750,
                                        height: 750
                                    }
                                }
                            }
                        },
                        bannerStyles: {
                            type: Object,
                            default: function() {}
                        }
                    },
                    data: function() {
                        return {
                            windowWidth: 0,
                            compName: "main-banner",
                            showSubCatBtns: !1,
                            selectedBtnIndex: -1
                        }
                    },
                    computed: {
                        buttonContainerinlineStyles: function() {
                            var t = "center";
                            return "left" === this.buttonAlignment.toLowerCase().trim() ? t = "flex-start" : "right" === this.buttonAlignment.toLowerCase().trim() && (t = "flex-end"), "\n        justify-content: ".concat(t, "\n      ")
                        },
                        aspectRatioValues: function() {
                            return this.windowWidth <= 767 ? "".concat(this.aspectRatio.mobile.width, ":").concat(this.aspectRatio.mobile.height) : "".concat(this.aspectRatio.desktop.width, ":").concat(this.aspectRatio.desktop.height)
                        },
                        mainImageLink: function() {
                            var t = "desktop";
                            return "mobile" === this.windowSize.device && (t = this.windowSize.device), "object" === r()(this.mainLink) ? this.mainLink[t] : this.mainLink
                        }
                    },
                    mounted: function() {
                        var t = this;
                        this.windowWidth = window.innerWidth, window.addEventListener("resize", this.debounce((function() {
                            t.windowWidth = t.viewportWidth()
                        }), 250))
                    },
                    methods: {
                        debounce: function(t) {
                            var e, time = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 300;
                            return function() {
                                clearTimeout(e);
                                for (var n = arguments.length, o = new Array(n), r = 0; r < n; r++) o[r] = arguments[r];
                                e = setTimeout(t.bind.apply(t, [null].concat(o)), time)
                            }
                        },
                        viewportWidth: function() {
                            return window.innerWidth
                        },
                        overlayPositionHorizontal: function() {
                            return this.windowWidth, this.overlay.position.desktop.horizontal
                        },
                        overlayPositionVertical: function() {
                            return this.windowWidth > 767 ? this.overlay.position.desktop.vertical : this.overlay.position.mobile.vertical
                        },
                        ctaUrl: function(button) {
                            var t = "desktop";
                            return "mobile" === this.windowSize.device && (t = this.windowSize.device), "object" === r()(button.url) ? "" !== button.url[t] && " " !== button.url[t] ? button.url[t] : this.mainLink[t] : "" !== button.url && " " !== button.url ? button.url : this.mainLink.url
                        },
                        displayCtaIcon: function(button) {
                            var t = "desktop";
                            return "mobile" === this.windowSize.device && (t = this.windowSize.device), !(!button.images || "" === button.images[t] || " " === button.images[t]) && button.images[t]
                        },
                        ctaButtonInlineStyles: function(button) {
                            var t = "0",
                                e = "",
                                n = "";
                            return this.roundedButtons && (t = "20px"), button.color && (e = button.color.background, n = button.color.text), "\n        border-radius: ".concat(t, ";\n        background-color: ").concat(e, ";\n        color: ").concat(n, ";\n      ")
                        },
                        toggleSubCatBtns: function(t, e) {
                            return e.preventDefault(), this.selectedBtnIndex = t, this.showSubCatBtns = !this.showSubCatBtns, !1
                        }
                    }
                },
                f = m,
                h = (n(250), n(10)),
                component = Object(h.a)(f, (function() {
                    var t = this,
                        e = t.$createElement,
                        n = t._self._c || e;
                    return t.images ? n("a", {
                        staticClass: "ga-ip mainBanner__container",
                        style: t.bannerStyles,
                        attrs: {
                            "data-ip-position": t.$attrs.component_index + "__image-link",
                            "data-ip-name": t.images.alt,
                            href: t.mainImageLink
                        }
                    }, [t.icons.length && t.icons[0].image.length ? n("div", {
                        staticClass: "icons-container"
                    }, t._l(t.icons, (function(e, o) {
                        return n("a", {
                            key: o,
                            class: ["main-banner__icon", "ga-ip"],
                            attrs: {
                                href: !(!e.url || " " === e.url) && e.url,
                                "data-ip-position": t.$attrs.component_index + "__icon-" + (o + 1),
                                "data-ip-name": e.image,
                                "data-ip-id": e.url
                            }
                        }, [e.image.length ? n("img", {
                            attrs: {
                                src: e.image
                            }
                        }) : t._e()])
                    })), 0) : t._e(), t._v(" "), t.overlay.showOverlay ? n("div", {
                        staticClass: "overlay-container",
                        style: "width: " + t.overlay.width + "%; top: " + t.overlayPositionVertical() + "%; left: " + t.overlayPositionHorizontal() + "%;"
                    }, [n("Picture", {
                        staticClass: "overlay",
                        attrs: {
                            component_id: t.$attrs.component_id + "__overlay-picture",
                            component_index: t.$attrs.component_index + "__overlay-picture",
                            image: t.overlay.images,
                            "aspect-ratio": t.overlay.aspectRatio.desktop,
                            "aspect-ratio-mobile": t.overlay.aspectRatio.mobile
                        }
                    }), t._v(" "), 0 !== t.overlay.ctas.length ? n("div", {
                        staticClass: "overlay-button-container"
                    }, t._l(t.overlay.ctas, (function(button, e) {
                        return n("a", {
                            key: e,
                            staticClass: "overlay-cta-btn ga-ip",
                            style: " width: " + 100 / t.overlay.ctas.length + "%;",
                            attrs: {
                                href: button.url,
                                "data-ip-position": t.$attrs.component_index + "__overlay-button-" + (e + 1),
                                "data-ip-name": button.url,
                                "data-ip-id": button.url
                            }
                        }, [n("Picture", {
                            staticClass: "overlay",
                            attrs: {
                                component_id: t.$attrs.component_id + "__overlay-button-picture",
                                component_index: t.$attrs.component_index + "__overlay-button-picture",
                                image: button.images,
                                "aspect-ratio": button.aspectRatio.desktop,
                                "aspect-ratio-mobile": button.aspectRatio.mobile
                            }
                        })], 1)
                    })), 0) : t._e()], 1) : t._e(), t._v(" "), n("Picture", {
                        attrs: {
                            component_id: t.$attrs.component_id + "__picture",
                            component_index: t.$attrs.component_index + "__picture",
                            image: t.images,
                            "aspect-ratio": t.aspectRatioValues,
                            "aspect-ratio-mobile": t.aspectRatioValues
                        }
                    }), t._v(" "), n("TextDisplay", {
                        class: [{
                            invert: t.invertText
                        }, "title-" + t.fontSize.title.selectBox.current, "subtitle-" + t.fontSize.subtitle.selectBox.current],
                        attrs: {
                            component_id: t.$attrs.component_id + "__text-display",
                            component_index: t.$attrs.component_index + "__text-display",
                            headline: t.text.title,
                            subtext: t.text.subtitle
                        }
                    }), t._v(" "), t.buttons && !t.showSubCatBtns ? n("div", {
                        staticClass: "buttons__container",
                        style: t.buttonContainerinlineStyles
                    }, t._l(t.buttons, (function(button, e) {
                        return n("a", {
                            key: e,
                            class: ["cta-btn", "ga-ip", {
                                invert: button.invert
                            }],
                            style: t.ctaButtonInlineStyles(button),
                            attrs: {
                                href: (!button.subCategories || !button.subCategories.length) && t.ctaUrl(button),
                                id: button.id ? button.id : "",
                                "data-ip-position": t.$attrs.component_index + "__cta-" + (e + 1),
                                "data-ip-name": button.text,
                                "data-ip-id": button.url
                            },
                            on: {
                                click: function(n) {
                                    button.subCategories && button.subCategories.length && t.toggleSubCatBtns(e, n)
                                }
                            }
                        }, [t.displayCtaIcon(button) ? n("img", {
                            attrs: {
                                src: t.displayCtaIcon(button)
                            }
                        }) : t._e(), t._v(" "), n("span", [t._v("\n        " + t._s(button.text) + "\n      ")])])
                    })), 0) : t._e(), t._v(" "), t.showSubCatBtns && t.selectedBtnIndex >= 0 ? n("div", {
                        staticClass: "sub-cat-btns__container",
                        style: t.buttonContainerinlineStyles
                    }, t._l(t.buttons[t.selectedBtnIndex].subCategories, (function(e, o) {
                        return n("a", {
                            key: o,
                            class: ["sub-cat-btn", "sub-cat-btn-" + o, "cta-btn", "ga-ip"],
                            style: t.ctaButtonInlineStyles(e),
                            attrs: {
                                id: e.id ? e.id : "",
                                "data-ip-position": t.$attrs.component_index + "__subCatBtn-" + (o + 1),
                                "data-ip-name": e.text,
                                "data-ip-id": e.url,
                                href: !!e.url && e.url
                            }
                        }, [t.displayCtaIcon(e) ? n("img", {
                            attrs: {
                                src: t.displayCtaIcon(e)
                            }
                        }) : t._e(), t._v(" "), e.text.length ? n("span", [t._v(t._s(e.text))]) : t._e()])
                    })), 0) : t._e()], 1) : t._e()
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        72: function(t, e, n) {},
        78: function(t, e, n) {
            "use strict";
            n(72)
        },
        81: function(t, e, n) {
            "use strict";
            n.r(e);
            var o = {
                    inheritAttrs: !1,
                    props: {
                        headline: {
                            type: String,
                            default: ""
                        },
                        subtext: {
                            type: String,
                            default: ""
                        },
                        weight: {
                            type: Number,
                            default: 0
                        },
                        invertText: {
                            type: Boolean,
                            default: !1
                        }
                    },
                    computed: {
                        explictHeadline: function() {
                            return this.weight > 0 && this.weight <= 6 ? "h".concat(this.weight) : "div"
                        },
                        safeHeadline: function() {
                            return this.escapeHTML(this.headline)
                        },
                        safeSubtext: function() {
                            var t = this.escapeHTML(this.subtext).split("\n\n");
                            return t.length > 1 ? "<p>".concat(t.join("</p><p>"), "</p>") : t[0]
                        }
                    },
                    methods: {
                        escapeHTML: function(t) {
                            return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;").replace(/\*(.+)\*/g, "<b>$1</b>")
                        }
                    }
                },
                r = (n(78), n(10)),
                component = Object(r.a)(o, (function() {
                    var t = this,
                        e = t.$createElement,
                        n = t._self._c || e;
                    return t.headline || t.subtext ? n("div", {
                        class: ["c-text", {
                            invert: t.invertText
                        }]
                    }, [t.headline ? n(t.explictHeadline, {
                        tag: "component",
                        staticClass: "c-text__headline",
                        domProps: {
                            innerHTML: t._s(t.safeHeadline)
                        }
                    }) : t._e(), t._v(" "), t.subtext ? n("div", {
                        staticClass: "c-text__subtext",
                        domProps: {
                            innerHTML: t._s(t.safeSubtext)
                        }
                    }) : t._e()], 1) : t._e()
                }), [], !1, null, null, null);
            e.default = component.exports
        }
    }
]);