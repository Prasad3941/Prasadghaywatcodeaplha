(window.webpackJsonp = window.webpackJsonp || []).push([
    [31], {
        159: function(t, e, c) {},
        160: function(t, e, c) {},
        258: function(t, e, c) {
            "use strict";
            c(159)
        },
        259: function(t, e, c) {
            "use strict";
            c(160)
        },
        307: function(t, e, c) {
            "use strict";
            c.r(e);
            var o = c(6),
                r = c.n(o),
                n = c(90),
                l = c.n(n),
                d = c(73),
                _ = {
                    name: "Product",
                    components: {
                        Picture: c(69).default
                    },
                    props: {
                        product: {
                            type: Object,
                            default: function() {}
                        },
                        currency: {
                            type: Object,
                            default: function() {}
                        },
                        aspectRatio: {
                            type: Object,
                            default: function() {}
                        },
                        quickBuy: {
                            type: Object,
                            default: function() {
                                return {
                                    active: !0,
                                    svgPath: "M128.167,87H150l-14,55H64L50,87H71L99.583,58.417ZM70.8,134h58.4L139,95H61Zm46.367-47L99.583,69.417,82,87h35.167Z",
                                    text: "Quick Buy"
                                }
                            }
                        },
                        price: {
                            type: Object,
                            default: function() {}
                        },
                        imageShots: {
                            type: Object,
                            default: function() {
                                return {
                                    current: "a",
                                    hover: "b"
                                }
                            }
                        }
                    },
                    data: function() {
                        return {
                            className: "product",
                            imageShot: ""
                        }
                    },
                    computed: {
                        productImage: function() {
                            var t = this;
                            return this.product.pluDetails.images.filter((function(image) {
                                return image.shot === t.imageShot
                            }))
                        },
                        colours: function() {
                            var t = this;
                            return this.product.productColours && this.product.productColours.colours.length ? {
                                main: this.product.productColours.colours.filter((function(e, c) {
                                    return c < t.product.productColours.maxToShow
                                })),
                                additional: this.product.productColours.colours.filter((function(e, c) {
                                    return c >= t.product.productColours.maxToShow
                                }))
                            } : {
                                main: [],
                                additional: []
                            }
                        }
                    },
                    mounted: function() {
                        this.imageShot = this.imageShots.default
                    }
                },
                h = (c(258), c(10)),
                m = Object(h.a)(_, (function() {
                    var t = this,
                        e = t.$createElement,
                        c = t._self._c || e;
                    return c("a", {
                        class: [t.className, "ga-ip"],
                        attrs: {
                            "data-ip-position": "" + t.$attrs.component_index,
                            "data-ip-name": t.product.pluDetails.brand + " - " + t.product.pluDetails.title,
                            href: t.product.pluDetails.url
                        }
                    }, [t.productImage[0] ? c("Picture", {
                        attrs: {
                            image: t.productImage[0].url,
                            "aspect-ratio": t.aspectRatio.desktop,
                            "aspect-ratio-mobile": t.aspectRatio.mobile
                        },
                        nativeOn: {
                            mouseover: function(e) {
                                t.imageShot = t.imageShots.hover
                            },
                            mouseleave: function(e) {
                                t.imageShot = t.imageShots.default
                            }
                        }
                    }) : t._e(), t._v(" "), t.quickBuy.active ? c("div", {
                        class: [t.className + "__quick-buy", "quickBuyContainer"]
                    }, [t.quickBuy.svgPath && " " !== t.quickBuy.svgPath ? c("div", {
                        staticClass: "quickBuy-inner quickView itemQuickView",
                        staticStyle: {
                            "font-size": "12px"
                        },
                        attrs: {
                            "data-quickview-path": ""
                        }
                    }, [c("svg", {
                        attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            width: "30",
                            height: "30",
                            viewBox: "0 0 200 200"
                        }
                    }, [c("path", {
                        staticClass: "cls-1",
                        attrs: {
                            d: t.quickBuy.svgPath
                        }
                    })])]) : t._e(), t._v(" "), t.quickBuy.text && " " !== t.quickBuy.text ? c("p", [t._v("\n      " + t._s(t.quickBuy.text) + "\n    ")]) : t._e()]) : t._e(), t._v(" "), c("div", {
                        class: t.className + "-info"
                    }, [c("div", {
                        class: t.className + "-info__details"
                    }, [c("div", {
                        class: t.className + "-info__text"
                    }, [t.product.pluDetails.brand && " " !== t.product.pluDetails.brand ? c("h4", {
                        class: t.className + "-info__text__brand"
                    }, [t._v("\n          " + t._s(t.product.pluDetails.brand) + "\n        ")]) : t._e(), t._v(" "), t.product.pluDetails.title && " " !== t.product.pluDetails.title ? c("h4", {
                        class: t.className + "-info__text__title"
                    }, [t._v("\n          " + t._s(t.product.pluDetails.title) + "\n        ")]) : t._e()]), t._v(" "), t.product.pluDetails.price.was && 0 !== t.product.pluDetails.price.was || t.product.pluDetails.price.now && 0 !== t.product.pluDetails.price.now ? c("div", {
                        class: t.className + "__price-container"
                    }, [t.product.pluDetails.price.was && " " !== t.product.pluDetails.price.was ? c("p", {
                        class: [t.className + "__price", t.className + "__price--was"]
                    }, [t.currency.text.was && " " != t.currency.text.was ? c("span", {
                        staticClass: "price-text--was"
                    }, [t._v(t._s(t.currency.text.was) + " ")]) : t._e(), t._v(" "), c("span", {
                        staticClass: "price--was"
                    }, [t._v(t._s(t.price.was))])]) : t._e(), t._v(" "), t.product.pluDetails.price.now && 0 !== t.product.pluDetails.price.now ? c("p", {
                        class: [t.className + "__price", t.className + "__price--now", {
                            sale: t.product.pluDetails.price.was && 0 !== t.product.pluDetails.price.was
                        }]
                    }, [t.currency.text.now && 0 != t.currency.text.now ? c("span", {
                        staticClass: "price-text--now"
                    }, [t._v(t._s(t.currency.text.now) + " ")]) : t._e(), t._v(" "), c("span", {
                        staticClass: "price--now"
                    }, [t._v(t._s(t.price.now) + "\n          ")])]) : t._e()]) : t._e()]), t._v(" "), c("div", {
                        staticClass: "colours__container"
                    }, [t.colours.main.length ? c("div", {
                        staticClass: "main-colours__container"
                    }, t._l(t.colours.main, (function(e, o) {
                        return c("a", {
                            key: o,
                            staticClass: "product__colour",
                            attrs: {
                                href: e.url || !1
                            }
                        }, [c("div", {
                            staticClass: "colour__display",
                            style: "backgroundColor: " + e.hex
                        }), t._v(" "), e.text && " " !== e.text ? c("p", {
                            staticClass: "colour__text"
                        }, [t._v(t._s(e.text))]) : t._e()])
                    })), 0) : t._e(), t._v(" "), t.colours.additional.length ? c("div", {
                        staticClass: "additional-colours__container"
                    }, [t._v("\n        +" + t._s(t.colours.additional.length) + " " + t._s(t.colours.additional.length > 1 ? t.product.productColours.additionalText.plural : t.product.productColours.additionalText.single) + "\n      ")]) : t._e()]), t._v(" "), t.product.ctas.length ? c("div", {
                        class: t.className + "__ctas-container"
                    }, t._l(t.product.ctas, (function(e, o) {
                        return c("a", {
                            key: o,
                            class: [t.className + "__cta", "ga-ip"],
                            attrs: {
                                href: e.url,
                                "data-ip-position": t.$attrs.component_index + "__cta-" + (o + 1),
                                "data-ip-name": e.text
                            }
                        }, [t._v("\n        " + t._s(e.text) + "\n      ")])
                    })), 0) : t._e()])], 1)
                }), [], !1, null, null, null).exports,
                v = {
                    name: "ProductSpotlight",
                    components: {
                        CarouselCE: d.default,
                        Product: m
                    },
                    props: {
                        theme: {
                            type: Object,
                            default: function() {
                                return {
                                    selectBox: {
                                        current: "card",
                                        options: "product_spotlight.theme"
                                    }
                                }
                            }
                        },
                        carousel: {
                            type: Object,
                            default: function() {
                                return {
                                    active: {
                                        selectBox: {
                                            current: "mobile-only",
                                            options: "product_spotlight.carousel.active"
                                        }
                                    },
                                    options: {
                                        slidesPerView: 4,
                                        spaceBetween: 0,
                                        freeMode: !1,
                                        centeredSlides: !1,
                                        breakpoints: {
                                            767: {
                                                slidesPerView: 1.5,
                                                spaceBetween: 40,
                                                freeMode: !1,
                                                centeredSlides: !0
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        title: {
                            type: Object,
                            default: function() {
                                return {
                                    html: {
                                        value: 'Product <span style="font-size: 1.5rem">Spotlight</span>'
                                    }
                                }
                            }
                        },
                        filters: {
                            type: Object,
                            default: function() {
                                return {
                                    primary: !0,
                                    secondary: !1
                                }
                            }
                        },
                        currency: {
                            type: Object,
                            default: function() {
                                return {
                                    symbol: "£",
                                    location: {
                                        selectBox: {
                                            current: "before_price",
                                            options: "product_spotlight.currency.location"
                                        }
                                    },
                                    text: {
                                        was: "Was",
                                        now: ""
                                    }
                                }
                            }
                        },
                        tabs: {
                            type: Array,
                            default: function() {
                                return [{
                                    header: {
                                        text: "MENS"
                                    },
                                    body: {
                                        products: [{
                                            pluDetails: {
                                                plu: "030664",
                                                title: "Nike Air Force 1 '07 Men's Shoe",
                                                url: "/product/nike--air-force-1-07-mens-shoe/1267679/",
                                                brand: "Nike",
                                                price: {
                                                    was: " ",
                                                    now: "80.50"
                                                },
                                                category: "Air Force 1 '07 Men's Shoe",
                                                images: [{
                                                    shot: "a",
                                                    url: "https://i8.amplience.net/i/jpl/jd_030664_a"
                                                }, {
                                                    shot: "b",
                                                    url: "https://i8.amplience.net/i/jpl/jd_030664_b"
                                                }, {
                                                    shot: "c",
                                                    url: "https://i8.amplience.net/i/jpl/jd_030664_c"
                                                }, {
                                                    shot: "d",
                                                    url: "https://i8.amplience.net/i/jpl/jd_030664_d"
                                                }, {
                                                    shot: "e",
                                                    url: "https://i8.amplience.net/i/jpl/jd_030664_e"
                                                }, {
                                                    shot: "f",
                                                    url: "https://i8.amplience.net/i/jpl/jd_030664_f"
                                                }]
                                            },
                                            productColours: {
                                                maxToShow: 3,
                                                additionalText: {
                                                    single: "Colour",
                                                    plural: "Colours"
                                                },
                                                colours: [{
                                                    hex: "#aa0000",
                                                    text: "",
                                                    url: "/colour-1"
                                                }, {
                                                    hex: "#00aa00",
                                                    text: "",
                                                    url: "/colour-2"
                                                }, {
                                                    hex: "#0000aa",
                                                    text: "",
                                                    url: "/colour-3"
                                                }, {
                                                    hex: "#a0000a",
                                                    text: "",
                                                    url: ""
                                                }]
                                            },
                                            ctas: []
                                        }, {
                                            pluDetails: {
                                                plu: "163316",
                                                title: "Continental 80 Shoes",
                                                url: "/product/white-adidas-originals-continental-80-shoes/1322724",
                                                brand: "adidas Originals",
                                                price: {
                                                    was: "0",
                                                    now: "75"
                                                },
                                                category: "Continental 80 Shoes",
                                                images: [{
                                                    shot: "a",
                                                    url: "https://i8.amplience.net/i/jpl/jd_163316_a"
                                                }, {
                                                    shot: "b",
                                                    url: "https://i8.amplience.net/i/jpl/jd_163316_b"
                                                }, {
                                                    shot: "c",
                                                    url: "https://i8.amplience.net/i/jpl/jd_163316_c"
                                                }, {
                                                    shot: "d",
                                                    url: "https://i8.amplience.net/i/jpl/jd_163316_d"
                                                }, {
                                                    shot: "e",
                                                    url: "https://i8.amplience.net/i/jpl/jd_163316_e"
                                                }, {
                                                    shot: "f",
                                                    url: "https://i8.amplience.net/i/jpl/jd_163316_f"
                                                }]
                                            },
                                            ctas: []
                                        }],
                                        ctas: []
                                    },
                                    quickBuy: {
                                        svgPath: "",
                                        text: ""
                                    }
                                }]
                            }
                        },
                        aspectRatio: {
                            type: Object,
                            default: function() {
                                return {
                                    desktop: "685:485",
                                    mobile: "685:485"
                                }
                            }
                        },
                        imageShots: {
                            type: Object,
                            default: function() {
                                return {
                                    default: {
                                        selectBox: {
                                            current: "a",
                                            options: "product_spotlight.image_shots"
                                        }
                                    },
                                    hover: {
                                        selectBox: {
                                            current: "b",
                                            options: "product_spotlight.image_shots"
                                        }
                                    }
                                }
                            }
                        }
                    },
                    data: function() {
                        return {
                            className: "product-spotlight",
                            activeTab: 0,
                            activeSecondaryFilter: 0
                        }
                    },
                    computed: {
                        secondaryFilters: function() {
                            return this.tabs[this.activeTab].body.products.map((function(t) {
                                return t.pluDetails.category
                            })).reduce((function(t, e) {
                                return t.includes(e) ? t : [].concat(l()(t), [e])
                            }), [])
                        },
                        products: function() {
                            var t = this,
                                e = this.tabs[this.activeTab].body.products;
                            return e.forEach((function(t) {
                                var e = t.pluDetails.price;
                                e && e.was && "string" == typeof e.was && (e.was = e.was.split(" ").join(""))
                            })), e.filter((function(e) {
                                return t.filters.secondary ? e.pluDetails.category === t.secondaryFilters[t.activeSecondaryFilter] : e
                            }))
                        },
                        showQuickBuy: function() {
                            return !!(this.tabs[this.activeTab].quickBuy.svgPath && " " !== this.tabs[this.activeTab].quickBuy.svgPath || this.tabs[this.activeTab].quickBuy.text && " " !== this.tabs[this.activeTab].quickBuy.text)
                        },
                        quickBuy: function() {
                            return {
                                active: this.showQuickBuy,
                                svgPath: this.tabs[this.activeTab].quickBuy.svgPath,
                                text: this.tabs[this.activeTab].quickBuy.text
                            }
                        },
                        carouselActive: function() {
                            var t = {
                                disabled: !0,
                                disabledMobile: !0,
                                disabledDesktop: !0
                            };
                            switch (this.carousel.active.selectBox.current) {
                                case "enabled":
                                    t = {
                                        disabled: !1,
                                        disabledMobile: !1,
                                        disabledDesktop: !1
                                    };
                                    break;
                                case "mobile-only":
                                    t = {
                                        disabled: !1,
                                        disabledMobile: !1,
                                        disabledDesktop: !0
                                    };
                                    break;
                                case "desktop-only":
                                    t = {
                                        disabled: !1,
                                        disabledMobile: !0,
                                        disabledDesktop: !1
                                    };
                                    break;
                                default:
                                    t = {
                                        disabled: !0,
                                        disabledMobile: !0,
                                        disabledDesktop: !0
                                    }
                            }
                            return t
                        },
                        imageShotsToPass: function() {
                            var t = this,
                                e = this.imageShots,
                                c = !1;
                            return Object.entries(this.imageShots).forEach((function(o, n) {
                                "object" === r()(o[1]) && (c = !0), n === Object.entries(t.imageShots).length - 1 && c && (e = {
                                    default: Object.entries(t.imageShots)[0][1].selectBox.current,
                                    hover: Object.entries(t.imageShots)[1][1].selectBox.current
                                })
                            })), e
                        }
                    },
                    methods: {
                        changeTab: function(t) {
                            this.activeTab = t, this.activeSecondaryFilter = 0
                        },
                        setSecondaryFilter: function(t) {
                            this.activeSecondaryFilter = t
                        },
                        price: function(t) {
                            return {
                                was: this.priceDisplay(t.pluDetails.price.was),
                                now: this.priceDisplay(t.pluDetails.price.now)
                            }
                        },
                        priceDisplay: function(t) {
                            return "after_price" === this.currency.location.selectBox.current ? "".concat(t).concat(this.currency.symbol) : "".concat(this.currency.symbol).concat(t)
                        }
                    }
                },
                f = (c(259), Object(h.a)(v, (function() {
                    var t = this,
                        e = t.$createElement,
                        c = t._self._c || e;
                    return c("div", {
                        class: [t.className, t.theme.selectBox.current]
                    }, [c("div", {
                        class: t.className + "__header"
                    }, [c("div", {
                        class: t.className + "__title-container"
                    }, [c("h1", {
                        class: t.className + "__title",
                        domProps: {
                            innerHTML: t._s(t.title.html.value)
                        }
                    })]), t._v(" "), c("div", {
                        class: t.className + "__tabs-container"
                    }, t._l(t.tabs, (function(e, o) {
                        return e.header.text && " " !== e.header.text ? c("div", {
                            key: o,
                            class: [t.className + "__tab", {
                                active: t.activeTab === o
                            }],
                            on: {
                                click: function(e) {
                                    t.changeTab(o)
                                }
                            }
                        }, [t.filters.primary ? c("h2", {
                            class: t.className + "__tab__primary",
                            domProps: {
                                innerHTML: t._s(e.header.text)
                            }
                        }) : t._e()]) : t._e()
                    })), 0), t._v(" "), t.filters.secondary ? c("div", {
                        class: t.className + "__tab__secondary-filters"
                    }, t._l(t.secondaryFilters, (function(e, o) {
                        return c("div", {
                            key: o,
                            class: ["secondary-filter", {
                                active: t.activeSecondaryFilter === o
                            }],
                            on: {
                                click: function(e) {
                                    t.setSecondaryFilter(o)
                                }
                            }
                        }, [t._v("\n        " + t._s(e) + "\n      ")])
                    })), 0) : t._e()]), t._v(" "), c("div", {
                        class: t.className + "__body"
                    }, [t.tabs[t.activeTab].body.products.length ? c("div", {
                        class: t.className + "__products"
                    }, [c("CarouselCE", {
                        attrs: {
                            component_id: t.$attrs.component_id + "__carousel",
                            component_index: t.$attrs.component_index + "__carousel",
                            options: t.carousel.options,
                            disabled: t.carouselActive.disabled,
                            "disabled-mobile": t.carouselActive.disabledMobile,
                            "disabled-desktop": t.carouselActive.disabledDesktop
                        }
                    }, t._l(t.products, (function(e, o) {
                        return c("Product", {
                            key: o,
                            class: ["swiper-slide", t.className + "__product", t.theme.selectBox.current],
                            attrs: {
                                component_id: t.$attrs.component_id + "__tab-" + t.tabs[t.activeTab].header.text.replace(/ /g, "-") + "__product-" + (o + 1),
                                component_index: t.$attrs.component_index + "__tab-" + t.tabs[t.activeTab].header.text.replace(/ /g, "-") + "__product-" + (o + 1),
                                "aspect-ratio": t.aspectRatio,
                                currency: t.currency,
                                product: e,
                                "quick-buy": t.quickBuy,
                                price: t.price(e),
                                "image-shots": t.imageShotsToPass
                            }
                        })
                    })), 1)], 1) : t._e(), t._v(" "), c("div", {
                        class: t.className + "__ctas-container"
                    }, t._l(t.tabs[t.activeTab].body.ctas, (function(e, o) {
                        return c("a", {
                            key: o,
                            class: [t.className + "__cta", "ga-ip"],
                            attrs: {
                                "data-ip-position": t.$attrs.component_index + "__tab-" + t.tabs[t.activeTab].header.text.replace(/ /g, "-") + "__cta-" + o,
                                "data-ip-name": e.text,
                                href: e.url
                            }
                        }, [t._v("\n        " + t._s(e.text) + "\n      ")])
                    })), 0)])])
                }), [], !1, null, null, null));
            e.default = f.exports
        }
    }
]);