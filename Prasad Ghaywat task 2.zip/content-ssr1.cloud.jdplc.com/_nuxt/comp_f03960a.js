(window.webpackJsonp = window.webpackJsonp || []).push([
    [4], {
        120: function(e, n, t) {},
        219: function(e, n, t) {
            "use strict";
            t(120)
        },
        312: function(e, n, t) {
            "use strict";
            t.r(n);
            var r = t(3),
                c = t.n(r),
                o = t(2),
                d = t.n(o),
                l = t(299),
                v = t(297),
                h = t(300),
                f = t(301),
                y = t(296),
                m = t(89),
                x = t(99),
                P = {
                    name: "SsrPage",
                    components: {
                        DynamicLoop: l.default,
                        ListingBanner: v.default,
                        SizeGuide: h.default,
                        UspBanner: f.default,
                        Navigation: y.default
                    },
                    data: function() {
                        return {
                            page: null,
                            banner: null,
                            sizeGuide: null,
                            usp: null,
                            navigation: null,
                            statusCode: "test",
                            queryParams: {
                                site: "",
                                country: "",
                                channel: "",
                                page: "",
                                environment: "",
                                listingsBanner: !1
                            },
                            bannerDevice: "responsive",
                            navigationDevice: "responsive"
                        }
                    },
                    asyncData: function(e) {
                        return c()(d.a.mark((function n() {
                            var t, r, c, source, o, l, v, h, f, y, m, x, P, S, w, _, j, $, D, z, k, C, G, O, B, M, T, L, F, N, A, E, U, content, J;
                            return d.a.wrap((function(n) {
                                for (;;) switch (n.prev = n.next) {
                                    case 0:
                                        if (n.prev = 0, t = {
                                                source: e.query.source,
                                                page: e.query.page,
                                                country: e.query.country,
                                                environment: e.query.environment
                                            }, !e.query.listingsBanner) {
                                            n.next = 12;
                                            break
                                        }
                                        return r = e.query, c = r.country, source = r.source, o = r.url, l = r.environment, source = source.replace("site_", "").replace("app_", ""), n.next = 7, e.$axios.$get("fetchBanner?country=".concat(c, "&fascia=").concat(source, "&environment=").concat(l, "&url=").concat(o));
                                    case 7:
                                        return 0 !== (v = n.sent).length && v && v.banner && 0 !== v.banner.length || e.redirect(404, "/not-found"), n.abrupt("return", {
                                            banner: v.banner[0],
                                            bannerDevice: e.query.channel.toLowerCase()
                                        });
                                    case 12:
                                        if (!e.query.sizeGuide) {
                                            n.next = 24;
                                            break
                                        }
                                        return h = e.query, f = h.fascia, y = h.country, m = h.environment, x = h.brand, P = h.gender, S = h.category, w = x ? "&brand=".concat(x) : "", _ = P ? "&gender=".concat(P) : "", j = S ? "&category=".concat(S) : "", $ = "getSizeGuide/".concat(f, "/").concat(y, "/").concat(m, "/?").concat(w).concat(_).concat(j), n.next = 20, e.$axios.$get($);
                                    case 20:
                                        return D = n.sent, n.abrupt("return", {
                                            sizeGuide: D
                                        });
                                    case 24:
                                        if (!e.query.usp) {
                                            n.next = 33;
                                            break
                                        }
                                        return z = e.query, k = z.source, C = z.country, G = z.environment, O = "getUsp/".concat(k, "/").concat(C, "/").concat(G), n.next = 29, e.$axios.$get(O);
                                    case 29:
                                        return B = n.sent, n.abrupt("return", {
                                            usp: B
                                        });
                                    case 33:
                                        if (!e.query.navigation) {
                                            n.next = 42;
                                            break
                                        }
                                        return M = e.query, T = M.source, L = M.country, F = M.environment, N = "getNavigation/".concat(T, "/").concat(L, "/").concat(F, "/"), n.next = 38, e.$axios.$get(N);
                                    case 38:
                                        return A = n.sent, n.abrupt("return", {
                                            navigation: A,
                                            navigationDevice: e.query.channel || "responsive"
                                        });
                                    case 42:
                                        if (!1 !== Object.values(t).includes(void 0)) {
                                            n.next = 50;
                                            break
                                        }
                                        return n.next = 45, e.$axios.$get("getContent/sites/".concat(t.source, "/").concat(t.page, "/").concat(t.country, "/").concat(t.environment));
                                    case 45:
                                        return E = n.sent, e.query.channel & E.foundPage && (E.foundPage.channel = e.query.channel || "responsive"), U = E.foundPage ? E.foundPage : "null", content = U.content, J = U.channel, 0 === E.length && e.redirect("/not-found"), n.abrupt("return", {
                                            page: E,
                                            content: content,
                                            channel: J
                                        });
                                    case 50:
                                        return n.abrupt("return");
                                    case 51:
                                        n.next = 56;
                                        break;
                                    case 53:
                                        n.prev = 53, n.t0 = n.catch(0), n.t0.response && 404 === n.t0.response.status && (console.log("Couldn't detect content requested: ", n.t0.response.data), e.redirect(404, "/not-found"));
                                    case 56:
                                    case "end":
                                        return n.stop()
                                }
                            }), n, null, [
                                [0, 53]
                            ])
                        })))()
                    },
                    mounted: function() {
                        if (this.page && (this.addStylesFromStyleManager(), this.addScriptsFromScriptManager()), this.navigation) {
                            var e = 18e5,
                                n = new Date(Math.round((new Date).getTime() / e) * e).getTime();
                            Object(m.b)("https://jdsports-client-resources.co.uk/jdsports-client-resources/front-end-dev/styles/top-nav/nav-amends.css?".concat(n))
                        }
                        if (this.banner) {
                            var t = 18e5,
                                r = new Date(Math.round((new Date).getTime() / t) * t).getTime();
                            Object(m.b)("https://jdsports-client-resources.co.uk/jdsports-client-resources/front-end-dev/styles/listing-banners/listing-banner-amends.css?".concat(r))
                        }
                    },
                    methods: {
                        addStylesFromStyleManager: function() {
                            Object(m.c)(), this.page.foundPage.stylesheets && this.page.foundPage.stylesheets.length && this.page.foundPage.stylesheets.forEach((function(e) {
                                Object(m.b)(e)
                            })), this.page.foundPage.customStyles && this.page.foundPage.customStyles.length && Object(m.a)(this.page.foundPage.customStyles)
                        },
                        addScriptsFromScriptManager: function() {
                            Object(x.c)(), this.page.foundPage.scripts && this.page.foundPage.scripts.length && this.page.foundPage.scripts.forEach((function(script) {
                                Object(x.b)(script)
                            })), this.page.foundPage.customScripts && this.page.foundPage.customScripts.length && Object(x.a)(this.page.foundPage.customScripts)
                        }
                    }
                },
                S = (t(219), t(10)),
                component = Object(S.a)(P, (function() {
                    var e = this,
                        n = e.$createElement,
                        t = e._self._c || n;
                    return t("div", {
                        attrs: {
                            id: "nav" === e.$config.vueAppComp ? "app-nav" : "app"
                        }
                    }, [t("div", {
                        attrs: {
                            id: "nav" === e.$config.vueAppComp ? "editor-nav" : "editor"
                        }
                    }, [t("div", {
                        attrs: {
                            id: "nav" === e.$config.vueAppComp ? "ssr-nav" : "ssr"
                        }
                    }, [e.page ? t("DynamicLoop", {
                        attrs: {
                            content: e.content,
                            channel: e.channel
                        }
                    }) : e._e(), e._v(" "), e.banner ? t("ListingBanner", {
                        staticClass: "banner",
                        attrs: {
                            "banner-data": e.banner,
                            "display-channel": e.bannerDevice,
                            "mesh-styles": ""
                        }
                    }) : e._e(), e._v(" "), e.sizeGuide ? t("SizeGuide", {
                        staticClass: "size-guide__outer",
                        attrs: {
                            brands: e.sizeGuide.content.brands,
                            generic: e.sizeGuide.content.generic,
                            theme: e.sizeGuide.content.theme,
                            title: e.sizeGuide.content.title
                        }
                    }) : e._e(), e._v(" "), e.usp ? t("UspBanner", {
                        staticClass: "usp-banner",
                        attrs: {
                            "usp-bars": e.usp.content.uspBars,
                            colours: e.usp.content.colours,
                            "delay-time": e.usp.content.delayTime,
                            "open-in-new-tab": e.usp.content.openInNewTab,
                            theme: e.usp.content.theme,
                            title: e.usp.content.title,
                            "usp-width": e.usp.content.uspWidth
                        }
                    }) : e._e(), e._v(" "), e.navigation ? t("Navigation", {
                        staticClass: "top-nav",
                        class: e.navigation.country,
                        attrs: {
                            content: e.navigation.content,
                            "display-channel": e.navigationDevice
                        }
                    }) : e._e()], 1)])])
                }), [], !1, null, null, null);
            n.default = component.exports
        }
    }
]);