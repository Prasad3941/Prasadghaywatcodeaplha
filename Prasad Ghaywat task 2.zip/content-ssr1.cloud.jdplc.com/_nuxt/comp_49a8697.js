(window.webpackJsonp = window.webpackJsonp || []).push([
    [22, 53], {
        176: function(t, e, o) {},
        274: function(t, e, o) {
            "use strict";
            o(176)
        },
        354: function(t, e, o) {
            "use strict";
            o.r(e);
            var n = o(6),
                l = o.n(n),
                r = o(69),
                c = o(87),
                d = o(70),
                v = {
                    name: "SpotList",
                    components: {
                        Picture: r.default,
                        VideoSpot: c.default
                    },
                    mixins: [d.a],
                    props: {
                        title: {
                            type: String,
                            default: "SpotList"
                        },
                        titleUrl: {
                            type: String,
                            default: ""
                        },
                        spotListSpots: {
                            type: Array,
                            default: function() {
                                return [{
                                    images: {
                                        desktop: "https://i1.adis.ws/i/jpl/desktop_single_middlespot_11-a0dc26a94028f04a20a5a86e9940a44b?qlt=80",
                                        mobile: "https://i1.adis.ws/i/jpl/mobile_spot11-3de2bf8f7e2067656312a9b345a41016?qlt=80"
                                    },
                                    url: {
                                        desktop: "/desktop-spot-link",
                                        mobile: "/mobile-spot-link"
                                    },
                                    aspectRatio: {
                                        desktop: "640:640",
                                        mobile: "750:448"
                                    },
                                    videoToggle: !1,
                                    videoOptions: {
                                        popUp: !1,
                                        videos: {
                                            desktop: "https://i1.adis.ws/v/jpl/JD_Home_Page",
                                            mobile: ""
                                        },
                                        overlayImage: {
                                            desktop: "https://via.placeholder.com/640/?text=Desktop+Video+Image",
                                            mobile: "https://via.placeholder.com/640/?text=Mobile+Video+Image"
                                        },
                                        aspectRatio: {
                                            desktop: {
                                                width: "640",
                                                height: "640"
                                            },
                                            mobile: {
                                                width: "640",
                                                height: "640"
                                            }
                                        },
                                        overlay: {
                                            text: {
                                                html: {
                                                    value: "<h1>Overlay Text</h1><p>This is the text shown when the video is paused.</p>"
                                                }
                                            },
                                            ctas: [{
                                                text: "CTA Button",
                                                url: "/default-cta-link",
                                                invert: !1
                                            }, {
                                                text: "CTA Button",
                                                url: "/default-cta-link",
                                                invert: !1
                                            }],
                                            position: {
                                                vertical: {
                                                    selectBox: {
                                                        current: "center",
                                                        options: "video_spot.position"
                                                    }
                                                },
                                                horizontal: {
                                                    selectBox: {
                                                        current: "start",
                                                        options: "video_spot.position"
                                                    }
                                                }
                                            },
                                            showOverlayImage: !0,
                                            showPlayButton: !0
                                        },
                                        theme: {
                                            selectBox: {
                                                current: "default",
                                                options: "video_spot.theme"
                                            }
                                        },
                                        settings: {
                                            controls: !0,
                                            autoplay: !1,
                                            mute: !0,
                                            loop: !1
                                        }
                                    },
                                    ctas: [{
                                        invert: !1,
                                        url: {
                                            desktop: "/desktop-cta-link",
                                            mobile: "mobile-cta-link"
                                        },
                                        text: "Shop Now",
                                        fontSize: {
                                            selectBox: {
                                                current: "18px",
                                                options: "spot_list.spots.cta.font_size"
                                            }
                                        }
                                    }],
                                    double: !1,
                                    title: "Men's Footwear",
                                    invertTitles: !1,
                                    fontSize: {
                                        selectBox: {
                                            current: "20px",
                                            options: "spot_list.spots.font_size"
                                        }
                                    }
                                }, {
                                    images: {
                                        desktop: "https://i1.adis.ws/i/jpl/desktop_single_middlespot_11-a0dc26a94028f04a20a5a86e9940a44b?qlt=80",
                                        mobile: "https://i1.adis.ws/i/jpl/mobile_spot11-3de2bf8f7e2067656312a9b345a41016?qlt=80"
                                    },
                                    url: "/men/mens-footwear/",
                                    aspectRatio: {
                                        desktop: "640:640",
                                        mobile: "750:448"
                                    },
                                    videoToggle: !1,
                                    videoOptions: {
                                        popUp: !1,
                                        videos: {
                                            desktop: "https://i1.adis.ws/v/jpl/JD_Home_Page",
                                            mobile: ""
                                        },
                                        overlayImage: {
                                            desktop: "https://via.placeholder.com/640/?text=Desktop+Video+Image",
                                            mobile: "https://via.placeholder.com/640/?text=Mobile+Video+Image"
                                        },
                                        aspectRatio: {
                                            desktop: {
                                                width: "640",
                                                height: "640"
                                            },
                                            mobile: {
                                                width: "640",
                                                height: "640"
                                            }
                                        },
                                        overlay: {
                                            text: {
                                                html: {
                                                    value: "<h1>Overlay Text</h1><p>This is the text shown when the video is paused.</p>"
                                                }
                                            },
                                            ctas: [{
                                                text: "CTA Button",
                                                url: "/default-cta-link",
                                                invert: !1
                                            }, {
                                                text: "CTA Button",
                                                url: "/default-cta-link",
                                                invert: !1
                                            }],
                                            position: {
                                                vertical: {
                                                    selectBox: {
                                                        current: "center",
                                                        options: "video_spot.position"
                                                    }
                                                },
                                                horizontal: {
                                                    selectBox: {
                                                        current: "start",
                                                        options: "video_spot.position"
                                                    }
                                                }
                                            },
                                            showOverlayImage: !0,
                                            showPlayButton: !0
                                        },
                                        theme: {
                                            selectBox: {
                                                current: "default",
                                                options: "video_spot.theme"
                                            }
                                        },
                                        settings: {
                                            controls: !0,
                                            autoplay: !1,
                                            mute: !0,
                                            loop: !1
                                        }
                                    },
                                    ctas: [{
                                        invert: !1,
                                        url: "",
                                        text: "Shop Now",
                                        fontSize: {
                                            selectBox: {
                                                current: "18px",
                                                options: "spot_list.spots.cta.font_size"
                                            }
                                        }
                                    }],
                                    double: !1,
                                    title: "Men's Footwear",
                                    invertTitles: !1,
                                    fontSize: {
                                        selectBox: {
                                            current: "20px",
                                            options: "spot_list.spots.font_size"
                                        }
                                    }
                                }]
                            }
                        },
                        componentName: {
                            type: String,
                            default: void 0
                        },
                        noWrap: {
                            type: Boolean,
                            default: !1
                        },
                        margin: {
                            type: Boolean,
                            default: !1
                        },
                        smallSize: {
                            type: Boolean,
                            default: !1
                        },
                        toggleGradient: {
                            type: Boolean,
                            default: !1
                        },
                        channel: {
                            type: String,
                            default: "responsive"
                        },
                        isLazyLoad: {
                            type: Boolean,
                            default: !0
                        }
                    },
                    methods: {
                        spotUrl: function(t) {
                            var e = "desktop";
                            return "mobile" === this.windowSize.device && (e = this.windowSize.device), "object" === l()(t.url) ? t.url[e] : t.url
                        },
                        ctaUrl: function(t, e) {
                            var o = "desktop";
                            return "mobile" === this.windowSize.device && (o = this.windowSize.device), "object" === l()(t.url) ? "" !== t.url[o] && " " !== t.url[o] ? t.url[o] : e.url[o] : "" !== t.url && " " !== t.url ? t.url : e.url
                        }
                    }
                },
                h = (o(274), o(10)),
                component = Object(h.a)(v, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        staticClass: "c-container"
                    }, [t.title && " " !== t.title ? o("div", {
                        staticClass: "title-container"
                    }, [o("a", {
                        staticClass: "spotlist-title ga-ip",
                        attrs: {
                            href: t.titleUrl,
                            "data-ip-name": t.title,
                            "data-ip-position": t.$attrs.component_index + "__title",
                            "old-ip": "true"
                        }
                    }, [t._v("\n      " + t._s(t.title) + "\n    ")])]) : t._e(), t._v(" "), o("div", {
                        staticClass: "list-container"
                    }, [o("ul", {
                        staticClass: "spot-list",
                        class: {
                            "spot-list--no-margin": !t.margin, "spot-list--small-size": t.smallSize, "spot-list--spotWrap": t.noWrap
                        }
                    }, t._l(t.spotListSpots, (function(e, n) {
                        return o("li", t._b({
                            key: n,
                            class: {
                                "is-double": e.double
                            }
                        }, "li", e, !1), [e.videoToggle ? t._e() : o("a", {
                            staticClass: "ga-ip spot-list__link",
                            attrs: {
                                href: t.spotUrl(e),
                                "data-ip-position": t.$attrs.component_index + "__spot-" + (n + 1),
                                "data-ip-name": e.title
                            }
                        }, [o("Picture", {
                            attrs: {
                                image: e.images,
                                "aspect-ratio": e.aspectRatio.desktop,
                                "aspect-ratio-mobile": e.aspectRatio.mobile,
                                channel: t.channel,
                                "is-lazy-load": t.isLazyLoad
                            }
                        })], 1), t._v(" "), e.videoToggle ? o("VideoSpot", {
                            attrs: {
                                theme: e.videoOptions.theme,
                                "pop-up": e.videoOptions.popUp,
                                videos: e.videoOptions.videos,
                                images: e.videoOptions.overlayImage,
                                overlay: t.overlay,
                                "aspect-ratio": e.videoOptions.aspectRatio,
                                settings: e.videoOptions.settings
                            }
                        }) : t._e(), t._v(" "), e.videoToggle ? t._e() : o("a", {
                            staticClass: "spot-list__cta",
                            class: [{
                                "spot-list__cta--title": e.title,
                                "spot-list__gradient-overlay": t.toggleGradient,
                                "spot-list__cta--is-small": t.smallSize,
                                "spot-list__cta--no-wrap": t.noWrap,
                                "spot-list__cta--wrap": !t.noWrap,
                                "spot-list__cta-invert-title": e.invertTitles
                            }, "ga-ip"],
                            attrs: {
                                href: t.spotUrl(e),
                                "data-ip-position": t.$attrs.component_index + "__spot-" + (n + 1) + "__ctas-container",
                                "data-ip-name": e.title
                            }
                        }, [e.title ? o("strong", {
                            staticClass: "spot-list__cta__title",
                            style: {
                                fontSize: e.fontSize.selectBox.current
                            }
                        }, [t._v(t._s(e.title))]) : t._e(), t._v(" "), o("div", {
                            staticClass: "spot-list__ctas-container"
                        }, t._l(e.ctas, (function(l, r) {
                            return o("a", t._b({
                                key: l.url,
                                staticClass: "btn ga-ip",
                                attrs: {
                                    href: t.ctaUrl(l, e),
                                    "data-ip-position": t.$attrs.component_index + "__spot-" + (n + 1) + "__cta-" + (r + 1),
                                    "data-ip-name": l.text
                                }
                            }, "a", e, !1), [o("div", {
                                staticClass: "text-container"
                            }, [o("div", {
                                class: ["text-container-inner", {
                                    "btn--invert": l.invert,
                                    "not--inverted": !l.invert
                                }],
                                style: {
                                    fontSize: l.fontSize.selectBox.current
                                }
                            }, [t._v("\n                  " + t._s(l.text) + "\n                ")])])])
                        })), 0)])], 1)
                    })), 0)])])
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        80: function(t, e, o) {},
        87: function(t, e, o) {
            "use strict";
            o.r(e);
            var n = o(6),
                l = o.n(n),
                r = o(70),
                c = {
                    name: "VideoSpot",
                    components: {
                        Picture: o(69).default
                    },
                    mixins: [r.a],
                    props: {
                        theme: {
                            type: Object,
                            default: function() {
                                return {
                                    selectBox: {
                                        current: "default",
                                        options: "video_spot.theme"
                                    }
                                }
                            }
                        },
                        videos: {
                            type: Object,
                            default: function() {
                                return {
                                    desktop: "https://i1.adis.ws/v/jpl/JD_Home_Page",
                                    mobile: "https://www.youtube.com/watch?v=OStGEbJI-ek"
                                }
                            }
                        },
                        images: {
                            type: Object,
                            default: function() {
                                return {
                                    desktop: "https://via.placeholder.com/1280x720/?text=Desktop+Video+Image",
                                    mobile: "https://via.placeholder.com/640/?text=Mobile+Video+Image"
                                }
                            }
                        },
                        overlay: {
                            type: [Object],
                            default: function() {
                                return {
                                    text: {
                                        html: {
                                            value: "<h1>Overlay Text</h1><p>This is the text shown when the video is paused.</p>"
                                        }
                                    },
                                    ctas: [{
                                        text: "CTA Button",
                                        url: "/default-cta-link",
                                        invert: !1
                                    }, {
                                        text: "CTA Button",
                                        url: "/default-cta-link",
                                        invert: !1
                                    }],
                                    position: {
                                        vertical: {
                                            selectBox: {
                                                current: "center",
                                                options: "video_spot.position"
                                            }
                                        },
                                        horizontal: {
                                            selectBox: {
                                                current: "start",
                                                options: "video_spot.position"
                                            }
                                        }
                                    },
                                    showOverlayImage: !0,
                                    showPlayButton: !0
                                }
                            }
                        },
                        aspectRatio: {
                            type: Object,
                            default: function() {
                                return {
                                    desktop: {
                                        width: "1280",
                                        height: "720"
                                    },
                                    mobile: {
                                        width: "640",
                                        height: "640"
                                    }
                                }
                            }
                        },
                        popUp: {
                            type: Boolean,
                            default: !1
                        },
                        settings: {
                            type: Object,
                            default: function() {
                                return {
                                    controls: !0,
                                    autoplay: !1,
                                    mute: !0,
                                    loop: !1
                                }
                            }
                        }
                    },
                    data: function() {
                        return {
                            className: "video-spot",
                            isPlaying: !1,
                            popUpOpen: !1
                        }
                    },
                    computed: {
                        overlayText: function() {
                            return "object" === l()(this.overlay.text) ? this.overlay.text.html.value : this.overlay.text
                        },
                        currentDevice: function() {
                            return this.windowSize.device
                        },
                        uniqueId: function() {
                            return "".concat(this.className, "_").concat(this._uid)
                        },
                        hasVideo: function() {
                            return !(!this.video || " " === this.video)
                        },
                        video: function() {
                            return "tablet" === this.windowSize.device ? this.videos.desktop : this.videos[this.windowSize.device]
                        },
                        image: function() {
                            return "tablet" === this.windowSize.device ? this.images.desktop : this.images[this.windowSize.device]
                        },
                        videoUrl: function() {
                            if (this.hasVideo) {
                                if (this.embedVideo) {
                                    if (this.isYouTubeLink) {
                                        var t = this.video.replace("/watch?v=", "/embed/");
                                        return this.settings.autoplay ? "".concat(t, "?autoplay=1") : t
                                    }
                                    return this.video
                                }
                                return ["".concat(this.video, "/mp4_720p?protocol=https"), "".concat(this.video, "/webm_720p?protocol=https"), "".concat(this.video, "/mp4_480p?protocol=https"), "".concat(this.video, "/webm_480p?protocol=https"), "".concat(this.video, "/mp4_240p?protocol=https"), "".concat(this.video, "/webm_240p?protocol=https")]
                            }
                            return " "
                        },
                        isYouTubeLink: function() {
                            return this.video.includes("youtube")
                        },
                        videoRatio: function() {
                            return !!this.windowSize.device && ("tablet" === this.windowSize.device ? this.aspectRatio.desktop : this.aspectRatio[this.windowSize.device])
                        },
                        currentAspectPadding: function() {
                            var t = this.videoRatio.height / this.videoRatio.width * 100;
                            return "".concat(t, "%")
                        },
                        imageRatio: function() {
                            return "".concat(this.videoRatio.width, ":").concat(this.videoRatio.height).replace(/px/g, "").replace(/%/g, "").replace(/rem/g, "").replace(/em/g, "")
                        },
                        embedVideo: function() {
                            return !(!this.video.includes("youtube") && !this.video.includes("smartzer"))
                        },
                        showOverlay: function() {
                            return !!this.popUpOpen || !this.isPlaying
                        }
                    },
                    watch: {
                        currentDevice: function() {
                            this.$forceUpdate()
                        },
                        isPlaying: function(t) {
                            t ? this.isYouTubeLink || this.$refs.videoRef.play() : this.isYouTubeLink || this.$refs.videoRef.pause()
                        }
                    },
                    mounted: function() {
                        this.settings.autoplay && this.video && (this.isPlaying = !0)
                    },
                    methods: {
                        mimeType: function(t) {
                            return t.includes("mp4_") ? "video/mp4" : "video/webm"
                        }
                    }
                },
                d = (o(93), o(10)),
                component = Object(d.a)(c, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        class: [t.className + "__outer", t.theme.selectBox.current]
                    }, [t.hasVideo ? o("div", {
                        class: [t.className, t.windowSize.device],
                        style: {
                            paddingBottom: t.currentAspectPadding
                        },
                        on: {
                            click: function() {
                                t.popUp && (t.popUpOpen = !t.popUpOpen)
                            }
                        }
                    }, [t.showOverlay ? o("div", {
                        class: t.className + "__overlay",
                        on: {
                            click: function(e) {
                                t.isPlaying = !0
                            }
                        }
                    }, [o("div", {
                        class: [t.className + "__overlay__items", "horizontal--" + t.overlay.position.horizontal.selectBox.current, "vertical--" + t.overlay.position.vertical.selectBox.current]
                    }, [o("div", {
                        class: [t.className + "__overlay__text", "horizontal--" + t.overlay.position.horizontal.selectBox.current],
                        domProps: {
                            innerHTML: t._s(t.overlayText)
                        }
                    }), t._v(" "), t.overlay.ctas.length ? o("div", {
                        class: t.className + "__overlay__ctas"
                    }, t._l(t.overlay.ctas, (function(e, n) {
                        return o("a", {
                            key: n,
                            class: [t.className + "__overlay__cta", "ga-ip", {
                                invert: e.invert
                            }],
                            attrs: {
                                "data-ip-position": t.$attrs.index + "__cta-" + (n + 1),
                                "data-ip-name": e.text,
                                href: e.url
                            },
                            domProps: {
                                innerHTML: t._s(e.text)
                            }
                        })
                    })), 0) : t._e()]), t._v(" "), t.overlay.showPlayButton ? o("div", {
                        class: t.className + "__overlay__play-btn",
                        on: {
                            click: function(e) {
                                t.isPlaying = !0
                            }
                        }
                    }, [o("svg", {
                        staticClass: "btn--play",
                        attrs: {
                            width: "188",
                            height: "188",
                            viewBox: "0 0 188 188"
                        }
                    }, [o("circle", {
                        staticClass: "btn--play-circle cls-1",
                        attrs: {
                            cx: "94",
                            cy: "94",
                            r: "68"
                        }
                    }), t._v(" "), o("path", {
                        staticClass: "btn--play-triangle",
                        attrs: {
                            d: "M109,94.512l-25.006,14.5V80.009Z"
                        }
                    })])]) : t._e(), t._v(" "), t.overlay.showOverlayImage ? o("Picture", {
                        class: t.className + "__overlay__image",
                        attrs: {
                            component_id: t.$attrs.component_id + "__picture",
                            component_index: t.$attrs.component_index + "__picture",
                            image: t.image,
                            "aspect-ratio": t.imageRatio,
                            "aspect-ratio-mobile": t.imageRatio
                        }
                    }) : t._e()], 1) : t._e(), t._v(" "), o("div", {
                        class: [t.className + "-container", {
                            "pop-up": t.popUpOpen
                        }],
                        on: {
                            click: function() {
                                t.isPlaying = !1
                            }
                        }
                    }, [t.popUpOpen ? o("div", {
                        class: t.className + "__pop-up__close-btn",
                        domProps: {
                            innerHTML: t._s("&#215;")
                        },
                        on: {
                            click: function() {
                                t.isPlaying = !1
                            }
                        }
                    }) : t._e(), t._v(" "), t.embedVideo ? t._e() : o("video", {
                        ref: "videoRef",
                        class: [t.className + "_html5", t.uniqueId, {
                            "pop-up": t.popUpOpen
                        }],
                        attrs: {
                            controls: t.settings.controls,
                            autoplay: t.settings.autoplay,
                            poster: t.image,
                            loop: t.settings.loop,
                            playsinline: ""
                        },
                        domProps: {
                            muted: t.settings.mute
                        },
                        on: {
                            pause: function(e) {
                                t.isPlaying = !1
                            },
                            play: function(e) {
                                t.isPlaying = !0
                            }
                        }
                    }, t._l(t.videoUrl, (function(e) {
                        return o("source", {
                            key: e,
                            attrs: {
                                src: e,
                                type: t.mimeType(e)
                            }
                        })
                    })), 0), t._v(" "), t.embedVideo ? o("iframe", {
                        class: [t.className + "_youtube", t.uniqueId, {
                            "pop-up": t.popUpOpen
                        }],
                        attrs: {
                            src: t.videoUrl,
                            frameborder: "0",
                            allow: "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture",
                            allowfullscreen: ""
                        }
                    }) : t._e()])]) : t._e()])
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        93: function(t, e, o) {
            "use strict";
            o(80)
        }
    }
]);