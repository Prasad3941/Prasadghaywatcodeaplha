(window.webpackJsonp = window.webpackJsonp || []).push([
    [86], {
        327: function(t, e, l) {
            "use strict";
            l.r(e);
            var n = {
                    name: "CustomHtml",
                    props: {
                        code: {
                            type: Object,
                            default: function() {
                                return {
                                    html: {
                                        value: '<div class="custom-html__text">Custom HTML</div>'
                                    }
                                }
                            }
                        }
                    },
                    data: function() {
                        return {
                            className: "custom-html"
                        }
                    },
                    computed: {
                        htmlCode: function() {
                            return this.code.html.value && " " !== this.code.html.value ? this.code.html.value : ""
                        }
                    }
                },
                o = l(10),
                component = Object(o.a)(n, (function() {
                    var t = this,
                        e = t.$createElement;
                    return (t._self._c || e)("div", {
                        class: t.className,
                        domProps: {
                            innerHTML: t._s(t.htmlCode)
                        }
                    })
                }), [], !1, null, null, null);
            e.default = component.exports
        }
    }
]);