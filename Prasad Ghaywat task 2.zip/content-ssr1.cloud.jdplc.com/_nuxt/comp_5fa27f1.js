(window.webpackJsonp = window.webpackJsonp || []).push([
    [0, 53], {
        127: function(t, e, o) {},
        226: function(t, e, o) {
            "use strict";
            o(127)
        },
        73: function(t, e, o) {
            "use strict";
            o.r(e);
            var n = o(6),
                r = o.n(n),
                l = o(70),
                c = o(69),
                d = o(87),
                h = {
                    name: "CarouselCE",
                    components: {
                        Picture: c.default,
                        VideoSpot: d.default
                    },
                    mixins: [l.a],
                    props: {
                        options: {
                            type: Object,
                            default: function() {
                                return {
                                    slidesPerView: 1,
                                    spaceBetween: 0,
                                    freeMode: !1
                                }
                            }
                        },
                        slides: {
                            type: Array,
                            default: function() {
                                return [{
                                    title: "Slide 01",
                                    url: "",
                                    images: {
                                        desktop: "https://via.placeholder.com/1160x485/ACE0AC/FFF/?text=+",
                                        mobile: "https://via.placeholder.com/640/ACE0AC/FFF/?text=+"
                                    },
                                    videos: {
                                        desktop: "https://i1.adis.ws/v/jpl/JDXM_60s",
                                        mobile: "https://i1.adis.ws/v/jpl/JDXM_60s_SQUARE",
                                        popUp: !1
                                    },
                                    text: "CarouselCE - First Slide",
                                    ctas: [{
                                        text: "CTA 01",
                                        url: "/slide-01_cta-01"
                                    }, {
                                        text: "CTA 02",
                                        url: "/slide-01_cta-02"
                                    }, {
                                        text: "CTA 03",
                                        url: "/slide-01_cta-03"
                                    }]
                                }, {
                                    title: {
                                        html: {
                                            value: "Slide 02"
                                        }
                                    },
                                    url: "",
                                    images: {
                                        desktop: "https://via.placeholder.com/1160x485/adadff/FFF/?text=+",
                                        mobile: "https://via.placeholder.com/640/adadff/FFF/?text=+"
                                    },
                                    text: {
                                        html: {
                                            value: "CarouselCE - Second Slide"
                                        }
                                    },
                                    ctas: [{
                                        text: "CTA 01",
                                        url: "/slide-02_cta-01"
                                    }, {
                                        text: "CTA 02",
                                        url: "/slide-02_cta-02"
                                    }]
                                }, {
                                    title: "Slide 03",
                                    url: "/slide-03",
                                    images: {
                                        desktop: "https://via.placeholder.com/1160x485/aa4444/FFF/?text=+",
                                        mobile: "https://via.placeholder.com/640/aa4444/FFF/?text=+"
                                    },
                                    text: "CarouselCE - Third Slide - (Entire slide clickable)",
                                    ctas: [{
                                        text: "CTA 01",
                                        url: "/slide-03_cta-01"
                                    }, {
                                        text: "CTA 02",
                                        url: "/slide-03_cta-02"
                                    }, {
                                        text: "CTA 03",
                                        url: "/slide-03_cta-03"
                                    }]
                                }]
                            }
                        },
                        defaultAspectRatio: {
                            type: Object,
                            default: function() {
                                return {
                                    desktop: "1160:485",
                                    mobile: "640:640"
                                }
                            }
                        },
                        disabled: {
                            type: Boolean,
                            default: !1
                        },
                        disabledDesktop: {
                            type: Boolean,
                            default: !1
                        },
                        disabledMobile: {
                            type: Boolean,
                            default: !1
                        },
                        template: {
                            type: String,
                            default: "default"
                        },
                        context: {
                            type: String,
                            default: "carousel-ce"
                        },
                        reInitCarouselOnClick: {
                            default: !1,
                            type: Boolean
                        },
                        arrows: {
                            type: Object,
                            default: function() {
                                return {
                                    buttons: {
                                        prev: "&#8249;",
                                        next: "&#8250;"
                                    },
                                    fontColor: "white",
                                    showBackground: !0,
                                    backgroundColor: "rgba(150, 150, 150, .5)",
                                    fontSize: {
                                        selectBox: {
                                            current: "2rem",
                                            options: "carousel_ce.arrows.font_size"
                                        }
                                    },
                                    position: {
                                        horizontal: "0",
                                        vertical: "0"
                                    },
                                    hideMobile: !1
                                }
                            }
                        },
                        color: {
                            type: String,
                            default: "black"
                        },
                        textAlignment: {
                            type: Object,
                            default: function() {
                                return {
                                    title: "center",
                                    text: "center"
                                }
                            }
                        },
                        maxWidth: {
                            type: String,
                            default: "100vw"
                        },
                        ctaProperties: {
                            type: Object,
                            default: function() {
                                return {
                                    color: "",
                                    backgroundColor: "",
                                    borderColor: "",
                                    fontSize: {
                                        selectBox: {
                                            current: "1rem",
                                            options: "carousel_ce.cta.font_size"
                                        }
                                    },
                                    fontWeight: "400",
                                    type: {
                                        selectBox: {
                                            current: "default",
                                            options: "carousel_ce.cta.type"
                                        }
                                    },
                                    alignment: "center",
                                    hideMobile: !1
                                }
                            }
                        },
                        pagination: {
                            type: Object,
                            default: function() {
                                return {
                                    show: !0,
                                    showOnMobile: !0,
                                    position: "0"
                                }
                            }
                        },
                        channel: {
                            type: String,
                            default: "responsive"
                        },
                        isLazyLoad: {
                            type: Boolean,
                            default: !0
                        }
                    },
                    data: function() {
                        return {
                            swiper: !1,
                            test: !1,
                            defaultOptions: {
                                lazy: !0,
                                preloadImages: !1,
                                observer: !0,
                                watchOverflow: !0,
                                pagination: {
                                    type: "bullets",
                                    clickable: "true"
                                }
                            }
                        }
                    },
                    computed: {
                        carouselOptions: function() {
                            var t = JSON.parse(JSON.stringify(this.defaultOptions));
                            return t.pagination.el = ".pagination-".concat(this._uid), t.navigation = {
                                nextEl: "#carousel-".concat(this._uid, " .btn--next"),
                                prevEl: "#carousel-".concat(this._uid, " .btn--prev")
                            }, Object.assign(t, this.options)
                        },
                        textStyles: function() {
                            return {
                                color: this.color
                            }
                        },
                        alignCtas: function() {
                            return this.calcAlignment(this.ctaProperties.alignment)
                        },
                        alignTitle: function() {
                            return this.calcAlignment(this.textAlignment.title)
                        },
                        alignText: function() {
                            return this.calcAlignment(this.textAlignment.text)
                        },
                        ctaStyles: function() {
                            return {
                                color: this.ctaProperties.color,
                                backgroundColor: this.ctaProperties.backgroundColor,
                                borderColor: this.ctaProperties.borderColor,
                                fontSize: this.ctaProperties.fontSize.selectBox.current,
                                fontWeight: this.ctaProperties.fontWeight
                            }
                        },
                        maxWidthDesktopOnly: function() {
                            return "mobile" !== this.windowSize.device ? this.maxWidth : "1000rem"
                        },
                        windowDevice: function() {
                            return this.windowSize.device
                        },
                        aspectRatio: function() {
                            return {
                                desktop: {
                                    width: this.defaultAspectRatio.desktop.split(":")[0],
                                    height: this.defaultAspectRatio.desktop.split(":")[1]
                                },
                                mobile: {
                                    width: this.defaultAspectRatio.mobile.split(":")[0],
                                    height: this.defaultAspectRatio.mobile.split(":")[0]
                                }
                            }
                        }
                    },
                    watch: {
                        disabled: function() {
                            this.disabled ? this.disabled && this.destroyCarousel() : (this.enableCarousel(), this.reInitCarousel())
                        },
                        options: {
                            handler: function() {
                                this.carouselOptionsUpdated()
                            },
                            deep: !0
                        },
                        windowDevice: function() {
                            var t = this;
                            setTimeout((function() {
                                t.enableCarousel(), "mobile" === t.windowDevice && t.disabledMobile && t.destroyCarousel()
                            }), 700)
                        }
                    },
                    updated: function() {
                        this.reInitCarouselOnClick && this.reInitCarousel()
                    },
                    mounted: function() {
                        this.reInitCarousel()
                    },
                    methods: {
                        buttonClicked: function(t) {
                            this.$emit("button-clicked", t)
                        },
                        carouselOptionsUpdated: function() {
                            this.reInitCarousel()
                        },
                        enableCarousel: function() {
                            var t = this;
                            if (!1 === this.swiper || "object" === r()(this.swiper) && !0 === this.swiper.destroyed) {
                                var e = o(83).Swiper;
                                this.swiper = new e("#carousel-".concat(this._uid, " .swiper-container"), this.carouselOptions);
                                var n = document.querySelectorAll(".".concat(this.$attrs.component_id, " .swiper-slide"));
                                this.$nextTick((function() {
                                    n.forEach((function(e) {
                                        t.disabled && "mobile" !== t.windowDevice || t.disabledMobile && "mobile" === t.windowDevice ? e.classList.add("swiper-no-swiping") : e.classList.remove("swiper-no-swiping")
                                    }))
                                })), !0 !== this.options.loop && !0 !== this.defaultOptions.loop || this.swiper && (this.swiper.on("reachEnd", (function() {
                                    t.goTo(0)
                                })), this.swiper.on("reachBeginning", (function() {
                                    t.goTo(t.slides.length - 1)
                                })))
                            }
                        },
                        destroyCarousel: function() {
                            this.swiper && !this.swiper.destroyed && this.swiper.destroy()
                        },
                        reInitCarousel: function() {
                            this.disabled || (this.destroyCarousel(), this.enableCarousel())
                        },
                        goTo: function(t) {
                            this.carouselOptions.loop && (t += 1), this.$emit("swiper-index", t), this.swiper.slideTo(t)
                        },
                        checkLinkActive: function(link) {
                            return "" !== link && "false" !== link && "inactive" !== link && link
                        },
                        paginationClassName: function() {
                            return ".pagination-".concat(this.context)
                        },
                        addArrowStyles: function(t, e) {
                            var o = {};
                            return o.color = this.arrows.fontColor || "black", this.arrows.showBackground && (o.backgroundColor = this.arrows.backgroundColor), "&#8249;" !== this.arrows.buttons.prev && "&#8250;" !== this.arrows.buttons.next || (o.fontSize = "28px", o.paddingBottom = ".3rem", o[e] = ".2rem"), this.arrows.fontSize.selectBox.current && (o.fontSize = this.arrows.fontSize.selectBox.current), o[t] = this.arrows.position.horizontal, o.top = this.arrows.position.vertical, o
                        },
                        paginationStyles: function() {
                            var t = {};
                            return this.pagination.position && (t.bottom = this.pagination.position), t
                        },
                        calcAlignment: function(t) {
                            if ("mobile" !== this.windowSize.device) {
                                if ("left" === t.toLowerCase()) return {
                                    left: "2rem",
                                    right: "auto",
                                    transform: "translateX(0)"
                                };
                                if ("right" === t.toLowerCase()) return {
                                    left: "auto",
                                    right: "2rem",
                                    transform: "translateX(0)"
                                }
                            }
                            return {
                                left: "50%"
                            }
                        },
                        showVideo: function(t) {
                            return !!(this.slides[t].videos && this.slides[t].videos.desktop && this.slides[t].videos.mobile && " " !== this.slides[t].videos.desktop && " " !== this.slides[t].videos.mobile)
                        },
                        currentSlideTitle: function(t) {
                            var e = this.slides[t];
                            return "object" === r()(e.title) ? e.title.html.value : e.title
                        },
                        currentSlideText: function(t) {
                            var e = this.slides[t];
                            return "object" === r()(e.text) ? e.text.html.value : e.text
                        },
                        slideImgUrl: function(t) {
                            return t ? "mobile" === this.windowDevice ? t.mobile : t.desktop : ""
                        }
                    }
                },
                f = (o(226), o(10)),
                component = Object(f.a)(h, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        class: ["ce-carousel", {
                            disabled: t.disabled || "mobile" === t.windowDevice && t.disabledMobile || "desktop" === t.windowDevice && t.disabledDesktop || "tablet" === t.windowDevice && t.disabledDesktop
                        }],
                        style: {
                            maxWidth: t.maxWidthDesktopOnly
                        },
                        attrs: {
                            id: "carousel-" + t._uid
                        }
                    }, [t.$slots.default ? t._e() : o("div", {
                        directives: [{
                            name: "swiper",
                            rawName: "v-swiper:CarouselCESsr",
                            value: t.carouselOptions,
                            expression: "carouselOptions",
                            arg: "CarouselCESsr"
                        }],
                        class: ["swiper-container", "swiper-" + t._uid]
                    }, [o("div", {
                        staticClass: "swiper-wrapper"
                    }, t._l(t.slides, (function(e, n) {
                        return o("div", {
                            key: n,
                            ref: "swiper-slide",
                            refInFor: !0,
                            staticClass: "swiper-slide"
                        }, [o("a", {
                            class: ["slide-inner", "slide-" + n, "ga-ip"],
                            attrs: {
                                "data-ip-position": t.$attrs.component_index + "__slide-" + (n + 1),
                                "data-ip-name": t.slideImgUrl(e.images),
                                href: t.checkLinkActive(e.url)
                            }
                        }, [e.title && !t.showVideo(n) ? o("h1", {
                            staticClass: "slide-title",
                            style: [t.textStyles, t.alignTitle],
                            domProps: {
                                innerHTML: t._s(t.currentSlideTitle(n))
                            }
                        }) : t._e(), t._v(" "), e.images && !t.showVideo(n) ? o("Picture", {
                            staticClass: "slide-image",
                            attrs: {
                                component_id: t.$attrs.component_id + "__slide-" + (n + 1) + "__picture",
                                component_index: t.$attrs.component_index + "__slide-" + (n + 1) + "__picture",
                                image: e.images,
                                "aspect-ratio": t.defaultAspectRatio.desktop,
                                "aspect-ratio-mobile": t.defaultAspectRatio.mobile,
                                channel: t.channel,
                                "is-lazy-load": t.isLazyLoad
                            }
                        }) : t._e(), t._v(" "), e.videos && t.showVideo(n) ? o("VideoSpot", {
                            attrs: {
                                component_id: t.$attrs.component_id + "__slide-" + (n + 1) + "__video-spot",
                                component_index: t.$attrs.component_index + "__slide-" + (n + 1) + "__video-spot",
                                videos: e.videos,
                                images: e.images,
                                "aspect-ratio": t.aspectRatio,
                                "pop-up": e.videos.popUp,
                                overlay: {
                                    text: {
                                        html: {
                                            value: e.title
                                        }
                                    },
                                    ctas: e.ctas,
                                    position: {
                                        vertical: {
                                            selectBox: {
                                                current: "center",
                                                options: "video_spot.position"
                                            }
                                        },
                                        horizontal: {
                                            selectBox: {
                                                current: "start",
                                                options: "video_spot.position"
                                            }
                                        }
                                    },
                                    showOverlayImage: !0,
                                    showPlayButton: !0
                                }
                            }
                        }) : t._e(), t._v(" "), e.text && !t.showVideo(n) ? o("p", {
                            staticClass: "slide-text",
                            style: [t.textStyles, t.alignText],
                            domProps: {
                                innerHTML: t._s(t.currentSlideText(n))
                            }
                        }) : t._e(), t._v(" "), e.ctas && !t.showVideo(n) ? o("div", {
                            class: ["slide-ctas__container", t.ctaProperties.type.selectBox.current, {
                                "hide-mobile": t.ctaProperties.hideMobile
                            }],
                            style: t.alignCtas
                        }, t._l(e.ctas, (function(e, r) {
                            return o("a", {
                                key: r,
                                class: ["slide-cta", "ga-ip"],
                                style: t.ctaStyles,
                                attrs: {
                                    href: t.checkLinkActive(e.url),
                                    "data-ip-position": t.$attrs.component_index + "__slide-" + (n + 1) + "__cta-" + (r + 1),
                                    "data-ip-name": e.text
                                }
                            }, [t._v("\n              " + t._s(e.text) + "\n            ")])
                        })), 0) : t._e()], 1)])
                    })), 0)]), t._v(" "), t.$slots.default ? o("div", {
                        staticClass: "swiper-container"
                    }, [o("div", {
                        staticClass: "swiper-wrapper"
                    }, [t._t("default")], 2)]) : t._e(), t._v(" "), o("div", {
                        class: ["buttons", {
                            "hide-mobile": t.arrows.hideMobile
                        }]
                    }, [o("button", {
                        staticClass: "buttons__arrow btn--prev",
                        style: t.addArrowStyles("left", "paddingRight"),
                        attrs: {
                            type: "button"
                        },
                        domProps: {
                            innerHTML: t._s(t.arrows.buttons.prev || "Prev")
                        },
                        on: {
                            click: function(e) {
                                t.buttonClicked(-1)
                            }
                        }
                    }), t._v(" "), o("button", {
                        staticClass: "buttons__arrow btn--next buttons__arrow--next",
                        style: t.addArrowStyles("right", "paddingLeft"),
                        attrs: {
                            type: "button"
                        },
                        domProps: {
                            innerHTML: t._s(t.arrows.buttons.next || "Next")
                        },
                        on: {
                            click: function(e) {
                                t.buttonClicked(1)
                            }
                        }
                    })]), t._v(" "), o("div", {
                        class: ["pagination-" + t._uid, "pagination-" + t.context, "pagination-ce", {
                            "hide-mobile": !t.pagination.showOnMobile
                        }, {
                            "hide-desktop": !t.pagination.show
                        }],
                        style: t.paginationStyles()
                    })])
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        80: function(t, e, o) {},
        83: function(t, e, o) {
            var n;
            t.exports = (n = o(39), function(t) {
                function e(i) {
                    if (o[i]) return o[i].exports;
                    var s = o[i] = {
                        i: i,
                        l: !1,
                        exports: {}
                    };
                    return t[i].call(s.exports, s, s.exports, e), s.l = !0, s.exports
                }
                var o = {};
                return e.m = t, e.c = o, e.i = function(t) {
                    return t
                }, e.d = function(t, o, i) {
                    e.o(t, o) || Object.defineProperty(t, o, {
                        configurable: !1,
                        enumerable: !0,
                        get: i
                    })
                }, e.n = function(t) {
                    var o = t && t.__esModule ? function() {
                        return t.default
                    } : function() {
                        return t
                    };
                    return e.d(o, "a", o), o
                }, e.o = function(t, e) {
                    return Object.prototype.hasOwnProperty.call(t, e)
                }, e.p = "/", e(e.s = 4)
            }([function(t, e) {
                t.exports = n
            }, function(t, e) {
                t.exports = function(t, e, o, i, s, n) {
                    var r, a = t = t || {},
                        u = typeof t.default;
                    "object" !== u && "function" !== u || (r = t, a = t.default);
                    var l, p = "function" == typeof a ? a.options : a;
                    if (e && (p.render = e.render, p.staticRenderFns = e.staticRenderFns, p._compiled = !0), o && (p.functional = !0), s && (p._scopeId = s), n ? (l = function(t) {
                            (t = t || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (t = __VUE_SSR_CONTEXT__), i && i.call(this, t), t && t._registeredComponents && t._registeredComponents.add(n)
                        }, p._ssrRegister = l) : i && (l = i), l) {
                        var c = p.functional,
                            d = c ? p.render : p.beforeCreate;
                        c ? (p._injectStyles = l, p.render = function(t, e) {
                            return l.call(e), d(t, e)
                        }) : p.beforeCreate = d ? [].concat(d, l) : [l]
                    }
                    return {
                        esModule: r,
                        exports: a,
                        options: p
                    }
                }
            }, function(t, e, o) {
                "use strict";
                Object.defineProperty(e, "__esModule", {
                    value: !0
                });
                var i = o(5),
                    s = o.n(i),
                    n = o(8),
                    a = o(1)(s.a, n.a, !1, null, null, null);
                e.default = a.exports
            }, function(t, e, o) {
                "use strict";
                Object.defineProperty(e, "__esModule", {
                    value: !0
                });
                var i = o(6),
                    s = o.n(i),
                    n = o(7),
                    a = o(1)(s.a, n.a, !1, null, null, null);
                e.default = a.exports
            }, function(t, e, o) {
                "use strict";

                function i(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.install = e.swiperSlide = e.swiper = e.Swiper = void 0;
                var n = i(o(0)),
                    a = i(o(2)),
                    p = i(o(3)),
                    r = window.Swiper || n.default,
                    l = p.default,
                    c = a.default,
                    d = function(t, e) {
                        e && (p.default.props.globalOptions.default = function() {
                            return e
                        }), t.component(p.default.name, p.default), t.component(a.default.name, a.default)
                    },
                    h = {
                        Swiper: r,
                        swiper: l,
                        swiperSlide: c,
                        install: d
                    };
                e.default = h, e.Swiper = r, e.swiper = l, e.swiperSlide = c, e.install = d
            }, function(t, e, o) {
                "use strict";
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = {
                    name: "swiper-slide",
                    data: function() {
                        return {
                            slideClass: "swiper-slide"
                        }
                    },
                    ready: function() {
                        this.update()
                    },
                    mounted: function() {
                        this.update(), this.$parent && this.$parent.options && this.$parent.options.slideClass && (this.slideClass = this.$parent.options.slideClass)
                    },
                    updated: function() {
                        this.update()
                    },
                    attached: function() {
                        this.update()
                    },
                    methods: {
                        update: function() {
                            this.$parent && this.$parent.swiper && this.$parent.update()
                        }
                    }
                }
            }, function(t, e, o) {
                "use strict";
                Object.defineProperty(e, "__esModule", {
                    value: !0
                });
                var s = function(t) {
                        return t && t.__esModule ? t : {
                            default: t
                        }
                    }(o(0)),
                    n = window.Swiper || s.default;
                "function" != typeof Object.assign && Object.defineProperty(Object, "assign", {
                    value: function(t, e) {
                        if (null == t) throw new TypeError("Cannot convert undefined or null to object");
                        for (var o = Object(t), i = 1; i < arguments.length; i++) {
                            var s = arguments[i];
                            if (null != s)
                                for (var n in s) Object.prototype.hasOwnProperty.call(s, n) && (o[n] = s[n])
                        }
                        return o
                    },
                    writable: !0,
                    configurable: !0
                });
                var r = ["beforeDestroy", "slideChange", "slideChangeTransitionStart", "slideChangeTransitionEnd", "slideNextTransitionStart", "slideNextTransitionEnd", "slidePrevTransitionStart", "slidePrevTransitionEnd", "transitionStart", "transitionEnd", "touchStart", "touchMove", "touchMoveOpposite", "sliderMove", "touchEnd", "click", "tap", "doubleTap", "imagesReady", "progress", "reachBeginning", "reachEnd", "fromEdge", "setTranslate", "setTransition", "resize"];
                e.default = {
                    name: "swiper",
                    props: {
                        options: {
                            type: Object,
                            default: function() {
                                return {}
                            }
                        },
                        globalOptions: {
                            type: Object,
                            required: !1,
                            default: function() {
                                return {}
                            }
                        }
                    },
                    data: function() {
                        return {
                            swiper: null,
                            classes: {
                                wrapperClass: "swiper-wrapper"
                            }
                        }
                    },
                    ready: function() {
                        this.swiper || this.mountInstance()
                    },
                    mounted: function() {
                        if (!this.swiper) {
                            var t = !1;
                            for (var e in this.classes) this.classes.hasOwnProperty(e) && this.options[e] && (t = !0, this.classes[e] = this.options[e]);
                            t ? this.$nextTick(this.mountInstance) : this.mountInstance()
                        }
                    },
                    activated: function() {
                        this.update()
                    },
                    updated: function() {
                        this.update()
                    },
                    beforeDestroy: function() {
                        this.$nextTick((function() {
                            this.swiper && (this.swiper.destroy && this.swiper.destroy(), delete this.swiper)
                        }))
                    },
                    methods: {
                        update: function() {
                            this.swiper && (this.swiper.update && this.swiper.update(), this.swiper.navigation && this.swiper.navigation.update(), this.swiper.pagination && this.swiper.pagination.render(), this.swiper.pagination && this.swiper.pagination.update())
                        },
                        mountInstance: function() {
                            var t = Object.assign({}, this.globalOptions, this.options);
                            this.swiper = new n(this.$el, t), this.bindEvents(), this.$emit("ready", this.swiper)
                        },
                        bindEvents: function() {
                            var t = this,
                                e = this;
                            r.forEach((function(o) {
                                t.swiper.on(o, (function() {
                                    e.$emit.apply(e, [o].concat(Array.prototype.slice.call(arguments))), e.$emit.apply(e, [o.replace(/([A-Z])/g, "-$1").toLowerCase()].concat(Array.prototype.slice.call(arguments)))
                                }))
                            }))
                        }
                    }
                }
            }, function(t, e, o) {
                "use strict";
                var i = function() {
                        var t = this,
                            e = t.$createElement,
                            o = t._self._c || e;
                        return o("div", {
                            staticClass: "swiper-container"
                        }, [t._t("parallax-bg"), t._v(" "), o("div", {
                            class: t.classes.wrapperClass
                        }, [t._t("default")], 2), t._v(" "), t._t("pagination"), t._v(" "), t._t("button-prev"), t._v(" "), t._t("button-next"), t._v(" "), t._t("scrollbar")], 2)
                    },
                    n = {
                        render: i,
                        staticRenderFns: []
                    };
                e.a = n
            }, function(t, e, o) {
                "use strict";
                var i = function() {
                        var t = this,
                            e = t.$createElement;
                        return (t._self._c || e)("div", {
                            class: t.slideClass
                        }, [t._t("default")], 2)
                    },
                    n = {
                        render: i,
                        staticRenderFns: []
                    };
                e.a = n
            }]))
        },
        87: function(t, e, o) {
            "use strict";
            o.r(e);
            var n = o(6),
                r = o.n(n),
                l = o(70),
                c = {
                    name: "VideoSpot",
                    components: {
                        Picture: o(69).default
                    },
                    mixins: [l.a],
                    props: {
                        theme: {
                            type: Object,
                            default: function() {
                                return {
                                    selectBox: {
                                        current: "default",
                                        options: "video_spot.theme"
                                    }
                                }
                            }
                        },
                        videos: {
                            type: Object,
                            default: function() {
                                return {
                                    desktop: "https://i1.adis.ws/v/jpl/JD_Home_Page",
                                    mobile: "https://www.youtube.com/watch?v=OStGEbJI-ek"
                                }
                            }
                        },
                        images: {
                            type: Object,
                            default: function() {
                                return {
                                    desktop: "https://via.placeholder.com/1280x720/?text=Desktop+Video+Image",
                                    mobile: "https://via.placeholder.com/640/?text=Mobile+Video+Image"
                                }
                            }
                        },
                        overlay: {
                            type: [Object],
                            default: function() {
                                return {
                                    text: {
                                        html: {
                                            value: "<h1>Overlay Text</h1><p>This is the text shown when the video is paused.</p>"
                                        }
                                    },
                                    ctas: [{
                                        text: "CTA Button",
                                        url: "/default-cta-link",
                                        invert: !1
                                    }, {
                                        text: "CTA Button",
                                        url: "/default-cta-link",
                                        invert: !1
                                    }],
                                    position: {
                                        vertical: {
                                            selectBox: {
                                                current: "center",
                                                options: "video_spot.position"
                                            }
                                        },
                                        horizontal: {
                                            selectBox: {
                                                current: "start",
                                                options: "video_spot.position"
                                            }
                                        }
                                    },
                                    showOverlayImage: !0,
                                    showPlayButton: !0
                                }
                            }
                        },
                        aspectRatio: {
                            type: Object,
                            default: function() {
                                return {
                                    desktop: {
                                        width: "1280",
                                        height: "720"
                                    },
                                    mobile: {
                                        width: "640",
                                        height: "640"
                                    }
                                }
                            }
                        },
                        popUp: {
                            type: Boolean,
                            default: !1
                        },
                        settings: {
                            type: Object,
                            default: function() {
                                return {
                                    controls: !0,
                                    autoplay: !1,
                                    mute: !0,
                                    loop: !1
                                }
                            }
                        }
                    },
                    data: function() {
                        return {
                            className: "video-spot",
                            isPlaying: !1,
                            popUpOpen: !1
                        }
                    },
                    computed: {
                        overlayText: function() {
                            return "object" === r()(this.overlay.text) ? this.overlay.text.html.value : this.overlay.text
                        },
                        currentDevice: function() {
                            return this.windowSize.device
                        },
                        uniqueId: function() {
                            return "".concat(this.className, "_").concat(this._uid)
                        },
                        hasVideo: function() {
                            return !(!this.video || " " === this.video)
                        },
                        video: function() {
                            return "tablet" === this.windowSize.device ? this.videos.desktop : this.videos[this.windowSize.device]
                        },
                        image: function() {
                            return "tablet" === this.windowSize.device ? this.images.desktop : this.images[this.windowSize.device]
                        },
                        videoUrl: function() {
                            if (this.hasVideo) {
                                if (this.embedVideo) {
                                    if (this.isYouTubeLink) {
                                        var t = this.video.replace("/watch?v=", "/embed/");
                                        return this.settings.autoplay ? "".concat(t, "?autoplay=1") : t
                                    }
                                    return this.video
                                }
                                return ["".concat(this.video, "/mp4_720p?protocol=https"), "".concat(this.video, "/webm_720p?protocol=https"), "".concat(this.video, "/mp4_480p?protocol=https"), "".concat(this.video, "/webm_480p?protocol=https"), "".concat(this.video, "/mp4_240p?protocol=https"), "".concat(this.video, "/webm_240p?protocol=https")]
                            }
                            return " "
                        },
                        isYouTubeLink: function() {
                            return this.video.includes("youtube")
                        },
                        videoRatio: function() {
                            return !!this.windowSize.device && ("tablet" === this.windowSize.device ? this.aspectRatio.desktop : this.aspectRatio[this.windowSize.device])
                        },
                        currentAspectPadding: function() {
                            var t = this.videoRatio.height / this.videoRatio.width * 100;
                            return "".concat(t, "%")
                        },
                        imageRatio: function() {
                            return "".concat(this.videoRatio.width, ":").concat(this.videoRatio.height).replace(/px/g, "").replace(/%/g, "").replace(/rem/g, "").replace(/em/g, "")
                        },
                        embedVideo: function() {
                            return !(!this.video.includes("youtube") && !this.video.includes("smartzer"))
                        },
                        showOverlay: function() {
                            return !!this.popUpOpen || !this.isPlaying
                        }
                    },
                    watch: {
                        currentDevice: function() {
                            this.$forceUpdate()
                        },
                        isPlaying: function(t) {
                            t ? this.isYouTubeLink || this.$refs.videoRef.play() : this.isYouTubeLink || this.$refs.videoRef.pause()
                        }
                    },
                    mounted: function() {
                        this.settings.autoplay && this.video && (this.isPlaying = !0)
                    },
                    methods: {
                        mimeType: function(t) {
                            return t.includes("mp4_") ? "video/mp4" : "video/webm"
                        }
                    }
                },
                d = (o(93), o(10)),
                component = Object(d.a)(c, (function() {
                    var t = this,
                        e = t.$createElement,
                        o = t._self._c || e;
                    return o("div", {
                        class: [t.className + "__outer", t.theme.selectBox.current]
                    }, [t.hasVideo ? o("div", {
                        class: [t.className, t.windowSize.device],
                        style: {
                            paddingBottom: t.currentAspectPadding
                        },
                        on: {
                            click: function() {
                                t.popUp && (t.popUpOpen = !t.popUpOpen)
                            }
                        }
                    }, [t.showOverlay ? o("div", {
                        class: t.className + "__overlay",
                        on: {
                            click: function(e) {
                                t.isPlaying = !0
                            }
                        }
                    }, [o("div", {
                        class: [t.className + "__overlay__items", "horizontal--" + t.overlay.position.horizontal.selectBox.current, "vertical--" + t.overlay.position.vertical.selectBox.current]
                    }, [o("div", {
                        class: [t.className + "__overlay__text", "horizontal--" + t.overlay.position.horizontal.selectBox.current],
                        domProps: {
                            innerHTML: t._s(t.overlayText)
                        }
                    }), t._v(" "), t.overlay.ctas.length ? o("div", {
                        class: t.className + "__overlay__ctas"
                    }, t._l(t.overlay.ctas, (function(e, n) {
                        return o("a", {
                            key: n,
                            class: [t.className + "__overlay__cta", "ga-ip", {
                                invert: e.invert
                            }],
                            attrs: {
                                "data-ip-position": t.$attrs.index + "__cta-" + (n + 1),
                                "data-ip-name": e.text,
                                href: e.url
                            },
                            domProps: {
                                innerHTML: t._s(e.text)
                            }
                        })
                    })), 0) : t._e()]), t._v(" "), t.overlay.showPlayButton ? o("div", {
                        class: t.className + "__overlay__play-btn",
                        on: {
                            click: function(e) {
                                t.isPlaying = !0
                            }
                        }
                    }, [o("svg", {
                        staticClass: "btn--play",
                        attrs: {
                            width: "188",
                            height: "188",
                            viewBox: "0 0 188 188"
                        }
                    }, [o("circle", {
                        staticClass: "btn--play-circle cls-1",
                        attrs: {
                            cx: "94",
                            cy: "94",
                            r: "68"
                        }
                    }), t._v(" "), o("path", {
                        staticClass: "btn--play-triangle",
                        attrs: {
                            d: "M109,94.512l-25.006,14.5V80.009Z"
                        }
                    })])]) : t._e(), t._v(" "), t.overlay.showOverlayImage ? o("Picture", {
                        class: t.className + "__overlay__image",
                        attrs: {
                            component_id: t.$attrs.component_id + "__picture",
                            component_index: t.$attrs.component_index + "__picture",
                            image: t.image,
                            "aspect-ratio": t.imageRatio,
                            "aspect-ratio-mobile": t.imageRatio
                        }
                    }) : t._e()], 1) : t._e(), t._v(" "), o("div", {
                        class: [t.className + "-container", {
                            "pop-up": t.popUpOpen
                        }],
                        on: {
                            click: function() {
                                t.isPlaying = !1
                            }
                        }
                    }, [t.popUpOpen ? o("div", {
                        class: t.className + "__pop-up__close-btn",
                        domProps: {
                            innerHTML: t._s("&#215;")
                        },
                        on: {
                            click: function() {
                                t.isPlaying = !1
                            }
                        }
                    }) : t._e(), t._v(" "), t.embedVideo ? t._e() : o("video", {
                        ref: "videoRef",
                        class: [t.className + "_html5", t.uniqueId, {
                            "pop-up": t.popUpOpen
                        }],
                        attrs: {
                            controls: t.settings.controls,
                            autoplay: t.settings.autoplay,
                            poster: t.image,
                            loop: t.settings.loop,
                            playsinline: ""
                        },
                        domProps: {
                            muted: t.settings.mute
                        },
                        on: {
                            pause: function(e) {
                                t.isPlaying = !1
                            },
                            play: function(e) {
                                t.isPlaying = !0
                            }
                        }
                    }, t._l(t.videoUrl, (function(e) {
                        return o("source", {
                            key: e,
                            attrs: {
                                src: e,
                                type: t.mimeType(e)
                            }
                        })
                    })), 0), t._v(" "), t.embedVideo ? o("iframe", {
                        class: [t.className + "_youtube", t.uniqueId, {
                            "pop-up": t.popUpOpen
                        }],
                        attrs: {
                            src: t.videoUrl,
                            frameborder: "0",
                            allow: "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture",
                            allowfullscreen: ""
                        }
                    }) : t._e()])]) : t._e()])
                }), [], !1, null, null, null);
            e.default = component.exports
        },
        93: function(t, e, o) {
            "use strict";
            o(80)
        }
    }
]);