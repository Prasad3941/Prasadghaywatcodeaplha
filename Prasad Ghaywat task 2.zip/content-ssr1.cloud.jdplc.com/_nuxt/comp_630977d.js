/*! For license information please see LICENSES */
(window.webpackJsonp = window.webpackJsonp || []).push([
    [7], {
        11: function(e, t, r) {
            "use strict";
            var n = {
                name: "NoSsr",
                functional: !0,
                props: {
                    placeholder: String,
                    placeholderTag: {
                        type: String,
                        default: "div"
                    }
                },
                render: function(e, t) {
                    var r = t.parent,
                        n = t.slots,
                        o = t.props,
                        l = n(),
                        d = l.default;
                    void 0 === d && (d = []);
                    var c = l.placeholder;
                    return r._isMounted ? d : (r.$once("hook:mounted", (function() {
                        r.$forceUpdate()
                    })), o.placeholderTag && (o.placeholder || c) ? e(o.placeholderTag, {
                        class: ["no-ssr-placeholder"]
                    }, o.placeholder || c) : d.length > 0 ? d.map((function() {
                        return e(!1)
                    })) : e(!1))
                }
            };
            e.exports = n
        },
        18: function(e, t, r) {
            "use strict";
            var n = {
                name: "ClientOnly",
                functional: !0,
                props: {
                    placeholder: String,
                    placeholderTag: {
                        type: String,
                        default: "div"
                    }
                },
                render: function(e, t) {
                    var r = t.parent,
                        n = t.slots,
                        o = t.props,
                        l = n(),
                        d = l.default;
                    void 0 === d && (d = []);
                    var c = l.placeholder;
                    return r._isMounted ? d : (r.$once("hook:mounted", (function() {
                        r.$forceUpdate()
                    })), o.placeholderTag && (o.placeholder || c) ? e(o.placeholderTag, {
                        class: ["client-only-placeholder"]
                    }, o.placeholder || c) : d.length > 0 ? d.map((function() {
                        return e(!1)
                    })) : e(!1))
                }
            };
            e.exports = n
        },
        31: function(e, t, r) {
            "use strict";
            t.a = function(e, t) {
                return t = t || {}, new Promise((function(r, n) {
                    var s = new XMLHttpRequest,
                        o = [],
                        u = [],
                        i = {},
                        a = function() {
                            return {
                                ok: 2 == (s.status / 100 | 0),
                                statusText: s.statusText,
                                status: s.status,
                                url: s.responseURL,
                                text: function() {
                                    return Promise.resolve(s.responseText)
                                },
                                json: function() {
                                    return Promise.resolve(s.responseText).then(JSON.parse)
                                },
                                blob: function() {
                                    return Promise.resolve(new Blob([s.response]))
                                },
                                clone: a,
                                headers: {
                                    keys: function() {
                                        return o
                                    },
                                    entries: function() {
                                        return u
                                    },
                                    get: function(e) {
                                        return i[e.toLowerCase()]
                                    },
                                    has: function(e) {
                                        return e.toLowerCase() in i
                                    }
                                }
                            }
                        };
                    for (var l in s.open(t.method || "get", e, !0), s.onload = function() {
                            s.getAllResponseHeaders().replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm, (function(e, t, r) {
                                o.push(t = t.toLowerCase()), u.push([t, r]), i[t] = i[t] ? i[t] + "," + r : r
                            })), r(a())
                        }, s.onerror = n, s.withCredentials = "include" == t.credentials, t.headers) s.setRequestHeader(l, t.headers[l]);
                    s.send(t.body || null)
                }))
            }
        },
        35: function(e, t, r) {
            "use strict";
            var n = function(e) {
                return function(e) {
                    return !!e && "object" == typeof e
                }(e) && ! function(e) {
                    var t = Object.prototype.toString.call(e);
                    return "[object RegExp]" === t || "[object Date]" === t || function(e) {
                        return e.$$typeof === o
                    }(e)
                }(e)
            };
            var o = "function" == typeof Symbol && Symbol.for ? Symbol.for("react.element") : 60103;

            function l(e, t) {
                return !1 !== t.clone && t.isMergeableObject(e) ? f((r = e, Array.isArray(r) ? [] : {}), e, t) : e;
                var r
            }

            function d(e, source, t) {
                return e.concat(source).map((function(element) {
                    return l(element, t)
                }))
            }

            function c(e) {
                return Object.keys(e).concat(function(e) {
                    return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(e).filter((function(symbol) {
                        return e.propertyIsEnumerable(symbol)
                    })) : []
                }(e))
            }

            function h(object, e) {
                try {
                    return e in object
                } catch (e) {
                    return !1
                }
            }

            function v(e, source, t) {
                var r = {};
                return t.isMergeableObject(e) && c(e).forEach((function(n) {
                    r[n] = l(e[n], t)
                })), c(source).forEach((function(n) {
                    (function(e, t) {
                        return h(e, t) && !(Object.hasOwnProperty.call(e, t) && Object.propertyIsEnumerable.call(e, t))
                    })(e, n) || (h(e, n) && t.isMergeableObject(source[n]) ? r[n] = function(e, t) {
                        if (!t.customMerge) return f;
                        var r = t.customMerge(e);
                        return "function" == typeof r ? r : f
                    }(n, t)(e[n], source[n], t) : r[n] = l(source[n], t))
                })), r
            }

            function f(e, source, t) {
                (t = t || {}).arrayMerge = t.arrayMerge || d, t.isMergeableObject = t.isMergeableObject || n, t.cloneUnlessOtherwiseSpecified = l;
                var r = Array.isArray(source);
                return r === Array.isArray(e) ? r ? t.arrayMerge(e, source, t) : v(e, source, t) : l(source, t)
            }
            f.all = function(e, t) {
                if (!Array.isArray(e)) throw new Error("first argument should be an array");
                return e.reduce((function(e, r) {
                    return f(e, r, t)
                }), {})
            };
            var m = f;
            e.exports = m
        },
        36: function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return c
            }));
            var n = r(6);

            function o(e) {
                return null !== e && "object" === n(e)
            }

            function l(e, t) {
                var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : ".",
                    n = arguments.length > 3 ? arguments[3] : void 0;
                if (!o(t)) return l(e, {}, r, n);
                var d = Object.assign({}, t);
                for (var c in e)
                    if ("__proto__" !== c && "constructor" !== c) {
                        var h = e[c];
                        null != h && (n && n(d, c, h, r) || (Array.isArray(h) && Array.isArray(d[c]) ? d[c] = d[c].concat(h) : o(h) && o(d[c]) ? d[c] = l(h, d[c], (r ? "".concat(r, ".") : "") + c.toString(), n) : d[c] = h))
                    }
                return d
            }

            function d(e) {
                return function() {
                    for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++) r[n] = arguments[n];
                    return r.reduce((function(p, t) {
                        return l(p, t, "", e)
                    }), {})
                }
            }
            var c = d();
            c.fn = d((function(e, t, r, n) {
                if (void 0 !== e[t] && "function" == typeof r) return e[t] = r(e[t]), !0
            })), c.arrayFn = d((function(e, t, r, n) {
                if (Array.isArray(e[t]) && "function" == typeof r) return e[t] = r(e[t]), !0
            })), c.extend = d
        },
        37: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.install = t.swiper = t.Swiper = void 0;
            var n = l(r(39)),
                o = l(r(68));

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            var d = window.Swiper || n.default,
                c = ["beforeDestroy", "slideChange", "slideChangeTransitionStart", "slideChangeTransitionEnd", "slideNextTransitionStart", "slideNextTransitionEnd", "slidePrevTransitionStart", "slidePrevTransitionEnd", "transitionStart", "transitionEnd", "touchStart", "touchMove", "touchMoveOpposite", "sliderMove", "touchEnd", "click", "tap", "doubleTap", "imagesReady", "progress", "reachBeginning", "reachEnd", "fromEdge", "setTranslate", "setTransition", "resize"],
                h = function(e) {
                    var t = function(e, t, r) {
                        var n = null;
                        return t.arg ? n = t.arg : r.data.attrs && (r.data.attrs.instanceName || r.data.attrs["instance-name"]) ? n = r.data.attrs.instanceName || r.data.attrs["instance-name"] : e.id && (n = e.id), n || "swiper"
                    };
                    return {
                        bind: function(e, t, r) {
                            r.context; - 1 === e.className.indexOf("swiper-container") && (e.className += (e.className ? " " : "") + "swiper-container")
                        },
                        inserted: function(r, n, l) {
                            var h = l.context,
                                v = n.value,
                                f = t(r, n, l),
                                m = h[f],
                                w = function(e, t, data) {
                                    var r = e.data && e.data.on || e.componentOptions && e.componentOptions.listeners;
                                    r && r[t] && r[t].fns(data)
                                };
                            if (!m) {
                                var y = (0, o.default)({}, e, v);
                                m = h[f] = new d(r, y), c.forEach((function(e) {
                                    m.on(e, (function() {
                                        w.apply(void 0, [l, e].concat(Array.prototype.slice.call(arguments))), w.apply(void 0, [l, e.replace(/([A-Z])/g, "-$1")].concat(Array.prototype.slice.call(arguments)))
                                    }))
                                }))
                            }
                            w(l, "ready", m)
                        },
                        componentUpdated: function(e, r, n) {
                            var o = t(e, r, n),
                                l = n.context[o];
                            l && (l.update && l.update(), l.navigation && l.navigation.update(), l.pagination && l.pagination.render(), l.pagination && l.pagination.update())
                        },
                        unbind: function(e, r, n) {
                            var o = t(e, r, n),
                                l = n.context[o];
                            l && (l.destroy && l.destroy(), delete n.context[o])
                        }
                    }
                },
                v = h({}),
                f = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    e.directive("swiper", h(t))
                },
                m = {
                    Swiper: d,
                    swiper: v,
                    install: f
                };
            t.Swiper = d, t.swiper = v, t.install = f, t.default = m
        },
        39: function(e, t, r) {
            e.exports = function() {
                "use strict";
                var e = "undefined" == typeof document ? {
                        body: {},
                        addEventListener: function() {},
                        removeEventListener: function() {},
                        activeElement: {
                            blur: function() {},
                            nodeName: ""
                        },
                        querySelector: function() {
                            return null
                        },
                        querySelectorAll: function() {
                            return []
                        },
                        getElementById: function() {
                            return null
                        },
                        createEvent: function() {
                            return {
                                initEvent: function() {}
                            }
                        },
                        createElement: function() {
                            return {
                                children: [],
                                childNodes: [],
                                style: {},
                                setAttribute: function() {},
                                getElementsByTagName: function() {
                                    return []
                                }
                            }
                        },
                        location: {
                            hash: ""
                        }
                    } : document,
                    t = "undefined" == typeof window ? {
                        document: e,
                        navigator: {
                            userAgent: ""
                        },
                        location: {},
                        history: {},
                        CustomEvent: function() {
                            return this
                        },
                        addEventListener: function() {},
                        removeEventListener: function() {},
                        getComputedStyle: function() {
                            return {
                                getPropertyValue: function() {
                                    return ""
                                }
                            }
                        },
                        Image: function() {},
                        Date: function() {},
                        screen: {},
                        setTimeout: function() {},
                        clearTimeout: function() {}
                    } : window,
                    r = function(e) {
                        for (var t = this, i = 0; i < e.length; i += 1) t[i] = e[i];
                        return t.length = e.length, this
                    };

                function n(n, o) {
                    var l = [],
                        i = 0;
                    if (n && !o && n instanceof r) return n;
                    if (n)
                        if ("string" == typeof n) {
                            var d, c, html = n.trim();
                            if (html.indexOf("<") >= 0 && html.indexOf(">") >= 0) {
                                var h = "div";
                                for (0 === html.indexOf("<li") && (h = "ul"), 0 === html.indexOf("<tr") && (h = "tbody"), 0 !== html.indexOf("<td") && 0 !== html.indexOf("<th") || (h = "tr"), 0 === html.indexOf("<tbody") && (h = "table"), 0 === html.indexOf("<option") && (h = "select"), (c = e.createElement(h)).innerHTML = html, i = 0; i < c.childNodes.length; i += 1) l.push(c.childNodes[i])
                            } else
                                for (d = o || "#" !== n[0] || n.match(/[ .<>:~]/) ? (o || e).querySelectorAll(n.trim()) : [e.getElementById(n.trim().split("#")[1])], i = 0; i < d.length; i += 1) d[i] && l.push(d[i])
                        } else if (n.nodeType || n === t || n === e) l.push(n);
                    else if (n.length > 0 && n[0].nodeType)
                        for (i = 0; i < n.length; i += 1) l.push(n[i]);
                    return new r(l)
                }

                function o(e) {
                    for (var t = [], i = 0; i < e.length; i += 1) - 1 === t.indexOf(e[i]) && t.push(e[i]);
                    return t
                }

                function l(e) {
                    if (void 0 === e) return this;
                    for (var t = e.split(" "), i = 0; i < t.length; i += 1)
                        for (var r = 0; r < this.length; r += 1) void 0 !== this[r] && void 0 !== this[r].classList && this[r].classList.add(t[i]);
                    return this
                }

                function d(e) {
                    for (var t = e.split(" "), i = 0; i < t.length; i += 1)
                        for (var r = 0; r < this.length; r += 1) void 0 !== this[r] && void 0 !== this[r].classList && this[r].classList.remove(t[i]);
                    return this
                }

                function c(e) {
                    return !!this[0] && this[0].classList.contains(e)
                }

                function h(e) {
                    for (var t = e.split(" "), i = 0; i < t.length; i += 1)
                        for (var r = 0; r < this.length; r += 1) void 0 !== this[r] && void 0 !== this[r].classList && this[r].classList.toggle(t[i]);
                    return this
                }

                function v(e, t) {
                    var r = arguments;
                    if (1 === arguments.length && "string" == typeof e) return this[0] ? this[0].getAttribute(e) : void 0;
                    for (var i = 0; i < this.length; i += 1)
                        if (2 === r.length) this[i].setAttribute(e, t);
                        else
                            for (var n in e) this[i][n] = e[n], this[i].setAttribute(n, e[n]);
                    return this
                }

                function f(e) {
                    for (var i = 0; i < this.length; i += 1) this[i].removeAttribute(e);
                    return this
                }

                function data(e, t) {
                    var r;
                    if (void 0 !== t) {
                        for (var i = 0; i < this.length; i += 1)(r = this[i]).dom7ElementDataStorage || (r.dom7ElementDataStorage = {}), r.dom7ElementDataStorage[e] = t;
                        return this
                    }
                    if (r = this[0]) {
                        if (r.dom7ElementDataStorage && e in r.dom7ElementDataStorage) return r.dom7ElementDataStorage[e];
                        var n = r.getAttribute("data-" + e);
                        return n || void 0
                    }
                }

                function m(e) {
                    for (var i = 0; i < this.length; i += 1) {
                        var t = this[i].style;
                        t.webkitTransform = e, t.transform = e
                    }
                    return this
                }

                function w(e) {
                    "string" != typeof e && (e += "ms");
                    for (var i = 0; i < this.length; i += 1) {
                        var t = this[i].style;
                        t.webkitTransitionDuration = e, t.transitionDuration = e
                    }
                    return this
                }

                function y() {
                    for (var e, t = [], r = arguments.length; r--;) t[r] = arguments[r];
                    var o = t[0],
                        l = t[1],
                        d = t[2],
                        c = t[3];

                    function h(e) {
                        var t = e.target;
                        if (t) {
                            var r = e.target.dom7EventData || [];
                            if (r.indexOf(e) < 0 && r.unshift(e), n(t).is(l)) d.apply(t, r);
                            else
                                for (var o = n(t).parents(), c = 0; c < o.length; c += 1) n(o[c]).is(l) && d.apply(o[c], r)
                        }
                    }

                    function v(e) {
                        var t = e && e.target && e.target.dom7EventData || [];
                        t.indexOf(e) < 0 && t.unshift(e), d.apply(this, t)
                    }
                    "function" == typeof t[1] && (o = (e = t)[0], d = e[1], c = e[2], l = void 0), c || (c = !1);
                    for (var f, m = o.split(" "), i = 0; i < this.length; i += 1) {
                        var w = this[i];
                        if (l)
                            for (f = 0; f < m.length; f += 1) {
                                var y = m[f];
                                w.dom7LiveListeners || (w.dom7LiveListeners = {}), w.dom7LiveListeners[y] || (w.dom7LiveListeners[y] = []), w.dom7LiveListeners[y].push({
                                    listener: d,
                                    proxyListener: h
                                }), w.addEventListener(y, h, c)
                            } else
                                for (f = 0; f < m.length; f += 1) {
                                    var x = m[f];
                                    w.dom7Listeners || (w.dom7Listeners = {}), w.dom7Listeners[x] || (w.dom7Listeners[x] = []), w.dom7Listeners[x].push({
                                        listener: d,
                                        proxyListener: v
                                    }), w.addEventListener(x, v, c)
                                }
                    }
                    return this
                }

                function x() {
                    for (var e, t = [], r = arguments.length; r--;) t[r] = arguments[r];
                    var n = t[0],
                        o = t[1],
                        l = t[2],
                        d = t[3];
                    "function" == typeof t[1] && (n = (e = t)[0], l = e[1], d = e[2], o = void 0), d || (d = !1);
                    for (var c = n.split(" "), i = 0; i < c.length; i += 1)
                        for (var h = c[i], v = 0; v < this.length; v += 1) {
                            var f = this[v],
                                m = void 0;
                            if (!o && f.dom7Listeners ? m = f.dom7Listeners[h] : o && f.dom7LiveListeners && (m = f.dom7LiveListeners[h]), m && m.length)
                                for (var w = m.length - 1; w >= 0; w -= 1) {
                                    var y = m[w];
                                    l && y.listener === l ? (f.removeEventListener(h, y.proxyListener, d), m.splice(w, 1)) : l || (f.removeEventListener(h, y.proxyListener, d), m.splice(w, 1))
                                }
                        }
                    return this
                }

                function T() {
                    for (var r = [], n = arguments.length; n--;) r[n] = arguments[n];
                    for (var o = r[0].split(" "), l = r[1], i = 0; i < o.length; i += 1)
                        for (var d = o[i], c = 0; c < this.length; c += 1) {
                            var h = this[c],
                                v = void 0;
                            try {
                                v = new t.CustomEvent(d, {
                                    detail: l,
                                    bubbles: !0,
                                    cancelable: !0
                                })
                            } catch (t) {
                                (v = e.createEvent("Event")).initEvent(d, !0, !0), v.detail = l
                            }
                            h.dom7EventData = r.filter((function(data, e) {
                                return e > 0
                            })), h.dispatchEvent(v), h.dom7EventData = [], delete h.dom7EventData
                        }
                    return this
                }

                function E(e) {
                    var i, t = ["webkitTransitionEnd", "transitionend"],
                        r = this;

                    function n(o) {
                        if (o.target === this)
                            for (e.call(this, o), i = 0; i < t.length; i += 1) r.off(t[i], n)
                    }
                    if (e)
                        for (i = 0; i < t.length; i += 1) r.on(t[i], n);
                    return this
                }

                function S(e) {
                    if (this.length > 0) {
                        if (e) {
                            var t = this.styles();
                            return this[0].offsetWidth + parseFloat(t.getPropertyValue("margin-right")) + parseFloat(t.getPropertyValue("margin-left"))
                        }
                        return this[0].offsetWidth
                    }
                    return null
                }

                function C(e) {
                    if (this.length > 0) {
                        if (e) {
                            var t = this.styles();
                            return this[0].offsetHeight + parseFloat(t.getPropertyValue("margin-top")) + parseFloat(t.getPropertyValue("margin-bottom"))
                        }
                        return this[0].offsetHeight
                    }
                    return null
                }

                function M() {
                    if (this.length > 0) {
                        var r = this[0],
                            n = r.getBoundingClientRect(),
                            body = e.body,
                            o = r.clientTop || body.clientTop || 0,
                            l = r.clientLeft || body.clientLeft || 0,
                            d = r === t ? t.scrollY : r.scrollTop,
                            c = r === t ? t.scrollX : r.scrollLeft;
                        return {
                            top: n.top + d - o,
                            left: n.left + c - l
                        }
                    }
                    return null
                }

                function P() {
                    return this[0] ? t.getComputedStyle(this[0], null) : {}
                }

                function k(e, r) {
                    var i;
                    if (1 === arguments.length) {
                        if ("string" != typeof e) {
                            for (i = 0; i < this.length; i += 1)
                                for (var n in e) this[i].style[n] = e[n];
                            return this
                        }
                        if (this[0]) return t.getComputedStyle(this[0], null).getPropertyValue(e)
                    }
                    if (2 === arguments.length && "string" == typeof e) {
                        for (i = 0; i < this.length; i += 1) this[i].style[e] = r;
                        return this
                    }
                    return this
                }

                function z(e) {
                    if (!e) return this;
                    for (var i = 0; i < this.length; i += 1)
                        if (!1 === e.call(this[i], i, this[i])) return this;
                    return this
                }

                function html(html) {
                    if (void 0 === html) return this[0] ? this[0].innerHTML : void 0;
                    for (var i = 0; i < this.length; i += 1) this[i].innerHTML = html;
                    return this
                }

                function text(text) {
                    if (void 0 === text) return this[0] ? this[0].textContent.trim() : null;
                    for (var i = 0; i < this.length; i += 1) this[i].textContent = text;
                    return this
                }

                function $(o) {
                    var l, i, d = this[0];
                    if (!d || void 0 === o) return !1;
                    if ("string" == typeof o) {
                        if (d.matches) return d.matches(o);
                        if (d.webkitMatchesSelector) return d.webkitMatchesSelector(o);
                        if (d.msMatchesSelector) return d.msMatchesSelector(o);
                        for (l = n(o), i = 0; i < l.length; i += 1)
                            if (l[i] === d) return !0;
                        return !1
                    }
                    if (o === e) return d === e;
                    if (o === t) return d === t;
                    if (o.nodeType || o instanceof r) {
                        for (l = o.nodeType ? [o] : o, i = 0; i < l.length; i += 1)
                            if (l[i] === d) return !0;
                        return !1
                    }
                    return !1
                }

                function L() {
                    var i, e = this[0];
                    if (e) {
                        for (i = 0; null !== (e = e.previousSibling);) 1 === e.nodeType && (i += 1);
                        return i
                    }
                }

                function I(e) {
                    if (void 0 === e) return this;
                    var t, n = this.length;
                    return new r(e > n - 1 ? [] : e < 0 ? (t = n + e) < 0 ? [] : [this[t]] : [this[e]])
                }

                function O() {
                    for (var t, n = [], o = arguments.length; o--;) n[o] = arguments[o];
                    for (var l = 0; l < n.length; l += 1) {
                        t = n[l];
                        for (var i = 0; i < this.length; i += 1)
                            if ("string" == typeof t) {
                                var d = e.createElement("div");
                                for (d.innerHTML = t; d.firstChild;) this[i].appendChild(d.firstChild)
                            } else if (t instanceof r)
                            for (var c = 0; c < t.length; c += 1) this[i].appendChild(t[c]);
                        else this[i].appendChild(t)
                    }
                    return this
                }

                function D(t) {
                    var i, n;
                    for (i = 0; i < this.length; i += 1)
                        if ("string" == typeof t) {
                            var o = e.createElement("div");
                            for (o.innerHTML = t, n = o.childNodes.length - 1; n >= 0; n -= 1) this[i].insertBefore(o.childNodes[n], this[i].childNodes[0])
                        } else if (t instanceof r)
                        for (n = 0; n < t.length; n += 1) this[i].insertBefore(t[n], this[i].childNodes[0]);
                    else this[i].insertBefore(t, this[i].childNodes[0]);
                    return this
                }

                function A(e) {
                    return this.length > 0 ? e ? this[0].nextElementSibling && n(this[0].nextElementSibling).is(e) ? new r([this[0].nextElementSibling]) : new r([]) : this[0].nextElementSibling ? new r([this[0].nextElementSibling]) : new r([]) : new r([])
                }

                function N(e) {
                    var t = [],
                        o = this[0];
                    if (!o) return new r([]);
                    for (; o.nextElementSibling;) {
                        var l = o.nextElementSibling;
                        e ? n(l).is(e) && t.push(l) : t.push(l), o = l
                    }
                    return new r(t)
                }

                function H(e) {
                    if (this.length > 0) {
                        var t = this[0];
                        return e ? t.previousElementSibling && n(t.previousElementSibling).is(e) ? new r([t.previousElementSibling]) : new r([]) : t.previousElementSibling ? new r([t.previousElementSibling]) : new r([])
                    }
                    return new r([])
                }

                function B(e) {
                    var t = [],
                        o = this[0];
                    if (!o) return new r([]);
                    for (; o.previousElementSibling;) {
                        var l = o.previousElementSibling;
                        e ? n(l).is(e) && t.push(l) : t.push(l), o = l
                    }
                    return new r(t)
                }

                function G(e) {
                    for (var t = [], i = 0; i < this.length; i += 1) null !== this[i].parentNode && (e ? n(this[i].parentNode).is(e) && t.push(this[i].parentNode) : t.push(this[i].parentNode));
                    return n(o(t))
                }

                function X(e) {
                    for (var t = [], i = 0; i < this.length; i += 1)
                        for (var r = this[i].parentNode; r;) e ? n(r).is(e) && t.push(r) : t.push(r), r = r.parentNode;
                    return n(o(t))
                }

                function Y(e) {
                    var t = this;
                    return void 0 === e ? new r([]) : (t.is(e) || (t = t.parents(e).eq(0)), t)
                }

                function V(e) {
                    for (var t = [], i = 0; i < this.length; i += 1)
                        for (var n = this[i].querySelectorAll(e), o = 0; o < n.length; o += 1) t.push(n[o]);
                    return new r(t)
                }

                function j(e) {
                    for (var t = [], i = 0; i < this.length; i += 1)
                        for (var l = this[i].childNodes, d = 0; d < l.length; d += 1) e ? 1 === l[d].nodeType && n(l[d]).is(e) && t.push(l[d]) : 1 === l[d].nodeType && t.push(l[d]);
                    return new r(o(t))
                }

                function F() {
                    for (var i = 0; i < this.length; i += 1) this[i].parentNode && this[i].parentNode.removeChild(this[i]);
                    return this
                }

                function R() {
                    for (var e = [], t = arguments.length; t--;) e[t] = arguments[t];
                    var i, r, o = this;
                    for (i = 0; i < e.length; i += 1) {
                        var l = n(e[i]);
                        for (r = 0; r < l.length; r += 1) o[o.length] = l[r], o.length += 1
                    }
                    return o
                }
                n.fn = r.prototype, n.Class = r, n.Dom7 = r;
                var W = {
                    addClass: l,
                    removeClass: d,
                    hasClass: c,
                    toggleClass: h,
                    attr: v,
                    removeAttr: f,
                    data: data,
                    transform: m,
                    transition: w,
                    on: y,
                    off: x,
                    trigger: T,
                    transitionEnd: E,
                    outerWidth: S,
                    outerHeight: C,
                    offset: M,
                    css: k,
                    each: z,
                    html: html,
                    text: text,
                    is: $,
                    index: L,
                    eq: I,
                    append: O,
                    prepend: D,
                    next: A,
                    nextAll: N,
                    prev: H,
                    prevAll: B,
                    parent: G,
                    parents: X,
                    closest: Y,
                    find: V,
                    children: j,
                    remove: F,
                    add: R,
                    styles: P
                };
                Object.keys(W).forEach((function(e) {
                    n.fn[e] = W[e]
                }));
                var style, _, U = {
                        deleteProps: function(e) {
                            var object = e;
                            Object.keys(object).forEach((function(e) {
                                try {
                                    object[e] = null
                                } catch (e) {}
                                try {
                                    delete object[e]
                                } catch (e) {}
                            }))
                        },
                        nextTick: function(e, t) {
                            return void 0 === t && (t = 0), setTimeout(e, t)
                        },
                        now: function() {
                            return Date.now()
                        },
                        getTranslate: function(e, r) {
                            var n, o, l;
                            void 0 === r && (r = "x");
                            var d = t.getComputedStyle(e, null);
                            return t.WebKitCSSMatrix ? ((o = d.transform || d.webkitTransform).split(",").length > 6 && (o = o.split(", ").map((function(a) {
                                return a.replace(",", ".")
                            })).join(", ")), l = new t.WebKitCSSMatrix("none" === o ? "" : o)) : n = (l = d.MozTransform || d.OTransform || d.MsTransform || d.msTransform || d.transform || d.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,")).toString().split(","), "x" === r && (o = t.WebKitCSSMatrix ? l.m41 : 16 === n.length ? parseFloat(n[12]) : parseFloat(n[4])), "y" === r && (o = t.WebKitCSSMatrix ? l.m42 : 16 === n.length ? parseFloat(n[13]) : parseFloat(n[5])), o || 0
                        },
                        parseUrlQuery: function(e) {
                            var i, r, param, n, o = {},
                                l = e || t.location.href;
                            if ("string" == typeof l && l.length)
                                for (n = (r = (l = l.indexOf("?") > -1 ? l.replace(/\S*\?/, "") : "").split("&").filter((function(e) {
                                        return "" !== e
                                    }))).length, i = 0; i < n; i += 1) param = r[i].replace(/#\S+/g, "").split("="), o[decodeURIComponent(param[0])] = void 0 === param[1] ? void 0 : decodeURIComponent(param[1]) || "";
                            return o
                        },
                        isObject: function(e) {
                            return "object" == typeof e && null !== e && e.constructor && e.constructor === Object
                        },
                        extend: function() {
                            for (var e = [], t = arguments.length; t--;) e[t] = arguments[t];
                            for (var r = Object(e[0]), i = 1; i < e.length; i += 1) {
                                var n = e[i];
                                if (null != n)
                                    for (var o = Object.keys(Object(n)), l = 0, d = o.length; l < d; l += 1) {
                                        var c = o[l],
                                            desc = Object.getOwnPropertyDescriptor(n, c);
                                        void 0 !== desc && desc.enumerable && (U.isObject(r[c]) && U.isObject(n[c]) ? U.extend(r[c], n[c]) : !U.isObject(r[c]) && U.isObject(n[c]) ? (r[c] = {}, U.extend(r[c], n[c])) : r[c] = n[c])
                                    }
                            }
                            return r
                        }
                    },
                    K = (_ = e.createElement("div"), {
                        touch: t.Modernizr && !0 === t.Modernizr.touch || !!(t.navigator.maxTouchPoints > 0 || "ontouchstart" in t || t.DocumentTouch && e instanceof t.DocumentTouch),
                        pointerEvents: !!(t.navigator.pointerEnabled || t.PointerEvent || "maxTouchPoints" in t.navigator),
                        prefixedPointerEvents: !!t.navigator.msPointerEnabled,
                        transition: (style = _.style, "transition" in style || "webkitTransition" in style || "MozTransition" in style),
                        transforms3d: t.Modernizr && !0 === t.Modernizr.csstransforms3d || function() {
                            var style = _.style;
                            return "webkitPerspective" in style || "MozPerspective" in style || "OPerspective" in style || "MsPerspective" in style || "perspective" in style
                        }(),
                        flexbox: function() {
                            for (var style = _.style, e = "alignItems webkitAlignItems webkitBoxAlign msFlexAlign mozBoxAlign webkitFlexDirection msFlexDirection mozBoxDirection mozBoxOrient webkitBoxDirection webkitBoxOrient".split(" "), i = 0; i < e.length; i += 1)
                                if (e[i] in style) return !0;
                            return !1
                        }(),
                        observer: "MutationObserver" in t || "WebkitMutationObserver" in t,
                        passiveListener: function() {
                            var e = !1;
                            try {
                                var r = Object.defineProperty({}, "passive", {
                                    get: function() {
                                        e = !0
                                    }
                                });
                                t.addEventListener("testPassiveListener", null, r)
                            } catch (e) {}
                            return e
                        }(),
                        gestures: "ongesturestart" in t
                    }),
                    J = function(e) {
                        void 0 === e && (e = {});
                        var t = this;
                        t.params = e, t.eventsListeners = {}, t.params && t.params.on && Object.keys(t.params.on).forEach((function(e) {
                            t.on(e, t.params.on[e])
                        }))
                    },
                    Z = {
                        components: {
                            configurable: !0
                        }
                    };

                function Q() {
                    var e, t, r = this,
                        n = r.$el;
                    e = void 0 !== r.params.width ? r.params.width : n[0].clientWidth, t = void 0 !== r.params.height ? r.params.height : n[0].clientHeight, 0 === e && r.isHorizontal() || 0 === t && r.isVertical() || (e = e - parseInt(n.css("padding-left"), 10) - parseInt(n.css("padding-right"), 10), t = t - parseInt(n.css("padding-top"), 10) - parseInt(n.css("padding-bottom"), 10), U.extend(r, {
                        width: e,
                        height: t,
                        size: r.isHorizontal() ? e : t
                    }))
                }

                function ee() {
                    var e = this,
                        r = e.params,
                        n = e.$wrapperEl,
                        o = e.size,
                        l = e.rtlTranslate,
                        d = e.wrongRTL,
                        c = e.virtual && r.virtual.enabled,
                        h = c ? e.virtual.slides.length : e.slides.length,
                        v = n.children("." + e.params.slideClass),
                        f = c ? e.virtual.slides.length : v.length,
                        m = [],
                        w = [],
                        y = [],
                        x = r.slidesOffsetBefore;
                    "function" == typeof x && (x = r.slidesOffsetBefore.call(e));
                    var T = r.slidesOffsetAfter;
                    "function" == typeof T && (T = r.slidesOffsetAfter.call(e));
                    var E = e.snapGrid.length,
                        S = e.snapGrid.length,
                        C = r.spaceBetween,
                        M = -x,
                        P = 0,
                        k = 0;
                    if (void 0 !== o) {
                        var z, $;
                        "string" == typeof C && C.indexOf("%") >= 0 && (C = parseFloat(C.replace("%", "")) / 100 * o), e.virtualSize = -C, l ? v.css({
                            marginLeft: "",
                            marginTop: ""
                        }) : v.css({
                            marginRight: "",
                            marginBottom: ""
                        }), r.slidesPerColumn > 1 && (z = Math.floor(f / r.slidesPerColumn) === f / e.params.slidesPerColumn ? f : Math.ceil(f / r.slidesPerColumn) * r.slidesPerColumn, "auto" !== r.slidesPerView && "row" === r.slidesPerColumnFill && (z = Math.max(z, r.slidesPerView * r.slidesPerColumn)));
                        for (var L, I = r.slidesPerColumn, O = z / I, D = Math.floor(f / r.slidesPerColumn), i = 0; i < f; i += 1) {
                            $ = 0;
                            var A = v.eq(i);
                            if (r.slidesPerColumn > 1) {
                                var N = void 0,
                                    H = void 0,
                                    B = void 0;
                                "column" === r.slidesPerColumnFill ? (B = i - (H = Math.floor(i / I)) * I, (H > D || H === D && B === I - 1) && (B += 1) >= I && (B = 0, H += 1), N = H + B * z / I, A.css({
                                    "-webkit-box-ordinal-group": N,
                                    "-moz-box-ordinal-group": N,
                                    "-ms-flex-order": N,
                                    "-webkit-order": N,
                                    order: N
                                })) : H = i - (B = Math.floor(i / O)) * O, A.css("margin-" + (e.isHorizontal() ? "top" : "left"), 0 !== B && r.spaceBetween && r.spaceBetween + "px").attr("data-swiper-column", H).attr("data-swiper-row", B)
                            }
                            if ("none" !== A.css("display")) {
                                if ("auto" === r.slidesPerView) {
                                    var G = t.getComputedStyle(A[0], null),
                                        X = A[0].style.transform,
                                        Y = A[0].style.webkitTransform;
                                    if (X && (A[0].style.transform = "none"), Y && (A[0].style.webkitTransform = "none"), r.roundLengths) $ = e.isHorizontal() ? A.outerWidth(!0) : A.outerHeight(!0);
                                    else if (e.isHorizontal()) {
                                        var V = parseFloat(G.getPropertyValue("width")),
                                            j = parseFloat(G.getPropertyValue("padding-left")),
                                            F = parseFloat(G.getPropertyValue("padding-right")),
                                            R = parseFloat(G.getPropertyValue("margin-left")),
                                            W = parseFloat(G.getPropertyValue("margin-right")),
                                            _ = G.getPropertyValue("box-sizing");
                                        $ = _ && "border-box" === _ ? V + R + W : V + j + F + R + W
                                    } else {
                                        var J = parseFloat(G.getPropertyValue("height")),
                                            Z = parseFloat(G.getPropertyValue("padding-top")),
                                            Q = parseFloat(G.getPropertyValue("padding-bottom")),
                                            ee = parseFloat(G.getPropertyValue("margin-top")),
                                            te = parseFloat(G.getPropertyValue("margin-bottom")),
                                            ae = G.getPropertyValue("box-sizing");
                                        $ = ae && "border-box" === ae ? J + ee + te : J + Z + Q + ee + te
                                    }
                                    X && (A[0].style.transform = X), Y && (A[0].style.webkitTransform = Y), r.roundLengths && ($ = Math.floor($))
                                } else $ = (o - (r.slidesPerView - 1) * C) / r.slidesPerView, r.roundLengths && ($ = Math.floor($)), v[i] && (e.isHorizontal() ? v[i].style.width = $ + "px" : v[i].style.height = $ + "px");
                                v[i] && (v[i].swiperSlideSize = $), y.push($), r.centeredSlides ? (M = M + $ / 2 + P / 2 + C, 0 === P && 0 !== i && (M = M - o / 2 - C), 0 === i && (M = M - o / 2 - C), Math.abs(M) < .001 && (M = 0), r.roundLengths && (M = Math.floor(M)), k % r.slidesPerGroup == 0 && m.push(M), w.push(M)) : (r.roundLengths && (M = Math.floor(M)), k % r.slidesPerGroup == 0 && m.push(M), w.push(M), M = M + $ + C), e.virtualSize += $ + C, P = $, k += 1
                            }
                        }
                        if (e.virtualSize = Math.max(e.virtualSize, o) + T, l && d && ("slide" === r.effect || "coverflow" === r.effect) && n.css({
                                width: e.virtualSize + r.spaceBetween + "px"
                            }), K.flexbox && !r.setWrapperSize || (e.isHorizontal() ? n.css({
                                width: e.virtualSize + r.spaceBetween + "px"
                            }) : n.css({
                                height: e.virtualSize + r.spaceBetween + "px"
                            })), r.slidesPerColumn > 1 && (e.virtualSize = ($ + r.spaceBetween) * z, e.virtualSize = Math.ceil(e.virtualSize / r.slidesPerColumn) - r.spaceBetween, e.isHorizontal() ? n.css({
                                width: e.virtualSize + r.spaceBetween + "px"
                            }) : n.css({
                                height: e.virtualSize + r.spaceBetween + "px"
                            }), r.centeredSlides)) {
                            L = [];
                            for (var ie = 0; ie < m.length; ie += 1) {
                                var re = m[ie];
                                r.roundLengths && (re = Math.floor(re)), m[ie] < e.virtualSize + m[0] && L.push(re)
                            }
                            m = L
                        }
                        if (!r.centeredSlides) {
                            L = [];
                            for (var se = 0; se < m.length; se += 1) {
                                var ne = m[se];
                                r.roundLengths && (ne = Math.floor(ne)), m[se] <= e.virtualSize - o && L.push(ne)
                            }
                            m = L, Math.floor(e.virtualSize - o) - Math.floor(m[m.length - 1]) > 1 && m.push(e.virtualSize - o)
                        }
                        if (0 === m.length && (m = [0]), 0 !== r.spaceBetween && (e.isHorizontal() ? l ? v.css({
                                marginLeft: C + "px"
                            }) : v.css({
                                marginRight: C + "px"
                            }) : v.css({
                                marginBottom: C + "px"
                            })), r.centerInsufficientSlides) {
                            var oe = 0;
                            if (y.forEach((function(e) {
                                    oe += e + (r.spaceBetween ? r.spaceBetween : 0)
                                })), (oe -= r.spaceBetween) < o) {
                                var le = (o - oe) / 2;
                                m.forEach((function(e, t) {
                                    m[t] = e - le
                                })), w.forEach((function(e, t) {
                                    w[t] = e + le
                                }))
                            }
                        }
                        U.extend(e, {
                            slides: v,
                            snapGrid: m,
                            slidesGrid: w,
                            slidesSizesGrid: y
                        }), f !== h && e.emit("slidesLengthChange"), m.length !== E && (e.params.watchOverflow && e.checkOverflow(), e.emit("snapGridLengthChange")), w.length !== S && e.emit("slidesGridLengthChange"), (r.watchSlidesProgress || r.watchSlidesVisibility) && e.updateSlidesOffset()
                    }
                }

                function te(e) {
                    var i, t = this,
                        r = [],
                        n = 0;
                    if ("number" == typeof e ? t.setTransition(e) : !0 === e && t.setTransition(t.params.speed), "auto" !== t.params.slidesPerView && t.params.slidesPerView > 1)
                        for (i = 0; i < Math.ceil(t.params.slidesPerView); i += 1) {
                            var o = t.activeIndex + i;
                            if (o > t.slides.length) break;
                            r.push(t.slides.eq(o)[0])
                        } else r.push(t.slides.eq(t.activeIndex)[0]);
                    for (i = 0; i < r.length; i += 1)
                        if (void 0 !== r[i]) {
                            var l = r[i].offsetHeight;
                            n = l > n ? l : n
                        }
                    n && t.$wrapperEl.css("height", n + "px")
                }

                function ae() {
                    for (var e = this, t = e.slides, i = 0; i < t.length; i += 1) t[i].swiperSlideOffset = e.isHorizontal() ? t[i].offsetLeft : t[i].offsetTop
                }

                function ie(e) {
                    void 0 === e && (e = this && this.translate || 0);
                    var t = this,
                        r = t.params,
                        o = t.slides,
                        l = t.rtlTranslate;
                    if (0 !== o.length) {
                        void 0 === o[0].swiperSlideOffset && t.updateSlidesOffset();
                        var d = -e;
                        l && (d = e), o.removeClass(r.slideVisibleClass), t.visibleSlidesIndexes = [], t.visibleSlides = [];
                        for (var i = 0; i < o.length; i += 1) {
                            var c = o[i],
                                h = (d + (r.centeredSlides ? t.minTranslate() : 0) - c.swiperSlideOffset) / (c.swiperSlideSize + r.spaceBetween);
                            if (r.watchSlidesVisibility) {
                                var v = -(d - c.swiperSlideOffset),
                                    f = v + t.slidesSizesGrid[i];
                                (v >= 0 && v < t.size || f > 0 && f <= t.size || v <= 0 && f >= t.size) && (t.visibleSlides.push(c), t.visibleSlidesIndexes.push(i), o.eq(i).addClass(r.slideVisibleClass))
                            }
                            c.progress = l ? -h : h
                        }
                        t.visibleSlides = n(t.visibleSlides)
                    }
                }

                function re(e) {
                    void 0 === e && (e = this && this.translate || 0);
                    var t = this,
                        r = t.params,
                        n = t.maxTranslate() - t.minTranslate(),
                        progress = t.progress,
                        o = t.isBeginning,
                        l = t.isEnd,
                        d = o,
                        c = l;
                    0 === n ? (progress = 0, o = !0, l = !0) : (o = (progress = (e - t.minTranslate()) / n) <= 0, l = progress >= 1), U.extend(t, {
                        progress: progress,
                        isBeginning: o,
                        isEnd: l
                    }), (r.watchSlidesProgress || r.watchSlidesVisibility) && t.updateSlidesProgress(e), o && !d && t.emit("reachBeginning toEdge"), l && !c && t.emit("reachEnd toEdge"), (d && !o || c && !l) && t.emit("fromEdge"), t.emit("progress", progress)
                }

                function se() {
                    var e, t = this,
                        r = t.slides,
                        n = t.params,
                        o = t.$wrapperEl,
                        l = t.activeIndex,
                        d = t.realIndex,
                        c = t.virtual && n.virtual.enabled;
                    r.removeClass(n.slideActiveClass + " " + n.slideNextClass + " " + n.slidePrevClass + " " + n.slideDuplicateActiveClass + " " + n.slideDuplicateNextClass + " " + n.slideDuplicatePrevClass), (e = c ? t.$wrapperEl.find("." + n.slideClass + '[data-swiper-slide-index="' + l + '"]') : r.eq(l)).addClass(n.slideActiveClass), n.loop && (e.hasClass(n.slideDuplicateClass) ? o.children("." + n.slideClass + ":not(." + n.slideDuplicateClass + ')[data-swiper-slide-index="' + d + '"]').addClass(n.slideDuplicateActiveClass) : o.children("." + n.slideClass + "." + n.slideDuplicateClass + '[data-swiper-slide-index="' + d + '"]').addClass(n.slideDuplicateActiveClass));
                    var h = e.nextAll("." + n.slideClass).eq(0).addClass(n.slideNextClass);
                    n.loop && 0 === h.length && (h = r.eq(0)).addClass(n.slideNextClass);
                    var v = e.prevAll("." + n.slideClass).eq(0).addClass(n.slidePrevClass);
                    n.loop && 0 === v.length && (v = r.eq(-1)).addClass(n.slidePrevClass), n.loop && (h.hasClass(n.slideDuplicateClass) ? o.children("." + n.slideClass + ":not(." + n.slideDuplicateClass + ')[data-swiper-slide-index="' + h.attr("data-swiper-slide-index") + '"]').addClass(n.slideDuplicateNextClass) : o.children("." + n.slideClass + "." + n.slideDuplicateClass + '[data-swiper-slide-index="' + h.attr("data-swiper-slide-index") + '"]').addClass(n.slideDuplicateNextClass), v.hasClass(n.slideDuplicateClass) ? o.children("." + n.slideClass + ":not(." + n.slideDuplicateClass + ')[data-swiper-slide-index="' + v.attr("data-swiper-slide-index") + '"]').addClass(n.slideDuplicatePrevClass) : o.children("." + n.slideClass + "." + n.slideDuplicateClass + '[data-swiper-slide-index="' + v.attr("data-swiper-slide-index") + '"]').addClass(n.slideDuplicatePrevClass))
                }

                function ne(e) {
                    var t, r = this,
                        n = r.rtlTranslate ? r.translate : -r.translate,
                        o = r.slidesGrid,
                        l = r.snapGrid,
                        d = r.params,
                        c = r.activeIndex,
                        h = r.realIndex,
                        v = r.snapIndex,
                        f = e;
                    if (void 0 === f) {
                        for (var i = 0; i < o.length; i += 1) void 0 !== o[i + 1] ? n >= o[i] && n < o[i + 1] - (o[i + 1] - o[i]) / 2 ? f = i : n >= o[i] && n < o[i + 1] && (f = i + 1) : n >= o[i] && (f = i);
                        d.normalizeSlideIndex && (f < 0 || void 0 === f) && (f = 0)
                    }
                    if ((t = l.indexOf(n) >= 0 ? l.indexOf(n) : Math.floor(f / d.slidesPerGroup)) >= l.length && (t = l.length - 1), f !== c) {
                        var m = parseInt(r.slides.eq(f).attr("data-swiper-slide-index") || f, 10);
                        U.extend(r, {
                            snapIndex: t,
                            realIndex: m,
                            previousIndex: c,
                            activeIndex: f
                        }), r.emit("activeIndexChange"), r.emit("snapIndexChange"), h !== m && r.emit("realIndexChange"), r.emit("slideChange")
                    } else t !== v && (r.snapIndex = t, r.emit("snapIndexChange"))
                }

                function oe(e) {
                    var t = this,
                        r = t.params,
                        o = n(e.target).closest("." + r.slideClass)[0],
                        l = !1;
                    if (o)
                        for (var i = 0; i < t.slides.length; i += 1) t.slides[i] === o && (l = !0);
                    if (!o || !l) return t.clickedSlide = void 0, void(t.clickedIndex = void 0);
                    t.clickedSlide = o, t.virtual && t.params.virtual.enabled ? t.clickedIndex = parseInt(n(o).attr("data-swiper-slide-index"), 10) : t.clickedIndex = n(o).index(), r.slideToClickedSlide && void 0 !== t.clickedIndex && t.clickedIndex !== t.activeIndex && t.slideToClickedSlide()
                }
                J.prototype.on = function(e, t, r) {
                    var n = this;
                    if ("function" != typeof t) return n;
                    var o = r ? "unshift" : "push";
                    return e.split(" ").forEach((function(e) {
                        n.eventsListeners[e] || (n.eventsListeners[e] = []), n.eventsListeners[e][o](t)
                    })), n
                }, J.prototype.once = function(e, t, r) {
                    var n = this;
                    if ("function" != typeof t) return n;

                    function o() {
                        for (var r = [], l = arguments.length; l--;) r[l] = arguments[l];
                        t.apply(n, r), n.off(e, o)
                    }
                    return n.on(e, o, r)
                }, J.prototype.off = function(e, t) {
                    var r = this;
                    return r.eventsListeners ? (e.split(" ").forEach((function(e) {
                        void 0 === t ? r.eventsListeners[e] = [] : r.eventsListeners[e] && r.eventsListeners[e].length && r.eventsListeners[e].forEach((function(n, o) {
                            n === t && r.eventsListeners[e].splice(o, 1)
                        }))
                    })), r) : r
                }, J.prototype.emit = function() {
                    for (var e = [], t = arguments.length; t--;) e[t] = arguments[t];
                    var r, data, n, o = this;
                    return o.eventsListeners ? ("string" == typeof e[0] || Array.isArray(e[0]) ? (r = e[0], data = e.slice(1, e.length), n = o) : (r = e[0].events, data = e[0].data, n = e[0].context || o), (Array.isArray(r) ? r : r.split(" ")).forEach((function(e) {
                        if (o.eventsListeners && o.eventsListeners[e]) {
                            var t = [];
                            o.eventsListeners[e].forEach((function(e) {
                                t.push(e)
                            })), t.forEach((function(e) {
                                e.apply(n, data)
                            }))
                        }
                    })), o) : o
                }, J.prototype.useModulesParams = function(e) {
                    var t = this;
                    t.modules && Object.keys(t.modules).forEach((function(r) {
                        var n = t.modules[r];
                        n.params && U.extend(e, n.params)
                    }))
                }, J.prototype.useModules = function(e) {
                    void 0 === e && (e = {});
                    var t = this;
                    t.modules && Object.keys(t.modules).forEach((function(r) {
                        var n = t.modules[r],
                            o = e[r] || {};
                        n.instance && Object.keys(n.instance).forEach((function(e) {
                            var r = n.instance[e];
                            t[e] = "function" == typeof r ? r.bind(t) : r
                        })), n.on && t.on && Object.keys(n.on).forEach((function(e) {
                            t.on(e, n.on[e])
                        })), n.create && n.create.bind(t)(o)
                    }))
                }, Z.components.set = function(e) {
                    var t = this;
                    t.use && t.use(e)
                }, J.installModule = function(e) {
                    for (var t = [], r = arguments.length - 1; r-- > 0;) t[r] = arguments[r + 1];
                    var n = this;
                    n.prototype.modules || (n.prototype.modules = {});
                    var o = e.name || Object.keys(n.prototype.modules).length + "_" + U.now();
                    return n.prototype.modules[o] = e, e.proto && Object.keys(e.proto).forEach((function(t) {
                        n.prototype[t] = e.proto[t]
                    })), e.static && Object.keys(e.static).forEach((function(t) {
                        n[t] = e.static[t]
                    })), e.install && e.install.apply(n, t), n
                }, J.use = function(e) {
                    for (var t = [], r = arguments.length - 1; r-- > 0;) t[r] = arguments[r + 1];
                    var n = this;
                    return Array.isArray(e) ? (e.forEach((function(e) {
                        return n.installModule(e)
                    })), n) : n.installModule.apply(n, [e].concat(t))
                }, Object.defineProperties(J, Z);
                var le = {
                    updateSize: Q,
                    updateSlides: ee,
                    updateAutoHeight: te,
                    updateSlidesOffset: ae,
                    updateSlidesProgress: ie,
                    updateProgress: re,
                    updateSlidesClasses: se,
                    updateActiveIndex: ne,
                    updateClickedSlide: oe
                };

                function de(e) {
                    void 0 === e && (e = this.isHorizontal() ? "x" : "y");
                    var t = this,
                        r = t.params,
                        n = t.rtlTranslate,
                        o = t.translate,
                        l = t.$wrapperEl;
                    if (r.virtualTranslate) return n ? -o : o;
                    var d = U.getTranslate(l[0], e);
                    return n && (d = -d), d || 0
                }

                function pe(e, t) {
                    var r = this,
                        n = r.rtlTranslate,
                        o = r.params,
                        l = r.$wrapperEl,
                        progress = r.progress,
                        d = 0,
                        c = 0,
                        h = 0;
                    r.isHorizontal() ? d = n ? -e : e : c = e, o.roundLengths && (d = Math.floor(d), c = Math.floor(c)), o.virtualTranslate || (K.transforms3d ? l.transform("translate3d(" + d + "px, " + c + "px, " + h + "px)") : l.transform("translate(" + d + "px, " + c + "px)")), r.previousTranslate = r.translate, r.translate = r.isHorizontal() ? d : c;
                    var v = r.maxTranslate() - r.minTranslate();
                    (0 === v ? 0 : (e - r.minTranslate()) / v) !== progress && r.updateProgress(e), r.emit("setTranslate", r.translate, t)
                }

                function ce() {
                    return -this.snapGrid[0]
                }

                function ue() {
                    return -this.snapGrid[this.snapGrid.length - 1]
                }
                var he = {
                    getTranslate: de,
                    setTranslate: pe,
                    minTranslate: ce,
                    maxTranslate: ue
                };

                function ve(e, t) {
                    var r = this;
                    r.$wrapperEl.transition(e), r.emit("setTransition", e, t)
                }

                function fe(e, t) {
                    void 0 === e && (e = !0);
                    var r = this,
                        n = r.activeIndex,
                        o = r.params,
                        l = r.previousIndex;
                    o.autoHeight && r.updateAutoHeight();
                    var d = t;
                    if (d || (d = n > l ? "next" : n < l ? "prev" : "reset"), r.emit("transitionStart"), e && n !== l) {
                        if ("reset" === d) return void r.emit("slideResetTransitionStart");
                        r.emit("slideChangeTransitionStart"), "next" === d ? r.emit("slideNextTransitionStart") : r.emit("slidePrevTransitionStart")
                    }
                }

                function me(e, t) {
                    void 0 === e && (e = !0);
                    var r = this,
                        n = r.activeIndex,
                        o = r.previousIndex;
                    r.animating = !1, r.setTransition(0);
                    var l = t;
                    if (l || (l = n > o ? "next" : n < o ? "prev" : "reset"), r.emit("transitionEnd"), e && n !== o) {
                        if ("reset" === l) return void r.emit("slideResetTransitionEnd");
                        r.emit("slideChangeTransitionEnd"), "next" === l ? r.emit("slideNextTransitionEnd") : r.emit("slidePrevTransitionEnd")
                    }
                }
                var ge = {
                    setTransition: ve,
                    transitionStart: fe,
                    transitionEnd: me
                };

                function be(e, t, r, n) {
                    void 0 === e && (e = 0), void 0 === t && (t = this.params.speed), void 0 === r && (r = !0);
                    var o = this,
                        l = e;
                    l < 0 && (l = 0);
                    var d = o.params,
                        c = o.snapGrid,
                        h = o.slidesGrid,
                        v = o.previousIndex,
                        f = o.activeIndex,
                        m = o.rtlTranslate;
                    if (o.animating && d.preventInteractionOnTransition) return !1;
                    var w = Math.floor(l / d.slidesPerGroup);
                    w >= c.length && (w = c.length - 1), (f || d.initialSlide || 0) === (v || 0) && r && o.emit("beforeSlideChangeStart");
                    var y, x = -c[w];
                    if (o.updateProgress(x), d.normalizeSlideIndex)
                        for (var i = 0; i < h.length; i += 1) - Math.floor(100 * x) >= Math.floor(100 * h[i]) && (l = i);
                    if (o.initialized && l !== f) {
                        if (!o.allowSlideNext && x < o.translate && x < o.minTranslate()) return !1;
                        if (!o.allowSlidePrev && x > o.translate && x > o.maxTranslate() && (f || 0) !== l) return !1
                    }
                    return y = l > f ? "next" : l < f ? "prev" : "reset", m && -x === o.translate || !m && x === o.translate ? (o.updateActiveIndex(l), d.autoHeight && o.updateAutoHeight(), o.updateSlidesClasses(), "slide" !== d.effect && o.setTranslate(x), "reset" !== y && (o.transitionStart(r, y), o.transitionEnd(r, y)), !1) : (0 !== t && K.transition ? (o.setTransition(t), o.setTranslate(x), o.updateActiveIndex(l), o.updateSlidesClasses(), o.emit("beforeTransitionStart", t, n), o.transitionStart(r, y), o.animating || (o.animating = !0, o.onSlideToWrapperTransitionEnd || (o.onSlideToWrapperTransitionEnd = function(e) {
                        o && !o.destroyed && e.target === this && (o.$wrapperEl[0].removeEventListener("transitionend", o.onSlideToWrapperTransitionEnd), o.$wrapperEl[0].removeEventListener("webkitTransitionEnd", o.onSlideToWrapperTransitionEnd), o.onSlideToWrapperTransitionEnd = null, delete o.onSlideToWrapperTransitionEnd, o.transitionEnd(r, y))
                    }), o.$wrapperEl[0].addEventListener("transitionend", o.onSlideToWrapperTransitionEnd), o.$wrapperEl[0].addEventListener("webkitTransitionEnd", o.onSlideToWrapperTransitionEnd))) : (o.setTransition(0), o.setTranslate(x), o.updateActiveIndex(l), o.updateSlidesClasses(), o.emit("beforeTransitionStart", t, n), o.transitionStart(r, y), o.transitionEnd(r, y)), !0)
                }

                function we(e, t, r, n) {
                    void 0 === e && (e = 0), void 0 === t && (t = this.params.speed), void 0 === r && (r = !0);
                    var o = this,
                        l = e;
                    return o.params.loop && (l += o.loopedSlides), o.slideTo(l, t, r, n)
                }

                function ye(e, t, r) {
                    void 0 === e && (e = this.params.speed), void 0 === t && (t = !0);
                    var n = this,
                        o = n.params,
                        l = n.animating;
                    return o.loop ? !l && (n.loopFix(), n._clientLeft = n.$wrapperEl[0].clientLeft, n.slideTo(n.activeIndex + o.slidesPerGroup, e, t, r)) : n.slideTo(n.activeIndex + o.slidesPerGroup, e, t, r)
                }

                function xe(e, t, r) {
                    void 0 === e && (e = this.params.speed), void 0 === t && (t = !0);
                    var n = this,
                        o = n.params,
                        l = n.animating,
                        d = n.snapGrid,
                        c = n.slidesGrid,
                        h = n.rtlTranslate;
                    if (o.loop) {
                        if (l) return !1;
                        n.loopFix(), n._clientLeft = n.$wrapperEl[0].clientLeft
                    }

                    function v(e) {
                        return e < 0 ? -Math.floor(Math.abs(e)) : Math.floor(e)
                    }
                    var f, m = v(h ? n.translate : -n.translate),
                        w = d.map((function(e) {
                            return v(e)
                        })),
                        y = (c.map((function(e) {
                            return v(e)
                        })), d[w.indexOf(m)], d[w.indexOf(m) - 1]);
                    return void 0 !== y && (f = c.indexOf(y)) < 0 && (f = n.activeIndex - 1), n.slideTo(f, e, t, r)
                }

                function Te(e, t, r) {
                    void 0 === e && (e = this.params.speed), void 0 === t && (t = !0);
                    var n = this;
                    return n.slideTo(n.activeIndex, e, t, r)
                }

                function Ee(e, t, r) {
                    void 0 === e && (e = this.params.speed), void 0 === t && (t = !0);
                    var n = this,
                        o = n.activeIndex,
                        l = Math.floor(o / n.params.slidesPerGroup);
                    if (l < n.snapGrid.length - 1) {
                        var d = n.rtlTranslate ? n.translate : -n.translate,
                            c = n.snapGrid[l];
                        d - c > (n.snapGrid[l + 1] - c) / 2 && (o = n.params.slidesPerGroup)
                    }
                    return n.slideTo(o, e, t, r)
                }

                function Se() {
                    var e, t = this,
                        r = t.params,
                        o = t.$wrapperEl,
                        l = "auto" === r.slidesPerView ? t.slidesPerViewDynamic() : r.slidesPerView,
                        d = t.clickedIndex;
                    if (r.loop) {
                        if (t.animating) return;
                        e = parseInt(n(t.clickedSlide).attr("data-swiper-slide-index"), 10), r.centeredSlides ? d < t.loopedSlides - l / 2 || d > t.slides.length - t.loopedSlides + l / 2 ? (t.loopFix(), d = o.children("." + r.slideClass + '[data-swiper-slide-index="' + e + '"]:not(.' + r.slideDuplicateClass + ")").eq(0).index(), U.nextTick((function() {
                            t.slideTo(d)
                        }))) : t.slideTo(d) : d > t.slides.length - l ? (t.loopFix(), d = o.children("." + r.slideClass + '[data-swiper-slide-index="' + e + '"]:not(.' + r.slideDuplicateClass + ")").eq(0).index(), U.nextTick((function() {
                            t.slideTo(d)
                        }))) : t.slideTo(d)
                    } else t.slideTo(d)
                }
                var Ce = {
                    slideTo: be,
                    slideToLoop: we,
                    slideNext: ye,
                    slidePrev: xe,
                    slideReset: Te,
                    slideToClosest: Ee,
                    slideToClickedSlide: Se
                };

                function Me() {
                    var t = this,
                        r = t.params,
                        o = t.$wrapperEl;
                    o.children("." + r.slideClass + "." + r.slideDuplicateClass).remove();
                    var l = o.children("." + r.slideClass);
                    if (r.loopFillGroupWithBlank) {
                        var d = r.slidesPerGroup - l.length % r.slidesPerGroup;
                        if (d !== r.slidesPerGroup) {
                            for (var i = 0; i < d; i += 1) {
                                var c = n(e.createElement("div")).addClass(r.slideClass + " " + r.slideBlankClass);
                                o.append(c)
                            }
                            l = o.children("." + r.slideClass)
                        }
                    }
                    "auto" !== r.slidesPerView || r.loopedSlides || (r.loopedSlides = l.length), t.loopedSlides = parseInt(r.loopedSlides || r.slidesPerView, 10), t.loopedSlides += r.loopAdditionalSlides, t.loopedSlides > l.length && (t.loopedSlides = l.length);
                    var h = [],
                        v = [];
                    l.each((function(e, r) {
                        var o = n(r);
                        e < t.loopedSlides && v.push(r), e < l.length && e >= l.length - t.loopedSlides && h.push(r), o.attr("data-swiper-slide-index", e)
                    }));
                    for (var f = 0; f < v.length; f += 1) o.append(n(v[f].cloneNode(!0)).addClass(r.slideDuplicateClass));
                    for (var m = h.length - 1; m >= 0; m -= 1) o.prepend(n(h[m].cloneNode(!0)).addClass(r.slideDuplicateClass))
                }

                function Pe() {
                    var e, t = this,
                        r = t.params,
                        n = t.activeIndex,
                        o = t.slides,
                        l = t.loopedSlides,
                        d = t.allowSlidePrev,
                        c = t.allowSlideNext,
                        h = t.snapGrid,
                        v = t.rtlTranslate;
                    t.allowSlidePrev = !0, t.allowSlideNext = !0;
                    var f = -h[n] - t.getTranslate();
                    n < l ? (e = o.length - 3 * l + n, e += l, t.slideTo(e, 0, !1, !0) && 0 !== f && t.setTranslate((v ? -t.translate : t.translate) - f)) : ("auto" === r.slidesPerView && n >= 2 * l || n >= o.length - l) && (e = -o.length + n + l, e += l, t.slideTo(e, 0, !1, !0) && 0 !== f && t.setTranslate((v ? -t.translate : t.translate) - f)), t.allowSlidePrev = d, t.allowSlideNext = c
                }

                function ke() {
                    var e = this,
                        t = e.$wrapperEl,
                        r = e.params,
                        n = e.slides;
                    t.children("." + r.slideClass + "." + r.slideDuplicateClass + ",." + r.slideClass + "." + r.slideBlankClass).remove(), n.removeAttr("data-swiper-slide-index")
                }
                var ze = {
                    loopCreate: Me,
                    loopFix: Pe,
                    loopDestroy: ke
                };

                function $e(e) {
                    var t = this;
                    if (!(K.touch || !t.params.simulateTouch || t.params.watchOverflow && t.isLocked)) {
                        var r = t.el;
                        r.style.cursor = "move", r.style.cursor = e ? "-webkit-grabbing" : "-webkit-grab", r.style.cursor = e ? "-moz-grabbin" : "-moz-grab", r.style.cursor = e ? "grabbing" : "grab"
                    }
                }

                function Le() {
                    var e = this;
                    K.touch || e.params.watchOverflow && e.isLocked || (e.el.style.cursor = "")
                }
                var Ie = {
                    setGrabCursor: $e,
                    unsetGrabCursor: Le
                };

                function Oe(e) {
                    var t = this,
                        r = t.$wrapperEl,
                        n = t.params;
                    if (n.loop && t.loopDestroy(), "object" == typeof e && "length" in e)
                        for (var i = 0; i < e.length; i += 1) e[i] && r.append(e[i]);
                    else r.append(e);
                    n.loop && t.loopCreate(), n.observer && K.observer || t.update()
                }

                function De(e) {
                    var t = this,
                        r = t.params,
                        n = t.$wrapperEl,
                        o = t.activeIndex;
                    r.loop && t.loopDestroy();
                    var l = o + 1;
                    if ("object" == typeof e && "length" in e) {
                        for (var i = 0; i < e.length; i += 1) e[i] && n.prepend(e[i]);
                        l = o + e.length
                    } else n.prepend(e);
                    r.loop && t.loopCreate(), r.observer && K.observer || t.update(), t.slideTo(l, 0, !1)
                }

                function Ae(e, t) {
                    var r = this,
                        n = r.$wrapperEl,
                        o = r.params,
                        l = r.activeIndex;
                    o.loop && (l -= r.loopedSlides, r.loopDestroy(), r.slides = n.children("." + o.slideClass));
                    var d = r.slides.length;
                    if (e <= 0) r.prependSlide(t);
                    else if (e >= d) r.appendSlide(t);
                    else {
                        for (var c = l > e ? l + 1 : l, h = [], i = d - 1; i >= e; i -= 1) {
                            var v = r.slides.eq(i);
                            v.remove(), h.unshift(v)
                        }
                        if ("object" == typeof t && "length" in t) {
                            for (var f = 0; f < t.length; f += 1) t[f] && n.append(t[f]);
                            c = l > e ? l + t.length : l
                        } else n.append(t);
                        for (var m = 0; m < h.length; m += 1) n.append(h[m]);
                        o.loop && r.loopCreate(), o.observer && K.observer || r.update(), o.loop ? r.slideTo(c + r.loopedSlides, 0, !1) : r.slideTo(c, 0, !1)
                    }
                }

                function Ne(e) {
                    var t = this,
                        r = t.params,
                        n = t.$wrapperEl,
                        o = t.activeIndex;
                    r.loop && (o -= t.loopedSlides, t.loopDestroy(), t.slides = n.children("." + r.slideClass));
                    var l, d = o;
                    if ("object" == typeof e && "length" in e) {
                        for (var i = 0; i < e.length; i += 1) l = e[i], t.slides[l] && t.slides.eq(l).remove(), l < d && (d -= 1);
                        d = Math.max(d, 0)
                    } else l = e, t.slides[l] && t.slides.eq(l).remove(), l < d && (d -= 1), d = Math.max(d, 0);
                    r.loop && t.loopCreate(), r.observer && K.observer || t.update(), r.loop ? t.slideTo(d + t.loopedSlides, 0, !1) : t.slideTo(d, 0, !1)
                }

                function He() {
                    for (var e = this, t = [], i = 0; i < e.slides.length; i += 1) t.push(i);
                    e.removeSlide(t)
                }
                var Be = {
                        appendSlide: Oe,
                        prependSlide: De,
                        addSlide: Ae,
                        removeSlide: Ne,
                        removeAllSlides: He
                    },
                    Ge = function() {
                        var r = t.navigator.userAgent,
                            n = {
                                ios: !1,
                                android: !1,
                                androidChrome: !1,
                                desktop: !1,
                                windows: !1,
                                iphone: !1,
                                ipod: !1,
                                ipad: !1,
                                cordova: t.cordova || t.phonegap,
                                phonegap: t.cordova || t.phonegap
                            },
                            o = r.match(/(Windows Phone);?[\s\/]+([\d.]+)?/),
                            l = r.match(/(Android);?[\s\/]+([\d.]+)?/),
                            d = r.match(/(iPad).*OS\s([\d_]+)/),
                            c = r.match(/(iPod)(.*OS\s([\d_]+))?/),
                            h = !d && r.match(/(iPhone\sOS|iOS)\s([\d_]+)/);
                        if (o && (n.os = "windows", n.osVersion = o[2], n.windows = !0), l && !o && (n.os = "android", n.osVersion = l[2], n.android = !0, n.androidChrome = r.toLowerCase().indexOf("chrome") >= 0), (d || h || c) && (n.os = "ios", n.ios = !0), h && !c && (n.osVersion = h[2].replace(/_/g, "."), n.iphone = !0), d && (n.osVersion = d[2].replace(/_/g, "."), n.ipad = !0), c && (n.osVersion = c[3] ? c[3].replace(/_/g, ".") : null, n.iphone = !0), n.ios && n.osVersion && r.indexOf("Version/") >= 0 && "10" === n.osVersion.split(".")[0] && (n.osVersion = r.toLowerCase().split("version/")[1].split(" ")[0]), n.desktop = !(n.os || n.android || n.webView), n.webView = (h || d || c) && r.match(/.*AppleWebKit(?!.*Safari)/i), n.os && "ios" === n.os) {
                            var v = n.osVersion.split("."),
                                f = e.querySelector('meta[name="viewport"]');
                            n.minimalUi = !n.webView && (c || h) && (1 * v[0] == 7 ? 1 * v[1] >= 1 : 1 * v[0] > 7) && f && f.getAttribute("content").indexOf("minimal-ui") >= 0
                        }
                        return n.pixelRatio = t.devicePixelRatio || 1, n
                    }();

                function Xe(r) {
                    var o = this,
                        data = o.touchEventsData,
                        l = o.params,
                        d = o.touches;
                    if (!o.animating || !l.preventInteractionOnTransition) {
                        var c = r;
                        if (c.originalEvent && (c = c.originalEvent), data.isTouchEvent = "touchstart" === c.type, (data.isTouchEvent || !("which" in c) || 3 !== c.which) && !(!data.isTouchEvent && "button" in c && c.button > 0 || data.isTouched && data.isMoved))
                            if (l.noSwiping && n(c.target).closest(l.noSwipingSelector ? l.noSwipingSelector : "." + l.noSwipingClass)[0]) o.allowClick = !0;
                            else if (!l.swipeHandler || n(c).closest(l.swipeHandler)[0]) {
                            d.currentX = "touchstart" === c.type ? c.targetTouches[0].pageX : c.pageX, d.currentY = "touchstart" === c.type ? c.targetTouches[0].pageY : c.pageY;
                            var h = d.currentX,
                                v = d.currentY,
                                f = l.edgeSwipeDetection || l.iOSEdgeSwipeDetection,
                                m = l.edgeSwipeThreshold || l.iOSEdgeSwipeThreshold;
                            if (!f || !(h <= m || h >= t.screen.width - m)) {
                                if (U.extend(data, {
                                        isTouched: !0,
                                        isMoved: !1,
                                        allowTouchCallbacks: !0,
                                        isScrolling: void 0,
                                        startMoving: void 0
                                    }), d.startX = h, d.startY = v, data.touchStartTime = U.now(), o.allowClick = !0, o.updateSize(), o.swipeDirection = void 0, l.threshold > 0 && (data.allowThresholdMove = !1), "touchstart" !== c.type) {
                                    var w = !0;
                                    n(c.target).is(data.formElements) && (w = !1), e.activeElement && n(e.activeElement).is(data.formElements) && e.activeElement !== c.target && e.activeElement.blur();
                                    var y = w && o.allowTouchMove && l.touchStartPreventDefault;
                                    (l.touchStartForcePreventDefault || y) && c.preventDefault()
                                }
                                o.emit("touchStart", c)
                            }
                        }
                    }
                }

                function Ye(t) {
                    var r = this,
                        data = r.touchEventsData,
                        o = r.params,
                        l = r.touches,
                        d = r.rtlTranslate,
                        c = t;
                    if (c.originalEvent && (c = c.originalEvent), data.isTouched) {
                        if (!data.isTouchEvent || "mousemove" !== c.type) {
                            var h = "touchmove" === c.type ? c.targetTouches[0].pageX : c.pageX,
                                v = "touchmove" === c.type ? c.targetTouches[0].pageY : c.pageY;
                            if (c.preventedByNestedSwiper) return l.startX = h, void(l.startY = v);
                            if (!r.allowTouchMove) return r.allowClick = !1, void(data.isTouched && (U.extend(l, {
                                startX: h,
                                startY: v,
                                currentX: h,
                                currentY: v
                            }), data.touchStartTime = U.now()));
                            if (data.isTouchEvent && o.touchReleaseOnEdges && !o.loop)
                                if (r.isVertical()) {
                                    if (v < l.startY && r.translate <= r.maxTranslate() || v > l.startY && r.translate >= r.minTranslate()) return data.isTouched = !1, void(data.isMoved = !1)
                                } else if (h < l.startX && r.translate <= r.maxTranslate() || h > l.startX && r.translate >= r.minTranslate()) return;
                            if (data.isTouchEvent && e.activeElement && c.target === e.activeElement && n(c.target).is(data.formElements)) return data.isMoved = !0, void(r.allowClick = !1);
                            if (data.allowTouchCallbacks && r.emit("touchMove", c), !(c.targetTouches && c.targetTouches.length > 1)) {
                                l.currentX = h, l.currentY = v;
                                var f, m = l.currentX - l.startX,
                                    w = l.currentY - l.startY;
                                if (!(r.params.threshold && Math.sqrt(Math.pow(m, 2) + Math.pow(w, 2)) < r.params.threshold))
                                    if (void 0 === data.isScrolling && (r.isHorizontal() && l.currentY === l.startY || r.isVertical() && l.currentX === l.startX ? data.isScrolling = !1 : m * m + w * w >= 25 && (f = 180 * Math.atan2(Math.abs(w), Math.abs(m)) / Math.PI, data.isScrolling = r.isHorizontal() ? f > o.touchAngle : 90 - f > o.touchAngle)), data.isScrolling && r.emit("touchMoveOpposite", c), void 0 === data.startMoving && (l.currentX === l.startX && l.currentY === l.startY || (data.startMoving = !0)), data.isScrolling) data.isTouched = !1;
                                    else if (data.startMoving) {
                                    r.allowClick = !1, c.preventDefault(), o.touchMoveStopPropagation && !o.nested && c.stopPropagation(), data.isMoved || (o.loop && r.loopFix(), data.startTranslate = r.getTranslate(), r.setTransition(0), r.animating && r.$wrapperEl.trigger("webkitTransitionEnd transitionend"), data.allowMomentumBounce = !1, !o.grabCursor || !0 !== r.allowSlideNext && !0 !== r.allowSlidePrev || r.setGrabCursor(!0), r.emit("sliderFirstMove", c)), r.emit("sliderMove", c), data.isMoved = !0;
                                    var y = r.isHorizontal() ? m : w;
                                    l.diff = y, y *= o.touchRatio, d && (y = -y), r.swipeDirection = y > 0 ? "prev" : "next", data.currentTranslate = y + data.startTranslate;
                                    var x = !0,
                                        T = o.resistanceRatio;
                                    if (o.touchReleaseOnEdges && (T = 0), y > 0 && data.currentTranslate > r.minTranslate() ? (x = !1, o.resistance && (data.currentTranslate = r.minTranslate() - 1 + Math.pow(-r.minTranslate() + data.startTranslate + y, T))) : y < 0 && data.currentTranslate < r.maxTranslate() && (x = !1, o.resistance && (data.currentTranslate = r.maxTranslate() + 1 - Math.pow(r.maxTranslate() - data.startTranslate - y, T))), x && (c.preventedByNestedSwiper = !0), !r.allowSlideNext && "next" === r.swipeDirection && data.currentTranslate < data.startTranslate && (data.currentTranslate = data.startTranslate), !r.allowSlidePrev && "prev" === r.swipeDirection && data.currentTranslate > data.startTranslate && (data.currentTranslate = data.startTranslate), o.threshold > 0) {
                                        if (!(Math.abs(y) > o.threshold || data.allowThresholdMove)) return void(data.currentTranslate = data.startTranslate);
                                        if (!data.allowThresholdMove) return data.allowThresholdMove = !0, l.startX = l.currentX, l.startY = l.currentY, data.currentTranslate = data.startTranslate, void(l.diff = r.isHorizontal() ? l.currentX - l.startX : l.currentY - l.startY)
                                    }
                                    o.followFinger && ((o.freeMode || o.watchSlidesProgress || o.watchSlidesVisibility) && (r.updateActiveIndex(), r.updateSlidesClasses()), o.freeMode && (0 === data.velocities.length && data.velocities.push({
                                        position: l[r.isHorizontal() ? "startX" : "startY"],
                                        time: data.touchStartTime
                                    }), data.velocities.push({
                                        position: l[r.isHorizontal() ? "currentX" : "currentY"],
                                        time: U.now()
                                    })), r.updateProgress(data.currentTranslate), r.setTranslate(data.currentTranslate))
                                }
                            }
                        }
                    } else data.startMoving && data.isScrolling && r.emit("touchMoveOpposite", c)
                }

                function Ve(e) {
                    var t = this,
                        data = t.touchEventsData,
                        r = t.params,
                        n = t.touches,
                        o = t.rtlTranslate,
                        l = t.$wrapperEl,
                        d = t.slidesGrid,
                        c = t.snapGrid,
                        h = e;
                    if (h.originalEvent && (h = h.originalEvent), data.allowTouchCallbacks && t.emit("touchEnd", h), data.allowTouchCallbacks = !1, !data.isTouched) return data.isMoved && r.grabCursor && t.setGrabCursor(!1), data.isMoved = !1, void(data.startMoving = !1);
                    r.grabCursor && data.isMoved && data.isTouched && (!0 === t.allowSlideNext || !0 === t.allowSlidePrev) && t.setGrabCursor(!1);
                    var v, f = U.now(),
                        m = f - data.touchStartTime;
                    if (t.allowClick && (t.updateClickedSlide(h), t.emit("tap", h), m < 300 && f - data.lastClickTime > 300 && (data.clickTimeout && clearTimeout(data.clickTimeout), data.clickTimeout = U.nextTick((function() {
                            t && !t.destroyed && t.emit("click", h)
                        }), 300)), m < 300 && f - data.lastClickTime < 300 && (data.clickTimeout && clearTimeout(data.clickTimeout), t.emit("doubleTap", h))), data.lastClickTime = U.now(), U.nextTick((function() {
                            t.destroyed || (t.allowClick = !0)
                        })), !data.isTouched || !data.isMoved || !t.swipeDirection || 0 === n.diff || data.currentTranslate === data.startTranslate) return data.isTouched = !1, data.isMoved = !1, void(data.startMoving = !1);
                    if (data.isTouched = !1, data.isMoved = !1, data.startMoving = !1, v = r.followFinger ? o ? t.translate : -t.translate : -data.currentTranslate, r.freeMode) {
                        if (v < -t.minTranslate()) return void t.slideTo(t.activeIndex);
                        if (v > -t.maxTranslate()) return void(t.slides.length < c.length ? t.slideTo(c.length - 1) : t.slideTo(t.slides.length - 1));
                        if (r.freeModeMomentum) {
                            if (data.velocities.length > 1) {
                                var w = data.velocities.pop(),
                                    y = data.velocities.pop(),
                                    x = w.position - y.position,
                                    time = w.time - y.time;
                                t.velocity = x / time, t.velocity /= 2, Math.abs(t.velocity) < r.freeModeMinimumVelocity && (t.velocity = 0), (time > 150 || U.now() - w.time > 300) && (t.velocity = 0)
                            } else t.velocity = 0;
                            t.velocity *= r.freeModeMomentumVelocityRatio, data.velocities.length = 0;
                            var T = 1e3 * r.freeModeMomentumRatio,
                                E = t.velocity * T,
                                S = t.translate + E;
                            o && (S = -S);
                            var C, M, P = !1,
                                k = 20 * Math.abs(t.velocity) * r.freeModeMomentumBounceRatio;
                            if (S < t.maxTranslate()) r.freeModeMomentumBounce ? (S + t.maxTranslate() < -k && (S = t.maxTranslate() - k), C = t.maxTranslate(), P = !0, data.allowMomentumBounce = !0) : S = t.maxTranslate(), r.loop && r.centeredSlides && (M = !0);
                            else if (S > t.minTranslate()) r.freeModeMomentumBounce ? (S - t.minTranslate() > k && (S = t.minTranslate() + k), C = t.minTranslate(), P = !0, data.allowMomentumBounce = !0) : S = t.minTranslate(), r.loop && r.centeredSlides && (M = !0);
                            else if (r.freeModeSticky) {
                                for (var z, $ = 0; $ < c.length; $ += 1)
                                    if (c[$] > -S) {
                                        z = $;
                                        break
                                    }
                                S = -(S = Math.abs(c[z] - S) < Math.abs(c[z - 1] - S) || "next" === t.swipeDirection ? c[z] : c[z - 1])
                            }
                            if (M && t.once("transitionEnd", (function() {
                                    t.loopFix()
                                })), 0 !== t.velocity) T = o ? Math.abs((-S - t.translate) / t.velocity) : Math.abs((S - t.translate) / t.velocity);
                            else if (r.freeModeSticky) return void t.slideToClosest();
                            r.freeModeMomentumBounce && P ? (t.updateProgress(C), t.setTransition(T), t.setTranslate(S), t.transitionStart(!0, t.swipeDirection), t.animating = !0, l.transitionEnd((function() {
                                t && !t.destroyed && data.allowMomentumBounce && (t.emit("momentumBounce"), t.setTransition(r.speed), t.setTranslate(C), l.transitionEnd((function() {
                                    t && !t.destroyed && t.transitionEnd()
                                })))
                            }))) : t.velocity ? (t.updateProgress(S), t.setTransition(T), t.setTranslate(S), t.transitionStart(!0, t.swipeDirection), t.animating || (t.animating = !0, l.transitionEnd((function() {
                                t && !t.destroyed && t.transitionEnd()
                            })))) : t.updateProgress(S), t.updateActiveIndex(), t.updateSlidesClasses()
                        } else if (r.freeModeSticky) return void t.slideToClosest();
                        (!r.freeModeMomentum || m >= r.longSwipesMs) && (t.updateProgress(), t.updateActiveIndex(), t.updateSlidesClasses())
                    } else {
                        for (var L = 0, I = t.slidesSizesGrid[0], i = 0; i < d.length; i += r.slidesPerGroup) void 0 !== d[i + r.slidesPerGroup] ? v >= d[i] && v < d[i + r.slidesPerGroup] && (L = i, I = d[i + r.slidesPerGroup] - d[i]) : v >= d[i] && (L = i, I = d[d.length - 1] - d[d.length - 2]);
                        var O = (v - d[L]) / I;
                        if (m > r.longSwipesMs) {
                            if (!r.longSwipes) return void t.slideTo(t.activeIndex);
                            "next" === t.swipeDirection && (O >= r.longSwipesRatio ? t.slideTo(L + r.slidesPerGroup) : t.slideTo(L)), "prev" === t.swipeDirection && (O > 1 - r.longSwipesRatio ? t.slideTo(L + r.slidesPerGroup) : t.slideTo(L))
                        } else {
                            if (!r.shortSwipes) return void t.slideTo(t.activeIndex);
                            "next" === t.swipeDirection && t.slideTo(L + r.slidesPerGroup), "prev" === t.swipeDirection && t.slideTo(L)
                        }
                    }
                }

                function je() {
                    var e = this,
                        t = e.params,
                        r = e.el;
                    if (!r || 0 !== r.offsetWidth) {
                        t.breakpoints && e.setBreakpoint();
                        var n = e.allowSlideNext,
                            o = e.allowSlidePrev,
                            l = e.snapGrid;
                        if (e.allowSlideNext = !0, e.allowSlidePrev = !0, e.updateSize(), e.updateSlides(), t.freeMode) {
                            var d = Math.min(Math.max(e.translate, e.maxTranslate()), e.minTranslate());
                            e.setTranslate(d), e.updateActiveIndex(), e.updateSlidesClasses(), t.autoHeight && e.updateAutoHeight()
                        } else e.updateSlidesClasses(), ("auto" === t.slidesPerView || t.slidesPerView > 1) && e.isEnd && !e.params.centeredSlides ? e.slideTo(e.slides.length - 1, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0);
                        e.allowSlidePrev = o, e.allowSlideNext = n, e.params.watchOverflow && l !== e.snapGrid && e.checkOverflow()
                    }
                }

                function Fe(e) {
                    var t = this;
                    t.allowClick || (t.params.preventClicks && e.preventDefault(), t.params.preventClicksPropagation && t.animating && (e.stopPropagation(), e.stopImmediatePropagation()))
                }

                function Re() {
                    var t = this,
                        r = t.params,
                        n = t.touchEvents,
                        o = t.el,
                        l = t.wrapperEl;
                    t.onTouchStart = Xe.bind(t), t.onTouchMove = Ye.bind(t), t.onTouchEnd = Ve.bind(t), t.onClick = Fe.bind(t);
                    var d = "container" === r.touchEventsTarget ? o : l,
                        c = !!r.nested;
                    if (K.touch || !K.pointerEvents && !K.prefixedPointerEvents) {
                        if (K.touch) {
                            var h = !("touchstart" !== n.start || !K.passiveListener || !r.passiveListeners) && {
                                passive: !0,
                                capture: !1
                            };
                            d.addEventListener(n.start, t.onTouchStart, h), d.addEventListener(n.move, t.onTouchMove, K.passiveListener ? {
                                passive: !1,
                                capture: c
                            } : c), d.addEventListener(n.end, t.onTouchEnd, h)
                        }(r.simulateTouch && !Ge.ios && !Ge.android || r.simulateTouch && !K.touch && Ge.ios) && (d.addEventListener("mousedown", t.onTouchStart, !1), e.addEventListener("mousemove", t.onTouchMove, c), e.addEventListener("mouseup", t.onTouchEnd, !1))
                    } else d.addEventListener(n.start, t.onTouchStart, !1), e.addEventListener(n.move, t.onTouchMove, c), e.addEventListener(n.end, t.onTouchEnd, !1);
                    (r.preventClicks || r.preventClicksPropagation) && d.addEventListener("click", t.onClick, !0), t.on(Ge.ios || Ge.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", je, !0)
                }

                function qe() {
                    var t = this,
                        r = t.params,
                        n = t.touchEvents,
                        o = t.el,
                        l = t.wrapperEl,
                        d = "container" === r.touchEventsTarget ? o : l,
                        c = !!r.nested;
                    if (K.touch || !K.pointerEvents && !K.prefixedPointerEvents) {
                        if (K.touch) {
                            var h = !("onTouchStart" !== n.start || !K.passiveListener || !r.passiveListeners) && {
                                passive: !0,
                                capture: !1
                            };
                            d.removeEventListener(n.start, t.onTouchStart, h), d.removeEventListener(n.move, t.onTouchMove, c), d.removeEventListener(n.end, t.onTouchEnd, h)
                        }(r.simulateTouch && !Ge.ios && !Ge.android || r.simulateTouch && !K.touch && Ge.ios) && (d.removeEventListener("mousedown", t.onTouchStart, !1), e.removeEventListener("mousemove", t.onTouchMove, c), e.removeEventListener("mouseup", t.onTouchEnd, !1))
                    } else d.removeEventListener(n.start, t.onTouchStart, !1), e.removeEventListener(n.move, t.onTouchMove, c), e.removeEventListener(n.end, t.onTouchEnd, !1);
                    (r.preventClicks || r.preventClicksPropagation) && d.removeEventListener("click", t.onClick, !0), t.off(Ge.ios || Ge.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", je)
                }
                var We = {
                    attachEvents: Re,
                    detachEvents: qe
                };

                function _e() {
                    var e = this,
                        t = e.activeIndex,
                        r = e.initialized,
                        n = e.loopedSlides;
                    void 0 === n && (n = 0);
                    var o = e.params,
                        l = o.breakpoints;
                    if (l && (!l || 0 !== Object.keys(l).length)) {
                        var d = e.getBreakpoint(l);
                        if (d && e.currentBreakpoint !== d) {
                            var c = d in l ? l[d] : void 0;
                            c && ["slidesPerView", "spaceBetween", "slidesPerGroup"].forEach((function(param) {
                                var e = c[param];
                                void 0 !== e && (c[param] = "slidesPerView" !== param || "AUTO" !== e && "auto" !== e ? "slidesPerView" === param ? parseFloat(e) : parseInt(e, 10) : "auto")
                            }));
                            var h = c || e.originalParams,
                                v = o.loop && h.slidesPerView !== o.slidesPerView;
                            U.extend(e.params, h), U.extend(e, {
                                allowTouchMove: e.params.allowTouchMove,
                                allowSlideNext: e.params.allowSlideNext,
                                allowSlidePrev: e.params.allowSlidePrev
                            }), e.currentBreakpoint = d, v && r && (e.loopDestroy(), e.loopCreate(), e.updateSlides(), e.slideTo(t - n + e.loopedSlides, 0, !1)), e.emit("breakpoint", h)
                        }
                    }
                }

                function Ue(e) {
                    var r = this;
                    if (e) {
                        var n = !1,
                            o = [];
                        Object.keys(e).forEach((function(e) {
                            o.push(e)
                        })), o.sort((function(a, b) {
                            return parseInt(a, 10) - parseInt(b, 10)
                        }));
                        for (var i = 0; i < o.length; i += 1) {
                            var l = o[i];
                            r.params.breakpointsInverse ? l <= t.innerWidth && (n = l) : l >= t.innerWidth && !n && (n = l)
                        }
                        return n || "max"
                    }
                }
                var Ke = {
                        setBreakpoint: _e,
                        getBreakpoint: Ue
                    },
                    Je = function() {
                        function e() {
                            var e = t.navigator.userAgent.toLowerCase();
                            return e.indexOf("safari") >= 0 && e.indexOf("chrome") < 0 && e.indexOf("android") < 0
                        }
                        return {
                            isIE: !!t.navigator.userAgent.match(/Trident/g) || !!t.navigator.userAgent.match(/MSIE/g),
                            isEdge: !!t.navigator.userAgent.match(/Edge/g),
                            isSafari: e(),
                            isUiWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(t.navigator.userAgent)
                        }
                    }();

                function Ze() {
                    var e = this,
                        t = e.classNames,
                        r = e.params,
                        n = e.rtl,
                        o = e.$el,
                        l = [];
                    l.push(r.direction), r.freeMode && l.push("free-mode"), K.flexbox || l.push("no-flexbox"), r.autoHeight && l.push("autoheight"), n && l.push("rtl"), r.slidesPerColumn > 1 && l.push("multirow"), Ge.android && l.push("android"), Ge.ios && l.push("ios"), (Je.isIE || Je.isEdge) && (K.pointerEvents || K.prefixedPointerEvents) && l.push("wp8-" + r.direction), l.forEach((function(e) {
                        t.push(r.containerModifierClass + e)
                    })), o.addClass(t.join(" "))
                }

                function Qe() {
                    var e = this,
                        t = e.$el,
                        r = e.classNames;
                    t.removeClass(r.join(" "))
                }

                function et(e, r, n, o, l, d) {
                    var image;

                    function c() {
                        d && d()
                    }
                    e.complete && l ? c() : r ? ((image = new t.Image).onload = c, image.onerror = c, o && (image.sizes = o), n && (image.srcset = n), r && (image.src = r)) : c()
                }

                function tt() {
                    var e = this;

                    function t() {
                        null != e && e && !e.destroyed && (void 0 !== e.imagesLoaded && (e.imagesLoaded += 1), e.imagesLoaded === e.imagesToLoad.length && (e.params.updateOnImagesReady && e.update(), e.emit("imagesReady")))
                    }
                    e.imagesToLoad = e.$el.find("img");
                    for (var i = 0; i < e.imagesToLoad.length; i += 1) {
                        var r = e.imagesToLoad[i];
                        e.loadImage(r, r.currentSrc || r.getAttribute("src"), r.srcset || r.getAttribute("srcset"), r.sizes || r.getAttribute("sizes"), !0, t)
                    }
                }

                function at() {
                    var e = this,
                        t = e.isLocked;
                    e.isLocked = 1 === e.snapGrid.length, e.allowSlideNext = !e.isLocked, e.allowSlidePrev = !e.isLocked, t !== e.isLocked && e.emit(e.isLocked ? "lock" : "unlock"), t && t !== e.isLocked && (e.isEnd = !1, e.navigation.update())
                }
                var it = {
                        init: !0,
                        direction: "horizontal",
                        touchEventsTarget: "container",
                        initialSlide: 0,
                        speed: 300,
                        preventInteractionOnTransition: !1,
                        edgeSwipeDetection: !1,
                        edgeSwipeThreshold: 20,
                        freeMode: !1,
                        freeModeMomentum: !0,
                        freeModeMomentumRatio: 1,
                        freeModeMomentumBounce: !0,
                        freeModeMomentumBounceRatio: 1,
                        freeModeMomentumVelocityRatio: 1,
                        freeModeSticky: !1,
                        freeModeMinimumVelocity: .02,
                        autoHeight: !1,
                        setWrapperSize: !1,
                        virtualTranslate: !1,
                        effect: "slide",
                        breakpoints: void 0,
                        breakpointsInverse: !1,
                        spaceBetween: 0,
                        slidesPerView: 1,
                        slidesPerColumn: 1,
                        slidesPerColumnFill: "column",
                        slidesPerGroup: 1,
                        centeredSlides: !1,
                        slidesOffsetBefore: 0,
                        slidesOffsetAfter: 0,
                        normalizeSlideIndex: !0,
                        centerInsufficientSlides: !1,
                        watchOverflow: !1,
                        roundLengths: !1,
                        touchRatio: 1,
                        touchAngle: 45,
                        simulateTouch: !0,
                        shortSwipes: !0,
                        longSwipes: !0,
                        longSwipesRatio: .5,
                        longSwipesMs: 300,
                        followFinger: !0,
                        allowTouchMove: !0,
                        threshold: 0,
                        touchMoveStopPropagation: !0,
                        touchStartPreventDefault: !0,
                        touchStartForcePreventDefault: !1,
                        touchReleaseOnEdges: !1,
                        uniqueNavElements: !0,
                        resistance: !0,
                        resistanceRatio: .85,
                        watchSlidesProgress: !1,
                        watchSlidesVisibility: !1,
                        grabCursor: !1,
                        preventClicks: !0,
                        preventClicksPropagation: !0,
                        slideToClickedSlide: !1,
                        preloadImages: !0,
                        updateOnImagesReady: !0,
                        loop: !1,
                        loopAdditionalSlides: 0,
                        loopedSlides: null,
                        loopFillGroupWithBlank: !1,
                        allowSlidePrev: !0,
                        allowSlideNext: !0,
                        swipeHandler: null,
                        noSwiping: !0,
                        noSwipingClass: "swiper-no-swiping",
                        noSwipingSelector: null,
                        passiveListeners: !0,
                        containerModifierClass: "swiper-container-",
                        slideClass: "swiper-slide",
                        slideBlankClass: "swiper-slide-invisible-blank",
                        slideActiveClass: "swiper-slide-active",
                        slideDuplicateActiveClass: "swiper-slide-duplicate-active",
                        slideVisibleClass: "swiper-slide-visible",
                        slideDuplicateClass: "swiper-slide-duplicate",
                        slideNextClass: "swiper-slide-next",
                        slideDuplicateNextClass: "swiper-slide-duplicate-next",
                        slidePrevClass: "swiper-slide-prev",
                        slideDuplicatePrevClass: "swiper-slide-duplicate-prev",
                        wrapperClass: "swiper-wrapper",
                        runCallbacksOnInit: !0
                    },
                    st = {
                        update: le,
                        translate: he,
                        transition: ge,
                        slide: Ce,
                        loop: ze,
                        grabCursor: Ie,
                        manipulation: Be,
                        events: We,
                        breakpoints: Ke,
                        checkOverflow: {
                            checkOverflow: at
                        },
                        classes: {
                            addClasses: Ze,
                            removeClasses: Qe
                        },
                        images: {
                            loadImage: et,
                            preloadImages: tt
                        }
                    },
                    nt = {},
                    ot = function(e) {
                        function t() {
                            for (var r, o, l, d = [], c = arguments.length; c--;) d[c] = arguments[c];
                            1 === d.length && d[0].constructor && d[0].constructor === Object ? l = d[0] : (o = (r = d)[0], l = r[1]), l || (l = {}), l = U.extend({}, l), o && !l.el && (l.el = o), e.call(this, l), Object.keys(st).forEach((function(e) {
                                Object.keys(st[e]).forEach((function(r) {
                                    t.prototype[r] || (t.prototype[r] = st[e][r])
                                }))
                            }));
                            var h = this;
                            void 0 === h.modules && (h.modules = {}), Object.keys(h.modules).forEach((function(e) {
                                var t = h.modules[e];
                                if (t.params) {
                                    var r = Object.keys(t.params)[0],
                                        n = t.params[r];
                                    if ("object" != typeof n || null === n) return;
                                    if (!(r in l) || !("enabled" in n)) return;
                                    !0 === l[r] && (l[r] = {
                                        enabled: !0
                                    }), "object" != typeof l[r] || "enabled" in l[r] || (l[r].enabled = !0), l[r] || (l[r] = {
                                        enabled: !1
                                    })
                                }
                            }));
                            var v = U.extend({}, it);
                            h.useModulesParams(v), h.params = U.extend({}, v, nt, l), h.originalParams = U.extend({}, h.params), h.passedParams = U.extend({}, l), h.$ = n;
                            var f = n(h.params.el);
                            if (o = f[0]) {
                                if (f.length > 1) {
                                    var m = [];
                                    return f.each((function(e, r) {
                                        var n = U.extend({}, l, {
                                            el: r
                                        });
                                        m.push(new t(n))
                                    })), m
                                }
                                o.swiper = h, f.data("swiper", h);
                                var w, y, x = f.children("." + h.params.wrapperClass);
                                return U.extend(h, {
                                    $el: f,
                                    el: o,
                                    $wrapperEl: x,
                                    wrapperEl: x[0],
                                    classNames: [],
                                    slides: n(),
                                    slidesGrid: [],
                                    snapGrid: [],
                                    slidesSizesGrid: [],
                                    isHorizontal: function() {
                                        return "horizontal" === h.params.direction
                                    },
                                    isVertical: function() {
                                        return "vertical" === h.params.direction
                                    },
                                    rtl: "rtl" === o.dir.toLowerCase() || "rtl" === f.css("direction"),
                                    rtlTranslate: "horizontal" === h.params.direction && ("rtl" === o.dir.toLowerCase() || "rtl" === f.css("direction")),
                                    wrongRTL: "-webkit-box" === x.css("display"),
                                    activeIndex: 0,
                                    realIndex: 0,
                                    isBeginning: !0,
                                    isEnd: !1,
                                    translate: 0,
                                    previousTranslate: 0,
                                    progress: 0,
                                    velocity: 0,
                                    animating: !1,
                                    allowSlideNext: h.params.allowSlideNext,
                                    allowSlidePrev: h.params.allowSlidePrev,
                                    touchEvents: (w = ["touchstart", "touchmove", "touchend"], y = ["mousedown", "mousemove", "mouseup"], K.pointerEvents ? y = ["pointerdown", "pointermove", "pointerup"] : K.prefixedPointerEvents && (y = ["MSPointerDown", "MSPointerMove", "MSPointerUp"]), h.touchEventsTouch = {
                                        start: w[0],
                                        move: w[1],
                                        end: w[2]
                                    }, h.touchEventsDesktop = {
                                        start: y[0],
                                        move: y[1],
                                        end: y[2]
                                    }, K.touch || !h.params.simulateTouch ? h.touchEventsTouch : h.touchEventsDesktop),
                                    touchEventsData: {
                                        isTouched: void 0,
                                        isMoved: void 0,
                                        allowTouchCallbacks: void 0,
                                        touchStartTime: void 0,
                                        isScrolling: void 0,
                                        currentTranslate: void 0,
                                        startTranslate: void 0,
                                        allowThresholdMove: void 0,
                                        formElements: "input, select, option, textarea, button, video",
                                        lastClickTime: U.now(),
                                        clickTimeout: void 0,
                                        velocities: [],
                                        allowMomentumBounce: void 0,
                                        isTouchEvent: void 0,
                                        startMoving: void 0
                                    },
                                    allowClick: !0,
                                    allowTouchMove: h.params.allowTouchMove,
                                    touches: {
                                        startX: 0,
                                        startY: 0,
                                        currentX: 0,
                                        currentY: 0,
                                        diff: 0
                                    },
                                    imagesToLoad: [],
                                    imagesLoaded: 0
                                }), h.useModules(), h.params.init && h.init(), h
                            }
                        }
                        e && (t.__proto__ = e), t.prototype = Object.create(e && e.prototype), t.prototype.constructor = t;
                        var r = {
                            extendedDefaults: {
                                configurable: !0
                            },
                            defaults: {
                                configurable: !0
                            },
                            Class: {
                                configurable: !0
                            },
                            $: {
                                configurable: !0
                            }
                        };
                        return t.prototype.slidesPerViewDynamic = function() {
                            var e = this,
                                t = e.params,
                                r = e.slides,
                                n = e.slidesGrid,
                                o = e.size,
                                l = e.activeIndex,
                                d = 1;
                            if (t.centeredSlides) {
                                for (var c, h = r[l].swiperSlideSize, i = l + 1; i < r.length; i += 1) r[i] && !c && (d += 1, (h += r[i].swiperSlideSize) > o && (c = !0));
                                for (var v = l - 1; v >= 0; v -= 1) r[v] && !c && (d += 1, (h += r[v].swiperSlideSize) > o && (c = !0))
                            } else
                                for (var f = l + 1; f < r.length; f += 1) n[f] - n[l] < o && (d += 1);
                            return d
                        }, t.prototype.update = function() {
                            var e = this;
                            if (e && !e.destroyed) {
                                var t = e.snapGrid,
                                    r = e.params;
                                r.breakpoints && e.setBreakpoint(), e.updateSize(), e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), e.params.freeMode ? (n(), e.params.autoHeight && e.updateAutoHeight()) : (("auto" === e.params.slidesPerView || e.params.slidesPerView > 1) && e.isEnd && !e.params.centeredSlides ? e.slideTo(e.slides.length - 1, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0)) || n(), r.watchOverflow && t !== e.snapGrid && e.checkOverflow(), e.emit("update")
                            }

                            function n() {
                                var t = e.rtlTranslate ? -1 * e.translate : e.translate,
                                    r = Math.min(Math.max(t, e.maxTranslate()), e.minTranslate());
                                e.setTranslate(r), e.updateActiveIndex(), e.updateSlidesClasses()
                            }
                        }, t.prototype.init = function() {
                            var e = this;
                            e.initialized || (e.emit("beforeInit"), e.params.breakpoints && e.setBreakpoint(), e.addClasses(), e.params.loop && e.loopCreate(), e.updateSize(), e.updateSlides(), e.params.watchOverflow && e.checkOverflow(), e.params.grabCursor && e.setGrabCursor(), e.params.preloadImages && e.preloadImages(), e.params.loop ? e.slideTo(e.params.initialSlide + e.loopedSlides, 0, e.params.runCallbacksOnInit) : e.slideTo(e.params.initialSlide, 0, e.params.runCallbacksOnInit), e.attachEvents(), e.initialized = !0, e.emit("init"))
                        }, t.prototype.destroy = function(e, t) {
                            void 0 === e && (e = !0), void 0 === t && (t = !0);
                            var r = this,
                                n = r.params,
                                o = r.$el,
                                l = r.$wrapperEl,
                                d = r.slides;
                            return void 0 === r.params || r.destroyed || (r.emit("beforeDestroy"), r.initialized = !1, r.detachEvents(), n.loop && r.loopDestroy(), t && (r.removeClasses(), o.removeAttr("style"), l.removeAttr("style"), d && d.length && d.removeClass([n.slideVisibleClass, n.slideActiveClass, n.slideNextClass, n.slidePrevClass].join(" ")).removeAttr("style").removeAttr("data-swiper-slide-index").removeAttr("data-swiper-column").removeAttr("data-swiper-row")), r.emit("destroy"), Object.keys(r.eventsListeners).forEach((function(e) {
                                r.off(e)
                            })), !1 !== e && (r.$el[0].swiper = null, r.$el.data("swiper", null), U.deleteProps(r)), r.destroyed = !0), null
                        }, t.extendDefaults = function(e) {
                            U.extend(nt, e)
                        }, r.extendedDefaults.get = function() {
                            return nt
                        }, r.defaults.get = function() {
                            return it
                        }, r.Class.get = function() {
                            return e
                        }, r.$.get = function() {
                            return n
                        }, Object.defineProperties(t, r), t
                    }(J),
                    lt = {
                        name: "device",
                        proto: {
                            device: Ge
                        },
                        static: {
                            device: Ge
                        }
                    },
                    pt = {
                        name: "support",
                        proto: {
                            support: K
                        },
                        static: {
                            support: K
                        }
                    },
                    ct = {
                        name: "browser",
                        proto: {
                            browser: Je
                        },
                        static: {
                            browser: Je
                        }
                    },
                    ut = {
                        name: "resize",
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                resize: {
                                    resizeHandler: function() {
                                        e && !e.destroyed && e.initialized && (e.emit("beforeResize"), e.emit("resize"))
                                    },
                                    orientationChangeHandler: function() {
                                        e && !e.destroyed && e.initialized && e.emit("orientationchange")
                                    }
                                }
                            })
                        },
                        on: {
                            init: function() {
                                var e = this;
                                t.addEventListener("resize", e.resize.resizeHandler), t.addEventListener("orientationchange", e.resize.orientationChangeHandler)
                            },
                            destroy: function() {
                                var e = this;
                                t.removeEventListener("resize", e.resize.resizeHandler), t.removeEventListener("orientationchange", e.resize.orientationChangeHandler)
                            }
                        }
                    },
                    ht = {
                        func: t.MutationObserver || t.WebkitMutationObserver,
                        attach: function(e, r) {
                            void 0 === r && (r = {});
                            var n = this,
                                o = new(0, ht.func)((function(e) {
                                    if (1 !== e.length) {
                                        var r = function() {
                                            n.emit("observerUpdate", e[0])
                                        };
                                        t.requestAnimationFrame ? t.requestAnimationFrame(r) : t.setTimeout(r, 0)
                                    } else n.emit("observerUpdate", e[0])
                                }));
                            o.observe(e, {
                                attributes: void 0 === r.attributes || r.attributes,
                                childList: void 0 === r.childList || r.childList,
                                characterData: void 0 === r.characterData || r.characterData
                            }), n.observer.observers.push(o)
                        },
                        init: function() {
                            var e = this;
                            if (K.observer && e.params.observer) {
                                if (e.params.observeParents)
                                    for (var t = e.$el.parents(), i = 0; i < t.length; i += 1) e.observer.attach(t[i]);
                                e.observer.attach(e.$el[0], {
                                    childList: e.params.observeSlideChildren
                                }), e.observer.attach(e.$wrapperEl[0], {
                                    attributes: !1
                                })
                            }
                        },
                        destroy: function() {
                            var e = this;
                            e.observer.observers.forEach((function(e) {
                                e.disconnect()
                            })), e.observer.observers = []
                        }
                    },
                    vt = {
                        name: "observer",
                        params: {
                            observer: !1,
                            observeParents: !1,
                            observeSlideChildren: !1
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                observer: {
                                    init: ht.init.bind(e),
                                    attach: ht.attach.bind(e),
                                    destroy: ht.destroy.bind(e),
                                    observers: []
                                }
                            })
                        },
                        on: {
                            init: function() {
                                this.observer.init()
                            },
                            destroy: function() {
                                this.observer.destroy()
                            }
                        }
                    },
                    ft = {
                        update: function(e) {
                            var t = this,
                                r = t.params,
                                n = r.slidesPerView,
                                o = r.slidesPerGroup,
                                l = r.centeredSlides,
                                d = t.params.virtual,
                                c = d.addSlidesBefore,
                                h = d.addSlidesAfter,
                                v = t.virtual,
                                f = v.from,
                                m = v.to,
                                w = v.slides,
                                y = v.slidesGrid,
                                x = v.renderSlide,
                                T = v.offset;
                            t.updateActiveIndex();
                            var E, S, C, M = t.activeIndex || 0;
                            E = t.rtlTranslate ? "right" : t.isHorizontal() ? "left" : "top", l ? (S = Math.floor(n / 2) + o + c, C = Math.floor(n / 2) + o + h) : (S = n + (o - 1) + c, C = o + h);
                            var P = Math.max((M || 0) - C, 0),
                                k = Math.min((M || 0) + S, w.length - 1),
                                z = (t.slidesGrid[P] || 0) - (t.slidesGrid[0] || 0);

                            function $() {
                                t.updateSlides(), t.updateProgress(), t.updateSlidesClasses(), t.lazy && t.params.lazy.enabled && t.lazy.load()
                            }
                            if (U.extend(t.virtual, {
                                    from: P,
                                    to: k,
                                    offset: z,
                                    slidesGrid: t.slidesGrid
                                }), f === P && m === k && !e) return t.slidesGrid !== y && z !== T && t.slides.css(E, z + "px"), void t.updateProgress();
                            if (t.params.virtual.renderExternal) return t.params.virtual.renderExternal.call(t, {
                                offset: z,
                                from: P,
                                to: k,
                                slides: function() {
                                    for (var e = [], i = P; i <= k; i += 1) e.push(w[i]);
                                    return e
                                }()
                            }), void $();
                            var L = [],
                                I = [];
                            if (e) t.$wrapperEl.find("." + t.params.slideClass).remove();
                            else
                                for (var i = f; i <= m; i += 1)(i < P || i > k) && t.$wrapperEl.find("." + t.params.slideClass + '[data-swiper-slide-index="' + i + '"]').remove();
                            for (var O = 0; O < w.length; O += 1) O >= P && O <= k && (void 0 === m || e ? I.push(O) : (O > m && I.push(O), O < f && L.push(O)));
                            I.forEach((function(e) {
                                t.$wrapperEl.append(x(w[e], e))
                            })), L.sort((function(a, b) {
                                return b - a
                            })).forEach((function(e) {
                                t.$wrapperEl.prepend(x(w[e], e))
                            })), t.$wrapperEl.children(".swiper-slide").css(E, z + "px"), $()
                        },
                        renderSlide: function(e, t) {
                            var r = this,
                                o = r.params.virtual;
                            if (o.cache && r.virtual.cache[t]) return r.virtual.cache[t];
                            var l = o.renderSlide ? n(o.renderSlide.call(r, e, t)) : n('<div class="' + r.params.slideClass + '" data-swiper-slide-index="' + t + '">' + e + "</div>");
                            return l.attr("data-swiper-slide-index") || l.attr("data-swiper-slide-index", t), o.cache && (r.virtual.cache[t] = l), l
                        },
                        appendSlide: function(e) {
                            var t = this;
                            t.virtual.slides.push(e), t.virtual.update(!0)
                        },
                        prependSlide: function(e) {
                            var t = this;
                            if (t.virtual.slides.unshift(e), t.params.virtual.cache) {
                                var r = t.virtual.cache,
                                    n = {};
                                Object.keys(r).forEach((function(e) {
                                    n[e + 1] = r[e]
                                })), t.virtual.cache = n
                            }
                            t.virtual.update(!0), t.slideNext(0)
                        }
                    },
                    mt = {
                        name: "virtual",
                        params: {
                            virtual: {
                                enabled: !1,
                                slides: [],
                                cache: !0,
                                renderSlide: null,
                                renderExternal: null,
                                addSlidesBefore: 0,
                                addSlidesAfter: 0
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                virtual: {
                                    update: ft.update.bind(e),
                                    appendSlide: ft.appendSlide.bind(e),
                                    prependSlide: ft.prependSlide.bind(e),
                                    renderSlide: ft.renderSlide.bind(e),
                                    slides: e.params.virtual.slides,
                                    cache: {}
                                }
                            })
                        },
                        on: {
                            beforeInit: function() {
                                var e = this;
                                if (e.params.virtual.enabled) {
                                    e.classNames.push(e.params.containerModifierClass + "virtual");
                                    var t = {
                                        watchSlidesProgress: !0
                                    };
                                    U.extend(e.params, t), U.extend(e.originalParams, t), e.params.initialSlide || e.virtual.update()
                                }
                            },
                            setTranslate: function() {
                                var e = this;
                                e.params.virtual.enabled && e.virtual.update()
                            }
                        }
                    },
                    gt = {
                        handle: function(r) {
                            var n = this,
                                o = n.rtlTranslate,
                                l = r;
                            l.originalEvent && (l = l.originalEvent);
                            var d = l.keyCode || l.charCode;
                            if (!n.allowSlideNext && (n.isHorizontal() && 39 === d || n.isVertical() && 40 === d)) return !1;
                            if (!n.allowSlidePrev && (n.isHorizontal() && 37 === d || n.isVertical() && 38 === d)) return !1;
                            if (!(l.shiftKey || l.altKey || l.ctrlKey || l.metaKey || e.activeElement && e.activeElement.nodeName && ("input" === e.activeElement.nodeName.toLowerCase() || "textarea" === e.activeElement.nodeName.toLowerCase()))) {
                                if (n.params.keyboard.onlyInViewport && (37 === d || 39 === d || 38 === d || 40 === d)) {
                                    var c = !1;
                                    if (n.$el.parents("." + n.params.slideClass).length > 0 && 0 === n.$el.parents("." + n.params.slideActiveClass).length) return;
                                    var h = t.innerWidth,
                                        v = t.innerHeight,
                                        f = n.$el.offset();
                                    o && (f.left -= n.$el[0].scrollLeft);
                                    for (var m = [
                                            [f.left, f.top],
                                            [f.left + n.width, f.top],
                                            [f.left, f.top + n.height],
                                            [f.left + n.width, f.top + n.height]
                                        ], i = 0; i < m.length; i += 1) {
                                        var w = m[i];
                                        w[0] >= 0 && w[0] <= h && w[1] >= 0 && w[1] <= v && (c = !0)
                                    }
                                    if (!c) return
                                }
                                n.isHorizontal() ? (37 !== d && 39 !== d || (l.preventDefault ? l.preventDefault() : l.returnValue = !1), (39 === d && !o || 37 === d && o) && n.slideNext(), (37 === d && !o || 39 === d && o) && n.slidePrev()) : (38 !== d && 40 !== d || (l.preventDefault ? l.preventDefault() : l.returnValue = !1), 40 === d && n.slideNext(), 38 === d && n.slidePrev()), n.emit("keyPress", d)
                            }
                        },
                        enable: function() {
                            var t = this;
                            t.keyboard.enabled || (n(e).on("keydown", t.keyboard.handle), t.keyboard.enabled = !0)
                        },
                        disable: function() {
                            var t = this;
                            t.keyboard.enabled && (n(e).off("keydown", t.keyboard.handle), t.keyboard.enabled = !1)
                        }
                    },
                    bt = {
                        name: "keyboard",
                        params: {
                            keyboard: {
                                enabled: !1,
                                onlyInViewport: !0
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                keyboard: {
                                    enabled: !1,
                                    enable: gt.enable.bind(e),
                                    disable: gt.disable.bind(e),
                                    handle: gt.handle.bind(e)
                                }
                            })
                        },
                        on: {
                            init: function() {
                                var e = this;
                                e.params.keyboard.enabled && e.keyboard.enable()
                            },
                            destroy: function() {
                                var e = this;
                                e.keyboard.enabled && e.keyboard.disable()
                            }
                        }
                    };

                function wt() {
                    var t = "onwheel",
                        r = t in e;
                    if (!r) {
                        var element = e.createElement("div");
                        element.setAttribute(t, "return;"), r = "function" == typeof element[t]
                    }
                    return !r && e.implementation && e.implementation.hasFeature && !0 !== e.implementation.hasFeature("", "") && (r = e.implementation.hasFeature("Events.wheel", "3.0")), r
                }
                var yt = {
                        lastScrollTime: U.now(),
                        event: t.navigator.userAgent.indexOf("firefox") > -1 ? "DOMMouseScroll" : wt() ? "wheel" : "mousewheel",
                        normalize: function(e) {
                            var t = 10,
                                r = 40,
                                n = 800,
                                o = 0,
                                l = 0,
                                d = 0,
                                c = 0;
                            return "detail" in e && (l = e.detail), "wheelDelta" in e && (l = -e.wheelDelta / 120), "wheelDeltaY" in e && (l = -e.wheelDeltaY / 120), "wheelDeltaX" in e && (o = -e.wheelDeltaX / 120), "axis" in e && e.axis === e.HORIZONTAL_AXIS && (o = l, l = 0), d = o * t, c = l * t, "deltaY" in e && (c = e.deltaY), "deltaX" in e && (d = e.deltaX), (d || c) && e.deltaMode && (1 === e.deltaMode ? (d *= r, c *= r) : (d *= n, c *= n)), d && !o && (o = d < 1 ? -1 : 1), c && !l && (l = c < 1 ? -1 : 1), {
                                spinX: o,
                                spinY: l,
                                pixelX: d,
                                pixelY: c
                            }
                        },
                        handleMouseEnter: function() {
                            this.mouseEntered = !0
                        },
                        handleMouseLeave: function() {
                            this.mouseEntered = !1
                        },
                        handle: function(e) {
                            var r = e,
                                n = this,
                                o = n.params.mousewheel;
                            if (!n.mouseEntered && !o.releaseOnEdges) return !0;
                            r.originalEvent && (r = r.originalEvent);
                            var l = 0,
                                d = n.rtlTranslate ? -1 : 1,
                                data = yt.normalize(r);
                            if (o.forceToAxis)
                                if (n.isHorizontal()) {
                                    if (!(Math.abs(data.pixelX) > Math.abs(data.pixelY))) return !0;
                                    l = data.pixelX * d
                                } else {
                                    if (!(Math.abs(data.pixelY) > Math.abs(data.pixelX))) return !0;
                                    l = data.pixelY
                                }
                            else l = Math.abs(data.pixelX) > Math.abs(data.pixelY) ? -data.pixelX * d : -data.pixelY;
                            if (0 === l) return !0;
                            if (o.invert && (l = -l), n.params.freeMode) {
                                n.params.loop && n.loopFix();
                                var c = n.getTranslate() + l * o.sensitivity,
                                    h = n.isBeginning,
                                    v = n.isEnd;
                                if (c >= n.minTranslate() && (c = n.minTranslate()), c <= n.maxTranslate() && (c = n.maxTranslate()), n.setTransition(0), n.setTranslate(c), n.updateProgress(), n.updateActiveIndex(), n.updateSlidesClasses(), (!h && n.isBeginning || !v && n.isEnd) && n.updateSlidesClasses(), n.params.freeModeSticky && (clearTimeout(n.mousewheel.timeout), n.mousewheel.timeout = U.nextTick((function() {
                                        n.slideToClosest()
                                    }), 300)), n.emit("scroll", r), n.params.autoplay && n.params.autoplayDisableOnInteraction && n.autoplay.stop(), c === n.minTranslate() || c === n.maxTranslate()) return !0
                            } else {
                                if (U.now() - n.mousewheel.lastScrollTime > 60)
                                    if (l < 0)
                                        if (n.isEnd && !n.params.loop || n.animating) {
                                            if (o.releaseOnEdges) return !0
                                        } else n.slideNext(), n.emit("scroll", r);
                                else if (n.isBeginning && !n.params.loop || n.animating) {
                                    if (o.releaseOnEdges) return !0
                                } else n.slidePrev(), n.emit("scroll", r);
                                n.mousewheel.lastScrollTime = (new t.Date).getTime()
                            }
                            return r.preventDefault ? r.preventDefault() : r.returnValue = !1, !1
                        },
                        enable: function() {
                            var e = this;
                            if (!yt.event) return !1;
                            if (e.mousewheel.enabled) return !1;
                            var t = e.$el;
                            return "container" !== e.params.mousewheel.eventsTarged && (t = n(e.params.mousewheel.eventsTarged)), t.on("mouseenter", e.mousewheel.handleMouseEnter), t.on("mouseleave", e.mousewheel.handleMouseLeave), t.on(yt.event, e.mousewheel.handle), e.mousewheel.enabled = !0, !0
                        },
                        disable: function() {
                            var e = this;
                            if (!yt.event) return !1;
                            if (!e.mousewheel.enabled) return !1;
                            var t = e.$el;
                            return "container" !== e.params.mousewheel.eventsTarged && (t = n(e.params.mousewheel.eventsTarged)), t.off(yt.event, e.mousewheel.handle), e.mousewheel.enabled = !1, !0
                        }
                    },
                    xt = {
                        update: function() {
                            var e = this,
                                t = e.params.navigation;
                            if (!e.params.loop) {
                                var r = e.navigation,
                                    n = r.$nextEl,
                                    o = r.$prevEl;
                                o && o.length > 0 && (e.isBeginning ? o.addClass(t.disabledClass) : o.removeClass(t.disabledClass), o[e.params.watchOverflow && e.isLocked ? "addClass" : "removeClass"](t.lockClass)), n && n.length > 0 && (e.isEnd ? n.addClass(t.disabledClass) : n.removeClass(t.disabledClass), n[e.params.watchOverflow && e.isLocked ? "addClass" : "removeClass"](t.lockClass))
                            }
                        },
                        onPrevClick: function(e) {
                            var t = this;
                            e.preventDefault(), t.isBeginning && !t.params.loop || t.slidePrev()
                        },
                        onNextClick: function(e) {
                            var t = this;
                            e.preventDefault(), t.isEnd && !t.params.loop || t.slideNext()
                        },
                        init: function() {
                            var e, t, r = this,
                                o = r.params.navigation;
                            (o.nextEl || o.prevEl) && (o.nextEl && (e = n(o.nextEl), r.params.uniqueNavElements && "string" == typeof o.nextEl && e.length > 1 && 1 === r.$el.find(o.nextEl).length && (e = r.$el.find(o.nextEl))), o.prevEl && (t = n(o.prevEl), r.params.uniqueNavElements && "string" == typeof o.prevEl && t.length > 1 && 1 === r.$el.find(o.prevEl).length && (t = r.$el.find(o.prevEl))), e && e.length > 0 && e.on("click", r.navigation.onNextClick), t && t.length > 0 && t.on("click", r.navigation.onPrevClick), U.extend(r.navigation, {
                                $nextEl: e,
                                nextEl: e && e[0],
                                $prevEl: t,
                                prevEl: t && t[0]
                            }))
                        },
                        destroy: function() {
                            var e = this,
                                t = e.navigation,
                                r = t.$nextEl,
                                n = t.$prevEl;
                            r && r.length && (r.off("click", e.navigation.onNextClick), r.removeClass(e.params.navigation.disabledClass)), n && n.length && (n.off("click", e.navigation.onPrevClick), n.removeClass(e.params.navigation.disabledClass))
                        }
                    },
                    Tt = {
                        update: function() {
                            var e = this,
                                t = e.rtl,
                                r = e.params.pagination;
                            if (r.el && e.pagination.el && e.pagination.$el && 0 !== e.pagination.$el.length) {
                                var o, l = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length,
                                    d = e.pagination.$el,
                                    c = e.params.loop ? Math.ceil((l - 2 * e.loopedSlides) / e.params.slidesPerGroup) : e.snapGrid.length;
                                if (e.params.loop ? ((o = Math.ceil((e.activeIndex - e.loopedSlides) / e.params.slidesPerGroup)) > l - 1 - 2 * e.loopedSlides && (o -= l - 2 * e.loopedSlides), o > c - 1 && (o -= c), o < 0 && "bullets" !== e.params.paginationType && (o = c + o)) : o = void 0 !== e.snapIndex ? e.snapIndex : e.activeIndex || 0, "bullets" === r.type && e.pagination.bullets && e.pagination.bullets.length > 0) {
                                    var h, v, f, m = e.pagination.bullets;
                                    if (r.dynamicBullets && (e.pagination.bulletSize = m.eq(0)[e.isHorizontal() ? "outerWidth" : "outerHeight"](!0), d.css(e.isHorizontal() ? "width" : "height", e.pagination.bulletSize * (r.dynamicMainBullets + 4) + "px"), r.dynamicMainBullets > 1 && void 0 !== e.previousIndex && (e.pagination.dynamicBulletIndex += o - e.previousIndex, e.pagination.dynamicBulletIndex > r.dynamicMainBullets - 1 ? e.pagination.dynamicBulletIndex = r.dynamicMainBullets - 1 : e.pagination.dynamicBulletIndex < 0 && (e.pagination.dynamicBulletIndex = 0)), h = o - e.pagination.dynamicBulletIndex, f = ((v = h + (Math.min(m.length, r.dynamicMainBullets) - 1)) + h) / 2), m.removeClass(r.bulletActiveClass + " " + r.bulletActiveClass + "-next " + r.bulletActiveClass + "-next-next " + r.bulletActiveClass + "-prev " + r.bulletActiveClass + "-prev-prev " + r.bulletActiveClass + "-main"), d.length > 1) m.each((function(e, t) {
                                        var l = n(t),
                                            d = l.index();
                                        d === o && l.addClass(r.bulletActiveClass), r.dynamicBullets && (d >= h && d <= v && l.addClass(r.bulletActiveClass + "-main"), d === h && l.prev().addClass(r.bulletActiveClass + "-prev").prev().addClass(r.bulletActiveClass + "-prev-prev"), d === v && l.next().addClass(r.bulletActiveClass + "-next").next().addClass(r.bulletActiveClass + "-next-next"))
                                    }));
                                    else if (m.eq(o).addClass(r.bulletActiveClass), r.dynamicBullets) {
                                        for (var w = m.eq(h), y = m.eq(v), i = h; i <= v; i += 1) m.eq(i).addClass(r.bulletActiveClass + "-main");
                                        w.prev().addClass(r.bulletActiveClass + "-prev").prev().addClass(r.bulletActiveClass + "-prev-prev"), y.next().addClass(r.bulletActiveClass + "-next").next().addClass(r.bulletActiveClass + "-next-next")
                                    }
                                    if (r.dynamicBullets) {
                                        var x = Math.min(m.length, r.dynamicMainBullets + 4),
                                            T = (e.pagination.bulletSize * x - e.pagination.bulletSize) / 2 - f * e.pagination.bulletSize,
                                            E = t ? "right" : "left";
                                        m.css(e.isHorizontal() ? E : "top", T + "px")
                                    }
                                }
                                if ("fraction" === r.type && (d.find("." + r.currentClass).text(r.formatFractionCurrent(o + 1)), d.find("." + r.totalClass).text(r.formatFractionTotal(c))), "progressbar" === r.type) {
                                    var S;
                                    S = r.progressbarOpposite ? e.isHorizontal() ? "vertical" : "horizontal" : e.isHorizontal() ? "horizontal" : "vertical";
                                    var C = (o + 1) / c,
                                        M = 1,
                                        P = 1;
                                    "horizontal" === S ? M = C : P = C, d.find("." + r.progressbarFillClass).transform("translate3d(0,0,0) scaleX(" + M + ") scaleY(" + P + ")").transition(e.params.speed)
                                }
                                "custom" === r.type && r.renderCustom ? (d.html(r.renderCustom(e, o + 1, c)), e.emit("paginationRender", e, d[0])) : e.emit("paginationUpdate", e, d[0]), d[e.params.watchOverflow && e.isLocked ? "addClass" : "removeClass"](r.lockClass)
                            }
                        },
                        render: function() {
                            var e = this,
                                t = e.params.pagination;
                            if (t.el && e.pagination.el && e.pagination.$el && 0 !== e.pagination.$el.length) {
                                var r = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length,
                                    n = e.pagination.$el,
                                    o = "";
                                if ("bullets" === t.type) {
                                    for (var l = e.params.loop ? Math.ceil((r - 2 * e.loopedSlides) / e.params.slidesPerGroup) : e.snapGrid.length, i = 0; i < l; i += 1) t.renderBullet ? o += t.renderBullet.call(e, i, t.bulletClass) : o += "<" + t.bulletElement + ' class="' + t.bulletClass + '"></' + t.bulletElement + ">";
                                    n.html(o), e.pagination.bullets = n.find("." + t.bulletClass)
                                }
                                "fraction" === t.type && (o = t.renderFraction ? t.renderFraction.call(e, t.currentClass, t.totalClass) : '<span class="' + t.currentClass + '"></span> / <span class="' + t.totalClass + '"></span>', n.html(o)), "progressbar" === t.type && (o = t.renderProgressbar ? t.renderProgressbar.call(e, t.progressbarFillClass) : '<span class="' + t.progressbarFillClass + '"></span>', n.html(o)), "custom" !== t.type && e.emit("paginationRender", e.pagination.$el[0])
                            }
                        },
                        init: function() {
                            var e = this,
                                t = e.params.pagination;
                            if (t.el) {
                                var r = n(t.el);
                                0 !== r.length && (e.params.uniqueNavElements && "string" == typeof t.el && r.length > 1 && 1 === e.$el.find(t.el).length && (r = e.$el.find(t.el)), "bullets" === t.type && t.clickable && r.addClass(t.clickableClass), r.addClass(t.modifierClass + t.type), "bullets" === t.type && t.dynamicBullets && (r.addClass("" + t.modifierClass + t.type + "-dynamic"), e.pagination.dynamicBulletIndex = 0, t.dynamicMainBullets < 1 && (t.dynamicMainBullets = 1)), "progressbar" === t.type && t.progressbarOpposite && r.addClass(t.progressbarOppositeClass), t.clickable && r.on("click", "." + t.bulletClass, (function(t) {
                                    t.preventDefault();
                                    var r = n(this).index() * e.params.slidesPerGroup;
                                    e.params.loop && (r += e.loopedSlides), e.slideTo(r)
                                })), U.extend(e.pagination, {
                                    $el: r,
                                    el: r[0]
                                }))
                            }
                        },
                        destroy: function() {
                            var e = this,
                                t = e.params.pagination;
                            if (t.el && e.pagination.el && e.pagination.$el && 0 !== e.pagination.$el.length) {
                                var r = e.pagination.$el;
                                r.removeClass(t.hiddenClass), r.removeClass(t.modifierClass + t.type), e.pagination.bullets && e.pagination.bullets.removeClass(t.bulletActiveClass), t.clickable && r.off("click", "." + t.bulletClass)
                            }
                        }
                    },
                    Et = {
                        setTranslate: function() {
                            var e = this;
                            if (e.params.scrollbar.el && e.scrollbar.el) {
                                var t = e.scrollbar,
                                    r = e.rtlTranslate,
                                    progress = e.progress,
                                    n = t.dragSize,
                                    o = t.trackSize,
                                    l = t.$dragEl,
                                    d = t.$el,
                                    c = e.params.scrollbar,
                                    h = n,
                                    v = (o - n) * progress;
                                r ? (v = -v) > 0 ? (h = n - v, v = 0) : -v + n > o && (h = o + v) : v < 0 ? (h = n + v, v = 0) : v + n > o && (h = o - v), e.isHorizontal() ? (K.transforms3d ? l.transform("translate3d(" + v + "px, 0, 0)") : l.transform("translateX(" + v + "px)"), l[0].style.width = h + "px") : (K.transforms3d ? l.transform("translate3d(0px, " + v + "px, 0)") : l.transform("translateY(" + v + "px)"), l[0].style.height = h + "px"), c.hide && (clearTimeout(e.scrollbar.timeout), d[0].style.opacity = 1, e.scrollbar.timeout = setTimeout((function() {
                                    d[0].style.opacity = 0, d.transition(400)
                                }), 1e3))
                            }
                        },
                        setTransition: function(e) {
                            var t = this;
                            t.params.scrollbar.el && t.scrollbar.el && t.scrollbar.$dragEl.transition(e)
                        },
                        updateSize: function() {
                            var e = this;
                            if (e.params.scrollbar.el && e.scrollbar.el) {
                                var t = e.scrollbar,
                                    r = t.$dragEl,
                                    n = t.$el;
                                r[0].style.width = "", r[0].style.height = "";
                                var o, l = e.isHorizontal() ? n[0].offsetWidth : n[0].offsetHeight,
                                    d = e.size / e.virtualSize,
                                    c = d * (l / e.size);
                                o = "auto" === e.params.scrollbar.dragSize ? l * d : parseInt(e.params.scrollbar.dragSize, 10), e.isHorizontal() ? r[0].style.width = o + "px" : r[0].style.height = o + "px", n[0].style.display = d >= 1 ? "none" : "", e.params.scrollbarHide && (n[0].style.opacity = 0), U.extend(t, {
                                    trackSize: l,
                                    divider: d,
                                    moveDivider: c,
                                    dragSize: o
                                }), t.$el[e.params.watchOverflow && e.isLocked ? "addClass" : "removeClass"](e.params.scrollbar.lockClass)
                            }
                        },
                        setDragPosition: function(e) {
                            var t, r = this,
                                n = r.scrollbar,
                                o = r.rtlTranslate,
                                l = n.$el,
                                d = n.dragSize,
                                c = n.trackSize;
                            t = ((r.isHorizontal() ? "touchstart" === e.type || "touchmove" === e.type ? e.targetTouches[0].pageX : e.pageX || e.clientX : "touchstart" === e.type || "touchmove" === e.type ? e.targetTouches[0].pageY : e.pageY || e.clientY) - l.offset()[r.isHorizontal() ? "left" : "top"] - d / 2) / (c - d), t = Math.max(Math.min(t, 1), 0), o && (t = 1 - t);
                            var h = r.minTranslate() + (r.maxTranslate() - r.minTranslate()) * t;
                            r.updateProgress(h), r.setTranslate(h), r.updateActiveIndex(), r.updateSlidesClasses()
                        },
                        onDragStart: function(e) {
                            var t = this,
                                r = t.params.scrollbar,
                                n = t.scrollbar,
                                o = t.$wrapperEl,
                                l = n.$el,
                                d = n.$dragEl;
                            t.scrollbar.isTouched = !0, e.preventDefault(), e.stopPropagation(), o.transition(100), d.transition(100), n.setDragPosition(e), clearTimeout(t.scrollbar.dragTimeout), l.transition(0), r.hide && l.css("opacity", 1), t.emit("scrollbarDragStart", e)
                        },
                        onDragMove: function(e) {
                            var t = this,
                                r = t.scrollbar,
                                n = t.$wrapperEl,
                                o = r.$el,
                                l = r.$dragEl;
                            t.scrollbar.isTouched && (e.preventDefault ? e.preventDefault() : e.returnValue = !1, r.setDragPosition(e), n.transition(0), o.transition(0), l.transition(0), t.emit("scrollbarDragMove", e))
                        },
                        onDragEnd: function(e) {
                            var t = this,
                                r = t.params.scrollbar,
                                n = t.scrollbar.$el;
                            t.scrollbar.isTouched && (t.scrollbar.isTouched = !1, r.hide && (clearTimeout(t.scrollbar.dragTimeout), t.scrollbar.dragTimeout = U.nextTick((function() {
                                n.css("opacity", 0), n.transition(400)
                            }), 1e3)), t.emit("scrollbarDragEnd", e), r.snapOnRelease && t.slideToClosest())
                        },
                        enableDraggable: function() {
                            var t = this;
                            if (t.params.scrollbar.el) {
                                var r = t.scrollbar,
                                    n = t.touchEventsTouch,
                                    o = t.touchEventsDesktop,
                                    l = t.params,
                                    d = r.$el[0],
                                    c = !(!K.passiveListener || !l.passiveListeners) && {
                                        passive: !1,
                                        capture: !1
                                    },
                                    h = !(!K.passiveListener || !l.passiveListeners) && {
                                        passive: !0,
                                        capture: !1
                                    };
                                K.touch ? (d.addEventListener(n.start, t.scrollbar.onDragStart, c), d.addEventListener(n.move, t.scrollbar.onDragMove, c), d.addEventListener(n.end, t.scrollbar.onDragEnd, h)) : (d.addEventListener(o.start, t.scrollbar.onDragStart, c), e.addEventListener(o.move, t.scrollbar.onDragMove, c), e.addEventListener(o.end, t.scrollbar.onDragEnd, h))
                            }
                        },
                        disableDraggable: function() {
                            var t = this;
                            if (t.params.scrollbar.el) {
                                var r = t.scrollbar,
                                    n = t.touchEventsTouch,
                                    o = t.touchEventsDesktop,
                                    l = t.params,
                                    d = r.$el[0],
                                    c = !(!K.passiveListener || !l.passiveListeners) && {
                                        passive: !1,
                                        capture: !1
                                    },
                                    h = !(!K.passiveListener || !l.passiveListeners) && {
                                        passive: !0,
                                        capture: !1
                                    };
                                K.touch ? (d.removeEventListener(n.start, t.scrollbar.onDragStart, c), d.removeEventListener(n.move, t.scrollbar.onDragMove, c), d.removeEventListener(n.end, t.scrollbar.onDragEnd, h)) : (d.removeEventListener(o.start, t.scrollbar.onDragStart, c), e.removeEventListener(o.move, t.scrollbar.onDragMove, c), e.removeEventListener(o.end, t.scrollbar.onDragEnd, h))
                            }
                        },
                        init: function() {
                            var e = this;
                            if (e.params.scrollbar.el) {
                                var t = e.scrollbar,
                                    r = e.$el,
                                    o = e.params.scrollbar,
                                    l = n(o.el);
                                e.params.uniqueNavElements && "string" == typeof o.el && l.length > 1 && 1 === r.find(o.el).length && (l = r.find(o.el));
                                var d = l.find("." + e.params.scrollbar.dragClass);
                                0 === d.length && (d = n('<div class="' + e.params.scrollbar.dragClass + '"></div>'), l.append(d)), U.extend(t, {
                                    $el: l,
                                    el: l[0],
                                    $dragEl: d,
                                    dragEl: d[0]
                                }), o.draggable && t.enableDraggable()
                            }
                        },
                        destroy: function() {
                            this.scrollbar.disableDraggable()
                        }
                    },
                    St = {
                        setTransform: function(e, progress) {
                            var t = this,
                                r = t.rtl,
                                o = n(e),
                                l = r ? -1 : 1,
                                p = o.attr("data-swiper-parallax") || "0",
                                d = o.attr("data-swiper-parallax-x"),
                                c = o.attr("data-swiper-parallax-y"),
                                h = o.attr("data-swiper-parallax-scale"),
                                v = o.attr("data-swiper-parallax-opacity");
                            if (d || c ? (d = d || "0", c = c || "0") : t.isHorizontal() ? (d = p, c = "0") : (c = p, d = "0"), d = d.indexOf("%") >= 0 ? parseInt(d, 10) * progress * l + "%" : d * progress * l + "px", c = c.indexOf("%") >= 0 ? parseInt(c, 10) * progress + "%" : c * progress + "px", null != v) {
                                var f = v - (v - 1) * (1 - Math.abs(progress));
                                o[0].style.opacity = f
                            }
                            if (null == h) o.transform("translate3d(" + d + ", " + c + ", 0px)");
                            else {
                                var m = h - (h - 1) * (1 - Math.abs(progress));
                                o.transform("translate3d(" + d + ", " + c + ", 0px) scale(" + m + ")")
                            }
                        },
                        setTranslate: function() {
                            var e = this,
                                t = e.$el,
                                r = e.slides,
                                progress = e.progress,
                                o = e.snapGrid;
                            t.children("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y]").each((function(t, r) {
                                e.parallax.setTransform(r, progress)
                            })), r.each((function(t, r) {
                                var l = r.progress;
                                e.params.slidesPerGroup > 1 && "auto" !== e.params.slidesPerView && (l += Math.ceil(t / 2) - progress * (o.length - 1)), l = Math.min(Math.max(l, -1), 1), n(r).find("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y]").each((function(t, r) {
                                    e.parallax.setTransform(r, l)
                                }))
                            }))
                        },
                        setTransition: function(e) {
                            void 0 === e && (e = this.params.speed), this.$el.find("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y]").each((function(t, r) {
                                var o = n(r),
                                    l = parseInt(o.attr("data-swiper-parallax-duration"), 10) || e;
                                0 === e && (l = 0), o.transition(l)
                            }))
                        }
                    },
                    Ct = {
                        getDistanceBetweenTouches: function(e) {
                            if (e.targetTouches.length < 2) return 1;
                            var t = e.targetTouches[0].pageX,
                                r = e.targetTouches[0].pageY,
                                n = e.targetTouches[1].pageX,
                                o = e.targetTouches[1].pageY;
                            return Math.sqrt(Math.pow(n - t, 2) + Math.pow(o - r, 2))
                        },
                        onGestureStart: function(e) {
                            var t = this,
                                r = t.params.zoom,
                                o = t.zoom,
                                l = o.gesture;
                            if (o.fakeGestureTouched = !1, o.fakeGestureMoved = !1, !K.gestures) {
                                if ("touchstart" !== e.type || "touchstart" === e.type && e.targetTouches.length < 2) return;
                                o.fakeGestureTouched = !0, l.scaleStart = Ct.getDistanceBetweenTouches(e)
                            }
                            l.$slideEl && l.$slideEl.length || (l.$slideEl = n(e.target).closest(".swiper-slide"), 0 === l.$slideEl.length && (l.$slideEl = t.slides.eq(t.activeIndex)), l.$imageEl = l.$slideEl.find("img, svg, canvas"), l.$imageWrapEl = l.$imageEl.parent("." + r.containerClass), l.maxRatio = l.$imageWrapEl.attr("data-swiper-zoom") || r.maxRatio, 0 !== l.$imageWrapEl.length) ? (l.$imageEl.transition(0), t.zoom.isScaling = !0) : l.$imageEl = void 0
                        },
                        onGestureChange: function(e) {
                            var t = this,
                                r = t.params.zoom,
                                n = t.zoom,
                                o = n.gesture;
                            if (!K.gestures) {
                                if ("touchmove" !== e.type || "touchmove" === e.type && e.targetTouches.length < 2) return;
                                n.fakeGestureMoved = !0, o.scaleMove = Ct.getDistanceBetweenTouches(e)
                            }
                            o.$imageEl && 0 !== o.$imageEl.length && (K.gestures ? n.scale = e.scale * n.currentScale : n.scale = o.scaleMove / o.scaleStart * n.currentScale, n.scale > o.maxRatio && (n.scale = o.maxRatio - 1 + Math.pow(n.scale - o.maxRatio + 1, .5)), n.scale < r.minRatio && (n.scale = r.minRatio + 1 - Math.pow(r.minRatio - n.scale + 1, .5)), o.$imageEl.transform("translate3d(0,0,0) scale(" + n.scale + ")"))
                        },
                        onGestureEnd: function(e) {
                            var t = this,
                                r = t.params.zoom,
                                n = t.zoom,
                                o = n.gesture;
                            if (!K.gestures) {
                                if (!n.fakeGestureTouched || !n.fakeGestureMoved) return;
                                if ("touchend" !== e.type || "touchend" === e.type && e.changedTouches.length < 2 && !Ge.android) return;
                                n.fakeGestureTouched = !1, n.fakeGestureMoved = !1
                            }
                            o.$imageEl && 0 !== o.$imageEl.length && (n.scale = Math.max(Math.min(n.scale, o.maxRatio), r.minRatio), o.$imageEl.transition(t.params.speed).transform("translate3d(0,0,0) scale(" + n.scale + ")"), n.currentScale = n.scale, n.isScaling = !1, 1 === n.scale && (o.$slideEl = void 0))
                        },
                        onTouchStart: function(e) {
                            var t = this.zoom,
                                r = t.gesture,
                                image = t.image;
                            r.$imageEl && 0 !== r.$imageEl.length && (image.isTouched || (Ge.android && e.preventDefault(), image.isTouched = !0, image.touchesStart.x = "touchstart" === e.type ? e.targetTouches[0].pageX : e.pageX, image.touchesStart.y = "touchstart" === e.type ? e.targetTouches[0].pageY : e.pageY))
                        },
                        onTouchMove: function(e) {
                            var t = this,
                                r = t.zoom,
                                n = r.gesture,
                                image = r.image,
                                o = r.velocity;
                            if (n.$imageEl && 0 !== n.$imageEl.length && (t.allowClick = !1, image.isTouched && n.$slideEl)) {
                                image.isMoved || (image.width = n.$imageEl[0].offsetWidth, image.height = n.$imageEl[0].offsetHeight, image.startX = U.getTranslate(n.$imageWrapEl[0], "x") || 0, image.startY = U.getTranslate(n.$imageWrapEl[0], "y") || 0, n.slideWidth = n.$slideEl[0].offsetWidth, n.slideHeight = n.$slideEl[0].offsetHeight, n.$imageWrapEl.transition(0), t.rtl && (image.startX = -image.startX, image.startY = -image.startY));
                                var l = image.width * r.scale,
                                    d = image.height * r.scale;
                                if (!(l < n.slideWidth && d < n.slideHeight)) {
                                    if (image.minX = Math.min(n.slideWidth / 2 - l / 2, 0), image.maxX = -image.minX, image.minY = Math.min(n.slideHeight / 2 - d / 2, 0), image.maxY = -image.minY, image.touchesCurrent.x = "touchmove" === e.type ? e.targetTouches[0].pageX : e.pageX, image.touchesCurrent.y = "touchmove" === e.type ? e.targetTouches[0].pageY : e.pageY, !image.isMoved && !r.isScaling) {
                                        if (t.isHorizontal() && (Math.floor(image.minX) === Math.floor(image.startX) && image.touchesCurrent.x < image.touchesStart.x || Math.floor(image.maxX) === Math.floor(image.startX) && image.touchesCurrent.x > image.touchesStart.x)) return void(image.isTouched = !1);
                                        if (!t.isHorizontal() && (Math.floor(image.minY) === Math.floor(image.startY) && image.touchesCurrent.y < image.touchesStart.y || Math.floor(image.maxY) === Math.floor(image.startY) && image.touchesCurrent.y > image.touchesStart.y)) return void(image.isTouched = !1)
                                    }
                                    e.preventDefault(), e.stopPropagation(), image.isMoved = !0, image.currentX = image.touchesCurrent.x - image.touchesStart.x + image.startX, image.currentY = image.touchesCurrent.y - image.touchesStart.y + image.startY, image.currentX < image.minX && (image.currentX = image.minX + 1 - Math.pow(image.minX - image.currentX + 1, .8)), image.currentX > image.maxX && (image.currentX = image.maxX - 1 + Math.pow(image.currentX - image.maxX + 1, .8)), image.currentY < image.minY && (image.currentY = image.minY + 1 - Math.pow(image.minY - image.currentY + 1, .8)), image.currentY > image.maxY && (image.currentY = image.maxY - 1 + Math.pow(image.currentY - image.maxY + 1, .8)), o.prevPositionX || (o.prevPositionX = image.touchesCurrent.x), o.prevPositionY || (o.prevPositionY = image.touchesCurrent.y), o.prevTime || (o.prevTime = Date.now()), o.x = (image.touchesCurrent.x - o.prevPositionX) / (Date.now() - o.prevTime) / 2, o.y = (image.touchesCurrent.y - o.prevPositionY) / (Date.now() - o.prevTime) / 2, Math.abs(image.touchesCurrent.x - o.prevPositionX) < 2 && (o.x = 0), Math.abs(image.touchesCurrent.y - o.prevPositionY) < 2 && (o.y = 0), o.prevPositionX = image.touchesCurrent.x, o.prevPositionY = image.touchesCurrent.y, o.prevTime = Date.now(), n.$imageWrapEl.transform("translate3d(" + image.currentX + "px, " + image.currentY + "px,0)")
                                }
                            }
                        },
                        onTouchEnd: function() {
                            var e = this.zoom,
                                t = e.gesture,
                                image = e.image,
                                r = e.velocity;
                            if (t.$imageEl && 0 !== t.$imageEl.length) {
                                if (!image.isTouched || !image.isMoved) return image.isTouched = !1, void(image.isMoved = !1);
                                image.isTouched = !1, image.isMoved = !1;
                                var n = 300,
                                    o = 300,
                                    l = r.x * n,
                                    d = image.currentX + l,
                                    c = r.y * o,
                                    h = image.currentY + c;
                                0 !== r.x && (n = Math.abs((d - image.currentX) / r.x)), 0 !== r.y && (o = Math.abs((h - image.currentY) / r.y));
                                var v = Math.max(n, o);
                                image.currentX = d, image.currentY = h;
                                var f = image.width * e.scale,
                                    m = image.height * e.scale;
                                image.minX = Math.min(t.slideWidth / 2 - f / 2, 0), image.maxX = -image.minX, image.minY = Math.min(t.slideHeight / 2 - m / 2, 0), image.maxY = -image.minY, image.currentX = Math.max(Math.min(image.currentX, image.maxX), image.minX), image.currentY = Math.max(Math.min(image.currentY, image.maxY), image.minY), t.$imageWrapEl.transition(v).transform("translate3d(" + image.currentX + "px, " + image.currentY + "px,0)")
                            }
                        },
                        onTransitionEnd: function() {
                            var e = this,
                                t = e.zoom,
                                r = t.gesture;
                            r.$slideEl && e.previousIndex !== e.activeIndex && (r.$imageEl.transform("translate3d(0,0,0) scale(1)"), r.$imageWrapEl.transform("translate3d(0,0,0)"), t.scale = 1, t.currentScale = 1, r.$slideEl = void 0, r.$imageEl = void 0, r.$imageWrapEl = void 0)
                        },
                        toggle: function(e) {
                            var t = this.zoom;
                            t.scale && 1 !== t.scale ? t.out() : t.in(e)
                        },
                        in: function(e) {
                            var t, r, o, l, d, c, h, v, f, m, w, y, x, T, E, S, C = this,
                                M = C.zoom,
                                P = C.params.zoom,
                                k = M.gesture,
                                image = M.image;
                            k.$slideEl || (k.$slideEl = C.clickedSlide ? n(C.clickedSlide) : C.slides.eq(C.activeIndex), k.$imageEl = k.$slideEl.find("img, svg, canvas"), k.$imageWrapEl = k.$imageEl.parent("." + P.containerClass)), k.$imageEl && 0 !== k.$imageEl.length && (k.$slideEl.addClass("" + P.zoomedSlideClass), void 0 === image.touchesStart.x && e ? (t = "touchend" === e.type ? e.changedTouches[0].pageX : e.pageX, r = "touchend" === e.type ? e.changedTouches[0].pageY : e.pageY) : (t = image.touchesStart.x, r = image.touchesStart.y), M.scale = k.$imageWrapEl.attr("data-swiper-zoom") || P.maxRatio, M.currentScale = k.$imageWrapEl.attr("data-swiper-zoom") || P.maxRatio, e ? (E = k.$slideEl[0].offsetWidth, S = k.$slideEl[0].offsetHeight, o = k.$slideEl.offset().left + E / 2 - t, l = k.$slideEl.offset().top + S / 2 - r, h = k.$imageEl[0].offsetWidth, v = k.$imageEl[0].offsetHeight, f = h * M.scale, m = v * M.scale, x = -(w = Math.min(E / 2 - f / 2, 0)), T = -(y = Math.min(S / 2 - m / 2, 0)), (d = o * M.scale) < w && (d = w), d > x && (d = x), (c = l * M.scale) < y && (c = y), c > T && (c = T)) : (d = 0, c = 0), k.$imageWrapEl.transition(300).transform("translate3d(" + d + "px, " + c + "px,0)"), k.$imageEl.transition(300).transform("translate3d(0,0,0) scale(" + M.scale + ")"))
                        },
                        out: function() {
                            var e = this,
                                t = e.zoom,
                                r = e.params.zoom,
                                o = t.gesture;
                            o.$slideEl || (o.$slideEl = e.clickedSlide ? n(e.clickedSlide) : e.slides.eq(e.activeIndex), o.$imageEl = o.$slideEl.find("img, svg, canvas"), o.$imageWrapEl = o.$imageEl.parent("." + r.containerClass)), o.$imageEl && 0 !== o.$imageEl.length && (t.scale = 1, t.currentScale = 1, o.$imageWrapEl.transition(300).transform("translate3d(0,0,0)"), o.$imageEl.transition(300).transform("translate3d(0,0,0) scale(1)"), o.$slideEl.removeClass("" + r.zoomedSlideClass), o.$slideEl = void 0)
                        },
                        enable: function() {
                            var e = this,
                                t = e.zoom;
                            if (!t.enabled) {
                                t.enabled = !0;
                                var r = !("touchstart" !== e.touchEvents.start || !K.passiveListener || !e.params.passiveListeners) && {
                                    passive: !0,
                                    capture: !1
                                };
                                K.gestures ? (e.$wrapperEl.on("gesturestart", ".swiper-slide", t.onGestureStart, r), e.$wrapperEl.on("gesturechange", ".swiper-slide", t.onGestureChange, r), e.$wrapperEl.on("gestureend", ".swiper-slide", t.onGestureEnd, r)) : "touchstart" === e.touchEvents.start && (e.$wrapperEl.on(e.touchEvents.start, ".swiper-slide", t.onGestureStart, r), e.$wrapperEl.on(e.touchEvents.move, ".swiper-slide", t.onGestureChange, r), e.$wrapperEl.on(e.touchEvents.end, ".swiper-slide", t.onGestureEnd, r)), e.$wrapperEl.on(e.touchEvents.move, "." + e.params.zoom.containerClass, t.onTouchMove)
                            }
                        },
                        disable: function() {
                            var e = this,
                                t = e.zoom;
                            if (t.enabled) {
                                e.zoom.enabled = !1;
                                var r = !("touchstart" !== e.touchEvents.start || !K.passiveListener || !e.params.passiveListeners) && {
                                    passive: !0,
                                    capture: !1
                                };
                                K.gestures ? (e.$wrapperEl.off("gesturestart", ".swiper-slide", t.onGestureStart, r), e.$wrapperEl.off("gesturechange", ".swiper-slide", t.onGestureChange, r), e.$wrapperEl.off("gestureend", ".swiper-slide", t.onGestureEnd, r)) : "touchstart" === e.touchEvents.start && (e.$wrapperEl.off(e.touchEvents.start, ".swiper-slide", t.onGestureStart, r), e.$wrapperEl.off(e.touchEvents.move, ".swiper-slide", t.onGestureChange, r), e.$wrapperEl.off(e.touchEvents.end, ".swiper-slide", t.onGestureEnd, r)), e.$wrapperEl.off(e.touchEvents.move, "." + e.params.zoom.containerClass, t.onTouchMove)
                            }
                        }
                    },
                    Mt = {
                        loadInSlide: function(e, t) {
                            void 0 === t && (t = !0);
                            var r = this,
                                o = r.params.lazy;
                            if (void 0 !== e && 0 !== r.slides.length) {
                                var l = r.virtual && r.params.virtual.enabled ? r.$wrapperEl.children("." + r.params.slideClass + '[data-swiper-slide-index="' + e + '"]') : r.slides.eq(e),
                                    d = l.find("." + o.elementClass + ":not(." + o.loadedClass + "):not(." + o.loadingClass + ")");
                                !l.hasClass(o.elementClass) || l.hasClass(o.loadedClass) || l.hasClass(o.loadingClass) || (d = d.add(l[0])), 0 !== d.length && d.each((function(e, d) {
                                    var c = n(d);
                                    c.addClass(o.loadingClass);
                                    var h = c.attr("data-background"),
                                        v = c.attr("data-src"),
                                        f = c.attr("data-srcset"),
                                        m = c.attr("data-sizes");
                                    r.loadImage(c[0], v || h, f, m, !1, (function() {
                                        if (null != r && r && (!r || r.params) && !r.destroyed) {
                                            if (h ? (c.css("background-image", 'url("' + h + '")'), c.removeAttr("data-background")) : (f && (c.attr("srcset", f), c.removeAttr("data-srcset")), m && (c.attr("sizes", m), c.removeAttr("data-sizes")), v && (c.attr("src", v), c.removeAttr("data-src"))), c.addClass(o.loadedClass).removeClass(o.loadingClass), l.find("." + o.preloaderClass).remove(), r.params.loop && t) {
                                                var e = l.attr("data-swiper-slide-index");
                                                if (l.hasClass(r.params.slideDuplicateClass)) {
                                                    var n = r.$wrapperEl.children('[data-swiper-slide-index="' + e + '"]:not(.' + r.params.slideDuplicateClass + ")");
                                                    r.lazy.loadInSlide(n.index(), !1)
                                                } else {
                                                    var d = r.$wrapperEl.children("." + r.params.slideDuplicateClass + '[data-swiper-slide-index="' + e + '"]');
                                                    r.lazy.loadInSlide(d.index(), !1)
                                                }
                                            }
                                            r.emit("lazyImageReady", l[0], c[0])
                                        }
                                    })), r.emit("lazyImageLoad", l[0], c[0])
                                }))
                            }
                        },
                        load: function() {
                            var e = this,
                                t = e.$wrapperEl,
                                r = e.params,
                                o = e.slides,
                                l = e.activeIndex,
                                d = e.virtual && r.virtual.enabled,
                                c = r.lazy,
                                h = r.slidesPerView;

                            function v(e) {
                                if (d) {
                                    if (t.children("." + r.slideClass + '[data-swiper-slide-index="' + e + '"]').length) return !0
                                } else if (o[e]) return !0;
                                return !1
                            }

                            function f(e) {
                                return d ? n(e).attr("data-swiper-slide-index") : n(e).index()
                            }
                            if ("auto" === h && (h = 0), e.lazy.initialImageLoaded || (e.lazy.initialImageLoaded = !0), e.params.watchSlidesVisibility) t.children("." + r.slideVisibleClass).each((function(t, r) {
                                var o = d ? n(r).attr("data-swiper-slide-index") : n(r).index();
                                e.lazy.loadInSlide(o)
                            }));
                            else if (h > 1)
                                for (var i = l; i < l + h; i += 1) v(i) && e.lazy.loadInSlide(i);
                            else e.lazy.loadInSlide(l);
                            if (c.loadPrevNext)
                                if (h > 1 || c.loadPrevNextAmount && c.loadPrevNextAmount > 1) {
                                    for (var m = c.loadPrevNextAmount, w = h, y = Math.min(l + w + Math.max(m, w), o.length), x = Math.max(l - Math.max(w, m), 0), T = l + h; T < y; T += 1) v(T) && e.lazy.loadInSlide(T);
                                    for (var E = x; E < l; E += 1) v(E) && e.lazy.loadInSlide(E)
                                } else {
                                    var S = t.children("." + r.slideNextClass);
                                    S.length > 0 && e.lazy.loadInSlide(f(S));
                                    var C = t.children("." + r.slidePrevClass);
                                    C.length > 0 && e.lazy.loadInSlide(f(C))
                                }
                        }
                    },
                    Pt = {
                        LinearSpline: function(e, t) {
                            var r, n, o, l, d, c = function(e, t) {
                                for (n = -1, r = e.length; r - n > 1;) e[o = r + n >> 1] <= t ? n = o : r = o;
                                return r
                            };
                            return this.x = e, this.y = t, this.lastIndex = e.length - 1, this.interpolate = function(e) {
                                return e ? (d = c(this.x, e), l = d - 1, (e - this.x[l]) * (this.y[d] - this.y[l]) / (this.x[d] - this.x[l]) + this.y[l]) : 0
                            }, this
                        },
                        getInterpolateFunction: function(e) {
                            var t = this;
                            t.controller.spline || (t.controller.spline = t.params.loop ? new Pt.LinearSpline(t.slidesGrid, e.slidesGrid) : new Pt.LinearSpline(t.snapGrid, e.snapGrid))
                        },
                        setTranslate: function(e, t) {
                            var r, n, o = this,
                                l = o.controller.control;

                            function d(e) {
                                var t = o.rtlTranslate ? -o.translate : o.translate;
                                "slide" === o.params.controller.by && (o.controller.getInterpolateFunction(e), n = -o.controller.spline.interpolate(-t)), n && "container" !== o.params.controller.by || (r = (e.maxTranslate() - e.minTranslate()) / (o.maxTranslate() - o.minTranslate()), n = (t - o.minTranslate()) * r + e.minTranslate()), o.params.controller.inverse && (n = e.maxTranslate() - n), e.updateProgress(n), e.setTranslate(n, o), e.updateActiveIndex(), e.updateSlidesClasses()
                            }
                            if (Array.isArray(l))
                                for (var i = 0; i < l.length; i += 1) l[i] !== t && l[i] instanceof ot && d(l[i]);
                            else l instanceof ot && t !== l && d(l)
                        },
                        setTransition: function(e, t) {
                            var i, r = this,
                                n = r.controller.control;

                            function o(t) {
                                t.setTransition(e, r), 0 !== e && (t.transitionStart(), t.params.autoHeight && U.nextTick((function() {
                                    t.updateAutoHeight()
                                })), t.$wrapperEl.transitionEnd((function() {
                                    n && (t.params.loop && "slide" === r.params.controller.by && t.loopFix(), t.transitionEnd())
                                })))
                            }
                            if (Array.isArray(n))
                                for (i = 0; i < n.length; i += 1) n[i] !== t && n[i] instanceof ot && o(n[i]);
                            else n instanceof ot && t !== n && o(n)
                        }
                    },
                    kt = {
                        name: "controller",
                        params: {
                            controller: {
                                control: void 0,
                                inverse: !1,
                                by: "slide"
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                controller: {
                                    control: e.params.controller.control,
                                    getInterpolateFunction: Pt.getInterpolateFunction.bind(e),
                                    setTranslate: Pt.setTranslate.bind(e),
                                    setTransition: Pt.setTransition.bind(e)
                                }
                            })
                        },
                        on: {
                            update: function() {
                                var e = this;
                                e.controller.control && e.controller.spline && (e.controller.spline = void 0, delete e.controller.spline)
                            },
                            resize: function() {
                                var e = this;
                                e.controller.control && e.controller.spline && (e.controller.spline = void 0, delete e.controller.spline)
                            },
                            observerUpdate: function() {
                                var e = this;
                                e.controller.control && e.controller.spline && (e.controller.spline = void 0, delete e.controller.spline)
                            },
                            setTranslate: function(e, t) {
                                var r = this;
                                r.controller.control && r.controller.setTranslate(e, t)
                            },
                            setTransition: function(e, t) {
                                var r = this;
                                r.controller.control && r.controller.setTransition(e, t)
                            }
                        }
                    },
                    zt = {
                        makeElFocusable: function(e) {
                            return e.attr("tabIndex", "0"), e
                        },
                        addElRole: function(e, t) {
                            return e.attr("role", t), e
                        },
                        addElLabel: function(e, label) {
                            return e.attr("aria-label", label), e
                        },
                        disableEl: function(e) {
                            return e.attr("aria-disabled", !0), e
                        },
                        enableEl: function(e) {
                            return e.attr("aria-disabled", !1), e
                        },
                        onEnterKey: function(e) {
                            var t = this,
                                r = t.params.a11y;
                            if (13 === e.keyCode) {
                                var o = n(e.target);
                                t.navigation && t.navigation.$nextEl && o.is(t.navigation.$nextEl) && (t.isEnd && !t.params.loop || t.slideNext(), t.isEnd ? t.a11y.notify(r.lastSlideMessage) : t.a11y.notify(r.nextSlideMessage)), t.navigation && t.navigation.$prevEl && o.is(t.navigation.$prevEl) && (t.isBeginning && !t.params.loop || t.slidePrev(), t.isBeginning ? t.a11y.notify(r.firstSlideMessage) : t.a11y.notify(r.prevSlideMessage)), t.pagination && o.is("." + t.params.pagination.bulletClass) && o[0].click()
                            }
                        },
                        notify: function(e) {
                            var t = this.a11y.liveRegion;
                            0 !== t.length && (t.html(""), t.html(e))
                        },
                        updateNavigation: function() {
                            var e = this;
                            if (!e.params.loop) {
                                var t = e.navigation,
                                    r = t.$nextEl,
                                    n = t.$prevEl;
                                n && n.length > 0 && (e.isBeginning ? e.a11y.disableEl(n) : e.a11y.enableEl(n)), r && r.length > 0 && (e.isEnd ? e.a11y.disableEl(r) : e.a11y.enableEl(r))
                            }
                        },
                        updatePagination: function() {
                            var e = this,
                                t = e.params.a11y;
                            e.pagination && e.params.pagination.clickable && e.pagination.bullets && e.pagination.bullets.length && e.pagination.bullets.each((function(r, o) {
                                var l = n(o);
                                e.a11y.makeElFocusable(l), e.a11y.addElRole(l, "button"), e.a11y.addElLabel(l, t.paginationBulletMessage.replace(/{{index}}/, l.index() + 1))
                            }))
                        },
                        init: function() {
                            var e = this;
                            e.$el.append(e.a11y.liveRegion);
                            var t, r, n = e.params.a11y;
                            e.navigation && e.navigation.$nextEl && (t = e.navigation.$nextEl), e.navigation && e.navigation.$prevEl && (r = e.navigation.$prevEl), t && (e.a11y.makeElFocusable(t), e.a11y.addElRole(t, "button"), e.a11y.addElLabel(t, n.nextSlideMessage), t.on("keydown", e.a11y.onEnterKey)), r && (e.a11y.makeElFocusable(r), e.a11y.addElRole(r, "button"), e.a11y.addElLabel(r, n.prevSlideMessage), r.on("keydown", e.a11y.onEnterKey)), e.pagination && e.params.pagination.clickable && e.pagination.bullets && e.pagination.bullets.length && e.pagination.$el.on("keydown", "." + e.params.pagination.bulletClass, e.a11y.onEnterKey)
                        },
                        destroy: function() {
                            var e, t, r = this;
                            r.a11y.liveRegion && r.a11y.liveRegion.length > 0 && r.a11y.liveRegion.remove(), r.navigation && r.navigation.$nextEl && (e = r.navigation.$nextEl), r.navigation && r.navigation.$prevEl && (t = r.navigation.$prevEl), e && e.off("keydown", r.a11y.onEnterKey), t && t.off("keydown", r.a11y.onEnterKey), r.pagination && r.params.pagination.clickable && r.pagination.bullets && r.pagination.bullets.length && r.pagination.$el.off("keydown", "." + r.params.pagination.bulletClass, r.a11y.onEnterKey)
                        }
                    },
                    $t = {
                        init: function() {
                            var e = this;
                            if (e.params.history) {
                                if (!t.history || !t.history.pushState) return e.params.history.enabled = !1, void(e.params.hashNavigation.enabled = !0);
                                var r = e.history;
                                r.initialized = !0, r.paths = $t.getPathValues(), (r.paths.key || r.paths.value) && (r.scrollToSlide(0, r.paths.value, e.params.runCallbacksOnInit), e.params.history.replaceState || t.addEventListener("popstate", e.history.setHistoryPopState))
                            }
                        },
                        destroy: function() {
                            var e = this;
                            e.params.history.replaceState || t.removeEventListener("popstate", e.history.setHistoryPopState)
                        },
                        setHistoryPopState: function() {
                            var e = this;
                            e.history.paths = $t.getPathValues(), e.history.scrollToSlide(e.params.speed, e.history.paths.value, !1)
                        },
                        getPathValues: function() {
                            var e = t.location.pathname.slice(1).split("/").filter((function(e) {
                                    return "" !== e
                                })),
                                r = e.length;
                            return {
                                key: e[r - 2],
                                value: e[r - 1]
                            }
                        },
                        setHistory: function(e, r) {
                            var n = this;
                            if (n.history.initialized && n.params.history.enabled) {
                                var o = n.slides.eq(r),
                                    l = $t.slugify(o.attr("data-history"));
                                t.location.pathname.includes(e) || (l = e + "/" + l);
                                var d = t.history.state;
                                d && d.value === l || (n.params.history.replaceState ? t.history.replaceState({
                                    value: l
                                }, null, l) : t.history.pushState({
                                    value: l
                                }, null, l))
                            }
                        },
                        slugify: function(text) {
                            return text.toString().toLowerCase().replace(/\s+/g, "-").replace(/[^\w-]+/g, "").replace(/--+/g, "-").replace(/^-+/, "").replace(/-+$/, "")
                        },
                        scrollToSlide: function(e, t, r) {
                            var n = this;
                            if (t)
                                for (var i = 0, o = n.slides.length; i < o; i += 1) {
                                    var l = n.slides.eq(i);
                                    if ($t.slugify(l.attr("data-history")) === t && !l.hasClass(n.params.slideDuplicateClass)) {
                                        var d = l.index();
                                        n.slideTo(d, e, r)
                                    }
                                } else n.slideTo(0, e, r)
                        }
                    },
                    Lt = {
                        onHashCange: function() {
                            var t = this,
                                r = e.location.hash.replace("#", "");
                            if (r !== t.slides.eq(t.activeIndex).attr("data-hash")) {
                                var n = t.$wrapperEl.children("." + t.params.slideClass + '[data-hash="' + r + '"]').index();
                                if (void 0 === n) return;
                                t.slideTo(n)
                            }
                        },
                        setHash: function() {
                            var r = this;
                            if (r.hashNavigation.initialized && r.params.hashNavigation.enabled)
                                if (r.params.hashNavigation.replaceState && t.history && t.history.replaceState) t.history.replaceState(null, null, "#" + r.slides.eq(r.activeIndex).attr("data-hash") || !1);
                                else {
                                    var n = r.slides.eq(r.activeIndex),
                                        o = n.attr("data-hash") || n.attr("data-history");
                                    e.location.hash = o || ""
                                }
                        },
                        init: function() {
                            var r = this;
                            if (!(!r.params.hashNavigation.enabled || r.params.history && r.params.history.enabled)) {
                                r.hashNavigation.initialized = !0;
                                var o = e.location.hash.replace("#", "");
                                if (o)
                                    for (var l = 0, i = 0, d = r.slides.length; i < d; i += 1) {
                                        var c = r.slides.eq(i);
                                        if ((c.attr("data-hash") || c.attr("data-history")) === o && !c.hasClass(r.params.slideDuplicateClass)) {
                                            var h = c.index();
                                            r.slideTo(h, l, r.params.runCallbacksOnInit, !0)
                                        }
                                    }
                                r.params.hashNavigation.watchState && n(t).on("hashchange", r.hashNavigation.onHashCange)
                            }
                        },
                        destroy: function() {
                            var e = this;
                            e.params.hashNavigation.watchState && n(t).off("hashchange", e.hashNavigation.onHashCange)
                        }
                    },
                    It = {
                        run: function() {
                            var e = this,
                                t = e.slides.eq(e.activeIndex),
                                r = e.params.autoplay.delay;
                            t.attr("data-swiper-autoplay") && (r = t.attr("data-swiper-autoplay") || e.params.autoplay.delay), e.autoplay.timeout = U.nextTick((function() {
                                e.params.autoplay.reverseDirection ? e.params.loop ? (e.loopFix(), e.slidePrev(e.params.speed, !0, !0), e.emit("autoplay")) : e.isBeginning ? e.params.autoplay.stopOnLastSlide ? e.autoplay.stop() : (e.slideTo(e.slides.length - 1, e.params.speed, !0, !0), e.emit("autoplay")) : (e.slidePrev(e.params.speed, !0, !0), e.emit("autoplay")) : e.params.loop ? (e.loopFix(), e.slideNext(e.params.speed, !0, !0), e.emit("autoplay")) : e.isEnd ? e.params.autoplay.stopOnLastSlide ? e.autoplay.stop() : (e.slideTo(0, e.params.speed, !0, !0), e.emit("autoplay")) : (e.slideNext(e.params.speed, !0, !0), e.emit("autoplay"))
                            }), r)
                        },
                        start: function() {
                            var e = this;
                            return void 0 === e.autoplay.timeout && !e.autoplay.running && (e.autoplay.running = !0, e.emit("autoplayStart"), e.autoplay.run(), !0)
                        },
                        stop: function() {
                            var e = this;
                            return !!e.autoplay.running && void 0 !== e.autoplay.timeout && (e.autoplay.timeout && (clearTimeout(e.autoplay.timeout), e.autoplay.timeout = void 0), e.autoplay.running = !1, e.emit("autoplayStop"), !0)
                        },
                        pause: function(e) {
                            var t = this;
                            t.autoplay.running && (t.autoplay.paused || (t.autoplay.timeout && clearTimeout(t.autoplay.timeout), t.autoplay.paused = !0, 0 !== e && t.params.autoplay.waitForTransition ? (t.$wrapperEl[0].addEventListener("transitionend", t.autoplay.onTransitionEnd), t.$wrapperEl[0].addEventListener("webkitTransitionEnd", t.autoplay.onTransitionEnd)) : (t.autoplay.paused = !1, t.autoplay.run())))
                        }
                    },
                    Ot = {
                        setTranslate: function() {
                            for (var e = this, t = e.slides, i = 0; i < t.length; i += 1) {
                                var r = e.slides.eq(i),
                                    n = -r[0].swiperSlideOffset;
                                e.params.virtualTranslate || (n -= e.translate);
                                var o = 0;
                                e.isHorizontal() || (o = n, n = 0);
                                var l = e.params.fadeEffect.crossFade ? Math.max(1 - Math.abs(r[0].progress), 0) : 1 + Math.min(Math.max(r[0].progress, -1), 0);
                                r.css({
                                    opacity: l
                                }).transform("translate3d(" + n + "px, " + o + "px, 0px)")
                            }
                        },
                        setTransition: function(e) {
                            var t = this,
                                r = t.slides,
                                n = t.$wrapperEl;
                            if (r.transition(e), t.params.virtualTranslate && 0 !== e) {
                                var o = !1;
                                r.transitionEnd((function() {
                                    if (!o && t && !t.destroyed) {
                                        o = !0, t.animating = !1;
                                        for (var e = ["webkitTransitionEnd", "transitionend"], i = 0; i < e.length; i += 1) n.trigger(e[i])
                                    }
                                }))
                            }
                        }
                    },
                    Dt = {
                        setTranslate: function() {
                            var e, t = this,
                                r = t.$el,
                                o = t.$wrapperEl,
                                l = t.slides,
                                d = t.width,
                                c = t.height,
                                h = t.rtlTranslate,
                                v = t.size,
                                f = t.params.cubeEffect,
                                m = t.isHorizontal(),
                                w = t.virtual && t.params.virtual.enabled,
                                y = 0;
                            f.shadow && (m ? (0 === (e = o.find(".swiper-cube-shadow")).length && (e = n('<div class="swiper-cube-shadow"></div>'), o.append(e)), e.css({
                                height: d + "px"
                            })) : 0 === (e = r.find(".swiper-cube-shadow")).length && (e = n('<div class="swiper-cube-shadow"></div>'), r.append(e)));
                            for (var i = 0; i < l.length; i += 1) {
                                var x = l.eq(i),
                                    T = i;
                                w && (T = parseInt(x.attr("data-swiper-slide-index"), 10));
                                var E = 90 * T,
                                    S = Math.floor(E / 360);
                                h && (E = -E, S = Math.floor(-E / 360));
                                var progress = Math.max(Math.min(x[0].progress, 1), -1),
                                    C = 0,
                                    M = 0,
                                    P = 0;
                                T % 4 == 0 ? (C = 4 * -S * v, P = 0) : (T - 1) % 4 == 0 ? (C = 0, P = 4 * -S * v) : (T - 2) % 4 == 0 ? (C = v + 4 * S * v, P = v) : (T - 3) % 4 == 0 && (C = -v, P = 3 * v + 4 * v * S), h && (C = -C), m || (M = C, C = 0);
                                var k = "rotateX(" + (m ? 0 : -E) + "deg) rotateY(" + (m ? E : 0) + "deg) translate3d(" + C + "px, " + M + "px, " + P + "px)";
                                if (progress <= 1 && progress > -1 && (y = 90 * T + 90 * progress, h && (y = 90 * -T - 90 * progress)), x.transform(k), f.slideShadows) {
                                    var z = m ? x.find(".swiper-slide-shadow-left") : x.find(".swiper-slide-shadow-top"),
                                        $ = m ? x.find(".swiper-slide-shadow-right") : x.find(".swiper-slide-shadow-bottom");
                                    0 === z.length && (z = n('<div class="swiper-slide-shadow-' + (m ? "left" : "top") + '"></div>'), x.append(z)), 0 === $.length && ($ = n('<div class="swiper-slide-shadow-' + (m ? "right" : "bottom") + '"></div>'), x.append($)), z.length && (z[0].style.opacity = Math.max(-progress, 0)), $.length && ($[0].style.opacity = Math.max(progress, 0))
                                }
                            }
                            if (o.css({
                                    "-webkit-transform-origin": "50% 50% -" + v / 2 + "px",
                                    "-moz-transform-origin": "50% 50% -" + v / 2 + "px",
                                    "-ms-transform-origin": "50% 50% -" + v / 2 + "px",
                                    "transform-origin": "50% 50% -" + v / 2 + "px"
                                }), f.shadow)
                                if (m) e.transform("translate3d(0px, " + (d / 2 + f.shadowOffset) + "px, " + -d / 2 + "px) rotateX(90deg) rotateZ(0deg) scale(" + f.shadowScale + ")");
                                else {
                                    var L = Math.abs(y) - 90 * Math.floor(Math.abs(y) / 90),
                                        I = 1.5 - (Math.sin(2 * L * Math.PI / 360) / 2 + Math.cos(2 * L * Math.PI / 360) / 2),
                                        O = f.shadowScale,
                                        D = f.shadowScale / I,
                                        A = f.shadowOffset;
                                    e.transform("scale3d(" + O + ", 1, " + D + ") translate3d(0px, " + (c / 2 + A) + "px, " + -c / 2 / D + "px) rotateX(-90deg)")
                                }
                            var N = Je.isSafari || Je.isUiWebView ? -v / 2 : 0;
                            o.transform("translate3d(0px,0," + N + "px) rotateX(" + (t.isHorizontal() ? 0 : y) + "deg) rotateY(" + (t.isHorizontal() ? -y : 0) + "deg)")
                        },
                        setTransition: function(e) {
                            var t = this,
                                r = t.$el;
                            t.slides.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e), t.params.cubeEffect.shadow && !t.isHorizontal() && r.find(".swiper-cube-shadow").transition(e)
                        }
                    },
                    At = {
                        setTranslate: function() {
                            for (var e = this, t = e.slides, r = e.rtlTranslate, i = 0; i < t.length; i += 1) {
                                var o = t.eq(i),
                                    progress = o[0].progress;
                                e.params.flipEffect.limitRotation && (progress = Math.max(Math.min(o[0].progress, 1), -1));
                                var l = -180 * progress,
                                    d = 0,
                                    c = -o[0].swiperSlideOffset,
                                    h = 0;
                                if (e.isHorizontal() ? r && (l = -l) : (h = c, c = 0, d = -l, l = 0), o[0].style.zIndex = -Math.abs(Math.round(progress)) + t.length, e.params.flipEffect.slideShadows) {
                                    var v = e.isHorizontal() ? o.find(".swiper-slide-shadow-left") : o.find(".swiper-slide-shadow-top"),
                                        f = e.isHorizontal() ? o.find(".swiper-slide-shadow-right") : o.find(".swiper-slide-shadow-bottom");
                                    0 === v.length && (v = n('<div class="swiper-slide-shadow-' + (e.isHorizontal() ? "left" : "top") + '"></div>'), o.append(v)), 0 === f.length && (f = n('<div class="swiper-slide-shadow-' + (e.isHorizontal() ? "right" : "bottom") + '"></div>'), o.append(f)), v.length && (v[0].style.opacity = Math.max(-progress, 0)), f.length && (f[0].style.opacity = Math.max(progress, 0))
                                }
                                o.transform("translate3d(" + c + "px, " + h + "px, 0px) rotateX(" + d + "deg) rotateY(" + l + "deg)")
                            }
                        },
                        setTransition: function(e) {
                            var t = this,
                                r = t.slides,
                                n = t.activeIndex,
                                o = t.$wrapperEl;
                            if (r.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e), t.params.virtualTranslate && 0 !== e) {
                                var l = !1;
                                r.eq(n).transitionEnd((function() {
                                    if (!l && t && !t.destroyed) {
                                        l = !0, t.animating = !1;
                                        for (var e = ["webkitTransitionEnd", "transitionend"], i = 0; i < e.length; i += 1) o.trigger(e[i])
                                    }
                                }))
                            }
                        }
                    },
                    Nt = {
                        setTranslate: function() {
                            for (var e = this, t = e.width, r = e.height, o = e.slides, l = e.$wrapperEl, d = e.slidesSizesGrid, c = e.params.coverflowEffect, h = e.isHorizontal(), v = e.translate, f = h ? t / 2 - v : r / 2 - v, m = h ? c.rotate : -c.rotate, w = c.depth, i = 0, y = o.length; i < y; i += 1) {
                                var x = o.eq(i),
                                    T = d[i],
                                    E = (f - x[0].swiperSlideOffset - T / 2) / T * c.modifier,
                                    S = h ? m * E : 0,
                                    C = h ? 0 : m * E,
                                    M = -w * Math.abs(E),
                                    P = h ? 0 : c.stretch * E,
                                    k = h ? c.stretch * E : 0;
                                Math.abs(k) < .001 && (k = 0), Math.abs(P) < .001 && (P = 0), Math.abs(M) < .001 && (M = 0), Math.abs(S) < .001 && (S = 0), Math.abs(C) < .001 && (C = 0);
                                var z = "translate3d(" + k + "px," + P + "px," + M + "px)  rotateX(" + C + "deg) rotateY(" + S + "deg)";
                                if (x.transform(z), x[0].style.zIndex = 1 - Math.abs(Math.round(E)), c.slideShadows) {
                                    var $ = h ? x.find(".swiper-slide-shadow-left") : x.find(".swiper-slide-shadow-top"),
                                        L = h ? x.find(".swiper-slide-shadow-right") : x.find(".swiper-slide-shadow-bottom");
                                    0 === $.length && ($ = n('<div class="swiper-slide-shadow-' + (h ? "left" : "top") + '"></div>'), x.append($)), 0 === L.length && (L = n('<div class="swiper-slide-shadow-' + (h ? "right" : "bottom") + '"></div>'), x.append(L)), $.length && ($[0].style.opacity = E > 0 ? E : 0), L.length && (L[0].style.opacity = -E > 0 ? -E : 0)
                                }
                            }(K.pointerEvents || K.prefixedPointerEvents) && (l[0].style.perspectiveOrigin = f + "px 50%")
                        },
                        setTransition: function(e) {
                            this.slides.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e)
                        }
                    },
                    Ht = {
                        init: function() {
                            var e = this,
                                t = e.params.thumbs,
                                r = e.constructor;
                            t.swiper instanceof r ? (e.thumbs.swiper = t.swiper, U.extend(e.thumbs.swiper.originalParams, {
                                watchSlidesProgress: !0,
                                slideToClickedSlide: !1
                            }), U.extend(e.thumbs.swiper.params, {
                                watchSlidesProgress: !0,
                                slideToClickedSlide: !1
                            })) : U.isObject(t.swiper) && (e.thumbs.swiper = new r(U.extend({}, t.swiper, {
                                watchSlidesVisibility: !0,
                                watchSlidesProgress: !0,
                                slideToClickedSlide: !1
                            })), e.thumbs.swiperCreated = !0), e.thumbs.swiper.$el.addClass(e.params.thumbs.thumbsContainerClass), e.thumbs.swiper.on("tap", e.thumbs.onThumbClick)
                        },
                        onThumbClick: function() {
                            var e = this,
                                t = e.thumbs.swiper;
                            if (t) {
                                var r = t.clickedIndex,
                                    o = t.clickedSlide;
                                if (!(o && n(o).hasClass(e.params.thumbs.slideThumbActiveClass) || null == r)) {
                                    var l;
                                    if (l = t.params.loop ? parseInt(n(t.clickedSlide).attr("data-swiper-slide-index"), 10) : r, e.params.loop) {
                                        var d = e.activeIndex;
                                        e.slides.eq(d).hasClass(e.params.slideDuplicateClass) && (e.loopFix(), e._clientLeft = e.$wrapperEl[0].clientLeft, d = e.activeIndex);
                                        var c = e.slides.eq(d).prevAll('[data-swiper-slide-index="' + l + '"]').eq(0).index(),
                                            h = e.slides.eq(d).nextAll('[data-swiper-slide-index="' + l + '"]').eq(0).index();
                                        l = void 0 === c ? h : void 0 === h ? c : h - d < d - c ? h : c
                                    }
                                    e.slideTo(l)
                                }
                            }
                        },
                        update: function(e) {
                            var t = this,
                                r = t.thumbs.swiper;
                            if (r) {
                                var n = "auto" === r.params.slidesPerView ? r.slidesPerViewDynamic() : r.params.slidesPerView;
                                if (t.realIndex !== r.realIndex) {
                                    var o, l = r.activeIndex;
                                    if (r.params.loop) {
                                        r.slides.eq(l).hasClass(r.params.slideDuplicateClass) && (r.loopFix(), r._clientLeft = r.$wrapperEl[0].clientLeft, l = r.activeIndex);
                                        var d = r.slides.eq(l).prevAll('[data-swiper-slide-index="' + t.realIndex + '"]').eq(0).index(),
                                            c = r.slides.eq(l).nextAll('[data-swiper-slide-index="' + t.realIndex + '"]').eq(0).index();
                                        o = void 0 === d ? c : void 0 === c ? d : c - l == l - d ? l : c - l < l - d ? c : d
                                    } else o = t.realIndex;
                                    r.visibleSlidesIndexes.indexOf(o) < 0 && (r.params.centeredSlides ? o = o > l ? o - Math.floor(n / 2) + 1 : o + Math.floor(n / 2) - 1 : o > l && (o = o - n + 1), r.slideTo(o, e ? 0 : void 0))
                                }
                                var h = 1,
                                    v = t.params.thumbs.slideThumbActiveClass;
                                if (t.params.slidesPerView > 1 && !t.params.centeredSlides && (h = t.params.slidesPerView), r.slides.removeClass(v), r.params.loop)
                                    for (var i = 0; i < h; i += 1) r.$wrapperEl.children('[data-swiper-slide-index="' + (t.realIndex + i) + '"]').addClass(v);
                                else
                                    for (var f = 0; f < h; f += 1) r.slides.eq(t.realIndex + f).addClass(v)
                            }
                        }
                    },
                    Bt = [lt, pt, ct, ut, vt, mt, bt, {
                        name: "mousewheel",
                        params: {
                            mousewheel: {
                                enabled: !1,
                                releaseOnEdges: !1,
                                invert: !1,
                                forceToAxis: !1,
                                sensitivity: 1,
                                eventsTarged: "container"
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                mousewheel: {
                                    enabled: !1,
                                    enable: yt.enable.bind(e),
                                    disable: yt.disable.bind(e),
                                    handle: yt.handle.bind(e),
                                    handleMouseEnter: yt.handleMouseEnter.bind(e),
                                    handleMouseLeave: yt.handleMouseLeave.bind(e),
                                    lastScrollTime: U.now()
                                }
                            })
                        },
                        on: {
                            init: function() {
                                var e = this;
                                e.params.mousewheel.enabled && e.mousewheel.enable()
                            },
                            destroy: function() {
                                var e = this;
                                e.mousewheel.enabled && e.mousewheel.disable()
                            }
                        }
                    }, {
                        name: "navigation",
                        params: {
                            navigation: {
                                nextEl: null,
                                prevEl: null,
                                hideOnClick: !1,
                                disabledClass: "swiper-button-disabled",
                                hiddenClass: "swiper-button-hidden",
                                lockClass: "swiper-button-lock"
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                navigation: {
                                    init: xt.init.bind(e),
                                    update: xt.update.bind(e),
                                    destroy: xt.destroy.bind(e),
                                    onNextClick: xt.onNextClick.bind(e),
                                    onPrevClick: xt.onPrevClick.bind(e)
                                }
                            })
                        },
                        on: {
                            init: function() {
                                var e = this;
                                e.navigation.init(), e.navigation.update()
                            },
                            toEdge: function() {
                                this.navigation.update()
                            },
                            fromEdge: function() {
                                this.navigation.update()
                            },
                            destroy: function() {
                                this.navigation.destroy()
                            },
                            click: function(e) {
                                var t = this,
                                    r = t.navigation,
                                    o = r.$nextEl,
                                    l = r.$prevEl;
                                !t.params.navigation.hideOnClick || n(e.target).is(l) || n(e.target).is(o) || (o && o.toggleClass(t.params.navigation.hiddenClass), l && l.toggleClass(t.params.navigation.hiddenClass))
                            }
                        }
                    }, {
                        name: "pagination",
                        params: {
                            pagination: {
                                el: null,
                                bulletElement: "span",
                                clickable: !1,
                                hideOnClick: !1,
                                renderBullet: null,
                                renderProgressbar: null,
                                renderFraction: null,
                                renderCustom: null,
                                progressbarOpposite: !1,
                                type: "bullets",
                                dynamicBullets: !1,
                                dynamicMainBullets: 1,
                                formatFractionCurrent: function(e) {
                                    return e
                                },
                                formatFractionTotal: function(e) {
                                    return e
                                },
                                bulletClass: "swiper-pagination-bullet",
                                bulletActiveClass: "swiper-pagination-bullet-active",
                                modifierClass: "swiper-pagination-",
                                currentClass: "swiper-pagination-current",
                                totalClass: "swiper-pagination-total",
                                hiddenClass: "swiper-pagination-hidden",
                                progressbarFillClass: "swiper-pagination-progressbar-fill",
                                progressbarOppositeClass: "swiper-pagination-progressbar-opposite",
                                clickableClass: "swiper-pagination-clickable",
                                lockClass: "swiper-pagination-lock"
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                pagination: {
                                    init: Tt.init.bind(e),
                                    render: Tt.render.bind(e),
                                    update: Tt.update.bind(e),
                                    destroy: Tt.destroy.bind(e),
                                    dynamicBulletIndex: 0
                                }
                            })
                        },
                        on: {
                            init: function() {
                                var e = this;
                                e.pagination.init(), e.pagination.render(), e.pagination.update()
                            },
                            activeIndexChange: function() {
                                var e = this;
                                (e.params.loop || void 0 === e.snapIndex) && e.pagination.update()
                            },
                            snapIndexChange: function() {
                                var e = this;
                                e.params.loop || e.pagination.update()
                            },
                            slidesLengthChange: function() {
                                var e = this;
                                e.params.loop && (e.pagination.render(), e.pagination.update())
                            },
                            snapGridLengthChange: function() {
                                var e = this;
                                e.params.loop || (e.pagination.render(), e.pagination.update())
                            },
                            destroy: function() {
                                this.pagination.destroy()
                            },
                            click: function(e) {
                                var t = this;
                                t.params.pagination.el && t.params.pagination.hideOnClick && t.pagination.$el.length > 0 && !n(e.target).hasClass(t.params.pagination.bulletClass) && t.pagination.$el.toggleClass(t.params.pagination.hiddenClass)
                            }
                        }
                    }, {
                        name: "scrollbar",
                        params: {
                            scrollbar: {
                                el: null,
                                dragSize: "auto",
                                hide: !1,
                                draggable: !1,
                                snapOnRelease: !0,
                                lockClass: "swiper-scrollbar-lock",
                                dragClass: "swiper-scrollbar-drag"
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                scrollbar: {
                                    init: Et.init.bind(e),
                                    destroy: Et.destroy.bind(e),
                                    updateSize: Et.updateSize.bind(e),
                                    setTranslate: Et.setTranslate.bind(e),
                                    setTransition: Et.setTransition.bind(e),
                                    enableDraggable: Et.enableDraggable.bind(e),
                                    disableDraggable: Et.disableDraggable.bind(e),
                                    setDragPosition: Et.setDragPosition.bind(e),
                                    onDragStart: Et.onDragStart.bind(e),
                                    onDragMove: Et.onDragMove.bind(e),
                                    onDragEnd: Et.onDragEnd.bind(e),
                                    isTouched: !1,
                                    timeout: null,
                                    dragTimeout: null
                                }
                            })
                        },
                        on: {
                            init: function() {
                                var e = this;
                                e.scrollbar.init(), e.scrollbar.updateSize(), e.scrollbar.setTranslate()
                            },
                            update: function() {
                                this.scrollbar.updateSize()
                            },
                            resize: function() {
                                this.scrollbar.updateSize()
                            },
                            observerUpdate: function() {
                                this.scrollbar.updateSize()
                            },
                            setTranslate: function() {
                                this.scrollbar.setTranslate()
                            },
                            setTransition: function(e) {
                                this.scrollbar.setTransition(e)
                            },
                            destroy: function() {
                                this.scrollbar.destroy()
                            }
                        }
                    }, {
                        name: "parallax",
                        params: {
                            parallax: {
                                enabled: !1
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                parallax: {
                                    setTransform: St.setTransform.bind(e),
                                    setTranslate: St.setTranslate.bind(e),
                                    setTransition: St.setTransition.bind(e)
                                }
                            })
                        },
                        on: {
                            beforeInit: function() {
                                var e = this;
                                e.params.parallax.enabled && (e.params.watchSlidesProgress = !0, e.originalParams.watchSlidesProgress = !0)
                            },
                            init: function() {
                                var e = this;
                                e.params.parallax && e.parallax.setTranslate()
                            },
                            setTranslate: function() {
                                var e = this;
                                e.params.parallax && e.parallax.setTranslate()
                            },
                            setTransition: function(e) {
                                var t = this;
                                t.params.parallax && t.parallax.setTransition(e)
                            }
                        }
                    }, {
                        name: "zoom",
                        params: {
                            zoom: {
                                enabled: !1,
                                maxRatio: 3,
                                minRatio: 1,
                                toggle: !0,
                                containerClass: "swiper-zoom-container",
                                zoomedSlideClass: "swiper-slide-zoomed"
                            }
                        },
                        create: function() {
                            var e = this,
                                t = {
                                    enabled: !1,
                                    scale: 1,
                                    currentScale: 1,
                                    isScaling: !1,
                                    gesture: {
                                        $slideEl: void 0,
                                        slideWidth: void 0,
                                        slideHeight: void 0,
                                        $imageEl: void 0,
                                        $imageWrapEl: void 0,
                                        maxRatio: 3
                                    },
                                    image: {
                                        isTouched: void 0,
                                        isMoved: void 0,
                                        currentX: void 0,
                                        currentY: void 0,
                                        minX: void 0,
                                        minY: void 0,
                                        maxX: void 0,
                                        maxY: void 0,
                                        width: void 0,
                                        height: void 0,
                                        startX: void 0,
                                        startY: void 0,
                                        touchesStart: {},
                                        touchesCurrent: {}
                                    },
                                    velocity: {
                                        x: void 0,
                                        y: void 0,
                                        prevPositionX: void 0,
                                        prevPositionY: void 0,
                                        prevTime: void 0
                                    }
                                };
                            "onGestureStart onGestureChange onGestureEnd onTouchStart onTouchMove onTouchEnd onTransitionEnd toggle enable disable in out".split(" ").forEach((function(r) {
                                t[r] = Ct[r].bind(e)
                            })), U.extend(e, {
                                zoom: t
                            });
                            var r = 1;
                            Object.defineProperty(e.zoom, "scale", {
                                get: function() {
                                    return r
                                },
                                set: function(t) {
                                    if (r !== t) {
                                        var n = e.zoom.gesture.$imageEl ? e.zoom.gesture.$imageEl[0] : void 0,
                                            o = e.zoom.gesture.$slideEl ? e.zoom.gesture.$slideEl[0] : void 0;
                                        e.emit("zoomChange", t, n, o)
                                    }
                                    r = t
                                }
                            })
                        },
                        on: {
                            init: function() {
                                var e = this;
                                e.params.zoom.enabled && e.zoom.enable()
                            },
                            destroy: function() {
                                this.zoom.disable()
                            },
                            touchStart: function(e) {
                                var t = this;
                                t.zoom.enabled && t.zoom.onTouchStart(e)
                            },
                            touchEnd: function(e) {
                                var t = this;
                                t.zoom.enabled && t.zoom.onTouchEnd(e)
                            },
                            doubleTap: function(e) {
                                var t = this;
                                t.params.zoom.enabled && t.zoom.enabled && t.params.zoom.toggle && t.zoom.toggle(e)
                            },
                            transitionEnd: function() {
                                var e = this;
                                e.zoom.enabled && e.params.zoom.enabled && e.zoom.onTransitionEnd()
                            }
                        }
                    }, {
                        name: "lazy",
                        params: {
                            lazy: {
                                enabled: !1,
                                loadPrevNext: !1,
                                loadPrevNextAmount: 1,
                                loadOnTransitionStart: !1,
                                elementClass: "swiper-lazy",
                                loadingClass: "swiper-lazy-loading",
                                loadedClass: "swiper-lazy-loaded",
                                preloaderClass: "swiper-lazy-preloader"
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                lazy: {
                                    initialImageLoaded: !1,
                                    load: Mt.load.bind(e),
                                    loadInSlide: Mt.loadInSlide.bind(e)
                                }
                            })
                        },
                        on: {
                            beforeInit: function() {
                                var e = this;
                                e.params.lazy.enabled && e.params.preloadImages && (e.params.preloadImages = !1)
                            },
                            init: function() {
                                var e = this;
                                e.params.lazy.enabled && !e.params.loop && 0 === e.params.initialSlide && e.lazy.load()
                            },
                            scroll: function() {
                                var e = this;
                                e.params.freeMode && !e.params.freeModeSticky && e.lazy.load()
                            },
                            resize: function() {
                                var e = this;
                                e.params.lazy.enabled && e.lazy.load()
                            },
                            scrollbarDragMove: function() {
                                var e = this;
                                e.params.lazy.enabled && e.lazy.load()
                            },
                            transitionStart: function() {
                                var e = this;
                                e.params.lazy.enabled && (e.params.lazy.loadOnTransitionStart || !e.params.lazy.loadOnTransitionStart && !e.lazy.initialImageLoaded) && e.lazy.load()
                            },
                            transitionEnd: function() {
                                var e = this;
                                e.params.lazy.enabled && !e.params.lazy.loadOnTransitionStart && e.lazy.load()
                            }
                        }
                    }, kt, {
                        name: "a11y",
                        params: {
                            a11y: {
                                enabled: !0,
                                notificationClass: "swiper-notification",
                                prevSlideMessage: "Previous slide",
                                nextSlideMessage: "Next slide",
                                firstSlideMessage: "This is the first slide",
                                lastSlideMessage: "This is the last slide",
                                paginationBulletMessage: "Go to slide {{index}}"
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                a11y: {
                                    liveRegion: n('<span class="' + e.params.a11y.notificationClass + '" aria-live="assertive" aria-atomic="true"></span>')
                                }
                            }), Object.keys(zt).forEach((function(t) {
                                e.a11y[t] = zt[t].bind(e)
                            }))
                        },
                        on: {
                            init: function() {
                                var e = this;
                                e.params.a11y.enabled && (e.a11y.init(), e.a11y.updateNavigation())
                            },
                            toEdge: function() {
                                var e = this;
                                e.params.a11y.enabled && e.a11y.updateNavigation()
                            },
                            fromEdge: function() {
                                var e = this;
                                e.params.a11y.enabled && e.a11y.updateNavigation()
                            },
                            paginationUpdate: function() {
                                var e = this;
                                e.params.a11y.enabled && e.a11y.updatePagination()
                            },
                            destroy: function() {
                                var e = this;
                                e.params.a11y.enabled && e.a11y.destroy()
                            }
                        }
                    }, {
                        name: "history",
                        params: {
                            history: {
                                enabled: !1,
                                replaceState: !1,
                                key: "slides"
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                history: {
                                    init: $t.init.bind(e),
                                    setHistory: $t.setHistory.bind(e),
                                    setHistoryPopState: $t.setHistoryPopState.bind(e),
                                    scrollToSlide: $t.scrollToSlide.bind(e),
                                    destroy: $t.destroy.bind(e)
                                }
                            })
                        },
                        on: {
                            init: function() {
                                var e = this;
                                e.params.history.enabled && e.history.init()
                            },
                            destroy: function() {
                                var e = this;
                                e.params.history.enabled && e.history.destroy()
                            },
                            transitionEnd: function() {
                                var e = this;
                                e.history.initialized && e.history.setHistory(e.params.history.key, e.activeIndex)
                            }
                        }
                    }, {
                        name: "hash-navigation",
                        params: {
                            hashNavigation: {
                                enabled: !1,
                                replaceState: !1,
                                watchState: !1
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                hashNavigation: {
                                    initialized: !1,
                                    init: Lt.init.bind(e),
                                    destroy: Lt.destroy.bind(e),
                                    setHash: Lt.setHash.bind(e),
                                    onHashCange: Lt.onHashCange.bind(e)
                                }
                            })
                        },
                        on: {
                            init: function() {
                                var e = this;
                                e.params.hashNavigation.enabled && e.hashNavigation.init()
                            },
                            destroy: function() {
                                var e = this;
                                e.params.hashNavigation.enabled && e.hashNavigation.destroy()
                            },
                            transitionEnd: function() {
                                var e = this;
                                e.hashNavigation.initialized && e.hashNavigation.setHash()
                            }
                        }
                    }, {
                        name: "autoplay",
                        params: {
                            autoplay: {
                                enabled: !1,
                                delay: 3e3,
                                waitForTransition: !0,
                                disableOnInteraction: !0,
                                stopOnLastSlide: !1,
                                reverseDirection: !1
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                autoplay: {
                                    running: !1,
                                    paused: !1,
                                    run: It.run.bind(e),
                                    start: It.start.bind(e),
                                    stop: It.stop.bind(e),
                                    pause: It.pause.bind(e),
                                    onTransitionEnd: function(t) {
                                        e && !e.destroyed && e.$wrapperEl && t.target === this && (e.$wrapperEl[0].removeEventListener("transitionend", e.autoplay.onTransitionEnd), e.$wrapperEl[0].removeEventListener("webkitTransitionEnd", e.autoplay.onTransitionEnd), e.autoplay.paused = !1, e.autoplay.running ? e.autoplay.run() : e.autoplay.stop())
                                    }
                                }
                            })
                        },
                        on: {
                            init: function() {
                                var e = this;
                                e.params.autoplay.enabled && e.autoplay.start()
                            },
                            beforeTransitionStart: function(e, t) {
                                var r = this;
                                r.autoplay.running && (t || !r.params.autoplay.disableOnInteraction ? r.autoplay.pause(e) : r.autoplay.stop())
                            },
                            sliderFirstMove: function() {
                                var e = this;
                                e.autoplay.running && (e.params.autoplay.disableOnInteraction ? e.autoplay.stop() : e.autoplay.pause())
                            },
                            destroy: function() {
                                var e = this;
                                e.autoplay.running && e.autoplay.stop()
                            }
                        }
                    }, {
                        name: "effect-fade",
                        params: {
                            fadeEffect: {
                                crossFade: !1
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                fadeEffect: {
                                    setTranslate: Ot.setTranslate.bind(e),
                                    setTransition: Ot.setTransition.bind(e)
                                }
                            })
                        },
                        on: {
                            beforeInit: function() {
                                var e = this;
                                if ("fade" === e.params.effect) {
                                    e.classNames.push(e.params.containerModifierClass + "fade");
                                    var t = {
                                        slidesPerView: 1,
                                        slidesPerColumn: 1,
                                        slidesPerGroup: 1,
                                        watchSlidesProgress: !0,
                                        spaceBetween: 0,
                                        virtualTranslate: !0
                                    };
                                    U.extend(e.params, t), U.extend(e.originalParams, t)
                                }
                            },
                            setTranslate: function() {
                                var e = this;
                                "fade" === e.params.effect && e.fadeEffect.setTranslate()
                            },
                            setTransition: function(e) {
                                var t = this;
                                "fade" === t.params.effect && t.fadeEffect.setTransition(e)
                            }
                        }
                    }, {
                        name: "effect-cube",
                        params: {
                            cubeEffect: {
                                slideShadows: !0,
                                shadow: !0,
                                shadowOffset: 20,
                                shadowScale: .94
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                cubeEffect: {
                                    setTranslate: Dt.setTranslate.bind(e),
                                    setTransition: Dt.setTransition.bind(e)
                                }
                            })
                        },
                        on: {
                            beforeInit: function() {
                                var e = this;
                                if ("cube" === e.params.effect) {
                                    e.classNames.push(e.params.containerModifierClass + "cube"), e.classNames.push(e.params.containerModifierClass + "3d");
                                    var t = {
                                        slidesPerView: 1,
                                        slidesPerColumn: 1,
                                        slidesPerGroup: 1,
                                        watchSlidesProgress: !0,
                                        resistanceRatio: 0,
                                        spaceBetween: 0,
                                        centeredSlides: !1,
                                        virtualTranslate: !0
                                    };
                                    U.extend(e.params, t), U.extend(e.originalParams, t)
                                }
                            },
                            setTranslate: function() {
                                var e = this;
                                "cube" === e.params.effect && e.cubeEffect.setTranslate()
                            },
                            setTransition: function(e) {
                                var t = this;
                                "cube" === t.params.effect && t.cubeEffect.setTransition(e)
                            }
                        }
                    }, {
                        name: "effect-flip",
                        params: {
                            flipEffect: {
                                slideShadows: !0,
                                limitRotation: !0
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                flipEffect: {
                                    setTranslate: At.setTranslate.bind(e),
                                    setTransition: At.setTransition.bind(e)
                                }
                            })
                        },
                        on: {
                            beforeInit: function() {
                                var e = this;
                                if ("flip" === e.params.effect) {
                                    e.classNames.push(e.params.containerModifierClass + "flip"), e.classNames.push(e.params.containerModifierClass + "3d");
                                    var t = {
                                        slidesPerView: 1,
                                        slidesPerColumn: 1,
                                        slidesPerGroup: 1,
                                        watchSlidesProgress: !0,
                                        spaceBetween: 0,
                                        virtualTranslate: !0
                                    };
                                    U.extend(e.params, t), U.extend(e.originalParams, t)
                                }
                            },
                            setTranslate: function() {
                                var e = this;
                                "flip" === e.params.effect && e.flipEffect.setTranslate()
                            },
                            setTransition: function(e) {
                                var t = this;
                                "flip" === t.params.effect && t.flipEffect.setTransition(e)
                            }
                        }
                    }, {
                        name: "effect-coverflow",
                        params: {
                            coverflowEffect: {
                                rotate: 50,
                                stretch: 0,
                                depth: 100,
                                modifier: 1,
                                slideShadows: !0
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                coverflowEffect: {
                                    setTranslate: Nt.setTranslate.bind(e),
                                    setTransition: Nt.setTransition.bind(e)
                                }
                            })
                        },
                        on: {
                            beforeInit: function() {
                                var e = this;
                                "coverflow" === e.params.effect && (e.classNames.push(e.params.containerModifierClass + "coverflow"), e.classNames.push(e.params.containerModifierClass + "3d"), e.params.watchSlidesProgress = !0, e.originalParams.watchSlidesProgress = !0)
                            },
                            setTranslate: function() {
                                var e = this;
                                "coverflow" === e.params.effect && e.coverflowEffect.setTranslate()
                            },
                            setTransition: function(e) {
                                var t = this;
                                "coverflow" === t.params.effect && t.coverflowEffect.setTransition(e)
                            }
                        }
                    }, {
                        name: "thumbs",
                        params: {
                            thumbs: {
                                swiper: null,
                                slideThumbActiveClass: "swiper-slide-thumb-active",
                                thumbsContainerClass: "swiper-container-thumbs"
                            }
                        },
                        create: function() {
                            var e = this;
                            U.extend(e, {
                                thumbs: {
                                    swiper: null,
                                    init: Ht.init.bind(e),
                                    update: Ht.update.bind(e),
                                    onThumbClick: Ht.onThumbClick.bind(e)
                                }
                            })
                        },
                        on: {
                            beforeInit: function() {
                                var e = this,
                                    t = e.params.thumbs;
                                t && t.swiper && (e.thumbs.init(), e.thumbs.update(!0))
                            },
                            slideChange: function() {
                                var e = this;
                                e.thumbs.swiper && e.thumbs.update()
                            },
                            update: function() {
                                var e = this;
                                e.thumbs.swiper && e.thumbs.update()
                            },
                            resize: function() {
                                var e = this;
                                e.thumbs.swiper && e.thumbs.update()
                            },
                            observerUpdate: function() {
                                var e = this;
                                e.thumbs.swiper && e.thumbs.update()
                            },
                            setTransition: function(e) {
                                var t = this.thumbs.swiper;
                                t && t.setTransition(e)
                            },
                            beforeDestroy: function() {
                                var e = this,
                                    t = e.thumbs.swiper;
                                t && e.thumbs.swiperCreated && t && t.destroy()
                            }
                        }
                    }];
                return void 0 === ot.use && (ot.use = ot.Class.use, ot.installModule = ot.Class.installModule), ot.use(Bt), ot
            }()
        },
        50: function(e, t, r) {},
        68: function(e, t, r) {
            "use strict";
            var n = Object.getOwnPropertySymbols,
                o = Object.prototype.hasOwnProperty,
                l = Object.prototype.propertyIsEnumerable;

            function d(e) {
                if (null == e) throw new TypeError("Object.assign cannot be called with null or undefined");
                return Object(e)
            }
            e.exports = function() {
                try {
                    if (!Object.assign) return !1;
                    var e = new String("abc");
                    if (e[5] = "de", "5" === Object.getOwnPropertyNames(e)[0]) return !1;
                    for (var t = {}, i = 0; i < 10; i++) t["_" + String.fromCharCode(i)] = i;
                    if ("0123456789" !== Object.getOwnPropertyNames(t).map((function(e) {
                            return t[e]
                        })).join("")) return !1;
                    var r = {};
                    return "abcdefghijklmnopqrst".split("").forEach((function(e) {
                        r[e] = e
                    })), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, r)).join("")
                } catch (e) {
                    return !1
                }
            }() ? Object.assign : function(e, source) {
                for (var t, r, c = d(e), s = 1; s < arguments.length; s++) {
                    for (var h in t = Object(arguments[s])) o.call(t, h) && (c[h] = t[h]);
                    if (n) {
                        r = n(t);
                        for (var i = 0; i < r.length; i++) l.call(t, r[i]) && (c[r[i]] = t[r[i]])
                    }
                }
                return c
            }
        }
    }
]);