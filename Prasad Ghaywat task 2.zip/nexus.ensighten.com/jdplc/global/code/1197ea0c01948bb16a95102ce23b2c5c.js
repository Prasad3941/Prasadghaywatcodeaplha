Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    if (window.dataObject && window.dataObject.items) {
        JDObject.helpers.productList.getProducts = function() {
            var items = document.getElementById("list").children;
            var products = [];
            for (var i = 0; i < items.length; i++)
                if (items[i].tagName.toUpperCase() == "LI") products.push(items[i]);
            return products
        };
        JDObject.helpers.productList.getProductLinks = function(prod) {
            return prod.getElementsByTagName("A")
        };
        JDObject.helpers.productList.getProductPlu = function(a) {
            var match = a.href.match(/[0-9]{6,}/g);
            return match ? match[0] : false
        };
        JDObject.helpers.productList.getIgnoreClickButtons = function() {
            var a = document.getElementsByClassName("quickView");
            var b = document.getElementsByClassName("quickSave");
            return [a, b]
        };
        window.JDObject.helpers.productList.productClickTagging()
    }
}, 1093744, [3608461], 295180, [294965]);