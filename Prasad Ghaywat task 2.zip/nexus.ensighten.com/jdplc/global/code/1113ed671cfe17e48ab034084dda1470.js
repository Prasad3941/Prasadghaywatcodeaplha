Bootstrapper.bindDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;

    function internationalPopup() {
        var $ = window.jQuery;
        try {
            function getCookie(c_name) {
                if (document.cookie.length > 0) {
                    c_start = document.cookie.indexOf(c_name + "\x3d");
                    if (c_start != -1) {
                        c_start = c_start + c_name.length + 1;
                        c_end = document.cookie.indexOf(";", c_start);
                        if (c_end == -1) c_end = document.cookie.length;
                        return unescape(document.cookie.substring(c_start, c_end))
                    }
                }
                return ""
            }

            function setCookie(c_name,
                value, expiredays) {
                var exdate = new Date;
                exdate.setDate(exdate.getDate() + expiredays);
                document.cookie = c_name + "\x3d" + escape(value) + (expiredays == null ? "" : ";expires\x3d" + exdate.toUTCString() + "; path\x3d/")
            }
            var countryUser = "";
            var countryCurr = "GB";
            var imageFolder = "//jdsports-client-resources.co.uk/jdsports-client-resources/intpopup/";
            try {
                cookieValue = getCookie("userCountry").trim()
            } catch (e) {
                cookieValue = ""
            }
            console.log("cookieValue");
            console.log(cookieValue);
            if (typeof cookieValue == "undefined" || cookieValue == null ||
                cookieValue == "") popSeen = false;
            else {
                popSeen = true;
                countryUser = getCookie("userCountry")
            }
            var test = window.location.search.indexOf("intPopupTest\x3d") > -1 ? true : false;
            if (popSeen && !test) return;
            Bootstrapper.loadScriptCallback("//js.maxmind.com/js/apis/geoip2/v2.0/geoip2.js", function() {
                var onSuccess = function(location) {
                    countryUser = location.country.iso_code;
                    console.log("ISO_CODE: " + countryUser);
                    if (test) countryUser = window.location.search.match(/intPopupTest=[A-Za-z]{2}/g)[0].split("\x3d")[1].toUpperCase();
                    console.log("geoloc" +
                        location.country.iso_code + "user country" + countryUser + " curr country" + countryCurr);
                    var isCountryDiff = countryUser != countryCurr || test === true;
                    var imgUrl = {
                        DE: "https://size-client-resources.s3.amazonaws.com/assets/lightbox/2017/int-popup/Lightbox.jpg",
                        ES: "https://size-client-resources.s3.amazonaws.com/img/2017/0914/lightbox-spain-d731f9b89995b802465bb3e5f6e2ccfd.jpg",
                        FR: "https://size-client-resources.s3.amazonaws.com/img/2017/0906/lightbox-french-c95cf5ffb1116140c631c25a3104b6b9.jpg",
                        IE: "https://size-client-resources.s3.amazonaws.com/img/2017/0911/lightbox-ireland-3c2fc76092ada53112ad7a8fc2ca38fe.jpg",
                        IT: "https://size-client-resources.s3.amazonaws.com/img/2017/0914/lightbox-italy-5458a3d076f1f3aff11e219c6398a9f3.jpg"
                    }[countryUser];
                    var url = "//www.sizeofficial." + countryUser.toLowerCase();
                    if (isCountryDiff && imgUrl) {
                        var width = 800;
                        var height = 500;
                        if ($("#intPopup").length > 0) $("#intPopup").fadeIn(300);
                        else {
                            console.log("display lightbox");
                            var lightbox = '\x3cdiv id\x3d"intPopup" style\x3d"position: fixed;top: 0;left: 0;width: 100%;height: 100%;//background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAA9JREFUeNpiYGBg2AwQYAAAuAC01qHx9QAAAABJRU5ErkJggg\x3d\x3d) repeat;background: rgba(0, 0, 0, .8);z-index:999998;"\x3e' +
                                '\x3cdiv id\x3d"intPopupContent" style\x3d"position: relative;z-index: 100;text-align:center;width: ' + width + "px;height:" + height + 'px;margin:30px auto; background-color:#FFF;//box-shadow: 0 0 20px rgba(0,0,0,0.4);font:12px normal Helvetica, Arial, Verdana, sans-serif;box-shadow: 0 3px 7px rgba(0, 0, 0, 0.5);z-index:999999;" \x3e' + '\x3ca href\x3d"' + url + '"\x3e' + '\x3cimg src\x3d"' + imgUrl + '"/\x3e' + "\x3c/a\x3e" + "\x3c/div\x3e" + "\x3c/div\x3e";
                            console.log(lightbox);
                            $("body").prepend(lightbox);
                            $("#intPopupContent").click(function() {
                                ga("send",
                                    "event", "click", "international-popup", countryUser, {
                                        transport: "beacon"
                                    })
                            })
                        }
                        $("#intPopup").click(function() {
                            $("#intPopup").fadeOut("fast")
                        });
                        $("#intPopupClose").click(function() {
                            $("#intPopup").fadeOut("fast")
                        })
                    }
                    setCookie("popupSeen", "1", 365);
                    setCookie("userCountry", countryUser, 365)
                };
                var onError = function(error) {
                    console.log("Error:\n\n" + JSON.stringify(error, undefined, 4))
                };
                geoip2.country(onSuccess, onError)
            })
        } catch (e) {
            console.log(e)
        }
    }

    function checkJquery() {
        if (window.jQuery) internationalPopup();
        else window.setTimeout(checkJquery,
            100)
    }
    checkJquery()
}, 2849757, 479446);