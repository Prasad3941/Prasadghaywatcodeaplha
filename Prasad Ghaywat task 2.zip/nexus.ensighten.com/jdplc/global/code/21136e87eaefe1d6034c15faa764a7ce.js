Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var items = document.querySelectorAll(".quickBuy, .quickView, .itemQuickView");
    var fn = function(e) {
        var plu = false;
        var path = false;
        var unitPrice = false;
        var attr = e.target.getAttribute("data-quickview-path");
        var pte = e.target.parentElement.parentElement;
        var salepri = pte.querySelector(".itemPrice .now span[data-oi-price]");
        var nonslaepri = ".itemPrice .pri[data-oi-price]";
        var selEl =
            salepri || pte.querySelector(nonslaepri);
        if (selEl) unitPrice = parseFloat(selEl.innerText.replace(/[^0-9.]/g, ""));
        if (!attr) attr = e.target.href && e.target.href.pathname;
        if (attr) {
            path = attr;
            plu = attr.match(/(?:product\/[^\/]*\/)([a-zA-Z0-9]{6,})/)[1]
        }
        if (!plu) plu = e.target.getAttribute("data-plu");
        var obj = Bootstrapper.dataManager.getData();
        var item = false;
        for (var i = 0; i < obj.items.length; i++)
            if (JDObject.get.cleanPlu(obj.items[i].plu) == JDObject.get.cleanPlu(plu)) {
                item = obj.items[i];
                break
            }
        var data = {
            target: e.target,
            plu: plu || ""
        };
        JDObject.assert("JDO.H.temp.quickView");
        JDObject.helpers.temp.quickView.plu = plu;
        if (item) {
            data.item = item;
            JDObject.helpers.temp.quickView.item = item
        }
        if (obj.category) data.category = obj.category;
        if (unitPrice) data.unitPrice = unitPrice;
        JDObject.eventSubmit("quickViewClick", data)
    };
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        item.addEventListener("click", fn)
    }
}, 2995086, [3996520], 450422, [418795]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var id = {
        AR: 5825,
        BA: 26995,
        BL: 1520,
        CL: 5882,
        CH: 7691,
        CR: 30421,
        FP: 5824,
        FR: 24150,
        FS: 7541,
        GO: 3549,
        HS: 6700,
        JD: 1431,
        ML: 1521,
        MS: 5803,
        OI: 24152,
        PY: 12478,
        SC: 2769,
        SZ: 2767,
        TE: 4244,
        UO: 5970,
        WG: 24151,
        FPFR: 17017,
        FPIT: 18937,
        FPNL: 18938,
        FPDE: 18926,
        FPDK: 18939,
        FPIE: 18945,
        FPFI: 18942,
        FPSE: 18941,
        JDAT: 18277,
        JDBE: 8319,
        JDDE: 10073,
        JDDK: 8844,
        JDES: 10121,
        JDFR: 7322,
        JDFI: 12462,
        JDIE: 5945,
        JDIT: 9690,
        JDNL: 8193,
        JDSE: 8841,
        JDPT: 18936,
        JDGL: 22169,
        JDPL: 32201,
        SZFR: 7723,
        SZFI: 18940,
        SZNL: 11256,
        SZDK: 11257,
        SZDE: 10597,
        SZES: 11258,
        SZIE: 12184,
        SZIT: 11259,
        SZSE: 12293,
        SZBE: 18933,
        SD: 12693
    }[window.JDObject.fasciaCode];
    if (id && !/^checkout/g.test(window.location.hostname)) {
        Bootstrapper.insertScript("//www.dwin1.com/" + id + ".js");
        var cks = "";
        var match = window.location.search.match(/[\?&](?:cks|awc)=([^&]+)/i);
        if (match && match.length && match.length > 1) cks = match[1];
        if (cks) {
            window.localStorage.setItem("AWIN_CKS", cks);
            var domain =
                window.location.hostname.replace(/(www|m|desktop|mobile|t|tablet|a|checkout)\./g, "");
            JDObject.cookie.set("JDO_AWIN_CKS", cks, 30, domain)
        }
    }
}, 3787029, [4029119, 3455314], 341729, [274206, 542880]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var getSizeData = function(item) {
        var sku = item.getAttribute("data-sku").split(".");
        var plu = sku[0];
        sku = sku[1];
        var price = item.getAttribute("data-price");
        var hasStock = parseInt(item.getAttribute("data-stock").replace(/[^\d]/g, "")) > 0;
        var name = item.innerText.trim();
        return {
            plu: plu,
            sku: sku,
            price: price,
            unitPrice: unitPrice,
            hasStock: hasStock,
            name: name,
            sizeName: name
        }
    };
    JDObject.helpers.JDObject.events.quickViewClick =
        function(data) {
            try {
                waiter(data)
            } catch (e) {}
            var j = 0;
            var fn = function() {
                j++;
                var atb = document.querySelector(".quickViewButtons .add-to-basket");
                var btns = document.querySelectorAll(".quickDetails #productSizeStock button");
                if (!btns || !atb) {
                    if (j > 40) return;
                    setTimeout(fn, 200);
                    return
                }
                atb.addEventListener("click", function(e) {
                    var size = document.querySelectorAll(".quickDetails #productSizeStock button .activeOptionInput");
                    if (!size) return;
                    var sizeData = getSizeData();
                    JDObject.eventSubmit("quickViewAddToBasket", sizeData)
                });
                for (var i = 0; i < btns.length; i++) {
                    var item = btns[i];
                    item.addEventListener("click", function(e) {
                        var sizeData = getSizeData(e.target);
                        JDObject.eventSubmit("quickViewSizeSelect", sizeData)
                    })
                }
            };
            fn()
        };
    JDObject.h.hooks.register({
        name: "quickViewClick",
        eventType: "click",
        testerType: "matchAny",
        tester: ".quicklook",
        preflight: function(element) {
            if (!element) return;
            var plu = element.dataset.id;
            return {
                plu
            }
        }
    });
    var waiter = function(data, i) {
        var container = document.querySelector(".quicklook_container");
        var sizeButtons = (container || {}).querySelectorAll(".attribute_value_list li a");
        if (!container || !sizeButtons) {
            if (i < 40) setTimeout(waiter, 200, data.plu, (i || 0) + 1);
            return
        }
        var sizes = Array.from(sizeButtons).map((x) => x.innerText);
        JDObject.eventSubmit("quickView.view", {
            sizes: sizes,
            sizeButtons: sizeButtons,
            plu: data.plu,
            description: data.description,
            unitPrice: data.unitPrice
        })
    };
    JDObject.helpers.JDObject.events.quickViewClick = function(x) {
        waiter(x)
    };
    var items = document.querySelectorAll(".quicklook");
    items.forEach((x) => x.addEventListener("click",
        clickHandler));

    function clickHandler(e) {
        if (!(e.target instanceof HTMLElement)) return;
        var element = e.target;
        var plu = element.dataset.id;
        if (!plu) return;
        var url = element.parentElement.pathname;
        var name = (element.parentElement.querySelector("h2") || {}).innerText;
        var data = {
            plu: plu,
            description: name,
            productUrl: url
        };
        JDObject.eventSubmit("quickViewClick", data)
    }
}, 3285823, [3996520], 645420, [418795]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var tagATW = function() {
        var links = document.getElementsByClassName("addToWishlist");
        var fn = function() {
            window.JDObject.eventSubmit("addToWishlist", {
                page: window.location.pathname
            }, true)
        };
        for (var i = 0; i < links.length; i++) links[i].addEventListener("click", fn)
    };
    tagATW();
    var atw = document.querySelectorAll(".addToWishlist,.wishlistAdd");
    var fn2 = function() {
        JDObject.eventSubmit("addToWishlistClick", {})
    };
    for (var i = 0; i < atw.length; i++) atw[i].addEventListener("click", fn2)
}, 3188416, [3996520], 446512, [418795]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var links = document.getElementsByClassName("itemRating");
    var fn = function(event) {
        var item = event.target;
        var isUnload = true;
        if (item.pathname == window.location.pathname) isUnload = false;
        var page = window.location.pathname.indexOf("product");
        page = page > -1 && page < 10 ? "product" : "list";
        JDObject.eventSubmit("ratingClick", {
            page: page
        }, isUnload)
    };
    for (var i = 0; i < links.length; i++) links[i].addEventListener("click",
        fn)
}, 1729935, [3996520], 448201, [418795]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var fn = function() {
        var items = document.querySelectorAll(".tagg-balloon");
        Array.prototype.map.call(items, function(item) {
            if (item.getAttribute("tag-type")) return;
            var tagType = item.className.match(/[A-Z]+/)[0];
            item.setAttribute("tag-type", tagType);
            var text = item.innerText;
            if (["QPH", "QP"].indexOf(tagType) < 0) text = text.replace(/[0-9]+/g, "n");
            text = text.replace(/ ?- ?/g, "-");
            var obj = Bootstrapper.dataManager.getData();
            var version = (item.parentElement || item.parentNode).className.indexOf("tagg-balloons-wrapper-v2") > -1 ? 2 : 1;
            var data = {
                type: tagType,
                text: text,
                page: obj.pageType,
                version: version
            };
            JDObject.eventSubmit("taggstarBalloon", data)
        })
    };
    setInterval(fn, 1E3)
}, 2738763, [3446643, 3996520], 459676, [387263, 418795]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var items = document.querySelectorAll(".paymentMethod button.btn");
    var fn = function() {
        var item = this;
        var set = item.parentElement.getAttribute("data-paymentmethod");
        var option;
        if (set.match(/paypal/ig)) option = /credit/ig.test(set) ? "paypal_credit" : "paypal";
        else option = set;
        JDObject.eventSubmit("paymentMethodClick", {
            type: option,
            paymentType: option
        })
    };
    for (var i = 0; i < items.length; i++) items[i].addEventListener("click",
        fn);
    JDObject.h.hooks.register({
        eventType: "click",
        eventName: "paymentMethodClick",
        testerType: "matchAny",
        tester: "button.external-androidPay, button.external-applePay",
        preflight: function(items) {
            var initialName = JSON.parse(items[0].dataset.credentials).name;
            var type = initialName == "ANDROID PAY" ? "android" : "apple";
            type = JDObject.pageType == "basket" || JDObject.pageType == "checkout" ? type : type + "-quickview";
            return {
                type: type
            }
        }
    })
}, 3255410, [3996520, 3920363], 508268, [418795, 477766]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    JDObject.h.hooks.register({
        name: "productListClick",
        eventType: "mousedown",
        testerType: "matchAny",
        tester: "#rViewedEl a",
        preflight: function(item) {
            if (item.length) item = item[0];
            var listType = "recent";
            var targetPlu = window.location.pathname.match(JDObject.h.regex.pluR)[1];
            var pagePlu = dataObject.plu;
            var listPos = JDObject.query("#rViewedEl a").indexOf(item);
            listPos = typeof listPos ===
                "number" ? listPos += 1 : 0;
            return {
                targetPlu,
                position: listPos,
                list: listType + " - " + pagePlu
            }
        }
    });
    JDObject.h.hooks.register({
        name: "productListClick",
        eventType: "mousedown",
        testerType: "matchAny",
        tester: ".mt-merch-item a",
        preflight: function(item) {
            if (item.length) item = item[0];
            var listType = "recommended-list";
            var p = item.parentElement;
            while (!p.id.includes("mtRecs") && !p.id.includes("mt-slider") && p !== document.body) p = p.parentElement;
            if (p !== document.body) listType = p.querySelector("h2").innerText.toLowerCase().trim().replace(/\s/g,
                "-");
            var targetPlu = window.location.pathname.match(JDObject.h.regex.pluR)[1];
            var pagePlu = dataObject.plu;
            var listPos = JDObject.query(".mt-merch-item a").indexOf(item);
            listPos = typeof listPos === "number" ? listPos += 1 : 0;
            return {
                targetPlu,
                position: listPos,
                list: listType + " - " + pagePlu
            }
        }
    })
}, 3591660, [3920363], 657201, [477766]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var getBasketBrand = function(obj, item) {
        var basketRow = JDObject.h.q.ancestors.matchOne(item, ".basketListItem.anatwineFulfilment");
        if (!basketRow || !obj.items) return;
        var code = (basketRow.length ? basketRow[0] : basketRow).querySelector(".itemCode strong, .itemCode b");
        if (!code) return;
        code = code.innerText;
        if (!code) return;
        code = JDObject.get.cleanPlu(code);
        for (var i = 0; i < obj.items.length; i++) {
            if (obj.items[i].plu !=
                code) continue;
            return obj.items[i].brand
        }
    };
    var getBrand = function(item) {
        var obj = Bootstrapper.dataManager.getData();
        if (obj.brand) return obj.brand;
        var basketBrand = getBasketBrand(obj, item);
        if (basketBrand) return basketBrand;
        var productName = "";
        var className = "";
        if (JDObject.pageType == "basket" || JDObject.pageType == "product") className = ".basketListItem";
        else className = ".anatwineFulfilment";
        var fullfilment2 = item.parentNode.className.match(/fulfilmentMessage2/gi);
        if (fullfilment2) {
            productName = item.parentNode.innerText;
            className = ".anatwineFulfilment"
        } else {
            item = JDObject.h.q.ancestors.matchAny(item, className);
            if (item && (item.length === undefined || item.length > 0)) {
                if (item.length) item = item[0];
                var x = item.querySelector(".fulfilment-message img");
                x = !x ? x : x.src.match(/nike|reebok|adidas/gi);
                if (x && x.length) return x[x.length - 1];
                x = item.querySelector(".itemInfo h4");
                if (x) productName = x.innerText
            }
        }
        if (/nike|jordan/gi.test(productName)) return "Nike";
        if (/reebok/gi.test(productName)) return "Reebok";
        if (/adidas/gi.test(productName)) return "adidas";
        return "unknown"
    };
    var getPagetype = function(target) {
        if (target == document.querySelector("#basket-quickitems .fulfilment-learn-more")) return "Mini Basket";
        var p = JDObject.pageType;
        return "checkout,product,basket".indexOf(p) > -1 ? p[0].toUpperCase() + p.slice(1) : "unknown"
    };
    JDObject.h.hooks.register({
        name: "anatwineLearnMore",
        eventType: "mousedown",
        testerType: "matchAny",
        tester: ".fulfilment-learn-more",
        preflight: function(item) {
            if (item.length) item = item[0];
            var brand = getBrand(item);
            var location = getPagetype(item);
            if (brand ===
                "unknown") return false;
            return {
                label: brand,
                category: location
            }
        }
    })
}, 3158245, [3996520, 3044549, 3920363], 631700, [418795, 477762, 477766]);
Bootstrapper.bindDependencyDOMParsed(function() {
        var Bootstrapper = window["Bootstrapper"];
        var ensightenOptions = Bootstrapper.ensightenOptions;
        var links = document.getElementsByClassName("forgotPasswordLink");
        var c = window.location.pathname.indexOf("checkout") > -1;
        var place = c ? "checkout" : "login";
        var fn = function() {
            window.JDObject.eventSubmit("forgotPasswordClick", {
                GAEvent: ["click", "forgotPassword", place],
                place: place
            }, true)
        };
        for (var i = 0; i < links.length; i++) links[i].addEventListener("click", fn)
    }, 1836320, [3996520],
    446197, [418795]);
Bootstrapper.bindImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var btns = document.getElementsByClassName("itemAddtoBasket");
    var fn = function() {
        window.setTimeout(tagSizeButtons, 200)
    };
    for (var i = 0; i < btns.length; i++) btns[i].addEventListener("click", fn);
    var atb = function() {
        if (window.JDObject.helpers.quickView.exists == true) return;
        var s = this.dataset.sku.split(".");
        var p = this.dataset.price;
        var data = {
            plu: s[0],
            sku: s[1],
            unitPrice: p,
            price: p,
            origin: "wishlist"
        };
        console.info(JSON.stringify(data));
        JDObject.eventSubmit("addToBasket", data)
    };
    var tagSizeButtons = function() {
        if (window.JDObject.helpers.quickView.exists == true) return;
        var a = document.getElementById("quickDetails");
        var flag = false;
        if (a) {
            var sizes = a.getElementsByClassName("options")[0];
            if (sizes) {
                sizes = sizes.getElementsByTagName("button");
                if (sizes.length > 0)
                    for (var i = 0; i < sizes.length; i++) sizes[i].addEventListener("click", atb)
            }
        }
        window.setTimeout(tagSizeButtons, 200)
    }
}, 1696117, 440421);
Bootstrapper.bindDependencyDOMParsed(function() {
        var Bootstrapper = window["Bootstrapper"];
        var ensightenOptions = Bootstrapper.ensightenOptions;
        if (!window.JDObject) window.JDObject = {};
        if (!JDObject.helpers) JDObject.helpers = {};
        if (!JDObject.helpers.search) JDObject.helpers.search = {};
        try {
            var search = document.getElementById("fp-mobile-search-layer").getElementsByTagName("form")[0];
            search.onsubmit = window.JDObject.helpers.search.submit
        } catch (e) {}
        try {
            var search2 = document.getElementById("site-search");
            search2.onsubmit =
                window.JDObject.helpers.search.submit
        } catch (e) {}
        try {
            var search3 = document.getElementById("searchBar");
            search3.onsubmit = window.JDObject.helpers.search.submit
        } catch (e) {}
        try {
            var search4 = document.getElementById("catalogue-search-form");
            search4.onsubmit = window.JDObject.helpers.search.submit
        } catch (e) {}
        try {
            var mic = document.getElementById("speechInput");
            mic.addEventListener("click", function() {
                window.JDObject.helpers.search.voice = JDObject.siteCode.length % 2 == 1 ? true : !window.JDObject.helpers.search.voice
            })
        } catch (e) {}
    },
    3600156, [3948570], 323698, [323697]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;

    function cleanInnerHTML(inp) {
        return inp.replace(/<\/?b>/g, "").replace(/<.*/g, "")
    }
    JDObject.query("#recentProducts .overlayLink").map(function(item) {
        item.addEventListener("click", function(e) {
            var plu = JDObject.get.pluFromUrl(this.pathname);
            JDObject.eventSubmit("productClick", {
                plu: plu,
                type: "RecentlyViewedSearch"
            }, true)
        })
    });
    var ts = document.getElementById("trendingSearches");
    if (ts) ts.addEventListener("click", function(e) {
        var item = e.target;
        if (item.tagName === "A") {
            JDObject.eventSubmit("search.trending", {
                value: cleanInnerHTML(item.innerHTML)
            }, false);
            JDObject.eventSubmit("pageView.viewSearchResults", {
                type: "trending",
                searchValue: cleanInnerHTML(item.innerHTML)
            }, true)
        }
    });
    var lsr = document.getElementById("liveSearchResults") || document.getElementById("liveSearchResultsContent");
    if (lsr) lsr.addEventListener("click", function(e) {
        var item = e.target;
        if (item.tagName === "A") {
            while (item.tagName.toUpperCase() ==
                "SPAN" || item.tagName.toUpperCase() == "IMG") item = item.parentElement;
            if (item.parentElement.className.indexOf("product") > -1) {
                var plu = JDObject.get.pluFromUrl(this.pathname);
                JDObject.eventSubmit("productClick", {
                    plu: plu,
                    type: "SuggestedSearch"
                }, true);
                JDObject.eventSubmit("search.suggestedProduct", {
                    value: cleanInnerHTML(item.innerHTML)
                }, true);
                JDObject.eventSubmit("pageView.viewSearchResults", {
                    type: "suggestedProduct",
                    searchValue: cleanInnerHTML(item.innerHTML)
                }, true)
            } else {
                JDObject.eventSubmit("search.suggestedTerm", {
                    value: cleanInnerHTML(item.innerHTML)
                }, true);
                JDObject.eventSubmit("pageView.viewSearchResults", {
                    type: "suggestedTerm",
                    searchValue: cleanInnerHTML(item.innerHTML)
                }, true)
            }
        }
    });
    var rs = document.getElementById("recentSearches") || document.getElementById("recentSearchesContent");
    if (rs) rs.addEventListener("click", function(e) {
        var item = e.target;
        if (item.tagName === "A") {
            JDObject.eventSubmit("search.recent", {
                value: cleanInnerHTML(item.innerHTML)
            }, false);
            JDObject.eventSubmit("pageView.viewSearchResults", {
                type: "recent",
                searchValue: cleanInnerHTML(item.innerHTML)
            }, true)
        }
    })
}, 4057305, [4029119, 3996520], 454992, [274206, 418795]);
Bootstrapper.bindDependencyDOMParsed(function() {
        var Bootstrapper = window["Bootstrapper"];
        var ensightenOptions = Bootstrapper.ensightenOptions;
        var apple = document.getElementsByClassName("external-applePay");
        var android = document.getElementsByClassName("external-androidPay");
        if (apple.length) apple[0].addEventListener("click", function(e) {
            JDObject.eventSubmit("mobilePayClick", {
                type: "apple"
            })
        });
        if (android.length) android[0].addEventListener("click", function(e) {
            JDObject.eventSubmit("mobilePayClick", {
                type: "android"
            })
        })
    },
    2239132, [3996520], 509118, [418795]);