Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    if (window.dataObject && window.dataObject.items) {
        JDObject.assert("JDO.H.productList");
        JDObject.helpers.productList.productClickTagging = function() {
            var obj = Bootstrapper.dataManager.getData();
            var productData = {};
            for (var i = 0; i < obj.items.length; i++) productData[obj.items[i].plu.toString()] = {
                description: obj.items[i].description,
                price: obj.items[i].unitPrice || 0,
                sale: obj.items[i].sale,
                position: i + 1
            };
            JDObject.helpers.productList.productData = productData;
            var products = JDObject.helpers.productList.getProducts();
            if (products.length > 0) {
                var productClick = function(event) {
                    if (JDObject.helpers.productList.ignoreCurrentProductClick) return;
                    var item = this;
                    if (event.button == 0) JDObject.helpers.productList.productClickHref = item.href;
                    var plu = JDObject.helpers.productList.getProductPlu(item);
                    if (plu === false) return true;
                    var prod = JDObject.helpers.productList.productData[plu];
                    if (prod) {
                        var name = prod.description;
                        var posi = prod.position;
                        var gaData = {
                            "id": plu,
                            "name": name,
                            "position": posi
                        };
                        if (prod.price) gaData.price = prod.price;
                        else if (event.target) try {
                            var p = getPriceFromDom(event.target);
                            if (p) gaData.price = p
                        } catch (e) {}
                        ga("ec:addProduct", gaData)
                    }
                    ga("ec:setAction", "click", {
                        list: window.location.pathname
                    });
                    var callback = function() {
                        if (JDObject.helpers.productList.productClickHref) document.location = JDObject.helpers.productList.productClickHref;
                        JDObject.helpers.productList.productClickHref = null
                    };
                    if ("BL,ML,UO".split(",").indexOf(JDObject.fasciaParent) <
                        0) ga("send", "event", "UX", "click", "product", {
                        transport: "beacon"
                    });
                    else ga("send", "event", "UX", "click", "product", {
                        transport: "beacon"
                    });
                    if (event.button == 0);
                };
                for (var i = 0; i < products.length; i++) {
                    var items = JDObject.helpers.productList.getProductLinks(products[i]);
                    for (var j = 0; j < items.length; j++) items[j].onclick = productClick
                }
                if (JDObject.helpers.productList.getIgnoreClickButtons) {
                    var ignoreButtons = JDObject.helpers.productList.getIgnoreClickButtons();
                    var fn = function() {
                        JDObject.helpers.productList.ignoreCurrentProductClick =
                            true;
                        setTimeout(function() {
                            JDObject.helpers.productList.ignoreCurrentProductClick = false
                        }, 300)
                    };
                    for (var i = 0; i < ignoreButtons.length; i++)
                        for (var j = 0; j < ignoreButtons[i].length; j++) ignoreButtons[i][j].addEventListener("click", fn)
                }
            }
        }
    }
    var getPriceFromDom = function(prodEl) {
        while (prodEl.id != "productListMain" && prodEl.className.indexOf("productListItem") < 0) prodEl = prodEl.parentElement;
        if (prodEl.className.indexOf("productListItem") < 0) return false;
        var pri = prodEl.querySelector(".itemContainer .itemPrice .pri .now span");
        var price;
        if (pri) price = pri.innerText;
        else {
            pri = prodEl.querySelector(".itemContainer .itemPrice .pri");
            if (pri) price = pri.innerText;
            else return false
        }
        price = price.match(/([\d\.]+)/);
        if (price) return price[1];
        return false
    }
}, 3608461, [3749935], 294965, [276916]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var obj = JDObject.helpers.criteo.initiate();
    if (document.location.pathname.match(/^\/((home)|(shop))?\/?$/) || window.JDObject.isHomepage) {
        window.criteo_q.push({
            event: "viewHome"
        });
        JDObject.helpers.criteo.finalise()
    } else if (obj.items) {
        var itemIds = [];
        for (var i = 0; i < obj.items.length; i++) itemIds.push(obj.items[i].plu);
        window.criteo_q.push({
            event: "viewList",
            item: itemIds.slice(0,
                3),
            keywords: dataObject.keywords || ""
        });
        JDObject.helpers.criteo.finalise()
    } else {
        window.criteo_q.push({
            event: "viewPage"
        });
        JDObject.helpers.criteo.finalise()
    }
}, 3786127, [3749935, 3842731], 356886, [276916, 356885]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var obj = Bootstrapper.dataManager.getData();
    const wlpn = window.location.pathname;
    var prefixStr1 = "";
    var prefixStr2 = "";
    if (JDObject.fasciaCode == "FR") {
        prefixStr1 = "fr-";
        prefixStr2 = "fr_"
    }
    if (obj.items && obj.items.length) {
        var url = JDObject.helpers.redEye.init();
        var oPlu = JDObject.helpers.redEye.useOriginalPlu;
        var isEnabled = true;
        var isMob = /^([A-Z]{2})+M$/i.test(window.JDObject.siteCode);
        var devb = isMob ? "Mob" : "";
        var brandName = "nobrand";
        if (/\/brand\//i.test(wlpn)) {
            if (obj.items[0].brand) brandName = obj.items[0].brand;
            url = JDObject.helpers.redEye.init(prefixStr2 + "brand-viewed");
            url += "\x26" + prefixStr2 + "view_brand_event\x3d" + prefixStr1 + "view-brand-event";
            url += "\x26" + prefixStr2 + "view_brand_name\x3d" + brandName;
            url += "\x26" + prefixStr2 + "view_brand_url\x3d" + window.location.href.replace("https://", "");
            url += "\x26" + prefixStr2 + "view_brand_site\x3d" + JDObject.fasciaCode + devb
        } else if (/\/search\//i.test(wlpn) ||
            obj.listingType === "search") {
            if (obj.keywords && obj.keywords.length > 0) {
                url = JDObject.helpers.redEye.init(prefixStr2 + "search-results");
                url += "\x26" + prefixStr2 + "good_search\x3d" + prefixStr1 + "good_search";
                url += "\x26" + prefixStr2 + "search_term\x3d" + encodeURIComponent(obj.keywords);
                url += "\x26" + prefixStr2 + "search_site\x3d" + JDObject.fasciaCode + devb;
                var ampSC = window.JDObject.amplienceSiteCode;
                for (var i = 0; i < 5; i++) {
                    var item = obj.items[i];
                    if (!item) break;
                    var x = i + 1;
                    var imgPlu = item.mediaRef;
                    if ("GO".split(",").indexOf(JDObject.fasciaCode) >
                        -1) try {
                        imgPlu = document.querySelector('.product-item-holder a[href^\x3d"/' + item.plu + '"] noscript').innerHTML.match(JDObject.get.imgRegex)[1];
                        imgPlu = imgPlu.slice(0, -1)
                    } catch (e) {}
                    var ampPlu = imgPlu || ampSC + "_" + JDObject.get.cleanPlu(item.plu);
                    if (JDObject.fasciaCode == "ODPS") ampPlu = ampPlu.replace("od_", "bl_");
                    var prodUrl = JDObject.get.productURL(oPlu ? item.originalPlu : item.plu);
                    if (JDObject.helpers.redEye.forceMobileUrl) prodUrl = prodUrl.replace("www", "m");
                    url += "\x26" + prefixStr2 + "search_name" + x + "\x3d" + JDObject.helpers.redEye.cleanName(item.description);
                    url += "\x26" + prefixStr2 + "search_code" + x + "\x3d" + encodeURIComponent(JDObject.get.cleanPlu(item.plu));
                    url += "\x26" + prefixStr2 + "search_url" + x + "\x3d" + encodeURIComponent(JDObject.helpers.redEye.rmfurl(prodUrl));
                    if (obj.items[i].brand && !!obj.items[i].brand) brandName = obj.items[i].brand;
                    else brandName = "nobrand";
                    url += "\x26" + prefixStr2 + "search_brand" + x + "\x3d" + brandName;
                    if (JDObject.fasciaCode == "BA") {
                        if (document.querySelector("a.itemImage[href*\x3d'" + item.plu + "']") && document.querySelector("a.itemImage[href*\x3d'" +
                                item.plu + "']").querySelector("img")) {
                            var imgurl = document.querySelector("a.itemImage[href*\x3d'" + item.plu + "']").querySelector("img").getAttribute("src");
                            url += "\x26" + prefixStr2 + "search_image" + x + "\x3d" + encodeURIComponent(imgurl.replace(/(https?:)?\/\//g, ""))
                        }
                    } else url += "\x26" + prefixStr2 + "search_image" + x + "\x3d" + encodeURIComponent("i1.adis.ws/i/jpl/" + ampPlu + "_a?qlt\x3d85");
                    if (item.previousPrice) {
                        url += "\x26" + prefixStr2 + "search_val" + x + "\x3d" + encodeURIComponent(item.previousPrice);
                        url += "\x26" + prefixStr2 +
                            "search_discount_val" + x + "\x3d" + encodeURIComponent(item.unitPrice)
                    } else url += "\x26" + prefixStr2 + "search_val" + x + "\x3d" + encodeURIComponent(item.unitPrice)
                }
            }
        } else {
            if (dataObject && (dataObject.category || dataObject.categoryName)) url = JDObject.helpers.redEye.init(prefixStr2 + "category-viewed");
            url += "\x26" + prefixStr2 + "view_cat_event\x3d" + prefixStr1 + "view-cat-event";
            if (JDObject.fasciaCode == "GO") isEnabled = false;
            var cat;
            if (obj.category) cat = obj.category;
            else if (obj.pageName) {
                cat = obj.pageName.replace(/[^a-zA-Z ]/g,
                    "");
                if (JDObject.fasciaCode === "NY") cat = cat.split("|")[0] || ""
            } else cat = wlpn.split("/")[1];
            if (JDObject.fasciaCode != "BA") url += "\x26" + prefixStr2 + "view_cat_site\x3d" + JDObject.fasciaCode + devb;
            url += "\x26" + prefixStr2 + "view_cat_name\x3d" + encodeURIComponent(JDObject.helpers.redEye.cleanName(cat.replace(/[^\w\s]/gi, " ")));
            url += "\x26" + prefixStr2 + "view_cat_url\x3d" + window.location.href.replace("https://", "")
        }
        if (isEnabled) JDObject.helpers.redEye.finalise(url)
    }
}, 3800440, [3749935, 3938569, 3340719, 1672186], 411900, [276916,
    411899, 432622, 439126
]);
Bootstrapper.bindDependencyImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    try {
        var imageLinks = JDObject.query("#productListMain .itemImage");
        var plus = dataObject.items.map((x) => x.plu);
        imageLinks.forEach((x) => {
            plus.forEach((y, i) => {
                if (!x.href.includes(y)) return;
                var img = x.querySelector("img");
                if (!img) return;
                img = img.src.match(JDObject.get.imgRegex);
                if (!img || img.length < 2) return;
                var mRef = img[1].replace(/_$/, "");
                dataObject.items[i].mediaRef = mRef
            })
        })
    } catch (e) {}
    if (window.dataObject &&
        window.dataObject.items) Bootstrapper.dataManager.push({
        name: "JD Sports GlobalExPBC Data Layer",
        id: "productListDataLayer",
        data: {
            itemCount: {
                name: "itemCount",
                get: function() {
                    var itemCount;
                    try {
                        itemCount = dataObject.itemCount
                    } catch (e) {}
                    return itemCount
                }
            },
            itemPageCount: {
                name: "itemPageCount",
                get: function() {
                    var itemPageCount;
                    try {
                        itemPageCount = dataObject.itemPageCount
                    } catch (e) {}
                    return itemPageCount
                }
            },
            itemPageCurrent: {
                name: "itemPageCurrent",
                get: function() {
                    var itemPageCurrent;
                    try {
                        itemPageCurrent = dataObject.itemPageCurrent
                    } catch (e) {}
                    return itemPageCurrent
                }
            },
            itemPagePer: {
                name: "itemPagePer",
                get: function() {
                    var itemPagePer;
                    try {
                        itemPagePer = dataObject.itemPagePer
                    } catch (e) {}
                    return itemPagePer
                }
            },
            items: {
                name: "items",
                get: function() {
                    var items = [];
                    try {
                        items = dataObject.items
                    } catch (e) {}
                    return items
                }
            },
            listingType: {
                name: "search or not-search",
                get: function() {
                    var listingType = "unknown";
                    try {
                        listingType = dataObject.listingType
                    } catch (e) {
                        if (document.location.pathname.indexOf("search") > -1) listingType = "search"
                    }
                    return listingType
                }
            },
            keywords: {
                name: "search or not-search",
                get: function() {
                    var keywords = [];
                    try {
                        if (dataObject.listingType.toLowerCase() == "search") keywords = dataObject.keywords
                    } catch (e) {
                        if (document.location.pathname.indexOf("search") > -1) keywords = "search"
                    }
                    return keywords
                }
            },
            category: {
                name: "list category",
                get: function() {
                    var keywords = "";
                    try {
                        keywords = dataObject.category
                    } catch (e) {
                        if (document.location.pathname.indexOf("search") > -1) keywords = "search"
                    }
                    return keywords
                }
            },
            categories: {
                name: "categories",
                get: function() {
                    var cats = [];
                    try {
                        cats = dataObject.category.split(/ ?> ?/gi)
                    } catch (e) {
                        console.log("failed to fetch categories");
                        window.complainToMaster && window.complainToMaster({
                            error: {
                                name: e.name,
                                message: e.message
                            }
                        }, "failed to fetch categories")
                    }
                    return cats
                }
            }
        }
    });
    var type = "productListDataLayer";
    JDObject.runDependants ? JDObject.runDependants(type) : JDObject.bindORInbox.push(type)
}, 3749935, [4029119, 2913091], 276916, [274206, 276097]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var obj = Bootstrapper.dataManager.getData();
    JDObject.eventSubmit("pageView.globalEx", {
        obj: obj
    });
    JDObject.eventSubmit("pageView.globalExPBC", {
        obj: obj
    });
    JDObject.eventSubmit("pageView.globalExPBCC", {
        obj: obj
    });
    if (window.dataObject && dataObject.items && dataObject.items.length) {
        var data = {
            obj: obj
        };
        var res = window.location.pathname.match(/^\/?(?:search\/|s:)([^\/]+)\/?/i);
        if (res && res[1]) {
            data.type = "search";
            data.searchValue = decodeURIComponent(res[1]).replace(/\+/g, " ")
        } else data.type = "list";
        JDObject.eventSubmit("pageView.list", data)
    }
}, 3398015, [3749935, 3996520], 512697, [276916, 418795]);
Bootstrapper.bindDependencyDOMLoaded(function() {
        var Bootstrapper = window["Bootstrapper"];
        var ensightenOptions = Bootstrapper.ensightenOptions;
        var sortDropDown = document.querySelector("#productListRefine #sortFormTop select");
        var sortDropDownMobile = document.querySelector("#sortForm #sortSelect");
        var fn = function(event) {
            console.log("Hooks/ProductList/Sort");
            JDObject.eventSubmit("productList.sort", {
                label: event.target.value
            })
        };
        if (sortDropDown || sortDropDownMobile) sortDropDown.addEventListener("change", fn)
    },
    3138968, [3961811], 617410, [424075]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    if (window.dataObject && dataObject.items) {
        var plp = JDObject.assert("JDO.h.d.plp");
        window.setInterval(function() {
            var selects = JDObject.query("#sortFormTop select.sort, #sortSelect");
            for (var i = 0; i < selects.length; i++) {
                var item = selects[i];
                var value = item.value || "recommended";
                if (!item.oldValue) {
                    item.oldValue = value;
                    continue
                }
                if (item.oldValue == value) continue;
                JDObject.eventSubmit("productList.sort", {
                    label: value
                });
                item.oldValue = value
            }
        }, 256);
        JDObject.h.hooks.register({
            name: "productList.refine",
            eventType: "click",
            testerType: "matchAny",
            tester: "#productListLeft .list-filters .filterLink",
            preflight: function(item) {
                var value = item.innerHTML.replace(/(<[^>]+>|\([^()]+\))/g, "").trim();
                var set = JDObject.h.q.ancestors.matchOneByClass(item, "filterSet");
                var h4 = set.getElementsByTagName("h4")[0];
                var name = h4.innerHTML.replace(/<[^>]+>/g, "");
                return {
                    name: name,
                    type: name,
                    value: value
                }
            }
        });
        JDObject.h.hooks.register({
            name: "productList.refineOpenClear",
            eventType: "click",
            testerType: "matchAny",
            tester: "#productListTitleRight .refine .btn.btn-default",
            preflight: function() {
                return "Open Refine"
            }
        });
        var refineSelectionItems = [];
        var submitEvents = function() {
            var s = refineSelectionItems;
            for (var i = 0; i < s.length; i++) JDObject.eventSubmit("productList.refine", s[i])
        };
        var getEventData = function(item) {
            var btnText = item.innerHTML;
            var parent = item.parentNode.parentNode.parentNode.querySelector(".topLevelFilter");
            var typeName = parent.innerHTML;
            return {
                name: typeName,
                type: typeName,
                value: btnText
            }
        };
        var fn = function(e) {
            var item = e.target;
            var selected = item.className.match(/(^| )selected( |$)/g);
            var data = getEventData(item);
            if (selected) {
                refineSelectionItems.push(data);
                return
            }
            for (var i = 0; i < refineSelectionItems.length; i++) {
                if (refineSelectionItems[i].type != data.type || refineSelectionItems[i].value != data.value) continue;
                refineSelectionItems.splice(i, i)
            }
        };
        const selectItems = document.querySelectorAll("#refine #topLevelFilters .filterLink");
        selectItems.forEach(function(selectItem) {
            selectItem.addEventListener("click",
                fn)
        });
        var applyBtn = document.querySelector("#refine #applyClear a.apply-active");
        if (applyBtn) applyBtn.addEventListener("click", (e) => {
            submitEvents()
        });
        var clearBtn = document.querySelector("#refine .clear-all-active");
        if (clearBtn) clearBtn.addEventListener("click", (e) => {
            refineSelectionItems = [];
            JDObject.eventSubmit("productList.refineOpenClear", "Clear Selection")
        })
    }
}, 4018460, [2505967, 3044549, 3920363], 489327, [382230, 477762, 477766]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    JDObject.h.hooks.register({
        name: "productList.refine",
        eventType: "click",
        testerType: "matchAny",
        tester: ".filterLink",
        preflight: function(item) {
            if (item.length) item = item[0];
            console.info("test");
            while (item.className.indexOf("filterLink") < 0) {
                if (item == window.body) return false;
                item = item.parentElement || item.parentNode
            }
            var text = item.innerText;
            while (item.className.indexOf("filterSet") <
                0) {
                if (item == window.body) return false;
                item = item.parentElement || item.parentNode
            }
            var name = item.getElementsByTagName("h4")[0].innerText;
            var x = text.split("(");
            var value = x[0];
            var count = x[1].match(/\d/g).join("");
            return {
                beacon: true,
                type: name,
                value: value,
                count: count,
                list: window.location.pathname
            }
        }
    })
}, 3130526, [3920363], 483135, [477766]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var btns = document.querySelectorAll(".pageLinks .pageLink:not(.active), .pageNav:not(.disabled)");
    var fn = function(e) {
        var t = e.target;
        var inner = t.innerHTML;
        var page = "";
        if (inner.length < 4) page = inner;
        else if (inner.indexOf("right") > -1) page = "next";
        else if (inner.indexOf("left") > -1) page = "previous";
        JDObject.eventSubmit("productList.pagination", {
            page: page
        })
    };
    for (var i = 0; i <
        btns.length; i++) btns[i].addEventListener("click", fn)
}, 3130537, [3996520], 467076, [418795]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var showLess = document.getElementsByClassName("showLess");
    var showMore = document.getElementsByClassName("showMore");

    function getCount(e) {
        return e.target.getAttribute("data-rpp")
    }
    var lessFn = function(e) {
        JDObject.eventSubmit("productList.showLess", {
            count: getCount(e)
        })
    };
    var moreFn = function(e) {
        JDObject.eventSubmit("productList.showMore", {
            count: getCount(e)
        })
    };
    for (var i =
            0; i < showLess.length; i++) showLess[i].addEventListener("click", lessFn);
    for (var i = 0; i < showMore.length; i++) showMore[i].addEventListener("click", moreFn)
}, 3699524, [3996520], 467069, [418795]);
Bootstrapper.bindDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var container = document.querySelector("#lbOpenCt");
    var isOpen = false;
    var openCloseTrigger = function() {
        if (container.hasChildNodes() === isOpen) return;
        isOpen = container.hasChildNodes();
        if (isOpen) waitForSizeLoad();
        else JDObject.eventSubmit("quickView.close", {})
    };
    if (container) setInterval(openCloseTrigger, 500);
    var waitForSizeLoad = function(data) {
        if (document.querySelector("#productSizeStock .options-loading, #quickDetails .options-loading")) {
            setTimeout(waitForSizeLoad,
                200, data);
            return
        }
        JDObject.eventSubmit("quickView.view", getQuickViewData())
    };
    var getQuickViewData = function() {
        var sizes = container.querySelectorAll("#productSizeStock button, #quickDetails .options button");
        var data = {};
        var img = container.querySelector("#quickImage img");
        if (img) {
            img = img.src.match(/^.*(?:jpl)\/([a-z]+_[^_\/\?&]+)_[a-z]/i) || [];
            img = img[0];
            if (img) data.mediaRef = img
        }
        if (sizes && sizes.length) {
            data.sizeButtons = sizes;
            var item = sizes[0];
            var plu = item.dataset.sku;
            if (plu) plu = plu.split(".")[0];
            if (plu) {
                data.plu =
                    JDObject.get.cleanPlu(plu);
                data.originalPlu = plu
            }
            var price = item.dataset.price;
            if (price) price = parseFloat(price.replace(/[^\d\.]/g, ""));
            if (price) {
                data.unitPrice = price;
                data.price = price
            }
            var title = container.querySelector("#productItemTitle h1, .productDetails h1");
            if (title) {
                data.description = title.innerText;
                data.name = title.innerText
            }
            for (let i = 0; i < sizes.length; i++) {
                var item = sizes[i];
                var itemData = {
                    button: item
                };
                var sku = item.dataset.sku;
                if (sku) sku = sku.split(".")[1];
                if (sku) itemData.sku = sku;
                var hasStock = item.dataset.stock;
                hasStock = !/^(0|false|null|non?e?)$/i.test(hasStock);
                itemData.hasStock = hasStock;
                var name = item.innerText.trim();
                itemData.name = name;
                if (i === 0) data.items = [];
                data.items.push(itemData)
            }
        }
        return data
    }
}, 3275900, 646010);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var target = document.querySelector("#productListMain");
    if (target) {
        JDObject.assert("JDO.H.temp");
        JDObject.helpers.temp.plpLoadMoreCount = 0;
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type == "childList" && !JDObject.helpers.temp.plpLoadMoreDeduplicator) {
                    JDObject.helpers.temp.plpLoadMoreCount++;
                    JDObject.eventSubmit("scrollLoadMore", {
                        count: JDObject.helpers.temp.plpLoadMoreCount
                    });
                    JDObject.helpers.temp.plpLoadMoreDeduplicator = true;
                    window.setTimeout(function() {
                        JDObject.helpers.temp.plpLoadMoreDeduplicator = false
                    }, 500)
                }
            })
        });
        var config = {
            attributes: true,
            childList: true,
            characterData: true
        };
        observer.observe(target, config)
    }
}, 2066462, [2505967], 467098, [382230]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var items = document.querySelectorAll("li.neLink a");
    var fn = function(e) {
        var header = document.getElementsByClassName("fhTitle")[0].innerText;
        var linkText = this.innerText;
        JDObject.eventSubmit("navigation.fredHopperClick", {
            header: header,
            linkText: linkText
        })
    };
    for (var i = 0; i < items.length; i++) items[i].addEventListener("click", fn);
    JDObject.assert("JDO.H.GA.e.navigation");
    JDObject.helpers.GA.events.navigation.fredHopperClick =
        function(data) {
            ga("send", "event", "Navigation", "FH Banner Click", data.header + " - " + data.linkText)
        }
}, 2661712, [3952459], 571644, [268459]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var obj = Bootstrapper.dataManager.getData();
    var searchURLRemap = ["AK", "CL", "FP", "JD", "HS", "OI", "PY", "SC", "SZ"].indexOf(JDObject.fasciaParent) > -1;
    if (!searchURLRemap && ["BLM", "MLM", "TEM", "UOM"].indexOf(JDObject.siteCode) > -1) searchURLRemap = true;
    try {
        if (window.dataObject && dataObject.items) {
            var items = obj.items;
            console.log("Impressions");
            for (var i = 0; i < items.length; i++) {
                item =
                    items[i];
                ga("ec:addImpression", {
                    "id": item.plu,
                    "category": item.category || "",
                    "list": window.location.pathname,
                    "position": item.position || i + 1
                });
                if (i != 0 && i % 50 == 0) ga("send", "event", "UX", "impressions", "overflow", {
                    nonInteraction: true
                })
            }
            if (dataObject.itemCount != null) ga("set", "dimension6", dataObject.itemCount || 0)
        }
    } catch (e) {
        if (window.dataObject && dataObject.items) {
            console.log("GUA Impressions Error");
            console.log(e);
            window.complainToMaster && window.complainToMaster({
                error: {
                    type: e.name,
                    message: e.message
                }
            }, "failed to add GUA impressions")
        }
    }
    if (window.location.pathname.indexOf("/checkout") <
        0)
        if (document.location.pathname == "/") ga("send", "pageview", "/home");
        else if (searchURLRemap && window.location.pathname.match(/(\/search\/[a-z]+)/gi)) {
        var a = document.location.pathname.replace(/%20/g, "+").replace(/^\/?search\//, "?q\x3d");
        var url = document.location.pathname + (a[a.length - 1] == "/" ? a.slice(0, a.length - 1) : a) + document.location.search.replace("?", "\x26");
        window.JDObject.helpers.GA.sendGAPageview(url)
    } else window.JDObject.helpers.GA.sendGAPageview();
    else ga("send", "event", "Data", "OldCheckout");
    if (document.getElementsByClassName("not-found").length >
        0 && !JDObject.is404) ga("send", "event", "UX", "productList", "no products found")
}, 3759470, [3952459, 4029119, 3749935, 3279930], 267967, [268459, 274206, 276916, 349782]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var getItem = function(plu) {
        for (var i = 0; i < obj.items.length; i++)
            if (JDObject.get.cleanPlu(obj.items[i].plu) == JDObject.get.cleanPlu(plu)) return obj.items[i];
        return false
    };
    if (window.location.hostname[0].toLowerCase() != "m") JDObject.h.hooks.register({
        name: "quickViewAddToBasket",
        eventType: "mousedown",
        testerType: "matchAny",
        tester: "#quickDetails .options .btn, .quickViewButtons .add-to-basket",
        preflight: function(item) {
            if (item.length) item = item[0];
            var data = {};
            data.isUnload = false;
            data.btn = item;
            var size = document.querySelector("#itemOptions .activeOptionInput, #quickDetails .activeOptionInput");
            if (!size) size = item;
            if (size) {
                if (size.dataset && size.dataset.sku) {
                    var sku = size.dataset.sku.split(".");
                    if (sku.length > 1) data.plu = JDObject.get.cleanPlu(sku[0]);
                    data.sku = sku[sku.length - 1]
                }
                data.size = size.innerHTML.trim()
            }
            var qv = JDObject.helpers.temp.quickView;
            if (qv.item) data.item = qv.item;
            else if (qv.plu || data.plu) {
                var itm =
                    getItem(qv.plu || data.plu);
                if (itm) data.item = itm
            }
            return data
        }
    });
    else JDObject.h.hooks.register({
        name: "quickViewAddToBasket",
        eventType: "mousedown",
        testerType: "matchAny",
        tester: "#quickDetails .options .btn",
        preflight: function(item) {
            if (item.length) item = item[0];
            var data = {};
            data.isUnload = false;
            data.btn = item;
            var size = document.querySelector("#itemOptions .activeOptionInput, #quickDetails .activeOptionInput");
            if (!size) size = item;
            if (size) {
                if (size.dataset && size.dataset.sku) {
                    var sku = size.dataset.sku.split(".");
                    if (sku.length > 1) data.plu = JDObject.get.cleanPlu(sku[0]);
                    data.sku = sku[sku.length - 1]
                }
                data.size = size.innerHTML.trim()
            }
            var qv = JDObject.helpers.temp.quickView;
            if (qv.item) data.item = qv.item;
            else if (qv.plu || data.plu) {
                var itm = getItem(qv.plu || data.plu);
                if (itm) data.item = itm
            }
            return data
        }
    })
}, 2771129, [3044549, 3920363], 488914, [477762, 477766]);