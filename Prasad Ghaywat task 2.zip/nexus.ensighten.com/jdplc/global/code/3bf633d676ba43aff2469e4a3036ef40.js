Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    if (window.dataObject && window.dataObject.items) {
        JDObject.assert("JDO.H.productList");
        JDObject.helpers.productList.productClickTagging = function() {
            var obj = Bootstrapper.dataManager.getData();
            var productData = {};
            for (var i = 0; i < obj.items.length; i++) productData[obj.items[i].plu.toString()] = {
                description: obj.items[i].description,
                price: obj.items[i].unitPrice || 0,
                sale: obj.items[i].sale,
                position: i + 1
            };
            JDObject.helpers.productList.productData = productData;
            var products = JDObject.helpers.productList.getProducts();
            if (products.length > 0) {
                var productClick = function(event) {
                    if (JDObject.helpers.productList.ignoreCurrentProductClick) return;
                    var item = this;
                    if (event.button == 0) JDObject.helpers.productList.productClickHref = item.href;
                    var plu = JDObject.helpers.productList.getProductPlu(item);
                    if (plu === false) return true;
                    var prod = JDObject.helpers.productList.productData[plu];
                    if (prod) {
                        var name = prod.description;
                        var posi = prod.position;
                        var gaData = {
                            "id": plu,
                            "name": name,
                            "position": posi
                        };
                        if (prod.price) gaData.price = prod.price;
                        else if (event.target) try {
                            var p = getPriceFromDom(event.target);
                            if (p) gaData.price = p
                        } catch (e) {}
                        ga("ec:addProduct", gaData)
                    }
                    ga("ec:setAction", "click", {
                        list: window.location.pathname
                    });
                    var callback = function() {
                        if (JDObject.helpers.productList.productClickHref) document.location = JDObject.helpers.productList.productClickHref;
                        JDObject.helpers.productList.productClickHref = null
                    };
                    if ("BL,ML,UO".split(",").indexOf(JDObject.fasciaParent) <
                        0) ga("send", "event", "UX", "click", "product", {
                        transport: "beacon"
                    });
                    else ga("send", "event", "UX", "click", "product", {
                        transport: "beacon"
                    });
                    if (event.button == 0);
                };
                for (var i = 0; i < products.length; i++) {
                    var items = JDObject.helpers.productList.getProductLinks(products[i]);
                    for (var j = 0; j < items.length; j++) items[j].onclick = productClick
                }
                if (JDObject.helpers.productList.getIgnoreClickButtons) {
                    var ignoreButtons = JDObject.helpers.productList.getIgnoreClickButtons();
                    var fn = function() {
                        JDObject.helpers.productList.ignoreCurrentProductClick =
                            true;
                        setTimeout(function() {
                            JDObject.helpers.productList.ignoreCurrentProductClick = false
                        }, 300)
                    };
                    for (var i = 0; i < ignoreButtons.length; i++)
                        for (var j = 0; j < ignoreButtons[i].length; j++) ignoreButtons[i][j].addEventListener("click", fn)
                }
            }
        }
    }
    var getPriceFromDom = function(prodEl) {
        while (prodEl.id != "productListMain" && prodEl.className.indexOf("productListItem") < 0) prodEl = prodEl.parentElement;
        if (prodEl.className.indexOf("productListItem") < 0) return false;
        var pri = prodEl.querySelector(".itemContainer .itemPrice .pri .now span");
        var price;
        if (pri) price = pri.innerText;
        else {
            pri = prodEl.querySelector(".itemContainer .itemPrice .pri");
            if (pri) price = pri.innerText;
            else return false
        }
        price = price.match(/([\d\.]+)/);
        if (price) return price[1];
        return false
    }
}, 3608461, [3749935], 294965, [276916]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    if (window.location.search.indexOf("taggTest\x3dtrue") < 0) {
        var productList = function(siteConfig, siteCode, mobile) {
            var selectors = {
                MS: {
                    breadCrumb: "#breads span a",
                    itemInfo: ".itemInformation",
                    productNameDetails: '.product[data-component-name\x3d"catalogue-product"]',
                    productURL: "a.itemImage",
                    mobileListItems: "#productListMain li.productListItem span.itemContainer"
                },
                FS: {
                    breadCrumb: "#breads span a",
                    itemInfo: ".itemInformation",
                    productNameDetails: '.product[data-component-name\x3d"catalogue-product"]',
                    productURL: "a.itemImage",
                    mobileListItems: "#productListMain li.productListItem span.itemContainer"
                },
                JDFR: {
                    breadCrumb: "#breads span a",
                    itemInfo: ".itemInformation",
                    productNameDetails: '.product[data-component-name\x3d"catalogue-product"]',
                    productURL: "a.itemImage",
                    mobileListItems: "#productListMain li.productListItem span.itemContainer"
                },
                SZ: {
                    breadCrumb: "#breads span a",
                    itemInfo: ".itemInformation",
                    productNameDetails: '.product[data-component-name\x3d"catalogue-product"]',
                    productURL: "a.itemImage",
                    mobileListItems: "#productListMain li.productListItem span.itemContainer"
                },
                FP: {
                    breadCrumb: "#breads span a",
                    itemInfo: ".itemInformation",
                    productNameDetails: '.product[data-component-name\x3d"catalogue-product"]',
                    productURL: "a.itemImage",
                    mobileListItems: "#productListMain li.productListItem span.itemContainer"
                },
                HS: {
                    breadCrumb: "#breads span a",
                    itemInfo: ".itemInformation",
                    productNameDetails: '.product[data-component-name\x3d"catalogue-product"]',
                    productURL: "a.itemImage",
                    mobileListItems: "#productListMain li.productListItem span.itemContainer"
                }
            }[siteCode];
            if (!selectors) selectors = {
                breadCrumb: "#breads span a",
                itemInfo: "span.itemInformation",
                productNameDetails: '.product[data-component-name\x3d"catalogue-product"]',
                productURL: "a.itemImage",
                mobileListItems: "#productListMain li.productListItem span.itemContainer"
            };
            var $anchorElements;
            var anchorSelectors = {
                mobileListItems: selectors.mobileListItems,
                productNameDetails: selectors.productNameDetails
            };
            var categoryModule = function() {
                function isMobile() {
                    return location.host[0] == "m"
                }

                function getPageData(item) {
                    var data =
                        window.JDObject.dataLayerCache;
                    return data && data[item]
                }

                function getProductIds() {
                    var productIds = [],
                        pageData = window.JDObject.dataLayerCache,
                        j, item;
                    for (j = 0; j < pageData.items.length; j++) {
                        item = pageData.items[j];
                        productIds.push(item.plu)
                    }
                    return productIds
                }

                function getProductIdFromAnchor(anchor) {
                    var $refObj = anchor.children(selectors.productURL),
                        id = 0;
                    if ($refObj != null && typeof $refObj.attr("href") != "undefined") {
                        var url = $refObj.attr("href");
                        try {
                            id = url.split("/")[3];
                            if (siteCode != "FS") id = id.split("_")[0]
                        } catch (e) {}
                    }
                    return id
                }

                function getBalloonAnchors() {
                    if ($anchorElements) return $anchorElements;
                    for (var p in anchorSelectors)
                        if (anchorSelectors.hasOwnProperty(p)) {
                            var jq = $(anchorSelectors[p]);
                            if (jq.length) return $anchorElements = jq
                        }
                }

                function getCategory() {
                    var breadcrumb, category, $breadcrumbs, j;
                    if (isMobile()) return "-";
                    else {
                        $breadcrumbs = $(selectors.breadCrumb);
                        category = "";
                        for (j = 1; j < $breadcrumbs.length - 1; j++) category += "/" + $breadcrumbs.eq(j).text().trim().toLowerCase()
                    }
                    return category
                }

                function displayMessages(socialProof, $balloonAnchors) {
                    for (var i =
                            0; i < socialProof.length; i++)(function(i) {
                        var isJDint = JDObject.fasciaParent == "JD" && JDObject.fasciaParent != JDObject.fasciaCode;
                        var message = socialProof[i],
                            firstProduct = socialProof[i].product,
                            wrapperClass = isMobile() && !isJDint ? "tagg-balloons-wrapper-n" : "tagg-balloons-wrapper",
                            $balloonWrapper = $('\x3cdiv class\x3d"tagg-category-page ' + wrapperClass + '"\x3e\x3c/div\x3e'),
                            $balloon = taggstar.util.getBalloon(message.messages[0]);
                        $balloonWrapper.append($balloon);
                        $balloonAnchors.each(function(index, value) {
                            var $anchor =
                                $(value),
                                id = getProductIdFromAnchor($anchor);
                            if (id == firstProduct.id) $anchor.find(selectors.itemInfo).append($balloonWrapper)
                        })
                    })(i)
                }
                var pageType = getPageData("pageType");
                if (pageType != "global" && pageType != "list" && pageType != "category") {
                    taggstar.log("not category page", "warn");
                    return
                }
                taggstar.init(siteConfig);
                var categoryPageData = {
                    products: getProductIds(),
                    category: getCategory()
                };
                taggstar.categoryRequest(categoryPageData, function(responseData, error) {
                    taggstar.handleResponseMulti(responseData, error, function(messages) {
                        var $balloonAnchors =
                            getBalloonAnchors();
                        if ($balloonAnchors) displayMessages(responseData.socialProof, $balloonAnchors)
                    })
                })
            };
            taggstar.boot(function() {
                var data = Bootstrapper.dataManager.getData();
                if (data) window.JDObject.dataLayerCache = data;
                return data && data.pageType
            }, categoryModule)
        };
        JDObject.helpers.taggstar.load(productList)
    }
}, 3971840, [3749935, 3446643], 387264, [276916, 387263]);