Bootstrapper.bindImmediate(function() {
    var ddConditions = {
        "not": [null],
        "caseInsensitive": ["ignore case"],
        "compareTo": [""],
        "requiredData": ["54089"],
        "comparators": ["exists"]
    };
    Bootstrapper.data.resolve(ddConditions.requiredData, function() {
        ddConditions.values = Array.prototype.slice.call(arguments, 0);
        var Bootstrapper = window["Bootstrapper"];
        if (Bootstrapper.data.checkConditions(ddConditions)) Bootstrapper.bindImmediate(function() {
            var Bootstrapper = window["Bootstrapper"];
            var ensightenOptions = Bootstrapper.ensightenOptions;
            console.log("Targeting tagging enabled")
        }, 3455314, 542880)
    })
}, -1, -1);