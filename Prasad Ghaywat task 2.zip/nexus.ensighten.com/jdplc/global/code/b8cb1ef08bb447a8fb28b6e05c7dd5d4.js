Bootstrapper.bindDependencyImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    window.complainToMaster = function(data) {
        var msg = false;
        if (typeof data == typeof "") msg = data;
        if (data.message) msg = data.message;
        if (!msg) return;
        console.warn("%cError detected: " + msg || "See below.", "font-size:large");
        if (msg != data) console.dir(data);
        console.trace()
    }
}, 2631846, [4029119], 492025, [274206]);
Bootstrapper.bindImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions
}, 2505967, 382230);
Bootstrapper.bindDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    if (!window.JDObject) window.JDObject = {};
    var is404 = false;
    if (document.title.match(/(page not found)/gi)) is404 = true;
    var selectQuery = ".info-page-not-found, .info-pagina-non-trovata, .info-pagina-niet-gevonden, .info-siden-blev-ikke-fundet, .info-seite-nicht-gefunden, .info-sidan-hittades-inte, .info-pgina-no-encontrada, .info-pagina-non-trovata";
    if (document.querySelector(selectQuery)) is404 =
        true;
    var a = document.getElementById("infoTitle");
    if (a && a.innerHTML.indexOf("Page not found") > -1) is404 = true;
    if (document.getElementById("fourohfourTitle")) is404 = true;
    if (window.location.pathname.indexOf("search") < 0) {
        var b = document.querySelectorAll("#breads a span");
        if (b && b.length > 0 && b[1].innerHTML.toLowerCase() == "no results") is404 = true;
        var c = document.querySelectorAll("div.not-found");
        if (c && c.length > 0 && JDObject.pageType != "list") is404 = true
    }
    window.JDObject.is404 = is404
}, 3104864, 428948);
Bootstrapper.bindDependencyImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    window.JDObject.assert("JDObject.helpers.JDO.bindOR.sets");
    window.JDObject.helpers.JDObject.bindOR.idCount = 0;
    window.JDObject.helpers.JDObject.bindOR.dependants = {};
    window.JDObject.helpers.JDObject.bindOR.alreadyRun = [];
    JDObject.bindOR = function(bindings, did, fn) {
        if (typeof bindings == typeof "s") bindings = [bindings];
        var item = {
            id: JDObject.helpers.JDObject.bindOR.idCount++,
            deploymentId: did,
            bindings: bindings,
            fn: fn,
            hasRun: false
        };
        JDObject.helpers.JDObject.bindOR.dependants[item.id] = item;
        if (JDObject.helpers.JDObject.bindOR.checkHasRun(bindings)) {
            item.fn();
            item.hasRun = true
        } else
            for (var i = 0; i < bindings.length; i++) {
                var binding = bindings[i];
                if (!JDObject.helpers.JDObject.bindOR.sets[binding]) JDObject.helpers.JDObject.bindOR.sets[binding] = [];
                JDObject.helpers.JDObject.bindOR.sets[binding].push(item.id)
            }
    };
    JDObject.helpers.JDObject.bindOR.checkHasRun = function(bindings) {
        var run = JDObject.helpers.JDObject.bindOR.alreadyRun;
        for (var i = 0; i < bindings.length; i++)
            if (run.indexOf(bindings[i]) > -1) return true;
        return false
    };
    JDObject.runDependants = function(name) {
        var sets = JDObject.helpers.JDObject.bindOR.sets;
        var set = sets[name];
        if (set)
            for (var j = set.length - 1; j >= 0; j--) {
                var dependant = window.JDObject.helpers.JDObject.bindOR.dependants[set[j]];
                console.log(dependant);
                try {
                    if (dependant.hasRun === true) window.complainToMaster("JDObject.bindOR deployment re-run, fix urgently");
                    dependant.fn();
                    dependant.hasRun = true
                } catch (e) {
                    console.log("JDObject.bindOR dependant failure: " +
                        dependant.deploymentId);
                    JDObject.complainToMaster("bindOR dependant failure: " + dependant.deploymentId);
                    continue
                }
                for (var i = 0; i < dependant.bindings.length; i++) {
                    var binding = dependant.bindings[i];
                    if (binding == name) continue;
                    var p = sets[binding].indexOf(set[j]);
                    sets[binding].splice(p, 1)
                }
            }
        JDObject.helpers.JDObject.bindOR.alreadyRun.push(name);
        sets[name] = []
    };
    var inbox = JDObject.bindORInbox;
    if (inbox && inbox.length)
        for (var i = 0; i < inbox.length; i++) JDObject.runDependants(inbox[i])
}, 1714705, [4029119, 2505967], 386782, [274206, 382230]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    JDObject.assert("JDO.H.e");
    JDObject.helpers.events.queue = [];
    JDObject.helpers.events.historical = [];
    var tagTypes = ["airship", "criteo", "FB", "GA", "GA4", "GoogleAdWords", "GoogleConsent", "google", "googlegtag", "hero", "JDObject", "kafka", "mobon", "newRelic", "pinterest", "redEye", "rtbHouse", "reporting", "sessionCam", "snapchat", "tiktok", "twitter", "trueFit"];
    if (JDObject.fasciaCode == "GO") tagTypes.push("GTM");
    JDObject.helpers.events.tagTypes = tagTypes;
    var attempt = function(path, args, isQueue) {
        try {
            var items = path.split(".");
            var current = window.JDObject;
            var events = {};
            for (var i = 0; i < items.length; i++)
                if (items[i] == "h") current = current.helpers;
                else if (items[i] == "e" || items[i] == "events") {
                current = current.events;
                events = current
            } else current = current[items[i]];
            var initData = false;
            if (events.init) {
                initData = events.init(args);
                args.initData = initData
            }
            var result = current(args);
            if (events.finalise) events.finalise(result);
            return true
        } catch (e) {
            if (!isQueue) JDObject.helpers.events.queue.push([path,
                args
            ]);
            return false
        }
    };
    JDObject.runEventQueue = function() {
        var items = JDObject.helpers.events.queue;
        var itemsOut = [];
        for (var i = 0; i < items.length; i++) {
            var flag = attempt(items[i][0], items[i][1], true);
            if (!flag) itemsOut.push(items[i])
        }
        JDObject.helpers.events.queue = itemsOut
    };
    JDObject.eventSubmit = function(type, data, isUnload) {
        if (JDObject.isDebug) try {
            JDObject.debug('JDObject.eventSubmit detected:\n\tName:\t %c"' + type + '"%c', "color: #f68b66", "color: unset", "\n\tData:\t ", data, "\n\tIsUnload: ", !!isUnload);
            const store =
                "JDORecentEvents";
            const events = JSON.parse(localStorage.getItem(store) || "[]");
            events.unshift({
                type: type,
                data: data
            });
            if (events.length > 20) events.pop();
            localStorage.setItem(store, JSON.stringify(events));
            JDObject.debug("JDO Events:\n\t", events)
        } catch (e) {}
        if (data === undefined) data = {};
        if (!data.obj) data.obj = Bootstrapper.dataManager.getData();
        if (!data.page) data.page = window.location.pathname;
        if (!data.eventId) data.eventId = JDObject.get.Sha256(navigator.userAgent + Math.random() + (new Date).toString());
        if (isUnload) try {
            data = {
                data: data
            };
            data.JDOSubType = type;
            data.pathname = window.location.pathname;
            var json = JSON.stringify(data);
            window.localStorage.setItem("JDObjectEventSumbitData", json);
            return true
        } catch (e) {}
        var fn = {
            "signup": window.location.pathname.indexOf("myaccount") > -1 ? "registerUser" : "newsletterSignup",
            "email_signup": "newsletterSignup",
            "login": "logIn",
            "billing-details": "CheckoutEmailPassed",
            "quickview": "quickView",
            "register": "registerUser",
            "quickviewAddToBasket": "quickViewAddToBasket"
        }[type] || type;
        var output;
        if (JDObject.helpers.events[fn]) output =
            JDObject.helpers.events[fn](data);
        var tagTypes = JDObject.helpers.events.tagTypes;
        for (var i = 0; i < tagTypes.length; i++) attempt("h." + tagTypes[i] + ".events." + fn, data);
        JDObject.helpers.events.historical.push([type, data])
    };
    JDObject.runEventsForTag = function(name) {
        var evs = JDObject.helpers.events.historical;
        for (var i = 0; i < evs.length; i++) attempt("h." + name + ".events." + evs[i][0], evs[i][1])
    };
    JDObject.helpers.events.registerUser = function(data) {
        attempt("h.manaQin.registerUser", data)
    };
    JDObject.helpers.events.newsletterSignup =
        function(data) {
            if (typeof data == typeof "st") data = {
                email: data
            };
            attempt("h.redEye.newsletterSignup", data)
        };
    JDObject.helpers.events.CheckoutEmailPassed = function(data) {
        if (typeof data == typeof "st") data = {
            email: data
        };
        attempt("h.redEye.CheckoutEmailPassed", data);
        var radio = document.querySelector("#payment_methods_fieldset .checkout_label_radio input.radio:checked");
        radio = radio.parentNode || {};
        radio = radio.querySelector("span") || {};
        radio = radio.innerText;
        if (radio) {
            data.type = radio;
            data.paymentType = radio
        }
        if ("BL,ML,UO,GO".split(",").indexOf(JDObject.fasciaParent) >
            -1) attempt("h.GA.checkout.startPayment", data)
    };
    JDObject.helpers.events.registeredCheckout = function(data) {
        window.JDObject.helpers.events.CheckoutEmailPassed(data)
    };
    var json = window.localStorage.getItem("JDObjectEventSumbitData");
    if (json) {
        data = JSON.parse(json);
        type = data.JDOSubType;
        JDObject.eventSubmit(type, data.data);
        window.localStorage.removeItem("JDObjectEventSumbitData")
    }
}, 3996520, [4029119, 2853374], 418795, [274206, 597950]);
Bootstrapper.bindDependencyDOMLoaded(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var ic = 1;
    var runMenMeCode = function() {
        if (window.location.href.indexOf("checkout.basechildrenswear.com/confirm") != -1 && typeof dataObject != "undefined" && dataObject.orderID) {
            var obj = dataObject;
            var mmpc = "mm2e11514d";
            var mmu1 = "https://";
            var mmu2 = "tag.mention-me.com/api/v2/referreroffer/" + mmpc;
            var mmDiv = document.createElement("div");
            mmDiv.id = "mmWrapper";
            var mmSel = document.querySelector("#root");
            if (mmSel) {
                console.log("dropNav element found");
                mmSel.parentNode.insertBefore(mmDiv, mmSel);
                var mLoc = "locale\x3den_GB";
                var mSituation = "situation\x3dpostpurchase";
                var mOrderNum = "order_number\x3d" + obj.orderId;
                var mmsc = document.createElement("script");
                mmsc.type = "text/javascript";
                mmsc.async = true;
                mmsc.src = mmu1 + mmu2 + "?" + mSituation + "\x26" + mLoc + "\x26" + mOrderNum;
                if (obj.custName) mmsc.src = mmsc.src + "\x26" + "fullname\x3d" + encodeURIComponent(obj.custName);
                if (obj.custEmail) mmsc.src = mmsc.src + "\x26" + "email\x3d" + encodeURIComponent(obj.custEmail);
                if (obj.orderTotal) mmsc.src = mmsc.src + "\x26" + "order_subtotal\x3d" + obj.orderTotal;
                if (JDObject.orderCurrency || JDObject.currency || dataObject.currency) mmsc.src = mmsc.src + "\x26" + "order_currency\x3d" + (obj.orderCurrency || JDObject.currency || dataObject.currency);
                document.body.appendChild(mmsc)
            }
        } else setTimeout(function() {
            if (ic <= 20) {
                ic++;
                runMenMeCode()
            }
        }, 500)
    };
    runMenMeCode()
}, 3708509, [4029119, 3455279], 708666, [274206, 542879]);
Bootstrapper.bindImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    if (!window.JDObject) window.JDObject = {};
    if (!JDObject.get) JDObject.get = {};
    window.JDObject.get.productURL = function(plu) {
        var siteFlair = "";
        if (JDObject.fasciaCode.length > 2) {
            siteFlair = {
                JD: "_jdsports",
                SZ: "_size",
                AI: "_activinstinct",
                FS: "_activinstinct",
                MS: "_activinstinct"
            }[JDObject.fasciaParent];
            if (siteFlair) siteFlair += JDObject.fasciaCode.slice(2).toLowerCase()
        } else siteFlair = {
                SD: "_supplyanddemand"
            }[JDObject.fasciaCode] ||
            "";
        if ("JDGL".split(",").indexOf(JDObject.fasciaCode) > -1) siteFlair = "";
        siteFlair = siteFlair || "";
        var stripProtocol = function(url) {
            return url
        };
        if (document.getElementById("main")) return window.location.protocol + "//" + window.location.hostname + "/product/name/" + plu + siteFlair;
        if (window.location.pathname.indexOf(plu) > -1 && window.location.pathname.indexOf("search") < 0) return window.location.href;
        var items = document.getElementsByClassName("basket_item");
        if (!items.length) items = document.getElementsByClassName("basket-item");
        for (var i = 0; i < items.length; i++) {
            var as = items[i].getElementsByTagName("A");
            for (var j = 0; j < as.length; j++) {
                var a = as[j];
                if (a.pathname) {
                    if (a.pathname.indexOf(plu) > -1) return stripProtocol(a.href)
                } else if (a.href.indexOf(plu) > -1) return stripProtocol(a.href)
            }
        }
        var items = document.getElementsByTagName("a");
        for (var i = 0; i < items.length; i++)
            if (items[i].href.indexOf(plu) > -1) return stripProtocol(items[i].href);
        return ""
    }
}, 3340719, 432622);
Bootstrapper.bindDependencyImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var id = {
        JD: "982809095",
        JDAU: "979933417",
        JDGL: "982809095",
        SZ: "688445577"
    }[JDObject.fasciaCode];

    function ensureConsentDefaultsSet() {
        return new Promise(function(resolve) {
            (function waitForConsentDefaults() {
                var _a = JDObject.helpers.GoogleConsent;
                if (_a === null || _a === void 0 ? void 0 : _a.ConsentDefaultSet) return resolve();
                setTimeout(waitForConsentDefaults, 30)
            })()
        })
    }
    ensureConsentDefaultsSet().then(() => {
        if (id) {
            var pageType = JDObject.pageType;
            var obj = Bootstrapper.dataManager.getData();
            var sendPurchaseEvent = function(id, confirmPageId, orderTotal, orderId) {
                gtag("event", "conversion", {
                    "send_to": "AW-" + id + "/" + confirmPageId,
                    "value": orderTotal,
                    "transaction_id": orderId,
                    "currency": "GBP"
                })
            };
            var sendPageGaEvent = function(action, id, label) {
                gtag("event", action, {
                    "send_to": "AW-" + id + "/" + label
                })
            };
            var convLabel = {
                JD: {
                    "list": "6J6TCMf6quEBEIf00dQD###ey7SCKTn2KQDEIf00dQD",
                    "product": "4PI0CNDRj-EBEIf00dQD###uXZRCIr-n6QDEIf00dQD"
                },
                JDAU: {
                    "list": "HSvLCJGQ7PsCEOmxotMD",
                    "product": "BteyCLfd6vsCEOmxotMD"
                },
                JDGL: {
                    "list": "ey7SCKTn2KQDEIf00dQD",
                    "product": "uXZRCIr-n6QDEIf00dQD",
                    "confirmation": ""
                }
            }[JDObject.fasciaCode][pageType];
            var confirmPageId = {
                JDGL: "CWEPCO-2-6EDEIf00dQD",
                JD: "CWEPCO-2-6EDEIf00dQD###CWEPCO-2-6EDEIf00dQD",
                SZ: "Z6HfCOyF4qYDEImxo8gC"
            }[JDObject.fasciaCode];
            if (!convLabel) var convLabel = {
                JD: "98PBCOD4p-EBEIf00dQD###M7AACM6-n6QDEIf00dQD",
                JDAU: "GgOhCNCi7PsCEOmxotMD",
                JDGL: "M7AACM6-n6QDEIf00dQD"
            }[JDObject.fasciaCode];
            var atbLabel = {
                JD: "-3a2CNPAm-EBEIf00dQD###RI13COfIl6MDEIf00dQD",
                JDAU: "AyW7CLPmwvsCEOmxotMD",
                JDGL: "RI13COfIl6MDEIf00dQD"
            }[JDObject.fasciaCode] || "";
            Bootstrapper.insertScript("https://www.googletagmanager.com/gtag/js?id\x3dAW-" + id);
            window.dataLayer = window.dataLayer || [];
            var gtag = function() {
                dataLayer.push(arguments)
            };
            gtag("js", new Date);
            gtag("config", "AW-" + id);
            if (pageType == "list" && convLabel) {
                let spconvLabel = convLabel.split("###");
                if (spconvLabel.length == 2) {
                    sendPageGaEvent("Page View", id, spconvLabel[0]);
                    sendPageGaEvent("conversion",
                        id, spconvLabel[1])
                } else sendPageGaEvent("Page View", id, convLabel)
            } else if (pageType == "product" && convLabel) {
                let spconvLabel = convLabel.split("###");
                if (spconvLabel.length == 2) {
                    sendPageGaEvent("Page View", id, spconvLabel[0]);
                    sendPageGaEvent("conversion", id, spconvLabel[1])
                } else sendPageGaEvent("Page View", id, convLabel);
                document.querySelector("body").addEventListener("click", function(event) {
                    var abbId = event.target.id;
                    if (abbId && abbId == "addToBasket") {
                        var skuValue = document.querySelector(".activeOptionInput");
                        if (skuValue && atbLabel) {
                            let spconvLabel = atbLabel.split("###");
                            if (spconvLabel.length == 2) {
                                sendPageGaEvent("click", id, spconvLabel[0]);
                                sendPageGaEvent("conversion", id, spconvLabel[1])
                            } else sendPageGaEvent("click", id, atbLabel)
                        }
                    }
                })
            } else if (obj.orderId && confirmPageId) {
                var purchasePage = true;
                if (JDObject.fasciaCode == "SZ" && obj.brand.toLowerCase().indexOf("nike") == -1) purchasePage = false;
                if (purchasePage) {
                    let spconfirmPageId = confirmPageId.split("###");
                    if (spconfirmPageId.length == 2) {
                        sendPurchaseEvent(id, spconfirmPageId[0],
                            obj.orderTotal, obj.orderId);
                        sendPurchaseEvent(id, spconfirmPageId[1], obj.orderTotal, obj.orderId)
                    } else sendPurchaseEvent(id, confirmPageId, obj.orderTotal, obj.orderId)
                }
            } else {
                let spconvLabel = convLabel.split("###");
                if (spconvLabel.length == 2) {
                    sendPageGaEvent("Page View", id, spconvLabel[0]);
                    sendPageGaEvent("conversion", id, spconvLabel[1])
                } else sendPageGaEvent("Page View", id, convLabel)
            }
        }
    })
}, 4020968, [3455309], 662878, [542878]);
Bootstrapper.bindDependencyImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var domain = location.hostname.replace(/^(ww[w2]|m(obile)?|t(ablet)?|c(heckout)?)\./, "");
    if (window.location.search.indexOf("utm_source")) {
        var sarr = window.location.search.slice(1).split("\x26");
        for (var i = 0; i < sarr.length; i++) {
            if (sarr[i].indexOf("utm_source") < 0) continue;
            var utm = sarr[i].split("\x3d")[1];
            localStorage.setItem("JDOUtmValue", utm.toLowerCase());
            localStorage.setItem("JDOUtmValueDate",
                (new Date).valueOf() + 30 * 24 * 60 * 60 * 1E3);
            JDObject.cookie.set("jdo_utm_source", utm.toLowerCase(), 30, domain)
        }
    }
}, 3671586, [3655148], 422926, [681736]);
Bootstrapper.bindImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    Bootstrapper.registerDataDefinition(function() {
        Bootstrapper.data.define({
            extract: function() {
                return window.testing
            },
            transform: function(val) {
                return val ? val : ""
            },
            load: "page",
            trigger: Bootstrapper.data.immediateTrigger,
            dataDefName: "IdTest",
            collection: "Site Data",
            source: "Manage",
            priv: "false"
        }, {
            id: "48049"
        })
    }, 48049)
}, -1, -1);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var events = JDObject.assert("JDObject.helpers.GA.events");
    var beacon = {
        transport: "beacon"
    };
    var nonInteraction = {
        nonInteraction: true
    };
    events.promotionClick = function(data) {
        JDObject.helpers.promotions.click.call(data.a || data.item)
    };
    events.popupError = function(data) {
        ga("send", "event", "PopupErrorMessage", window.location.pathname, data.message)
    };
    events.newsletterSignup = function(data) {
        ga("send",
            "event", "NewsletterSignup", window.location.pathname)
    };
    events.trackOrder = function(data) {
        ga("send", "event", "OrderTracking", window.location.pathname)
    };
    events.checkoutStepClick = function(data) {
        ga("send", "event", "CheckoutStepClick", data.name, window.location.pathname)
    };
    events.addToWishlist = function(data) {
        ga("send", "event", "AddToWishlist", data.page)
    };
    events.addToWishlistClick = function(data) {
        ga("send", "event", "Product", "AddToWishlistClick", data.obj.plu)
    };
    events.reviewChangeClick = function(data) {
        ga("send", "event",
            "click", "ReviewChangeClick", window.location.pathname)
    };
    events.quickViewClick = function(data) {
        ga("send", "event", "click", "QuickView", window.location.pathname);
        if (data.plu) ga("ec:addProduct", {
            "id": data.plu
        });
        else JDObject.errors.list.push("quickViewClick hook not populating plu");
        ga("ec:setAction", "detail");
        ga("send", "pageview", "/product/quickview")
    };
    events.productListClickLF = function(data) {
        if (data && data.beacon) {
            console.log("product clicked in plp");
            var prdData = {
                "id": data.plu
            };
            if (data.position) prdData.position =
                data.position;
            ga("ec:addProduct", prdData);
            ga("ec:setAction", "click", {
                list: data.list || window.location.pathname
            });
            ga("send", "event", {
                eventCategory: "click",
                eventAction: "productList",
                eventLabel: data.plu,
                transport: "beacon"
            })
        } else {
            data.beacon = true;
            if (!data.list) data.list = window.location.pathname;
            JDObject.eventSubmit("productListClickLF", data, true)
        }
    };
    events.quickViewAddToBasket = function(data) {
        if (data.plu) ga("ec:addProduct", {
            "id": data.plu
        });
        ga("ec:setAction", "add");
        ga("send", "event", "UX", "click", "quickview add to basket")
    };
    events.productClick = function(data) {
        ga("ec:addProduct", {
            id: data.plu
        });
        ga("ec:setAction", "click", {
            list: data.list
        });
        ga("send", "event", "click", data.type, data.plu)
    };
    events.ratingClick = function(data) {
        if (data.page) ga("send", "event", "click", "RatingClick", data.page)
    };
    events.orientationChange = function(data) {
        ga("send", "event", "UX", "OrientationChange", data.orientation)
    };
    events.quantityUpdate = function(data) {
        ga("send", "event", "input", "quantityUpdate", data.quantity)
    };
    events.logIn = function(data) {
        var isCheckout = window.location.pathname.indexOf("checkout") >
            -1;
        var type = isCheckout ? "checkout" : "login page";
        ga("send", "event", "UX", "login", type, {
            transport: "beacon",
            dimension20: type
        })
    };
    events.registerUser = function(data) {
        ga("send", "event", "UX", "login", "register", {
            transport: "beacon",
            dimension20: "register"
        })
    };
    events.guestCheckout = function(data) {
        ga("send", "event", "UX", "login", "guest checkout", {
            transport: "beacon",
            dimension20: "guest checkout"
        })
    };
    events.customerDataLoaded = function(data) {
        ga("set", "userId", data.hash);
        ga("send", "event", "data", "internal", "customerDataLoaded",
            nonInteraction)
    };
    events.paymentMethodClick = function(data) {
        ga("set", "dimension18", data.type);
        ga("set", "dimension19", data.type);
        ga("ec:setAction", "checkout", {
            "step": 4,
            "option": data.type
        });
        ga("send", "pageview", "/checkout/payment/" + data.type, {
            transport: "beacon"
        });
        ga("send", "event", "click", "PaymentMethod", data.type, {
            transport: "beacon"
        })
    };
    events.taggstarBalloon = function(data) {
        var text = data.text.replace(/[0-9]+/g, "n");
        var pageType = data.page || JDObject.pageType;
        var page = pageType == "list" ? "PLP" : pageType == "product" ?
            "PDP" : pageType == "basket" ? "Basket" : pageType == "cart" ? "Basket" : "unknown";
        if (page == "PLP") return;
        var type = "V" + data.version + "-" + data.type + "-" + text;
        ga("send", "event", "Taggstar", page, type, {
            nonInteraction: true
        })
    };
    events.search = {
        search: function(data) {
            ga("send", "event", "search", "submit", data.value)
        },
        recent: function(data) {
            ga("send", "event", "click", "search.recent", data.value)
        },
        suggestedProduct: function(data) {
            ga("send", "event", "click", "search.suggested-product", data.value)
        },
        suggestedTerm: function(data) {
            ga("send",
                "event", "click", "search.suggested-term", data.value)
        },
        trending: function(data) {
            ga("send", "event", "click", "search.trending", data.value)
        },
        noResults: function(data) {
            ga("send", "event", "UX", "productList", "no products found")
        }
    };
    events.product = {
        gallery: {
            select: function(data) {
                ga("send", "event", "Product", "gallery.select", data.shot)
            },
            playVideo: function(data) {
                ga("send", "event", "Product", "gallery.video", data.plu)
            },
            playSpin: function(data) {
                ga("send", "event", "Product", "gallery.360", data.plu)
            },
            zoom: function(data) {
                ga("send",
                    "event", "Product", "gallery.zoom", data.plu)
            }
        },
        outOfStock: function(data) {
            ga("send", "event", "Product", "out-of-stock", data.plu, nonInteraction)
        },
        stockBanner: function(data) {
            ga("send", "event", "Product", "OOS Banner", data.type, beacon)
        },
        infoTabsClick: function(data) {
            ga("send", "event", "Product", data.action, data.obj.plu)
        },
        uspBannerClick: function(data) {
            ga("send", "event", "Product", "USP " + data.position + " clicked", data.type)
        },
        notifyMe: function(data) {
            ga("send", "event", "Product", "Notify Me", data.prdocutsku)
        },
        storeFinder: {
            view: function(data) {
                ga("send",
                    "event", "Store Stock", "Find in Store Click", data.obj.plu)
            },
            findStore: function(data) {
                ga("send", "event", "Store Stock", data.type, data.label)
            },
            call: function(data) {
                ga("send", "event", "Store Stock", "Call", data.label)
            },
            getDirections: function(data) {
                ga("send", "event", "Store Stock", "Get Directions", data.label)
            }
        },
        shopTheLook: function(data) {
            ga("send", "event", "Product", data.action, data.label)
        }
    };
    events.reviews = {
        read: function(data) {
            ga("send", "event", "Product", "Review View", data.obj.plu)
        },
        write: function(data) {
            ga("send",
                "event", "Product", "Review Write", data.obj.plu)
        }
    };
    events.productList = {
        sort: function(data) {
            ga("send", "event", "List", "Sort clicks", data.label)
        },
        refine: function(data) {
            ga("send", "event", "List", "Refine clicks", data.type + "-" + data.value)
        },
        refineOpenClear: function(data) {
            ga("send", "event", "List", "Refine clicks", data)
        },
        showLess: function(data) {
            ga("send", "event", "click", "showLess", window.location.pathname)
        },
        showMore: function(data) {
            ga("send", "event", "click", "showMore", window.location.pathname)
        },
        pagination: function(data) {
            ga("send",
                "event", "click", "pagination", data.page)
        }
    };
    events.scrollLoadMore = function(data) {
        ga("send", "event", "UX", "ScrollLoadMore" + data.count, window.location.pathname)
    };
    events.scrollToTopClick = function(data) {
        ga("send", "event", "click", "scrollToTop", window.location.pathname)
    };
    events.checkout = {
        expressCollectClick: function(data) {
            ga("send", "event", "click", "ExpressCollect")
        },
        delivery: {
            setCountry: function(data) {
                ga("set", "dimension24", data.country)
            },
            selectCountry: function(data) {
                JDObject.helpers.GA.events.checkout.delivery.setCountry(data);
                ga("send", "event", "click", "DeliveryCountry", data.country)
            },
            selectDeliveryMethod: function(data) {
                ga("set", "dimension25", data.type);
                ga("send", "event", "click", "DeliveryType", data.type);
                ga("send", "event", "Checkout", "Delivery Type Selected", data.type)
            },
            findAddress: function(data) {
                ga("set", "dimension11", data.type);
                ga("send", "event", "Checkout", "Find Address", data.type)
            },
            pcaAddressEntered: function(data) {
                ga("set", "dimension27", data.type);
                ga("set", "dimension11", "PCA Predict");
                ga("send", "event", "Checkout", "PCA Predict Selection",
                    data.type)
            },
            collectionSelect: function(data) {
                ga("set", "dimension28", data.store);
                ga("set", "dimension30", data.searchType);
                ga("send", "event", "Checkout", "Collection Selection", data.store)
            },
            continueSecurely: function(data) {
                ga("set", "dimension31", data.billChecked);
                ga("set", "dimension32", data.notYouChecked);
                ga("set", "dimension33", data.numErrors);
                ga("set", "dimension34", data.errorDesc);
                ga("send", "event", "Checkout", "Continue Securely", data.errorDesc)
            }
        },
        paymentType: function(data) {
            ga("set", "dimension18", data);
            ga("ec:setAction", "checkout", {
                "step": 3,
                "option": data
            });
            ga("send", "pageview", "/checkout/payment/" + data, {
                transport: "beacon"
            });
            ga("send", "event", "Checkout", "PaymentMethod", data)
        },
        checkoutType: function(data) {
            ga("set", "dimension37", data.type);
            ga("send", "event", "Checkout", "Checkout Type Selected", data.type)
        },
        collectionMethod: function(data) {
            ga("set", "dimension24", data.type);
            ga("send", "event", "Checkout", "Collection method selected", data.type)
        },
        unavailableProduct: function(data) {
            ga("send", "event", "Checkout",
                "Oh Blimey Delivery Unavailable", data)
        },
        findStoresSearch: function(data) {
            ga("send", "event", "Checkout", "Find Stores \u2013 " + data.status, data.stores)
        },
        storeSelected: function(data) {
            ga("set", "dimension25", data.deliveryOption);
            ga("send", "event", "Checkout", "Store Selected", data.deliveryOption)
        },
        expressClick: function(data) {
            ga("send", "event", "Cart", "Express Payment CTA", data.type)
        }
    };
    events.voiceSearchSubmit = function(data) {
        var term = window.location.pathname.match(/^(?:\/s(?:earch\/|:))(.*)(?:\/)/i);
        if (!term) term =
            window.location.search.match(/(?:(?:\?|&)search=)((\w|\d|\+)+)/i);
        if (!term) return;
        term = term[1].replace("+", " ");
        ga("send", "event", "site search", "voice", term)
    };
    events.addToBasketSelectSize = function(data) {};
    events.anatwineLearnMore = function(data) {
        if (!data) return;
        ga("send", "event", data.category, "Anatwine learn more", data.label)
    };
    events.mobilePayClick = function(data) {
        ga("send", "event", "click", "mobilePay", data.type, {
            transport: "beacon",
            dimension19: data.type
        })
    };
    events.intPopup = {
        view: function(data) {
            ga("send",
                "event", "Splash Page", "shown", data.userCountry, nonInteraction)
        },
        countrySelection: function(data) {
            ga("send", "event", "Splash Page", "clicked " + data.selected, data.userCountry, nonInteraction)
        },
        close: function(data) {
            ga("send", "event", "Splash Page", "closed", data.userCountry, nonInteraction)
        }
    };
    events.navigation = {
        header: function(data) {
            ga("send", "event", "Header", data.type, data.page, beacon)
        },
        sizeGuideSelectionClick: function(data) {
            ga("send", "event", "Product", "Size Guide Selection", data.linkText)
        },
        sizeGuideButtonClick: function(data) {
            ga("send",
                "event", "Product", "Size Guide Open")
        },
        fitFinderClick: function(data) {
            ga("send", "event", "Product", "Fit Finder", data.plu)
        },
        footer: function(data) {
            ga("send", "event", "Footer", data.text, data.url, beacon)
        }
    };
    var sendBasketUpdate = function(data, ecAction, action) {
        ga("ec:addProduct", {
            id: data.plu,
            name: data.description,
            category: data.category,
            brand: data.brand,
            price: data.unitPrice,
            quantity: data.quantity,
            dimension35: data.sale
        });
        ga("ec:setAction", ecAction);
        var inStock = data.inStock === true || data.inStock === "true" ? "in stock" :
            data.inStock === false || data.inStock === "false" ? "out of stock" : "stock unknown";
        ga("send", "event", "basket", action, beacon)
    };
    events.basket = {
        update: {
            addOne: function(data) {
                sendBasketUpdate(data, "add", "item added")
            },
            removeOne: function(data) {
                sendBasketUpdate(data, "remove", "item removed - reduce")
            },
            removeItem: function(data) {
                sendBasketUpdate(data, "remove", "item removed - remove")
            }
        },
        beginCheckout: function(data) {
            ga("send", "event", "basket", "Continue Securely", data.label)
        },
        voucher: {
            applyCode: function(data) {
                ga("send",
                    "event", "basket", `Promo Code ${data.Success?"Success":"Failure"}`, data.Code)
            },
            apply: function(data) {
                ga("send", "event", "basket", "Promo Code Success", data)
            },
            applyFailed: function(data) {
                ga("send", "event", "basket", "Promo Code Failure", data)
            }
        },
        membershipCard: function(data) {
            ga("send", "event", "basket", "submit membership " + (data.success ? "success" : "failure"), data.cardNumber)
        }
    };
    events.error = function(data) {
        ga("send", "event", "error", data.type, data.message, nonInteraction)
    };
    window.JDObject.runEventQueue()
}, 3961811, [3952459, 2505967, 3996520], 424075, [268459, 382230, 418795]);
Bootstrapper.bindDependencyImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    if (JDObject.is404) JDObject.eventSubmit("pageView.pageNotFound", {})
}, 3944178, [3104864], 754671, [428948]);
Bootstrapper.bindDependencyImmediate(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    const cookieName = "ckgRM";
    const otherCookie = JDObject.cookie.get("_gali") || "";
    const gaCookieRemove = JDObject.cookie.get(cookieName);
    const gaCookieValues = document.cookie.split(";").filter((cookie) => cookie.includes("_ga")).map((gaCookie) => gaCookie.split("\x3d")[0]);
    if (!gaCookieRemove || otherCookie.includes("reject")) {
        const domain = window.location.hostname.replace(/^m|www/,
            "");
        gaCookieValues.forEach((name) => {
            const expires = (new Date).toUTCString();
            let value = `${name}=null; expires=${expires};`;
            console.log(value);
            document.cookie = value;
            value += ` domain=${domain};`;
            document.cookie = value
        });
        JDObject.cookie.set(cookieName, "true", 120, domain)
    }
}, 3952960, [3655148], 755890, [681736]);