Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var excludeFascias = ["NY", "FR", "BL", "ML", "UO"];
    if (excludeFascias.indexOf(JDObject.fasciaCode) == -1) {
        JDObject.assert("JDO.H.redEye");
        var fasciaParent = JDObject.fasciaParent;
        var domain = {
            FP: "footpatrol.com",
            JD: "jdsports.co.uk",
            JDGL: "jdsports.com",
            SZ: "size.co.uk",
            JDAU: "jd-sports.com.au",
            JDFR: "jdsports.fr",
            JDDE: "jdsports.de",
            JDIE: "jdsports.ie",
            JDKR: "jdsports.co.kr",
            JDMY: "jdsports.co.kr",
            JDNZ: "jd-sports.com.au",
            JDSG: "jdsports.co.kr",
            JDTH: "jdsports.co.kr",
            XX: "jdsandbox.co.uk"
        }[JDObject.fasciaCode] || {
            AI: "activinstinct.com",
            FS: "activinstinct.com",
            MS: "activinstinct.com",
            FP: "footpatrol.fr",
            JD: "jdsports.nl",
            SZ: "sizeofficial.de",
            FDNI: "scotlandfootballshop.co.uk",
            FDWA: "scotlandfootballshop.co.uk"
        }[fasciaParent] || false;
        var subdomain = {
            FP: "redeye"
        }[JDObject.fasciaCode] || "reporting";
        if (JDObject.fasciaCode == "HS") domain = false;
        if (!domain) {
            domain = window.location.hostname.split(".");
            var hasSub = domain[0] ==
                "www" || domain[0] == "m";
            domain = domain.slice(hasSub ? 1 : 0).join(".")
        }
        JDObject.helpers.redEye.domain = domain;
        Bootstrapper.insertScript("//" + subdomain + "." + domain + "/cgi/wcjs");
        JDObject.helpers.redEye.init = function(path, domain) {
            var fewFascias = ["XX"];
            if (!domain) domain = JDObject.helpers.redEye.domain;
            var url = "//" + subdomain + "." + domain + "/cgi-bin/rr/blank.gif";
            url += "?nourl\x3d";
            var fc = JDObject.fasciaCode;
            var site = {
                MS: "AI"
            }[fc] || fc;
            if (fc == "GO") site = JDObject.siteCode == "GO" ? "GODesk" : "GOMob";
            var pagename = path || window.location.pathname;
            url += window.encodeURIComponent(pagename);
            url += "\x26site\x3d" + site;
            url += "\x26currency\x3d" + JDObject.currency;
            return url
        };
        JDObject.helpers.redEye.finalise = function(url) {
            if (!JDObject.helpers.redEye.forceMobileUrl) {
                var host = window.location.hostname;
                var url2 = host.replace(/^m\./, "www.");
                var diff;
                for (var i = 0; i < 100; i++) {
                    diff = url;
                    url = url.replace(host, url2);
                    if (url == diff) break
                }
            }
            var email = url.match(/(?:e-?mail=)([^&]+)/i);
            if (email) {
                email = decodeURIComponent(email[1]);
                var hash = JDObject.get.Sha256(email.toLowerCase()).slice(0,
                    32);
                url += "\x26id_hash\x3d" + hash;
                document.cookie = "user_hash_id\x3d" + hash + "; max-age\x3d" + 60 * 60 * 24 * 356 + ";path\x3d/";
                window.localStorage.setItem("userHashId", hash)
            }
            var ev = url.match(/\?nourl=([^&]+)/);
            if (ev) ev = ev[1];
            if (ev) {
                var time = ev.slice(0, 20).replace(/\-/g, "_") + "_time\x3d" + encodeURIComponent((new Date).toISOString());
                url += "\x26" + time
            }
            JDObject.helpers.redEye.pixel = Bootstrapper.imageRequest(url)
        };
        JDObject.helpers.redEye.cleanName = function(input) {
            var output = input.replace(/&#0*39;/g, "'").replace(/&#0*38;/g,
                "%26").replace(/(&#\d+;)/g, "").replace("\u2019", "'");
            output = output.match(/([\w'+\-\s])+/gi) || [output];
            output = output.join("");
            output = output.replace(/ amp /g, " ");
            return output
        };
        JDObject.helpers.redEye.rmfurl = function(input) {
            var output = input.replace(/(https?:\/\/)|(\/\/)/g, "");
            return output
        };
        var btn = document.getElementById("continueSecurelyButton");
        if (btn) btn.addEventListener("click", function() {
            var inp = document.getElementById("phone");
            if (inp) {
                var val = inp.value;
                val = val.match(/\d+/g).join("");
                val = (+val).toString(2);
                if (val) localStorage.setItem("JDOPN", val)
            }
        });
        JDObject.helpers.redEye.useOriginalPlu = ["AIAU", "FSAU", "AK", "PY", "OI"].indexOf(JDObject.fasciaCode) > -1 || ["FP"].includes(JDObject.fasciaParent);
        JDObject.helpers.redEye.forceMobileUrl = ["BLM", "MLM", "UOM"].indexOf(JDObject.siteCode) > -1
    }
}, 3938569, [4029119, 3455279, 2853374], 411899, [274206, 542879, 597950]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    JDObject.assert("JDO.H.promotions");
    var promos = document.querySelectorAll("#nav li a[class\x3d'ga-ip']");
    JDObject.helpers.promotions.click = function() {
        var prom = this;
        var posi, name, gaid, crea;
        try {
            gaid = prom.dataset.ipId || prom.pathname;
            name = prom.dataset.ipName || prom.textContent.trim();
            posi = prom.dataset.ipPosition
        } catch (e) {
            gaid = prom.getAttribute("data-ip-id") || prom.pathname;
            name = prom.getAttribute("data-ip-name") || prom.textContent.trim();
            posi = prom.getAttribute("data-ip-position")
        }
        crea = window.location.pathname;
        if (crea === "" || crea == "/") crea = "/home";
        if (gaid === "" || gaid == "/") gaid = "/home";
        ga("ec:addPromo", {
            "id": gaid,
            "name": name,
            "creative": crea,
            "position": posi
        });
        ga("ec:setAction", "promo_click");
        ga("send", "event", "Internal Promotions", "click", name, {
            transport: "beacon"
        })
    };
    var new_el;
    for (var i = 0; i < promos.length; i++) {
        new_el = promos[i].outerHTML;
        promos[i].parentNode.innerHTML = new_el
    }
    promos =
        document.querySelectorAll("#nav li a[class\x3d'ga-ip']");
    for (var i = 0; i < promos.length; i++) {
        promos[i].addEventListener("click", JDObject.helpers.promotions.click);
        promos[i].setAttribute("old-ip", "true")
    }
}, 3961817, [3952459], 297470, [268459]);
Bootstrapper.bindDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    JDObject.assert("JDO.H.GA");
    JDObject.helpers.GA.searchStringExemptions = ["q", "search"];
    JDObject.helpers.GA.sendGAPageview = function(gaData) {
        gaData = gaData || {};
        if (typeof gaData == typeof "s") gaData = {
            page: gaData
        };
        var getSanitisedURL = function(input) {
            var blacklist = ["firstName", "lastName", "email", "Email", "orderId", "OrderId", "orderID", "OrderID", "postcode", "newsletterEmail", "phone",
                "password", "confirmPassword", "billingCountry", "billingPostcode", "billingFirstName", "billingLastName", "billingAddress1", "billingAddress2", "billingTown", "billingCounty", "BillingAddress", "shippingPostcode", "shippingCountry", "shippingTown", "shippingAddress1", "shippingAddress2", "shippingCounty"
            ];
            var pathname = window.location.pathname;
            var search = [];
            if (input) {
                var pair = input.split(/\?(.+)?/);
                pathname = pair[0];
                if (pair[1]) search = pair[1].split("\x26")
            } else search = window.location.search.slice(1).split("\x26");
            var allowed = [];
            for (var i = 0; i < search.length; i++) {
                var flag = false;
                if (search.indexOf("@") > -1) continue;
                for (var j = 0; j < blacklist.length; j++)
                    if (search[i].split("\x3d")[0] == blacklist[j]) {
                        flag = true;
                        break
                    }
                if (flag || search[i].match(/.+@.+\..+/g)) continue;
                allowed.push(search[i])
            }
            return [pathname, allowed.join("\x26")]
        };
        var urlFrag = getSanitisedURL(gaData.page);
        var loc = window.location.protocol + "//" + window.location.hostname;
        gaData.page = urlFrag[1] ? urlFrag.join("?") : urlFrag[0];
        gaData.location = loc + (urlFrag[1] ? urlFrag.join("?") :
            urlFrag[0]);
        if (JDObject.get.orientation) gaData.dimension16 = JDObject.get.orientation();
        gaData.dimension17 = JDObject.browser.userAgent;
        var chFlag = false;
        if (window.location.pathname.indexOf("/checkout") > -1) chFlag = true;
        var obj = Bootstrapper.dataManager.getData();
        if (chFlag && obj.items) {
            var items = obj.items;
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                ga("ec:addProduct", {
                    "id": item.plu,
                    "brand": item.brand || "",
                    "name": item.description,
                    "category": item.category || "",
                    "variant": item.sku || item.color,
                    "price": item.unitPrice,
                    "quantity": item.quantity,
                    "dimension35": item.sale
                })
            }
        }
        ga("send", "pageview", gaData)
    }
}, 3279930, 349782);
Bootstrapper.bindDependencyDOMParsed(function() {
        var Bootstrapper = window["Bootstrapper"];
        var ensightenOptions = Bootstrapper.ensightenOptions;
        if (!window.JDObject) window.JDObject = {};
        if (!JDObject.helpers) JDObject.helpers = {};
        if (!JDObject.helpers.GA) JDObject.helpers.GA = {};
        if (!JDObject.helpers.GA.clickActions) JDObject.helpers.GA.clickActions = {};
        JDObject.helpers.GA.clickActions.fn = function(event) {
            var item = this;
            var fnName = item.getAttribute("data-click-fn");
            var clickAction = JDObject.helpers.GA.clickActions[fnName];
            var buttons = clickAction.buttons || [0];
            var href = clickAction.getHref ? clickAction.getHref() : item.href;
            var gaData = clickAction.fn && clickAction.fn(item, event) || {};
            var category = clickAction.eventCategory || "UX";
            var action = clickAction.eventAction || "click";
            var label = clickAction.eventLabel || "default";
            var finalise = clickAction.finalise;
            if (buttons.indexOf(event.button) > -1) {
                var callback = clickAction.callback || function() {
                    document.location = href
                };
                gaData.hitCallback = callback;
                ga("send", "event", category, action, label, gaData);
                setTimeout(callback, clickAction.timeout || 1E3);
                return false
            } else ga("send", "event", category, action, label, gaData);
            if (finalise) finalise()
        };
        JDObject.helpers.GA.clickActions.addClicks = function(action) {
            var fn = JDObject.helpers.GA.clickActions.fn;
            var items = action.getItems();
            if (items.length)
                for (var i = 0; i < items.length; i++) {
                    var item = items[i];
                    item.onclick = fn;
                    item.setAttribute("data-click-fn", action.name)
                } else if (action.cycle) window.setTimeout(function() {
                    JDObject.helpers.GA.clickActions.addClicks(action)
                }, 1E3)
        }
    },
    1278169, [3952459], 364093, [268459]);