Bootstrapper.bindDOMLoaded(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var uid = sessionStorage.JDOSessionId;
    var runRtBHouse = function(ppid) {
        try {
            (function() {
                var prefix = "",
                    hash = "UeaAwqBzS4vDI9lpsnWK",
                    rtbhTags = [];
                rtbhTags.push("pr_" + hash + "_" + ppid);
                rtbhTags.push("pr_" + hash + "_uid_" + uid);
                var key = "__rtbhouse.lid",
                    lid = window.localStorage.getItem(key);
                if (!lid) {
                    lid = "";
                    var pool = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                    for (var i =
                            0; i < 20; i++) lid += pool.charAt(Math.floor(Math.random() * pool.length));
                    window.localStorage.setItem(key, lid)
                }
                rtbhTags.push("pr_" + hash + "_lid_" + lid);
                var ifr = document.createElement("iframe"),
                    sr = encodeURIComponent(document.referrer ? document.referrer : ""),
                    su = encodeURIComponent(document.location.href ? document.location.href : ""),
                    ifrSrc = "https://" + prefix + "creativecdn.com/tags?type\x3diframe",
                    tmstmp = encodeURIComponent("" + Date.now());
                for (var i = 0; i < rtbhTags.length; i++) ifrSrc += "\x26id\x3d" + encodeURIComponent(rtbhTags[i]);
                ifrSrc += "\x26su\x3d" + su + "\x26sr\x3d" + sr + "\x26ts\x3d" + tmstmp;
                ifr.setAttribute("src", ifrSrc);
                ifr.setAttribute("width", "1");
                ifr.setAttribute("height", "1");
                ifr.setAttribute("scrolling", "no");
                ifr.setAttribute("frameBorder", "0");
                ifr.setAttribute("style", "display:none");
                ifr.setAttribute("referrerpolicy", "no-referrer-when-downgrade");
                if (document.body) document.body.appendChild(ifr);
                else window.addEventListener("DOMContentLoaded", function() {
                    document.body.appendChild(ifr)
                })
            })()
        } catch (e) {}
    };
    var obj = Bootstrapper.dataManager.getData();
    var cppn = window.location.pathname;
    if (JDObject.pageType == "globalExPBCC") runRtBHouse("home");
    else if (/\/sale\//i.test(cppn) && JDObject.pageType == "list" && obj.items) runRtBHouse("sales");
    else if ((JDObject.pageType == "list" || JDObject.pageType == "basket") && obj.items && obj.items.length > 0) {
        var cc = 5;
        var pids = [];
        if (obj.items.length <= 5) cc = obj.items.length;
        for (var i = 0; i < cc; i++) pids.push(obj.items[i].plu);
        if (JDObject.pageType == "basket") runRtBHouse("basketstatus_" + pids.join());
        else runRtBHouse("listing_" + pids.join())
    } else if (JDObject.pageType ==
        "product" && obj.plu) {
        runRtBHouse("offer_" + obj.plu);
        document.querySelector("body").addEventListener("click", function(event) {
            var abbId = event.target;
            if (abbId && abbId.parentNode && abbId.parentNode.id) var sizeDivId = abbId.parentNode.id;
            var skuValue = document.querySelector(".activeOptionInput");
            if (sizeDivId == "productSizeStock" && skuValue) runRtBHouse("size_" + skuValue.getAttribute("data-sku"));
            if (abbId && abbId.id && abbId.id == "addToBasket")
                if (skuValue) runRtBHouse("basketadd_" + obj.plu)
        })
    } else if (/\/wishlists\//i.test(cppn)) {
        wItems =
            document.querySelectorAll("#wishlistItems li.listItem");
        var wurl = baseUrl;
        var wpList = [];
        for (var i = 0; i < wItems.length; i++) {
            var x = i + 1;
            var surl = "";
            var pluSku = wItems[i].querySelector("a[data-sku]").getAttribute("data-sku");
            var pluSkuExplode = pluSku.split(".");
            var plu = pluSkuExplode[0];
            var sku = pluSkuExplode[1];
            wpList.push(plu)
        }
        runRtBHouse("wishlist_" + wpList.join())
    } else if (obj.orderTotal && obj.orderId) {
        var pids = [];
        for (var i = 0; i < obj.items.length; i++) {
            var pluid = obj.items[i].plu.split("_")[0];
            pids.push(pluid)
        }
        runRtBHouse("orderstatus2_" +
            obj.orderTotal + "_" + obj.orderId + "_" + pids.join())
    } else if (/\/checkout\//i.test(cppn)) runRtBHouse("startorder")
}, 3697863, 709305);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var allowed = true;
    var id = JDObject.helpers.snapchat.id;
    if (allowed && id) {
        var tr = window.snaptr = function() {
            tr.handleRequest ? tr.handleRequest.apply(tr, arguments) : tr.queue.push(arguments)
        };
        tr.queue = [];
        Bootstrapper.insertScript("https://sc-static.net/scevent.min.js");
        const scUrlParams = new URLSearchParams(window.location.search);
        const scParam = scUrlParams.get("ScCid");
        var sc_cid =
            "";
        if (scParam && scParam != null) {
            sc_cid = scParam;
            window.localStorage.setItem("SC_CID", sc_cid);
            var domain = window.location.hostname.replace(/(www|m|desktop|mobile|t|tablet|a|checkout)\./g, "");
            JDObject.cookie.set("ScCid", sc_cid, 30, domain)
        }
        var scData = {};
        var email = JDObject.h.d.c.email();
        var regemail = /^([A-Za-z0-9_\-\.])+@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        if (typeof email != "undefined" && regemail.test(email.value) == true) {
            scData.user_email = email;
            scData.user_hashed_email = JDObject.get.Sha256(email)
        }
        var track =
            function(type, subType, data, eventId) {
                if (eventId) data.client_dedup_id = eventId;
                window.snaptr(type, subType, data)
            };
        track("init", id, scData);
        JDObject.helpers.snapchat.events = {
            navigation: {
                pageLoad: function(data) {
                    var ids = [];
                    var obj = data.obj;
                    if (obj.items)
                        for (var i = 0; i < obj.items.length; i++) ids.push(obj.items[i].plu);
                    if (obj.plu) ids.push(obj.plu);
                    let pvd = {};
                    if (ids.length) pvd.item_ids = ids;
                    pvd.click_id = sc_cid;
                    track("track", "PAGE_VIEW", pvd, data.eventId)
                }
            },
            pageView: {
                product: function(data) {
                    let scpd = {
                        currency: JDObject.currency,
                        price: data.obj.unitPrice,
                        click_id: sc_cid,
                        item_ids: JDObject.fasciaCode !== "JDFR" ? [data.obj.plu] : [data.obj.plu, window.dataObject.originalPlu]
                    };
                    track("track", "VIEW_CONTENT", scpd, data.eventId)
                },
                confirm: function(data) {
                    var obj = data.obj;
                    var ids = [];
                    for (var i = 0; i < obj.items.length; i++) ids.push(obj.items[i].plu);
                    ids = ids.join(",");
                    track("track", "PURCHASE", {
                        currency: JDObject.currency,
                        price: obj.orderTotal,
                        item_ids: ids,
                        transaction_id: obj.orderId
                    }, data.eventId)
                }
            },
            addToBasket: function(data) {
                var atbData = {
                    item_ids: [data.plu],
                    click_id: sc_cid
                };
                track("track", "ADD_CART", atbData, data.eventId)
            },
            quickViewAddToBasket: function(data) {
                var qatbData = {
                    item_ids: [data.plu],
                    click_id: sc_cid
                };
                track("track", "ADD_CART", qatbData, data.eventId)
            }
        }
    }
}, 4053217, [4029119, 3996520, 3640352, 3455314, 2853374, 3993904], 560411, [274206, 418795, 502041, 542880, 597950, 728092]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    (function() {
        var PinterestEvents = {
            pageView: {
                product: function(data) {
                    return Track("track", "pagevisit", {
                        line_items: [{
                            product_id: data.obj.plu
                        }]
                    })
                },
                confirmation: function(data) {
                    return Track("track", "checkout", {
                        currency: JDObject.currency,
                        order_quantity: data.obj.items.reduce(function(c, x) {
                            return c + +x.quantity
                        }, 0),
                        value: data.obj.orderTotal,
                        line_items: data.obj.items.map(function(x) {
                            return {
                                product_id: x.plu
                            }
                        }),
                        order_id: data.obj.orderId
                    })
                }
            },
            addToBasket: function(data) {
                return Track("track", "addtocart", {
                    currency: JDObject.currency,
                    order_quantity: data.quantity,
                    value: data.obj.unitPrice,
                    line_items: [{
                        product_id: data.obj.plu
                    }]
                })
            }
        };
        var Track = function(type, subType, data) {
            return pintrk(type, subType, data)
        };

        function PinterestInit(id) {
            JDObject.helpers.pinterest = {
                events: PinterestEvents
            };
            eval('window.pintrk\x3dfunction(){window.pintrk.queue.push(Array.prototype.slice.call(arguments))};\n\tvar n\x3dwindow.pintrk;n.queue\x3d[];n.version\x3d"3.0";');
            Bootstrapper.insertScript("https://s.pinimg.com/ct/core.js");
            pintrk("load", id);
            pintrk("page");
            JDObject.runEventsForTag("pinterest")
        }
        var id = {
            JD: "2612693522269",
            PY: "2613578422461",
            JDDE: "2613470748562",
            OI: "2613162510125",
            FP: "2612887949414",
            SZ: "2613136738311"
        }[JDObject.fasciaCode];
        if (id) PinterestInit(id)
    })()
}, 3802110, [3455314], 644007, [542880]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    var id = {
        AK: 844883612,
        AKM: 844883612,
        BL: 1004988603,
        BLM: 1004988603,
        CL: 958902171,
        CLM: 958902171,
        JD: 948117551,
        JDS: 948117551,
        JDM: 948117551,
        HS: 938642284,
        HSM: 938642284,
        ML: 1008342564,
        MLM: 1008342564,
        MS: 1064893355,
        MSM: 1064893355,
        PY: 847630681,
        PYM: 847630681,
        SC: 1030360849,
        SCM: 1030360849,
        SZ: 1042949456,
        SZM: 1042949456,
        TE: 1050655434,
        TEM: 1050655434,
        JDFR: 1004192739,
        JDFRM: 1004192739,
        JDDE: 984950282,
        JDDEM: 984950282,
        JDES: 1011982540,
        JDESM: 1011982540,
        JDIE: 1005077558,
        JDIEM: 1005077558,
        SZDE: 988354677,
        SZDEM: 988354677,
        SD: 975463819,
        SDM: 975463819
    }[window.JDObject.siteCode];
    if (window.location.pathname.match(/(reset-password|track-my-order)/g)) id = false;
    var label;
    try {
        label = {
            JD: "reJTCOGynwQQr8CMxAM",
            JDM: "reJTCOGynwQQr8CMxAM",
            SC: "p6_MCMuYxQkQkZ6o6wM",
            SCM: "p6_MCMuYxQkQkZ6o6wM",
            SK: "5OUdCJHRq4UCEJzN75ID"
        }[window.JDObject.siteCode]
    } catch (e) {}
    if (id) Bootstrapper.bindDOMParsed(function() {
        var obj = Bootstrapper.dataManager.getData();
        var gtp = {};
        gtp.ecomm_pagetype = {
            "list": "category",
            "product": "product",
            "basket": "cart",
            "confirmation": "purchase"
        }[obj.pageType] || obj.pageType;
        var path = window.location.pathname;
        if (JDObject.fasciaCode == "HS" && gtp.ecomm_pagetype == "category" && path.indexOf("search") > -1) gtp.ecomm_pagetype = "search";
        if (JDObject.fasciaCode == "HS" && ["", "/", "/home", "/home/"].indexOf(path) > -1) gtp.ecomm_pagetype = "home";
        if (obj.items) {
            var arr = obj.items;
            var pluArray = [];
            var priceArray = [];
            var nameArray = [];
            var qtyArray = [];
            var loops = obj.pageType ==
                "list" ? 3 : arr.length;
            for (var i = 0, l = loops; i < l; i++) {
                pluArray.push(arr[i].plu);
                priceArray.push(arr[i].unitPrice || arr[i].totalPrice);
                nameArray.push(arr[i].description);
                qtyArray.push(arr[i].quantity)
            }
            gtp.ecomm_prodid = pluArray;
            gtp.ecomm_totalvalue = priceArray.reduce((a, x) => a + parseFloat(x.replace(/[^\.\d]/g, "")), 0);
            gtp.ecomm_pname = nameArray;
            gtp.ecomm_itemquantity = qtyArray
        } else if (obj.plu) {
            gtp.ecomm_prodid = obj.plu;
            gtp.ecomm_pvalue = obj.unitPrice;
            gtp.ecomm_pname = obj.description;
            gtp.ecomm_pcat = obj.category;
            gtp.ecomm_brand =
                obj.brand;
            gtp.ecomm_sale = obj.sale
        }
        var fn = function(o) {
            return function() {
                window.google_trackConversion(o)
            }
        }({
            "google_conversion_id": id,
            "google_conversion_label": label,
            "google_remarketing_only": true,
            "google_custom_params": gtp
        });
        "function" != typeof window.google_trackConversion ? Bootstrapper.loadScriptCallback("//www.googleadservices.com/pagead/conversion_async.js", function(a) {
            return a
        }(fn)) : fn()
    })
}, 3689628, [4029119, 2913091, 3455314], 292546, [274206, 276097, 542880]);
Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    JDObject.assert("JDO.H.search");
    var siteSearchGaEvent = function(act, lab) {
        ga("send", "event", "site search", act, lab)
    };
    JDObject.helpers.search.submit = function() {
        var page = window.location.pathname;
        ga("ec:addPromo", {
            "id": "search",
            "name": "submit",
            "creative": page != "/" ? page : "/home",
            "position": "Header"
        });
        ga("ec:setAction", "promo_click");
        if (window.JDObject.helpers.search.voice) JDObject.eventSubmit("voiceSearchSubmit", {}, true);
        let productSearch = document.querySelector("#productsearch,#srchInput");
        if (productSearch && productSearch.value) {
            siteSearchGaEvent("standard search", productSearch.value);
            JDObject.eventSubmit("search.search", {
                value: productSearch.value
            }, false);
            JDObject.eventSubmit("pageView.viewSearchResults", {
                type: "search",
                searchValue: productSearch.value
            }, true)
        }
        console.log("Sent GA click")
    };
    var checFunction = function(ats, ty) {
        for (var i = 0; i < ats.length; i++) ats[i].addEventListener("click", function(e) {
            if (e.target.href &&
                e.target.href.indexOf("/search/") >= 0) siteSearchGaEvent(ty, e.target.innerText)
        })
    };
    if (document.querySelector("#enhancedSearch")) {
        if (document.querySelector("#enhancedSearch #trendingSearches")) {
            var ats1 = document.querySelectorAll("#trendingSearches a");
            checFunction(ats1, "trending search")
        }
        if (document.querySelector("#enhancedSearch #recentSearches")) {
            var ats2 = document.querySelectorAll("#recentSearches a");
            checFunction(ats2, "recent search")
        }
    }
}, 3948570, [3952459], 323697, [268459]);