Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    (function() {
        if (/^checkout/g.test(window.location.hostname)) return;
        var cs = JDObject.assert("JDO.H.contentSquare");
        var id = {
            SZ: "d767fabc3819a",
            SZDE: "d767fabc3819a",
            SZES: "d767fabc3819a",
            SZFR: "d767fabc3819a",
            SZIE: "d767fabc3819a",
            SZIT: "d767fabc3819a",
            SZNL: "d767fabc3819a",
            FP: "d084e75cd56b9",
            FPDE: "d084e75cd56b9",
            FPIE: "d084e75cd56b9",
            FPIT: "d084e75cd56b9",
            FPFR: "d084e75cd56b9",
            FPNL: "d084e75cd56b9",
            HS: "f14018b856a8f",
            JD: "5f88187146ec9",
            JDAU: "5f88187146ec9",
            JDBE: "5f88187146ec9",
            JDBG: "5f88187146ec9",
            JDCA: "5f88187146ec9",
            JDCY: "5f88187146ec9",
            JDDK: "5f88187146ec9",
            JDDE: "5f88187146ec9",
            JDES: "5f88187146ec9",
            JDFR: "5f88187146ec9",
            JDGR: "5f88187146ec9",
            JDHU: "5f88187146ec9",
            JDID: "5f88187146ec9",
            JDIE: "5f88187146ec9",
            JDIL: "5f88187146ec9",
            JDLT: "5f88187146ec9",
            JDIT: "5f88187146ec9",
            JDMY: "5f88187146ec9",
            JDNL: "5f88187146ec9",
            JDNZ: "5f88187146ec9",
            JDAT: "5f88187146ec9",
            JDPT: "5f88187146ec9",
            JDPL: "5f88187146ec9",
            JDRO: "5f88187146ec9",
            JDSG: "5f88187146ec9",
            JDSK: "5f88187146ec9",
            JDFI: "5f88187146ec9",
            JDSE: "5f88187146ec9",
            JDTH: "5f88187146ec9"
        }[window.JDObject.fasciaCode];
        if (!id) return;
        cs.id = id;
        window._uxa = window._uxa || [];
        try {
            if (typeof dataObject !== "undefined") {
                var customVarObj = {
                    1: "brand",
                    2: "category",
                    3: "exclusive",
                    4: "onlineexclusive",
                    5: "ownbrand",
                    6: "pageType",
                    7: "sale",
                    8: "storeId"
                };
                for (var key in customVarObj)
                    if (dataObject.hasOwnProperty(customVarObj[key]) && typeof dataObject[customVarObj[key]] !== "undefined" && dataObject[customVarObj[key]] !==
                        "") window._uxa.push(["setCustomVariable", key, customVarObj[key], dataObject[customVarObj[key]], 3])
            }
        } catch (e) {}
        if (typeof CS_CONF === "undefined") {
            window._uxa.push(["setPath", window.location.pathname + window.location.hash.replace("#", "?__")]);
            Bootstrapper.insertScript(`//t.contentsquare.net/uxa/${id}.js`)
        } else window._uxa.push(["trackPageview", window.location.pathname + window.location.hash.replace("#", "?__")])
    })();
    JDObject.runEventQueue()
}, 4095547, [4029119, 3996520], 767972, [274206, 418795]);