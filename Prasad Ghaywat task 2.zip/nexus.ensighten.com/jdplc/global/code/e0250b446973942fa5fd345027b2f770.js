Bootstrapper.bindDependencyDOMParsed(function() {
    var Bootstrapper = window["Bootstrapper"];
    var ensightenOptions = Bootstrapper.ensightenOptions;
    (function() {
        const consentExclusionList$2 = ["JDGL", "JDAU", "JDMY", "JDSG", "JDTH"];

        function loadScript$1(src, timeout = 8E3) {
            return new Promise((resolve, reject) => {
                window.Bootstrapper.loadScriptCallback(src, resolve);
                setTimeout(reject, timeout)
            })
        }

        function ensureConsentDefaultsSet$1() {
            return new Promise(function(resolve) {
                (function waitForConsentDefaults() {
                    var _a;
                    if (((_a = JDObject.helpers.GoogleConsent) ===
                            null || _a === void 0 ? void 0 : _a.ConsentDefaultSet) || consentExclusionList$2.includes(JDObject.fasciaCode)) return resolve();
                    setTimeout(waitForConsentDefaults, 30)
                })()
            })
        }
        class GoogleAdWords {
            constructor(id) {
                this._customDimensions = {};
                this.events = {
                    addToBasket: () => {
                        this._set({
                            send_to: this.Id + "/" + this.Conversions["add_to_cart"]
                        });
                        this._track("conversion")
                    }
                };
                this.Id = id.measurementId;
                this.Conversions = Object.fromEntries(id.conversionIds.map((conversion) => [conversion.event, conversion.conversionId]));
                ensureConsentDefaultsSet$1().then(() => {
                    if (!window.dataLayer) window.dataLayer = [];
                    if (!window.gtag) window.gtag = function() {
                        window.dataLayer.push(arguments)
                    };
                    let sessionVariables = {
                        cookie_expires: 30 * 24 * 60 * 60,
                        send_to: this.Id,
                        allow_enhanced_conversions: true
                    };
                    window.gtag("config", this.Id, sessionVariables);
                    const src = "https://www.googletagmanager.com/gtag/js?id\x3d" + this.Id;
                    loadScript$1(src)
                })
            }
            _set(nameOrData, value) {
                const data = value === undefined ? nameOrData : {
                    [nameOrData]: value
                };
                Object.keys(data).forEach((x) => {
                    this._customDimensions[x] = data[x]
                });
                window.gtag("set",
                    data)
            }
            _track(type, data) {
                data = Object.assign(Object.assign({}, this._customDimensions), data);
                if (data.value !== undefined || data.price !== undefined) data.currency = JDObject.currency;
                if (data.page_location) data.page_location = location.protocol + "//" + location.hostname + data.page_location;
                window.gtag("event", type, data)
            }
        }
        const ADWORDS_IDS = {
            XX: {
                measurementId: "AW-982809095",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "XPA0CJWaxYoDEIf00dQD"
                }]
            },
            JDAU: {
                measurementId: "AW-16446999455",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "AiibCPWIxY8ZEJ-XxaI9"
                }]
            },
            JDMY: {
                measurementId: "AW-16447007914",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "5PmICI2Bxo8ZEKrZxaI9"
                }]
            },
            JDNZ: {
                measurementId: "AW-16447012230",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "OMnwCPeCxo8ZEIb7xaI9"
                }]
            },
            JDSG: {
                measurementId: "AW-16446993434",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "i_d_CKKExo8ZEJroxKI9"
                }]
            },
            JDTH: {
                measurementId: "AW-16447001841",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "KIEYCLXduo8ZEPGpxaI9"
                }]
            },
            JDAT: {
                measurementId: "AW-11440385150",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "sJQXCKrtyo8ZEP7Ymc8q"
                }]
            },
            JDBE: {
                measurementId: "AW-11440327548",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "_Q_zCK3tyo8ZEPyWls8q"
                }]
            },
            JDDE: {
                measurementId: "AW-11440111047",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "UG4ZCI3xyo8ZEMf7iM8q"
                }]
            },
            JDDK: {
                measurementId: "AW-11440271809",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "rwfxCM3wy48ZEMHjks8q"
                }]
            },
            JDFI: {
                measurementId: "AW-11440368770",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "qn72CNDwy48ZEILZmM8q"
                }]
            },
            JDFR: {
                measurementId: "AW-11440105731",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "ogdGCKfWw48ZEIPSiM8q"
                }]
            },
            JDNL: {
                measurementId: "AW-11440345016",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "EvnQCK3Ww48ZELifl88q"
                }]
            },
            JDSE: {
                measurementId: "AW-11440270123",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "huTCCPTwy48ZEKvWks8q"
                }]
            },
            JDES: {
                measurementId: "AW-11440064506",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "uxdeCKiuwY8ZEPqPhs8q"
                }]
            },
            JDIT: {
                measurementId: "AW-11440103580",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "Kh-ZCKOswY8ZEJzBiM8q"
                }]
            },
            JDPT: {
                measurementId: "AW-11440104618",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "gJ5gCPevwY8ZEKrJiM8q"
                }]
            },
            JD: {
                measurementId: "AW-982809095",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "-3a2CNPAm-EBEIf00dQD"
                }]
            },
            JDIE: {
                measurementId: "AW-16446949076",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "pYW5CKWBwY8ZENSNwqI9"
                }]
            },
            FPDK: {
                measurementId: "AW-11432422401",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "veD3CMKAv48ZEIHYs8sq"
                }]
            },
            FPFI: {
                measurementId: "AW-11432423637",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "CnuPCPSLv48ZENXhs8sq"
                }]
            },
            FPFR: {
                measurementId: "AW-11429893835",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "J5qFCL6gv48ZEMutmcoq"
                }]
            },
            FPDE: {
                measurementId: "AW-11427364409",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "YQQfCO7Rwo8ZELn8_sgq"
                }]
            },
            FPIE: {
                measurementId: "AW-11432425332",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "qqj6CJvewo8ZEPTus8sq"
                }]
            },
            FPIT: {
                measurementId: "AW-11432420742",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "IYFYCLntwo8ZEIbLs8sq"
                }]
            },
            FPNL: {
                measurementId: "AW-11432426796",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "XuDzCOvvwo8ZEKz6s8sq"
                }]
            },
            FPSE: {
                measurementId: "AW-11432389723",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "IWyJCLPHw48ZENvYscsq"
                }]
            },
            FP: {
                measurementId: "AW-969399710",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "qDKDCJKbto8ZEJ67n84D"
                }]
            },
            HS: {
                measurementId: "AW-938642284",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "oDEaCIi4to8ZEOyWyr8D"
                }]
            },
            SZBE: {
                measurementId: "AW-11439106897",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "l1gyCIvst48ZENHWy84q"
                }]
            },
            SZDK: {
                measurementId: "AW-11439204851",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "ngc8CN_4t48ZEPPT0c4q"
                }]
            },
            SZFI: {
                measurementId: "AW-11439112621",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "Aq87CJCiw48ZEK2DzM4q"
                }]
            },
            SZFR: {
                measurementId: "AW-11439084322",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "Es2yCNSSwY8ZEKKmys4q"
                }]
            },
            SZDE: {
                measurementId: "AW-11439123705",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "g4otCMKIvo8ZEPnZzM4q"
                }]
            },
            SZIE: {
                measurementId: "AW-11439182291",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "2YvdCPz2yY8ZENOj0M4q"
                }]
            },
            SZIT: {
                measurementId: "AW-11439087682",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "_nw7COfkwY8ZEMLAys4q"
                }]
            },
            SZNL: {
                measurementId: "AW-11439201944",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "uCM7CNrTvo8ZEJi90c4q"
                }]
            },
            SZES: {
                measurementId: "AW-11439131370",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "GG0tCN7mvo8ZEOqVzc4q"
                }]
            },
            SZSE: {
                measurementId: "AW-11439108106",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "obkVCNq6yo8ZEIrgy84q"
                }]
            },
            SZ: {
                measurementId: "AW-987770967",
                conversionIds: [{
                    event: "add_to_cart",
                    conversionId: "ZPPRCILktI8ZENfggNcD"
                }]
            }
        };
        var GTag;
        (function(GTag) {
            function InstantiateGTag() {
                if (!window.dataLayer) window.dataLayer = [];
                if (!window.gtag) window.gtag = function() {
                    window.dataLayer.push(arguments)
                }
            }
            GTag.InstantiateGTag = InstantiateGTag;
            GTag.CONSENT_DEFAULTS = {
                ad_storage: "denied",
                ad_user_data: "denied",
                ad_personalization: "denied",
                analytics_storage: "denied"
            }
        })(GTag || (GTag = {}));
        class GoogleConsentMode {
            constructor() {
                this.ConsentDefaultSet =
                    false;
                this.CookieConsentSet = false;
                this.CookieConsentUpdated = false;
                this.events = {
                    updateConsent: (consentOptions) => {
                        this._setConsent(consentOptions);
                        this.CookieConsentUpdated = true
                    }
                };
                GTag.InstantiateGTag();
                gtag("consent", "default", GTag.CONSENT_DEFAULTS);
                gtag("set", {
                    ads_data_redaction: true
                });
                this.ConsentDefaultSet = true;
                this._getConsentFromCookies();
                this.CookieConsentSet = true
            }
            _setConsent(consent) {
                let consentObject = {
                    ad_storage: consent.targeting ? "granted" : "denied",
                    ad_user_data: consent.targeting ? "granted" : "denied",
                    ad_personalization: consent.targeting ? "granted" : "denied",
                    analytics_storage: consent.performance ? "granted" : "denied"
                };
                window.gtag("consent", "update", consentObject);
                gtag("set", {
                    ads_data_redaction: !consent.targeting
                })
            }
            _getConsentFromCookies() {
                var _a;
                let consentCookie = (_a = document.cookie.split("; ").find((row) => row.startsWith("gdprsettings3\x3d"))) === null || _a === void 0 ? void 0 : _a.split("\x3d")[1];
                const refName = "JDOReferrer";
                if (consentCookie) {
                    const ref = sessionStorage.getItem(refName);
                    if (ref) {
                        gtag("set", {
                            "page_referrer": ref
                        });
                        sessionStorage.removeItem(refName)
                    }
                } else sessionStorage.setItem(refName, document.referrer);
                let consentOptions = consentCookie ? JSON.parse(consentCookie) : {
                    performance: false,
                    functional: false,
                    targeting: false
                };
                this._setConsent(consentOptions)
            }
        }
        class Clean {
            static _number(val) {
                if (typeof val === "number") return val;
                if (typeof val !== "string") return undefined;
                const parsed = parseFloat(val.replace(/[^\d\.]+/g, ""));
                return !isNaN(parsed) ? parsed : undefined
            }
            static Float(val) {
                return this._number(val)
            }
            static Integer(val) {
                const parsed =
                    this._number(val);
                return parsed ? Math.round(parsed) : undefined
            }
        }
        const consentExclusionList$1 = ["JDGL", "JDAU", "JDMY", "JDSG", "JDTH"];

        function loadScript(src, timeout = 8E3) {
            return new Promise((resolve, reject) => {
                window.Bootstrapper.loadScriptCallback(src, resolve);
                setTimeout(reject, timeout)
            })
        }

        function ensureConsentDefaultsSet() {
            return new Promise(function(resolve) {
                (function waitForConsentDefaults() {
                    var _a;
                    if (((_a = JDObject.helpers.GoogleConsent) === null || _a === void 0 ? void 0 : _a.ConsentDefaultSet) || consentExclusionList$1.includes(JDObject.fasciaCode)) return resolve();
                    setTimeout(waitForConsentDefaults, 30)
                })()
            })
        }

        function ensureCustomerDataSet() {
            return new Promise(function(resolve) {
                (function waitForCustomerData() {
                    if (window.customerDataObject.ipAddress) return resolve(window.customerDataObject);
                    setTimeout(waitForCustomerData, 30)
                })()
            })
        }

        function ensureGA4Initialised() {
            return new Promise(function(resolve) {
                (function waitForGA4Initialisation() {
                    if (window.JDObject.helpers.GA4.IsInit === true) return resolve();
                    setTimeout(waitForGA4Initialisation, 30)
                })()
            })
        }
        class GoogleAnalytics4 {
            constructor(id) {
                this.IsProd = !location.hostname.includes("jdmesh.co");
                this.IsInit = false;
                this._customDimensions = {};
                this.events = {
                    addToBasket: (data) => {
                        this._track("add_to_cart", this._getAddToBasket(data))
                    },
                    addToWishlist: (data) => {
                        this._track("add_to_wishlist", this._getAddToBasket(data))
                    },
                    addToWishlistClick: (data) => {
                        this._track("add_to_wishlist", this._getAddToBasket(data))
                    },
                    logIn: (data) => {
                        this._track("login", {
                            method: "login page"
                        })
                    },
                    productListClick: (data) => {
                        var _a;
                        let prod;
                        try {
                            prod = this._getViewProduct((_a = data.item) !== null && _a !==
                                void 0 ? _a : data.obj.items.find((x) => x.plu == data.plu), data.position)
                        } catch (e) {}
                        this._track("select_item", {
                            item_list_id: location.pathname,
                            item_list_name: location.pathname,
                            items: prod ? [prod] : []
                        })
                    },
                    promotionClick: (data) => {
                        var _a;
                        const promo = data.name ? data : this._getPromotionData.call((_a = data.a) !== null && _a !== void 0 ? _a : data.item);
                        this._track("select_promotion", {
                            creative_name: promo.creative,
                            creative_slot: promo.position,
                            promotion_id: promo.id,
                            promotion_name: promo.name
                        })
                    },
                    registerUser: (data) => {
                        this._track("sign_up", {
                            method: "register"
                        })
                    },
                    basket: {
                        update: {
                            removeItem: (data) => {
                                const prod = this._getBasketProduct(data);
                                this._track("remove_from_cart", {
                                    items: [prod],
                                    value: prod.price
                                })
                            }
                        },
                        voucher: {
                            applySuccess: (data) => {
                                this._track("promo_code_success", {
                                    code_used: data.code_used
                                })
                            },
                            applyFailed: (data) => {
                                this._track("promo_code_failure", {
                                    code_used: data.code_used
                                })
                            }
                        }
                    },
                    checkout: {
                        expressClick: (data) => {
                            this._track("express_payment_cta", {
                                express_payment: data.type
                            })
                        }
                    },
                    pageView: {
                        basket: (data) => {
                            var _a, _b;
                            const items = data.obj.items.map((x,
                                i) => this._getBasketProduct(x, i));
                            const value = (_b = Clean.Float((_a = data.obj.total) !== null && _a !== void 0 ? _a : data.obj.orderTotal)) !== null && _b !== void 0 ? _b : 0;
                            this._set({
                                "basket_quantity": data.obj.items.reduce((total, x) => total + Clean.Integer(x.quantity), 0),
                                "basket_total": value,
                                "basket_lines": items.length,
                                "currency": JDObject.currency
                            });
                            this._track("view_cart", {
                                coupon: data.obj.voucher,
                                items: data.obj.items.map((x, i) => this._getViewProduct(x, i)),
                                tax: value - JDObject.siteData.getGrossFromTotal(value)
                            })
                        },
                        product: (data) => {
                            this._track("view_item", {
                                items: [this._getViewProduct(data.obj)]
                            })
                        },
                        list: (data) => {
                            this._track("view_item_list", {
                                item_list_id: location.pathname,
                                item_list_name: location.pathname,
                                items: data.obj.items.map((x, i) => this._getViewProduct(x, i)),
                                number_of_products: data.obj.items.length
                            });
                            if (location.pathname.includes("/campaign/")) this._track("view_promotion", {
                                creative_name: data.obj.pageName,
                                creative_slot: data.obj.category,
                                promotion_id: location.pathname.replace("/campaign/", ""),
                                promotion_name: data.obj.pageName,
                                items: data.obj.items.map((x, i) => this._getViewProduct(x, i))
                            })
                        },
                        viewSearchResults: (data) => {
                            this._track("view_search_results", {
                                search_type: data.type,
                                search_term: data.searchValue
                            })
                        },
                        pageNotFound: (data) => {
                            this._track("page_not_found", {
                                page_not_found: window.location.pathname
                            })
                        }
                    },
                    search: {
                        search: (data) => {
                            this._track("search", {
                                search_term: data.value,
                                search_type: "standard"
                            })
                        },
                        recent: (data) => {
                            this._track("search", {
                                search_term: data.value,
                                search_type: "recent"
                            })
                        },
                        trending: (data) => {
                            this._track("search", {
                                search_term: data.value,
                                search_type: "trending"
                            })
                        }
                    },
                    productClick: (data) => {
                        this._track("search", {
                            search_term: data.plu,
                            search_type: "recently_viewed"
                        })
                    },
                    productList: {
                        sort: (data) => {
                            if (!data.label.match(/sort/gi)) this._track("sort_clicks", {
                                list: data.label
                            })
                        },
                        refine: (data) => {
                            this._track("refine_clicks", {
                                list: data.type + "-" + data.value
                            })
                        }
                    },
                    navigation: {
                        fredHopperClick: (data) => {
                            this._track("fredhopper_banner_click", {
                                fredhopper_banner_name: data.header + " - " + data.linkText
                            })
                        },
                        footer: (data) => {
                            this._track("footer_click", {
                                footer_link_name: data.text
                            })
                        }
                    },
                    popupError: (data) => {
                        this._track("pop_up_error_message", {
                            path: window.location.pathname,
                            error_message: data.message
                        })
                    },
                    splashPage: (data) => {
                        this._track("splash_page", {})
                    },
                    newsletterSignup: (data) => {
                        this._track("newsletter_signup", {
                            page_path: window.location.pathname
                        })
                    }
                };
                this.Id = this.IsProd ? id : "G-0SWH3C2EMT";
                GTag.InstantiateGTag();
                Promise.all([ensureCustomerDataSet(), ensureConsentDefaultsSet()]).then((ga4Customer) => {
                    var _a;
                    let customer = ga4Customer;
                    let storeId = (_a = JDObject === null || JDObject === void 0 ? void 0 :
                        JDObject.siteData) === null || _a === void 0 ? void 0 : _a.meshStoreId;
                    if (typeof window.customerDataObject !== "undefined" && window.customerDataObject.customerID) customer.customerID = window.customerDataObject.customerID;
                    let sessionVariables = {
                        cookie_expires: 30 * 24 * 60 * 60,
                        logged_in: customer.customerID ? "logged in" : "guest",
                        allow_enhanced_conversions: true,
                        send_to: this.Id
                    };
                    if (customer[0].email) sessionVariables.user_id = customer.customerID;
                    if (storeId !== undefined) sessionVariables.store = storeId;
                    this._set(sessionVariables);
                    window.gtag("config", this.Id, sessionVariables);
                    const src = "https://www.googletagmanager.com/gtag/js?id\x3d" + this.Id;
                    loadScript(src);
                    this.IsInit = true
                })
            }
            _set(nameOrData, value) {
                const data = value === undefined ? nameOrData : {
                    [nameOrData]: value
                };
                Object.keys(data).forEach((x) => {
                    this._customDimensions[x] = data[x]
                });
                window.gtag("set", data)
            }
            _track(type, data) {
                ensureGA4Initialised().then(() => {
                    data = Object.assign(Object.assign({}, this._customDimensions), data);
                    if (data.value !== undefined || data.price !== undefined) data.currency =
                        JDObject.currency;
                    if (data.page_location) data.page_location = location.protocol + "//" + location.hostname + data.page_location;
                    window.gtag("event", type, data)
                })
            }
            _getViewProduct(item, index = 0) {
                const was = Clean.Float(item.previousPrice);
                const price = Clean.Float(item.unitPrice);
                const discount = was && price ? was - price : 0;
                let cats = [];
                if (item.categories && Array.isArray(item.categories)) cats = Array.isArray(item.categories[0]) ? item.categories[0] : item.categories;
                else if (typeof item.category === "string") cats = item.category.split(" \x3e ");
                return {
                    item_brand: item.brand,
                    item_id: item.plu.replace(/_.*/, ""),
                    item_name: item.description.replace(/&[^;]*;/gi, "'"),
                    price: price !== null && price !== void 0 ? price : 0,
                    discount: discount,
                    index,
                    item_category: cats[0],
                    item_category2: cats[1],
                    item_category3: cats[2]
                }
            }
            _getBasketProduct(item, index = 0) {
                var _a, _b, _c;
                return Object.assign(Object.assign({}, this._getViewProduct(item, index)), {
                    item_variant: (_a = item.sku) !== null && _a !== void 0 ? _a : item.ean,
                    quantity: (_c = Clean.Integer((_b = item.quantity) !== null && _b !== void 0 ? _b : item.count)) !==
                        null && _c !== void 0 ? _c : 1
                })
            }
            _getAddToBasket(data) {
                var _a, _b, _c, _d, _e, _f, _g;
                const value = (_d = (_a = Clean.Float(data.totalPrice)) !== null && _a !== void 0 ? _a : ((_b = Clean.Float(data.obj.unitPrice)) !== null && _b !== void 0 ? _b : 0) * ((_c = Clean.Integer(data.quantity)) !== null && _c !== void 0 ? _c : 1)) !== null && _d !== void 0 ? _d : 0;
                return {
                    value,
                    items: [this._getBasketProduct(Object.assign(Object.assign({}, data.obj), {
                        quantity: (_e = data.obj.quantity) !== null && _e !== void 0 ? _e : data.quantity,
                        sku: (_g = (_f = data.obj.sku) !== null && _f !== void 0 ? _f : data.sku) !==
                            null && _g !== void 0 ? _g : data.variant
                    }))]
                }
            }
            _getPromotionData() {
                var _a;
                let gaid = this.dataset.ipId || this.pathname;
                let name = this.dataset.ipName || ((_a = this.textContent) === null || _a === void 0 ? void 0 : _a.trim());
                let posi = this.dataset.ipPosition;
                let crea = window.location.pathname;
                if (crea === "" || crea == "/") crea = "/home";
                if (gaid === "" || gaid == "/") gaid = "/home";
                return {
                    id: gaid,
                    name,
                    position: posi,
                    creative: crea
                }
            }
        }
        const id = {
            AK: "G-138QXB1GW7",
            HS: "G-MKDXQSME2D",
            PY: "G-8HKSFPP2VT",
            SD: "G-9ZQ3EWQBPV",
            JD: "G-3CKP0GTK0M",
            JDAT: "G-HDTVPGJ1B7",
            JDAU: "G-EB1EQLP6S0",
            JDBE: "G-L50SL4M29T",
            JDDE: "G-DR7R5FQ65N",
            JDDK: "G-WHZTNYZ2RX",
            JDES: "G-D9ZCNWLC15",
            JDFI: "G-C6TCJ6H6C5",
            JDFR: "G-6BHRZSRP6K",
            JDGL: "G-6SYYDXQK9T",
            JDIE: "G-7SW3QVX8GS",
            JDIT: "G-2BLXMWYKY4",
            JDMY: "G-ND0BJV89PL",
            JDNL: "G-8VDYPK0ZM3",
            JDNZ: "G-99YVX646NP",
            JDPT: "G-N301DEKRZD",
            JDSE: "G-HZ9F6WNE8H",
            JDSG: "G-LV7SRL6PH9",
            JDTH: "G-2SWF8JEVV2",
            SZ: "G-30GL69BHPX",
            SZBE: "G-8T3R7M4DVX",
            SZDE: "G-BXC1YEQ5M6",
            SZDK: "G-MSSMXLTBWN",
            SZES: "G-46DML5RKWC",
            SZFI: "G-D5Z4FKP0SN",
            SZFR: "G-DXVMJK3M9P",
            SZIE: "G-2H28ZQQDN2",
            SZIT: "G-DTMZHCRS49",
            SZNL: "G-HRNN51LRGR",
            SZSE: "G-543N077TG8",
            FP: "G-W48NGJK8TS",
            FPDE: "G-930XCNG01S",
            FPDK: "G-7CRKM098B3",
            FPFI: "G-VLMTM59PKX",
            FPFR: "G-Y8C881KX85",
            FPIE: "G-T8CR8WMMM7",
            FPIT: "G-ZVGR1ZKB0C",
            FPNL: "G-GRXLE6QQ6B",
            FPSE: "G-GS2HMEPBRZ"
        }[JDObject.fasciaCode];
        let adwordsId = ADWORDS_IDS[JDObject.fasciaCode];
        const excludedFascias = ["GO", "BL", "ML", "UO", "ODPS", "FR", "NY", "ODBR", "ODEH"];
        const consentExclusionList = ["JDGL", "JDAU", "JDMY", "JDSG", "JDTH"];
        if (!excludedFascias.includes(window.JDObject.fasciaCode)) {
            if (!consentExclusionList.includes(window.JDObject.fasciaCode)) JDObject.helpers["GoogleConsent"] =
                new GoogleConsentMode;
            if (typeof adwordsId === "object" && (adwordsId === null || adwordsId === void 0 ? void 0 : adwordsId.measurementId)) JDObject.helpers.GoogleAdWords = new GoogleAdWords(adwordsId);
            JDObject.helpers["GA4"] = new GoogleAnalytics4(id)
        }
        JDObject.runEventQueue()
    })()
}, 4051188, [4029119, 3996520, 3856905, 3835934], 753323, [274206, 418795, 487275, 728534]);