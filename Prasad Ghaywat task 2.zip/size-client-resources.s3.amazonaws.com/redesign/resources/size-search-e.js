jQuery(document).ready(function() {
    jQuery('#searchButton').click(function() {
        jQuery('#lbOpenBg').css('display', 'block');
    });
    jQuery('#searchClose').click(function() {
        jQuery('#lbOpenBg').css('display', 'none');
    });
});