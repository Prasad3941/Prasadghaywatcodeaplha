jQuery(document).ready(function() {
    jQuery('#storeFindForm form .btn-level3').each(function() {
        string = jQuery(this).text('Find');
        jQuery(this).html('<img src="https://size-client-resources.s3.amazonaws.com/redesign/resources/white.svg"  />');
    });
    jQuery('#storeDirections').prependTo('#storePageContent #storeDetailsContent #storeInfo');
    jQuery('#storeTimes').appendTo('#storeInfo');

});