$(document).ready(function(e) {
    $("#signup").appendTo("#signupForm");
    $('.tabletTopNav').appendTo('#dropNav');
    $('#signup form button').each(function() {
        string = $(this).text('Sign Up');
        $(this).html('<img src="https://size-client-resources.s3.amazonaws.com/redesign/resources/white.svg" />');
    });
});

function openNav() {
    document.getElementById("tabletLinks").style.width = "100%";
}

function closeNav() {
    document.getElementById("tabletLinks").style.width = "0";
}


// use setTimeout() to execute
setTimeout(showpanel, 000);