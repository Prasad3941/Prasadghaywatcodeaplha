$(document).ready(function() {
    // Version Control
    var cVersion = "1.2";
    console.log('USP & NAV LOAD - v' + cVersion);

    // Version Comments
    // v0.1 - Initial Setup for redesigned header
    // v0.2 - Services Menu dropdown included

    // move navigation to headBot
    $('#nav-menu').insertAfter('#headBot > .logo');

    // create services menu and move userMenu
    $('<div id="services-container"><img src="https://size-client-resources.s3.amazonaws.com/ui-kit/svg/Account%20Options%20A.svg" alt="services icon"><div class="services-dropdown"></div></div>').insertAfter('#searchButton');
    $('#usermenu').appendTo('.services-dropdown');


    // create more menu and apply content from variables stored in MESH Snippets
    $('<div id="more-container"><img src="https://size-client-resources.s3.amazonaws.com/ui-kit/svg/More%20Menu.svg" alt="more menu icon"><div class="more-dropdown">' + render_moreContent() + '</div></div>').insertBefore('#headBot .logo');

    function render_moreContent() {
        var moreContent_output = "";
        for (var i = 0; i < moreContent.length; i++) {
            moreContent_output += '<a class="ga-ip" href="' + moreContent[i].href + '" data-ip-position="nav-more" data-ip-name="' + moreContent[i].title + '">' + moreContent[i].title + '</a>';
        }
        return moreContent_output;
    }

    // apply GA Tagging to main Navigation Links
    // WIP

    // add USP Slider apply content from variables stored in MESH Snippets
    $('<div id="usp-slider"><div class="usp-wrapper"><div class="usp-slider usp-1"><a href="" class="usp-link ga-ip" data-ip-position="usp-slider" data-ip-name=""></a></div><div class="usp-slider usp-2"><a href="" class="usp-link ga-ip" data-ip-position="usp-slider" data-ip-name=""></a></div><div class="usp-slider usp-3"><a href="" class="usp-link ga-ip" data-ip-position="usp-slider" data-ip-name=""></a></div><div class="usp-slider usp-4"><a href="" class="usp-link ga-ip" data-ip-position="usp-slider" data-ip-name=""></a></div><div class="usp-slider usp-1"><a href="" class="usp-link ga-ip" data-ip-position="usp-slider" data-ip-name=""></a></div><div class="usp-slider usp-2"><a href="" class="usp-link ga-ip" data-ip-position="usp-slider" data-ip-name=""></a></div><div class="usp-slider usp-3"><a href="" class="usp-link ga-ip" data-ip-position="usp-slider" data-ip-name=""></a></div><div class="usp-slider usp-4"><a href="" class="usp-link ga-ip" data-ip-position="usp-slider" data-ip-name=""></a></div></div></div>').prependTo('#headTop');
    $('.usp-1 a').each(function() {
        $(this).attr({
            href: uspContent[0].uspLink,
            'data-ip-position': uspContent[0].uspName,
            style: "color:" + uspContent[0].uspColor + ";"
        });
        $(this).text(uspContent[0].uspName);
        $(this).parent('.usp-slider').attr("style", "background-color:" + uspContent[0].uspBackground + ";");
    })
    $('.usp-2 a').each(function() {
        $(this).attr({
            href: uspContent[1].uspLink,
            'data-ip-position': uspContent[1].uspName,
            style: "color:" + uspContent[1].uspColor + ";"
        });
        $(this).text(uspContent[1].uspName);
        $(this).parent('.usp-slider').attr("style", "background-color:" + uspContent[1].uspBackground + ";");
    })
    $('.usp-3 a').each(function() {
        $(this).attr({
            href: uspContent[2].uspLink,
            'data-ip-position': uspContent[2].uspName,
            style: "color:" + uspContent[2].uspColor + ";"
        });
        $(this).text(uspContent[2].uspName);
        $(this).parent('.usp-slider').attr("style", "background-color:" + uspContent[2].uspBackground + ";");
    })
    $('.usp-4 a').each(function() {
        $(this).attr({
            href: uspContent[3].uspLink,
            'data-ip-position': uspContent[3].uspName,
            style: "color:" + uspContent[3].uspColor + ";"
        });
        $(this).text(uspContent[3].uspName);
        $(this).parent('.usp-slider').attr("style", "background-color:" + uspContent[3].uspBackground + ";");
    })
})