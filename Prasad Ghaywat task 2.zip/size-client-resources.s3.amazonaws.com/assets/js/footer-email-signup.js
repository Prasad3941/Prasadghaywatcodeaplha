$(document).ready(function() {
    moveEmailSignup();
    showpanel();
});

function showpanel() {
    $(document).ready(function() {
        $('#signup form button').each(function() {
            string = $(this).text('Sign Up');
            $(this).html('<img src="https://size-client-resources.s3.amazonaws.com/redesign/resources/white.svg" />');
        });
    });
}

function moveEmailSignup() {
    $('#signup').appendTo('#signupForm');
}