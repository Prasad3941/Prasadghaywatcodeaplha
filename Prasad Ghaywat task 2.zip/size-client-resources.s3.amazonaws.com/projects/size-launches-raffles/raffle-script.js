$(document).ready(function() {
    console.time('Raffle script')
    if (
        window.location.href.indexOf('/customer-service/size-launches-raffles/') >
        -1 ||
        window.location.href.indexOf('/customer-service/size-launches/') > -1
    ) {
        $.getJSON(
            'https://mosaic-platform.jdmesh.co/public/stores/size/tandc',
            callBack,
        )
        const jdGroupLink =
            '<a style="text-decoration: underline" href="https://www.jdplc.com/our-group">www.jdplc.com/our-group</a>'
        const deliveryLink =
            '<a style="text-decoration: underline" href="/customer-service/delivery/">www.size.co.uk/customer-service/delivery/</a>'
        const privacyLink =
            '<a style="text-decoration: underline" href="/customer-service/privacy/">www.size.co.uk/customer-service/privacy/</a>'
        const sizeAccessLink =
            '<a style="text-decoration: underline" href="/page/sizeaccess">https://www.size.co.uk/page/sizeaccess</a>'
        const termsLink =
            '<a style="text-decoration: underline" href="/customer-service/terms/">www.size.co.uk/customer-service/terms/</a>'
        const sportsFashionLink =
            '<a style="text-decoration: underline" href="www.jdplc.com/our-group/sports-fashion.aspx">www.jdplc.com/our-group/sports-fashion.aspx</a>'
        const justGivingLink =
            '<a style="text-decoration: underline" href="https://www.justgiving.com/crowdfunding/julietspositivepants?utm_term=4qMZJ9bQ">https://www.justgiving.com/crowdfunding/julietspositivepants?utm_term=4qMZJ9bQ</a>'
        const customerServiceLink =
            '<a style="text-decoration: underline" href="/customer-service/sizeaccess/">http://www.size.co.uk/customer-service/sizeaccess/</a>'

        function inStoreTemplate(product) {
            const inStoreRaffleCopy =
                `
      <p><strong>size?launches: ${product.productTitle} ${product.instoreName} Draw - ${product.productPrice}</strong></p>
      <p>You can enter the ${product.productTitle} ${product.instoreName} draw via the <strong>size?launches</strong> app by either scanning the QR code in the size? store and then logging into the <strong>size?launches</strong> app or by logging into the <strong>size?launches</strong> app directly and entering your date of birth, size? store, preferred size and valid payment details. Draws are only open for fixed periods as shown on the <strong>size?launches</strong> app (&ldquo;<strong>App</strong>&rdquo;) and a countdown timer will display the time remaining to enter each draw. Each draw will close when the countdown timer expires. Once you have submitted your details and if you choose to pay using a credit or debit card or via Klarna Pay in 3 (available in the UK only), we or Klarna (as applicable) will place a hold on your payment card for the price of the ${product.productTitle}, ${product.productPrice}. If you choose to pay via Klarna Pay in 30 Days (available in the UK only), neither Klarna nor size? will place a pre-authorisation hold on your payment card. Payment will be taken automatically if you win the draw.</p>
      <ol>
      <li>This draw is for the chance to purchase the ${product.productTitle} (the &ldquo;<strong>Item</strong>&rdquo;).</li>
      <li>Entrants must be 18 or over, with a registered size? account on the App.</li>
      <li>Registration details cannot be amended after entry. These details will be used if you win the draw.</li>
      <li>A winning entry makes it possible to purchase a certain product, but any purchases are subject to the size? <a href="https://www.size.co.uk/customer-service/termsandconditions/">Terms and Conditions: Online Sale of Goods</a>.</li>
      <li>Only one winning entry per person, per draw.</li>
      <li>You may only enter the ${product.instoreName} draw once (although this will not affect eligible bonus entries). For the avoidance of doubt, you may enter multiple different size? store location draws however in the event that you win, you must be able to collect the Item from the specific size? store within seven (7) days from being notified of that your payment has been processed by size?. You cannot nominate another person to collect the Item on your behalf. You must have photo ID on you for identification purposes when collecting the Item.</li>
      <li>Entries are not transferable.</li>
      </ol>
      <p>Winning customers will only be eligible to collect the ${product.productTitle} from the ${product.instoreName} at ${product.instoreAddress} store if we are able to process payment using the details provided.</p>
      <p><strong>THE PRIZE IS NOT FOR DELIVERY. YOU MUST COLLECT THE ITEM IN PERSON FROM THE SPECIFIED SIZE? STORE WITHIN 7 DAYS OF BEING NOTIFIED BY SIZE? THAT YOUR PAYMENT HAS BEEN PROCESSED. YOU WILL NOT BE ABLE TO NOMINATE ANYONE ELSE TO COLLECT THE PRIZE. IN THE EVENT YOU DO NOT COLLECT YOUR PRIZE, SIZE? WILL SELECT AN ALTERNATIVE WINNER. THIS DOES NOT AFFECT YOUR STATUTORY RIGHTS.</strong></p>
      <p><strong><u>Draw Terms and Conditions</u></strong></p>
      <p>By taking part in this draw you accept and agree to these Draw Terms and Conditions. If you do not agree with any of the Draw Terms and Conditions, then you should not take part in the draw. It is your responsibility to ensure that you review the Draw Terms and Conditions before entering the draw. We, JD Sports Fashion plc t/a size? (&ldquo;<strong>size?</strong>&rdquo;), recommend that you print and store or save a copy of these terms and conditions for future reference. size? is the promoter of this promotion.</p>
      <ol>
      <li><strong><u>What can you win?</u></strong></li>
      </ol>
      <p>Winners will each win a chance to purchase the ${product.productTitle} (the &ldquo;<strong>Chance to Purchase</strong>&rdquo;).</p>
      <p>The Chance to Purchase is subject to availability (including availability of sizes, styles and colours). The Chance to Purchase may not be exchanged for a cash value, nor is it transferable. The Chance to Purchase is subject to winner confirmation (i.e. size? has been able to contact winners and has been able to confirm eligibility) and validity of the entry details (including size?&rsquo;s ability to process payment).</p>
      <p>size? has the right to change, alter or withdraw the draw at any time due to any change in any applicable law or any events outside the control of size?. size? shall not be responsible for any delay, cancellation or rescheduling of the draw if it cannot be conducted as planned. The Chance to Purchase does not increase or decrease based on the payment method you choose.</p>
      <ol>
      <li><strong><u>Who can Enter?</u></strong></li>
      </ol>
      <p>This draw is available to individuals who are aged 18 or over with a registered size? account on the App and a valid address and postcode. If we are unable to verify any of your details, your entry will be void. Entrants must have access to the internet. Internet service providers&rsquo; fees may apply when accessing the internet. Entrants may only enter once per draw. Entrants must not attempt to enter the draw via more than one size?access account. If more than one entry from a household and/or customer is received, only the first entrant will be accepted. No purchase necessary to enter. Payment will only be taken if the customer is a winner.</p>
      <p>size? reserves the right to ask the winners to provide proof of age. Employees (and their immediate family) of the size? group (<a href="https://www.jdplc.com/our-group">www.jdplc.com/our-group</a>), or anyone else professionally connected with this draw are not eligible to enter the draw. size? reserves the right (at its sole discretion) to decide if the eligibility criteria are met. size? will not be responsible for entries that are lost, delayed, misdirected or incomplete or cannot be delivered or entered for any technical or other reason. If an entrant has violated any of these Draw Terms and Conditions, then an alternative entrant may be selected, at the discretion of size?.</p>
      <ol>
      <li><strong><u>Entries</u></strong></li>
      </ol>
      <p>All entries have an equal chance of winning but size?access members who enter a draw will automatically have three entries for each draw that they enter and Size?access+ members will automatically have five entries for each draw that they enter. Size?access membership and size?access+ status is free and is subject to the size?access terms and conditions, available here: <a href="http://www.size.co.uk/customer-service/sizeaccess/">http://www.size.co.uk/customer-service/sizeaccess/</a>. For more details about size?access membership and how to achieve size?access+ status please see below:.</p>
      <p><strong><u>Are you eligible?</u></strong></p>
      <p>size?access membership is only available to individuals aged 18 years and older with a valid size?launches account.</p>
      <p><strong><u>How do I sign up?</u></strong></p>
      <p>To become a member of size?access you can sign up on either the size? app or our size?launches app. Simply go to account preferences and sign up.</p>
      <p>As a size?access member you will automatically be given three entries to each draw to boost your chances of winning each draw you enter. You can also qualify for size?access+ status which gives you five entries to selected draws (details and restrictions are below).</p>
      <p><strong><u>What is size?access+</u></strong></p>
      <p>size?access+ is an enhanced temporary membership status that gives you 5 entries for each draw you enter.</p>
      <p>As a size?access member you can gain size?access+ for one week in your birthday week and your membership anniversary week. You can also &lsquo;cash in&rsquo; your sticker collections or achievement tokens to gain size?access+ boosts, which gives you size?access+ status for one draw entry of your choice (details below).</p>
      <p><strong><u>Birthday draw perks</u></strong></p>
      <p>During your birthday week, you&rsquo;ll gain temporary size?access+ status for 1 week. This will start on the Sunday of the week that your birthday falls and will end just before midnight on the Saturday after your birthday (for example, if your birthday is on a Monday, you will be granted temporary access from the Sunday 00.01am before your birthday to the Saturday 23.59 after your birthday). You will receive an email to advise you when your temporary size?access+ status is active and when it will expire. During this period, each draw that you enter will give you five entries! You&rsquo;ll be able to enter as many draws as you want during this week (although you can only enter a draw once), each one you enter will give you five entries for more chance of winning each &ndash; good luck!</p>
      <p><strong><u>Membership anniversary</u></strong></p>
      <p>On your size?access membership yearly anniversary, you&rsquo;ll gain temporary size?access+ status for 1 week. This will start on the Sunday of the week that your anniversary falls and will end just before midnight on the Saturday after your anniversary (for example, if your anniversary is on a Monday, you will be granted temporary access from the Sunday 00.01am before your anniversary to the Saturday 23.59 after your anniversary). You will receive an email to advise you when your size?access+ status is active and when it will expire. During this period, each draw that you enter will give you five entries! You&rsquo;ll be able to enter as many draws as you want during this week (although you can only enter a draw once), each one you enter will give you five entries for more chance of winning each &ndash; good luck!</p>
      <p><strong><u>Achievement tokens and sticker collection</u></strong></p>
      <p>There will be the opportunity to collect a range of electronic stickers and gain achievement tokens. We explain what electronic stickers and achievement tokens are and how to obtain them here: <a href="https://www.size.co.uk/page/sizeaccess">https://www.size.co.uk/page/sizeaccess</a>. When you unlock these &ndash; you&rsquo;ll gain a size?access+ boost. This boost grants you temporary size access+ status for one draw. You can use your size?access+ boost on any draw you choose to enter, this will give you five entries in that particular draw, giving you more chance of winning. These boosts can be collected and - if you aren&rsquo;t lucky with the draw &ndash; they will be returned to you once the draw ends and you&rsquo;ll be able to use them again on another draw of your choice, until you are a winner.</p>
      <p>Electronic stickers and achievement tokens can be collected to use whenever you like (although they can&rsquo;t be used together at the same time), and if you aren&rsquo;t lucky with the draw you entered, the boost will be returned to you at the end of the draw for you to use again during the period that your size?access+ status is active. You are only eligible to win once for each draw you enter.</p>
      <p><strong><u>What are stickers</u></strong></p>
      <p>Stickers are rewarded and available for you to collect when you win a draw for a particular collection or style. When you collect 5 draw stickers of a specific collection or style you will be rewarded with a size?access+ boost.</p>
      <p><strong><u>What are achievement tokens</u></strong></p>
      <p>Achievement tokens are rewarded to you after you have won a selected number of draw milestones &ndash; these will be available to you on winning multiple draws at the following intervals: 5, 10, 25, 50, 75, 100, 125, 150, 200 draws (for example, when you win 5 draws, you will be given an achievement token). When you collect each achievement token, you will be rewarded with a size?access+ boost. More details here: <a href="https://www.size.co.uk/page/sizeaccess">https://www.size.co.uk/page/sizeaccess</a>.</p>
      <p><strong>Entries to draws </strong></p>
      <p>Entrants may only enter each draw once, we will automatically boost your entry for you depending if you are an eligible size?access member or have size?access+ status and have selected the correct option at the time of entry. Entrants will have the following maximum entries to each draw depending on their membership status:</p>
      <p>non-member = 1 entry to each draw</p>
      <p>size?access member = 3 entries to each draw</p>
      <p>size?access+ status = 5 entries to each draw</p>
      <p>(&ldquo;<strong>Entry Limit</strong>&rdquo;)</p>
      <p>You will be given applicable bonus entries for a boosted chance of winning each draw that you enter however please note that you are only eligible to win once per draw. For example, if you enter a draw as a size?access member, you will automatically be given 3 entries into the draw, but even if you have multiple winning entries, you will only be able to win one Chance to Purchase.</p>
      <p>Please note, bonus entries applied to size?access members and size?access+ status holders will not be applicable to any draws associated with a charity or charitable causes.</p>
      <p>Entrants can only enter each draw once (we will automatically provide the applicable multiple entries if you are eligible and the correct option is selected at the time you enter) and entries cannot be split, transferred or be used in conjunction with other entries and will at all times be subject to the Entry Limit.</p>
      <p>Each entry will constitute a single entry in the draw and will be treated exactly the same as any other entry to the draw (including being subject to the Entry Limit) and will have the same chance of winning as any other entry. Entries may not be exchanged for a cash value, nor are they transferable. In any event, entrants will only have a maximum of five entries to each draw.</p>
      <ol>
      <li><strong><u>How to Enter</u></strong></li>
      </ol>
      <p><strong>Step 1: </strong>Scan the size?launches QR code instore at ${product.instoreName} at ${product.instoreAddress} and log in to the <strong>size?launches</strong> app or log into the size?launches app directly.</p>
      <p><strong>Step 2:</strong> Locate the ${product.productTitle} ${product.instoreName} draw page.</p>
      <p><strong>Step 3:</strong> Enter your date of birth, preferred size, preferred payment method, valid payment details, and a valid address and postcode on the ${product.productTitle} ${product.instoreName} draw page before the expiry of the countdown timer for that draw. We cannot amend your details after entry.</p>
      <p><strong>Step 4:</strong></p>
      <ul>
      <li><u>Paying by credit or debit card:</u> a pre-authorisation hold for ${product.productPrice} will be placed on your payment card. We will only take payment if you are selected.</li>
      <li><u>Paying in via Klarna Pay in 3*:</u> a pre-authorisation hold for the first instalment will be placed on your payment card and the remaining instalments will be taken via the selected payment instalment schedule. Klarna will only take payment if you are selected.</li>
      <li><u>Paying via Klarna Pay 30 in days*:</u> Neither Klarna nor us will place a pre-authorisation hold on your payment card.</li>
      </ul>
      <p><strong>Step 5:</strong> If you are selected, we will send you an email within 24 hours of the close of the draw confirming that you have won the Chance to Purchase and your payment will be processed as set out below. If you are not selected, your held payment will be released after the draw has ended and may take 3-5 days to appear in your bank account depending on your bank.</p>
      <ul>
      <li><u>Paying by credit or debit card:</u> we will process the payment within 24 hours of the close of the draw.</li>
      </ul>
      <ul>
      <li><u>Paying via Klarna Pay in 3*:</u> Klarna will process your first instalment upon dispatch and the remaining instalments will be taken via the selected payment instalment schedule.</li>
      </ul>
      <ul>
      <li><u>Paying via Klarna Pay in 30 days*:</u> Klarna will process your payment 30 days from the date of dispatch.</li>
      </ul>
      <p>*Payments made via Klarna are accepted in the UK only and are subject to Klarna&rsquo;s terms: see <a href="https://cdn.klarna.com/1.0/shared/content/legal/terms/0/en_gb/slice_it_card/">Klarna Pay in 3 T&amp;Cs </a>and <a href="https://cdn.klarna.com/1.0/shared/content/legal/terms/0/en_gb/pay_after_delivery/">Klarna Pay Later T&amp;Cs</a>.</p>
      <p><strong>Step 6:</strong> head to the ${product.instoreName} store at ${product.instoreAddress} to collect the ${product.productTitle}. The Item will be held for collection for seven (7) days after your payment has been processed by size? and confirmation of payment has been given to you. You must have a valid form of photo ID to be able to collect the Item.</p>
      <ol>
      <li><strong><u>Closing Times</u></strong></li>
      </ol>
      <p>Any entries received after the draw closing time will not be valid.</p>
      <ol>
      <li><strong><u>How are Winners Selected?</u></strong></li>
      </ol>
      <p>Winners will be selected at random based on all entries received for each of the sizes available. The decision of size? is final and binding on all entrants. No correspondence will be entered into regarding the selection of the winners (other than with the winners themselves). Entrants will be notified via email confirming whether they have won the Chance to Purchase or not, within 48 hours of the draw closing. The odds of receiving eligibility to purchase the launch product depends on the number of eligible entries received and availability of shoe sizes.</p>
      <p>For the name and county of the winners please send a self-addressed envelope to <strong>${product.productTitle} Size? Draw, JD Sports Fashion plc, Marketing Department, Hollinsbrook Way, Pilsworth, Bury, Lancashire, BL9 8RR</strong>.</p>
      <p><strong>size? reserves the right to: (i) withdraw the Chance to Purchase or refuse purchase of the Item if a winner breaches any of the terms in these terms and conditions or if they are found to have acted in a dishonest or fraudulent manner; and (ii) blacklist from future draws any person who enters, or who size? believes has attempted to enter the draw more than once and/or who size? believes is engaging in, or is found to have engaged in, dishonest or fraudulent activity or</strong><strong>has attempted to cheat or abuse the process, including through use of software that allows users to automate their entries, or engaged in behaviour that size? deems as inappropriate.</strong></p>
      <ol>
      <li><strong><u>Delivery and Returns</u></strong></li>
      </ol>
      <p>The purchase of the Item is subject to the size? Terms and Conditions (<a href="https://www.size.co.uk/customer-service/terms/">www.size.co.uk/customer-service/terms/</a>) and these Draw Terms and Conditions. In the event of any conflict between the size? Terms and Conditions and these Draw Terms and Conditions, these Draw Terms and Conditions will apply.</p>
      <p>Upon receiving valid payment, the Item will be available to collect from the ${product.instoreName} store at ${product.instoreAddress} and will be available for collection by you for seven (7) days. size? will not be responsible for delivering the Item to you in the event that you are unable to collect it from the size? store. You must collect the Item yourself in person and no other person can collect the Item on your behalf. If the Item is not collected within seven (7) days of valid payment, size? shall have the right to select an alternative winner. You must have a valid form of photo ID to be able to collect the Item.</p>
      <p>size? will not offer a replacement for an Item under any circumstances (including but not limited to non-delivery), this does not affect your statutory rights.</p>
      <ol>
      <li><strong><u>Winners&rsquo; Responsibilities</u></strong></li>
      </ol>
      <p>It is the winner&rsquo;s responsibility to: (i) complete all stages of the &lsquo;How to Enter&rsquo; section above; (ii) provide accurate contact details; (iii) provide valid proof of age promptly upon request (minimum age 18); (iv) adhere to local laws in the territory in which the winner resides; (vi) comply with any rules, instructions, requirements, terms and conditions or regulations of the size?; (v) pay for all costs (including but not limited to transport costs) incurred to collect the Item from the size? store. size? will not be liable to the winner or any other persons where they fail to comply with such responsibilities and any such failure may result in forfeiture of the Chance to Purchase.</p>
      <ol>
      <li><strong><u>Personal Information</u></strong></li>
      </ol>
      <p>By ticking the appropriate opt-in box(es) you agree that you will be opted in to receive regular communication from size? (and its affiliates). For a list of size? affiliates who may send marketing communications, please click on this link: <a href="https://www.jdplc.com/our-group">www.jdplc.com/our-group</a>. size? will use personal information which you provide, or which we obtain through our dealings with you, to sign you up to marketing materials provided by size? (and its affiliates) and to administer the draw. We may also use your personal data to tell you about size?&rsquo;s (and size? affiliates&rsquo;) products and offers, and for market research including analysis and development of our products and customer relationships. For full details on how size? uses your information, view our Privacy Policy here: <a href="http://www.size.co.uk/customer-service/privacy/">www.size.co.uk/customer-service/privacy/</a>. You can unsubscribe at any time by following the instructions contained in the promotional emails. If you do not wish to receive marketing communication from size? (and size? affiliates) please do not tick the appropriate opt-in box(es) above.</p>
      <ol>
      <li><strong><u>Changes </u></strong></li>
      </ol>
      <p>Size? may amend these Draw Terms and Conditions at any time by posting the amended Draw Terms and Conditions on the size? website and you agree that you will be bound by any changes to these Draw Terms and Conditions from the date they are published on the size? website. However, the changes will not apply to any draws that you have already entered. The date of last revision of these Draw Terms and Conditions is included at the top of this page.</p>
      <ol>
      <li><strong><u>Liability </u></strong></li>
      </ol>
      <p>Insofar as is permitted by law, size? will not in any circumstances be responsible or liable to compensate the winner or accept any liability for any loss, damage, personal injury or death occurring as a result of taking up the&nbsp;Chance to Purchase&nbsp;except where it is caused by the negligence of size? Your legal rights are not affected.</p>
      <ol>
      <li><strong><u>Publicity</u></strong></li>
      </ol>
      <p>By taking part in the draw, entrants agree to participate in publicity at size?&rsquo;s request if they are a winner of the draw. Entrants agree that size? (or any third party nominated by size?) may in its sole discretion use their name, image, any relevant video footage of them and comments relating to the draw and their experience for future promotional, marketing and publicity purposes in any media worldwide without notice and without any fee being paid (including for the avoidance of doubt when responding to any third party).</p>
      <p>If you wish to contact size? in relation to the draw, please use the following address: <strong>${product.productTitle} size? Draw, JD Sports Fashion plc, Edinburgh House, Hollinsbrook Way, Pilsworth, Bury, Lancashire, BL9 8RR, United Kingdom.</strong></p>
      `
            let template = ''
            template += '<div class="raffle-copy">'
            template += `<p>${inStoreRaffleCopy}</p>`
            template += '</div>'
            return template
        }

        function defaultTemplate(product) {
            const defaultRaffleCopy = {
                drawTnC: [{
                        paragraph: `<p>You can enter the ${product.productTitle} draw via the size?launches app by logging in and entering your date of birth, preferred size, valid payment details, preferred delivery method (please note delivery times are calculated from the launch date) and a valid delivery address and postcode on the releavntdraw page. Draws are only open for fixed periods as shown on the size?launches app (â€œAppâ€) and a countdown timer will display the time remaining to enter the draw. The draw will close when the countdown timer expires. Once you have submitted your details and if you choose to pay using a credit or debit card or via Klarna Pay in 3 (available in the UK only), we or Klarna (as applicable) will place a hold on your payment card for the price of the ${product.productTitle}, ${product.productPrice} , plus the applicable delivery fees. If you choose to pay via Klarna Pay in 30 Days (available in the UK only), neither Klarna nor size? will place a pre-authorisation hold on your payment card. Payment will be taken automatically if you win the draw.</p>`,
                        ol: [
                            'Entrants must be 18 or over, with a registered size? account on the App.',
                            'Registration details cannot be amended after entry. These details will be used if you win the draw.',
                            'A winning entry makes it possible to purchase a certain product, but any purchases are subject to the size?Terms and Conditions: Online Sale of Goods.',
                            'Only one winning entry per household, per draw.',
                            'You may only enter the draw once (although this will not affect eligible bonus entries).',
                            'Entries are not transferable.',
                            `Winning customers will only receive the ${product.productTitle} if we are able to process payment using the details provided.`,
                        ],
                    },
                    {
                        title: `<h2><u>Draw Terms and Conditions</u></h2>`,
                    },
                    {
                        title: '1. What can you win?',
                        paragraphs: [
                            `Winners will each win a chance to purchase the ${product.productTitle} (the â€œChance to Purchaseâ€).`,
                            'The Chance to Purchase is subject to availability (including availability of sizes, styles and colours). The Chance to Purchase may not be exchanged for a cash value, nor is it transferable. The Chance to Purchase is subject to winner confirmation (i.e. size? has been able to contact winners and has been able to confirm eligibility) and validity of the entry details (including size?â€™s ability to process payment).',
                            'size? has the right to change, alter or withdraw the draw at any time due to any change in any applicable law or any events outside the control of size?. size? shall not be responsible for any delay, cancellation or rescheduling of the draw if it cannot be conducted as planned. The Chance to Purchase does not increase or decrease based on the payment method you choose.',
                        ],
                    },
                    {
                        title: '2. Who can Enter?',
                        paragraphs: [
                            'This draw is available to individuals who are resident in the UK, aged 18 or over with a registered size? account on the App and a valid address and postcode. If we are unable to verify any of your details, your entry will be void. Entrants must have access to the internet. Internet service providersâ€™ fees may apply when accessing the internet. Entrants may only enter once per draw and are limited to one customer per household. Entrants must not attempt to enter the draw via more than one size?access account. If more than one entry from a household and/or customer is received, only the first entrant will be accepted. No purchase necessary to enter. Payment will only be taken if the customer is a winner.',
                            `size? reserves the right to ask the winners to provide proof of age. Employees (and their immediate family) of the size? group (${jdGroupLink}), or anyone else professionally connected with this draw are not eligible to enter the draw. size? reserves the right (at its sole discretion) to decide if the eligibility criteria are met. size? will not be responsible for entries that are lost, delayed, misdirected or incomplete or cannot be delivered or entered for any technical or other reason. If an entrant has violated any of these Draw Terms and Conditions, then an alternative entrant may be selected, at the discretion of size?.`,
                        ],
                    },
                    {
                        title: '3. Entries',
                        paragraph: `All entries have an equal chance of winning but size?access members who enter a draw will automatically have three entries for each draw that they enter and Size?access+ members will automatically have five entries for each draw that they enter. Size?access membership and size?access+ status is free and is subject to the size?access terms and conditions, available here: ${customerServiceLink}. For more details about size?access membership and how to achieve size?access+ status please see below:.`,
                        items: [{
                                title: 'Are you eligible?',
                                paragraph: 'size?access membership is only available to individuals aged 18 years and older and resident in the UK.',
                            },
                            {
                                title: 'How do I sign up?',
                                paragraphs: [
                                    'To become a member of size?access you can sign up on either the size? app or our size?launches app. Simply go to account preferences and sign up.',
                                    'As a size?access member you will automatically be given three entries to each draw to boost your chances of winning each draw you enter. You can also qualify for size?access+ status which gives you five entries to selected draws (details and restrictions are below).',
                                ],
                            },
                            {
                                title: 'What is size?access+',
                                paragraphs: [
                                    'size?access+ is an enhanced temporary membership status that gives you 5 entries for each draw you enter.',
                                    'As a size?access member you can gain size?access+ for one week in your birthday week and your membership anniversary week. You can also â€˜cash inâ€™ your sticker collections or achievement tokens to gain size?access+ boosts, which gives you size?access+ status for one draw entry of your choice (details below).',
                                ],
                            },
                            {
                                title: 'Birthday draw perks',
                                paragraph: 'During your birthday week, youâ€™ll gain temporary size?access+ status for 1 week, starting with the date of your birthday and ending just before midnight on the sixth day after your birthday (for example: if your birthday is on Monday, you will be granted temporary size?access+ status until 23:59 on the following Sunday). You will receive an email to advise you when your temporary size?access+ status is active and when it will expire. During this period, each draw that you enter will give you five entries! Youâ€™ll be able to enter as many draws as you want during this week (although you can only enter a draw once), each one you enter will give you five entries for more chance of winning each â€“ good luck!',
                            },
                            {
                                title: 'Membership anniversary',
                                paragraph: 'On your size?access membership yearly anniversary, youâ€™ll gain temporary size?access+ status for 1 week, starting with the date of your anniversary and ending just before midnight on the sixth day after your anniversary (for example: if your anniversary is on Monday, you will be granted temporary size?access+ status until 23:59 on the following Sunday). You will receive an email to advise you when your size?access+ status is active and when it will expire. During this period, each draw that you enter will give you five entries! Youâ€™ll be able to enter as many draws as you want during this week (although you can only enter a draw once), each one you enter will give you five entries for more chance of winning each â€“ good luck!',
                            },
                            {
                                title: 'Achievement tokens and sticker collection',
                                paragraphs: [
                                    `There will be the opportunity to collect a range of electronic stickers and gain achievement tokens. We explain what electronic stickers and achievement tokens are and how to obtain them here: ${sizeAccessLink}. When you unlock these â€“ youâ€™ll gain a size?access+ boost. This boost grants you temporary size access+ status for one draw. You can use your size?access+ boost on any draw you choose to enter, this will give you five entries in that particular draw, giving you more chance of winning. These boosts can be collected and - if you arenâ€™t lucky with the draw â€“ they will be returned to you once the draw ends and youâ€™ll be able to use them again on another draw of your choice, until you are a winner.`,
                                    'Electronic stickers and achievement tokens can be collected to use whenever you like (although they canâ€™t be used together at the same time), and if you arenâ€™t lucky with the draw you entered, the boost will be returned to you at the end of the draw for you to use again during the period that your size?access+ status is active. You are only eligible to win once for each draw you enter.',
                                ],
                            },
                            {
                                title: 'What are stickers',
                                paragraph: 'Stickers are rewarded and available for you to collect when you win a draw for a particular collection or style. When you collect 5 draw stickers of a specific collection or style you will be rewarded with a size?access+ boost.',
                            },
                            {
                                title: 'What are achievement tokens',
                                paragraphs: [
                                    `Achievement tokens are rewarded to you after you have won a selected number of draw milestones â€“ these will be available to you on winning multiple draws at the following intervals: 5, 10, 25, 50, 75, 100, 125, 150, 200 draws (for example, when you win 5 draws, you will be given an achievement token). When you collect each achievement token, you will be rewarded with a size?access+ boost. More details here: ${sizeAccessLink}`,
                                    'Entries to draws',
                                    'Entrants may only enter each draw once, we will automatically boost your entry for you depending if you are an eligible size?access member or have size?access+ status and have selected the correct option at the time of entry. Entrants will have the following maximum entries to each draw depending on their membership status:',
                                    'non-member = 1 entry to each draw',
                                    'size?access member = 3 entries to each draw',
                                    'size?access+ status = 5 entries to each draw',
                                    '("Entry Limit")',
                                    'You will be given applicable bonus entries for a boosted chance of winning each draw that you enter however please note that you are only eligible to win once per draw. For example, if you enter a draw as a size?access member, you will automatically be given 3 entries into the draw, but even if you have multiple winning entries, you will only be able to win one Chance to Purchase.',
                                    'Please note, bonus entries applied to size?access members and size?access+ status holders will not be applicable to any draws associated with a charity or charitable causes.',
                                    'Entrants can only enter each draw once (we will automatically provide the applicable multiple entries if you are eligible and the correct option is selected at the time you enter) and entries cannot be split, transferred or be used in conjunction with other entries and will at all times be subject to the Entry Limit.',
                                    'Each entry will constitute a single entry in the draw and will be treated exactly the same as any other entry to the draw (including being subject to the Entry Limit) and will have the same chance of winning as any other entry. Entries may not be exchanged for a cash value, nor are they transferable. In any event, entrants will only have a maximum of five entries to each draw.',
                                ],
                            },
                        ],
                    },
                    {
                        title: '4.How to Enter',
                        steps: [{
                                title: 'Step 1',
                                paragraph: 'Log in to the <b>size?launches</b> app.',
                            },
                            {
                                title: 'Step 2',
                                paragraph: `Locate the ${product.productTitle} draw page.`,
                            },
                            {
                                title: 'Step 3',
                                paragraph: `Enter your date of birth, preferred size, preferred payment method, valid payment details, preferred delivery method (please note delivery times are calculated from the launch date) and a valid delivery address and postcode on the ${product.productTitle} draw page before the expiry of the countdown timer for that draw. We cannot amend your details after entry.`,
                            },
                            {
                                title: 'Step 4',
                                ul: [
                                    `<u>Paying by credit or debit card:</u> a pre-authorisation hold for ${product.productPrice} plus the applicable delivery fees will be placed on your payment card. We will only take payment if you are selected.`,
                                    '<u>Paying in via Klarna Pay in 3*:</u> a pre-authorisation hold for the first instalment will be placed on your payment card and the remaining instalments will be taken via the selected payment instalment schedule. Klarna will only take payment if you are selected.',
                                    '<u>Paying via Klarna Pay in 30 days*</u> Neither Klarna nor us will place a pre-authorisation hold on your payment card.',
                                ],
                            },
                            {
                                title: 'Step 5',
                                paragraph: 'If you are selected, we will send you an email within 24 hours of the close of the draw confirming that you have won the Chance to Purchase and your payment will be processed as set out below. If you are not selected, your held payment will be released after the draw has ended and may take 3-5 days depending on your bank.',
                                ul: [
                                    '<u>Paying by credit or debit card:</u> we will process the payment within 24 hours of the close of the draw.',
                                    '<u>Paying via Klarna Pay in 3*:</u> Klarna will process your first instalment upon dispatch and the remaining instalments will be taken via the selected payment instalment schedule.',
                                    '<u>Paying via Klarna Pay in 30 days*:</u> Klarna will process your payment 30 days from the date of dispatch.',
                                ],
                            },
                            {
                                paragraph: '*Payments made via Klarna are accepted in the UK only and are subject to Klarnaâ€™s terms: see Klarna Pay in 3 T&Cs and Klarna Pay Later T&Cs.',
                            },
                            {
                                title: 'Step 6',
                                paragraph: `Sit back and wait for your ${product.productTitle} to arrive. The Item will be delivered using the delivery method selected at entry`,
                            },
                        ],
                    },
                    {
                        title: '5. Closing Times',
                        paragraph: 'Any entries received after the draw closing time will not be valid.',
                    },
                    {
                        title: '6. How are Winners Selected?',
                        paragraphs: [
                            'Winners will be selected at random based on all entries received for each of the sizes available. The decision of size? is final and binding on all entrants. No correspondence will be entered into regarding the selection of the winners (other than with the winners themselves). Entrants will be notified via email confirming whether they have won the Chance to Purchase or not, within 24 hours of the draw closing. The odds of receiving eligibility to purchase the launch product depends on the number of eligible entries received and availability of shoe sizes.',
                            `For the name and county of the winners please send a self-addressed envelope to ${product.productTitle} Draw, JD Sports Fashion plc, Marketing Department, Hollinsbrook Way, Pilsworth, Bury, Lancashire, BL9 8RR.`,
                            'size? reserves the right to: (i) withdraw the Chance to Purchase or refuse purchase of the Item if a winner breaches any of the terms in these terms and conditions or if they are found to have acted in a dishonest or fraudulent manner; and (ii) blacklist from future draws any person who enters, or who size? believes has attempted to enter the draw more than once and/or who size? believes is engaging in, or is found to have engaged in, dishonest or fraudulent activity or has attempted to cheat or abuse the process, including through use of software that allows users to automate their entries, or engaged in behaviour that size? deems as inappropriate.',
                        ],
                    },
                    {
                        title: '7. Delivery and Returns',
                        paragraphs: [
                            `The purchase of the Item is subject to the size? Terms and Conditions (${termsLink}) and these Draw Terms and Conditions. In the event of any conflict between the size? Terms and Conditions and these Draw Terms and Conditions, these Draw Terms and Conditions will apply.`,
                            `Upon receiving valid payment, we will deliver the item in accordance with the delivery method selected by the winner at the checkout. Delivery times will be calculated from the launch date. For more delivery information, please see ${deliveryLink}.`,
                            'size? will not offer a replacement for an Item under any circumstances (including but not limited to non-delivery), this does not affect your statutory rights.',
                        ],
                    },
                    {
                        title: '8. Winners Responsibilities',
                        paragraph: 'It is the winnerâ€™s responsibility to: (i) complete all stages of the â€˜How to Enterâ€™ section above; (ii) provide accurate contact details; (iii) provide valid proof of age promptly upon request (minimum age 18); (iv) adhere to local laws in the territory in which the winner resides; and (vi) comply with any rules, instructions, requirements, terms and conditions or regulations of the size?. size? will not be liable to the winner or any other persons where they fail to comply with such responsibilities and any such failure may result in forfeiture of the Chance to Purchase.',
                    },
                    {
                        title: '9. Personal Information',
                        paragraph: `By ticking the appropriate opt-in box(es) you agree that you will be opted in to receive regular communication from size? (and its affiliates). For a list of size? affiliates who may send marketing communications, please click on this link: ${jdGroupLink}. size? will use personal information which you provide, or which we obtain through our dealings with you, to sign you up to marketing materials provided by size? (and its affiliates) and to administer the draw. We may also use your personal data to tell you about size?â€™s (and size? affiliatesâ€™) products and offers, and for market research including analysis and development of our products and customer relationships. For full details on how size? uses your information, view our Privacy Policy here: ${privacyLink}. You can unsubscribe at any time by following the instructions contained in the promotional emails. If you do not wish to receive marketing communication from size? (and size? affiliates) please do not tick the appropriate opt-in box(es) above.`,
                    },
                    {
                        title: '10. Changes',
                        paragraph: 'Size? may amend these Draw Terms and Conditions at any time by posting the amended Draw Terms and Conditions on the size? website and you agree that you will be bound by any changes to these Draw Terms and Conditions from the date they are published on the size? website. However, the changes will not apply to any draws that you have already entered. The date of last revision of these Draw Terms and Conditions is included at the top of this page.',
                    },
                    {
                        title: '11. Liability',
                        paragraph: 'Insofar as is permitted by law, size? will not in any circumstances be responsible or liable to compensate the winner or accept any liability for any loss, damage, personal injury or death occurring as a result of taking up the Chance to Purchase except where it is caused by the negligence of size? Your legal rights are not affected.',
                    },
                    {
                        title: '12. Publicity',
                        paragraphs: [
                            'By taking part in the draw, entrants agree to participate in publicity at size?â€™s request if they are a winner of the draw. Entrants agree that size? (or any third party nominated by size?) may in its sole discretion use their name, image, any relevant video footage of them and comments relating to the draw and their experience for future promotional, marketing and publicity purposes in any media worldwide without notice and without any fee being paid (including for the avoidance of doubt when responding to any third party).',
                            `If you wish to contact size? in relation to the draw, please use the following address: ${product.productTitle} Draw, JD Sports Fashion plc, Edinburgh House, Hollinsbrook Way, Pilsworth, Bury, Lancashire, BL9 8RR, United Kingdom`,
                        ],
                    },
                ],
            }

            let template = ''
            template += '<div class="raffle-copy">'
            template += `<p>${buildTnC(defaultRaffleCopy.drawTnC)}</p>`
            template += '</div>'
            return template
        }

        function premiumTemplate(product) {
            const premiumRaffleCopy = {
                header: `You can enter this competition via the size?launches app (â€œAppâ€) by logging in, navigating to the relevant draw page, entering your date of birth, a valid delivery address and postcode and valid payment details to pay the Â£1.00 entry fee (â€œEntry Feeâ€) which will be donated to â€˜julietspositivepants - JustGivingâ€™. The Competition will open on Tuesday 12 October 2021 at 12pm GMT and close on Monday 18 October 2021 at 12pm GMT (â€œEntry Periodâ€).`,
                headerOrderedList: [
                    'Entrants must be 18 or over, with a registered size? account on the App.',
                    'You may enter as many times as you wish, however this does not guarantee a win.',
                    'Entries are not transferable. The winner will only receive the Prize (as described in section 1 below) if we are able to process payment using the details provided.',
                ],
                drawTnC: [{
                        title: `<h2><u>Draw Terms and Conditions</u></h2>`,
                        paragraph: 'By taking part in this competition you accept and agree to these terms and conditions. If you do not agree with any of these terms and conditions then you should not take part in the competition. It is your responsibility to ensure that you review the terms and conditions before entering the competition. We, JD Sports Fashion plc t/a size? (â€œsize?â€), recommend that you print and store or save a copy of these terms and conditions for future reference. size? is the promoter of this competition.',
                    },
                    {
                        title: '1. What can you win?',
                        paragraphs: [
                            'There will be 1 winner for each draw (the â€œPrizeâ€œ).',
                            'The Prize is subject to availability (including availability of sizes, styles and colours). The Prize may not be exchanged for a cash value, nor is it transferable. The Prize is subject to winner confirmation (i.e. size? has been able to contact the winner and has been able to confirm eligibility). size? has the right to change, alter or withdraw the competition or Prize at any time due to any change in any applicable law or any events outside the control of size?. size? shall not be responsible for any delay, cancellation or rescheduling of the Prize. If any part of the Prize is not claimed (for whatever reason), size? is under no obligation to supply an alternative prize.',
                        ],
                    },
                    {
                        title: '2. What is excluded from the Prize?',
                        paragraph: 'It is the winnersâ€™ responsibility to organise and pay for anything excluded from the Prize.',
                    },
                    {
                        title: '3. Who can Enter?',
                        paragraph: `Entrants must be aged 18 years or over and a with a registered account on the App and a valid address and postcode. If we are unable to verify any of your details, your entry will be void and you will not receive a refund of the Entry Fee. Entrants must have access to the internet. Entries are limited to one entry per household. size? reserves the right to ask the winners (if applicable) to provide proof of age. Employees (and their immediate family) of the size? group (${sportsFashionLink}), or anyone else professionally connected with this promotion are not eligible to enter the promotion. size? reserves the right (at its sole discretion) to decide if the eligibility criteria are met. If the eligibility criteria are not met, the entry will be invalid.`,
                    },
                    {
                        title: '4.How to Enter',
                        items: [{
                                title: 'Step 1',
                                paragraph: 'Log in to the <b>size?launches</b> app.',
                            },
                            {
                                title: 'Step 2',
                                paragraph: 'Locate the size?launches: Handmade decorations by Rosie Anwara in support of â€˜julietspositivepants - just givingâ€™ draw page (â€œDraw Pageâ€).',
                            },
                            {
                                title: 'Step 3',
                                paragraph: 'Enter your date of birth, preferred payment method valid payment details and a valid delivery address and postcode on the size?launches: Handmade decorations by Rosie Anwara in support of â€˜julietspositivepants - JustGivingâ€™ Draw Page during the Entry Period. We cannot amend your details after entry.',
                            },
                            {
                                title: 'Step 4',
                                paragraph: 'Answer the competition question that appears on the App.',
                            },
                            {
                                title: 'Step 5',
                                paragraph: `Pay a non-refundable Â£1.00 (one pound) entry fee. The Entry Fee will be donated directly to the â€˜julietspositivepantsâ€™ JustGiving page, which can be found at:</br></br>${justGivingLink}`,
                            },
                            {
                                title: 'Step 6',
                                paragraph: 'If you have won, we will be in touch using the contact details you provided with your entry to confirm your win.',
                            },
                        ],
                    },
                    {
                        title: '6. How are Winners Selected?',
                        paragraph: 'The winner will be selected at random based on the pool of the entrants that correctly answer the competition question at step 4 of the â€œHow to Enterâ€ section. The decision of size? is final and binding on all entrants. No correspondence will be entered into regarding the selection of the winner (other than with the winner themselves). The winner will be notified via email by on or around 18 October 2021.',
                    },
                    {
                        title: '7. Delivery and Returns',
                        paragraph: 'We will deliver the Prize via Royal Mail standard delivery.</br>size? will not offer a replacement for the Prize under any circumstances (including but not limited to non-delivery).',
                    },
                    {
                        title: "8. Winner's Responsibilities",
                        paragraph: 'It is the winnerâ€™s responsibility to: (i) complete all stages of the â€˜How to Enterâ€™ section above; (ii) provide accurate contact details; (iii) provide valid proof of age promptly upon request (minimum age 18); (iv) adhere to local laws in the territory in which the winner resides; and (vi) comply with any rules, instructions, requirements, terms and conditions or regulations of the size?. size? will not be liable to the winners or any other persons where they fail to comply with such responsibilities and any such failure may result in forfeiture of the Prize.',
                    },
                    {
                        title: '9. Personal Information',
                        paragraph: 'By ticking the appropriate opt-in box(es) you agree that you will be opted in to receive regular communication from size? (and its affiliates). For a list of size? affiliates who may send marketing communications, please click on this link:<a style="text-decoration: underline" href="www.jdplc.com/our-group" target="_blank">www.jdplc.com/our-group</a>. size? will use personal information which you provide, or which we obtain through our dealings with you, to sign you up to marketing materials provided by size? (and its affiliates) and to administer the competition. We may also use your personal data to tell you about size?â€™s (and size? affiliatesâ€™) products and offers, and for market research including analysis and development of our products and customer relationships. For full details on how size? uses your information, view our Privacy Policy here:<a style="text-decoration: underline" href="www.size.co.uk/customer-service/privacy/" target="_blank">www.size.co.uk/customer-service/privacy/</a>. You can unsubscribe at any time by following the instructions contained in the promotional emails. If you do not wish to receive marketing communication from size? (and size? affiliates) please do not tick the appropriate opt-in box(es) above.',
                    },
                    {
                        title: '10. Liability',
                        paragraph: 'Insofar as is permitted by law, size? will not in any circumstances be responsible or liable to compensate the winner or accept any liability for any loss, damage, personal injury or death occurring as a result of entering into this competition except where it is caused by the negligence of size? Your legal rights are not affected.',
                    },
                    {
                        title: '11. Publicity',
                        paragraphs: [
                            'By taking part in the competition, entrants may be invited to participate in publicity at size?â€™s request if they are a winner of the competition. Entrants agree that size? (or any third party nominated by size?) may in its sole discretion use their comments relating to the Prize and their experience for future promotional, marketing and publicity purposes in any media worldwide without notice and without any fee being paid (including for the avoidance of doubt when responding to any third party). Any use of images or other personal information that could identify entrants will be subject to the entrantsâ€™ consent.',
                            'If you wish to contact size? in relation to the competition, please use the following address: â€˜<a style="text-decoration: underline" href="https://www.justgiving.com/crowdfunding/julietspositivepants?utm_term=4qMZJ9bQ7" target="_blank">julietspositivepants -just giving</a>â€™ Competition, JD Sports Fashion plc (t/a size?), Edinburgh House, Hollinsbrook Way, Pilsworth, Bury, Lancashire, BL9 8RR, United Kingdom.',
                        ],
                    },
                ],
            }

            let template = ''
            template += '<div class="raffle-copy">'
            template += ``
            template += `<p>${generateListItems(
        premiumRaffleCopy.headerOrderedList,
      )}</p>`
            template += `<p>${buildTnC(premiumRaffleCopy.drawTnC)}</p>`
            template += '</div>'
            return template
        }

        function customTemplate(product, customData) {
            let template = ''
            template += '<div id="raffle-product-wrapper">'
            template += `<h1/>${product.productTitle}</h1>`
            template += '</div>'
            return template
        }

        function charityRaffle_quantity(product, templateQuantity) {
            const dateOptions = {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
            }
            const timeOptions = {
                timeZone: 'UTC',
                hour12: true,
                hour: '2-digit',
            }

            const entryUnixTime = new Date(product.entryDate).getTime()
            const entryDate = new Date(entryUnixTime).toLocaleDateString(
                'en-GB',
                dateOptions,
            )
            let entryTime = new Date(entryUnixTime).toLocaleTimeString(
                'en-GB',
                timeOptions,
            )

            if (entryTime == '00 pm') {
                entryTime = '12 pm'
            } else if (entryTime == '00 am') {
                entryTime = '12 am'
            }

            const closingUnixTime = new Date(product.closingDate).getTime()
            const closingDate = new Date(closingUnixTime).toLocaleDateString(
                'en-GB',
                dateOptions,
            )
            let closingTime = new Date(closingUnixTime).toLocaleTimeString(
                'en-GB',
                timeOptions,
            )
            if (closingTime == '00 pm') {
                closingTime = '12 pm'
            } else if (closingTime == '00 am') {
                closingTime = '12 am'
            }
            const charitytRaffleCopy = {
                drawTnC: [{
                        paragraph: `<p>You can enter this competition via the <b>size?launches</b>  app (â€œ<b>App</b>â€) by logging in, joining size access, navigating to the relevant launches page, entering your date of birth, a valid delivery address and postcode and valid payment details to pay the Â£1.00 entry fee (â€œ<b>Entry Fee</b>â€) which will be donated to â€˜<a style="text-decoration: underline" href="https://www.manchesteryz.org/">Manchester Youth Zoneâ€™</a>â€™'.  The Competition will open on ${entryDate} at ${entryTime} GMT and close on ${closingDate} at ${closingTime} GMT (â€œ<b>Entry Period</b>â€).   </p>`,
                        ol: [
                            'Entrants must be 18 or over, with a registered size? account on the App.',
                            'Signed up to size?access membership and logged in',
                            'You may enter as many times as you wish, however this does not guarantee a win.',
                            'Entries are not transferable. The winner will only receive the Prize (as described in section 1 below) if we are able to process payment using the details provided.',
                        ],
                    },
                    {
                        title: `<h2><u>Draw Terms and Conditions</u></h2>`,
                        paragraph: `By taking part in this competition you accept and agree to these terms and conditions. If you do not agree with any of these terms and conditions then you should not take part in the competition. It is your responsibility to ensure that you review the terms and conditions before entering the competition. We, JD Sports Fashion plc t/a size? (â€œsize?â€), recommend that you print and store or save a copy of these terms and conditions for future reference. size? is the promoter of this competition.`,
                    },
                    {
                        title: '1. What can you win?',
                        paragraphs: [
                            `There will be ${templateQuantity} ${
                templateQuantity > 1 ? 'winners' : 'winner'
              } who will win ${product.productTitle} (the â€œPrizeâ€œ).`,
                            `The Prize is subject to availability (including availability of sizes, styles and colours). The Prize may not be exchanged for a cash value, nor is it transferable. The Prize is subject to winner confirmation (i.e. size? has been able to contact the winner and has been able to confirm eligibility). size? has the right to change, alter or withdraw the competition or Prize at any time due to any change in any applicable law or any events outside the control of size?. size? shall not be responsible for any delay, cancellation or rescheduling of the Prize. If any part of the Prize is not claimed (for whatever reason), size? is under no obligation to supply an alternative prize.`,
                        ],
                    },
                    {
                        title: '2. What is excluded from the Prize?',
                        paragraphs: [
                            `It is the winnerâ€™s responsibility to organise and pay for anything excluded from the Prize.`,
                        ],
                    },
                    {
                        title: '3. Who can enter?',
                        paragraphs: [
                            `Entrants must be aged 18 years or over and a with a registered account on the App and a valid address and postcode. If we are unable to verify any of your details, your entry will be void and you will not receive a refund of the Entry Fee. Entrants must have access to the internet. Entries are limited to one entry per household.`,
                            `size? reserves the right to ask the winners (if applicable) to provide proof of age. size? reserves the right (at its sole discretion) to decide if the eligibility criteria are met. If the eligibility criteria are not met, the entry will be invalid`,
                        ],
                    },
                    {
                        title: '4.How to Enter',
                        steps: [{
                                title: 'Step 1',
                                paragraph: 'Log in to the <b>size?launches</b> app.',
                            },
                            {
                                title: 'Step 2',
                                paragraph: `Log in or join size?access if you are not already a member (more information on size access <a style="text-decoration: underline" href="/page/sizeaccess">here</a>)`,
                            },
                            {
                                title: 'Step 3',
                                paragraph: `Locate the size?launches: ${product.productTitle} draw page (â€œDraw Pageâ€).`,
                            },
                            {
                                title: 'Step 4',
                                paragraph: `Enter your date of birth, preferred payment method valid payment details and a valid delivery address and postcode on the size?launches: ${product.productTitle} Draw Page during the Entry Period.  We cannot amend your details after entry.`,
                            },
                            {
                                title: 'Step 5',
                                paragraph: 'Answer the competition question that appears on the App.',
                            },
                            {
                                title: 'Step 6',
                                paragraph: 'Pay a non-refundable Â£1.00 (one pound) entry fee. The Entry Fee will be donated directly to â€˜<a style="text-decoration: underline" href="https://www.manchesteryz.org/">Manchester Youth Zoneâ€™</a>â€™',
                            },
                            {
                                title: 'Step 7',
                                paragraph: 'If you have won, we will be in touch using the contact details you provided with your entry to confirm your win.',
                            },
                        ],
                    },
                    {
                        title: '5. Closing Times',
                        paragraph: 'Any entries received after the Entry Period will not be valid.',
                    },
                    {
                        title: '6. How are Winners Selected?',
                        paragraphs: [
                            `The winner will be selected at random based on the pool of the entrants that correctly answer the competition question at step 4 of the â€œHow to Enterâ€ section. The decision of size? is final and binding on all entrants. No correspondence will be entered into regarding the selection of the winner (other than with the winner themselves). The winner will be notified via email by on or around 15 January 2022 `,
                        ],
                    },
                    {
                        title: '7. Delivery and Returns',
                        paragraphs: [
                            `We will deliver the Prize via Royal Mail standard delivery.`,
                            `size? will not offer a replacement for the Prize under any circumstances (including but not limited to non-delivery).`,
                        ],
                    },
                    {
                        title: '8. Winners Responsibilities',
                        paragraph: 'It is the winnerâ€™s responsibility to: (i) complete all stages of the â€˜How to Enterâ€™ section above; (ii) provide accurate contact details; (iii) provide valid proof of age promptly upon request (minimum age 18); (iv) adhere to local laws in the territory in which the winner resides; and (vi) comply with any rules, instructions, requirements, terms and conditions or regulations of the size?. size? will not be liable to the winners or any other persons where they fail to comply with such responsibilities and any such failure may result in forfeiture of the Prize.',
                    },
                    {
                        title: '9. Personal Information',
                        paragraph: `By ticking the appropriate opt-in box(es) you agree that you will be opted in to receive regular communication from size? (and its affiliates). For a list of size? affiliates who may send marketing communications, please click on this link: ${jdGroupLink}. size? will use personal information which you provide, or which we obtain through our dealings with you, to sign you up to marketing materials provided by size? (and its affiliates) and to administer the draw. We may also use your personal data to tell you about size?â€™s (and size? affiliatesâ€™) products and offers, and for market research including analysis and development of our products and customer relationships. For full details on how size? uses your information, view our Privacy Policy here: ${privacyLink}. You can unsubscribe at any time by following the instructions contained in the promotional emails. If you do not wish to receive marketing communication from size? (and size? affiliates) please do not tick the appropriate opt-in box(es) above.`,
                    },
                    {
                        title: '10. Liability',
                        paragraph: 'Insofar as is permitted by law, size? will not in any circumstances be responsible or liable to compensate the winner or accept any liability for any loss, damage, personal injury or death occurring as a result of entering into this competition except where it is caused by the negligence of size? Your legal rights are not affected.',
                    },
                    {
                        title: '12. Publicity',
                        paragraphs: [
                            'By taking part in the competition, entrants may be invited to participate in publicity at size?â€™s request if they are a winner of the competition. Entrants agree that size? (or any third party nominated by size?) may in its sole discretion use their comments relating to the Prize and their experience for future promotional, marketing and publicity purposes in any media worldwide without notice and without any fee being paid (including for the avoidance of doubt when responding to any third party).  Any use of images or other personal information that could identify entrants will be subject to the entrantsâ€™ consent.',
                            `If you wish to contact size? in relation to the competition, please use the following address:  <b>size? day, JD Sports Fashion plc (t/a size?), Edinburgh House, Hollinsbrook Way, Pilsworth, Bury, Lancashire, BL9 8RR, United Kingdom.</b>`,
                        ],
                    },
                ],
            }

            let template = ''
            template += '<div class="raffle-copy">'
            template += `<p>${buildTnC(charitytRaffleCopy.drawTnC)}</p>`
            template += '</div>'
            return template
        }

        function generateListItems(listItem, type) {
            let html = ''
            let li = ''
            listItem.map((item) => {
                li += `<li>${item}</li>`
            })
            switch (type) {
                case 'ul':
                    html += `<ul>${li}</ul>`
                    break
                default:
                    html += `<ol>${li}</ol>`
            }
            return html
        }

        function buildTnC(data) {
            let html = ''
            data.map((item) => {
                const {
                    title,
                    paragraph,
                    ol,
                    ul
                } = item
                for (const property in item) {
                    if (property === 'paragraphs') {
                        item.paragraphs.map((p) => (html += `<p>${p}</p>`))
                    }
                    if (property === 'title') {
                        html += `<p><b>${title}</b></p>`
                    }
                    if (property === 'paragraph') {
                        html += `<p>${paragraph}</p>`
                    }
                    if (property === 'ol') {
                        html += `${generateListItems(ol, 'ol')}`
                    }
                    if (property === 'ul') {
                        html += `${generateListItems(ul, 'ul')}`
                    }
                    if (property === 'steps') {
                        item.steps.map((step) => {
                            const {
                                title,
                                paragraph,
                                ul,
                                ol
                            } = step
                            if (step.paragraph && step.title) {
                                html += `<p><b>${title}: </b>${paragraph}</p>`
                            }
                            if (step.paragraph && !step.title) {
                                html += `<p>${paragraph}</p>`
                            }
                            if (step.ul) {
                                html += `<p><b>${title}: </b></p>`
                                html += `${generateListItems(ul, 'ul')}`
                            }
                            if (step.ol) {
                                html += `<p><b>${title}: </b></p>`
                                html += `${generateListItems(ol, 'ol')}`
                            }
                        })
                    }
                    if (property === 'items') {
                        item.items.map((item) => {
                            const {
                                title,
                                paragraph,
                                ul,
                                ol
                            } = item
                            if (item.title) {
                                html += `<u>${title}</u>`
                            }
                            if (item.paragraph) {
                                html += `<p>${paragraph}</p>`
                            }
                            if (item.paragraphs) {
                                item.paragraphs.map((p) => (html += `<p>${p}</p>`))
                            }
                            if (item.ul) {
                                html += `<p><b>${title}:</b></p>`
                                html += `${generateListItems(ul, 'ul')}`
                            }
                            if (item.ol) {
                                html += `<p><b>${title}:</b></p>`
                                html += `${generateListItems(ol, 'ol')}`
                            }
                        })
                    }
                }
            })
            return html
        }

        function checkRaffleStatus(entryDate, closingDate) {
            let entry = new Date(entryDate).getTime()
            let closing = new Date(closingDate).getTime()
            let current = new Date().getTime()
            const dateTimeFormat = new Intl.DateTimeFormat('en', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
            })
            if (current > entry && current < closing) {
                return 'open'
            } else if (current > entry && current > closing) {
                return 'closed'
            } else if (current < entry) {
                return 'coming soon'
            } else {
                return ' '
            }
        }

        function raffleStatus(entryDate, closingDate) {
            let entry = new Date(entryDate).getTime()
            let closing = new Date(closingDate).getTime()
            let current = new Date().getTime()
            const dateTimeFormat = new Intl.DateTimeFormat('en', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
            })
            // let raffleClosed = dateTimeFormat.format(closing)
            // let raffleOpened = dateTimeFormat.format(entry)
            if (current > entry && current < closing) {
                // return `<span class="raffle-status open">Raffle Open</span><span class="status-popup">${raffleClosed}</span>`;
                return `<span class="raffle-status open">Draw Open</span>`
            } else if (current > entry && current > closing) {
                return `<span class="raffle-status closed">Draw Closed</span>`
                // return `<span class="raffle-status closed">Raffle Closed</span><span class="status-popup">${raffleClosed}</span>`;
            } else if (current < entry) {
                return '<span class="raffle-status coming-soon">Draw Coming Soon</span>'
            } else {
                return ' '
            }
        }

        function buildRaffleHtml(data) {
            let root = document.querySelector('#previewRafflesPage')
            const reversedData = data.products.slice(0).reverse()
            let html = ''
            if (reversedData.length) {
                for (product of reversedData) {
                    html += `<section class="raffle-section"><div class="raffle-title"><h2/>size?launches: ${
            product.productTitle
          } ${product.productPrice}</h2>${raffleStatus(
            product.entryDate,
            product.closingDate,
          )}</div>`
                    html += `<div class="raffle-accordion" style="display:none;min-width:100%;">`
                    if (product.termsTemplate) {
                        if (product.termsTemplate.includes('charityRaffle_quantity_')) {
                            let template = product.termsTemplate
                            let templateQuantity = template.replaceAll(
                                'charityRaffle_quantity_',
                                '',
                            )
                            html += charityRaffle_quantity(product, templateQuantity)
                        }
                    } else {
                        switch (product.template) {
                            case 'premium':
                                html += premiumTemplate(product)
                                break
                            case 'custom':
                                html += customTemplate(product)
                                break
                            default:
                                if (product.isInstoreRaffle === true) {
                                    html += inStoreTemplate(product)
                                } else {
                                    html += defaultTemplate(product)
                                }
                        }
                    }
                    html += '</div></section>'
                }
            } else {
                html += noRafflesFound()
            }
            return (root.innerHTML = html)
        }

        function delay(fn, ms) {
            let timer = 0
            return function(...args) {
                clearTimeout(timer)
                timer = setTimeout(fn.bind(this, ...args), ms || 0)
            }
        }

        function addEvents(data) {
            $('#raffle-search-input').on(
                'input',
                delay(function() {
                    $('#raffles-dropdown').val('')
                    let searchVal = $(this).val()
                    filterRaffleProducts(data, searchVal)
                }, 300),
            )
            $('#raffles-dropdown').on('input', function() {
                $('#raffle-search-input').val('')
                let searchVal = $(this).val()
                if (searchVal === 'closed') {
                    sortRaffleProducts(data, 'closed')
                } else if (searchVal === 'open') {
                    sortRaffleProducts(data, 'open')
                } else if (searchVal === 'latest') {
                    sortRaffleProducts(data, 'latest')
                } else {
                    filterRaffleProducts(data, searchVal)
                }
            })
            accordionToggle()
        }

        function accordionToggle() {
            $('.raffle-title').on('click', function() {
                // $('.raffle-accordion').stop().hide('slow');
                $(this).next('.raffle-accordion').stop().toggle('down')
                $(this).toggleClass('active')
                const windowWidth = $(window).width()
                const offset = windowWidth > 800 ? 96 : 130
                $('body,html').animate({
                        scrollTop: $(this).offset().top - offset,
                    },
                    600,
                )
            })
        }

        function sortRaffleProducts(data, val) {
            let filteredProducts = {
                products: [],
            }
            data.products
                .filter((product) => {
                    let status = checkRaffleStatus(product.entryDate, product.closingDate)

                    if (status == val) {
                        return product
                    }
                })
                .map((product) => {
                    return filteredProducts.products.push(product)
                })
            buildRaffleHtml(filteredProducts)
            accordionToggle()
        }

        function filterRaffleProducts(data, val) {
            let filteredProducts = {
                products: [],
            }
            let searchVal = val.toLowerCase()
            if (val.length > 0) {
                data.products
                    .filter((product) => {
                        return product.productTitle.toLowerCase().indexOf(searchVal) !== -1
                    })
                    .map((product) => {
                        return filteredProducts.products.push(product)
                    })
                buildRaffleHtml(filteredProducts)
            } else {
                buildRaffleHtml(data)
            }
            accordionToggle()
        }

        function noRafflesFound() {
            let html = ''
            html +=
                '<div class="rafflePreviews"><div><h2>No draws found</h2></div></div>'
            return html
        }

        function init(data) {
            buildRaffleHtml(data)
            addEvents(data)
        }

        function callBack(data) {
            init(data)
        }
    }
})