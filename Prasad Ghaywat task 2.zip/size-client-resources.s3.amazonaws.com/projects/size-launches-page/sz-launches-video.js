$('#video-toggle').click(function() {
    if ($('.playing')[0]) {
        $('.sizepreviews-video video').get(0).pause();
        console.log("Paused");
    } else {
        $('.sizepreviews-video video').get(0).play();
        console.log("Playing");
    }

    $(this).toggleClass('playing');
    $('.sizepreviews-video').toggle();
});