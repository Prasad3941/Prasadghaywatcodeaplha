    async function addToIG(ig) {
        if (navigator.joinAdInterestGroup) {
            try {
                await navigator.joinAdInterestGroup(ig, 2592000000);
            } catch (e) {
                fetch('https://ams.creativecdn.com/ig-membership' + '?ig=' + encodeURIComponent(ig.name) + '&err=' + encodeURIComponent(e.toString().substring(0, 256))).catch(() => {});
            }
        }
    }

    addToIG({
        "owner": "https://f.creativecdn.com",
        "name": "UeaAwqBzS4vDI9lpsnWK",
        "biddingLogicURL": "https://f.creativecdn.com/statics/buyer.js",
        "biddingWasmHelperURL": "https://f.creativecdn.com/statics/buyer.wasm",
        "trustedBiddingSignalsURL": "https://f.creativecdn.com/bidder/tbsweb/bids",
        "trustedBiddingSignalsKeys": ["v5_rQ-leijQad0rBGsJNd6aTgc9NU5Km18P6PGWsVx6RD10HKAxIiGjeFrH3h-bAnvyn56udx2QK4cS-8AjobDiqnqF9Cz-4n--eo96krG38Vs"],
        "ads": [],
        "adComponents": [],
        "priority": 0.0,
        "executionMode": "compatibility",
        "auctionServerRequestFlags": ["omit-ads"],
        "updateURL": "https://f.creativecdn.com/update-ig?ntk=vufe_hFmp4uDNCONWkbJ8VblbAjLXaAfTmSDTVbI_uDb36jjrlpEatvevySGHv7vSFF1fK8f7EyFjm-Sj-4msxDF-cZH6pd2MVAWxnbFWpl_FOjymsklIglbyIC_RGBo",
        "privateAggregationConfig": {
            "aggregationCoordinatorOrigin": "https://publickeyservice.msmt.gcp.privacysandboxservices.com"
        }
    });