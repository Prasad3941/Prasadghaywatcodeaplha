var oi = oi || {};

oi.settings = oi.settings || {};

oi.settings.translations = {
    "phrases": {
        "AddressLengthLimitation-optional": {
            "orig": "The address is too long for our parcel labels. Please enter a maximum of 30 characters in each field.",
            "trans": ""
        },
        "AddressLengthLimitation-required": {
            "orig": "Address is a required field. The address is too long for our parcel labels. Please enter a maximum of 30 characters in each field.",
            "trans": ""
        },
        "AddressLengthLimitation-unitRequired": {
            "orig": "Unit Number is a required field. The address is too long for our parcel labels. Please enter a maximum of 30 characters in each field.",
            "trans": ""
        },
        "BFPO": {
            "orig": "BFPO",
            "trans": ""
        },
        "DOB": {
            "orig": "D.O.B",
            "trans": ""
        },
        "Exclusive": {
            "orig": "exclusive",
            "trans": ""
        },
        "FREE": {
            "orig": "FREE",
            "trans": ""
        },
        "FaqDuplicateVoteArticle": {
            "orig": "You have already voted this article",
            "trans": ""
        },
        "FreeShipping": {
            "orig": "Free Shipping on orders over \u00a3150",
            "trans": ""
        },
        "GFFT-CARD": {
            "orig": "GIFT CARD",
            "trans": ""
        },
        "InvalidDiscountCode": {
            "orig": "Invalid Discount Code Provided",
            "trans": ""
        },
        "NameLengthLimitation": {
            "orig": "Please enter a maximum of 30 characters",
            "trans": ""
        },
        "OK": {
            "orig": "OK",
            "trans": ""
        },
        "Or": {
            "orig": "Or",
            "trans": ""
        },
        "Size": {
            "orig": "Size",
            "trans": "size?"
        },
        "StepOneSelectAmount": {
            "orig": "Step 1 - Select amount",
            "trans": ""
        },
        "Unsubscribe": {
            "orig": "Unsubscribe",
            "trans": ""
        },
        "YourBagIsEmpty": {
            "orig": "Your bag is empty!",
            "trans": ""
        },
        "aboutUs": {
            "orig": "About Us",
            "trans": ""
        },
        "accept-all-cookies": {
            "orig": "Accept All Cookies",
            "trans": ""
        },
        "accessYourSavedItems": {
            "orig": "Access your saved items.",
            "trans": ""
        },
        "accessibility": {
            "orig": "Accessibility",
            "trans": ""
        },
        "account-forgotpassword-error": {
            "orig": "Sorry, there was a problem and we were unable to send you a password reset email. Please try again.",
            "trans": ""
        },
        "account-menu-paymentCards": {
            "orig": "Payment Cards",
            "trans": ""
        },
        "account-paymentCards-title": {
            "orig": "My Payment Types",
            "trans": ""
        },
        "account-resetpassword-blocked": {
            "orig": "Your account is currently disabled as a security measure, please contact us to regain access.",
            "trans": ""
        },
        "account-resetpassword-error": {
            "orig": "Sorry there has been an error trying to reset your password. Please try again.",
            "trans": ""
        },
        "accountAlreadyExists": {
            "orig": "The email you provided has already been registered. Please sign in or provide another email address",
            "trans": ""
        },
        "accountPasswordError": {
            "orig": "Password does not meet minimum constraints. Please enter 8 alpha numeric characters (letters, numbers, symbols)",
            "trans": ""
        },
        "add": {
            "orig": "Add",
            "trans": ""
        },
        "addAFlag": {
            "orig": "Add a flag",
            "trans": ""
        },
        "addAddresses": {
            "orig": "Add Addresses",
            "trans": ""
        },
        "addBFPOAddressDetails": {
            "orig": "Add BFPO Address Details",
            "trans": ""
        },
        "addBillingAddress": {
            "orig": "Add Billing Address",
            "trans": ""
        },
        "addDeliveryAddress": {
            "orig": "Add Delivery Address",
            "trans": ""
        },
        "addDeliveryAddressFail": {
            "orig": "Unable to add delivery address",
            "trans": ""
        },
        "addDiscountCode": {
            "orig": "Add Discount Code:",
            "trans": ""
        },
        "addGiftCard": {
            "orig": "Add Gift Card",
            "trans": ""
        },
        "addNewAddress": {
            "orig": "Add new address",
            "trans": ""
        },
        "addNewAddressOrClickAmpCollect": {
            "orig": "Add New Address or Click & Collect",
            "trans": ""
        },
        "addNewDeliveryAddress": {
            "orig": "Add New Delivery Address",
            "trans": ""
        },
        "addPersonalisation": {
            "orig": "Add Personalisation",
            "trans": ""
        },
        "addToBasket": {
            "orig": "Add to basket",
            "trans": "Add to Bag"
        },
        "addToWishlist": {
            "orig": "Add to Wishlist",
            "trans": ""
        },
        "addToWishlistName": {
            "orig": "Add to '{name}'",
            "trans": ""
        },
        "addToYourWishlist": {
            "orig": "Save for later",
            "trans": "Save to Wishlist"
        },
        "adding": {
            "orig": "Adding",
            "trans": ""
        },
        "addingCollectionDetailsToCart": {
            "orig": "Adding collection details to cart",
            "trans": ""
        },
        "addingDeliveryAddressToCart": {
            "orig": "Adding delivery address to cart",
            "trans": ""
        },
        "addingDeliveryMethodToCart": {
            "orig": "Adding delivery method to cart",
            "trans": ""
        },
        "address": {
            "orig": "Address",
            "trans": ""
        },
        "addressDetails": {
            "orig": "Address Details",
            "trans": ""
        },
        "addressHasBeenAdded": {
            "orig": "Address has been added",
            "trans": ""
        },
        "addressHasBeenDeleted": {
            "orig": "Address has been deleted",
            "trans": ""
        },
        "addressHasBeenUpdated": {
            "orig": "Address has been updated",
            "trans": ""
        },
        "addressLine1": {
            "orig": "Address Line 1",
            "trans": ""
        },
        "addressLine2": {
            "orig": "Address Line 2",
            "trans": ""
        },
        "addressLine3": {
            "orig": "Address Line 3",
            "trans": ""
        },
        "addressPredict-cannotRetrieve": {
            "orig": "Unable to retrieve address details. Please try again",
            "trans": ""
        },
        "addressPredict-inputPlaceholder": {
            "orig": "Start typing your address or postcode",
            "trans": ""
        },
        "addressPredict-predictAgain": {
            "orig": "Find a different address",
            "trans": ""
        },
        "afterpayExpress": {
            "orig": "Afterpay Express",
            "trans": ""
        },
        "all": {
            "orig": "all",
            "trans": ""
        },
        "altLoading": {
            "orig": "Loading",
            "trans": ""
        },
        "altPrimaryBillingAddress": {
            "orig": "Primary Billing Address",
            "trans": ""
        },
        "altPrimaryDeliveryAddress": {
            "orig": "Primary Delivery Address",
            "trans": ""
        },
        "always-active": {
            "orig": "Always Active",
            "trans": ""
        },
        "amazonPay": {
            "orig": "Amazon Pay",
            "trans": ""
        },
        "america": {
            "orig": "America",
            "trans": ""
        },
        "anatwine-fulfilment-msg": {
            "orig": "This product is excluded from this promotion.",
            "trans": ""
        },
        "anatwineDeliveryAndPromotionExclusions": {
            "orig": "Promotions and discounts are unavailable on this item. Gift cards cannot be used on this product. UK delivery only.",
            "trans": ""
        },
        "andEgiftcard": {
            "orig": "& eGIFT CARD",
            "trans": ""
        },
        "androidPay-error-unableToCompletePayment": {
            "orig": "Unable to finalize Android pay payment",
            "trans": ""
        },
        "androidPay-start-buy-message": {
            "orig": "Buy with",
            "trans": ""
        },
        "applePay": {
            "orig": "Apple Pay",
            "trans": ""
        },
        "applePay-collection-button": {
            "orig": "I would like to collect my order",
            "trans": ""
        },
        "applePay-delivery-button": {
            "orig": "I would like my order delivered",
            "trans": ""
        },
        "applePay-error-couldNotStartPayment": {
            "orig": "Unable to start your Apple pay payment",
            "trans": "Unable to start your Apple Pay payment"
        },
        "applePay-error-noClickAndCollectStoresFound": {
            "orig": "Unable to find any stores for the area specified",
            "trans": ""
        },
        "applePay-error-paymentFailed": {
            "orig": "Unable to confirm your Apple pay payment",
            "trans": "Unable to confirm your Apple Pay payment"
        },
        "applePay-findMyStore-button": {
            "orig": "Find my store",
            "trans": ""
        },
        "applePay-loading-orderConfirmed": {
            "orig": "Processing order",
            "trans": ""
        },
        "applied": {
            "orig": "applied",
            "trans": ""
        },
        "apply": {
            "orig": "Apply",
            "trans": ""
        },
        "applyDiscountCode": {
            "orig": "Add Discount Code",
            "trans": ""
        },
        "april": {
            "orig": "April",
            "trans": ""
        },
        "areYouSureYouWantToDisconnect": {
            "orig": "Are you sure you want to disconnect?",
            "trans": ""
        },
        "attachFile": {
            "orig": "Attach File",
            "trans": ""
        },
        "august": {
            "orig": "August",
            "trans": ""
        },
        "backMyAccount": {
            "orig": "Back to My Account",
            "trans": ""
        },
        "backToHomepage": {
            "orig": "Back To Homepage",
            "trans": ""
        },
        "backToOrders": {
            "orig": "Back to Orders",
            "trans": ""
        },
        "backToShop": {
            "orig": "Back to Shop",
            "trans": ""
        },
        "backToTop": {
            "orig": "Back to Top",
            "trans": "Top"
        },
        "backToWishlists": {
            "orig": "Back to Wishlists",
            "trans": ""
        },
        "basketIsEmpty": {
            "orig": "Basket is empty",
            "trans": ""
        },
        "basketball": {
            "orig": "Basketball",
            "trans": ""
        },
        "billing": {
            "orig": "Billing",
            "trans": ""
        },
        "billingAddress": {
            "orig": "Billing Address",
            "trans": ""
        },
        "billingAddressDetails": {
            "orig": "Billing Address Details",
            "trans": ""
        },
        "billingDetails": {
            "orig": "Billing Details",
            "trans": ""
        },
        "blog": {
            "orig": "Blog",
            "trans": ""
        },
        "bnplFiveWeeks": {
            "orig": "5 weeks",
            "trans": ""
        },
        "bnplFourWeeks": {
            "orig": "4 weeks",
            "trans": ""
        },
        "bnplLearnMore": {
            "orig": "Learn more.",
            "trans": ""
        },
        "bnplNinetyDays": {
            "orig": "90 days",
            "trans": ""
        },
        "bnplOneWeek": {
            "orig": "1 week",
            "trans": ""
        },
        "bnplSixWeeks": {
            "orig": "6 weeks",
            "trans": "6 equal weekly"
        },
        "bnplTermsApply": {
            "orig": "terms apply",
            "trans": ""
        },
        "bnplThirtyDays": {
            "orig": "30 days",
            "trans": ""
        },
        "bnplThreeWeeks": {
            "orig": "3 weeks",
            "trans": ""
        },
        "bnplToday": {
            "orig": "Today",
            "trans": ""
        },
        "bnplTwoWeeks": {
            "orig": "2 weeks",
            "trans": "every 2 weeks"
        },
        "brand": {
            "orig": "brand",
            "trans": ""
        },
        "brands": {
            "orig": "Brands",
            "trans": ""
        },
        "buyNow": {
            "orig": "Buy Now",
            "trans": ""
        },
        "buyNowPayIn": {
            "orig": "Buy now, pay in",
            "trans": ""
        },
        "buyNowPayLater": {
            "orig": "Buy now, pay interest free instalments. No hidden fees.",
            "trans": "Buy now, pay later"
        },
        "buyNowPayLaterInterestFree": {
            "orig": "Buy now, pay later interest free instalments.",
            "trans": ""
        },
        "buyQuickly": {
            "orig": "BUY QUICKLY",
            "trans": ""
        },
        "call": {
            "orig": "Call",
            "trans": ""
        },
        "canIChangeMyDeliveryAddress": {
            "orig": "Can I change my delivery address?",
            "trans": ""
        },
        "canIChangeOrCancelMyOrder": {
            "orig": "Can I amend my delivery address, change or cancel my order?",
            "trans": ""
        },
        "canNotAdd0ItemsPleaseSelect": {
            "orig": "Can not add 0 Items, please select valid amount.",
            "trans": ""
        },
        "canYouSendMeVatInvoice": {
            "orig": "Can you send me a VAT invoice?",
            "trans": ""
        },
        "cancel": {
            "orig": "Cancel",
            "trans": ""
        },
        "cancelAvailable": {
            "orig": "The order is assigned, it can be cancelled",
            "trans": ""
        },
        "cancelCartFail": {
            "orig": "Unable to cancel cart transfer. Please try again.",
            "trans": ""
        },
        "cancelTransferFail": {
            "orig": "There was a problem trying to cancel your transfer.",
            "trans": ""
        },
        "cancellationFailure": {
            "orig": "Sorry we have unable to cancel your order at this time.  Please contact customer care with any queries.",
            "trans": ""
        },
        "cancellationRequest": {
            "orig": "Cancellation Request",
            "trans": ""
        },
        "cancellationSuccess": {
            "orig": "Your order has been successfully cancelled, your refund will be processed back to your account",
            "trans": ""
        },
        "cancellations": {
            "orig": "Cancellations",
            "trans": ""
        },
        "cancelled": {
            "orig": "is cancelled",
            "trans": ""
        },
        "careAmpMaterial": {
            "orig": "Care & Material",
            "trans": ""
        },
        "careers": {
            "orig": "Careers",
            "trans": ""
        },
        "cart-basketPromotionGroupTitle": {
            "orig": "Promotion",
            "trans": ""
        },
        "cart-basketReference-shared": {
            "orig": "Basket Reference",
            "trans": ""
        },
        "cart-didYouMean": {
            "orig": "Did you mean {email}?",
            "trans": ""
        },
        "cart-discountRemoveError": {
            "orig": "There was a problem removing your discount code. Please try again",
            "trans": ""
        },
        "cart-excludingDelivery": {
            "orig": "Excluding Delivery",
            "trans": ""
        },
        "cart-promotionTotal": {
            "orig": "Promotion Total",
            "trans": ""
        },
        "cart-securePayment-text": {
            "orig": "This site is secure and your personal details are protected.",
            "trans": ""
        },
        "cartContinueShopping": {
            "orig": "Continue Shopping",
            "trans": ""
        },
        "cartDelivery": {
            "orig": "Delivery",
            "trans": ""
        },
        "cartDiscount": {
            "orig": "Discount",
            "trans": ""
        },
        "cartDiscountCodeUnknown": {
            "orig": "Sorry, we didn't recognise that discount code.",
            "trans": ""
        },
        "cartFindFail": {
            "orig": "Unable to find cart.",
            "trans": ""
        },
        "cartMerge-decisionConfirm": {
            "orig": "Yes",
            "trans": ""
        },
        "cartMerge-decisionDiscard": {
            "orig": "No",
            "trans": ""
        },
        "cartMerge-decisionPrompt": {
            "orig": "Would you like to add these items to your basket now?",
            "trans": ""
        },
        "cartMerge-showModal-error": {
            "orig": "Unable to load the cart merge overlay. Please try again",
            "trans": ""
        },
        "cartMerge-title": {
            "orig": "These items have been saved to your basket in a previous visit",
            "trans": ""
        },
        "cartOverlay-basketReference-shared": {
            "orig": "Basket Reference",
            "trans": ""
        },
        "cartSubTotal": {
            "orig": "Sub-Total",
            "trans": ""
        },
        "cartTakeover-popup-message": {
            "orig": "Are you sure you want to take over a new cart?",
            "trans": ""
        },
        "cartTitle": {
            "orig": "My Basket",
            "trans": ""
        },
        "cartTotal": {
            "orig": "Total",
            "trans": ""
        },
        "cartTransfer-popup-message": {
            "orig": "Are you sure you want to replace this cart?",
            "trans": ""
        },
        "cartTransfer-popup-title": {
            "orig": "You already have a cart",
            "trans": ""
        },
        "change": {
            "orig": "Change",
            "trans": ""
        },
        "change-privacy-policy": {
            "orig": "We've changed our privacy policy",
            "trans": ""
        },
        "changeArea": {
            "orig": "Change Area",
            "trans": ""
        },
        "changeInMind": {
            "orig": "Change in Mind",
            "trans": ""
        },
        "changePassword": {
            "orig": "Change Password",
            "trans": ""
        },
        "checkYourBalance": {
            "orig": "CHECK YOUR BALANCE",
            "trans": ""
        },
        "checkout": {
            "orig": "Checkout",
            "trans": ""
        },
        "checkout-accept-label": {
            "orig": "I consent. (ACT ON THE CONSUMER PROTECTION IN ELECTRONIC COMMERCE Article 8 Clause 2) Do you accept this purchase after final confirmation on order items, prices, delivery information, discounts, etc.?",
            "trans": ""
        },
        "checkout-billing-authoriseKlarna-error": {
            "orig": "Unable to authorise Klarna payment, please try again. No money has been taken and your cart is still intact",
            "trans": ""
        },
        "checkout-billing-loadKlarna-error": {
            "orig": "Unable to begin Klarna Credit payment",
            "trans": "Unable to begin Klarna payment"
        },
        "checkout-billing-loadKlarnaForm-error": {
            "orig": "Unable to load Klarna credit form",
            "trans": "Sorry Klarna payment option can\u2019t be offered, please select another payment option"
        },
        "checkout-billing-loadPaymentForm-error": {
            "orig": "Unable to load payment form",
            "trans": ""
        },
        "checkout-billing-title": {
            "orig": "Billing & Review",
            "trans": ""
        },
        "checkout-cartItemRemove": {
            "orig": "Remove",
            "trans": ""
        },
        "checkout-clickAndCollect-customerDetailsTip": {
            "orig": "You need to bring ID and your order receipt when collecting your order. You can nominate someone else to collect your order.",
            "trans": ""
        },
        "checkout-clickAndCollect-customerDetailsTitle": {
            "orig": "Your details",
            "trans": ""
        },
        "checkout-clickAndCollect-nominatedCollectorTip": {
            "orig": "If it's not you collecting this order we will need the collectors name and phone number. They will need to bring their ID and your order receipt.",
            "trans": ""
        },
        "checkout-clickAndCollect-notYouCollectingCheckbox": {
            "orig": "Not you collecting?",
            "trans": ""
        },
        "checkout-clickAndCollect-notYouCollectingTitle": {
            "orig": "Collector details",
            "trans": ""
        },
        "checkout-confirmationEmailNotify": {
            "orig": "A confirmation email will be sent to",
            "trans": ""
        },
        "checkout-errorMessage-noClickAndCollectStoresFound": {
            "orig": "Unable to find any stores for the area specified.",
            "trans": ""
        },
        "checkout-estimatedDelivery": {
            "orig": "Estimated delivery",
            "trans": ""
        },
        "checkout-estimatedDeliveryDate": {
            "orig": "Estimated delivery date",
            "trans": ""
        },
        "checkout-footer-privacynotice": {
            "orig": "By continuing you accept our {privacyLink} and also agree to receive marketing communications from Blacks Outdoor Retail Ltd.",
            "trans": "By continuing you accept our https:\/\/www.size.co.uk\/customer-service\/privacy\/ and also agree to receive marketing communications from size?"
        },
        "checkout-header-liveChatButtonOfflineText": {
            "orig": "Live Chat Offline",
            "trans": ""
        },
        "checkout-header-liveChatTextBlock-desktop": {
            "orig": "Need assistance? We're here to help.",
            "trans": ""
        },
        "checkout-legalRequirementMessage": {
            "orig": "By placing your order you are agreeing to accept our terms and conditions and privacy policy. You also agree to receive marketing emails from",
            "trans": ""
        },
        "checkout-marketing-error": {
            "orig": "There was an error when trying to add your marketing preference to the cart, please try again",
            "trans": ""
        },
        "checkout-marketingOptIn-label": {
            "orig": "To keep up to date, opt in to our marketing communications by ticking this box",
            "trans": ""
        },
        "checkout-order-privacy-notice": {
            "orig": "Marketing communications from Blacks Outdoor Retail Ltd.",
            "trans": ""
        },
        "checkout-orderReceiptNotify": {
            "orig": "A receipt for your order has been sent to your chosen email address.",
            "trans": ""
        },
        "checkout-orderSummary-title": {
            "orig": "Order Summary",
            "trans": ""
        },
        "checkout-payment-title": {
            "orig": "Payment Details",
            "trans": ""
        },
        "checkout-paymentMethodGroup-global": {
            "orig": "Global Payments",
            "trans": ""
        },
        "checkout-paymentMethods-afterPay": {
            "orig": "Pay with Clearpay",
            "trans": ""
        },
        "checkout-paymentMethods-alipay": {
            "orig": "Pay with Alipay",
            "trans": ""
        },
        "checkout-paymentMethods-bank-transfer": {
            "orig": "Pay with Bank Transfer",
            "trans": ""
        },
        "checkout-paymentMethods-entercash": {
            "orig": "Pay with entercash",
            "trans": ""
        },
        "checkout-paymentMethods-kcp-card": {
            "orig": "Pay with Card",
            "trans": ""
        },
        "checkout-paymentMethods-kcp-payco": {
            "orig": "Pay with Payco",
            "trans": ""
        },
        "checkout-paymentMethods-klarnaCredit": {
            "orig": "Pay with Klarna Credit",
            "trans": "Pay later with Klarna"
        },
        "checkout-paymentMethods-multibanco": {
            "orig": "Pay with Multibanco",
            "trans": ""
        },
        "checkout-paymentMethods-openpay": {
            "orig": "Pay with Openpay",
            "trans": ""
        },
        "checkout-paymentMethods-unionpay": {
            "orig": "Pay with Unionpay",
            "trans": ""
        },
        "checkout-paymentMethods-wechat": {
            "orig": "Pay with Wechat",
            "trans": ""
        },
        "checkout-paymentMethods-zippay": {
            "orig": "Pay with Zip",
            "trans": ""
        },
        "checkout-placingOrder": {
            "orig": "Placing Order",
            "trans": ""
        },
        "checkout-updateNominatedCollector-error": {
            "orig": "Unable to update delivery details",
            "trans": ""
        },
        "checkoutAddDeliveryAddress": {
            "orig": "Add Delivery Address",
            "trans": ""
        },
        "checkoutAddressLookup": {
            "orig": "Lookup Address",
            "trans": ""
        },
        "checkoutAddressLookupNoResults": {
            "orig": "Sorry, no matching items found",
            "trans": ""
        },
        "checkoutAddressLookupSelect": {
            "orig": "Select your address",
            "trans": ""
        },
        "checkoutAsGuest": {
            "orig": "Checkout as guest",
            "trans": ""
        },
        "checkoutBillingAddress": {
            "orig": "Billing Address",
            "trans": ""
        },
        "checkoutDeliveryMethod": {
            "orig": "Delivery Method",
            "trans": ""
        },
        "checkoutGuestDescription": {
            "orig": "No need to register, just enter your email address to continue with your purchase. You can create a password after checkout to create an account.",
            "trans": ""
        },
        "checkoutGuestDescriptionTwo": {
            "orig": "Checkout quickly as a guest (you can create an account later if you wish).",
            "trans": ""
        },
        "checkoutLogin": {
            "orig": "Login",
            "trans": ""
        },
        "checkoutMaxValueFailure": {
            "orig": "Unable to do checkout process because total amount exceed cart maximum amount (THB 399,999.60)",
            "trans": ""
        },
        "checkoutMoreMemberBenefits": {
            "orig": "Check Out More Member Benefits",
            "trans": ""
        },
        "checkoutSecurely": {
            "orig": "Checkout securely",
            "trans": ""
        },
        "checkoutTitle": {
            "orig": "CHECKOUT",
            "trans": ""
        },
        "checkoutWithApplePay": {
            "orig": "Or checkout with Apple Pay",
            "trans": ""
        },
        "chooseDeliveryMethod": {
            "orig": "Choose a delivery method",
            "trans": ""
        },
        "chooseGiftCard": {
            "orig": "Head over to",
            "trans": ""
        },
        "chooseSize": {
            "orig": "Choose size",
            "trans": ""
        },
        "chooseSizeInStock": {
            "orig": "Choose size in stock",
            "trans": "Pick your UK size"
        },
        "city": {
            "orig": "City",
            "trans": ""
        },
        "clearAll": {
            "orig": "Clear All",
            "trans": ""
        },
        "clearAllFilters": {
            "orig": "Clear all filters",
            "trans": ""
        },
        "clearPayBNPLAdvice": {
            "orig": "Late fees of up to \u00a324 per purchase apply.",
            "trans": ""
        },
        "clearPayBnplPopoutText": {
            "orig": "instalments via Clearpay\u2019s credit offer. 18+,",
            "trans": "Late fees of up to \u00a324 per purchase apply."
        },
        "clearpayExpress": {
            "orig": "Clearpay Express",
            "trans": ""
        },
        "clearpayRiskDisclosure": {
            "orig": "Clearpay lends you a fixed amount of credit to allow you to pay for your purchase over 4 instalments. Late fees chargeable. T&Cs and eligibility criteria apply",
            "trans": ""
        },
        "clearpayTerms": {
            "orig": "clearpay.co.uk\/terms",
            "trans": ""
        },
        "clearpayTermsAndConditionsApply": {
            "orig": "T&C's apply",
            "trans": ""
        },
        "clickAmpCollect": {
            "orig": "Click & Collect",
            "trans": ""
        },
        "clickHereToCallUs": {
            "orig": "Click here if you would like to speak with a member of our support team.",
            "trans": ""
        },
        "close": {
            "orig": "Close",
            "trans": ""
        },
        "clothing": {
            "orig": "Clothing",
            "trans": ""
        },
        "code": {
            "orig": "Code",
            "trans": ""
        },
        "collectInStore": {
            "orig": "Collect it in-store",
            "trans": ""
        },
        "collectionPointsNearYou": {
            "orig": "Collection points near you",
            "trans": ""
        },
        "collections": {
            "orig": "Collections",
            "trans": ""
        },
        "color": {
            "orig": "Color:",
            "trans": "Colour:"
        },
        "colour": {
            "orig": "Colour",
            "trans": ""
        },
        "colours": {
            "orig": "Colours",
            "trans": ""
        },
        "confirm": {
            "orig": "Confirm",
            "trans": ""
        },
        "confirm-my-choices": {
            "orig": "Confirm My Choice",
            "trans": ""
        },
        "confirmPassword": {
            "orig": "Confirm password",
            "trans": ""
        },
        "confirmation": {
            "orig": "Confirmation",
            "trans": ""
        },
        "confirmationPage": {
            "orig": "Confirmation Page",
            "trans": ""
        },
        "confirmationPasswordDoesNotMatch": {
            "orig": "Confirmation password does not match.",
            "trans": "Password must be at least 8 characters, containing at least one character and one digit and no symbols."
        },
        "connectYourAccounts": {
            "orig": "Connect Your Accounts",
            "trans": ""
        },
        "connorTest": {
            "orig": "simon is a flop",
            "trans": ""
        },
        "connorsLanguageKeyTwo": {
            "orig": "Connor's Default Language Key",
            "trans": ""
        },
        "contactAdvice": {
            "orig": "We will only contact you with order updates",
            "trans": ""
        },
        "contactDetails": {
            "orig": "Contact Details",
            "trans": ""
        },
        "contactError": {
            "orig": "Sorry, there was a problem submitting the contact form",
            "trans": ""
        },
        "contactNumber": {
            "orig": "Contact number",
            "trans": ""
        },
        "contactPrefAdvice": {
            "orig": "I would like to hear from you by:",
            "trans": ""
        },
        "contactSuccess": {
            "orig": "Your message has been sent to the Customer Service Team",
            "trans": ""
        },
        "contactSuccessCaption": {
            "orig": "We will try respond to your enquiry as quickly and efficiently as possible.",
            "trans": ""
        },
        "contactUsBeforeShipping": {
            "orig": "please contact us before shipping",
            "trans": ""
        },
        "continueBtm": {
            "orig": "Continue",
            "trans": ""
        },
        "continueSecurely": {
            "orig": "Continue Securely",
            "trans": ""
        },
        "continueSecurelyAsGuest": {
            "orig": "Continue Securely As Guest",
            "trans": ""
        },
        "continueSecurelyNow": {
            "orig": "Continue Securely Now",
            "trans": ""
        },
        "continueShopping": {
            "orig": "Continue Shopping",
            "trans": ""
        },
        "cookie-infomation": {
            "orig": "Cookie Information",
            "trans": ""
        },
        "cookie-information": {
            "orig": "Cookie Information",
            "trans": ""
        },
        "cookie-policy": {
            "orig": "Cookie Policy",
            "trans": ""
        },
        "cookie-settings": {
            "orig": "Your Cookie Settings",
            "trans": ""
        },
        "cookies": {
            "orig": "Cookies",
            "trans": ""
        },
        "cookies-details": {
            "orig": "Cookies Details",
            "trans": ""
        },
        "copyrightSizeFashion": {
            "orig": "Size? All rights reserved.",
            "trans": "size? All rights reserved."
        },
        "corporate": {
            "orig": "Corporate",
            "trans": ""
        },
        "couldNotCreateGuestAccount": {
            "orig": "Sorry, we could not create the guest account. Please try again",
            "trans": ""
        },
        "couldNotFindAnyResultsBasedOn": {
            "orig": "Could not find any results based on your search. Please try again.",
            "trans": ""
        },
        "country": {
            "orig": "Country",
            "trans": ""
        },
        "county": {
            "orig": "County",
            "trans": ""
        },
        "cpex-confirmStep-clearPayError": {
            "orig": "There was a problem confirming your order",
            "trans": ""
        },
        "cpex-verifyStep-orderStatusCancelled": {
            "orig": "The order was cancelled",
            "trans": ""
        },
        "create-account-for-preferences": {
            "orig": "To update your preferences create an account",
            "trans": ""
        },
        "createAnAccount": {
            "orig": "Create an account",
            "trans": ""
        },
        "createAndShareGiftLists": {
            "orig": "Create and share gift lists.",
            "trans": ""
        },
        "createGuestAccount-badCredentials": {
            "orig": "Incorrect email address.",
            "trans": ""
        },
        "createGuestAccount-blocked": {
            "orig": "Your email is currently disabled as a security measure, please contact us to regain access.",
            "trans": ""
        },
        "createGuestAccount-suspended": {
            "orig": "Sorry we could not create your guest account. This email has been suspended for a few seconds due to too many incorrect attempts.",
            "trans": ""
        },
        "createNewAddress": {
            "orig": "Create new address",
            "trans": ""
        },
        "crepProtect": {
            "orig": "CREP PROTECT",
            "trans": ""
        },
        "currentPassword": {
            "orig": "Current password",
            "trans": ""
        },
        "currentlyOutOfStock": {
            "orig": "Currently Out of Stock",
            "trans": ""
        },
        "custom": {
            "orig": "Custom",
            "trans": ""
        },
        "customerNotFound": {
            "orig": "Unable to find customer.",
            "trans": ""
        },
        "customerService": {
            "orig": "Customer Service",
            "trans": ""
        },
        "customerServiceForm": {
            "orig": "Customer Service Form",
            "trans": ""
        },
        "customerUpdateNotFound": {
            "orig": "Could not find customer to update. Please try again",
            "trans": ""
        },
        "dailyDealsSubscriptions": {
            "orig": "Daily Deals Subscriptions",
            "trans": ""
        },
        "dashboard": {
            "orig": "Dashboard",
            "trans": ""
        },
        "december": {
            "orig": "December",
            "trans": ""
        },
        "decreaseQuantity": {
            "orig": "Decrease quantity",
            "trans": ""
        },
        "defaultBillingAddress": {
            "orig": "Default Billing Address",
            "trans": ""
        },
        "defaultDeliveryAddress": {
            "orig": "Default Delivery address",
            "trans": ""
        },
        "defectiveProduct": {
            "orig": "Defective Product",
            "trans": ""
        },
        "delete": {
            "orig": "Delete",
            "trans": ""
        },
        "deliverTo": {
            "orig": "Deliver To",
            "trans": ""
        },
        "delivery": {
            "orig": "Delivery",
            "trans": ""
        },
        "deliveryAddress": {
            "orig": "Delivery Address",
            "trans": ""
        },
        "deliveryAmpCollection": {
            "orig": "Delivery & Collection",
            "trans": ""
        },
        "deliveryCollectionOptions": {
            "orig": "Delivery & Collection Options",
            "trans": ""
        },
        "deliveryCustomMessage": {
            "orig": "Delivery Custom Message",
            "trans": ""
        },
        "deliveryDetails": {
            "orig": "Delivery Details",
            "trans": ""
        },
        "deliveryInstructions": {
            "orig": "Delivery Instructions",
            "trans": ""
        },
        "deliveryLocation": {
            "orig": "Delivery Location",
            "trans": ""
        },
        "deliveryMethodNotAvailable": {
            "orig": "Delivery Method currently not available for these products",
            "trans": ""
        },
        "deliveryMethodValidationFail": {
            "orig": "Unable to validate delivery method",
            "trans": ""
        },
        "deliveryRequest": {
            "orig": "Delivery Request",
            "trans": ""
        },
        "deliverySlot-postcodesDontMatch": {
            "orig": "Delivery slot postcode and delivery address postcodes must be the same",
            "trans": ""
        },
        "deliverySlotOptions-select": {
            "orig": "Select",
            "trans": ""
        },
        "deliverySlotOptions-selectLabel": {
            "orig": "Choose a day for your order to be delivered",
            "trans": ""
        },
        "deliverySlotOptions-selectTime": {
            "orig": "Choose a time slot for your delivery",
            "trans": ""
        },
        "deliverySlotOptions-title": {
            "orig": "Choose your delivery day",
            "trans": ""
        },
        "deliverySlots-loading": {
            "orig": "Loading delivery slots",
            "trans": ""
        },
        "deliveryTo": {
            "orig": "Delivery to:",
            "trans": ""
        },
        "deliveryType": {
            "orig": "Delivery Type:",
            "trans": ""
        },
        "depositorName": {
            "orig": "Name of depositor",
            "trans": ""
        },
        "depositorNameRequired": {
            "orig": "Please enter depositor name.",
            "trans": ""
        },
        "description": {
            "orig": "Description",
            "trans": ""
        },
        "details": {
            "orig": "Details",
            "trans": ""
        },
        "dialogClose": {
            "orig": "OK",
            "trans": ""
        },
        "dialogDiscountSuccessyBody": {
            "orig": "Your discount has been successfully added",
            "trans": ""
        },
        "dialogErrorTitle": {
            "orig": "Error",
            "trans": ""
        },
        "dialogProductStockTitle": {
            "orig": "Out Of Stock",
            "trans": ""
        },
        "dialogRemoveItemCancel": {
            "orig": "No thanks",
            "trans": ""
        },
        "directInput": {
            "orig": "direct input",
            "trans": ""
        },
        "disconnectAccounts": {
            "orig": "Disconnect Accounts",
            "trans": ""
        },
        "disconnectMyAccountFromNike": {
            "orig": "Disconnect my account from Nike",
            "trans": ""
        },
        "discount": {
            "orig": "Discount",
            "trans": ""
        },
        "discountAddError": {
            "orig": "Sorry there was a problem trying to add that discount ",
            "trans": ""
        },
        "discountCode": {
            "orig": "Offer Code",
            "trans": "Discount Code?"
        },
        "discountCode-error": {
            "orig": "The product you have selected is excluded from this promotion",
            "trans": ""
        },
        "discountCodesAppliedToYourBasket": {
            "orig": "Discount codes applied to your basket:",
            "trans": ""
        },
        "discountPromoCode": {
            "orig": "Add Discount \/ Promo Code",
            "trans": ""
        },
        "discounted": {
            "orig": "Discounted",
            "trans": ""
        },
        "discountsAndSavings": {
            "orig": "Discounts & Savings ",
            "trans": ""
        },
        "dispatched": {
            "orig": "Dispatched",
            "trans": ""
        },
        "dispatchedSoon": {
            "orig": "Dispatched Soon",
            "trans": ""
        },
        "doYouHaveAPassword": {
            "orig": "Do you have a password?",
            "trans": ""
        },
        "doYouHaveAnyJobVacancies": {
            "orig": "Do you have any job vacancies?",
            "trans": ""
        },
        "doYouShipToMyCountry": {
            "orig": "Do you ship to my country?",
            "trans": ""
        },
        "dr": {
            "orig": "Dr",
            "trans": ""
        },
        "eGFFT-CARD": {
            "orig": "eGIFT CARD",
            "trans": ""
        },
        "eGIFTCARD": {
            "orig": "eGift Card",
            "trans": ""
        },
        "eGift-Card": {
            "orig": "& eGift Card",
            "trans": ""
        },
        "eGift-card-is-here": {
            "orig": "eGift Card is here",
            "trans": ""
        },
        "eGiftCardDescription": {
            "orig": "Send by email or text immediately after purchase. The eGift Card can be redeemed online on {storeName}, however please note eGift Cards are not valid for in-store purchases. Redeem online only.",
            "trans": ""
        },
        "edit": {
            "orig": "Edit",
            "trans": ""
        },
        "editAddress": {
            "orig": "Edit Address",
            "trans": ""
        },
        "editBillingAddress": {
            "orig": "Edit Billing Address",
            "trans": ""
        },
        "egift-card": {
            "orig": "eGIFT CARD",
            "trans": ""
        },
        "eighteenPlusTermsApply": {
            "orig": "18+, terms apply",
            "trans": ""
        },
        "email": {
            "orig": "Email",
            "trans": ""
        },
        "emailAddress": {
            "orig": "Email address",
            "trans": ""
        },
        "emailAddressAlreadyRegistered": {
            "orig": "The email address you provided has already been registered. Please sign in or provide another email address",
            "trans": ""
        },
        "emailSent": {
            "orig": "Email sent!",
            "trans": ""
        },
        "enclosed": {
            "orig": "Enclosed (5,000 KRW)",
            "trans": ""
        },
        "enterANewPasswordBelowToUpdate": {
            "orig": "Enter a new password below to update your account login details.",
            "trans": ""
        },
        "enterASearchTerm": {
            "orig": "Enter a Search Term",
            "trans": ""
        },
        "enterAddressManually": {
            "orig": "Enter Address Manually",
            "trans": ""
        },
        "enterDiscountCode": {
            "orig": "Enter discount code",
            "trans": ""
        },
        "enterQuantity": {
            "orig": "Enter quantity",
            "trans": ""
        },
        "enterStudentDiscount": {
            "orig": "Student? Get your discount code",
            "trans": ""
        },
        "enterYourPassword": {
            "orig": "Enter your password",
            "trans": ""
        },
        "enterYourSearchHere": {
            "orig": "Search...",
            "trans": ""
        },
        "enterYourStartingLocation": {
            "orig": "Enter Your Starting Location",
            "trans": ""
        },
        "error": {
            "orig": "Error",
            "trans": ""
        },
        "errorInProductInformation": {
            "orig": "Error in product information",
            "trans": ""
        },
        "errorWhenAttempting3DSecureAuthenticationPleaseTry": {
            "orig": "Error when attempting 3DSecure authentication, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "exchanges": {
            "orig": "Exchanges",
            "trans": ""
        },
        "excludingDelivery": {
            "orig": "*",
            "trans": ""
        },
        "exclusiveRewardsWithNikeMembership": {
            "orig": "Exclusive Rewards with Nike Membership",
            "trans": ""
        },
        "existingCustomers": {
            "orig": "Existing Customers",
            "trans": ""
        },
        "expressCheckout": {
            "orig": "Express Checkout",
            "trans": ""
        },
        "expressCollectPrivacy": {
            "orig": "Express Collected is powered by our partner Octipas. Our {privacyPolicyLink} can be found here.",
            "trans": ""
        },
        "expressCollectWithin": {
            "orig": "Express collect within 2 hours (orders before 2pm)",
            "trans": ""
        },
        "externalDelivery-enter-postcode": {
            "orig": "Enter town or a UK postcode",
            "trans": ""
        },
        "externalPayment-error-unableToGetCart": {
            "orig": "Unable to retreive your cart",
            "trans": ""
        },
        "externalPayment-error-unableToGetDeliveryMethods": {
            "orig": "Unable to retreive delivery methods for your address",
            "trans": ""
        },
        "externalPayment-paying-by-card": {
            "orig": "Paying by card? Choose your delivery method on the next page",
            "trans": ""
        },
        "externalPayment-paying-by-express": {
            "orig": "Pay using an express payment method",
            "trans": ""
        },
        "fREEReturns": {
            "orig": "FREE Returns",
            "trans": ""
        },
        "failure": {
            "orig": "Failure!",
            "trans": ""
        },
        "faqSearchMinLetters": {
            "orig": "Please enter at least 3 letters",
            "trans": ""
        },
        "faqSearchResults": {
            "orig": "results found for",
            "trans": ""
        },
        "faqSearchResultsFeedbackQuestion": {
            "orig": "Did this answer your question?",
            "trans": ""
        },
        "faqSearchResultsGetHelpTitle": {
            "orig": "Other ways to get help",
            "trans": ""
        },
        "faqSearchResultsHeader": {
            "orig": "How can we help?",
            "trans": ""
        },
        "faqSearchResultsHome": {
            "orig": "Home",
            "trans": ""
        },
        "faqSearchResultsLiveChat": {
            "orig": "Live chat",
            "trans": ""
        },
        "faqSearchResultsMessage": {
            "orig": "Message",
            "trans": ""
        },
        "faqSearchResultsPopularTopics": {
            "orig": "Popular Topics",
            "trans": ""
        },
        "faqSearchResultsSearchForAnswers": {
            "orig": "Search for answers",
            "trans": ""
        },
        "faqSearchResultsSeeAll": {
            "orig": "See All",
            "trans": ""
        },
        "faqSearchResultsSubHeader": {
            "orig": "Find the right answer",
            "trans": ""
        },
        "faqSearchResultsTitle": {
            "orig": "Frequently Asked Questions",
            "trans": ""
        },
        "faqSearchResultsTwitterSupport": {
            "orig": "Twitter support",
            "trans": ""
        },
        "faqSearchResultsVoteError": {
            "orig": "Something went wrong in backend",
            "trans": ""
        },
        "faqSearchResultsVoteQuestion": {
            "orig": "Did this answer your question?",
            "trans": ""
        },
        "faqSearchResultsVoteSuccess": {
            "orig": "Thanks for your feedback.",
            "trans": ""
        },
        "fascia-size": {
            "orig": "size",
            "trans": ""
        },
        "fascia-the": {
            "orig": "The",
            "trans": ""
        },
        "fastShippingPlease": {
            "orig": "fast shipping please",
            "trans": ""
        },
        "featuredProducts-filter": {
            "orig": "Filter",
            "trans": ""
        },
        "featuredProducts-newIn": {
            "orig": "New In",
            "trans": ""
        },
        "features": {
            "orig": "Features",
            "trans": ""
        },
        "february": {
            "orig": "February",
            "trans": ""
        },
        "findAddress": {
            "orig": "Lookup Address",
            "trans": ""
        },
        "fireHydrant": {
            "orig": "please put it in the fire hydrant",
            "trans": ""
        },
        "firstName": {
            "orig": "First name",
            "trans": ""
        },
        "footer-careers": {
            "orig": "Careers",
            "trans": ""
        },
        "footer-contactUs": {
            "orig": "Contact Us",
            "trans": ""
        },
        "footer-cookies": {
            "orig": "Cookies",
            "trans": ""
        },
        "footer-copyright-notice": {
            "orig": "{group}, All rights reserved.",
            "trans": ""
        },
        "footer-findNearestSizeStore": {
            "orig": "Find your nearest size? store",
            "trans": ""
        },
        "footer-giftCardsBlock-buttonText-desktop": {
            "orig": "Buy gift cards",
            "trans": ""
        },
        "footer-giftCardsBlock-information-desktop": {
            "orig": "The ultimate gift card is the only gift card you need. Available in over 500 stores across the country, it's the perfect gift.",
            "trans": "The size? Gift Card. Stuck for ideas? Get it tied up with the size? Gift Card..."
        },
        "footer-giftCardsBlock-priceRange-desktop": {
            "orig": "\u00a35 - \u00a3300",
            "trans": ""
        },
        "footer-giftCardsBlock-title-desktop": {
            "orig": "Gift Cards",
            "trans": ""
        },
        "footer-help": {
            "orig": "Help",
            "trans": ""
        },
        "footer-links-linkToDesktopSite-mobile": {
            "orig": "View Full Site",
            "trans": ""
        },
        "footer-nativeAppsBlock-androidDownloadMessage": {
            "orig": "Download from Google Play",
            "trans": ""
        },
        "footer-nativeAppsBlock-information": {
            "orig": "Shop 24\/7 using the app. Access exclusive offers & shop the very latest products on the move.",
            "trans": ""
        },
        "footer-nativeAppsBlock-iosDownloadMessage": {
            "orig": "Download from the App Store",
            "trans": ""
        },
        "footer-nativeAppsBlock-title": {
            "orig": "Download our apps",
            "trans": ""
        },
        "footer-needHelp": {
            "orig": "Need Help?",
            "trans": ""
        },
        "footer-newsletter": {
            "orig": "Newsletter",
            "trans": ""
        },
        "footer-newsletter-privacy-policy-link": {
            "orig": "We treat your personal data with care, view our Privacy Policy",
            "trans": ""
        },
        "footer-newsletter-privacy-policy-link-text": {
            "orig": "https:\/\/www.thehipstore.co.uk\/customer-service\/privacy\/",
            "trans": ""
        },
        "footer-newsletterSignup-buttonText": {
            "orig": "Sign Up",
            "trans": ""
        },
        "footer-newsletterSignup-description": {
            "orig": "Sign up for our emails to receive exclusive updates and offers.",
            "trans": ""
        },
        "footer-newsletterSignup-failureMessage": {
            "orig": "Sorry - There was a problem registering your email",
            "trans": ""
        },
        "footer-newsletterSignup-placeholder-desktop": {
            "orig": "Sign up for the latest news",
            "trans": ""
        },
        "footer-newsletterSignup-placeholder-mobile": {
            "orig": "Email address",
            "trans": "Sign up for the latest news"
        },
        "footer-newsletterSignup-successMessage": {
            "orig": "Thank You - Your email has been registered",
            "trans": ""
        },
        "footer-newsletterSignup-text": {
            "orig": "JOIN OUR MAILING LIST TO RECEIVE EXCLUSIVE UPDATES & GET 10% OFF YOUR FIRST ORDER",
            "trans": ""
        },
        "footer-newsletterSignup-title-mobile": {
            "orig": "Be the first to know",
            "trans": ""
        },
        "footer-ourStoresBlock-buttonText-desktop": {
            "orig": "Find my nearest Store",
            "trans": ""
        },
        "footer-ourStoresBlock-information-desktop": {
            "orig": "Find your local store!",
            "trans": "Find your local size? store, view opening hours and find out where you can get free delivery to collect your order from!"
        },
        "footer-ourStoresBlock-postcodeEnter-desktop": {
            "orig": "Enter postcode...",
            "trans": ""
        },
        "footer-ourStoresBlock-postcodeIntro-desktop": {
            "orig": "Just enter your postcode below to find your nearest store.",
            "trans": ""
        },
        "footer-ourStoresBlock-title-desktop": {
            "orig": "Our Stores",
            "trans": ""
        },
        "footer-privacy": {
            "orig": "Privacy",
            "trans": ""
        },
        "footer-seeAllStores": {
            "orig": "See All Stores",
            "trans": ""
        },
        "footer-siteSecurity": {
            "orig": "Site Security",
            "trans": ""
        },
        "footer-sizeStores": {
            "orig": "size? Stores",
            "trans": ""
        },
        "footer-smartbanner-appstore": {
            "orig": "On the App Store",
            "trans": ""
        },
        "footer-smartbanner-button": {
            "orig": "VIEW",
            "trans": ""
        },
        "footer-smartbanner-googleplay": {
            "orig": "In Google Play",
            "trans": ""
        },
        "footer-smartbanner-price": {
            "orig": "FREE",
            "trans": ""
        },
        "footer-social": {
            "orig": "Social",
            "trans": ""
        },
        "footer-socialLinks-title-desktop": {
            "orig": "Follow us on social",
            "trans": ""
        },
        "footer-tnc": {
            "orig": "Terms & Conditions",
            "trans": ""
        },
        "footer-tweet": {
            "orig": "Tweet",
            "trans": ""
        },
        "footwear": {
            "orig": "Footwear",
            "trans": ""
        },
        "forFurtherDetailsSeeOur": {
            "orig": "For further details see our",
            "trans": ""
        },
        "forMoreDetails": {
            "orig": "for more details.",
            "trans": ""
        },
        "forMoreInformationVisit": {
            "orig": "For more information visit the",
            "trans": ""
        },
        "forTermsAndConditions": {
            "orig": "for T&Cs.",
            "trans": ""
        },
        "forgottenYourPassword": {
            "orig": "Forgotten your password?",
            "trans": ""
        },
        "forgottenYourPasswordShort": {
            "orig": "Forgotten your password?",
            "trans": ""
        },
        "form-emailAddressInput-title": {
            "orig": "Enter Email Address",
            "trans": ""
        },
        "fourInterestFree": {
            "orig": "4 interest free",
            "trans": ""
        },
        "free": {
            "orig": "Free",
            "trans": ""
        },
        "free-delivery-via-app-code": {
            "orig": "GET FREE UK DELIVERY VIA THE APP: USE CODE \u2018HIPAPP\u2019",
            "trans": ""
        },
        "freeClickAmpCollectOnThisItem": {
            "orig": "Free Click & Collect on this item",
            "trans": "\u00a31 Click & Collect on this item"
        },
        "freeDelivery": {
            "orig": "FREE Standard delivery",
            "trans": ""
        },
        "freeInstoreCollection": {
            "orig": "Free",
            "trans": ""
        },
        "freeUKDeliveryBadge": {
            "orig": "Free UK Delivery",
            "trans": ""
        },
        "friday": {
            "orig": "Friday",
            "trans": ""
        },
        "fulfilmentFailure": {
            "orig": "Unable to fulfil cart",
            "trans": ""
        },
        "fulfilmentProviderChange": {
            "orig": "Your item is out of stock, but don\u2019t worry, we\u2019ve got you another one! This changes who is delivering it and it may affect some of the delivery and return bits\u2026 but you\u2019ll still get exactly what you were after, so don\u2019t sweat it!  Please just have a quick look before paying.",
            "trans": ""
        },
        "fulfilmentShippingRestriction": {
            "orig": "This item can only be delivered to the UK.",
            "trans": ""
        },
        "fullName": {
            "orig": "Full Name",
            "trans": ""
        },
        "fullyCancelled": {
            "orig": "Shipment fully cancelled - refund pending",
            "trans": ""
        },
        "fullyDispatched": {
            "orig": "Fully dispatched",
            "trans": ""
        },
        "fullyRefunded": {
            "orig": "Shipment fully refunded - funds will be in your account within 3 days.",
            "trans": ""
        },
        "functional-cookie-description": {
            "orig": "These cookies enable the website to provide enhanced functionality and personalisation. They may be set by us or by third party providers whose services we have added to our pages. If you do not allow these cookies then some or all of these services may not function properly.",
            "trans": ""
        },
        "functional-cookie-title": {
            "orig": "Functional Cookies",
            "trans": ""
        },
        "gender": {
            "orig": "Gender",
            "trans": ""
        },
        "generalSubscription": {
            "orig": "General Subscription",
            "trans": ""
        },
        "getDeliverySlotMissingData": {
            "orig": "Some details needed to retrieve delivery slots is missing.",
            "trans": ""
        },
        "getDirections": {
            "orig": "Get Directions",
            "trans": ""
        },
        "getOurLatestProductRecommendationsForYou": {
            "orig": "Get our latest product recommendations for you.",
            "trans": ""
        },
        "getTheLookLead": {
            "orig": "Get the Look",
            "trans": ""
        },
        "getWishlist-error": {
            "orig": "An error occurred when retrieving wishlists",
            "trans": ""
        },
        "gift-card": {
            "orig": "GIFT CARD",
            "trans": ""
        },
        "gift-card-biggest-brands": {
            "orig": "SHOP THE BIGGEST BRANDS",
            "trans": ""
        },
        "gift-card-latest-drops": {
            "orig": "USE YOUR GIFTCARD NOW TO COP THE LATEST DROPS",
            "trans": ""
        },
        "giftCard": {
            "orig": "Gift Card",
            "trans": ""
        },
        "giftCard-cardType": {
            "orig": "Card Type",
            "trans": ""
        },
        "giftCard-checkBalanceSubmit": {
            "orig": "Check Balance",
            "trans": ""
        },
        "giftCard-enterCode": {
            "orig": "Enter gift card code",
            "trans": ""
        },
        "giftCard-enterCodePlaceholder": {
            "orig": "Gift Card Code",
            "trans": ""
        },
        "giftCard-enterPin": {
            "orig": "Pin Code",
            "trans": ""
        },
        "giftCard-enterPinPlaceholder": {
            "orig": "Pin Code",
            "trans": ""
        },
        "giftCard-error-captchaNotComplete": {
            "orig": "Please complete the captcha to continue.",
            "trans": ""
        },
        "giftCard-error-generic": {
            "orig": "Sorry there was a problem applying this gift card, please try again.",
            "trans": ""
        },
        "giftCard-error-invalidCode": {
            "orig": "Invalid gift card code.",
            "trans": ""
        },
        "giftCard-error-invalidPin": {
            "orig": "Invalid pin code entered.",
            "trans": ""
        },
        "giftCard-error-notFound": {
            "orig": "Gift card not found.",
            "trans": ""
        },
        "giftCard-number": {
            "orig": "Gift Card Number",
            "trans": ""
        },
        "giftCard-redeem-label": {
            "orig": "Enter your gift card number",
            "trans": ""
        },
        "giftCard-redeem-title": {
            "orig": "Redeem Gift Card",
            "trans": ""
        },
        "giftCard-redeemSubmit": {
            "orig": "Use Card",
            "trans": ""
        },
        "giftCard-selectValue": {
            "orig": "Select Value",
            "trans": ""
        },
        "giftCard-title": {
            "orig": "Gift Card",
            "trans": ""
        },
        "giftCardUnavailableForGiftCardPAY": {
            "orig": "Sorry, you cannot redeem a gift card for a gift card product",
            "trans": ""
        },
        "giftCardVisitLink": {
            "orig": "jdsports.co.uk\/Gift-cards",
            "trans": "size.co.uk\/Gift-cards"
        },
        "giftReceipt": {
            "orig": "Gift Receipt",
            "trans": ""
        },
        "giftWrapMyOrder": {
            "orig": "Gift wrap my order",
            "trans": ""
        },
        "giftcardPinWarning": {
            "orig": "If you don't have a pin code on the back of your gift card please use 1111.",
            "trans": ""
        },
        "giftcards-GiftcardNumber": {
            "orig": "Gift Card Number",
            "trans": ""
        },
        "giftcards-basketPage-addDiscountAndGiftcards": {
            "orig": "Add Discount and Gift Cards",
            "trans": ""
        },
        "giftcards-checkBalance-button": {
            "orig": "Check Balance",
            "trans": ""
        },
        "giftcards-checkBalance-currentBalance": {
            "orig": "Balance",
            "trans": ""
        },
        "giftcards-checkBalance-enterCard": {
            "orig": "Already purchased a card or just been given one? Enter your card number with no spaces or dashes and PIN below, to check your balance",
            "trans": ""
        },
        "giftcards-checkBalance-errorMessage": {
            "orig": "Invalid giftcard number or PIN provided.",
            "trans": ""
        },
        "giftcards-checkBalance-expiryDate": {
            "orig": "Expiry Date",
            "trans": ""
        },
        "giftcards-checkYourBalance": {
            "orig": "CHECK YOUR BALANCE",
            "trans": ""
        },
        "giftcards-checkout-completeYourOrder": {
            "orig": "Complete Your Order",
            "trans": ""
        },
        "giftcards-confirmationPage-giftcardsSubtotal": {
            "orig": "Giftcards:",
            "trans": ""
        },
        "giftcards-eGiftCard": {
            "orig": "eGift Card",
            "trans": ""
        },
        "giftcards-eGiftCustomisations-addPersonalMessage": {
            "orig": "Add personal message*",
            "trans": ""
        },
        "giftcards-eGiftCustomisations-errorRequiredFields": {
            "orig": "* Please enter all fields correctly.",
            "trans": ""
        },
        "giftcards-eGiftCustomisations-fromWho": {
            "orig": "Who shall we say it's from?*",
            "trans": ""
        },
        "giftcards-eGiftCustomisations-recipientsEmail": {
            "orig": "Recipient's email*",
            "trans": ""
        },
        "giftcards-eGiftCustomisations-recipientsName": {
            "orig": "Recipient's name*",
            "trans": ""
        },
        "giftcards-eGiftCustomisations-recipientsNumber": {
            "orig": "Recipient's number*",
            "trans": ""
        },
        "giftcards-eGiftCustomisations-selectDeliveryDate": {
            "orig": "Select a delivery date",
            "trans": ""
        },
        "giftcards-eGiftCustomisations-sendViaEmail": {
            "orig": "Send via email",
            "trans": ""
        },
        "giftcards-eGiftCustomisations-sendViaText": {
            "orig": "Send via text",
            "trans": ""
        },
        "giftcards-eGiftCustomisations-whenToSend": {
            "orig": "When do you want to send your eGift card?*",
            "trans": ""
        },
        "giftcards-enterGiftcardNumber": {
            "orig": "Enter giftcard number",
            "trans": ""
        },
        "giftcards-enterPIN": {
            "orig": "Enter PIN",
            "trans": ""
        },
        "giftcards-error-alreadyRedeemed": {
            "orig": "This gift card's balance has already been redeemed",
            "trans": ""
        },
        "giftcards-error-anatwineProducts": {
            "orig": "Sorry you cannot purchase a product that is direct from the supplier with a Gift Card. We are working on it.",
            "trans": ""
        },
        "giftcards-error-cannotBuyAGiftCard": {
            "orig": "You cannot buy a gift card using a gift card",
            "trans": ""
        },
        "giftcards-error-lockedCards": {
            "orig": "Your gift card is unavailable for redemption at the moment. Please remove from the basket or try again later",
            "trans": ""
        },
        "giftcards-error-one-could-not-find": {
            "orig": "Could not find giftcard number",
            "trans": ""
        },
        "giftcards-four-digit-PIN": {
            "orig": "4-Digit PIN",
            "trans": ""
        },
        "giftcards-headerGiftCards": {
            "orig": "GIFT CARDS",
            "trans": ""
        },
        "giftcards-listingAppliedGiftcards": {
            "orig": "Giftcard:",
            "trans": ""
        },
        "giftcards-orderconfirmation-balancelink": {
            "orig": "Thank you for your order, to check your remaining Gift Card balance visit",
            "trans": ""
        },
        "giftcards-redeem-addDiscountAndGiftcards": {
            "orig": "Add Discount and Gift Cards",
            "trans": ""
        },
        "giftcards-redeem-addGiftCard": {
            "orig": "Add Gift Card",
            "trans": ""
        },
        "giftcards-redeem-addGiftcardOrEgiftcard": {
            "orig": "Add Gift Card or eGift Card",
            "trans": ""
        },
        "giftcards-sendByEmail": {
            "orig": "Send by email.",
            "trans": ""
        },
        "giftcards-sendYourFamilyAndFriends": {
            "orig": "Send your family \u2018n\u2019 friends the perfect pressie via post or email. It\u2019s really easy\u2026 just choose below",
            "trans": ""
        },
        "giftcards-sentByPost": {
            "orig": "Sent by post",
            "trans": ""
        },
        "giftcards-toAnyAddressOrStore": {
            "orig": "to any address or the store you want.",
            "trans": ""
        },
        "giftcards-validOnlyUK": {
            "orig": "Valid in the UK only, at any JD Sports store and jdsports.co.uk",
            "trans": ""
        },
        "giftcards-zeroPayment-unableToComplete": {
            "orig": "We were unable to complete the order, please try again or contact us.",
            "trans": ""
        },
        "goToPage": {
            "orig": "Go to Page",
            "trans": ""
        },
        "googlePay": {
            "orig": "Google Pay",
            "trans": ""
        },
        "gotAQuestionChatWithUs": {
            "orig": "Got a question? Chat with us",
            "trans": ""
        },
        "gotQuestions": {
            "orig": "New to us and got questions?",
            "trans": ""
        },
        "guestOrderTracker-fieldValidationError": {
            "orig": "The order details you provided were not recognised. Please try again.",
            "trans": ""
        },
        "guestOrderTracker-findMyOrder-button": {
            "orig": "Find my order",
            "trans": "Track My Order"
        },
        "guestOrderTracker-header": {
            "orig": "Track my order",
            "trans": ""
        },
        "guestOrderTracker-orderNumber": {
            "orig": "Order No",
            "trans": "Order Number"
        },
        "guestOrderTracker-postcodeOptional": {
            "orig": "Or Postcode",
            "trans": ""
        },
        "guestOrderTracker-progressErrorSubtitle": {
            "orig": "Please check your email for further information",
            "trans": ""
        },
        "guestOrderTracker-progressErrorTitle": {
            "orig": "Sorry we were unable to retrieve the status of this order.",
            "trans": ""
        },
        "guestOrderTracker-subHeader": {
            "orig": "To see the status of your order all you need is your order number and your email address or postcode",
            "trans": ""
        },
        "guestOrderTracker-trackAnotherOrder": {
            "orig": "Track another order",
            "trans": ""
        },
        "guestOrderTracker-unexpectedError": {
            "orig": "An error occurred when trying to retrieve your order. Please try again.",
            "trans": ""
        },
        "head-over-to-size-eGift-card": {
            "orig": "Head over to size.co.uk & choose your eGift Card",
            "trans": ""
        },
        "header-searchBar-liveSearch-enterSearch": {
            "orig": "Enter your search",
            "trans": ""
        },
        "header-searchBar-liveSearch-noProducts": {
            "orig": "No Products Found",
            "trans": ""
        },
        "header-searchBar-liveSearch-noSearchTerms": {
            "orig": "No Search Terms Found",
            "trans": ""
        },
        "header-searchBar-liveSearch-suggest-title-desktop": {
            "orig": "Recommended searches",
            "trans": ""
        },
        "header-searchBar-liveSearch-title-desktop": {
            "orig": "Results",
            "trans": ""
        },
        "header-searchBar-recentProducts-title-desktop": {
            "orig": "Recently Viewed",
            "trans": ""
        },
        "header-searchBar-recentSearches-clear-mobile": {
            "orig": "Clear Recent Searches",
            "trans": ""
        },
        "header-searchBar-recentSearches-title-desktop": {
            "orig": "Recent Searches",
            "trans": ""
        },
        "header-searchBar-trendingSearches-title-desktop": {
            "orig": "Trending",
            "trans": "Trending Searches"
        },
        "header-searchBar-trendingSearches-title-mobile": {
            "orig": "Trending Searches",
            "trans": ""
        },
        "header-store-name": {
            "orig": "{storeName}",
            "trans": ""
        },
        "header-unsupportedBrowser-alternatives-desktop": {
            "orig": "supported browser",
            "trans": ""
        },
        "header-unsupportedBrowser-notice-desktop": {
            "orig": "This version of Internet Explorer is no longer supported. Please upgrade to a",
            "trans": ""
        },
        "header-usermenu-storelocator": {
            "orig": "Find a Store",
            "trans": "Find a store"
        },
        "help": {
            "orig": "Help",
            "trans": ""
        },
        "helpAmpInformation": {
            "orig": "Help & Information",
            "trans": ""
        },
        "helpAndInformation": {
            "orig": "Help & Information",
            "trans": ""
        },
        "here": {
            "orig": "here",
            "trans": ""
        },
        "home": {
            "orig": "Home",
            "trans": ""
        },
        "homeCheckoutBilling": {
            "orig": "Home \/ Checkout \/ Billing",
            "trans": ""
        },
        "homeDelivery": {
            "orig": "Home Delivery",
            "trans": ""
        },
        "hopefullyWeCanAnswerThem": {
            "orig": "Hopefully we can answer them below!",
            "trans": ""
        },
        "hostedLanding3DAuthLoadingFailure": {
            "orig": "Unable to load 3DSecure authentication, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "hostedLanding3DAuthParseFailure": {
            "orig": "Error when attempting 3DSecure authentication, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "hostedLandingErrorFailure": {
            "orig": "There was an error when attempting to pay, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "hostedLandingRejectedFailure": {
            "orig": "Your payment was rejected, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "hostedLandingRequestFailure": {
            "orig": "Unable to create a payment for your order, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "hostedLandingStartedFailure": {
            "orig": "Unable to begin 3DSecure authentication, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "howCanIReturnMyOrder": {
            "orig": "How can I return my order?",
            "trans": ""
        },
        "howDoIContactYourHeadOffice": {
            "orig": "How do I contact your Head Office for PR & Marketing opportunities?",
            "trans": ""
        },
        "howDoILeaveFeedbackAboutOne": {
            "orig": "How do I leave feedback about one of your stores?",
            "trans": ""
        },
        "howDoILeaveFeedbackAboutYour": {
            "orig": "How do I leave feedback about your online service?",
            "trans": ""
        },
        "howDoIReturnSomethingIBought": {
            "orig": "How do I return something I bought in store?",
            "trans": ""
        },
        "howDoIUnsubscribeFromYourMarketing": {
            "orig": "How do I unsubscribe from your marketing emails?",
            "trans": ""
        },
        "howDoIUseMyPromotionCode": {
            "orig": "How do I use my promotion code?",
            "trans": ""
        },
        "howLongWillItTakeForYou": {
            "orig": "How long will it take for you to process my refund?",
            "trans": ""
        },
        "iHaveAProblemWithMyDelivery": {
            "orig": "I have a problem with my delivery",
            "trans": ""
        },
        "iHaveAQuestionAboutGiftcards": {
            "orig": "I have a question about giftcards",
            "trans": ""
        },
        "iHaveAQuestionAboutPayments": {
            "orig": "I have a question about payments",
            "trans": ""
        },
        "iHaveProblemWithMyOrder": {
            "orig": "I have a problem with my order.",
            "trans": ""
        },
        "iWantToCheckStockInStores": {
            "orig": "I want to check stock in stores",
            "trans": ""
        },
        "iWantToCheckStockOnline": {
            "orig": "I want to check stock online",
            "trans": ""
        },
        "ifYourEmailAddressIsRegisteredTo": {
            "orig": "If your email address is registered to us, you will receive an email notification shortly.<br\/> Please follow the link provided in the email to create a new password",
            "trans": ""
        },
        "imHavingProblemsOnYourWebsite": {
            "orig": "I'm having problems on your website",
            "trans": ""
        },
        "in": {
            "orig": "in",
            "trans": ""
        },
        "inStock": {
            "orig": "In Stock",
            "trans": ""
        },
        "increaseQuantity": {
            "orig": "Increase quantity",
            "trans": ""
        },
        "informationOnOurStores": {
            "orig": "Information on our stores",
            "trans": ""
        },
        "instalments": {
            "orig": "instalments.",
            "trans": ""
        },
        "instalmentsAutopayWithCard": {
            "orig": "instalments. Autopay with your card.",
            "trans": ""
        },
        "interestFreeInstalment": {
            "orig": "interest free instalments.",
            "trans": ""
        },
        "interestFreeInstalments": {
            "orig": "3 interest free instalments.",
            "trans": ""
        },
        "international": {
            "orig": "International",
            "trans": ""
        },
        "introducingTheJdeGiftCard": {
            "orig": "INTRODUCING THE JD eGIFT CARD",
            "trans": ""
        },
        "invalid-gift-card": {
            "orig": "Invalid giftcard number provided.",
            "trans": ""
        },
        "invalid-gift-pin": {
            "orig": "Invalid gift card number or PIN Provided",
            "trans": ""
        },
        "invalidDataSubmitted": {
            "orig": "Invalid data submitted. Please try again.",
            "trans": ""
        },
        "invalidDiscountCode": {
            "orig": "Invalid discount code provided",
            "trans": ""
        },
        "invalidField": {
            "orig": "Invalid Field",
            "trans": ""
        },
        "invalidForm": {
            "orig": "Invalid Form",
            "trans": ""
        },
        "invalidPasswordResetLink": {
            "orig": "Invalid password reset link.",
            "trans": ""
        },
        "is": {
            "orig": "is",
            "trans": ""
        },
        "item": {
            "orig": "Item",
            "trans": ""
        },
        "itemAdded": {
            "orig": "Item Added to Bag",
            "trans": ""
        },
        "itemDecreased": {
            "orig": "Item Decreased",
            "trans": ""
        },
        "itemDetails": {
            "orig": "Item Details",
            "trans": ""
        },
        "itemInYourBasket": {
            "orig": "Item in your basket",
            "trans": ""
        },
        "itemIncreased": {
            "orig": "Item Increased",
            "trans": ""
        },
        "itemInfo-date": {
            "orig": "Date:",
            "trans": ""
        },
        "itemInfo-editors-notes": {
            "orig": "Editor's Notes",
            "trans": "Description"
        },
        "itemInfo-from": {
            "orig": "From:",
            "trans": ""
        },
        "itemInfo-message": {
            "orig": "Message:",
            "trans": ""
        },
        "itemInfo-to": {
            "orig": "To:",
            "trans": ""
        },
        "itemPrice": {
            "orig": "Item Price",
            "trans": ""
        },
        "items": {
            "orig": "Items",
            "trans": ""
        },
        "itemsInBasketAreNotReserved": {
            "orig": "Items placed in this basket are not reserved.",
            "trans": ""
        },
        "itemsInYourBasket": {
            "orig": "Items in your basket",
            "trans": ""
        },
        "iveForgottenMyPassword": {
            "orig": "I've forgotten my password",
            "trans": ""
        },
        "iveReceivedTheWrongItem": {
            "orig": "I've received the wrong item",
            "trans": ""
        },
        "jDSportsFashionGroup": {
            "orig": "JD Sports Fashion Group",
            "trans": ""
        },
        "january": {
            "orig": "January",
            "trans": ""
        },
        "jdsports_co_uk": {
            "orig": "jdsports.co.uk",
            "trans": ""
        },
        "jeans": {
            "orig": "Jeans",
            "trans": ""
        },
        "july": {
            "orig": "July",
            "trans": ""
        },
        "june": {
            "orig": "June",
            "trans": ""
        },
        "klarnaBnplLearnMore": {
            "orig": "Learn more",
            "trans": ""
        },
        "klarnaBnplPopoutText": {
            "orig": "instalments via Klarna\u2019s credit offer. 18+,",
            "trans": ""
        },
        "klarnaInThreeTerms": {
            "orig": "Pay in 3 Terms",
            "trans": ""
        },
        "klarnaPayInThreeRiskDisclosureLink": {
            "orig": "https:\/\/cdn.klarna.com\/1.0\/shared\/content\/legal\/terms\/0\/en_gb\/slice_it_card\/",
            "trans": ""
        },
        "klarnaPayLaterRiskDisclosureLink": {
            "orig": "https:\/\/cdn.klarna.com\/1.0\/shared\/content\/legal\/terms\/0\/en_gb\/pay_after_delivery\/",
            "trans": ""
        },
        "klarnaPayLaterTerms": {
            "orig": "Pay Later Terms",
            "trans": ""
        },
        "klarnaRiskDisclosure": {
            "orig": "You must be 18+ to use this credit product. Missed payments are visible to lenders and may affect your ability to obtain credit, including with Klarna. By continuing, I accept the",
            "trans": ""
        },
        "klarnaSpecificPdpBnplTerms": {
            "orig": "Buy now, pay later. This is a credit product. Eligibility criteria, terms apply. Credit check and late payment fees apply. 18+",
            "trans": "Klarna's Pay in 3 \/ Pay in 30 days are unregulated credit agreement. Borrowing more than you can afford or paying late may negatively impact your financial status and ability to obtain credit. 18+, UK residents only. Subject to status. Late fees may apply."
        },
        "lastName": {
            "orig": "Last name",
            "trans": ""
        },
        "latest": {
            "orig": "Latest",
            "trans": ""
        },
        "laybuyBnplPopoutText": {
            "orig": "Missed payments will show on your credit file potentially making credit harder to obtain and will result in late fees being added to the debt.",
            "trans": "Missed payments will show on your credit file potentially making credit harder to obtain and will result in late fees being added to the debt."
        },
        "laybuyRiskDisclosure": {
            "orig": "Laybuy is an interest-free credit product allowing you to pay for your purchase over 6 equal weekly instalments. Missed payments will show on your credit file potentially making credit harder to obtain and will result in late fees being added to the debt.",
            "trans": "Laybuy is an interest-free credit product allowing you to pay for your purchase over"
        },
        "laybuyRiskDisclosureLink": {
            "orig": "\/page\/laybuy",
            "trans": ""
        },
        "learnMore": {
            "orig": "Learn More",
            "trans": ""
        },
        "leaveItForTheSecurityGuard": {
            "orig": "leave it for the security guard in case of absence",
            "trans": ""
        },
        "leaveItInfrontOfTheDoor": {
            "orig": "please leave it in front of the door in case of absence",
            "trans": ""
        },
        "leg": {
            "orig": "Leg",
            "trans": ""
        },
        "legal": {
            "orig": "Legal",
            "trans": ""
        },
        "legalDisclaimerNotice": {
            "orig": "Buy Now Pay Later allows you to purchase goods today, using interest-free credit. Each BNPL provider has its own repayment terms and contract conditions. Some undertake credit searches and share payment data meaning missed payments will affect your credit file. Additionally, some impose fees if you miss a payment. Click on each partner's individual T&Cs for further details.",
            "trans": ""
        },
        "lessInfo": {
            "orig": "Less info",
            "trans": ""
        },
        "lettingKnowTheGiftFromYou": {
            "orig": "On the day you&#39ve chosen, they&#39ll get an email or SMS letting them know they have a gift from you",
            "trans": ""
        },
        "linkingProcessExplainedInMoreDetail": {
            "orig": "The linking process is explained in more detail in the",
            "trans": ""
        },
        "linkyouNikeAccount": {
            "orig": "Link your JD account with your Nike Membership for exclusive member-only products, experiences offers and more.",
            "trans": ""
        },
        "listing-filters-fromText-desktop": {
            "orig": "From",
            "trans": ""
        },
        "listing-filters-toText-desktop": {
            "orig": "To",
            "trans": ""
        },
        "listing-quickRefine-title": {
            "orig": "Shop by",
            "trans": ""
        },
        "listing-refine-badDataError-mobile": {
            "orig": "Invalid data supplied - could not convert filters",
            "trans": ""
        },
        "listingLoadMore": {
            "orig": "Load More",
            "trans": "Load More +"
        },
        "listingQuickBuy": {
            "orig": "Add to bag",
            "trans": ""
        },
        "liveSearch-error": {
            "orig": "An error occurred when searching for results.",
            "trans": ""
        },
        "loadDeliveryMethodFail": {
            "orig": "Unable to load delivery methods as no locale was specified.",
            "trans": ""
        },
        "loadDeliveryMethodFailArea": {
            "orig": "Unable to find any delivery methods for the area specified. Please try again.",
            "trans": ""
        },
        "loadDeliveryMethodFailGeneric": {
            "orig": "There was a problem loading the delivery methods. Please try again.",
            "trans": ""
        },
        "loadDeliveryMethodFailReebok": {
            "orig": "The Reebok items in your bag are unavailable for delivery to countries outside the EU. Please remove these items before continuing with checkout.",
            "trans": ""
        },
        "loadDeliverySlotFailGeneric": {
            "orig": "There was a problem loading the delivery slots. Please try again.",
            "trans": ""
        },
        "loadDeliverySlotsFail": {
            "orig": "Unable to load delivery slots as no slots were retrieved.",
            "trans": ""
        },
        "loading": {
            "orig": "Loading",
            "trans": ""
        },
        "loadingDeliveryMethods": {
            "orig": "Loading delivery methods",
            "trans": ""
        },
        "loadingInStoreDeliveryOptions": {
            "orig": "Loading in store delivery options",
            "trans": ""
        },
        "loadingOptions": {
            "orig": "Loading options...",
            "trans": ""
        },
        "loadingPaymentForm": {
            "orig": "Loading Payment form",
            "trans": ""
        },
        "location": {
            "orig": "Location",
            "trans": "Select your location"
        },
        "login": {
            "orig": "Login",
            "trans": ""
        },
        "login-notify-badcredentials": {
            "orig": "Incorrect username or password.",
            "trans": ""
        },
        "login-notify-blocked": {
            "orig": "Your account is currently disabled as a security measure, please contact us to regain access.",
            "trans": ""
        },
        "login-notify-suspended": {
            "orig": "Sorry we could not log you in. This account has been suspended for a few seconds due to too many failed login attempts.",
            "trans": ""
        },
        "login-notify-unabletologin": {
            "orig": "Unable to log you in at this time.",
            "trans": ""
        },
        "login-notify-wrongpassword": {
            "orig": "Incorrect password. Please try again or you can  - {resetYourPassword}",
            "trans": ""
        },
        "login-problemPopupHeader": {
            "orig": "Sorry. There was a problem.",
            "trans": ""
        },
        "login-registerBox-title": {
            "orig": "New to us?",
            "trans": ""
        },
        "manage-consent-preferences": {
            "orig": "Manage Consent Preferences",
            "trans": ""
        },
        "manageYourOrdersAndPreferences": {
            "orig": "Manage your orders and preferences.",
            "trans": ""
        },
        "march": {
            "orig": "March",
            "trans": ""
        },
        "marketing-opt-out": {
            "orig": "To opt out of marketing communications",
            "trans": ""
        },
        "marketingNoEmailSubmitted": {
            "orig": "Sorry, there was no email address submitted. Please try again.",
            "trans": ""
        },
        "maxCartValueExceeded": {
            "orig": "The requested cart value exceeds the maximum allowed cart value 150\u20ac. No more items can be added to the cart.",
            "trans": ""
        },
        "maxQuantityExceeded": {
            "orig": "Your request cannot be completed as it exceeds the maximum allowed amount of that product.",
            "trans": ""
        },
        "may": {
            "orig": "May",
            "trans": ""
        },
        "men": {
            "orig": "Men",
            "trans": ""
        },
        "mens": {
            "orig": "Mens",
            "trans": ""
        },
        "mens-footwear": {
            "orig": "Mens Footwear",
            "trans": ""
        },
        "menuSizeGuide": {
            "orig": "Find the perfect size",
            "trans": ""
        },
        "menuStoreLocator": {
            "orig": "Store Locator",
            "trans": ""
        },
        "mile": {
            "orig": "mile",
            "trans": ""
        },
        "miles": {
            "orig": "miles",
            "trans": ""
        },
        "miniBagCheckoutButton": {
            "orig": "Checkout",
            "trans": ""
        },
        "miniBagtoBagButton": {
            "orig": "Checkout",
            "trans": ""
        },
        "miniConsent-description": {
            "orig": "By clicking \u201cAccept All Cookies\u201d, you agree to the storing of cookies on your device to enhance site navigation, analyse site usage, and assist in our marketing efforts. Preferences can be adjusted in Cookie Settings. View our",
            "trans": ""
        },
        "miss": {
            "orig": "Miss",
            "trans": ""
        },
        "mobile": {
            "orig": "Mobile",
            "trans": ""
        },
        "monday": {
            "orig": "Monday",
            "trans": ""
        },
        "moreColoursAvailable": {
            "orig": "More colours available",
            "trans": ""
        },
        "moreDetails": {
            "orig": "More details",
            "trans": ""
        },
        "moreInfo": {
            "orig": "More Info",
            "trans": ""
        },
        "moreInfoTerms": {
            "orig": "For more info, read our full Terms & Conditions",
            "trans": ""
        },
        "mr": {
            "orig": "Mr",
            "trans": ""
        },
        "mrs": {
            "orig": "Mrs",
            "trans": ""
        },
        "ms": {
            "orig": "Ms",
            "trans": ""
        },
        "my-account-unlimited-delivery-launches": {
            "orig": "LAUNCHES",
            "trans": ""
        },
        "myAccount": {
            "orig": "My Account",
            "trans": ""
        },
        "myAddresses": {
            "orig": "My Addresses",
            "trans": ""
        },
        "myBag": {
            "orig": "My Bag",
            "trans": ""
        },
        "myBasket": {
            "orig": "My Basket",
            "trans": ""
        },
        "myDetails": {
            "orig": "My Details",
            "trans": ""
        },
        "myOrder": {
            "orig": "My Order",
            "trans": ""
        },
        "myOrders": {
            "orig": "Orders",
            "trans": ""
        },
        "myaccount-breadcrumbs-card": {
            "orig": "Card",
            "trans": ""
        },
        "myaccount-breadcrumbs-paymentCards": {
            "orig": "Payment Cards",
            "trans": ""
        },
        "myaccount-dashboard-defaultPaymentTitle": {
            "orig": "Default Payment Type",
            "trans": ""
        },
        "myaccount-defaultPaymentCard-title": {
            "orig": "Default Payment Type",
            "trans": ""
        },
        "myaccount-details-day": {
            "orig": "Day",
            "trans": ""
        },
        "myaccount-details-month": {
            "orig": "Month",
            "trans": ""
        },
        "myaccount-details-year": {
            "orig": "Year",
            "trans": ""
        },
        "myaccount-orders-paymentByMethod": {
            "orig": "Payment by {paymentMethod}",
            "trans": ""
        },
        "myaccount-paymentCard-deleteFailure": {
            "orig": "Sorry, we were unable to delete your card. Please try again.",
            "trans": ""
        },
        "myaccount-paymentCard-deleteSuccess": {
            "orig": "Your card has been deleted.",
            "trans": ""
        },
        "myaccount-paymentCard-title": {
            "orig": "Payment Card",
            "trans": ""
        },
        "myaccount-paymentCard-updateFailure": {
            "orig": "Sorry, we were unable to update your card. Please try again.",
            "trans": ""
        },
        "myaccount-paymentCard-updateSuccess": {
            "orig": "Your card has been updated.",
            "trans": ""
        },
        "myaccount-paymentCardForm-cardDisplayName": {
            "orig": "Display Name",
            "trans": ""
        },
        "myaccount-paymentCardForm-cardNumber": {
            "orig": "Card Number",
            "trans": ""
        },
        "myaccount-paymentCardForm-save": {
            "orig": "Save",
            "trans": ""
        },
        "myaccount-paymentCardForm-setToDefault": {
            "orig": "Set to default",
            "trans": ""
        },
        "myaccount-paymentCardForm-type": {
            "orig": "Type",
            "trans": ""
        },
        "myaccount-paymentCardForm-useAsDefault": {
            "orig": "Use as Default",
            "trans": ""
        },
        "myaccount-paymentCards-deleteButton": {
            "orig": "Delete",
            "trans": ""
        },
        "myaccount-paymentCards-editButton": {
            "orig": "Edit",
            "trans": ""
        },
        "myaccount-paymentCards-noCards": {
            "orig": "No Saved Cards",
            "trans": ""
        },
        "myaccount-paymentCards-title": {
            "orig": "Payment Type",
            "trans": ""
        },
        "myaccount-unlimited-delivery-birthday": {
            "orig": "BIRTHDAY",
            "trans": ""
        },
        "myaccount-unlimited-delivery-birthdayTreatsMessage": {
            "orig": "A LITTLE BIRTHDAY GIFT CARD JUST FOR YOU",
            "trans": ""
        },
        "myaccount-unlimited-delivery-early": {
            "orig": "EARLY",
            "trans": ""
        },
        "myaccount-unlimited-delivery-earlyLaunchesMessage": {
            "orig": "EARLY ACCESS TO THE HOTTEST DROPS",
            "trans": ""
        },
        "myaccount-unlimited-delivery-events": {
            "orig": "EVENTS",
            "trans": ""
        },
        "myaccount-unlimited-delivery-exclusive": {
            "orig": "EXCLUSIVE",
            "trans": ""
        },
        "myaccount-unlimited-delivery-exclusiveEventsMessage": {
            "orig": "ACCESS TO JD EXCLUSIVE EVENTS",
            "trans": ""
        },
        "myaccount-unlimited-delivery-forOnly": {
            "orig": "For only",
            "trans": ""
        },
        "myaccount-unlimited-delivery-jdxCost": {
            "orig": "\u00a39.99",
            "trans": ""
        },
        "myaccount-unlimited-delivery-jdxCostSavingMessage": {
            "orig": "At \u00a39.99 for 12 months, JDX pays for itself after just 3 orders with \u00a34.99 delivery",
            "trans": ""
        },
        "myaccount-unlimited-delivery-letsDoTheMaths": {
            "orig": "LET'S DO THE MATHS..",
            "trans": ""
        },
        "myaccount-unlimited-delivery-lineOneBenefits": {
            "orig": "a year you can level up your JD membership, gaining access to the most exclusive benefits",
            "trans": ""
        },
        "myaccount-unlimited-delivery-ordersPerYear": {
            "orig": "ORDERS PER YEAR",
            "trans": ""
        },
        "myaccount-unlimited-delivery-registerButton": {
            "orig": "REGISTER",
            "trans": ""
        },
        "myaccount-unlimited-delivery-savingBasedOn": {
            "orig": "Based on \u00a34.99 Next Day Delivery by Hermes",
            "trans": ""
        },
        "myaccount-unlimited-delivery-signInButton": {
            "orig": "SIGN IN",
            "trans": ""
        },
        "myaccount-unlimited-delivery-spread": {
            "orig": "SPREAD",
            "trans": ""
        },
        "myaccount-unlimited-delivery-spreadTheCostMessage": {
            "orig": "SPLIT IN 3 WITH JDX PAY",
            "trans": ""
        },
        "myaccount-unlimited-delivery-thatsNotAll": {
            "orig": "AND THAT'S NOT ALL..",
            "trans": ""
        },
        "myaccount-unlimited-delivery-theCost": {
            "orig": "THE COST",
            "trans": ""
        },
        "myaccount-unlimited-delivery-treats": {
            "orig": "TREATS",
            "trans": ""
        },
        "myaccount-unlimited-delivery-unlimitedNextDayDelivery": {
            "orig": "UNLIMITED NEXT DAY DELIVERY",
            "trans": ""
        },
        "myaccount-unlimited-delivery-withJDX": {
            "orig": "WITH JDX",
            "trans": ""
        },
        "myaccount-unlimited-delivery-withoutJDX": {
            "orig": "WITHOUT JDX",
            "trans": ""
        },
        "myaccount-unlimited-delivery-yearFiveJDXSaving": {
            "orig": "Save \u00a314.96",
            "trans": ""
        },
        "myaccount-unlimited-delivery-yearOneCostWithJDX": {
            "orig": "\u00a39.99",
            "trans": ""
        },
        "myaccount-unlimited-delivery-yearTenCostWithoutJDX": {
            "orig": "\u00a349.90",
            "trans": ""
        },
        "myaccount-unlimited-delivery-yearThreeCostWithoutJDX": {
            "orig": "\u00a314.97",
            "trans": ""
        },
        "myaccount-unlimited-delivery-yearThreeJDXSaving": {
            "orig": "Save \u00a34.98",
            "trans": ""
        },
        "myaccount-unlimited-delivery-yearTwoCostWithoutJDX": {
            "orig": "\u00a39.98",
            "trans": ""
        },
        "nameValidationMessage": {
            "orig": "Please enter your Name.",
            "trans": ""
        },
        "nativeAppsBlock-title": {
            "orig": "Download our app",
            "trans": ""
        },
        "necessary-cookie-description": {
            "orig": "These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not then work. These cookies do not store any personally identifiable information.",
            "trans": ""
        },
        "necessary-cookie-title": {
            "orig": "Strictly Necessary",
            "trans": ""
        },
        "newBillingAddress": {
            "orig": "New Billing Address",
            "trans": ""
        },
        "newIn": {
            "orig": "New In",
            "trans": ""
        },
        "newPassword": {
            "orig": "New password",
            "trans": ""
        },
        "newPasswordAdvice": {
            "orig": "Must contain upper and lower case characters, at least 8 characters, at least 1 number and at least 1 symbol.",
            "trans": ""
        },
        "newPasswordMustBeAtLeast8": {
            "orig": "New password must be at least 8 characters.",
            "trans": ""
        },
        "newPasswordsDoNotMatch": {
            "orig": "New passwords do not match.",
            "trans": ""
        },
        "newsletter-privacy-policy-link": {
            "orig": "By entering your email address you will be opted in to receive communications from HIP Store Limited. For full details on how we use your information,",
            "trans": ""
        },
        "newsletter-privacy-policy-link-text": {
            "orig": "view our privacy policy.",
            "trans": ""
        },
        "newsletter-signupfooter-placeholder": {
            "orig": "Sign up for the latest updates and 10% off",
            "trans": ""
        },
        "nextPage": {
            "orig": "Next Page",
            "trans": ""
        },
        "nikeConnectedMembership": {
            "orig": "Nike Connected Membership",
            "trans": ""
        },
        "nikeMembershipAtJDPrivacyPolicy": {
            "orig": "Nike Membership at JD Privacy Policy",
            "trans": ""
        },
        "nikeMembershipIntroduction": {
            "orig": "We're happy you've joined the JD and Nike Team. You'll be the first to know about upcoming Nike products, experiences and offers.",
            "trans": ""
        },
        "nikeMembershipIntroductionDownload": {
            "orig": "In order to get the most out of your membership, we recommend downloading to JD Sports mobile app.",
            "trans": ""
        },
        "nikeWillNoLongerreceiveInfo": {
            "orig": "Nike will no longer receive information about your future Nike and Jordan purchases with JD.",
            "trans": ""
        },
        "no": {
            "orig": "No",
            "trans": ""
        },
        "noBillingAddressFoundPleaseAddA": {
            "orig": "No Billing address found, please add a billing address below",
            "trans": ""
        },
        "noCart": {
            "orig": "No cart found",
            "trans": ""
        },
        "noDeliveryMethod": {
            "orig": "No delivery method specified",
            "trans": ""
        },
        "noDiscountEntered": {
            "orig": "No discount code specified",
            "trans": ""
        },
        "noFiltersAvailable": {
            "orig": "No Filters Available",
            "trans": ""
        },
        "noFlag": {
            "orig": "No Flag",
            "trans": ""
        },
        "noFundsHaveBeenTakenPleaseVerify": {
            "orig": "No funds have been taken, please verify your details and try again.",
            "trans": ""
        },
        "noHiddenFees": {
            "orig": "No hidden fees.",
            "trans": ""
        },
        "noItemsFound": {
            "orig": "No items found",
            "trans": ""
        },
        "noMoreSizesAvailable": {
            "orig": "No more sizes available",
            "trans": ""
        },
        "noPermissionDiscount": {
            "orig": "You do not have permission to apply this discount amount",
            "trans": ""
        },
        "noPostcodeProvided": {
            "orig": "Postcode not provided",
            "trans": ""
        },
        "noResults": {
            "orig": "No Results",
            "trans": ""
        },
        "noReviews": {
            "orig": "No Reviews",
            "trans": ""
        },
        "noReviewsForThisItem": {
            "orig": "No reviews for this item.",
            "trans": ""
        },
        "noYouCanCreateAnAccountLater": {
            "orig": "No (you can create an account later)",
            "trans": ""
        },
        "normalOpeningHours": {
            "orig": "Normal Opening hours",
            "trans": ""
        },
        "notEligibleToReturn": {
            "orig": "Not Eligible to Return",
            "trans": ""
        },
        "notYou": {
            "orig": "Not you?",
            "trans": ""
        },
        "notify-mergeCart-error": {
            "orig": "An error occurred when attempting to merge cart items",
            "trans": ""
        },
        "notifyAccountUpdated": {
            "orig": "Your account has been updated.",
            "trans": ""
        },
        "notifyAddAddressError": {
            "orig": "Sorry, there was a problem adding your address",
            "trans": ""
        },
        "notifyAddressUpdateError": {
            "orig": "There was a problem finding your address to update. Please try again.",
            "trans": ""
        },
        "notifyAddressUpdated": {
            "orig": "Your address has been updated.",
            "trans": ""
        },
        "notifyCancelled": {
            "orig": "Your payment has been cancelled",
            "trans": ""
        },
        "notifyCancelledText": {
            "orig": "No funds have been taken, please verify your details and try again.",
            "trans": ""
        },
        "notifyDeclined": {
            "orig": "Your payment has been declined",
            "trans": ""
        },
        "notifyDeleteAddressError": {
            "orig": "Sorry there was a problem deleting your address",
            "trans": ""
        },
        "notifyEmailRegistered": {
            "orig": "Your email has been registered.",
            "trans": ""
        },
        "notifyEnableCookies": {
            "orig": "This site requires cookies to be enabled. Please enable cookies in your browser settings and try again.",
            "trans": ""
        },
        "notifyInvalidEmail": {
            "orig": "Your email address is invalid.",
            "trans": ""
        },
        "notifyInvalidPostcode": {
            "orig": "Please enter a valid postcode.",
            "trans": ""
        },
        "notifyLookupFail": {
            "orig": "Sorry, we're unable to determine your position. Please try searching by town or postcode.",
            "trans": ""
        },
        "notifyMissingEmail": {
            "orig": "Please enter your Email Address.",
            "trans": ""
        },
        "notifyMissingPassword": {
            "orig": "Please enter your Password.",
            "trans": ""
        },
        "notifyNewPasswordMustMeetLengthRequirement": {
            "orig": "New password must be at least 6 characters.",
            "trans": ""
        },
        "notifyPasswordEnter": {
            "orig": "Please enter your current password.",
            "trans": ""
        },
        "notifyPasswordLength": {
            "orig": "New password must be at least 8 characters.",
            "trans": ""
        },
        "notifyPasswordMismatch": {
            "orig": "Confirmation password does not match.",
            "trans": ""
        },
        "notifyPasswordUpdateError": {
            "orig": "Unable to update your password.",
            "trans": ""
        },
        "notifyPasswordUpdated": {
            "orig": "Your password has been updated.",
            "trans": ""
        },
        "notifyRegisterAcccountError": {
            "orig": "Sorry, there was a problem registering your account. Please try again",
            "trans": ""
        },
        "notifyRegistrationFailed": {
            "orig": "Unable to register your details",
            "trans": ""
        },
        "notifySelectSize": {
            "orig": "Please select your desired size.",
            "trans": ""
        },
        "notifySetDeliveryMethodError": {
            "orig": "Sorry there was a problem setting your delivery method, please try again.",
            "trans": ""
        },
        "notifySuccess": {
            "orig": "Success!",
            "trans": ""
        },
        "notifyTY": {
            "orig": "Thank You.",
            "trans": ""
        },
        "notifyTooShortPassword": {
            "orig": "Password should consist of at least 8 alpha numeric characters (letters, numbers, symbols)",
            "trans": ""
        },
        "notifyUnableToAdd": {
            "orig": "Unable to add to basket.",
            "trans": ""
        },
        "notifyUnableToBeginPayment": {
            "orig": "Unable to begin payment, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "notifyUnableToLogout": {
            "orig": "Unable to log you out at this time.",
            "trans": ""
        },
        "notifyUnableToSelectDelMethod": {
            "orig": "Unable to select delivery method.",
            "trans": ""
        },
        "notifyUpdateAcccountError": {
            "orig": "Sorry there was a problem updating your account. Please try again.",
            "trans": ""
        },
        "notifyUpdateMarketingError": {
            "orig": "Sorry, there was a problem updating your marketing preference.",
            "trans": ""
        },
        "notifyYourAccountHasBeenCreated": {
            "orig": "Your account has been created",
            "trans": ""
        },
        "november": {
            "orig": "November",
            "trans": ""
        },
        "now": {
            "orig": "Now",
            "trans": ""
        },
        "nowPrice": {
            "orig": "Now Price:",
            "trans": ""
        },
        "oAuthCheckoutError": {
            "orig": "Your Session Has Expired",
            "trans": ""
        },
        "october": {
            "orig": "October",
            "trans": ""
        },
        "of": {
            "orig": "Of",
            "trans": ""
        },
        "offers": {
            "orig": "Offers",
            "trans": ""
        },
        "offline": {
            "orig": "Offline",
            "trans": ""
        },
        "ohYourBagIsEmpty": {
            "orig": "Oh! Your bag is empty!",
            "trans": ""
        },
        "oldPassword": {
            "orig": "Old Password",
            "trans": ""
        },
        "onThisItem": {
            "orig": "on this item",
            "trans": ""
        },
        "once-they-have-gift-card-redeemed-online-instore": {
            "orig": "Once they have their gift card, it can be redeemed online or in-store",
            "trans": ""
        },
        "onceTheyHaveTheirGiftCard": {
            "orig": "Once they have their gift card, it can be redeemed online",
            "trans": ""
        },
        "oneOrMoreItemsDispatched": {
            "orig": "1 or more items dispatched",
            "trans": ""
        },
        "onthe-day-you-have-chosen-email-sms": {
            "orig": "On the day you've chose, they'll get an email or SMS letting them know they have a gift from you",
            "trans": ""
        },
        "openingHoursAreSubjectToChangeYou": {
            "orig": "Opening hours are subject to change. You may wish to check with the store prior to visiting.",
            "trans": ""
        },
        "openingHoursMayDifferOnPublicHolidays": {
            "orig": "Opening hours may differ on public holidays.",
            "trans": ""
        },
        "openingTimes": {
            "orig": "Opening Times",
            "trans": ""
        },
        "optOutMarketing": {
            "orig": "If you would like to opt out from hearing from us please click",
            "trans": ""
        },
        "orEnterAddressManually": {
            "orig": "Or enter address manually",
            "trans": ""
        },
        "order": {
            "orig": "Order",
            "trans": ""
        },
        "order-addToCalendarMessage": {
            "orig": "Add this order to your calendar",
            "trans": ""
        },
        "order-amendments-ShipmentLength": {
            "orig": "Shipment {value} of {fulfilmentLength}",
            "trans": ""
        },
        "order-calendarDescriptionHeader": {
            "orig": "Products in your order",
            "trans": ""
        },
        "order-calendarSummaryOrder": {
            "orig": "Order",
            "trans": ""
        },
        "orderAmendments-header": {
            "orig": "Order Amendments",
            "trans": ""
        },
        "orderComplete": {
            "orig": "Order Complete",
            "trans": ""
        },
        "orderConfirmation": {
            "orig": "Order Confirmation",
            "trans": ""
        },
        "orderDate": {
            "orig": "Order Date:",
            "trans": ""
        },
        "orderDetails": {
            "orig": "Order Details",
            "trans": ""
        },
        "orderMistake": {
            "orig": "Order Mistake",
            "trans": ""
        },
        "orderNotFound": {
            "orig": "Order not found",
            "trans": ""
        },
        "orderNumLength": {
            "orig": "Order number should be at least {orderIdLength} digits long",
            "trans": ""
        },
        "orderNumMustBe9andNumeric": {
            "orig": "Order number should be at least 9 characters and numeric",
            "trans": ""
        },
        "orderNumMustBeAtLeast9": {
            "orig": "Order number should not be below 9 in length",
            "trans": ""
        },
        "orderNumber": {
            "orig": "Order Number",
            "trans": ""
        },
        "orderPlaced": {
            "orig": "Your Order has been placed",
            "trans": ""
        },
        "orderPrivacyNotice": {
            "orig": "By placing your order, you accept our {termsAndConditionsLinks} and our {privacyPolicyLink}. You agree to receive commercial offers from {groupLink}.",
            "trans": ""
        },
        "orderStatus": {
            "orig": "Order Status:",
            "trans": ""
        },
        "orderStatus-accepted": {
            "orig": "Accepted",
            "trans": ""
        },
        "orderStatus-collected": {
            "orig": "Collected",
            "trans": ""
        },
        "orderStatus-issue": {
            "orig": "Issue with order",
            "trans": ""
        },
        "orderStatus-onTheWay": {
            "orig": "On Its Way",
            "trans": ""
        },
        "orderStatus-placed": {
            "orig": "Order Placed",
            "trans": ""
        },
        "orderStatus-readyForCollection": {
            "orig": "Ready To Collect",
            "trans": ""
        },
        "orderStatus-warehouse": {
            "orig": "In Warehouse",
            "trans": "Awaiting Dispatch"
        },
        "orderTotal": {
            "orig": "Order Total:",
            "trans": ""
        },
        "orderTracker-acceptedMessage": {
            "orig": "Your order has been accepted, once your order has been dispatched we will send you an email and SMS message informing you that your order is on its way.",
            "trans": ""
        },
        "orderTracker-collectedMessage": {
            "orig": "Your order has been collected, thank you for shopping with us.",
            "trans": ""
        },
        "orderTracker-onTheWayMessage": {
            "orig": "Your order is on its way.",
            "trans": ""
        },
        "orderTracker-placedMessage": {
            "orig": "Your order is currently being reviewed, once your order has been dispatched we will send you an email and SMS message informing you that your order is on its way.",
            "trans": "Thank you for your order! It is currently being reviewed, once your order has been dispatched we will send you an email and SMS message informing you that your order is on its way."
        },
        "orderTracker-readyForCollectionMessage": {
            "orig": "Your order is now ready to collect from your chosen store.",
            "trans": ""
        },
        "orderTracker-warehouseMessage": {
            "orig": "Your order is in our warehouse being prepared, once your order has been dispatched we will send you an email and SMS message informing you that your order is on its way.",
            "trans": ""
        },
        "ordersPlacedBefore23rdMay2014Are": {
            "orig": "Older orders are not available to view online, please contact our customer services team via the help pages if you would like any more information on past purchases.",
            "trans": ""
        },
        "other": {
            "orig": "Other",
            "trans": ""
        },
        "ourStores": {
            "orig": "Our Stores",
            "trans": ""
        },
        "outOfStock": {
            "orig": "Out of Stock",
            "trans": ""
        },
        "over18TermsApply": {
            "orig": "18+ terms apply.",
            "trans": ""
        },
        "overEighteenTermsApply": {
            "orig": "18+ terms apply.",
            "trans": ""
        },
        "pGIFTCARD": {
            "orig": "Gift Card",
            "trans": ""
        },
        "page-errorMenu-back": {
            "orig": "Back To Homepage",
            "trans": ""
        },
        "page-errorMenu-continue": {
            "orig": "Continue Shopping",
            "trans": ""
        },
        "page-errorMenu-help": {
            "orig": "Help",
            "trans": ""
        },
        "page-errorMenu-storeFinder": {
            "orig": "Store Finder",
            "trans": ""
        },
        "page-footer-helpline": {
            "orig": "Need some help? Call us on {customerHelpline}",
            "trans": "Need some help? Email us at onlinehelp@size.co.uk"
        },
        "pageNotFound-mainMessage": {
            "orig": "We're sorry, we cannot find the page you're looking for.",
            "trans": ""
        },
        "pageNotFound-subMessage": {
            "orig": "Please check the address you entered is correct.",
            "trans": ""
        },
        "pageNotFound-title": {
            "orig": "Page not found",
            "trans": ""
        },
        "paid": {
            "orig": "Paid",
            "trans": ""
        },
        "paidByJDKorea": {
            "orig": "Paid by JD Sports Korea",
            "trans": ""
        },
        "password": {
            "orig": "Password",
            "trans": ""
        },
        "password-notify-mustBeDifferent": {
            "orig": "New password must not be the same as current password.",
            "trans": ""
        },
        "passwordMinLengthRequirement": {
            "orig": "Password must be at least 8 characters long",
            "trans": ""
        },
        "passwordMustContain": {
            "orig": "Must contain upper and lower case characters, at least 8 characters, and at least 1 number",
            "trans": ""
        },
        "passwordNotValid": {
            "orig": "Password entered is incorrect. Must contain upper and lower case characters, at least 8 characters, and at least 1 number",
            "trans": ""
        },
        "passwordSpecialCharactersNotAllowed": {
            "orig": "No special charecters allowed.Please check it once.",
            "trans": ""
        },
        "passwordTerms": {
            "orig": "Please enter 8 alpha numeric characters (letters & numbers)",
            "trans": "Please enter 8 alpha numeric characters (letters & numbers,)"
        },
        "passwordUpdateFail": {
            "orig": "Sorry, we were unable to update your password. Please try again.",
            "trans": ""
        },
        "passwordsDoNotMatch": {
            "orig": "Passwords do not match.",
            "trans": ""
        },
        "payByCard": {
            "orig": "Pay By Card",
            "trans": ""
        },
        "payInInstalments": {
            "orig": "Pay in instalments!",
            "trans": ""
        },
        "payMonthlyIn": {
            "orig": "Pay monthly in",
            "trans": ""
        },
        "payPalExpress-error-failedToPay": {
            "orig": "Unable to complete your purchase with PayPal",
            "trans": ""
        },
        "payPalExpress-error-failedToStart": {
            "orig": "Unable to begin PayPal payment",
            "trans": ""
        },
        "payPalExpress-error-failedToUpdate": {
            "orig": "Unable to update PayPal transaction",
            "trans": ""
        },
        "payPalExpress-loading-orderConfirmed": {
            "orig": "Processing Payment",
            "trans": ""
        },
        "payPalExpress-noDeliveryMethods": {
            "orig": "Unable to find delivery methods for chosen address",
            "trans": ""
        },
        "payPalExpress-setup-error": {
            "orig": "An error occurred when setting up your PayPal Transaction, please try again or choose another payment option",
            "trans": ""
        },
        "payWithPaypal": {
            "orig": "Pay with PayPal",
            "trans": ""
        },
        "payment": {
            "orig": "Payment",
            "trans": ""
        },
        "paymentBy": {
            "orig": "Payment by",
            "trans": ""
        },
        "paymentIcons-altTags-Afterpay": {
            "orig": "Afterpay logo",
            "trans": ""
        },
        "paymentIcons-altTags-Alipay": {
            "orig": "Alipay logo",
            "trans": ""
        },
        "paymentIcons-altTags-AmazonPay": {
            "orig": "AmazonPay logo",
            "trans": ""
        },
        "paymentIcons-altTags-ApplePay": {
            "orig": "Apple Pay logo",
            "trans": ""
        },
        "paymentIcons-altTags-Clearpay": {
            "orig": "Clearpay logo",
            "trans": ""
        },
        "paymentIcons-altTags-Entercash": {
            "orig": "Entercash logo",
            "trans": ""
        },
        "paymentIcons-altTags-Giropay": {
            "orig": "Giropay logo",
            "trans": ""
        },
        "paymentIcons-altTags-GooglePay": {
            "orig": "Google Pay logo",
            "trans": ""
        },
        "paymentIcons-altTags-Klarna": {
            "orig": "Klarna logo",
            "trans": ""
        },
        "paymentIcons-altTags-Laybuy": {
            "orig": "Laybuy logo",
            "trans": ""
        },
        "paymentIcons-altTags-Openpay": {
            "orig": "Openpay logo",
            "trans": ""
        },
        "paymentIcons-altTags-PayPal": {
            "orig": "PayPal logo",
            "trans": ""
        },
        "paymentIcons-altTags-Sofort": {
            "orig": "Sofort logo",
            "trans": ""
        },
        "paymentIcons-altTags-WeChat": {
            "orig": "WeChat logo",
            "trans": ""
        },
        "paymentIcons-altTags-iDEAL": {
            "orig": "iDEAL logo",
            "trans": ""
        },
        "paymentMethod": {
            "orig": "Payment Method",
            "trans": ""
        },
        "paymentType": {
            "orig": "Payment Type:",
            "trans": ""
        },
        "paypalExpress": {
            "orig": "Paypal Express",
            "trans": "PayPal Express"
        },
        "paypalRiskDisclosure": {
            "orig": "Pay in 3 eligibility\u202fis subject to status and approval. 18+ UK residents only. Pay in 3 is a form of credit, may not be suitable for everyone. Use may affect your credit score or make credit less accessible or more expensive for you. Consider if affordable for you.",
            "trans": ""
        },
        "paypalRiskDisclosureLink": {
            "orig": "https:\/\/www.paypal.com\/uk\/webapps\/mpp\/paypal-payin3",
            "trans": ""
        },
        "paypalpayinthree": {
            "orig": "PayPal Pay Later",
            "trans": ""
        },
        "performance-cookie-description": {
            "orig": "These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site. All information these cookies collect is aggregated and therefore anonymous. If you do not allow these cookies we will not know when you have visited our site, and will not be able to monitor its performance.",
            "trans": ""
        },
        "performance-cookie-title": {
            "orig": "Performance Cookies",
            "trans": ""
        },
        "personalisation": {
            "orig": "Personalisation: ",
            "trans": ""
        },
        "personaliseYourExperienceOnMobileTablet": {
            "orig": "Personalise your experience on mobile, tablet and desktop.",
            "trans": ""
        },
        "phone": {
            "orig": "Phone",
            "trans": ""
        },
        "phoneNumber": {
            "orig": "Phone Number",
            "trans": ""
        },
        "pinchZoom": {
            "orig": "Pinch to Zoom",
            "trans": ""
        },
        "pipingBox": {
            "orig": "please put it in the piping box",
            "trans": ""
        },
        "placeOrder": {
            "orig": "Place Order",
            "trans": ""
        },
        "placeOrderAmpPay": {
            "orig": "Place Order & Pay",
            "trans": ""
        },
        "placeOrderAmpPayByGiroPay": {
            "orig": "Pay by GiroPay",
            "trans": ""
        },
        "placeOrderAmpPayByIdeal": {
            "orig": "Pay by Ideal",
            "trans": ""
        },
        "placeOrderAmpPayBySofort": {
            "orig": "Pay by Sofort",
            "trans": ""
        },
        "placed": {
            "orig": "Placed",
            "trans": ""
        },
        "placeholder-giftcards-eGiftCustomisations-addPersonalMessage": {
            "orig": "Please add personal message",
            "trans": ""
        },
        "placeholder-giftcards-eGiftCustomisations-fromWho": {
            "orig": "Please enter from?",
            "trans": ""
        },
        "placeholder-giftcards-eGiftCustomisations-recipientsEmail": {
            "orig": "Please enter recipient's email",
            "trans": ""
        },
        "placeholder-giftcards-eGiftCustomisations-recipientsName": {
            "orig": "Please enter recipient's name",
            "trans": ""
        },
        "placeholder-giftcards-eGiftCustomisations-recipientsNumber": {
            "orig": "Please enter recipient's number",
            "trans": ""
        },
        "placeholderPostcodeOrTown": {
            "orig": "Postcode or Town",
            "trans": ""
        },
        "playVideo": {
            "orig": "Play video",
            "trans": ""
        },
        "pleaseAddAnAddress": {
            "orig": "Please add an address",
            "trans": ""
        },
        "pleaseCheckAAcceptPolicy": {
            "orig": "Please tick on the check box for E-Commerce Act Article 8 Clause.",
            "trans": ""
        },
        "pleaseCheckYourOrderDetailsBelowAny": {
            "orig": "Please check your order details below. Any necessary changes can be made by calling customer services on 0843 178 0555.",
            "trans": "Please check your order details below. If you have any questions about your order please contact us at onlinehelp@size.co.uk."
        },
        "pleaseCheckYourOrderDetailsBelowIf": {
            "orig": "Please check your order details below. If you need to make changes to your order please call customer support.",
            "trans": ""
        },
        "pleaseChooseATopic": {
            "orig": "Please choose a topic",
            "trans": ""
        },
        "pleaseClickCancelOrTryAgain": {
            "orig": "Please click cancel or try again.",
            "trans": ""
        },
        "pleaseCompleteAllTheRequiredFields": {
            "orig": "Please complete all the required fields",
            "trans": ""
        },
        "pleaseContactOurCustomerServicesTeamIf": {
            "orig": "please contact our customer services team if you would like any information on past purchases on {customerHelpline} or by email",
            "trans": "please contact our customer services team if you would like any information on past purchases on onlinehelp@size.co.uk or by email"
        },
        "pleaseEnterADiscountCode": {
            "orig": "Please enter a Discount Code.",
            "trans": "Please enter a Discount Code"
        },
        "pleaseEnterANumericValue": {
            "orig": "Please enter a numeric value.",
            "trans": ""
        },
        "pleaseEnterAPostcodeOrTown": {
            "orig": "Please enter a postcode or town.",
            "trans": ""
        },
        "pleaseEnterASearchTermOrSome": {
            "orig": "Please enter a search term or some keywords and try again.",
            "trans": ""
        },
        "pleaseEnterATown": {
            "orig": "Please enter a Town",
            "trans": ""
        },
        "pleaseEnterATownOrUKPostcode": {
            "orig": "Please enter a town or a UK postcode",
            "trans": "Please enter a town or postcode"
        },
        "pleaseEnterAValidPostcode": {
            "orig": "Please enter a valid postcode",
            "trans": ""
        },
        "pleaseEnterAlphabetsOnly": {
            "orig": "Please enter alphabets only",
            "trans": ""
        },
        "pleaseEnterAlphanumericOnly": {
            "orig": "Please enter alphanumeric characters and slash character only",
            "trans": ""
        },
        "pleaseEnterBothANameAndNumber": {
            "orig": "Please enter both a name and number.",
            "trans": ""
        },
        "pleaseEnterYourCurrentPassword": {
            "orig": "Please enter your current password.",
            "trans": ""
        },
        "pleaseEnterYourEmailAddress": {
            "orig": "Please enter your Email Address.",
            "trans": ""
        },
        "pleaseEnterYourPassword": {
            "orig": "Please enter your password.",
            "trans": ""
        },
        "pleaseNote": {
            "orig": "Please Note",
            "trans": ""
        },
        "pleaseSelectABillingAddressToAdd": {
            "orig": "Please select a billing address, to add a new billing address, click New Billing Address.",
            "trans": ""
        },
        "pleaseSelectACountry": {
            "orig": "Please select a country",
            "trans": ""
        },
        "pleaseSelectADeliveryMethod": {
            "orig": "Please select a Delivery Method",
            "trans": ""
        },
        "pleaseSelectADeliverySlot": {
            "orig": "Please select a delivery slot",
            "trans": ""
        },
        "pleaseSelectDelivery": {
            "orig": "Please select delivery request or provide delivery message.",
            "trans": ""
        },
        "pleaseSupplyBothANameAndNumberForShirt": {
            "orig": "Please supply both a name and number for shirt customisation",
            "trans": ""
        },
        "plpBrandExclusive": {
            "orig": "Brand Exclusive",
            "trans": ""
        },
        "plpFilterHeader": {
            "orig": "Filter",
            "trans": ""
        },
        "plpFreeDeliveryBadge": {
            "orig": "Free UK Delivery",
            "trans": ""
        },
        "plpNewArrival": {
            "orig": "New Arrival",
            "trans": ""
        },
        "plpWebExclusive": {
            "orig": "Online Exclusive",
            "trans": ""
        },
        "post": {
            "orig": "Post",
            "trans": ""
        },
        "postcode": {
            "orig": "Postcode",
            "trans": ""
        },
        "postofficecollect": {
            "orig": "Post Office Local Collect",
            "trans": ""
        },
        "prechat-submit-desktop": {
            "orig": "Request Chat",
            "trans": ""
        },
        "prepaidEnclosed": {
            "orig": "PrePaid + 2500 KRW enclosed",
            "trans": ""
        },
        "previousPage": {
            "orig": "Previous Page",
            "trans": ""
        },
        "price": {
            "orig": "Price",
            "trans": ""
        },
        "printGiftReceipt": {
            "orig": "Print Gift Receipt",
            "trans": ""
        },
        "printReceipt": {
            "orig": "Print Receipt",
            "trans": ""
        },
        "privacy-preference-center": {
            "orig": "Privacy Preference Centre",
            "trans": ""
        },
        "privacy-preference-center-header": {
            "orig": "When you visit any website, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences or your device and is mostly used to make the site work as you expect it to. The information does not usually directly identify you, but it can give you a more personalized web experience. We use Strictly Necessary cookies to make our website work. We would like to set optional cookies to give you a better user experience and to assist us in understanding how visitors use our site. Because we respect your right to privacy, optional cookies are not set unless you enable them. Click on the different category headings to find out more and change our default settings. Blocking some types of cookies may impact your experience of the site and the services we are able to offer. You can always change your preference by visiting 'Cookie Settings' at the bottom of the page.",
            "trans": ""
        },
        "privacyAdvice": {
            "orig": "We will use your information in accordance with our {privacyLink}. {updatedTime}",
            "trans": "We will use your information in accordance with our {privacyLink}."
        },
        "privacyNoticeInfo": {
            "orig": "We will use your information in accordance with our {privacyLink}. {updatedTime}",
            "trans": "We will use your information in accordance with our {privacyLink}."
        },
        "privacyPolicy": {
            "orig": "Privacy Policy",
            "trans": ""
        },
        "privacyPolicyLink": {
            "orig": "here",
            "trans": "privacy policy"
        },
        "privacyPolicyNotice": {
            "orig": "We will use your information in accordance with our {privacyLink}. {updatedTime}",
            "trans": "We will use your information in accordance with our {privacyLink}."
        },
        "privacyPolicyUpdateTime": {
            "orig": "Updated January 2024",
            "trans": "Updated October 2023"
        },
        "processing": {
            "orig": "Processing",
            "trans": ""
        },
        "product-fulfilment-learnmore": {
            "orig": "Learn More",
            "trans": ""
        },
        "product-options-pleaseSelect": {
            "orig": "Please Select",
            "trans": ""
        },
        "product-personalisation-acknowledgeNextDay": {
            "orig": "Next Day is unavailable on personalised items.",
            "trans": ""
        },
        "product-personalisation-acknowledgeNonReturn": {
            "orig": "Personalised items can't be returned.",
            "trans": ""
        },
        "product-personalisation-acknowledgeSquadChange": {
            "orig": "Squad numbers are subject to change.",
            "trans": ""
        },
        "product-personalisation-acknowledgeValidations": {
            "orig": "Dot (.) And hyphen (-) allowed in name field.",
            "trans": ""
        },
        "product-personalisation-acknowledgementIntro": {
            "orig": "I acknowledge the following",
            "trans": ""
        },
        "product-quickview-lowStock-desktop": {
            "orig": "LOW STOCK",
            "trans": "Low Stock"
        },
        "product-reviews-multipleReviews": {
            "orig": "{reviewCount} Reviews",
            "trans": ""
        },
        "product-reviews-readAll": {
            "orig": "Read all {reviewCount} Reviews",
            "trans": ""
        },
        "product-reviews-readOne": {
            "orig": "Read {reviewCount} Review",
            "trans": ""
        },
        "product-reviews-readReviews": {
            "orig": "Read reviews",
            "trans": ""
        },
        "product-reviews-singleReview": {
            "orig": "{reviewCount} Review",
            "trans": ""
        },
        "product-shareButton": {
            "orig": "Share",
            "trans": ""
        },
        "productAddActive": {
            "orig": "Add To Basket",
            "trans": ""
        },
        "productCode": {
            "orig": "Product Code",
            "trans": ""
        },
        "productCustomiseTitle": {
            "orig": "Personalise Your Product",
            "trans": ""
        },
        "productDetailsItemInfo": {
            "orig": "Product Details",
            "trans": ""
        },
        "productFilterHeading": {
            "orig": "Refine",
            "trans": ""
        },
        "productInfo": {
            "orig": "Product Info",
            "trans": "Details"
        },
        "productInfoAfterCareContact": {
            "orig": "After Care Contact",
            "trans": ""
        },
        "productInfoHandlingPrecautions": {
            "orig": "Handling Precautions",
            "trans": ""
        },
        "productInfoImpoter": {
            "orig": "Importer",
            "trans": ""
        },
        "productInfoManufacturer": {
            "orig": "Manufacturer",
            "trans": ""
        },
        "productInfoMaterial": {
            "orig": "Material",
            "trans": ""
        },
        "productInfoOrigin": {
            "orig": "origin",
            "trans": ""
        },
        "productInfoQualityAssuranceStandards": {
            "orig": "Quality assurance standards",
            "trans": ""
        },
        "productInfoSafetyQualityMark": {
            "orig": "Safety quality mark",
            "trans": ""
        },
        "productListing-productCount-oneProductFound": {
            "orig": "1 item",
            "trans": ""
        },
        "productListing-productCount-productsFound": {
            "orig": "{productCount}  items",
            "trans": ""
        },
        "productListing-seeMore": {
            "orig": "See More",
            "trans": ""
        },
        "productNoLongerExists": {
            "orig": "Unable to fulfil request. This product no longer exists",
            "trans": ""
        },
        "productNowPrice": {
            "orig": "Now",
            "trans": ""
        },
        "productNumber": {
            "orig": "Product Number",
            "trans": ""
        },
        "productOutOfStock": {
            "orig": "Oops, looks like one or more of your items is now out of stock.  Please remove and then we are good to go again\"",
            "trans": ""
        },
        "productSizeGuide": {
            "orig": "Size Guide",
            "trans": ""
        },
        "productSizeSelect": {
            "orig": "Select Size",
            "trans": "Select Your UK Size"
        },
        "productTerms": {
            "orig": "product terms",
            "trans": ""
        },
        "productWasPrice": {
            "orig": "Was",
            "trans": ""
        },
        "productsFilterHeading": {
            "orig": "Refine",
            "trans": ""
        },
        "productsFilterRefine": {
            "orig": "Refine",
            "trans": ""
        },
        "productsFilterSort": {
            "orig": "Sort",
            "trans": ""
        },
        "productsRefineAndOrder": {
            "orig": "Refine and Order",
            "trans": "Refine +"
        },
        "productsRefineApply": {
            "orig": "Apply",
            "trans": ""
        },
        "productsRefineClear": {
            "orig": "Clear",
            "trans": ""
        },
        "productsRefineClearAll": {
            "orig": "Clear All",
            "trans": ""
        },
        "productsRefineDone": {
            "orig": "Done",
            "trans": ""
        },
        "promoUnavailable": {
            "orig": "This item can only be delivered to the UK",
            "trans": ""
        },
        "promoUnavailablePleaseNote": {
            "orig": "This item can only be delivered to the UK",
            "trans": ""
        },
        "promoteGuest-createPassword": {
            "orig": "Create password",
            "trans": ""
        },
        "promoteGuest-description-firstLine": {
            "orig": "Get our latest product recommendations for you.",
            "trans": ""
        },
        "promoteGuest-description-fourthLine": {
            "orig": "Access to your saved items.",
            "trans": ""
        },
        "promoteGuest-description-secondLine": {
            "orig": "Personalise your experience on mobile, tablet and desktop.",
            "trans": ""
        },
        "promoteGuest-description-thirdLine": {
            "orig": "Manage your orders and preferences.",
            "trans": ""
        },
        "promoteGuest-errorMessage-alreadyPromoted": {
            "orig": "Your account has already been registered.",
            "trans": ""
        },
        "promoteGuest-errorMessage-unableToPromote": {
            "orig": "Your account was unable to be created.",
            "trans": ""
        },
        "promoteGuest-header": {
            "orig": "Track your order and quickly checkout next time by entering a password to register your account",
            "trans": ""
        },
        "promoteGuest-register": {
            "orig": "Register",
            "trans": ""
        },
        "promotionExclusionMessage": {
            "orig": "This item is excluded from emergency services and student discount promotions",
            "trans": ""
        },
        "promotional-preferences-optout-notice": {
            "orig": "To unsubscribe from all communications, please leave all boxes blank and click save.",
            "trans": ""
        },
        "promotionalPreferences": {
            "orig": "Promotional Preferences",
            "trans": ""
        },
        "promotionalPreferencesLeader": {
            "orig": "How I want to hear about promotions",
            "trans": ""
        },
        "provideLoginDetails": {
            "orig": "You must provide a username and password",
            "trans": ""
        },
        "purchaseQuantityNotAvailable": {
            "orig": "Your request cannot be completed, as the product you wish to purchase is not available in the quantity you requested.",
            "trans": ""
        },
        "qtyDispatched": {
            "orig": "Qty Dispatched",
            "trans": ""
        },
        "qtyOrdered": {
            "orig": "Qty Ordered",
            "trans": ""
        },
        "qtyToCancel": {
            "orig": "Qty to Cancel",
            "trans": ""
        },
        "qtyToExchange": {
            "orig": "Qty to Exchange",
            "trans": ""
        },
        "qtyToReturn": {
            "orig": "Qty to Return",
            "trans": ""
        },
        "quantity": {
            "orig": "Quantity",
            "trans": ""
        },
        "quickView": {
            "orig": "Quick Buy",
            "trans": ""
        },
        "quickview-deliverymethods-freedelivery-desktop": {
            "orig": "Free delivery on this item",
            "trans": ""
        },
        "raminingBalanceNote": {
            "orig": "Any remaining balance that is not used within the twelve-month period, the eGift Card will expire and the remaining balance will reduce to nil.",
            "trans": ""
        },
        "read": {
            "orig": "Read",
            "trans": ""
        },
        "readAllReviews": {
            "orig": "Read all Reviews",
            "trans": ""
        },
        "reason": {
            "orig": "Reason",
            "trans": ""
        },
        "reasonForReturn": {
            "orig": "Reason For Return",
            "trans": ""
        },
        "receievedWrongProduct": {
            "orig": "Received different product from ordered product",
            "trans": ""
        },
        "receipt": {
            "orig": "Receipt",
            "trans": ""
        },
        "recentlyViewed": {
            "orig": "Recently Viewed",
            "trans": ""
        },
        "recommendedForYou": {
            "orig": "Recommended for you",
            "trans": ""
        },
        "redeem": {
            "orig": "Apply",
            "trans": ""
        },
        "redeemOnlineAndInstore": {
            "orig": "REDEEM ONLINE",
            "trans": ""
        },
        "redirectingToDeliveryPage": {
            "orig": "Redirecting to delivery page",
            "trans": ""
        },
        "redirectingToTheBillingPage": {
            "orig": "Redirecting to the billing page",
            "trans": ""
        },
        "reducedToClear": {
            "orig": "Reduced to clear",
            "trans": ""
        },
        "refineBy": {
            "orig": "Refine By",
            "trans": ""
        },
        "region_size": {
            "orig": "UK",
            "trans": ""
        },
        "register": {
            "orig": "Register",
            "trans": ""
        },
        "register-marketingOptIn-label": {
            "orig": "We'd like to share our latest launches, offers and new drops with you. Please tick this box if you'd like to hear from us.",
            "trans": ""
        },
        "register-marketingOptIn-label-email": {
            "orig": "Please tick this box if you\u2019d like to hear from us by email",
            "trans": ""
        },
        "register-marketingOptIn-label-nike-account": {
            "orig": "We'd like to share our latest launches, offers and new drops with you. Please tick this box if you'd like to hear from us.",
            "trans": ""
        },
        "register-marketingOptIn-label-nike-account-email": {
            "orig": "Please tick this box if you'd like to hear from us by Email",
            "trans": ""
        },
        "register-marketingOptIn-label-nike-account-sms": {
            "orig": "Please tick this box if you'd like to hear from us by SMS",
            "trans": ""
        },
        "register-marketingOptIn-label-sms": {
            "orig": "Please tick this box if you\u2019d like to hear from us by SMS",
            "trans": ""
        },
        "register-notify-accountexists": {
            "orig": "Sorry unable to create your account as an account with that email address already exists",
            "trans": ""
        },
        "registerForAnAccount": {
            "orig": "Register for an account",
            "trans": ""
        },
        "registrationPagePrivacyNotice": {
            "orig": "By entering your email address you will be opted in to receive communications for the JD Sports Group. For full details on how we use your information, view our {privacyLink}. {updatedTime}",
            "trans": "We will use your information in accordance with our {privacyLink}."
        },
        "reject-all": {
            "orig": "Reject All",
            "trans": ""
        },
        "reject-all-cookies": {
            "orig": "Reject All Cookies",
            "trans": ""
        },
        "relatedCategories": {
            "orig": "Related Categories",
            "trans": ""
        },
        "remainingBalanceNote": {
            "orig": "Any remaining balance that is not used within the twelve-month period, the eGift Card will expire and the remaining balance will reduce to nil.",
            "trans": ""
        },
        "remove": {
            "orig": "Remove",
            "trans": ""
        },
        "removeFromWishlist": {
            "orig": "Remove from Wishlist",
            "trans": ""
        },
        "removeFromWishlistName": {
            "orig": "Remove from '{name}'",
            "trans": ""
        },
        "removeItem": {
            "orig": "Remove Item",
            "trans": ""
        },
        "removeOutOfStockItemsBeforeContinue": {
            "orig": "Please remove out of stock items before continuing",
            "trans": ""
        },
        "requestCancellation": {
            "orig": "Request Cancellation",
            "trans": ""
        },
        "requestExchange": {
            "orig": "Request Exchange",
            "trans": ""
        },
        "requestReturn": {
            "orig": "Request return",
            "trans": ""
        },
        "resetPassword": {
            "orig": "Reset Password",
            "trans": ""
        },
        "resetPasswordTitle": {
            "orig": "Reset Password",
            "trans": ""
        },
        "resetYourPassword": {
            "orig": "Reset your password",
            "trans": ""
        },
        "returns": {
            "orig": "Returns",
            "trans": ""
        },
        "returnsAccountName": {
            "orig": "Account Name",
            "trans": ""
        },
        "returnsAccountNumber": {
            "orig": "Account Number",
            "trans": ""
        },
        "returnsBankName": {
            "orig": "Bank Name",
            "trans": ""
        },
        "returnsHowToRefund": {
            "orig": "How to Refund",
            "trans": ""
        },
        "returnsPhoneNumber": {
            "orig": "Phone number",
            "trans": ""
        },
        "returnsSelectBank": {
            "orig": "Please select your bank",
            "trans": ""
        },
        "rev": {
            "orig": "Rev",
            "trans": ""
        },
        "review": {
            "orig": "Review",
            "trans": ""
        },
        "reviewYourOrderDetails": {
            "orig": "Review Your Order Details",
            "trans": ""
        },
        "reviews": {
            "orig": "Reviews",
            "trans": ""
        },
        "sale": {
            "orig": "Sale",
            "trans": ""
        },
        "sameDayDelivery-checking": {
            "orig": "Validating Postcode",
            "trans": ""
        },
        "sameDayDelivery-notFound": {
            "orig": "Same day delivery is not supported for this post code.",
            "trans": ""
        },
        "sameDayDelivery-postcodeValidationFail": {
            "orig": "Unable to check postcode availability",
            "trans": ""
        },
        "sameDayDelivery-validPostcodeRequired": {
            "orig": "You must input a valid postcode.",
            "trans": ""
        },
        "sameDayDelivery-validationFailed": {
            "orig": "Unable to validate same day delivery method",
            "trans": ""
        },
        "sameDayDelivery-validationSuccess": {
            "orig": "Your postcode is available for same day delivery",
            "trans": ""
        },
        "saturday": {
            "orig": "Saturday",
            "trans": ""
        },
        "save": {
            "orig": "Save",
            "trans": ""
        },
        "saveMyDetailsForNextTime": {
            "orig": "Save my details for next time?",
            "trans": ""
        },
        "savedToWishlist": {
            "orig": "Saved to wishlist",
            "trans": ""
        },
        "savedToWishlistName": {
            "orig": "Saved to '{name}'",
            "trans": ""
        },
        "saving": {
            "orig": "Saving",
            "trans": ""
        },
        "savingBillingAddressToCart": {
            "orig": "Saving billing address to cart",
            "trans": ""
        },
        "savingNewBillingAddress": {
            "orig": "Saving New Billing Address",
            "trans": ""
        },
        "search": {
            "orig": "Search",
            "trans": ""
        },
        "searchAgain": {
            "orig": "Search Again",
            "trans": ""
        },
        "securePayment": {
            "orig": "Secure Payment",
            "trans": ""
        },
        "see": {
            "orig": "See",
            "trans": ""
        },
        "seeStoreDetailsForMoreInformation": {
            "orig": "See store details for more information",
            "trans": ""
        },
        "selectABillingAddress": {
            "orig": "Select a billing address.",
            "trans": ""
        },
        "selectACountry": {
            "orig": "Select a country",
            "trans": ""
        },
        "selectADeliveryMethod": {
            "orig": "Select a delivery method",
            "trans": ""
        },
        "selectAcceptPolicy": {
            "orig": "Please tick on the check box.",
            "trans": ""
        },
        "selectAddress": {
            "orig": "Select Address",
            "trans": ""
        },
        "selectBillingAddress": {
            "orig": "Select Billing Address",
            "trans": ""
        },
        "selectCancelItems": {
            "orig": "Please select items to cancel the order.",
            "trans": ""
        },
        "selectDeliveryAddress": {
            "orig": "Select Delivery Address",
            "trans": ""
        },
        "selectDeliveryMethod": {
            "orig": "Select Delivery Method",
            "trans": ""
        },
        "selectDeliveryRequest": {
            "orig": "Please select delivery request",
            "trans": ""
        },
        "selectDeliverySlotFailGeneric": {
            "orig": "There was a problem selecting that chosen delivery slot. Please try again.",
            "trans": ""
        },
        "selectDeliverySlotMissingData": {
            "orig": "Some details regarding the chosen delivery slot are missing",
            "trans": ""
        },
        "selectExchangeItems": {
            "orig": "Please select required fields to exchange in the order.",
            "trans": ""
        },
        "selectExistingAddress": {
            "orig": "Select Existing Address",
            "trans": ""
        },
        "selectPaymentMethod": {
            "orig": "Select Payment Method",
            "trans": ""
        },
        "selectPlayerOptional": {
            "orig": "Select Player (Optional)",
            "trans": ""
        },
        "selectReasonCode": {
            "orig": "Select Reason Code",
            "trans": ""
        },
        "selectReturnItems": {
            "orig": "Please select items to return in the order.",
            "trans": ""
        },
        "selectSize": {
            "orig": "Select Size",
            "trans": "Select Your UK Size"
        },
        "selectSizeSticky": {
            "orig": "Select Size",
            "trans": ""
        },
        "selected": {
            "orig": "Selected",
            "trans": ""
        },
        "selectedAddress": {
            "orig": "Selected Address",
            "trans": ""
        },
        "send-via-email-sms-delivery": {
            "orig": "Send via email or SMS for instant delivery",
            "trans": ""
        },
        "sendGiftcardtoFamily": {
            "orig": "send your family n friends the perfect pressie via post, email or text. its really easy... just choose below",
            "trans": ""
        },
        "sendViaEmailorSMS": {
            "orig": "Send via email or SMS for instant delivery",
            "trans": ""
        },
        "september": {
            "orig": "September",
            "trans": ""
        },
        "service": {
            "orig": "Service",
            "trans": ""
        },
        "shareOnFacebook": {
            "orig": "Share on Facebook",
            "trans": ""
        },
        "shareOnTwitter": {
            "orig": "Share on Twitter",
            "trans": ""
        },
        "shareWithGooglePlus": {
            "orig": "Share with Google Plus",
            "trans": ""
        },
        "shareWithHUKD": {
            "orig": "Share with HUKD",
            "trans": ""
        },
        "shareWithPinterest": {
            "orig": "Share with Pinterest",
            "trans": ""
        },
        "shippingBankTransfer": {
            "orig": "Bank Transfer (5,000 KRW) [Nonghyup Bank :301-0217- 2984-31 \/ Account Holder : JD Sports Fashion Korea Inc]",
            "trans": ""
        },
        "shippingFee": {
            "orig": "Shipping Fee",
            "trans": ""
        },
        "shopMore": {
            "orig": "Shop More",
            "trans": "Continue Shopping"
        },
        "shop_more_adidas_cta_text": {
            "orig": "Shop more adidas",
            "trans": "Shop more adidas"
        },
        "shopnow": {
            "orig": "SHOP NOW",
            "trans": ""
        },
        "shorts": {
            "orig": "Shorts",
            "trans": ""
        },
        "showAll": {
            "orig": "Show All",
            "trans": ""
        },
        "showLess": {
            "orig": "Show Less",
            "trans": "Show Less"
        },
        "showMore": {
            "orig": "Show More",
            "trans": "Show More"
        },
        "showOptions": {
            "orig": "Show Options",
            "trans": ""
        },
        "showingResultsFor": {
            "orig": "Showing results for",
            "trans": ""
        },
        "signIn": {
            "orig": "Sign In",
            "trans": ""
        },
        "signInForOneClickCheckout": {
            "orig": "Sign in for One-Click Checkout",
            "trans": ""
        },
        "signInOrCreateAcc": {
            "orig": "Sign in or Create account",
            "trans": ""
        },
        "signOut": {
            "orig": "Sign Out",
            "trans": ""
        },
        "sir": {
            "orig": "Sir",
            "trans": ""
        },
        "siteMap": {
            "orig": "Site Map",
            "trans": ""
        },
        "size": {
            "orig": "Size",
            "trans": ""
        },
        "sizeGuide": {
            "orig": "Size Guide",
            "trans": ""
        },
        "sizeGuideError": {
            "orig": "sizeGuideError",
            "trans": ""
        },
        "someItemsUnavailable": {
            "orig": "Some of the items in your basket are unavailable. Please remove these items before continuing with checkout",
            "trans": ""
        },
        "someOfYourInformationWasIncorrect": {
            "orig": "Some of your information was incorrect",
            "trans": ""
        },
        "someOfYourInputWasIncorrectThe": {
            "orig": "Some of your input was incorrect, the fields have been highlighted for your convenience",
            "trans": "Some of your input was incorrect, please select the find address button and choose your address"
        },
        "someOfYourInputWasMissing": {
            "orig": "Some of the required fields were not filled out. They have been highlighted for your convenience.",
            "trans": ""
        },
        "somethingIsMissingFromMyOrder": {
            "orig": "Something is missing from my order",
            "trans": ""
        },
        "sorryThereWasAProblem": {
            "orig": "Sorry. There was a problem.",
            "trans": ""
        },
        "sorryThisProductIsNoLongerInStock": {
            "orig": "Sorry, this product is no longer in stock.",
            "trans": ""
        },
        "sorryWeCantFindAnyProductsThat": {
            "orig": "Sorry, we can't find any products that match your criteria.",
            "trans": ""
        },
        "sorryWeCouldNotRetrieveTheDetails": {
            "orig": "Sorry, we could not retrieve the details for this order.",
            "trans": ""
        },
        "sortBy": {
            "orig": "Sort by",
            "trans": ""
        },
        "specificLaybuyBbplLegalText": {
            "orig": "Laybuy offers interest-free credit, allowing you to pay for your purchase over 6 equal weekly instalments. Make sure you can afford to repay the amounts due. Missed payments will show on your credit file potentially making credit harder to obtain and will result in late fees being added to the debt.",
            "trans": ""
        },
        "spend": {
            "orig": "Spend",
            "trans": ""
        },
        "standardDelivery": {
            "orig": "Standard Delivery",
            "trans": ""
        },
        "startAnotherSearch": {
            "orig": "Start another search",
            "trans": ""
        },
        "startShopping": {
            "orig": "Start Shopping",
            "trans": ""
        },
        "startShoppingNowOrAdd": {
            "orig": "Start shopping now or adding items to your wish list to save them for later.",
            "trans": ""
        },
        "stateProvince": {
            "orig": "State\/Province",
            "trans": ""
        },
        "step-four": {
            "orig": "step four",
            "trans": ""
        },
        "step-one": {
            "orig": "step one",
            "trans": ""
        },
        "step-three": {
            "orig": "step three",
            "trans": ""
        },
        "step-two": {
            "orig": "step two",
            "trans": ""
        },
        "stepFour": {
            "orig": "STEP FOUR",
            "trans": ""
        },
        "stepOne": {
            "orig": "STEP ONE",
            "trans": ""
        },
        "stepThree": {
            "orig": "STEP THREE",
            "trans": ""
        },
        "stepTwo": {
            "orig": "STEP TWO",
            "trans": ""
        },
        "stockStatusMessage": {
            "orig": "Hurry! Only a few left in stock.",
            "trans": ""
        },
        "stopEditing": {
            "orig": "Stop Editing",
            "trans": ""
        },
        "storeDetails": {
            "orig": "Store Details",
            "trans": ""
        },
        "storeDetailsAndOpeningHours": {
            "orig": "Store details and opening hours",
            "trans": ""
        },
        "storeFinder": {
            "orig": "Store Finder",
            "trans": ""
        },
        "storeLocator": {
            "orig": "Store Locator",
            "trans": ""
        },
        "storeLocatorAll": {
            "orig": "View all Stores",
            "trans": ""
        },
        "storeResults": {
            "orig": "Store Results",
            "trans": ""
        },
        "storelocator-allStores-link": {
            "orig": "A-Z of Stores",
            "trans": ""
        },
        "storelocator-allStores-link-gb": {
            "orig": "A-Z of UK Stores",
            "trans": "A-Z of Stores"
        },
        "storelocator-findStore-title": {
            "orig": "Find my Store",
            "trans": "Find Store"
        },
        "storelocator-findStore-title-gb": {
            "orig": "Find UK Store",
            "trans": "Find Store"
        },
        "storelocator-search-geolocate": {
            "orig": "Stores Near Me",
            "trans": "Stores near me"
        },
        "storelocator-search-geolocate-title": {
            "orig": "Find stores near me",
            "trans": ""
        },
        "storelocator-search-placeholder": {
            "orig": "Postcode or Town",
            "trans": ""
        },
        "storelocator-search-submit": {
            "orig": "Find",
            "trans": ""
        },
        "storelocator-search-tooltip": {
            "orig": "Enter a postcode or town",
            "trans": "Enter Postcode or Town"
        },
        "storelocator-title": {
            "orig": "Store Finder",
            "trans": ""
        },
        "street": {
            "orig": "Street",
            "trans": ""
        },
        "stuck-for-ideas-get-in-tied-up": {
            "orig": "Stuck for ideas? Get it tied up with the Size? Gift Card",
            "trans": ""
        },
        "studentDiscountGiftCardError": {
            "orig": "Sorry, you cannot apply student discount to a Gift Card.",
            "trans": ""
        },
        "subTotal": {
            "orig": "Sub-total",
            "trans": ""
        },
        "subject": {
            "orig": "Subject",
            "trans": ""
        },
        "submit": {
            "orig": "Submit",
            "trans": ""
        },
        "submitCode": {
            "orig": "Submit code",
            "trans": ""
        },
        "subtotal": {
            "orig": "Subtotal",
            "trans": ""
        },
        "succeeded": {
            "orig": "Succeeded",
            "trans": ""
        },
        "success": {
            "orig": "Success!",
            "trans": ""
        },
        "successResponse": {
            "orig": "Thank you for your request - a customer care agent will be in contact shortly to arrange courier collection",
            "trans": ""
        },
        "summary": {
            "orig": "Summary",
            "trans": ""
        },
        "sunday": {
            "orig": "Sunday",
            "trans": ""
        },
        "sunglasses": {
            "orig": "Sunglasses",
            "trans": ""
        },
        "surname": {
            "orig": "Surname",
            "trans": ""
        },
        "swimwear": {
            "orig": "Swimwear",
            "trans": ""
        },
        "talkToUsOnlineNowOrCall": {
            "orig": "Talk to us online now or call 0161 393 7055",
            "trans": "Talk to us online now or send us an email at onlinehelp@size.co.uk"
        },
        "targeting-cookie-description": {
            "orig": "These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other sites. They do not store directly personal information, but are based on uniquely identifying your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.",
            "trans": ""
        },
        "targeting-cookie-title": {
            "orig": "Tracking Cookies",
            "trans": ""
        },
        "teams": {
            "orig": "Teams",
            "trans": ""
        },
        "telephone": {
            "orig": "Telephone",
            "trans": ""
        },
        "termsAndConditionLink": {
            "orig": "terms and conditions",
            "trans": ""
        },
        "test": {
            "orig": "test",
            "trans": ""
        },
        "thankYouForYourOrderTheExpected": {
            "orig": "Thank you for your order. The expected delivery date is",
            "trans": ""
        },
        "thanksForContactingUs": {
            "orig": "Thanks for contacting us with your comments and questions. We'll respond to you very soon.",
            "trans": ""
        },
        "theEmailAddressYouEnteredIsIncorrect": {
            "orig": "The email address you entered is incorrect please enter a valid email",
            "trans": ""
        },
        "theNextTimeYouHearFromUsWillBeViaAServiceEmails": {
            "orig": "The next time you hear from us will be via a service emails - this will include a link for you to unsubscribe from our marketing communications.",
            "trans": ""
        },
        "thePromotionCodeYouHaveEnteredIs": {
            "orig": "The promotion code you have entered is invalid. Please verify the code and try again.",
            "trans": ""
        },
        "thejdgiftcard": {
            "orig": "THE JD GIFT CARD",
            "trans": ""
        },
        "thenClickTheAddToBagButton": {
            "orig": "then click the 'add to bag' button next to the product you wish to purchase.",
            "trans": ""
        },
        "thereWasAnErrorWhenAttemptingTo": {
            "orig": "There was an error when attempting to pay, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "thereWasAnErrorWhenTryingTo": {
            "orig": "There was an error when trying to add your billing address to the cart, please try again",
            "trans": ""
        },
        "thisIsACreditProduct": {
            "orig": "This is an unregulated credit product. Late payment fees may apply with some providers. 18+ terms apply.",
            "trans": ""
        },
        "thisIsTheNameThatWillBe": {
            "orig": "This is the name that will be printed on your parcel.",
            "trans": ""
        },
        "thisItemIsExcludedFromDiscount": {
            "orig": "This item is excluded from discount promotions",
            "trans": ""
        },
        "thisSiteRequiresCookiesToBeEnabled": {
            "orig": "This site requires cookies to be enabled. Please enable cookies in your browser settings and try again.",
            "trans": ""
        },
        "threeInterestFree": {
            "orig": "3 interest free",
            "trans": ""
        },
        "thursday": {
            "orig": "Thursday",
            "trans": ""
        },
        "title": {
            "orig": "Title",
            "trans": ""
        },
        "titleEnterPostcodeOrTown": {
            "orig": "Enter postcode or town",
            "trans": ""
        },
        "titlePrimaryBillingAddress": {
            "orig": "Primary Billing Address",
            "trans": ""
        },
        "titlePrimaryDeliveryAddress": {
            "orig": "Primary Delivery Address",
            "trans": ""
        },
        "toAddProductsToYourBagSimply": {
            "orig": "To add products to your bag simply select your size and quantity",
            "trans": ""
        },
        "toAddProductsToYourWishlistSimply": {
            "orig": "To add a product to your wishlist just click the 'Save for later' button",
            "trans": ""
        },
        "toResetYourPasswordPleaseEnterYour": {
            "orig": "To reset your password please enter your email address below.",
            "trans": ""
        },
        "tooltip-fieldInfo-address1": {
            "orig": "Address is a required field.",
            "trans": ""
        },
        "tooltip-fieldInfo-address2": {
            "orig": "Optionally provide extra address details.",
            "trans": ""
        },
        "tooltip-fieldInfo-address3": {
            "orig": "Optionally provide extra address details",
            "trans": ""
        },
        "tooltip-fieldInfo-county": {
            "orig": "Optionally provide your county.",
            "trans": ""
        },
        "tooltip-fieldInfo-deliveryMessage": {
            "orig": "Please select delivery request or provide delivery message, minimum of 50 characters length.",
            "trans": ""
        },
        "tooltip-fieldInfo-email": {
            "orig": "Email must be entered in the correct format.",
            "trans": ""
        },
        "tooltip-fieldInfo-firstName": {
            "orig": "Please provide your first name. This cannot contain numbers.",
            "trans": ""
        },
        "tooltip-fieldInfo-mobile": {
            "orig": "Optionally provide a contact mobile number",
            "trans": ""
        },
        "tooltip-fieldInfo-phone": {
            "orig": "Please provide your contact telephone number. This should be 8-14 characters long and should only contain numbers or a '+' symbol",
            "trans": ""
        },
        "tooltip-fieldInfo-subject": {
            "orig": "Please provide the subject you wish to discuss.",
            "trans": ""
        },
        "tooltip-fieldInfo-surName": {
            "orig": "Please provide your surname. This cannot contain numbers.",
            "trans": ""
        },
        "tooltip-fieldInfo-town": {
            "orig": "Town is a required field.",
            "trans": ""
        },
        "total": {
            "orig": "Total",
            "trans": ""
        },
        "totalPaymentAmount": {
            "orig": "Total Payment Amount",
            "trans": ""
        },
        "totalSaving": {
            "orig": "Total saving",
            "trans": ""
        },
        "townCity": {
            "orig": "Town\/City",
            "trans": ""
        },
        "track": {
            "orig": "track",
            "trans": ""
        },
        "transferCartFail": {
            "orig": "Unable to transfer cart. Please try again.",
            "trans": ""
        },
        "trendingSearches-error": {
            "orig": "Could not load trending searches.",
            "trans": ""
        },
        "tryAgain": {
            "orig": "Try Again",
            "trans": ""
        },
        "tuesday": {
            "orig": "Tuesday",
            "trans": ""
        },
        "uKExcludingChannelIslands": {
            "orig": "UK (Excluding Channel Islands)",
            "trans": ""
        },
        "unableToAddItemToCart": {
            "orig": "Unable to add item to cart.",
            "trans": ""
        },
        "unableToAddToCart": {
            "orig": "Unable to add to cart",
            "trans": ""
        },
        "unableToBegin3DSecureAuthenticationPleaseTry": {
            "orig": "Unable to begin 3DSecure authentication, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "unableToBeginPayment": {
            "orig": "Unable to begin payment",
            "trans": ""
        },
        "unableToCancel": {
            "orig": "is unable to cancel",
            "trans": ""
        },
        "unableToCreateAGuestAccountPlease": {
            "orig": "Unable to create a guest account, please try again",
            "trans": ""
        },
        "unableToCreateAPaymentOrderFor": {
            "orig": "Unable to create a payment order for your cart, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "unableToDeleteAddress": {
            "orig": "Unable to delete address.",
            "trans": ""
        },
        "unableToFindYourAccount": {
            "orig": "Unable to find your account.",
            "trans": ""
        },
        "unableToLoad3DSecureAuthenticationPleaseTry": {
            "orig": "Unable to load 3DSecure authentication, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "unableToLoadDeliveryMethods": {
            "orig": "Unable to load delivery methods",
            "trans": ""
        },
        "unableToLoadStoreDeliveryPleaseTry": {
            "orig": "Unable to load store delivery, please try again'",
            "trans": ""
        },
        "unableToLogYouOutAtThis": {
            "orig": "Unable to log you out at this time.",
            "trans": ""
        },
        "unableToRegisterYourDetails": {
            "orig": "Unable to register your details",
            "trans": ""
        },
        "unableToRemoveItemFromCart": {
            "orig": "Unable to remove item from cart.",
            "trans": ""
        },
        "unableToSaveAddress": {
            "orig": "Unable to save address",
            "trans": ""
        },
        "unableToSaveDeliveryAddress": {
            "orig": "Unable to save delivery address",
            "trans": ""
        },
        "unableToSaveDeliveryMethod": {
            "orig": "Unable to save delivery method",
            "trans": ""
        },
        "unableToUpdateAddress": {
            "orig": "Unable to update address.",
            "trans": ""
        },
        "unableToUpdateCart": {
            "orig": "Unable to update cart",
            "trans": ""
        },
        "unableToUpdateCartNoStock": {
            "orig": "Unable to fulfil request. There is no stock available",
            "trans": ""
        },
        "unableToUpdateCartTryAgain": {
            "orig": "There was a problem and we were unable to update your cart. Please try again.",
            "trans": ""
        },
        "unableToUpdateYourDetails": {
            "orig": "Unable to update your details",
            "trans": ""
        },
        "unableToUpdateYourPassword": {
            "orig": "Unable to update your password.",
            "trans": ""
        },
        "unableToUpdateYourPreferences": {
            "orig": "Unable to update your preferences",
            "trans": ""
        },
        "unableUpdatePreferencesTryAgain": {
            "orig": "Sorry there was a problem updating your preferences. Please try again.",
            "trans": ""
        },
        "unavailableForGiftCards": {
            "orig": "Sorry, you cannot redeem a gift card for a product that is direct from supplier. We're working on it",
            "trans": ""
        },
        "unitnumber": {
            "orig": "Unit Number",
            "trans": ""
        },
        "unknownEmailAddress": {
            "orig": "Unknown email address",
            "trans": ""
        },
        "unlimited-delivery-DeliveryCostTableHeader": {
            "orig": "DELIVERY COST",
            "trans": ""
        },
        "updateBillingFail": {
            "orig": "Unable to update the billing address in the cart.",
            "trans": ""
        },
        "updateCartDeliveryAddressFail": {
            "orig": "Unable to update cart delivery address.",
            "trans": ""
        },
        "updateCartDeliveryDetailsFail": {
            "orig": "Unable to update cart delivery details",
            "trans": ""
        },
        "updateCartDeliveryMethodFail": {
            "orig": "Unable to update cart delivery method.",
            "trans": ""
        },
        "updateMarketingPreferences": {
            "orig": "To update your preferences please click",
            "trans": ""
        },
        "updateMarketingPreferencesLink": {
            "orig": "here",
            "trans": ""
        },
        "updatePasswordPasswordInvalid": {
            "orig": "Password must be at least 8 characters, containing at least  one number & one symbol",
            "trans": ""
        },
        "updateSymbolPasswordInvalid": {
            "orig": "Password must be at least 8 characters, containing at least one number & one symbol",
            "trans": ""
        },
        "updatedPdpBnplTerms": {
            "orig": "Buy now, pay later interest free instalments. This is a credit product. Late Payment Fees may apply with some providers. 18+ terms apply.",
            "trans": "This is an unregulated credit product. Late payment fees may apply with some providers. 18+ terms apply."
        },
        "usage": {
            "orig": "Usage",
            "trans": ""
        },
        "usage-description": {
            "orig": "size? Gift Cards are valid in any size? store within the UK. The card will expire and any remaining balance will reduce if it is not used within this 12 month period. For more info please read our full Terms & Conditions.",
            "trans": ""
        },
        "useAsBillingAddress": {
            "orig": "Use the same address for billing details",
            "trans": ""
        },
        "useAsDefaultBillingAddress": {
            "orig": "Use as Default Billing Address",
            "trans": ""
        },
        "useAsDefaultDeliveryAddress": {
            "orig": "Use as Default Delivery Address",
            "trans": ""
        },
        "useBillingAddressForDelivery": {
            "orig": "Use Billing Address for Delivery",
            "trans": ""
        },
        "useThePostcodeFinder": {
            "orig": "Use the postcode finder",
            "trans": ""
        },
        "userLoggedIn": {
            "orig": "You have been logged in",
            "trans": ""
        },
        "userRegisterFail": {
            "orig": "Some of the information entered is incorrect, please check and try again.",
            "trans": ""
        },
        "userSessionExpiredLogin": {
            "orig": "Your session has expired. Please sign in.",
            "trans": ""
        },
        "validateAddressCityMandatory": {
            "orig": "City is a mandatory field",
            "trans": ""
        },
        "validateAddressCountryMandatory": {
            "orig": "Country is a mandatory field",
            "trans": ""
        },
        "validateAddressFirstNameMandatory": {
            "orig": "First Name is a mandatory field",
            "trans": ""
        },
        "validateAddressLastNameMandatory": {
            "orig": "Last Name is a mandatory field",
            "trans": ""
        },
        "validateAddressPostcodeInvalid": {
            "orig": " Postcode is not valid",
            "trans": ""
        },
        "validateAddressPostcodeMandatory": {
            "orig": "Postcode is a mandatory field",
            "trans": ""
        },
        "validateAddressStateMandatory": {
            "orig": "County is a mandatory field",
            "trans": ""
        },
        "validateAddressStreetMandatory": {
            "orig": "Street Address is a mandatory field",
            "trans": ""
        },
        "validateAddressTitleInvalid": {
            "orig": "Title is not valid",
            "trans": ""
        },
        "validateCustomerConfirmPasswordMandatory": {
            "orig": "Confirmation Password is a mandatory field.",
            "trans": ""
        },
        "validateCustomerEmailInvalid": {
            "orig": "Email Address is not valid.",
            "trans": ""
        },
        "validateCustomerEmailMandatory": {
            "orig": "Email Address is a mandatory field.",
            "trans": ""
        },
        "validateCustomerEmailReset": {
            "orig": "The email address you entered is incorrect, please enter a valid email.",
            "trans": ""
        },
        "validateCustomerFirstNameInvalid": {
            "orig": "First Name is not valid.",
            "trans": ""
        },
        "validateCustomerFirstNameMandatory": {
            "orig": "First Name is a mandatory field.",
            "trans": ""
        },
        "validateCustomerLastNameInvalid": {
            "orig": "Last Name is not valid.",
            "trans": ""
        },
        "validateCustomerLastNameMandatory": {
            "orig": "Last Name is a mandatory field.",
            "trans": ""
        },
        "validateCustomerOrderNumberInvalid": {
            "orig": "Order number is not valid",
            "trans": ""
        },
        "validateCustomerPasswordInvalid": {
            "orig": "Password must contain a combination of letters and numbers.",
            "trans": ""
        },
        "validateCustomerPasswordLength": {
            "orig": "Password must be at least 8 characters.",
            "trans": ""
        },
        "validateCustomerPasswordMandatory": {
            "orig": "Password is a mandatory field.",
            "trans": ""
        },
        "validateCustomerPasswordMismatch": {
            "orig": "Passwords do not match.",
            "trans": ""
        },
        "validateCustomerPasswordSameCharacter3Times": {
            "orig": "Password cannot contain the same character 3 times consecutively.",
            "trans": ""
        },
        "validateCustomerPhoneInvalid": {
            "orig": "Phone Number is not valid.",
            "trans": ""
        },
        "validateCustomerPhoneMandatory": {
            "orig": "Phone Number is a mandatory field.",
            "trans": ""
        },
        "validateCustomerTitleInvalid": {
            "orig": "Title is not valid.",
            "trans": ""
        },
        "valueCheckoutNbspNbspGtGt": {
            "orig": "Checkout  >>",
            "trans": ""
        },
        "valueContinueSecurelyNbspNbspGtGt": {
            "orig": "Continue Securely  >>",
            "trans": ""
        },
        "valueSave": {
            "orig": "Save",
            "trans": ""
        },
        "vatIncluded": {
            "orig": "Includes VAT",
            "trans": ""
        },
        "view": {
            "orig": "View",
            "trans": ""
        },
        "view-now": {
            "orig": "View Now",
            "trans": ""
        },
        "view-our-privacyCollection": {
            "orig": "View our Privacy Collection Statement",
            "trans": ""
        },
        "view360Spinner": {
            "orig": "View 360 spinner",
            "trans": "View 360"
        },
        "viewAll": {
            "orig": "View All",
            "trans": ""
        },
        "viewAllDelvieryOptions": {
            "orig": "View all delivery options",
            "trans": ""
        },
        "viewBasket": {
            "orig": "View Basket",
            "trans": ""
        },
        "viewFullScreen": {
            "orig": "View Full Screen",
            "trans": ""
        },
        "viewLargerImage": {
            "orig": "View larger image",
            "trans": ""
        },
        "viewSizeGuide": {
            "orig": "View size guide",
            "trans": ""
        },
        "visit": {
            "orig": "Visit",
            "trans": ""
        },
        "visitOurCorporateWebsiteAt": {
            "orig": "Visit our corporate website at",
            "trans": ""
        },
        "was": {
            "orig": "Was",
            "trans": ""
        },
        "wasPrice": {
            "orig": "Was Price:",
            "trans": ""
        },
        "weAcceptCardsImage": {
            "orig": "We accept the following payment methods",
            "trans": ""
        },
        "weAcceptCardsList": {
            "orig": "We accept Visa, Visa Electron, Mastercard, Maestro, American Express, PayPal",
            "trans": ""
        },
        "weAcceptedOrder": {
            "orig": "Your Order has been accepted",
            "trans": ""
        },
        "weAreProcessingOrder": {
            "orig": "Your Order has is being processed",
            "trans": ""
        },
        "weMayUseThisToUpdateYou": {
            "orig": "We may use this to update you on the progress of your order or send you marketing communications",
            "trans": ""
        },
        "weWereUnableToBeginThePayment": {
            "orig": "We were unable to begin the payment process, please try again or contact us.",
            "trans": ""
        },
        "weWereUnableToCompleteYourOrder": {
            "orig": "We were unable to complete your order using the payment details provided, please verify your details and try again.",
            "trans": ""
        },
        "wednesday": {
            "orig": "Wednesday",
            "trans": ""
        },
        "welcome": {
            "orig": "Welcome",
            "trans": ""
        },
        "welcomeBack": {
            "orig": "Welcome Back",
            "trans": ""
        },
        "welcomeToNikeMembership": {
            "orig": "Welcome to Nike Membership at JD.",
            "trans": ""
        },
        "wellUseThisInformationToConfirmYour": {
            "orig": "We'll use this information to confirm your order and keep you updated on its progress.",
            "trans": ""
        },
        "whatDeliveryOptionsDoYouOfferAnd": {
            "orig": "What delivery options do you offer and how much does it cost?",
            "trans": ""
        },
        "whereIsMyOrder": {
            "orig": "Where is my order?",
            "trans": ""
        },
        "whoWillBeCollectingYourOrder": {
            "orig": "Who will be collecting your order?",
            "trans": ""
        },
        "whyHasMyOrderBeenCancelled": {
            "orig": "Why has my order been cancelled?",
            "trans": ""
        },
        "wishList": {
            "orig": "Wishlist",
            "trans": ""
        },
        "wishlist": {
            "orig": "Wishlist",
            "trans": ""
        },
        "wishlist-clearButton": {
            "orig": "Clear Wishlist",
            "trans": ""
        },
        "wishlist-count-many": {
            "orig": "{wishlistCount} items in list",
            "trans": ""
        },
        "wishlist-count-single": {
            "orig": "1 item in list",
            "trans": ""
        },
        "wishlist-createButton": {
            "orig": "Create new Wishlist",
            "trans": ""
        },
        "wishlist-deleteButton": {
            "orig": "Delete Wishlist",
            "trans": ""
        },
        "wishlist-deletePopup-confirm": {
            "orig": "Are you sure you want to delete the wishlist?",
            "trans": ""
        },
        "wishlist-deletePopup-title": {
            "orig": "Delete wishlist",
            "trans": ""
        },
        "wishlist-editButton": {
            "orig": "Edit",
            "trans": ""
        },
        "wishlist-editName-label": {
            "orig": "Wishlist Name",
            "trans": ""
        },
        "wishlist-editName-message": {
            "orig": "Please enter a name for your wishlist",
            "trans": ""
        },
        "wishlist-editName-placeholder": {
            "orig": "Wishlist",
            "trans": ""
        },
        "wishlist-editVisibility-label": {
            "orig": "Visibility",
            "trans": ""
        },
        "wishlist-editVisibility-private": {
            "orig": "Private",
            "trans": ""
        },
        "wishlist-editVisibility-shareable": {
            "orig": "Shareable",
            "trans": ""
        },
        "wishlist-editVisibility-tip": {
            "orig": "Shareable wishlists can be viewed by others with the link",
            "trans": ""
        },
        "wishlist-editWishlist-saveButton": {
            "orig": "Save",
            "trans": ""
        },
        "wishlist-editWishlist-saved": {
            "orig": "Saved",
            "trans": ""
        },
        "wishlist-editWishlist-title": {
            "orig": "Edit Wishlist",
            "trans": ""
        },
        "wishlist-loginButton": {
            "orig": "Login to add to account Wishlist",
            "trans": ""
        },
        "wishlist-makePrivateButton": {
            "orig": "Make Wishlist Private",
            "trans": ""
        },
        "wishlist-makeShareable-message": {
            "orig": "Make it shareable to enable sharing",
            "trans": ""
        },
        "wishlist-makeShareableButton": {
            "orig": "Make Wishlist Shareable",
            "trans": ""
        },
        "wishlist-newWishlist-title": {
            "orig": "New Wishlist",
            "trans": ""
        },
        "wishlist-notFound-message": {
            "orig": "If you followed a shared link to get here, it may be that the wishlist has been set to private",
            "trans": ""
        },
        "wishlist-notFound-title": {
            "orig": "We were unable to find the wishlist",
            "trans": ""
        },
        "wishlist-optionsButton": {
            "orig": "Options",
            "trans": ""
        },
        "wishlist-removeButton": {
            "orig": "Remove",
            "trans": ""
        },
        "wishlist-shareButton": {
            "orig": "Share",
            "trans": ""
        },
        "wishlist-title": {
            "orig": "My Wishlist",
            "trans": ""
        },
        "wishlist-unnamed": {
            "orig": "Wishlist",
            "trans": ""
        },
        "wishlist-visibility-isPrivate": {
            "orig": "This wishlist is private",
            "trans": ""
        },
        "wishlist-visibility-isShareable": {
            "orig": "This wishlist is visible to anyone with the link",
            "trans": ""
        },
        "wishlistContinueShopping": {
            "orig": "Continue shopping",
            "trans": ""
        },
        "wishlistCreate-error": {
            "orig": "Sorry, the wishlist name already exists",
            "trans": ""
        },
        "wishlistDelete-error": {
            "orig": "An error occurred when trying to delete wishlist",
            "trans": ""
        },
        "wishlistDelete-missingData": {
            "orig": "Sorry, there is missing data required for this request",
            "trans": ""
        },
        "wishlistShopOurRange": {
            "orig": "Shop our range",
            "trans": ""
        },
        "wishlistUpdate-error": {
            "orig": "Sorry, there was a problem updating your wishlist",
            "trans": ""
        },
        "wishlists": {
            "orig": "Wishlists",
            "trans": ""
        },
        "wishlists-title": {
            "orig": "My Wishlists",
            "trans": ""
        },
        "with": {
            "orig": "with",
            "trans": ""
        },
        "women": {
            "orig": "Women",
            "trans": ""
        },
        "womens": {
            "orig": "Womens",
            "trans": ""
        },
        "wouldYouLikeToUseTheAbove": {
            "orig": "Would you like to use the above address as your billing address?",
            "trans": ""
        },
        "writeAReview": {
            "orig": "Write a review",
            "trans": ""
        },
        "writeTheFirstReview": {
            "orig": "Write the first review",
            "trans": ""
        },
        "writeYourProductReview": {
            "orig": "Write your product review",
            "trans": ""
        },
        "yes": {
            "orig": "Yes",
            "trans": ""
        },
        "youCanNominateSomeoneElseToCollect": {
            "orig": "You can nominate someone else to collect your order. Identification and a copy of your order receipt is required.",
            "trans": ""
        },
        "youCurrentlyHaveNoOrdersOnRecord": {
            "orig": "You currently have no orders on record.",
            "trans": ""
        },
        "youCurrentlyHaveNoSavedAddresses": {
            "orig": "You currently have no saved addresses",
            "trans": ""
        },
        "youHaveSelected": {
            "orig": "You Have Selected",
            "trans": ""
        },
        "youHaventAddedAnythingToYour": {
            "orig": "You haven't added anything to your basket yet",
            "trans": ""
        },
        "youHaventAddedAnythingToYourWishlist": {
            "orig": "You haven't added anything to your wishlist yet",
            "trans": ""
        },
        "youMustInputAValidUKPostcode": {
            "orig": "You must input a valid UK postcode or town.",
            "trans": ""
        },
        "youWillNoLongerHaveAccessToNike": {
            "orig": "By disconnecting you will no longer have access to Nike Membership products, or be able to enjoy member-only content, experiences and offers.",
            "trans": ""
        },
        "yourAccountHasBeenUpdated": {
            "orig": "Your account has been updated.",
            "trans": ""
        },
        "yourBasketIsEmpty": {
            "orig": "Your basket is empty",
            "trans": ""
        },
        "yourBillingAddress": {
            "orig": "Your Billing Address",
            "trans": ""
        },
        "yourContactDetails": {
            "orig": "Your contact details?",
            "trans": ""
        },
        "yourDeliveryAddress": {
            "orig": "Your Delivery Address",
            "trans": ""
        },
        "yourDetails": {
            "orig": "Your Details",
            "trans": ""
        },
        "yourDetailsHaveBeenUpdated": {
            "orig": "Your details have been updated.",
            "trans": ""
        },
        "yourEmailAddressIsInvalid": {
            "orig": "Your email address is invalid",
            "trans": ""
        },
        "yourOrder": {
            "orig": "Your Order",
            "trans": ""
        },
        "yourOrderDetails": {
            "orig": "Your Order Details",
            "trans": ""
        },
        "yourOrderHasBeenDispatched": {
            "orig": "Your Order has been dispatched",
            "trans": ""
        },
        "yourPassword": {
            "orig": "Your Password",
            "trans": ""
        },
        "yourPasswordDoesNotContain8Digits": {
            "orig": "Your password does not contain 8 digits. Passwords must be at least 8 characters in length, and include both letters and numbers.",
            "trans": ""
        },
        "yourPasswordHasBeenUpdated": {
            "orig": "Your password has been updated.",
            "trans": ""
        },
        "yourPasswordShouldBeAtLeastCharacterSymbols": {
            "orig": "Your password should be at least 8 characters using a combination of  letters, numbers and symbols.",
            "trans": ""
        },
        "yourPasswordShouldBeAtLeastCharacters": {
            "orig": "Your password should be at least 8 characters using a combination of  letters and numbers",
            "trans": ""
        },
        "yourPaymentHasBeenCancelled": {
            "orig": "Your payment has been cancelled",
            "trans": ""
        },
        "yourPaymentHasBeenDeclined": {
            "orig": "Your payment has been declined",
            "trans": ""
        },
        "yourPaymentWasDeclined": {
            "orig": "Your payment was declined, please use another payment method. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "yourPaymentWasRejectedPleaseTryAgain": {
            "orig": "Your payment was rejected, please try again. No money has been taken and your cart is still intact.",
            "trans": ""
        },
        "yourPrivacyIsImportantToUsWe": {
            "orig": "Your privacy is important to us. We won't share your details with any other businesses or organisations without your consent.",
            "trans": ""
        },
        "yourPromotionalPreferencesHaveBeenUpdated": {
            "orig": "Your promotional preferences have been updated",
            "trans": ""
        },
        "yourSessionExpired": {
            "orig": "Sorry, Your session has expired",
            "trans": ""
        },
        "zipPostalCode": {
            "orig": "Zip\/Postal Code",
            "trans": ""
        }
    }
};